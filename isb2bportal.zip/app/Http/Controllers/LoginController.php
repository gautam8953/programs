<?php 
namespace App\Http\Controllers;
//use App\Http\Controllers\Controller;
use App\Models\LoginModel;
use Illuminate\Http\Request;
use Illuminate\Http\LoginMo;


class LoginController extends Controller
{
	
	function __construct()
	{
		
	}
	function login(Request $request){
		/*$dataSearch=array(
			'username'=>'admin',
			'password'=>'21232f297a57a5a743894a0e4a801fc3'
		);*/
		$dataSearch=$request->all();
		if(!empty($dataSearch['password'])){
			$dataSearch['password']=md5($dataSearch['password']);
		}
		$loginData=new LoginModel();
		$dataGet=$loginData->login($dataSearch);
		if(!empty($dataGet->id)){
			$returnData=array(
				'data'=>$dataGet,
				'code'=>0,
				'message'=>'Login Successful'
			);
		} else {
			$returnData=array(
				'code'=>2,
				'message'=>'Login Failed'
			);
		}
		return response()->json($returnData);
	}
}
