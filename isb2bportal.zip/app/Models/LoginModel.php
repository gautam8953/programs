<?php 
namespace App\Models;
use DB;

class LoginModel
{
	
	function __construct(){		
	}

	function login($dataSearch){
		$dataSearch['status']='1';
		$data=DB::table('users')->select('id','email','user_type','first_name','last_name')->where($dataSearch)->get()->first();
		//echo $data->toSql();
		return $data;
	}
}