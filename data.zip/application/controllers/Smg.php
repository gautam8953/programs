<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Smg extends CI_Controller {

    public function __construct() {
        parent :: __construct();
        $userID=$this->session->userdata('UserID');
        $RoleName=$this->session->userdata('RoleName');
        if(empty($userID)){ 
            redirect('user/login');
        } else {
            $this->load->model('SmgModel');
            $this->load->model('FacilityModel');
        }
    }

    public function index() {
        $data = array();
        $this->CommonModel->checkPageAccessWeb('smg/index',$this->session->userdata('RoleName'));
        /*if(!$this->CommonModel->checkPageActionWeb('smg/index','access_view',$this->session->userdata('RoleName'))){
            redirect('/');
        }*/
        $userID = $this->session->userdata('UserID');
        $data['search_options'] = $this->FacilityModel->getSearchOptions();
        $this->load->view('header');
        $this->load->view('smg/index', $data);
        $this->load->view('footer');
    }

    public function add() {
        //$this->CommonModel->checkPageAccessWeb('smg/add',$this->session->userdata('RoleName'));
        if(!$this->CommonModel->checkPageActionWeb('smg/add','access_add',$this->session->userdata('RoleName'))){
            redirect('/');
        }
        $data = array();
        $data['search_options'] = $this->FacilityModel->getSearchOptions();
        $this->load->view('header');
        $this->load->view('smg/add', $data);
        $this->load->view('footer');
    }

}
