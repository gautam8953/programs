<?php

defined('BASEPATH') OR exit('No direct script access allowed');

if ( ! function_exists('check_user'))
{
	function check_user()
	{
		$ci =& get_instance();
		$controllerName=$ci->router->fetch_class().' ';
		$methodeName=$ci->router->fetch_method();
		$url=strtolower($controllerName).'/'.strtolower($methodeName);
		$urlExcep=array('ApiUser/login','ApiUser/logout');
		if(!in_array($url,$urlExcep)){

		}
		$headers = getallheaders();
		//print_r($headers);		
		echo 'here in common helper';
		//die;
	}
}
if (!function_exists('convert_date_db')) {
    function convert_date_db($date){
        if(!empty($date)){
            /*$newdate=$date;
            $date=date('Y-m-d',strtotime($newdate));
            return $date;*/

            $newdate=$date;
            $date=date('Y-m-d',strtotime($newdate));
            if($date=='01-01-1970'){
                return null;
            } else {
                return $date;    
            }            
        } else {
            return null;
        }
    }
}
if (!function_exists('convert_date_show')) {
    function convert_date_show($date){
        if(!empty($date)){
            $newdate=$date;
            $date=date('d-m-Y',strtotime($newdate));
            if($date=='01-01-1970'){
                return '';
            } else {
                return $date;    
            }
        } else {
           return ''; 
       }
    }
}
if (!function_exists('convert_datetime_show')) {
    function convert_datetime_show($date){
        if(!empty($date)){
            $newdate=$date;
            $date=date('d-m-Y H:i:s',strtotime($newdate));
            if(date('Y',strtotime($date))<1985){
                return '';
            } else {
                return $date;    
            }
        } else {
           return ''; 
       }
    }
}

/* Form mishealth start */
if (!function_exists('actual_ip')) {
    function actual_ip(){
		$ipaddress = '';
        if(array_key_exists('HTTP_CLIENT_IP', $_SERVER))
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        elseif(array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        elseif(array_key_exists('HTTP_X_FORWARDED', $_SERVER))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        elseif(array_key_exists('HTTP_FORWARDED_FOR', $_SERVER))
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        elseif(array_key_exists('HTTP_FORWARDED', $_SERVER))
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        elseif(array_key_exists('REMOTE_ADDR', $_SERVER))
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress ;
	}
}

function check_input($theValue) {
	$theValue = trim($theValue);
  	$theValue = strip_tags($theValue);	
	$theValue = addslashes($theValue);
    $theValue = htmlspecialchars($theValue, ENT_QUOTES);
	//$ci=& get_instance();
	//$theValue = $ci->db->escape($theValue);
	return $theValue;
}
if(!function_exists('encryptor')){
    function encryptor($string,$action=NULL) {
        $output = false;
        $encrypt_method = "AES-256-CBC";
        //pls set your unique hashing key
        $secret_key = 'nphceashu';
        $secret_iv = 'nphceashuashu123';
        // hash
        $key = hash('sha256', $secret_key);
        // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
        $iv = substr(hash('sha256', $secret_iv), 0, 16);
        //do the encyption given text/string/number
        if( $action == 'decrypt' ) {
            //decrypt the given text/string/number
            $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        }
        else {
            $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
            $output = base64_encode($output);
            
        }
        return $output;
    }
}
function formatValue($value){
    return round($value,2);
}

/* Form mishealth end */