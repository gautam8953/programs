<?php

class CommonModel extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	function checkAPIWebUser(){
		$userID=$this->session->userdata('UserID');
		if(empty($userID)){ 
			return FALSE;
		} else { 
			return TRUE;
		}
	}
	function checkUser(){
		$userID=$this->session->userdata('UserID');
		if(empty($userID)){ 
			redirect('/');
		} else { 
			return TRUE;
		}
	}
	function checkAppRequest($dataHeader){
		include_once(APPPATH.'libraries/cryptojs-aes.php');
		$check=false;
		if(!empty($dataHeader['token'])){
			$tokenCheck=cryptoJsAesDecrypt(API_SALT,$dataHeader['token']);
			//$tokenCheck=encryptor($dataHeader['token'],'decrypt');
			if(empty($tokenCheck)){
				return false;
			} else {
				$tokenData=explode('_', $tokenCheck);
				$this->db->select('usertoken.UsertokenID,usertoken.LastActive,usertoken.Origin,role.RoleName,role.RoleID');
				$this->db->from('usertoken');
				$this->db->join('userrole', 'usertoken.UserID = userrole.UserID AND userrole.IsActive="1"', 'inner');
				$this->db->join('role', 'userrole.RoleID = role.RoleID AND role.IsActive="1"', 'inner');
				$this->db->where('usertoken.UserID',$tokenData[1]);
				$this->db->where('usertoken.LoginhistoryID',$tokenData[0]);
				$queryToken = $this->db->get();
				if($queryToken -> num_rows()>=1){
					$result_set = $queryToken->result();
					//echo date('Y-m-d H:i:s').' <-> '.$result_set[0]->LastActive.'  -> ';
					$start_date = new DateTime($result_set[0]->LastActive);
					$since_start = $start_date->diff(new DateTime(date('Y-m-d H:i:s')));
					$timeElapsed=explode(':',$since_start->format("%a:%H:%I:%S"));
					/*echo $since_start->i."<br>";
					echo $since_start->h."<br>";
					echo $since_start->days."<br>";
					echo date('Y-m-d H:i:s')."<br>";
					echo $result_set[0]->LastActive."<br>";*/
					if($since_start->i<30 && $since_start->h=='0' && $since_start->days=='0'){
						// same prev hit time cond removed $result_set[0]->LastActive==$tokenData[3] &&
						if($result_set[0]->Origin==$tokenData[2]){
							//$origin=$_SERVER['HTTP_ORIGIN'];
							$callTime=date('Y-m-d H:i:s');
							$APIKey= cryptoJsAesEncrypt(API_SALT, $tokenData[0].'_'.$tokenData[1].'_'.$tokenData[2].'_'.$callTime);
							$updateToken=array(
								'LastActive'=>$callTime,
								'Token'=>$APIKey
							);
						  	$sqlState="SELECT GROUP_CONCAT(DISTINCT StateID) as mappedStates FROM `usermapping` WHERE `UserID`='".trim($tokenData[1])."' and IsActive='1'";
						    $queryState = $this->db->query($sqlState, NULL);
						    $resultState=$queryState->row_array();
						    if(isset($resultState['mappedStates'])){
						    	$MappedState=$resultState['mappedStates'];
						    } else {
						    	$MappedState='';
						    }
						  	$sqlDistrict="SELECT GROUP_CONCAT(DISTINCT DistrictID) as mappedDis FROM `usermapping` WHERE `UserID`='".trim($tokenData[1])."' and IsActive='1'";
						    $queryDistrict = $this->db->query($sqlDistrict, NULL);
						    $resultDistrict=$queryDistrict->row_array();
						    if(isset($resultDistrict['mappedDis'])){
						    	$MappedDistrict=$resultDistrict['mappedDis'];
						    } else {
						    	$MappedDistrict='';
						    }
						  	$sqlFacility="SELECT GROUP_CONCAT(DISTINCT AssignedFacilities) as mappedFacilities FROM `usermapping` WHERE `UserID`='".trim($tokenData[1])."' and IsActive='1'";
						    $queryFacility = $this->db->query($sqlFacility, NULL);
						    $resultFacility=$queryFacility->row_array();
						    if(isset($resultFacility['mappedFacilities'])){
						    	$AssignedFacilities=$resultFacility['mappedFacilities'];
						    } else {
						    	$AssignedFacilities='';
						    }

							$this->db->where('UsertokenID', $result_set[0]->UsertokenID);
							$this->db->update('usertoken', $updateToken);
							$this->session->set_userdata('MappedState', $MappedState);
							$this->session->set_userdata('MappedDistrict', $MappedDistrict);
							$this->session->set_userdata('AssignedFacilities', $AssignedFacilities);
							$this->session->set_userdata('UserID', trim($tokenData[1]));
							$this->session->set_userdata('APIKey', $APIKey);
							$this->session->set_userdata('RoleName', $result_set[0]->RoleName);
							$this->session->set_userdata('RoleID', $result_set[0]->RoleID);
							$this->session->set_userdata('accessData', $this->CommonModel->getMenu());
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}

				} else {
					return false;
				}
			}
		} else {
			return false;
		}
	}
	function getApiData(){
		if(!empty($this->input->post())){
		    $data = $this->input->post();
		} else {
		    $data = json_decode(file_get_contents('php://input'), true);
		}
		if(empty($data)){
            $response['code'] = '13';
            $response['msg'] = $this->config->item('errCodes')[13].' raw';
		} else {
			return $data;			
		}

	}
 	function facilitySearchData($userId){
	    $this->db->select('usermapping.UserID,facilities.FacilityName,states.StateName,states.StateID,district.DistrictID,district.DistrictName,typedetail.TypeDetailID,typedetail.TypeDetailCode');
	    $this->db->from('usermapping');
	    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
	    $this->db->join('states', 'facilities.StateID=states.StateID', 'left');
	    $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'left');
	    $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');
	    $this->db->where('usermapping.UserID',$userId);
	    $this->db->where('usermapping.FacilityID >','0');
	    $this->db->limit('1');
	    $result = $this->db->get();
	    if($result -> num_rows()>=1){
	    	$dataFacility=$result->result_array();
	    } else {
	    	$dataFacility=array();
	    }
		return $dataFacility; 		
 	}


	function createRandamPassword()
	{
		$length = 10;
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$password = substr( str_shuffle( $chars ), 0, $length );
		return $password;		
	}
	function checkPassword($pwd){
		$error='';
		if( !preg_match("#[0-9]+#", $pwd) ) {
			$error = "Password must include at least one number! ";
		}
		if( !preg_match("#[a-z]+#", $pwd) ) {
			$error = "Password must include at least one letter! ";
		}
		if( !preg_match("#[A-Z]+#", $pwd) ) {
			$error = "Password must include at least one CAPS! ";
		}
		if( !preg_match("#\W+#", $pwd) ) {
			$error = "Password must include at least one symbol! ";
		}
		if( strlen($pwd)< 8 ) {
			$error = "Password length shold be at least 8 character! ";
		}
		if( strlen($pwd) > 16 ) {
			$error = "Password length should not exceed 16 character ";
		}
		return $error;
	}
 	function getlaqshyaFacilityData($data,$search){
		if ($search['RoleName'] == 'District') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.DistrictID';
        } else if ($search['RoleName'] == 'State') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.StateID';
        } else {
            $mappedData = explode(",", $search['mapped']);
        	$mappedField='f.StateID';
        }        
        $col = array(
            0 => 's.StateName',
            1 => 'd.DistrictName',
            2 => 'f.FacilityName',
            3 => 't.TypeDetailCode',
            4 => 'f.FacilityNumber',
        );
	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    $this->db->where('f.Islaqshya','1');
	    if(!empty($data['search_param1']) && $data['search_param1']!='Others'){
	    	$searchText=implode(' ', explode('_',trim($data['search_param1'])));
	    	$this->db->where('t.TypeDetailCode',$searchText);
	    	$this->db->where('t.TypeMasterID','4');
	    }
	    if(!empty($data['search_param1']) && $data['search_param1']=='Others'){
	    	$idsType=array('107','105','64','103','440');
		    $this->db->where_not_in('t.TypeDetailID', $idsType);
		    $this->db->where('t.TypeMasterID','4');
	    }
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($data['search']['value'])){
            $searchString=trim($data['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $queryTot = $this->db->get();

	    // data query
	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    $this->db->where('f.Islaqshya','1');
	    if(!empty($data['search_param1']) && $data['search_param1']!='Others'){
	    	$searchText=implode(' ', explode('_',trim($data['search_param1'])));
	    	$this->db->where('t.TypeDetailCode',$searchText);
	    	$this->db->where('t.TypeMasterID','4');
	    }
	    if(!empty($data['search_param1']) && $data['search_param1']=='Others'){
	    	$idsType=array('107','105','64','103','440');
		    $this->db->where_not_in('t.TypeDetailID', $idsType);
		    $this->db->where('t.TypeMasterID','4');
	    }
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($data['search']['value'])){
            $searchString=trim($data['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $this->db->order_by($col[$data['order'][0]['column']], $data['order'][0]['dir']);
	    $this->db->limit($data['length'],$data['start']);
	    $query = $this->db->get();
		$data1=array();
		foreach ($query->result() as $key => $value) {
		    $subdata=array();
		    $subdata[]=$value->StateName;
		    $subdata[]=$value->DistrictName;
		    $subdata[]=$value->FacilityName;
		    $subdata[]=$value->FacilityNumber;
		    $subdata[]=$value->TypeDetailCode;		     
		    $data1[]=$subdata;
		}
		$json_data=array(
		    "draw"              =>  intval($data['draw']),
		    "recordsTotal"      =>  intval($queryTot->num_rows()),
		    "recordsFiltered"   =>  intval($queryTot->num_rows()),
		    "data"              =>  $data1
		);
 		return $json_data;

 	}
 	function getlaqshyabaselrData($data,$search){
		if ($search['RoleName'] == 'District') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.DistrictID';
        } else if ($search['RoleName'] == 'State') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.StateID';
        } else {
            $mappedData = explode(",", $search['mapped']);
        	$mappedField='f.StateID';
        }        
        if($data['aspirational']=='aspirational'){
        	$condAspir=' AND d.IsHighPriority="1" ';
        } else {
        	$condAspir='';
        }
        $col = array(
            0 => 's.StateName',
            1 => 'd.DistrictName',
            2 => 'f.FacilityName',
            3 => 't.TypeDetailCode',
            3 => 'f.FacilityNumber',
        );
	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1 '.$condAspir, 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    $this->db->join('answer a', 'a.UserID=um.UserID AND um.FacilityID>0 AND a.IsActive=1 AND a.SurveyStatus=1 AND a.Sequence="1" AND a.SurveyID=1', 'inner');
	    $this->db->where('f.Islaqshya','1');
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $queryTot = $this->db->get();

	    // data query
	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1 '.$condAspir, 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    $this->db->join('answer a', 'a.UserID=um.UserID AND um.FacilityID>0 AND a.IsActive=1 AND a.SurveyStatus=1 AND a.Sequence="1" AND a.SurveyID=1', 'inner');
	    $this->db->where('f.Islaqshya','1');
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($data['search']['value'])){
            $searchString=trim($data['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $this->db->order_by($col[$data['order'][0]['column']], $data['order'][0]['dir']);
	    $this->db->limit($data['length'],$data['start']);
	    $query = $this->db->get();
		$data1=array();
		foreach ($query->result() as $key => $value) {
		    $subdata=array();
		    $subdata[]=$value->StateName;
		    $subdata[]=$value->DistrictName;
		    $subdata[]=$value->FacilityName;
		    $subdata[]=$value->FacilityNumber;
		    $subdata[]=$value->TypeDetailCode;		     
		    $data1[]=$subdata;
		}
		$json_data=array(
		    "draw"              =>  intval($data['draw']),
		    "recordsTotal"      =>  intval($queryTot->num_rows()),
		    "recordsFiltered"   =>  intval($queryTot->num_rows()),
		    "data"              =>  $data1
		);
 		return $json_data;

 	}
 	function getlaqshyabaseotData($data,$search){
		if ($search['RoleName'] == 'District') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.DistrictID';
        } else if ($search['RoleName'] == 'State') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.StateID';
        } else {
            $mappedData = explode(",", $search['mapped']);
        	$mappedField='f.StateID';
        }        
        if($data['aspirational']=='aspirational'){
        	$condAspir=' AND d.IsHighPriority="1" ';
        } else {
        	$condAspir='';
        }
        $col = array(
            0 => 's.StateName',
            1 => 'd.DistrictName',
            2 => 'f.FacilityName',
            3 => 't.TypeDetailCode',
            3 => 'f.FacilityNumber',
        );
	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1 '.$condAspir, 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    $this->db->join('answer a', 'a.UserID=um.UserID AND um.FacilityID>0 AND a.IsActive=1 AND a.SurveyStatus=1 AND a.Sequence="1" AND a.SurveyID=2', 'inner');
	    $this->db->where('f.Islaqshya','1');
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $queryTot = $this->db->get();

	    // data query
	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1 '.$condAspir, 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    $this->db->join('answer a', 'a.UserID=um.UserID AND um.FacilityID>0 AND a.IsActive=1 AND a.SurveyStatus=1 AND a.Sequence="1" AND a.SurveyID=2', 'inner');
	    $this->db->where('f.Islaqshya','1');
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($data['search']['value'])){
            $searchString=trim($data['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $this->db->order_by($col[$data['order'][0]['column']], $data['order'][0]['dir']);
	    $this->db->limit($data['length'],$data['start']);
	    $query = $this->db->get();
		$data1=array();
		foreach ($query->result() as $key => $value) {
		    $subdata=array();
		    $subdata[]=$value->StateName;
		    $subdata[]=$value->DistrictName;
		    $subdata[]=$value->FacilityName;
		    $subdata[]=$value->FacilityNumber;
		    $subdata[]=$value->TypeDetailCode;		     
		    $data1[]=$subdata;
		}
		$json_data=array(
		    "draw"              =>  intval($data['draw']),
		    "recordsTotal"      =>  intval($queryTot->num_rows()),
		    "recordsFiltered"   =>  intval($queryTot->num_rows()),
		    "data"              =>  $data1
		);
 		return $json_data;

 	}
 	function getlaqshyalrData($data,$search){
		if ($search['RoleName'] == 'District') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.DistrictID';
        } else if ($search['RoleName'] == 'State') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.StateID';
        } else {
            $mappedData = explode(",", $search['mapped']);
        	$mappedField='f.StateID';
        }        
        $col = array(
            0 => 's.StateName',
            1 => 'd.DistrictName',
            2 => 'f.FacilityName',
            3 => 't.TypeDetailCode',
            3 => 'f.FacilityNumber',
        );
	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    $this->db->where('f.Islaqshya','1');
	    $this->db->where('f.LrQualified','1');
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $queryTot = $this->db->get();

	    // data query
	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    $this->db->where('f.Islaqshya','1');
	    $this->db->where('f.LrQualified','1');
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($data['search']['value'])){
            $searchString=trim($data['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $this->db->order_by($col[$data['order'][0]['column']], $data['order'][0]['dir']);
	    $this->db->limit($data['length'],$data['start']);
	    $query = $this->db->get();
		$data1=array();
		foreach ($query->result() as $key => $value) {
		    $subdata=array();
		    $subdata[]=$value->StateName;
		    $subdata[]=$value->DistrictName;
		    $subdata[]=$value->FacilityName;
		    $subdata[]=$value->FacilityNumber;
		    $subdata[]=$value->TypeDetailCode;		     
		    $data1[]=$subdata;
		}
		$json_data=array(
		    "draw"              =>  intval($data['draw']),
		    "recordsTotal"      =>  intval($queryTot->num_rows()),
		    "recordsFiltered"   =>  intval($queryTot->num_rows()),
		    "data"              =>  $data1
		);
 		return $json_data;

 	}
 	function getlaqshyaotData($data,$search){
		if ($search['RoleName'] == 'District') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.DistrictID';
        } else if ($search['RoleName'] == 'State') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.StateID';
        } else {
            $mappedData = explode(",", $search['mapped']);
        	$mappedField='f.StateID';
        }        
        $col = array(
            0 => 's.StateName',
            1 => 'd.DistrictName',
            2 => 'f.FacilityName',
            3 => 't.TypeDetailCode',
            3 => 'f.FacilityNumber',
        );
	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    $this->db->where('f.Islaqshya','1');
	    $this->db->where('f.OtQualified','1');
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $queryTot = $this->db->get();

	    // data query
	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    $this->db->where('f.Islaqshya','1');
	    $this->db->where('f.OtQualified','1');
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($data['search']['value'])){
            $searchString=trim($data['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $this->db->order_by($col[$data['order'][0]['column']], $data['order'][0]['dir']);
	    $this->db->limit($data['length'],$data['start']);
	    $query = $this->db->get();
		$data1=array();
		foreach ($query->result() as $key => $value) {
		    $subdata=array();
		    $subdata[]=$value->StateName;
		    $subdata[]=$value->DistrictName;
		    $subdata[]=$value->FacilityName;
		    $subdata[]=$value->FacilityNumber;
		    $subdata[]=$value->TypeDetailCode;		     
		    $data1[]=$subdata;
		}
		$json_data=array(
		    "draw"              =>  intval($data['draw']),
		    "recordsTotal"      =>  intval($queryTot->num_rows()),
		    "recordsFiltered"   =>  intval($queryTot->num_rows()),
		    "data"              =>  $data1
		);
 		return $json_data;

 	}
 	function dashboard_facility_data($data){
 		$dataFacility=array();
	    $this->db->select('facilities.FacilityID,facilities.services');
	    $this->db->from('usermapping');
	    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID AND usermapping.FacilityID>0', 'inner');
	    $this->db->where('usermapping.UserID',$data['userID']);
	    $this->db->where('usermapping.IsActive','1');
	    $query = $this->db->get();
		$facilityData=$query->row_array();
		if($facilityData['FacilityID']>0){
			$dataFacility['facilityType']='lr';
		    $this->db->select('answer.AnswerID,answer.AssessmentDate,answer.SurveyStatus,answer.SurveyID,answer.Sequence');
		    $this->db->from('answer');
		    $this->db->where('answer.UserID',$data['userID']);
		    $this->db->where('answer.SurveyID','1');
		    $this->db->where('answer.IsActive','1');
		    $this->db->order_by('answer.AnswerID', 'DESC');
		    $this->db->limit('1');
		    $resultLR = $this->db->get();
		    if($resultLR ->num_rows()>0){
		    	$dataFacility['LR']=$resultLR->row_array();
		    }
			if($facilityData['services']=='both'){
				$dataFacility['facilityType']='both';
			    $this->db->select('answer.AnswerID,answer.AssessmentDate,answer.SurveyStatus,answer.SurveyID,answer.Sequence');
			    $this->db->from('answer');
			    $this->db->where('answer.UserID',$data['userID']);
			    $this->db->where('answer.SurveyID','2');
			    $this->db->where('answer.IsActive','1');
			    $this->db->order_by('answer.AnswerID', 'DESC');
			    $this->db->limit('1');
			    $resultOT = $this->db->get();
			    if($resultOT ->num_rows()>0){
			    	$dataFacility['OT']=$resultOT->row_array();
			    }
			}
		    $this->db->select('monthly.MonthlyID,monthly.ReportMonth,monthly.MonthlyStatus');
		    $this->db->from('monthly');
		    $this->db->where('monthly.UserID',$data['userID']);
		    $this->db->order_by('monthly.ReportMonth', 'DESC');
		    $this->db->limit('1');
		    $resultMonth = $this->db->get();
		    if($resultMonth ->num_rows()>0){
		    	$dataFacility['monthly']=$resultMonth->row_array();
		    }

		    // Certificate Status started
		    $this->db->select('stateOr.CertificationID,stateOr.status');
		    $this->db->from('certification stateOr');
		    $this->db->where('stateOr.UserID',$data['userID']);
		    $this->db->where('stateOr.certification_type','so');
		    $this->db->where('stateOr.level','3');
		    $this->db->where('stateOr.IsCurrent','1');
		    $this->db->where('stateOr.IsActive','1');
		    $this->db->order_by('stateOr.CertificationID', 'DESC');
		    $this->db->limit('1');
		    $result = $this->db->get();
		    if($result ->num_rows()>0){
		    	$dataFacility['stateOr']=$result->row_array();
		    }
		    
		    $this->db->select('StatecLR.CertificationID,StatecLR.status');
		    $this->db->from('certification StatecLR');
		    $this->db->where('StatecLR.UserID',$data['userID']);
		    $this->db->where('StatecLR.certification_type','lr');
		    $this->db->where('StatecLR.level','2');
		    $this->db->where('StatecLR.IsCurrent','1');
		    $this->db->where('StatecLR.IsActive','1');
		    $this->db->order_by('StatecLR.CertificationID', 'DESC');
		    $this->db->limit('1');
		    $result = $this->db->get();
		    if($result ->num_rows()>0){
		    	$dataFacility['StatecLR']=$result->row_array();
		    }

		    $this->db->select('StatecOT.CertificationID,StatecOT.status');
		    $this->db->from('certification StatecOT');
		    $this->db->where('StatecOT.UserID',$data['userID']);
		    $this->db->where('StatecOT.certification_type','ot');
		    $this->db->where('StatecOT.level','2');
		    $this->db->where('StatecOT.IsCurrent','1');
		    $this->db->where('StatecOT.IsActive','1');
		    $this->db->order_by('StatecOT.CertificationID', 'DESC');
		    $this->db->limit('1');
		    $result = $this->db->get();
		    if($result ->num_rows()>0){
		    	$dataFacility['StatecOT']=$result->row_array();
		    }
		    
		    $this->db->select('cLR.CertificationID,cLR.status');
		    $this->db->from('certification cLR');
		    $this->db->where('cLR.UserID',$data['userID']);
		    $this->db->where('cLR.certification_type','lr');
		    $this->db->where('cLR.level','1');
		    $this->db->where('cLR.IsCurrent','1');
		    $this->db->where('cLR.IsActive','1');
		    $this->db->order_by('cLR.CertificationID', 'DESC');
		    $this->db->limit('1');
		    $result = $this->db->get();
		    if($result ->num_rows()>0){
		    	$dataFacility['cLR']=$result->row_array();
		    }

		    $this->db->select('cOT.CertificationID,cOT.status');
		    $this->db->from('certification cOT');
		    $this->db->where('cOT.UserID',$data['userID']);
		    $this->db->where('cOT.certification_type','ot');
		    $this->db->where('cOT.level','1');
		    $this->db->where('cOT.IsCurrent','1');
		    $this->db->where('cOT.IsActive','1');
		    $this->db->order_by('cOT.CertificationID', 'DESC');
		    $this->db->limit('1');
		    $result = $this->db->get();
		    if($result ->num_rows()>0){
		    	$dataFacility['cOT']=$result->row_array();
		    }


		    $this->db->select('answer.AnswerID,answer.AssessmentDate,answer.SurveyStatus,answer.SurveyID,answer.Sequence');
		    $this->db->from('answer');
		    $this->db->where('answer.UserID',$data['userID']);
		    $this->db->where('answer.SurveyID','1');
		    $this->db->where('answer.Sequence','1');
		    $this->db->where('answer.IsActive','1');
		    $this->db->order_by('answer.AnswerID', 'DESC');
		    $this->db->limit('1');
		    $resultLR = $this->db->get();
		    if($resultLR ->num_rows()>0){
		    	$dataFacility['BaselineLR']=$resultLR->row_array();
		    }
			if($facilityData['services']=='both'){
				$dataFacility['facilityType']='both';
			    $this->db->select('answer.AnswerID,answer.AssessmentDate,answer.SurveyStatus,answer.SurveyID,answer.Sequence');
			    $this->db->from('answer');
			    $this->db->where('answer.UserID',$data['userID']);
			    $this->db->where('answer.SurveyID','2');
			    $this->db->where('answer.Sequence','1');
			    $this->db->where('answer.IsActive','1');
			    $this->db->order_by('answer.AnswerID', 'DESC');
			    $this->db->limit('1');
			    $resultOT = $this->db->get();
			    if($resultOT ->num_rows()>0){
			    	$dataFacility['BaselineOT']=$resultOT->row_array();
			    }
			}
		    // Certificate Status ended
		}
		return $dataFacility;
 	}
 	function checkFacilityAssessment($searchType,$UserID){
 		$respone=array('code'=>'0');
 		if($searchType=='lr'){
		    $this->db->select('answer.AnswerID,facilities.services');
		    $this->db->from('usermapping');
		    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID AND usermapping.FacilityID>0', 'inner');
		    $this->db->join('answer', 'usermapping.UserID=answer.UserID AND answer.IsActive="1" AND answer.SurveyID="2" ', 'left');
		    $this->db->where('usermapping.UserID',$UserID);
		    $this->db->limit('1');
		    $resultOT = $this->db->get();
		    $dataFacilityOT=$resultOT->row_array();
		    if(!empty($dataFacilityOT['AnswerID'])){
		    	$respone['code']='16';
		    	$respone['type']=$dataFacilityOT['services'];
		    	$respone['msg']='OT Assessment already filled, So services provided can not be changed';
		    }
 		}
 		if($searchType=='both'){
		    $this->db->select('answer.AnswerID,facilities.services');
		    $this->db->from('usermapping');
		    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID AND usermapping.FacilityID>0', 'inner');
		    $this->db->join('answer', 'usermapping.UserID=answer.UserID AND answer.IsActive="1" AND answer.SurveyID="1" AND answer.Sequence="2" ', 'left');
		    $this->db->where('usermapping.UserID',$UserID);
		    $this->db->limit('1');
		    $resultOT = $this->db->get();
		    $dataFacilityOT=$resultOT->row_array();
		    if(!empty($dataFacilityOT['AnswerID'])){
		    	$respone['code']='16';
		    	$respone['type']=$dataFacilityOT['services'];
		    	$respone['msg']='LR OtherLine Assessment already filled, So services provided can not be changed';
		    }
 		}
	    return $respone;
 	}
 	function dashboard_ministry_data($search){
	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('answer a', 'a.UserID=um.UserID AND um.FacilityID>0 AND a.IsActive=1 AND a.SurveyStatus=1 AND a.Sequence="1" ', 'inner');
	    $this->db->where('f.Islaqshya','1');
	    $this->db->group_by('um.UserID');
	    $query = $this->db->get();
	    $data['totalBaseLaQshya']=$query->num_rows();

	  	$this->db->select('f.FacilityID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->where('f.LrQualified','1');
	    $this->db->where('f.OtQualified','1');
	    $query = $this->db->get();
	    $data['totalQfLaQshya']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsHighPriority=1', 'inner');
	    $this->db->join('answer a', 'a.UserID=um.UserID AND um.FacilityID>0 AND a.IsActive=1 AND a.SurveyStatus=1 AND a.Sequence="1" ', 'inner');
	    $this->db->where('f.Islaqshya','1');
	    $this->db->group_by('um.UserID');
	    $query = $this->db->get();
	    $data['totalBaseLaQshyaDh']=$query->num_rows();


	  	$this->db->select('sum(m.BirthCompanionNos) as BirthCompanionNos,sum(m.SafeBirthChecklist) as SafeBirthChecklist,sum(m.CSectionOTSafeChecklist) as CSectionOTSafeChecklist, sum(m.RealTimePartograph) as RealTimePartograph');
	    $this->db->from('monthly m');
	    $this->db->where('m.ReportMonth',date('Y-m-01'));
	    $resultDeliveryQualityPie = $this->db->get();
	    $dataDeliveryQualityPie=$resultDeliveryQualityPie->row_array();

	    $data['deliveryQualityPie']=array(
	    	'deliveries are attended by a birth companion'=>$dataDeliveryQualityPie['BirthCompanionNos']>0?$dataDeliveryQualityPie['BirthCompanionNos']:0,
	    	'deliveries are conducted using safe birth checklist in Labour Room'=>$dataDeliveryQualityPie['SafeBirthChecklist']>0?$dataDeliveryQualityPie['SafeBirthChecklist']:0,
	    	'deliveries are conducted using  Safe Surgery checklist in Maternity OT'=>$dataDeliveryQualityPie['CSectionOTSafeChecklist']>0?$dataDeliveryQualityPie['CSectionOTSafeChecklist']:0,
	    	'deliveries for which Partograph is generated using real-time information in at least'=>$dataDeliveryQualityPie['RealTimePartograph']>0?$dataDeliveryQualityPie['RealTimePartograph']:0
	    );	    


 		return $data;

 	}
 	function getAllStates(){
	    $this->db->select('states.StateID,states.StateName');
	    $this->db->from('states');
	    $this->db->where('states.IsActive','1');		
	    $this->db->order_by('states.StateName', 'ASC');
	    $query = $this->db->get();
		$dataget=array();
		foreach ($query->result() as $key => $value) {
		    $subdata=array();
		    $subdata['StateID'] = $value->StateID;
		    $subdata['StateName'] = $value->StateName;
		    $dataget[]=$subdata;
		}
		$respone=array();
		$respone['totalData']=$query -> num_rows();
		$respone['data']=$dataget;
		$respone['code']='10';
		$respone['msg']='data get';
		return $respone;
	

 	}
 	function ministry_dashboard_new($search){
 		// box start
	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $query = $this->db->get();
	    $data['totalLaQshya']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','441');
	    $query = $this->db->get();
	    $data['totalCHC']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','451');
	    $query = $this->db->get();
	    $data['totalFRU']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','442');
	    $query = $this->db->get();
	    $data['totalDisFacility']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','485');
	    $query = $this->db->get();
	    $data['totalMedFacility']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','455');
	    $query = $this->db->get();
	    $data['totalSubDivFacility']=$query->num_rows();

		$idsType=array('441','451','442','485','455');
		$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where_not_in('t.TypeDetailID', $idsType);
	    $this->db->where('t.TypeMasterID','4');
	    $query = $this->db->get();
	    $data['totalOtherFacility']=$query->num_rows();

	    // box end

	    // map start
	  	$this->db->select('s.StateName as catName,count(f.FacilityID) as facilities,s.mapCode,
				IFNULL(sum(aLR.SurveyStatus),"NA") as LrBaseLine, 
				IFNULL(sum(aOT.SurveyStatus),"NA") as OtbaseLine,
				IFNULL(sum(cLR.IsActive),"NA") as certifiedLR,
				IFNULL(sum(cOT.IsActive),"NA") as certifiedOT,
				IFNULL(sum(cSLR.IsActive),"NA") as stateCertifiedLR,
				IFNULL(sum(cSOT.IsActive),"NA") as stateCertifiedOT
	  		');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('answer aLR','um.UserID=aLR.UserID AND aLR.IsActive=1 AND aLR.SurveyStatus=1 AND aLR.Sequence=11 AND aLR.SurveyID=1', 'left');
	    $this->db->join('answer aOT','um.UserID=aOT.UserID AND aOT.IsActive=1 AND aOT.SurveyStatus=1 AND aOT.Sequence=11 AND aOT.SurveyID=2', 'left');
	    $this->db->join('certification cLR','um.UserID=cLR.userID AND cLR.certification_type="lr" AND cLR.level=1 AND cLR.status=3 AND cLR.IsCurrent=1 AND cLR.IsActive=1', 'left');
	    $this->db->join('certification cOT','um.UserID=cOT.userID AND cOT.certification_type="ot" AND cOT.level=1 AND cOT.status=3 AND cOT.IsCurrent=1 AND cOT.IsActive=1', 'left');
	    $this->db->join('certification cSLR','um.UserID=cSLR.userID AND cSLR.certification_type="lr" AND cSLR.level=1 AND cSLR.status=3 AND cSLR.IsCurrent=1 AND cSLR.IsActive=1', 'left');
	    $this->db->join('certification cSOT','um.UserID=cSOT.userID AND cSOT.certification_type="ot" AND cSOT.level=1 AND cSOT.status=3 AND cSOT.IsCurrent=1 AND cSOT.IsActive=1', 'left');
	    $this->db->group_by('f.StateID');
	    $query = $this->db->get();

	    $keys=array('injs1','injs2','injs3','injs4','injs5','injs6','injs7','injs8','injs9','injs10','injs11','injs12','injs13','injs14','injs15','injs16','injs17','injs18','injs19','injs20','injs21','injs22','injs23','injs24','injs25','injs26','injs27','injs28','injs29','injs30','injs31','injs32','injs33','injs34','injs35','injs36');
	    $result_chart=array_fill_keys($keys, array());
	    foreach ($query->result_array() as $key => $value) {
	    	if(empty($result_chart[$value['mapCode']])){
	    		$result_chart[$value['mapCode']]=$value;
	    	} else {
	    		$result_chart[$value['mapCode']]['facilities']=$value['facilities'];
	    		$result_chart[$value['mapCode']]['certifiedLR']=$value['certifiedLR'];
	    		$result_chart[$value['mapCode']]['certifiedOT']=$value['certifiedOT'];
	    		$result_chart[$value['mapCode']]['LrBaseLine']=$value['LrBaseLine'];
	    		$result_chart[$value['mapCode']]['OtbaseLine']=$value['OtbaseLine'];
	    		$result_chart[$value['mapCode']]['stateCertifiedLR']=$value['stateCertifiedLR'];
	    		$result_chart[$value['mapCode']]['stateCertifiedOT']=$value['stateCertifiedOT'];
	    	}

	    }
	    $data['dataMap']=$result_chart;
	
	    /*$qryMap='SELECT s.`StateName` as catName,s.FacilityNum as facilitiesNew,s.FacilityNum as facilities,s.mapCode,IF(sd.baseline>0,sd.baseline,"NA") as LrBaseLine,IF(sd.baseline>0,sd.baseline,"NA") as OtbaseLine,IF(sd.national_lr>0,sd.national_lr,"NA") as certifiedLR,IF(sd.national_ot>0,sd.national_ot,"NA") as certifiedOT,IF(sd.state_lr>0,sd.state_lr,"NA") as stateCertifiedLR,IF(sd.state_ot>0,sd.state_ot,"NA") as stateCertifiedOT 
FROM `states` s
INNER JOIN state_static_data sd on(s.StateID=sd.state_id)
WHERE s.CountryID=1 AND s.IsActive=1 ORDER BY `StateID` ASC';
	    $query = $this->db->query($qryMap);
	    $keys=array('injs1','injs2','injs3','injs4','injs5','injs6','injs7','injs8','injs9','injs10','injs11','injs12','injs13','injs14','injs15','injs16','injs17','injs18','injs19','injs20','injs21','injs22','injs23','injs24','injs25','injs26','injs27','injs28','injs29','injs30','injs31','injs32','injs33','injs34','injs35','injs36');
	    $result_chart=array_fill_keys($keys, array());
	    foreach ($query->result_array() as $key => $value) {
	    	if(empty($result_chart[$value['mapCode']])){
	    		$result_chart[$value['mapCode']]=$value;
	    	} else {
	    		$result_chart[$value['mapCode']]['facilities']=$value['facilities'];
	    		$result_chart[$value['mapCode']]['certifiedLR']=$value['certifiedLR'];
	    		$result_chart[$value['mapCode']]['certifiedOT']=$value['certifiedOT'];
	    		$result_chart[$value['mapCode']]['stateCertifiedLR']=$value['stateCertifiedLR'];
	    		$result_chart[$value['mapCode']]['stateCertifiedOT']=$value['stateCertifiedOT'];
	    		$result_chart[$value['mapCode']]['LrBaseLine']=$value['LrBaseLine'];
	    		$result_chart[$value['mapCode']]['OtbaseLine']=$value['OtbaseLine'];
	    	}

	    }
	    $data['dataMap']=$result_chart;*/
	    // map end

	    //LaQshya Status
	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(stateOr.IsActive), 0) as stateOrFac');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification stateOr','um.UserID=stateOr.userID AND stateOr.certification_type="so" AND stateOr.level=3 AND stateOr.status=3 AND stateOr.IsCurrent=1 AND stateOr.IsActive=1', 'left');	    
	    $query = $this->db->get();
	    $data['box']['stateOr']=$query->row_array();
	    /*$data['box']['stateOr']=array(
	    	'Facilities'=>'2218',
	    	'stateOrFac'=>'2218'
	    );*/

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StateApLR.IsActive), 0) as StateappliedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StateApLR','um.UserID=StateApLR.userID AND StateApLR.certification_type="lr" AND StateApLR.level=2 AND StateApLR.status=1 AND StateApLR.IsActive=1 AND StateApLR.IsCurrent=1', 'left');	    
	    $query = $this->db->get();
	    $data['box']['StateApLR']=$query->row_array();
	    /*$data['box']['StateApLR']=array(
	    	'Facilities'=>'2218',
	    	'StateappliedLR'=>'0'
	    );*/

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StateApOT.IsActive), 0) as StateappliedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StateApOT','um.UserID=StateApOT.userID AND StateApOT.certification_type="ot" AND StateApOT.level=2 AND StateApOT.status=1 AND StateApOT.IsActive=1 AND StateApOT.IsCurrent=1', 'left');	    
	    $query = $this->db->get();
	    $data['box']['StateApOT']=$query->row_array();
	    /*$data['box']['StateApOT']=array(
	    	'Facilities'=>'2218',
	    	'StateappliedOT'=>'0'
	    );*/

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StatecLR.IsActive), 0) as StatecertifiedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StatecLR','um.UserID=StatecLR.userID AND StatecLR.certification_type="lr" AND StatecLR.level=2 AND StatecLR.status=3 AND StatecLR.IsActive=1 AND StatecLR.IsCurrent=1', 'left');	    
	    $query = $this->db->get();
	    $data['box']['StatecLR']=$query->row_array();
	    /*$data['box']['StatecLR']=array(
	    	'Facilities'=>'2218',
	    	'StatecertifiedLR'=>'99'
	    );*/

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StatecOT.IsActive), 0) as StatecertifiedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StatecOT','um.UserID=StatecOT.userID AND StatecOT.certification_type="ot" AND StatecOT.level=2 AND StatecOT.status=3 AND StatecOT.IsActive=1 AND StatecOT.IsCurrent=1', 'left');	    
	    $query = $this->db->get();
	    $data['box']['StatecOT']=$query->row_array();
	    /*$data['box']['StatecOT']=array(
	    	'Facilities'=>'2218',
	    	'StatecertifiedOT'=>'86'
	    );*/

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(ApLR.IsActive), 0) as AppliedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification ApLR','um.UserID=ApLR.userID AND ApLR.certification_type="lr" AND ApLR.level=1 AND ApLR.status=1 AND ApLR.IsActive=1 AND ApLR.IsCurrent=1', 'left');	    
	    $query = $this->db->get();
	    $data['box']['ApLR']=$query->row_array();
	   /* $data['box']['ApLR']=array(
	    	'Facilities'=>'2218',
	    	'AppliedLR'=>'0'
	    );*/

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(ApOT.IsActive), 0) as AppliedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification ApOT','um.UserID=ApOT.userID AND ApOT.certification_type="ot" AND ApOT.level=1 AND ApOT.status=1 AND ApOT.IsActive=1 AND ApOT.IsCurrent=1', 'left');	    
	    $query = $this->db->get();
	    $data['box']['ApOT']=$query->row_array();
	    /*$data['box']['ApOT']=array(
	    	'Facilities'=>'2218',
	    	'AppliedOT'=>'0'
	    );*/	  	

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(cLR.IsActive), 0) as CertifiedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification cLR','um.UserID=cLR.userID AND cLR.certification_type="lr" AND cLR.level=1 AND cLR.status=3 AND cLR.IsActive=1 AND cLR.IsCurrent=1', 'left');	    
	    $query = $this->db->get();
	    $data['box']['cLR']=$query->row_array();
	    /*$data['box']['cLR']=array(
	    	'Facilities'=>'2218',
	    	'CertifiedLR'=>'38'
	    );*/

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(cOT.IsActive), 0) as CertifiedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification cOT','um.UserID=cOT.userID AND cOT.certification_type="ot" AND cOT.level=1 AND cOT.status=3 AND cOT.IsActive=1 AND cOT.IsCurrent=1', 'left');	    
	    $query = $this->db->get();
	    $data['box']['cOT']=$query->row_array();
	    /*$data['box']['cOT']=array(
	    	'Facilities'=>'2218',
	    	'CertifiedOT'=>'26'
	    );*/
	    // box ended

	    $month=date('Y').'-'.date('m').'-01';

	  	$this->db->select('DATE_FORMAT(`m`.`ReportMonth`,"%b %Y") as ReportMonth,IFNULL(sum(m.TotalStillBirths), 0) as TotalStillBirths, IFNULL(sum(m.TotalLiveBirths), 0) as TotalLiveBirths');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1', 'left');
	    //$this->db->where('usertoken.UserID',$tokenData[1]);
	    $where = "m.ReportMonth !=null OR m.ReportMonth !='0000-00-00' ";
	    $this->db->where($where, NULL, FALSE);
	    $this->db->group_by('m.ReportMonth');
	    $query = $this->db->get();
	    foreach ($query->result_array() as $key => $value) {
	    	$data['chart']['LiveVSStill'][]=$value;
	    }

        $this->db->select('s.StateID,s.StateName');
        $this->db->from('states s');
        if(!empty($mappedData)){
            $this->db->where_in('s.StateID',$mappedData);
        }
        $this->db->order_by('s.StateName', 'ASC');
        $query = $this->db->get();
        foreach ($query->result() as $key => $value) {
            $data['state'][$value->StateID]=$value->StateName;
        }

		// top 5 states
		$this->db->select('count(f.StateID) as Facilities, s.StateName');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification c','um.UserID=c.userID AND c.status=3 AND c.IsActive=1 AND c.IsCurrent=1', 'inner');
	    $this->db->group_by('f.StateID');
	    $this->db->order_by('count(f.StateID)','DESC');
	    $this->db->limit('5');
	    $query = $this->db->get();
	    $top=$query->result_array();
	    $data['top']=$top;

 		return $data;

 	}
 	function getDashboardData_static($data){
 		// get map data from static data given by ministry, use when need to show static data in ministry and state map
 		$cond='';
 		if(!empty($data['state'])){
 			$cond=' AND s.mapCode="'.$data['state'].'" ';
 		} else {
 			$cond='';
 		}
 		if(!empty($data['mappedData']) && !empty($data['mappedField'])){
 			$facCond=' AND '.$data['mappedField'].' IN ("'.$data['mappedData'].'") ';
 		} else {
 			$facCond='';
 		}
	  	$sql='SELECT "all" as qryType,s.StateName,s.FacilityNum as FacilitiesNew,
count(f.FacilityID) as Facilities, 
IF(sd.baseline>0,sd.baseline,"NA") as LrBaseLine, 
IF(sd.baseline>0,sd.baseline,"NA") as OtbaseLine,  
IF(sd.national_ap_lr>0,sd.national_ap_lr,"NA") as AppliedLR,
IF(sd.national_ap_ot>0,sd.national_ap_ot,"NA") as AppliedOT,
"NA" as InprocessLR,
"NA" as InprocessOT,
IF(sd.national_lr>0,sd.national_lr,"NA") as CertifiedLR,
IF(sd.national_ot>0,sd.national_ot,"NA") as CertifiedOT,  
"NA" as StateappliedLR,
"NA" as StateappliedOT,
"NA" as StateInprocessLR,
"NA" as StateInprocessOT,
IF(sd.state_lr>0,sd.state_lr,"NA") as StatecertifiedLR,
IF(sd.state_ot>0,sd.state_ot,"NA") as StatecertifiedOT 
FROM `usermapping` `um` 
INNER JOIN `facilities` `f` ON `f`.`FacilityID`=`um`.`FacilityID` AND `um`.`FacilityID`>0 AND `f`.`IsActive`=1 '.$facCond.'  
INNER JOIN `states` `s` ON `f`.`StateID`=`s`.`StateID` AND `f`.`IsActive`=1 '.$cond.' 
INNER JOIN state_static_data sd on(s.StateID=sd.state_id) 
UNION
SELECT "aspirational" as qryType,s.StateName,sd.total_asp as FacilitiesNew,
count(f.FacilityID) as Facilities, 
IF(sd.total_asp_baseline>0,sd.total_asp_baseline,"NA") as LrBaseLine, 
IF(sd.total_asp_baseline>0,sd.total_asp_baseline,"NA") as OtbaseLine,  
IF(sd.asp_national_ap_lr>0,sd.asp_national_ap_lr,"NA") as AppliedLR,
IF(sd.asp_national_ap_ot>0,sd.asp_national_ap_ot,"NA") as AppliedOT,
"NA" as InprocessLR,
"NA" as InprocessOT,
IF(sd.asp_national_cr_lr>0,sd.asp_national_cr_lr,"NA") as CertifiedLR,
IF(sd.asp_national_cr_ot>0,sd.asp_national_cr_ot,"NA") as CertifiedOT,  
"NA" as StateappliedLR,
"NA" as StateappliedOT,
"NA" as StateInprocessLR,
"NA" as StateInprocessOT,
"NA" as StatecertifiedLR,
"NA" as StatecertifiedOT 
FROM `usermapping` `um` 
INNER JOIN `facilities` `f` ON `f`.`FacilityID`=`um`.`FacilityID` AND `um`.`FacilityID`>0 AND `f`.`IsActive`=1 '.$facCond.' 
INNER JOIN `states` `s` ON `f`.`StateID`=`s`.`StateID` AND `f`.`IsActive`=1 '.$cond.'  
INNER JOIN state_static_data sd on(s.StateID=sd.state_id) 
INNER JOIN district d on `f`.`DistrictID`=d.DistrictID AND d.IsHighPriority=1
';
		$result = $this->db->query($sql, NULL);

	    foreach ($result->result_array() as $key => $value) {
	    	$data[$value['qryType']]=$value; 
	    	//$data[$value['qryType']]=array_map(function($val) { return rand(10,10000); }, $value);
	    }
 		return $data;


 	}
 	function getDashboardData($data){
 		// get map data dynamicaly, use when need to show real time data in ministry and state map
 		$cond='';
 		if(!empty($data['state'])){
 			$cond=' AND s.mapCode="'.$data['state'].'" ';
 		} else {
 			$cond='';
 		}
 		if(!empty($data['mappedData']) && !empty($data['mappedField'])){
 			$facCond=' AND '.$data['mappedField'].' IN ("'.$data['mappedData'].'") ';
 		} else {
 			$facCond='';
 		}
	  	$sql='SELECT "all" as qryType,s.StateName,
count(f.FacilityID) as Facilities, 
IFNULL(sum(aLR.SurveyStatus), "NA") as LrBaseLine, 
IFNULL(sum(aOT.SurveyStatus), "NA") as OtbaseLine,  
IFNULL(sum(ApLR.IsActive), "NA") as AppliedLR,
IFNULL(sum(ApOT.IsActive), "NA") as AppliedOT,
IFNULL(sum(cLR.IsActive), "NA") as CertifiedLR,
IFNULL(sum(cOT.IsActive), "NA") as CertifiedOT,  
IFNULL(sum(StateApLR.IsActive), "NA") as StateappliedLR,
IFNULL(sum(StateApOT.IsActive), "NA") as StateappliedOT,
IFNULL(sum(StatecLR.IsActive), "NA") as StatecertifiedLR,
IFNULL(sum(StatecOT.IsActive), "NA") as StatecertifiedOT 
FROM `usermapping` `um` 
INNER JOIN `facilities` `f` ON `f`.`FacilityID`=`um`.`FacilityID` AND `um`.`FacilityID`>0 AND `f`.`IsActive`=1 '.$facCond.'  
INNER JOIN `states` `s` ON `f`.`StateID`=`s`.`StateID` AND `f`.`IsActive`=1 '.$cond.' 
LEFT JOIN `answer` `aLR` ON `um`.`UserID`=`aLR`.`UserID` AND `aLR`.`IsActive`=1 AND `aLR`.`SurveyStatus`=1 AND `aLR`.`Sequence`=11 AND `aLR`.`SurveyID`=1 
LEFT JOIN `answer` `aOT` ON `um`.`UserID`=`aOT`.`UserID` AND `aOT`.`IsActive`=1 AND `aOT`.`SurveyStatus`=1 AND `aOT`.`Sequence`=11 AND `aOT`.`SurveyID`=2 
LEFT JOIN `certification` `ApLR` ON `um`.`UserID`=`ApLR`.`userID` AND `ApLR`.`certification_type`="lr" AND `ApLR`.`level`=1 AND `ApLR`.`status`=1 AND `ApLR`.`IsCurrent`=1 AND `ApLR`.`IsActive`=1 
LEFT JOIN `certification` `ApOT` ON `um`.`UserID`=`ApOT`.`userID` AND `ApOT`.`certification_type`="ot" AND `ApOT`.`level`=1 AND `ApOT`.`status`=1 AND `ApOT`.`IsCurrent`=1 AND `ApOT`.`IsActive`=1 
LEFT JOIN `certification` `cLR` ON `um`.`UserID`=`cLR`.`userID` AND `cLR`.`certification_type`="lr" AND `cLR`.`level`=1 AND `cLR`.`status`=3 AND `cLR`.`IsCurrent`=1 AND `cLR`.`IsActive`=1  
LEFT JOIN `certification` `cOT` ON `um`.`UserID`=`cOT`.`userID` AND `cOT`.`certification_type`="ot" AND `cOT`.`level`=1 AND `cOT`.`status`=3 AND `cOT`.`IsCurrent`=1 AND `cOT`.`IsActive`=1 
LEFT JOIN `certification` `StateApLR` ON `um`.`UserID`=`StateApLR`.`userID` AND `StateApLR`.`certification_type`="lr" AND `StateApLR`.`level`=2 AND `StateApLR`.`status`=1 AND `StateApLR`.`IsCurrent`=1 AND `StateApLR`.`IsActive`=1 
LEFT JOIN `certification` `StateApOT` ON `um`.`UserID`=`StateApOT`.`userID` AND `StateApOT`.`certification_type`="ot" AND `StateApOT`.`level`=2 AND `StateApOT`.`status`=1 AND `StateApOT`.`IsCurrent`=1 AND `StateApOT`.`IsActive`=1 
LEFT JOIN `certification` `StatecLR` ON `um`.`UserID`=`StatecLR`.`userID` AND `StatecLR`.`certification_type`="lr" AND `StatecLR`.`level`=2 AND `StatecLR`.`status`=3 AND `StatecLR`.`IsCurrent`=1 AND `StatecLR`.`IsActive`=1 
LEFT JOIN `certification` `StatecOT` ON `um`.`UserID`=`StatecOT`.`userID` AND `StatecOT`.`certification_type`="ot" AND `StatecOT`.`level`=2 AND `StatecOT`.`status`=3 AND `StatecOT`.`IsCurrent`=1 AND `StatecOT`.`IsActive`=1
UNION
SELECT "aspirational" as qryType,s.StateName,
count(f.FacilityID) as Facilities, 
IFNULL(sum(aLR.SurveyStatus), "NA") as LrBaseLine, 
IFNULL(sum(aOT.SurveyStatus), "NA") as OtbaseLine,  
IFNULL(sum(ApLR.IsActive), "NA") as AppliedLR,
IFNULL(sum(ApOT.IsActive), "NA") as AppliedOT,
IFNULL(sum(cLR.IsActive), "NA") as CertifiedLR,
IFNULL(sum(cOT.IsActive), "NA") as CertifiedOT,  
IFNULL(sum(StateApLR.IsActive), "NA") as StateappliedLR,
IFNULL(sum(StateApOT.IsActive), "NA") as StateappliedOT,
IFNULL(sum(StatecLR.IsActive), "NA") as StatecertifiedLR,
IFNULL(sum(StatecOT.IsActive), "NA") as StatecertifiedOT 
FROM `usermapping` `um` 
INNER JOIN `facilities` `f` ON `f`.`FacilityID`=`um`.`FacilityID` AND `um`.`FacilityID`>0 AND `f`.`IsActive`=1 '.$facCond.' 
INNER JOIN `states` `s` ON `f`.`StateID`=`s`.`StateID` AND `f`.`IsActive`=1 '.$cond.'  
INNER JOIN district d on `f`.`DistrictID`=d.DistrictID AND d.IsHighPriority=1
LEFT JOIN `answer` `aLR` ON `um`.`UserID`=`aLR`.`UserID` AND `aLR`.`IsActive`=1 AND `aLR`.`SurveyStatus`=1 AND `aLR`.`Sequence`=11 AND `aLR`.`SurveyID`=1 
LEFT JOIN `answer` `aOT` ON `um`.`UserID`=`aOT`.`UserID` AND `aOT`.`IsActive`=1 AND `aOT`.`SurveyStatus`=1 AND `aOT`.`Sequence`=11 AND `aOT`.`SurveyID`=2 
LEFT JOIN `certification` `ApLR` ON `um`.`UserID`=`ApLR`.`userID` AND `ApLR`.`certification_type`="lr" AND `ApLR`.`level`=1 AND `ApLR`.`status`=1 AND `ApLR`.`IsCurrent`=1 AND `ApLR`.`IsActive`=1
LEFT JOIN `certification` `ApOT` ON `um`.`UserID`=`ApOT`.`userID` AND `ApOT`.`certification_type`="ot" AND `ApOT`.`level`=1 AND `ApOT`.`status`=1 AND `ApOT`.`IsCurrent`=1 AND `ApOT`.`IsActive`=1 
LEFT JOIN `certification` `cLR` ON `um`.`UserID`=`cLR`.`userID` AND `cLR`.`certification_type`="lr" AND `cLR`.`level`=1 AND `cLR`.`status`=3 AND `cLR`.`IsCurrent`=1 AND `cLR`.`IsActive`=1 
LEFT JOIN `certification` `cOT` ON `um`.`UserID`=`cOT`.`userID` AND `cOT`.`certification_type`="ot" AND `cOT`.`level`=1 AND `cOT`.`status`=3 AND `cOT`.`IsCurrent`=1 AND `cOT`.`IsActive`=1
LEFT JOIN `certification` `StateApLR` ON `um`.`UserID`=`StateApLR`.`userID` AND `StateApLR`.`certification_type`="lr" AND `StateApLR`.`level`=2 AND `StateApLR`.`status`=1 AND `StateApLR`.`IsCurrent`=1 AND `StateApLR`.`IsActive`=1
LEFT JOIN `certification` `StateApOT` ON `um`.`UserID`=`StateApOT`.`userID` AND `StateApOT`.`certification_type`="ot" AND `StateApOT`.`level`=2 AND `StateApOT`.`status`=1 AND `StateApOT`.`IsCurrent`=1 AND `StateApOT`.`IsActive`=1 
LEFT JOIN `certification` `StatecLR` ON `um`.`UserID`=`StatecLR`.`userID` AND `StatecLR`.`certification_type`="lr" AND `StatecLR`.`level`=2 AND `StatecLR`.`status`=3 AND `StatecLR`.`IsCurrent`=1 AND `StatecLR`.`IsActive`=1 
LEFT JOIN `certification` `StatecOT` ON `um`.`UserID`=`StatecOT`.`userID` AND `StatecOT`.`certification_type`="ot" AND `StatecOT`.`level`=2 AND `StatecOT`.`status`=3 AND `StatecOT`.`IsCurrent`=1 AND `StatecOT`.`IsActive`=1
';
		$result = $this->db->query($sql, NULL);

	    foreach ($result->result_array() as $key => $value) {
	    	$data[$value['qryType']]=$value;
	    }
 		return $data;


 	}

 	function getMinistryDashboardData($data,$search){
        $level=array('1'=>'national','2'=>'state','3'=>'so');
        $stage=array('1'=>'applied','2'=>'inprocess','3'=>'received','4'=>'rejected');
        $types=array('lr','ot','so');
		if ($search['RoleName'] == 'District') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.DistrictID';
        } else if ($search['RoleName'] == 'State') {
            $mappedData = explode(",", $search['mapped']);
            $mappedField='f.StateID';
        } else {
            $mappedData = explode(",", $search['mapped']);
        	$mappedField='f.StateID';
        }        

        if($data['aspirational']=='yes'){
        	$condAspir=' AND d.IsHighPriority="1" ';
        } else {
        	$condAspir='';
        }
        $col = array(
            0 => 's.StateName',
            1 => 'd.DistrictName',
            2 => 'f.FacilityName',
            3 => 't.TypeDetailCode',
            3 => 'f.FacilityNumber',
        );
        $condCertification='';
        if(isset($data['types'])){
        	if(in_array(strtolower($data['types']), $types)){
        		$condCertification.=' AND certification.certification_type="'.strtolower($data['types']).'"';        		
        	}
        }
        if(isset($data['level'])){
        	if(in_array(strtolower($data['level']), $level)){
        		$condCertification.=' AND certification.level="'.array_search(strtolower($data['level']), $level).'"';
        	}
        }
        if(isset($data['stage'])){
        	if(in_array(strtolower($data['stage']), $stage)){
        		$condCertification.=' AND certification.status="'.array_search(strtolower($data['stage']), $stage).'"';
        	}
        }

	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1 '.$condAspir, 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    if(!empty($data['types'])){
	    	$this->db->join('certification', 'um.UserID=certification.userID AND certification.IsCurrent=1 AND certification.IsActive=1 '.$condCertification, 'inner');
	    }
	    $this->db->where('f.Islaqshya','1');
	    
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $queryTot = $this->db->get();

	    // data query
	  	$this->db->select('f.FacilityName,f.FacilityNumber,d.DistrictName,s.StateName,t.TypeDetailCode,certification.certification_type,certification.level,certification.status');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s', 'f.StateID=s.StateID AND s.IsActive=1', 'inner');
	    $this->db->join('district d', 'f.DistrictID=d.DistrictID AND d.IsActive=1'.$condAspir, 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID', 'left');
	    if(!empty($data['types'])){
	    	$this->db->join('certification', 'um.UserID=certification.userID AND certification.IsCurrent=1 AND certification.IsActive=1 '.$condCertification, 'inner');
	    }
	    $this->db->where('f.Islaqshya','1');
	    
	    if(!empty($search['mapped'])){
	    	$this->db->where_in($mappedField,$mappedData);	    	
	    }
        if(!empty($data['search']['value'])){
            $searchString=trim($data['search']['value']);
            $this->db->where("(s.StateName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR f.FacilityName like '%".$searchString."%' OR t.TypeDetailCode like '%".$searchString."%' OR f.FacilityNumber like '%".$searchString."%')", NULL, FALSE);
        }
	    if(!empty($data['search_state'])){
	    	$this->db->where('s.StateID',$data['search_state']);	    	
	    }
	    if(!empty($data['search_district'])){
	    	$this->db->where('d.DistrictID',$data['search_district']);	    	
	    }
	    $this->db->order_by($col[$data['order'][0]['column']], $data['order'][0]['dir']);
	    $this->db->limit($data['length'],$data['start']);
	    $query = $this->db->get();
		$data1=array();
		foreach ($query->result() as $key => $value) {
		    $subdata=array();
			switch ($value->certification_type) {
				case 'lr':
					$certification_type='Labour Room';
					break;
				case 'ot':
					$certification_type='Operation Theater';
					break;
				case 'both':
					$certification_type='Labour Room & Operation Theater';
					break;	
				default:
					$certification_type='Labour Room';
					break;
			}
		    $subdata[]=$value->StateName;
		    $subdata[]=$value->DistrictName;
		    $subdata[]=$value->FacilityName;
		    $subdata[]=$value->FacilityNumber;
		    $subdata[]=$value->TypeDetailCode;
            $subdata[] = $certification_type;
            $subdata[] = $this->config->item('certificationLevel')[$value->level];
            $subdata[] = $this->config->item('certificationStatus')[$value->status];
		    $data1[]=$subdata;
		}
		$json_data=array(
		    "draw"              =>  intval($data['draw']),
		    "recordsTotal"      =>  intval($queryTot->num_rows()),
		    "recordsFiltered"   =>  intval($queryTot->num_rows()),
		    "data"              =>  $data1
		);
 		return $json_data;

 	}
 	function state_dashboard_new($search){
 		$mappedData = explode(",", $search['mapped']);
 		// box start
 		// static data start
	  	$this->db->select('state_static_data.*');
	    $this->db->from('state_static_data');
	    if(!empty($mappedData)){
	    	$this->db->where_in('state_static_data.state_id',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['state_static_data']=$query->row_array();
	    // static data end

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalLaQshya']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','441');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalCHC']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','451');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalFRU']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','442');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalDisFacility']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','485');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalMedFacility']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','455');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalSubDivFacility']=$query->num_rows();

		$idsType=array('441','442','485','451','455');
		$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where_not_in('t.TypeDetailID', $idsType);
	    $this->db->where('t.TypeMasterID','4');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalOtherFacility']=$query->num_rows();

	    // box end

	    // map start
	  	$this->db->select('s.StateName as catName,count(f.FacilityID) as facilities,s.mapCode,
				IFNULL(sum(aLR.SurveyStatus),"NA") as LrBaseLine, 
				IFNULL(sum(aOT.SurveyStatus),"NA") as OtbaseLine,
				IFNULL(sum(cLR.IsActive),"NA") as certifiedLR,
				IFNULL(sum(cOT.IsActive),"NA") as certifiedOT,
				IFNULL(sum(cSLR.IsActive),"NA") as stateCertifiedLR,
				IFNULL(sum(cSOT.IsActive),"NA") as stateCertifiedOT
	  		');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('answer aLR','um.UserID=aLR.UserID AND aLR.IsActive=1 AND aLR.SurveyStatus=1 AND aLR.Sequence=11 AND aLR.SurveyID=1', 'left');
	    $this->db->join('answer aOT','um.UserID=aOT.UserID AND aOT.IsActive=1 AND aOT.SurveyStatus=1 AND aOT.Sequence=11 AND aOT.SurveyID=2', 'left');
	    $this->db->join('certification cLR','um.UserID=cLR.userID AND cLR.certification_type="lr" AND cLR.level=1 AND cLR.status=3 AND cLR.IsCurrent=1 AND cLR.IsActive=1', 'left');
	    $this->db->join('certification cOT','um.UserID=cOT.userID AND cOT.certification_type="ot" AND cOT.level=1 AND cOT.status=3 AND cOT.IsCurrent=1 AND cOT.IsActive=1', 'left');
	    $this->db->join('certification cSLR','um.UserID=cSLR.userID AND cSLR.certification_type="lr" AND cSLR.level=1 AND cSLR.status=3 AND cSLR.IsCurrent=1 AND cSLR.IsActive=1', 'left');
	    $this->db->join('certification cSOT','um.UserID=cSOT.userID AND cSOT.certification_type="ot" AND cSOT.level=1 AND cSOT.status=3 AND cSOT.IsCurrent=1 AND cSOT.IsActive=1', 'left');

	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }	    
	    $this->db->group_by('f.StateID');
	    $query = $this->db->get();

	    $keys=array('injs1','injs2','injs3','injs4','injs5','injs6','injs7','injs8','injs9','injs10','injs11','injs12','injs13','injs14','injs15','injs16','injs17','injs18','injs19','injs20','injs21','injs22','injs23','injs24','injs25','injs26','injs27','injs28','injs29','injs30','injs31','injs32','injs33','injs34','injs35','injs36');
	    $result_chart=array_fill_keys($keys, array());
	    foreach ($query->result_array() as $key => $value) {
	    	if(empty($result_chart[$value['mapCode']])){
	    		$result_chart[$value['mapCode']]=$value;
	    	} else {
	    		$result_chart[$value['mapCode']]['facilities']=$value['facilities'];
	    		$result_chart[$value['mapCode']]['certifiedLR']=$value['certifiedLR'];
	    		$result_chart[$value['mapCode']]['certifiedOT']=$value['certifiedOT'];
	    		$result_chart[$value['mapCode']]['LrBaseLine']=$value['LrBaseLine'];
	    		$result_chart[$value['mapCode']]['OtbaseLine']=$value['OtbaseLine'];
	    		$result_chart[$value['mapCode']]['stateCertifiedLR']=$value['stateCertifiedLR'];
	    		$result_chart[$value['mapCode']]['stateCertifiedOT']=$value['stateCertifiedOT'];
	    	}

	    }
	    $data['dataMap']=$result_chart;

	    /*$qryMap='SELECT s.`StateName` as catName,s.FacilityNum as facilitiesNew,s.FacilityNum as facilities,s.mapCode,sd.baseline as LrBaseLine,sd.baseline as OtbaseLine,sd.national_lr as certifiedLR,sd.national_ot as certifiedOT 
FROM `states` s
INNER JOIN state_static_data sd on(s.StateID=sd.state_id)
WHERE s.CountryID=1 AND s.IsActive=1 AND s.StateID in('.implode(',', $mappedData).') ORDER BY `StateID` ASC';
	    $query = $this->db->query($qryMap);
	    $keys=array('injs1','injs2','injs3','injs4','injs5','injs6','injs7','injs8','injs9','injs10','injs11','injs12','injs13','injs14','injs15','injs16','injs17','injs18','injs19','injs20','injs21','injs22','injs23','injs24','injs25','injs26','injs27','injs28','injs29','injs30','injs31','injs32','injs33','injs34','injs35','injs36');
	    $result_chart=array_fill_keys($keys, array());
	    foreach ($query->result_array() as $key => $value) {
	    	if(empty($result_chart[$value['mapCode']])){
	    		$result_chart[$value['mapCode']]=$value;
	    	} else {
	    		$result_chart[$value['mapCode']]['facilities']+=$value['facilities'];
	    		$result_chart[$value['mapCode']]['certifiedLR']+=$value['certifiedLR'];
	    		$result_chart[$value['mapCode']]['certifiedOT']+=$value['certifiedOT'];
	    		$result_chart[$value['mapCode']]['LrBaseLine']+=$value['LrBaseLine'];
	    		$result_chart[$value['mapCode']]['OtbaseLine']+=$value['OtbaseLine'];
	    	}

	    }
	    $data['dataMap']=$result_chart;*/
	    // map end

	    //LaQshya Status
	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(stateOr.IsActive), 0) as stateOrFac');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification stateOr','um.UserID=stateOr.userID AND stateOr.certification_type="so" AND stateOr.level=3 AND stateOr.status=3 AND stateOr.IsCurrent=1 AND stateOr.IsActive=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['stateOr']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StateApLR.IsActive), 0) as StateappliedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StateApLR','um.UserID=StateApLR.userID AND StateApLR.certification_type="lr" AND StateApLR.level=2 AND StateApLR.status=1 AND StateApLR.IsActive=1 AND StateApLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StateApLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StateApOT.IsActive), 0) as StateappliedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StateApOT','um.UserID=StateApOT.userID AND StateApOT.certification_type="ot" AND StateApOT.level=2 AND StateApOT.status=1 AND StateApOT.IsActive=1 AND StateApOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StateApOT']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StateIpLR.IsActive), 0) as StateInprocessLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StateIpLR','um.UserID=StateIpLR.userID AND StateIpLR.certification_type="lr" AND StateIpLR.level=2 AND StateIpLR.status=2 AND StateIpLR.IsActive=1 AND StateIpLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StateIpLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StateIpOT.IsActive), 0) as StateInprocessOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StateIpOT','um.UserID=StateIpOT.userID AND StateIpOT.certification_type="ot" AND StateIpOT.level=2 AND StateIpOT.status=2 AND StateIpOT.IsActive=1 AND StateIpOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StateIpOT']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StatecLR.IsActive), 0) as StatecertifiedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StatecLR','um.UserID=StatecLR.userID AND StatecLR.certification_type="lr" AND StatecLR.level=2 AND StatecLR.status=3 AND StatecLR.IsActive=1 AND StatecLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StatecLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StatecOT.IsActive), 0) as StatecertifiedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StatecOT','um.UserID=StatecOT.userID AND StatecOT.certification_type="ot" AND StatecOT.level=2 AND StatecOT.status=3 AND StatecOT.IsActive=1 AND StatecOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StatecOT']=$query->row_array();	  	

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(ApLR.IsActive), 0) as AppliedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification ApLR','um.UserID=ApLR.userID AND ApLR.certification_type="lr" AND ApLR.level=1 AND ApLR.status=1 AND ApLR.IsActive=1 AND ApLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['ApLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(ApOT.IsActive), 0) as AppliedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification ApOT','um.UserID=ApOT.userID AND ApOT.certification_type="ot" AND ApOT.level=1 AND ApOT.status=1 AND ApOT.IsActive=1 AND ApOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['ApOT']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(IpLR.IsActive), 0) as InprocessLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification IpLR','um.UserID=IpLR.userID AND IpLR.certification_type="lr" AND IpLR.level=1 AND IpLR.status=2 AND IpLR.IsActive=1 AND IpLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['IpLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(IpOT.IsActive), 0) as InprocessOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification IpOT','um.UserID=IpOT.userID AND IpOT.certification_type="ot" AND IpOT.level=1 AND IpOT.status=2 AND IpOT.IsActive=1 AND IpOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['IpOT']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(cLR.IsActive), 0) as CertifiedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification cLR','um.UserID=cLR.userID AND cLR.certification_type="lr" AND cLR.level=1 AND cLR.status=3 AND cLR.IsActive=1 AND cLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['cLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(cOT.IsActive), 0) as CertifiedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification cOT','um.UserID=cOT.userID AND cOT.certification_type="ot" AND cOT.level=1 AND cOT.status=3 AND cOT.IsActive=1 AND cOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['cOT']=$query->row_array();
	    // box ended

	    $month=date('Y').'-'.date('m').'-01';

	  	$this->db->select('DATE_FORMAT(`m`.`ReportMonth`,"%b %Y") as ReportMonth,IFNULL(sum(m.TotalStillBirths), 0) as TotalStillBirths, IFNULL(sum(m.TotalLiveBirths), 0) as TotalLiveBirths');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1', 'left');
	    //$this->db->where('usertoken.UserID',$tokenData[1]);
	    
	    $where = "m.ReportMonth !=null OR m.ReportMonth !='0000-00-00' ";
	    $this->db->where($where, NULL, FALSE);
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.StateID',$mappedData);
	    }
	    $this->db->group_by('m.ReportMonth');
	    $query = $this->db->get();
	    foreach ($query->result_array() as $key => $value) {
	    	$data['chart']['LiveVSStill'][]=$value;
	    }

	  	$this->db->select('d.districtId,d.DistrictName');
	    $this->db->from('states s');
	    $this->db->join('district d','s.StateID=d.StateID AND d.IsActive=1', 'inner');
	    if(!empty($mappedData)){
	    	$this->db->where_in('s.StateID',$mappedData);
	    }
	    $this->db->order_by('d.DistrictName', 'ASC');
	    $query = $this->db->get();
	    foreach ($query->result() as $key => $value) {
	    	$data['districts'][$value->districtId]=$value->DistrictName;
	    }

		// top 5 District
		$this->db->select('count(d.DistrictID) as Facilities, d.DistrictName');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('district d','f.DistrictID=d.DistrictID AND d.IsActive=1', 'inner');
	    $this->db->join('certification c','um.UserID=c.userID AND c.status=3 AND c.IsActive=1 AND c.IsCurrent=1', 'inner');
	    if(!empty($mappedData)){
	    	$this->db->where_in('s.StateID',$mappedData);
	    }
	    $this->db->group_by('d.DistrictID');
	    $this->db->order_by('count(d.DistrictID)','DESC');
	    $this->db->limit('5');
	    $query = $this->db->get();
	    $top=$query->result_array();
	    $data['top']=$top;

 		return $data;

 	}

 	function district_dashboard_new($search){
 		$mappedData = explode(",", $search['mapped']);
 		// box start
	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalLaQshya']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','107');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalCHC']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','105');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalFRU']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','64');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalDisFacility']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','103');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalMedFacility']=$query->num_rows();

	  	$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where('t.TypeDetailID','440');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalSubDivFacility']=$query->num_rows();

		$idsType=array('107','105','64','103','440');
		$this->db->select('um.UsermappingID');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
	    $this->db->where('f.IsActive','1');
	    $this->db->where_not_in('t.TypeDetailID', $idsType);
	    $this->db->where('t.TypeMasterID','4');
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['totalOtherFacility']=$query->num_rows();

	    // box end

	    

	    //LaQshya Status
	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(stateOr.IsActive), 0) as stateOrFac');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification stateOr','um.UserID=stateOr.userID AND stateOr.certification_type="so" AND stateOr.level=3 AND stateOr.status=3 AND stateOr.IsCurrent=1 AND stateOr.IsActive=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['stateOr']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StateApLR.IsActive), 0) as StateappliedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StateApLR','um.UserID=StateApLR.userID AND StateApLR.certification_type="lr" AND StateApLR.level=2 AND StateApLR.status=1 AND StateApLR.IsActive=1 AND StateApLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StateApLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StateApOT.IsActive), 0) as StateappliedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StateApOT','um.UserID=StateApOT.userID AND StateApOT.certification_type="ot" AND StateApOT.level=2 AND StateApOT.status=1 AND StateApOT.IsActive=1 AND StateApOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StateApOT']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StateIpLR.IsActive), 0) as StateInprocessLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StateIpLR','um.UserID=StateIpLR.userID AND StateIpLR.certification_type="lr" AND StateIpLR.level=2 AND StateIpLR.status=2 AND StateIpLR.IsActive=1 AND StateIpLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StateIpLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StateIpOT.IsActive), 0) as StateInprocessOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StateIpOT','um.UserID=StateIpOT.userID AND StateIpOT.certification_type="ot" AND StateIpOT.level=2 AND StateIpOT.status=2 AND StateIpOT.IsActive=1 AND StateIpOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StateIpOT']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StatecLR.IsActive), 0) as StatecertifiedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StatecLR','um.UserID=StatecLR.userID AND StatecLR.certification_type="lr" AND StatecLR.level=2 AND StatecLR.status=3 AND StatecLR.IsActive=1 AND StatecLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StatecLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(StatecOT.IsActive), 0) as StatecertifiedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification StatecOT','um.UserID=StatecOT.userID AND StatecOT.certification_type="ot" AND StatecOT.level=2 AND StatecOT.status=3 AND StatecOT.IsActive=1 AND StatecOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['StatecOT']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(ApLR.IsActive), 0) as AppliedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification ApLR','um.UserID=ApLR.userID AND ApLR.certification_type="lr" AND ApLR.level=1 AND ApLR.status=1 AND ApLR.IsActive=1 AND ApLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['ApLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(ApOT.IsActive), 0) as AppliedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification ApOT','um.UserID=ApOT.userID AND ApOT.certification_type="ot" AND ApOT.level=1 AND ApOT.status=1 AND ApOT.IsActive=1 AND ApOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['ApOT']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(IpLR.IsActive), 0) as InprocessLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification IpLR','um.UserID=IpLR.userID AND IpLR.certification_type="lr" AND IpLR.level=1 AND IpLR.status=2 AND IpLR.IsActive=1 AND IpLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['IpLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(IpOT.IsActive), 0) as InprocessOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification IpOT','um.UserID=IpOT.userID AND IpOT.certification_type="ot" AND IpOT.level=1 AND IpOT.status=2 AND IpOT.IsActive=1 AND IpOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['IpOT']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(cLR.IsActive), 0) as CertifiedLR');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification cLR','um.UserID=cLR.userID AND cLR.certification_type="lr" AND cLR.level=1 AND cLR.status=3 AND cLR.IsActive=1 AND cLR.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['cLR']=$query->row_array();

	  	$this->db->select('count(f.FacilityID) as Facilities,IFNULL(sum(cOT.IsActive), 0) as CertifiedOT');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('certification cOT','um.UserID=cOT.userID AND cOT.certification_type="ot" AND cOT.level=1 AND cOT.status=3 AND cOT.IsActive=1 AND cOT.IsCurrent=1', 'left');	    
	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $query = $this->db->get();
	    $data['box']['cOT']=$query->row_array();
	    // box ended

	    $month=date('Y').'-'.date('m').'-01';

	  	$this->db->select('DATE_FORMAT(`m`.`ReportMonth`,"%b %Y") as ReportMonth,IFNULL(sum(m.TotalStillBirths), 0) as TotalStillBirths, IFNULL(sum(m.TotalLiveBirths), 0) as TotalLiveBirths');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1', 'left');
	    //$this->db->where('usertoken.UserID',$tokenData[1]);
	    $where = "m.ReportMonth !=null OR m.ReportMonth !='0000-00-00' ";
	    $this->db->where($where, NULL, FALSE);

	    if(!empty($mappedData)){
	    	$this->db->where_in('f.DistrictID',$mappedData);
	    }
	    $this->db->group_by('m.ReportMonth');
	    $query = $this->db->get();
	    foreach ($query->result_array() as $key => $value) {
	    	$data['chart']['LiveVSStill'][]=$value;
	    }

        $this->db->select('um.UserID,f.FacilityName');
        $this->db->from('usermapping um');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('typedetail t', 'f.FacilityTypeDetailID=t.TypeDetailID AND t.IsActive=1', 'inner');
        $this->db->where('f.Islaqshya','1');
        if(!empty($mappedData)){
            $this->db->where_in('f.DistrictID',$mappedData);
        }
        $query = $this->db->get();
        $data['facilities']=$query->result_array();

		// top 5 facility
        

 		return $data;

 	}
 	function piechart_MatDeath($data){
	  	$this->db->select('IFNULL(sum(m.MaternalAPH), 0) as MaternalAPH,
IFNULL(sum(m.MaternalPPH), 0) as MaternalPPH,
IFNULL(sum(m.MaternalSepsis), 0) as MaternalSepsis,
IFNULL(sum(m.MaternalObstructedLabour), 0) as MaternalObstructedLabour,
IFNULL(sum(m.MaternalPIHEclampsia), 0) as MaternalPIHEclampsia,
IFNULL(sum(m.MaternalOthers), 0) as MaternalOthers,
IFNULL(sum(m.MaternalPPH)+sum(m.MaternalSepsis)+sum(m.MaternalObstructedLabour)+sum(m.MaternalPIHEclampsia)+sum(m.MaternalOthers), 0) as TotalMaternalDeaths');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1 AND m.ReportMonth="'.$data['searchDate'].'"', 'left');	    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $query = $this->db->get();
	    $result=$query->row_array();
	    if(empty($result['TotalMaternalDeaths'])){
		    return array(
	            array('Category','Value'),
	            array('No Data',1)
	        );
	    } else {
		    return array(
	            array('Category','Value'),
	            array('APH',(int)$result['MaternalAPH']),
	            array('PPH',(int)$result['MaternalPPH']),
	            array('Sepsis',(int)$result['MaternalSepsis']),
	            array('Obstructed labour',(int)$result['MaternalObstructedLabour']),
	            array('Eclampsia',(int)$result['MaternalPIHEclampsia']),
	            array('Others',(int)$result['MaternalOthers'])
	        );	    	
	    }


 	}
 	function piechart_NeonDeath($data){
	  	$this->db->select('IFNULL(sum(m.NeonatalPrematurity), 0) as NeonatalPrematurity,
IFNULL(sum(m.NeonatalSepsis), 0) as NeonatalSepsis,
IFNULL(sum(m.NeonatalAsphyxia), 0) as NeonatalAsphyxia,
IFNULL(sum(m.NeonatalOthers), 0) as NeonatalOthers,IFNULL(sum(m.NeonatalPrematurity)+sum(m.NeonatalSepsis)+sum(m.NeonatalAsphyxia)+sum(m.NeonatalOthers), 0) as total');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1 AND m.ReportMonth="'.$data['searchDate'].'"', 'left');	    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $query = $this->db->get();
	    $result=$query->row_array();
	    if(empty($result['total'])){
		    return array(
	            array('Category','Value'),
	            array('No Data',1)
	        );
	    } else {
		    return array(
	            array('Category','Value'),
	            array('Prematurity',(int)$result['NeonatalPrematurity']),
	            array('Sepsis',(int)$result['NeonatalSepsis']),
	            array('Asphyxia',(int)$result['NeonatalAsphyxia']),
	            array('Others',(int)$result['NeonatalOthers'])
	        );	    	
	    }

 	}
 	function piechart_StillBirth($data){
	  	$this->db->select('IFNULL(sum(m.TotalFreshStillBirths), 0) as TotalFreshStillBirths,
IFNULL(sum(m.TotalMaceratedStillBirths), 0) as TotalMaceratedStillBirths,
IFNULL(sum(m.TotalMaceratedStillBirths)+sum(m.TotalFreshStillBirths), 0) as total');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1 AND m.ReportMonth="'.$data['searchDate'].'"', 'left');	    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $query = $this->db->get();
	    $result=$query->row_array();
	    if(empty($result['total'])){
		    return array(
	            array('Category','Value'),
	            array('No Data',1)
	        );
	    } else {
		    return array(
	            array('Category','Value'),
	            array('Still Births',(int)$result['TotalFreshStillBirths']),
	            array('Macerated Still Births',(int)$result['TotalMaceratedStillBirths'])
	        );
		}
 	}
 	function piechart_Deliveries($data){
	  	$this->db->select('IFNULL(sum(m.TotalNormalVaginalDeliveries), 0) as TotalNormalVaginalDeliveries,
IFNULL(sum(m.TotalAssistedVaginalDeliveries), 0) as TotalAssistedVaginalDeliveries,
IFNULL(sum(m.TotalCSections), 0) as TotalCSections,
IFNULL(sum(m.TotalCSections)+sum(m.TotalNormalVaginalDeliveries)+sum(m.TotalAssistedVaginalDeliveries), 0) as total');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1 AND m.ReportMonth="'.$data['searchDate'].'"', 'left');	    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $query = $this->db->get();
	    $result=$query->row_array();
	    if(empty($result['total'])){
		    return array(
	            array('Category','Value'),
	            array('No Data',1)
	        );
	    } else {
		    return array(
	            array('Category','Value'),
	            array('Normal Vaginal Deliveries',(int)$result['TotalNormalVaginalDeliveries']),
	            array('Assisted Vaginal Deliveries',(int)$result['TotalAssistedVaginalDeliveries']),
	            array('C-Sections',(int)$result['TotalCSections'])
	        );
		}
 	}
 	function chart_aph($data){
	  	$this->db->select('DATE_FORMAT(m.ReportMonth,"%b %Y") as ReportMonth,IFNULL(m.MaternalAPH,0) as MaternalAPH,IFNULL(m.MaternalPPH,0) as MaternalPPH');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1', 'left');    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $this->db->order_by('m.ReportMonth', 'desc');
	    $this->db->limit('6');
	    $query = $this->db->get();
	    $returnData=array(array('Category','APH','PPH'));
	    if($query -> num_rows()>0){
	    	foreach ($query->result_array() as $key => $value) {
	    		$returnData[]=array($value['ReportMonth'],(int)$value['MaternalAPH'],(int)$value['MaternalPPH']);
	    	}
	    }
	    return $returnData;
 	}
 	function chart_pih($data){
	  	$this->db->select('DATE_FORMAT(m.ReportMonth,"%b %Y") as ReportMonth,IFNULL(m.MaternalPIHEclampsia,0) as MaternalPIHEclampsia');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1', 'left');    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $this->db->order_by('m.ReportMonth', 'desc');
	    $this->db->limit('6');
	    $query = $this->db->get();
	    $returnData=array(array('Category','Eclampsia'));
	    if($query -> num_rows()>0){
	    	foreach ($query->result_array() as $key => $value) {
	    		$returnData[]=array($value['ReportMonth'],(int)$value['MaternalPIHEclampsia']);
	    	}
	    }
	    return $returnData;
 	}
 	function chart_sepsis($data){
	  	$this->db->select('DATE_FORMAT(m.ReportMonth,"%b %Y") as ReportMonth,IFNULL(m.NeonatalSepsis,0) as NeonatalSepsis');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1', 'left');    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $this->db->order_by('m.ReportMonth', 'desc');
	    $this->db->limit('6');
	    $query = $this->db->get();
	    $returnData=array(array('Category','Sepsis'));
	    if($query -> num_rows()>0){
	    	foreach ($query->result_array() as $key => $value) {
	    		$returnData[]=array($value['ReportMonth'],(int)$value['NeonatalSepsis']);
	    	}
	    }
	    return $returnData;
 	}
 	function chart_asphyxia($data){
	  	$this->db->select('DATE_FORMAT(m.ReportMonth,"%b %Y") as ReportMonth,IFNULL(m.NeonatalAsphyxia,0) as NeonatalAsphyxia');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1', 'left');    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $this->db->order_by('m.ReportMonth', 'desc');
	    $this->db->limit('6');
	    $query = $this->db->get();
	    $returnData=array(array('Category','Asphyxia'));
	    if($query -> num_rows()>0){
	    	foreach ($query->result_array() as $key => $value) {
	    		$returnData[]=array($value['ReportMonth'],(int)$value['NeonatalAsphyxia']);
	    	}
	    }
	    return $returnData;
 	}
 	function chart_partograph($data){
	  	$this->db->select('DATE_FORMAT(m.ReportMonth,"%b %Y") as ReportMonth,IFNULL(m.RealTimePartograph,0) as RealTimePartograph');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1', 'left');    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $this->db->order_by('m.ReportMonth', 'desc');
	    $this->db->limit('6');
	    $query = $this->db->get();
	    $returnData=array(array('Category','Partograph'));
	    if($query -> num_rows()>0){
	    	foreach ($query->result_array() as $key => $value) {
	    		$returnData[]=array($value['ReportMonth'],(int)$value['RealTimePartograph']);
	    	}
	    }
	    return $returnData;
 	}
 	function chart_birth($data){
	  	$this->db->select('DATE_FORMAT(m.ReportMonth,"%b %Y") as ReportMonth,IFNULL(m.BirthCompanionNos,0) as BirthCompanionNos');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1', 'left');    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $this->db->order_by('m.ReportMonth', 'desc');
	    $this->db->limit('6');
	    $query = $this->db->get();
	    $returnData=array(array('Category','Companions'));
	    if($query -> num_rows()>0){
	    	foreach ($query->result_array() as $key => $value) {
	    		$returnData[]=array($value['ReportMonth'],(int)$value['BirthCompanionNos']);
	    	}
	    }
	    return $returnData;
 	}
 	function chart_safebirth($data){
	  	$this->db->select('DATE_FORMAT(m.ReportMonth,"%b %Y") as ReportMonth,IFNULL(m.SafeBirthChecklist,0) as SafeBirthChecklist');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1', 'left');    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $this->db->order_by('m.ReportMonth', 'desc');
	    $this->db->limit('6');
	    $query = $this->db->get();
	    $returnData=array(array('Category','Safe Birth LR'));
	    if($query -> num_rows()>0){
	    	foreach ($query->result_array() as $key => $value) {
	    		$returnData[]=array($value['ReportMonth'],(int)$value['SafeBirthChecklist']);
	    	}
	    }
	    return $returnData;
 	}
 	function chart_safebirthot($data){
	  	$this->db->select('DATE_FORMAT(m.ReportMonth,"%b %Y") as ReportMonth,IFNULL(m.CSectionOTSafeChecklist,0) as CSectionOTSafeChecklist');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('monthly m','`um`.`UserID`=`m`.`UserID` AND `m`.`MonthlyStatus`=1', 'left');    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $this->db->order_by('m.ReportMonth', 'desc');
	    $this->db->limit('6');
	    $query = $this->db->get();
	    $returnData=array(array('Category','Safe Birth LR'));
	    if($query -> num_rows()>0){
	    	foreach ($query->result_array() as $key => $value) {
	    		$returnData[]=array($value['ReportMonth'],(int)$value['CSectionOTSafeChecklist']);
	    	}
	    }
	    return $returnData;
 	}
 	function chart_anexture($data){
	  	$this->db->select('DATE_FORMAT(ax.submitDate, "%b %Y") as ReportMonth,count(*) as cnt');
	    $this->db->from('usermapping um');
	    //$this->db->join('facilities f.', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->join('anexture ax','um.UserID=ax.UserID AND ax.isDraft=0', 'inner');    
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    $this->db->group_by('DATE_FORMAT(ax.submitDate, "%Y-%m-%d")');
	    $this->db->order_by('ax.submitDate', 'desc');
	    $this->db->limit('6');
	    $query = $this->db->get();

	    $returnData=array(array('Category','Anexure'));
	    if($query -> num_rows()>0){
	    	foreach ($query->result_array() as $key => $value) {
	    		$returnData[]=array($value['ReportMonth'],(int)$value['cnt']);
	    	}
	    }
	    return $returnData;
 	}
    function monthly_indicator($data) {
        $response = array();
        $val_a_text=$val_b_text=$val_c_text=$val_d_text=$val_e_text=$val_f_text=$val_g_text=$val_h_text=$val_i_text=$val_j_text=$val_k_text=$val_l_text=$val_m_text=$val_n_text=$val_o_text=$val_p_text=$val_q_text=$val_r_text=$val_s_text=$val_t_text=$val_u_text=$val_v_text=$val_w_text=$val_x_text=$val_y_text=$val_z_text=$val_za_text=0;

	  	$this->db->select('f.FacilityName');
	    $this->db->from('usermapping um');
	    $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
	    $this->db->where('f.Islaqshya','1');
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    if(isset($data['search'])){
	    	foreach ($data['search'] as $key => $value) {
	    		$this->db->where($value['field'], $value['value']);
	    	}
	    }
	    $queryTot = $this->db->get();
	    $totalFacility=$queryTot->num_rows();

        $this->db->select('s.StateName,d.DistrictName,f.FacilityName,f.FacilityNumber,f.stateID,f.districtId,um.UserID,m.*,ot.BaselineNQASChecklistLR,ot.BaselineNQASChecklistOT,ot.QualityTeamFacility,ot.QualityCircleLR,ot.QualityCircleOT,ot.OrientationAttended,ot.BaselineScoreOT,ot.BaselineScoreLR');
        $this->db->from('monthly as m');
        $this->db->join('onetime as ot', 'ot.UserID= m.UserID', 'inner');
        $this->db->join('usermapping as um', 'um.UserID= m.UserID', 'inner');
        $this->db->join('facilities as f', 'f.FacilityID= um.FacilityID', 'inner');
        $this->db->join('states as s', 's.StateID=f.StateID', 'inner');
        $this->db->join('district as d', 'd.DistrictID=f.DistrictID', 'inner');
/*        if ($this->session->userdata('RoleName') == 'District') {
            $MappedDistrict = $this->session->userdata('MappedDistrict');
            if ($MappedDistrict != '') {
                $MappedDistrictArray = explode(",", $MappedDistrict);
                $this->db->where_in('f.DistrictID', $MappedDistrictArray);
            }
        }*/
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    if(isset($data['search'])){
	    	foreach ($data['search'] as $key => $value) {
	    		$this->db->where($value['field'], $value['value']);
	    	}
	    }
        $this->db->where('m.ReportMonth', $data['searchDate']);
        $this->db->order_by('m.ReportMonth', 'DESC');
        $query = $this->db->get();

        //$dataget = array();
        foreach ($query->result() as $key => $value) {
            $val_a=($value->BaselineNQASChecklistLR==1 && $value->BaselineNQASChecklistOT==1)?'YES':'No' ;            
            $val_b=($value->QualityTeamFacility==1 || $value->QualityCircleLR==1 || $value->QualityCircleOT==1)?'YES':'NO';
            $val_c=($value->OrientationAttended==1)?'YES':'NO';
            $val_d=($value->BirthCompanionNos==0)?0:formatValue(($value->BirthCompanionNos * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c38*100/c11+c12
            $val_e=($value->SafeBirthChecklist==0)?0:formatValue(($value->SafeBirthChecklist * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c39*100/c11+c12
            $val_f=($value->CSectionOTSafeChecklist==0)?0:formatValue(($value->CSectionOTSafeChecklist * 100) / $value->TotalCSections); // c40*100/c13
            $val_g=($value->RealTimePartograph==0)?0:formatValue(($value->RealTimePartograph * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c41*100/c11+c12
            $val_h=($value->BreastfedNewborns==0)?0:formatValue(($value->BreastfedNewborns * 100) / ($value->TotalAssistedVaginalDeliveries + $value->TotalNormalVaginalDeliveries + $value->TotalCSections)); // c42*100/(c13+c12+c11)
            $val_i=($value->NewbornsSNCUAsphyxia==0)?0:formatValue(($value->NewbornsSNCUAsphyxia * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //c47*100/(c11+c12+13)
            $val_j=($value->NewbornsSNCUSepsis==0)?0:formatValue(($value->NewbornsSNCUSepsis * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //c48*100/(c11+c12+13)
            $val_k=($value->CSectionsInfection==0)?0:formatValue(($value->CSectionsInfection * 100) / ($value->TotalCSections)); // c45*100/c13
            $val_l=($value->PretermANCSInFacilitiesSNCU==0)?0:formatValue(($value->PretermANCSInFacilitiesSNCU * 100) / ($value->TotalPretermDeliveries)); //c46*100/c35
            $val_m=($value->MaternalPIHEclampsia==0)?0:formatValue(($value->MaternalPIHEclampsia * 100) / ($value->TotalMaternalDeaths)); // c20*100/c14
            $val_n=($value->MaternalAPH + $value->MaternalPPH==0)?0:formatValue((($value->MaternalAPH + $value->MaternalPPH) * 100) / ($value->TotalMaternalDeaths)); // (c16+c17)*100/c14
            $val_o=($value->ReorganizedLR==1)?'YES':'NO'; // c52
            $val_p=($value->AdequateStaffLR==1)?'YES':'NO'; //c53
            $val_q=($value->OxytocinCount==0)?0:formatValue(($value->OxytocinCount * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c54*100/(c11+c12)
            $val_r=''; //current osce score (remove) from form
            $val_s=$value->ReferralCases; //c58
            $val_t=$value->MaternalDeathsReviewed + $value->NeonatalDeaths + $value->MaternalMissCases; //c55+c56+c57
            $val_u=($value->StockOutsInOT==1)?'YES':'NO'; //c60
            $val_v=($value->TotalFreshStillBirths + $value->TotalMaceratedStillBirths==0)?0:formatValue((($value->TotalFreshStillBirths + $value->TotalMaceratedStillBirths) * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //(c25+c26)*100/(c11+c12+c13)
            $val_w=($value->SatisfiedDelivered==0)?0:formatValue(($value->SatisfiedDelivered * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //(c51)*100/(c11+c12+c13);
            $val_x=($value->MCHDHFunctional==1)?'YES':'NO'; //c62
            $val_y=($value->MCBSamplingLR==1 && $value->MCBSamplingOT==1)?'YES':'NO'; //c43+c44;
            $val_z=(($value->CurrentLabourRoomQualityScore-$value->BaselineScoreLR*100)>0 && !empty($value->BaselineScoreLR))?formatValue(($value->CurrentLabourRoomQualityScore-$value->BaselineScoreLR*100)/$value->BaselineScoreLR):0; //(c66-c72)*100/c72;
            $val_za=(($value->CurrentMaternityOTQualityScore-$value->BaselineScoreOT*100)>0 && !empty($value->BaselineScoreOT))?formatValue(($value->CurrentMaternityOTQualityScore-$value->BaselineScoreOT*100)/$value->BaselineScoreOT):0;  //c67-c75*100/c75;

	        if($val_a=='YES'){  $val_a_text++; }
	        if($val_b=='YES'){  $val_b_text++; }
	        if($val_b=='YES'){  $val_c_text++; }
	        if($val_d>=90){  $val_d_text++; }
	        if($val_e>=90){  $val_e_text++; }
	        if($val_f>=90){  $val_f_text++; }
	        if($val_g>=90){  $val_g_text++; }
	        if($val_h>=80){  $val_h_text++; }
	        if($val_i>=80){  $val_i_text++; }
	        if($val_j>=80){  $val_j_text++; }
	        if($val_k<=5){  $val_j_text++; }
	        if($val_l>=80){  $val_l_text++; }
	        if($val_m==0){  $val_m_text++; }
	        if($val_n==0){  $val_n_text++; }
	        if($val_o=='YES'){  $val_o_text++; }
	        if($val_p=='YES'){  $val_p_text++; }
	        if($val_q>=100){  $val_q_text++; }
	        if($val_r>=80){  $val_r_text++; }
	        if($val_s>=0){  $val_s_text++; }
	        if($val_t>=0){  $val_t_text++; }
	        if($val_u=='YES'){  $val_u_text++; }
	        if($val_v>=0){  $val_v_text++; }
	        if($val_w>=0){  $val_w_text++; }
	        if($val_x=='YES'){  $val_x_text++; }
	        if($val_y=='YES'){  $val_y_text++; }
	        if($val_z>=0){  $val_z_text++; }
	        if($val_za>=0){  $val_za_text++; }

            //$dataget[] = $subdata;
        }
        /*$response = array(
	      array("Indicator ", "Percent", array("role"=>"style") ),
	      array("Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores",round((float)((($val_a_text/$totalFacility))*100), 2), ""),
	      array("Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots", round((float)((($val_b_text/$totalFacility))*100), 2), " "),
	      array("Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI", round((float)((($val_c_text/$totalFacility))*100), 2), " "),
	      array("Percentage of deliveries are attended by a birth companion", round((float)((($val_d_text/$totalFacility))*100), 2), " "),
	      array("Percentage deliveries are conducted using safe birth checklist in Labour Room", round((float)((($val_e_text/$totalFacility))*100), 2), " "),
	      array("Percentage of deliveries are conducted using  Safe Surgery checklist in Maternity OT", round((float)((($val_f_text/$totalFacility))*100), 2), " "),
	      array("Percentage of deliveries for which Partograph is generated using real-time information in at least", round((float)((($val_g_text/$totalFacility))*100), 2), " "),
	      array("Percentage breastfeeding within 1 hour", round((float)((($val_h_text/$totalFacility))*100), 2), " "),
	      array("Neonatal asphyxia rate in Inborn Babies", round((float)((($val_i_text/$totalFacility))*100), 2), " "),
	      array("Neonatal sepsis rate in-born babies", round((float)((($val_j_text/$totalFacility))*100), 2), " "),
	      array("Surgical Site infection Rate in Maternity OT", round((float)((($val_k_text/$totalFacility))*100), 2), " "),
	      array("Antenatal corticosteroid administration rate in case in preterm labour", round((float)((($val_l_text/$totalFacility))*100), 2), " "),
	      array("Pre-eclampsia, eclampsia & PIH related mortality", round((float)((($val_m_text/$totalFacility))*100), 2), " "),
	      array("APH/PPH related mortality", round((float)((($val_n_text/$totalFacility))*100), 2), " "),
	      array("Facility Labour Room is reorganized as labour room standardization guidelines", round((float)((($val_o_text/$totalFacility))*100), 2), ""),
	      array("Facility Labour room has staffing as per defined norms", round((float)((($val_p_text/$totalFacility))*100), 2), ""),
	      array("Percentage of Women, administered Oxytocin, immediately after birth", round((float)((($val_q_text/$totalFacility))*100), 2), ""),
	      array("OSCE Score", round((float)((($val_r_text/$totalFacility))*100), 2), ""),
	      array("Facility conducts referral audit on Monthly basis", round((float)((($val_s_text/$totalFacility))*100), 2), ""),
	      array("Facility conducts Maternal death, Neonatal death and near-miss on monthly basis", round((float)((($val_t_text/$totalFacility))*100), 2), ""),
	      array("Facility report zero stock outs in Labour Room & Maternity OT", round((float)((($val_u_text/$totalFacility))*100), 2), ""),	      
	      array("Still Birth Rate", round((float)((($val_v_text/$totalFacility))*100), 2), ""),
	      array("Percentage of beneficiaries  who were either satisfied or highly satisfied", round((float)((($val_w_text/$totalFacility))*100), 2), ""),
	      array("functional Obs ICU/Hybrid ICU/HDU?", round((float)((($val_x_text/$totalFacility))*100), 2), ""),
	      array("Microbiological Surveillance in OT & LR", round((float)((($val_y_text/$totalFacility))*100), 2), ""),	      
	      array("Labour Room Quality Score Improvement from Baseline", round((float)((($val_z_text/$totalFacility))*100), 2), ""),
	      array("Maternity OT Quality Score Improvement from Baseline", round((float)((($val_za_text/$totalFacility))*100), 2), ""),
	      array("Score", 100, "")
        );*/
        $data_a=round((float)((($val_a_text/$totalFacility))*100), 2); if($data_a>75){  $data_a_class='success'; } else if($data_a>=50 && $data_a<=75){ $data_a_class='inprocess'; } else { $data_a_class='faild'; }

        $data_b=round((float)((($val_b_text/$totalFacility))*100), 2); if($data_b>75){  $data_b_class='success'; } else if($data_b>=50 && $data_b<=75){ $data_b_class='inprocess'; } else { $data_b_class='faild'; }

        $data_c=round((float)((($val_c_text/$totalFacility))*100), 2); if($data_c>75){  $data_c_class='success'; } else if($data_c>=50 && $data_c<=75){ $data_c_class='inprocess'; } else { $data_c_class='faild'; }

        $data_d=round((float)((($val_d_text/$totalFacility))*100), 2); if($data_d>75){  $data_d_class='success'; } else if($data_d>=50 && $data_d<=75){ $data_d_class='inprocess'; } else { $data_d_class='faild'; }

        $data_e=round((float)((($val_e_text/$totalFacility))*100), 2); if($data_e>75){  $data_e_class='success'; } else if($data_e>=50 && $data_e<=75){ $data_e_class='inprocess'; } else { $data_e_class='faild'; }

        $data_f=round((float)((($val_f_text/$totalFacility))*100), 2); if($data_f>75){  $data_f_class='success'; } else if($data_f>=50 && $data_f<=75){ $data_f_class='inprocess'; } else { $data_f_class='faild'; }

        $data_g=round((float)((($val_g_text/$totalFacility))*100), 2); if($data_g>75){  $data_g_class='success'; } else if($data_g>=50 && $data_g<=75){ $data_g_class='inprocess'; } else { $data_g_class='faild'; }

        $data_h=round((float)((($val_h_text/$totalFacility))*100), 2); if($data_h>75){  $data_h_class='success'; } else if($data_h>=50 && $data_h<=75){ $data_h_class='inprocess'; } else { $data_h_class='faild'; }

        $data_i=round((float)((($val_i_text/$totalFacility))*100), 2); if($data_i>75){  $data_i_class='success'; } else if($data_i>=50 && $data_i<=75){ $data_i_class='inprocess'; } else { $data_i_class='faild'; }

        $data_j=round((float)((($val_j_text/$totalFacility))*100), 2); if($data_j>75){  $data_j_class='success'; } else if($data_j>=50 && $data_j<=75){ $data_j_class='inprocess'; } else { $data_j_class='faild'; }

        $data_k=round((float)((($val_k_text/$totalFacility))*100), 2); if($data_k>75){  $data_k_class='success'; } else if($data_k>=50 && $data_k<=75){ $data_k_class='inprocess'; } else { $data_k_class='faild'; }

        $data_l=round((float)((($val_l_text/$totalFacility))*100), 2); if($data_l>75){  $data_l_class='success'; } else if($data_l>=50 && $data_l<=75){ $data_l_class='inprocess'; } else { $data_l_class='faild'; }

        $data_m=round((float)((($val_m_text/$totalFacility))*100), 2); if($data_m>75){  $data_m_class='success'; } else if($data_m>=50 && $data_m<=75){ $data_m_class='inprocess'; } else { $data_m_class='faild'; }

        $data_n=round((float)((($val_n_text/$totalFacility))*100), 2); if($data_n>75){  $data_n_class='success'; } else if($data_n>=50 && $data_n<=75){ $data_n_class='inprocess'; } else { $data_n_class='faild'; }

        $data_o=round((float)((($val_o_text/$totalFacility))*100), 2); if($data_o>75){  $data_o_class='success'; } else if($data_o>=50 && $data_o<=75){ $data_o_class='inprocess'; } else { $data_o_class='faild'; }

        $data_p=round((float)((($val_p_text/$totalFacility))*100), 2); if($data_p>75){  $data_p_class='success'; } else if($data_p>=50 && $data_p<=75){ $data_p_class='inprocess'; } else { $data_p_class='faild'; }

        $data_q=round((float)((($val_q_text/$totalFacility))*100), 2); if($data_q>75){  $data_q_class='success'; } else if($data_q>=50 && $data_q<=75){ $data_q_class='inprocess'; } else { $data_q_class='faild'; }

        $data_r=round((float)((($val_r_text/$totalFacility))*100), 2); if($data_r>75){  $data_r_class='success'; } else if($data_r>=50 && $data_r<=75){ $data_r_class='inprocess'; } else { $data_r_class='faild'; }

        $data_s=round((float)((($val_s_text/$totalFacility))*100), 2); if($data_s>75){  $data_s_class='success'; } else if($data_s>=50 && $data_s<=75){ $data_s_class='inprocess'; } else { $data_s_class='faild'; }

        $data_t=round((float)((($val_t_text/$totalFacility))*100), 2); if($data_t>75){  $data_t_class='success'; } else if($data_t>=50 && $data_t<=75){ $data_t_class='inprocess'; } else { $data_t_class='faild'; }

        $data_u=round((float)((($val_u_text/$totalFacility))*100), 2); if($data_u>75){  $data_u_class='success'; } else if($data_u>=50 && $data_u<=75){ $data_u_class='inprocess'; } else { $data_u_class='faild'; }

        $data_v=round((float)((($val_v_text/$totalFacility))*100), 2); if($data_v>75){  $data_v_class='success'; } else if($data_v>=50 && $data_v<=75){ $data_v_class='inprocess'; } else { $data_v_class='faild'; }

        $data_w=round((float)((($val_w_text/$totalFacility))*100), 2); if($data_w>75){  $data_w_class='success'; } else if($data_w>=50 && $data_w<=75){ $data_w_class='inprocess'; } else { $data_w_class='faild'; }

        $data_x=round((float)((($val_x_text/$totalFacility))*100), 2); if($data_x>75){  $data_x_class='success'; } else if($data_x>=50 && $data_x<=75){ $data_x_class='inprocess'; } else { $data_x_class='faild'; }

        $data_y=round((float)((($val_y_text/$totalFacility))*100), 2); if($data_y>75){  $data_y_class='success'; } else if($data_y>=50 && $data_y<=75){ $data_y_class='inprocess'; } else { $data_y_class='faild'; }

        $data_z=round((float)((($val_z_text/$totalFacility))*100), 2); if($data_z>75){  $data_z_class='success'; } else if($data_z>=50 && $data_z<=75){ $data_z_class='inprocess'; } else { $data_z_class='faild'; }

        $data_za=round((float)((($val_za_text/$totalFacility))*100), 2); if($data_za>75){  $data_za_class='success'; } else if($data_za>=50 && $data_za<=75){ $data_za_class='inprocess'; } else { $data_za_class='faild'; }

        
        $responseData= array();
          $responseData[]=array("id"=>"val_a","val"=>$data_a,"class"=>$data_a_class);
          $responseData[]=array("id"=>"val_b","val"=>$data_b,"class"=>$data_b_class);
          $responseData[]=array("id"=>"val_c","val"=>$data_c,"class"=>$data_c_class);
          $responseData[]=array("id"=>"val_d","val"=>$data_d,"class"=>$data_d_class);
          $responseData[]=array("id"=>"val_e","val"=>$data_e,"class"=>$data_e_class);
          $responseData[]=array("id"=>"val_f","val"=>$data_f,"class"=>$data_f_class);
          $responseData[]=array("id"=>"val_g","val"=>$data_g,"class"=>$data_g_class);
          $responseData[]=array("id"=>"val_h","val"=>$data_h,"class"=>$data_h_class);
          $responseData[]=array("id"=>"val_i","val"=>$data_i,"class"=>$data_i_class);
          $responseData[]=array("id"=>"val_j","val"=>$data_j,"class"=>$data_j_class);
          $responseData[]=array("id"=>"val_k","val"=>$data_k,"class"=>$data_k_class);
          $responseData[]=array("id"=>"val_l","val"=>$data_l,"class"=>$data_l_class);
          $responseData[]=array("id"=>"val_m","val"=>$data_m,"class"=>$data_m_class);
          $responseData[]=array("id"=>"val_n","val"=>$data_n,"class"=>$data_n_class);
          $responseData[]=array("id"=>"val_o","val"=>$data_o,"class"=>$data_o_class);
          $responseData[]=array("id"=>"val_p","val"=>$data_p,"class"=>$data_p_class);
          $responseData[]=array("id"=>"val_q","val"=>$data_q,"class"=>$data_q_class);
          $responseData[]=array("id"=>"val_r","val"=>$data_r,"class"=>$data_r_class);
          $responseData[]=array("id"=>"val_s","val"=>$data_s,"class"=>$data_s_class);
          $responseData[]=array("id"=>"val_t","val"=>$data_t,"class"=>$data_t_class);
          $responseData[]=array("id"=>"val_u","val"=>$data_u,"class"=>$data_u_class);
          $responseData[]=array("id"=>"val_v","val"=>$data_v,"class"=>$data_v_class);
          $responseData[]=array("id"=>"val_w","val"=>$data_w,"class"=>$data_w_class);
          $responseData[]=array("id"=>"val_x","val"=>$data_x,"class"=>$data_x_class);
          $responseData[]=array("id"=>"val_y","val"=>$data_y,"class"=>$data_y_class);   
          $responseData[]=array("id"=>"val_z","val"=>$data_z,"class"=>$data_z_class);
          $responseData[]=array("id"=>"val_za","val"=>$data_za,"class"=>$data_za_class);
        
          $response['data']=$responseData;
        //echo "<pre>"; print_r($response); echo "</pre>";
        return $response;
    }
    function faclity_monthly_indicator($data){
    	$val_a=$val_b=$val_c=$val_d=$val_e=$val_f=$val_g=$val_h=$val_i=$val_j=$val_k=$val_l=$val_m=$val_n=$val_o=$val_p=$val_q=$val_r=$val_s=$val_t=$val_u=$val_v=$val_w=$val_x=$val_y=$val_z=$val_za='-';

        $this->db->select('s.StateName,d.DistrictName,f.FacilityName,f.FacilityNumber,f.stateID,f.districtId,um.UserID,m.*,ot.BaselineNQASChecklistLR,ot.BaselineNQASChecklistOT,ot.QualityTeamFacility,ot.QualityCircleLR,ot.QualityCircleOT,ot.OrientationAttended,ot.BaselineScoreOT,ot.BaselineScoreLR');
        $this->db->from('monthly as m');
        $this->db->join('onetime as ot', 'ot.UserID= m.UserID', 'inner');
        $this->db->join('usermapping as um', 'um.UserID= m.UserID', 'inner');
        $this->db->join('facilities as f', 'f.FacilityID= um.FacilityID', 'inner');
        $this->db->join('states as s', 's.StateID=f.StateID', 'inner');
        $this->db->join('district as d', 'd.DistrictID=f.DistrictID', 'inner');
        if ($this->session->userdata('RoleName') == 'District') {
            $MappedDistrict = $this->session->userdata('MappedDistrict');
            if ($MappedDistrict != '') {
                $MappedDistrictArray = explode(",", $MappedDistrict);
                $this->db->where_in('f.DistrictID', $MappedDistrictArray);
            }
        }
	    if(!empty($data['cond'])){
	    	$this->db->where_in($data['cond']['mappedField'],$data['cond']['mappedData']);
	    }
	    if(isset($data['search'])){
	    	foreach ($data['search'] as $key => $value) {
	    		$this->db->where($value['field'], $value['value']);
	    	}
	    }
        $this->db->where('m.ReportMonth', $data['searchDate']);
        $this->db->order_by('m.ReportMonth', 'DESC');
        $query = $this->db->get();
        $subdata = array();
        foreach ($query->result() as $key => $value) {
            $val_a=($value->BaselineNQASChecklistLR==1 && $value->BaselineNQASChecklistOT==1)?'YES':'No' ;            
            $val_b=($value->QualityTeamFacility==1 || $value->QualityCircleLR==1 || $value->QualityCircleOT==1)?'YES':'NO';
            $val_c=($value->OrientationAttended==1)?'YES':'NO';
            $val_d=($value->BirthCompanionNos==0)?0:formatValue(($value->BirthCompanionNos * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c38*100/c11+c12
            $val_e=($value->SafeBirthChecklist==0)?0:formatValue(($value->SafeBirthChecklist * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c39*100/c11+c12
            $val_f=($value->CSectionOTSafeChecklist==0)?0:formatValue(($value->CSectionOTSafeChecklist * 100) / $value->TotalCSections); // c40*100/c13
            $val_g=($value->RealTimePartograph==0)?0:formatValue(($value->RealTimePartograph * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c41*100/c11+c12
            $val_h=($value->BreastfedNewborns==0)?0:formatValue(($value->BreastfedNewborns * 100) / ($value->TotalAssistedVaginalDeliveries + $value->TotalNormalVaginalDeliveries + $value->TotalCSections)); // c42*100/(c13+c12+c11)
            $val_i=($value->NewbornsSNCUAsphyxia==0)?0:formatValue(($value->NewbornsSNCUAsphyxia * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //c47*100/(c11+c12+13)
            $val_j=($value->NewbornsSNCUSepsis==0)?0:formatValue(($value->NewbornsSNCUSepsis * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //c48*100/(c11+c12+13)
            $val_k=($value->CSectionsInfection==0)?0:formatValue(($value->CSectionsInfection * 100) / ($value->TotalCSections)); // c45*100/c13
            $val_l=($value->PretermANCSInFacilitiesSNCU==0)?0:formatValue(($value->PretermANCSInFacilitiesSNCU * 100) / ($value->TotalPretermDeliveries)); //c46*100/c35
            $val_m=($value->MaternalPIHEclampsia==0)?0:formatValue(($value->MaternalPIHEclampsia * 100) / ($value->TotalMaternalDeaths)); // c20*100/c14
            $val_n=($value->MaternalAPH + $value->MaternalPPH==0)?0:formatValue((($value->MaternalAPH + $value->MaternalPPH) * 100) / ($value->TotalMaternalDeaths)); // (c16+c17)*100/c14
            $val_o=($value->ReorganizedLR==1)?'YES':'NO'; // c52
            $val_p=($value->AdequateStaffLR==1)?'YES':'NO'; //c53
            $val_q=($value->OxytocinCount==0)?0:formatValue(($value->OxytocinCount * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c54*100/(c11+c12)
            $val_r=''; //current osce score (remove) from form
            $val_s=$value->ReferralCases; //c58
            $val_t=$value->MaternalDeathsReviewed + $value->NeonatalDeaths + $value->MaternalMissCases; //c55+c56+c57
            $val_u=($value->StockOutsInOT==1)?'YES':'NO'; //c60
            $val_v=($value->TotalFreshStillBirths + $value->TotalMaceratedStillBirths==0)?0:formatValue((($value->TotalFreshStillBirths + $value->TotalMaceratedStillBirths) * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //(c25+c26)*100/(c11+c12+c13)
            $val_w=($value->SatisfiedDelivered==0)?0:formatValue(($value->SatisfiedDelivered * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //(c51)*100/(c11+c12+c13);
            $val_x=($value->MCHDHFunctional==1)?'YES':'NO'; //c62
            $val_y=($value->MCBSamplingLR==1 && $value->MCBSamplingOT==1)?'YES':'NO'; //c43+c44;
            $val_z=(($value->BaselineScoreLR)>0)?formatValue(($value->CurrentLabourRoomQualityScore-$value->BaselineScoreLR*100)/$value->BaselineScoreLR):0; //(c66-c72)*100/c72;
            $val_za=(($value->BaselineScoreOT)>0)?formatValue(($value->CurrentMaternityOTQualityScore-$value->BaselineScoreOT*100)/$value->BaselineScoreOT):0;  //c67-c75*100/c75;
            //$dataget[] = $subdata;
        }
        $val_a_text=$val_a=='YES'?'<span class="success">'.$val_a.'</span>':'<span class="faild">'.$val_a.'</span>';
        $val_b_text=$val_b=='YES'?'<span class="success">'.$val_b.'</span>':'<span class="faild">'.$val_b.'</span>';
        $val_c_text=$val_c=='YES'?'<span class="success">'.$val_c.'</span>':'<span class="faild">'.$val_c.'</span>';
        if(($val_d>0 && $val_d<50) || empty($val_d)){
        	$val_d_text='<span class="faild">'.$val_d.'%</span>';
        } else if($val_d>=50 && $val_d<90){
        	$val_d_text='<span class="inprocess">'.$val_d.'%</span>';
        } else if($val_d=='-' || empty($val_d)){
        	$val_d_text='<span class="faild">-</span>';
        } else {
        	$val_d_text='<span class="success">'.$val_d.'%</span>';
        }
        if(($val_e>0 && $val_e<50) || empty($val_d)){
        	$val_e_text='<span class="faild">'.$val_e.'%</span>';
        } else if($val_e>=50 && $val_e<90){
        	$val_e_text='<span class="inprocess">'.$val_e.'%</span>';
        } else if($val_e=='-' || empty($val_e)){
        	$val_e_text='<span class="faild">-</span>';
        } else {
        	$val_e_text='<span class="success">'.$val_e.'%</span>';
        }
        if(($val_f>0 && $val_f<50) || empty($val_d)){
        	$val_f_text='<span class="faild">'.$val_f.'%</span>';
        } else if($val_f>=50 && $val_f<90){
        	$val_f_text='<span class="inprocess">'.$val_f.'%</span>';
        } else if($val_f=='-' || empty($val_f)){
        	$val_f_text='<span class="faild">-</span>';
        } else {
        	$val_f_text='<span class="success">'.$val_f.'%</span>';
        }
        if(($val_g>0 && $val_g<50) || empty($val_d)){
        	$val_g_text='<span class="faild">'.$val_g.'%</span>';
        } else if($val_g>=50 && $val_g<90){
        	$val_g_text='<span class="inprocess">'.$val_g.'%</span>';
        } else if($val_g=='-' || empty($val_g)){
        	$val_g_text='<span class="faild">-</span>';
        } else {
        	$val_g_text='<span class="success">'.$val_g.'%</span>';
        }
        if(($val_h>0 && $val_h<50) || empty($val_d)){
        	$val_h_text='<span class="faild">'.$val_h.'%</span>';
        } else if($val_h>=50 && $val_h<80){
        	$val_h_text='<span class="inprocess">'.$val_h.'%</span>';
        } else if($val_h=='-' || empty($val_h)){
        	$val_h_text='<span class="faild">-</span>';
        } else {
        	$val_h_text='<span class="success">'.$val_h.'%</span>';
        }
        if(($val_i>0 && $val_i<50) || empty($val_d)){
        	$val_i_text='<span class="faild">'.$val_i.'%</span>';
        } else if($val_i>=50 && $val_i<80){
        	$val_i_text='<span class="inprocess">'.$val_i.'%</span>';
        } else if($val_i=='-' || empty($val_i)){
        	$val_i_text='<span class="faild">-</span>';
        } else {
        	$val_i_text='<span class="success">'.$val_i.'%</span>';
        }
        if(($val_j>0 && $val_j<50) || empty($val_d)){
        	$val_j_text='<span class="faild">'.$val_j.'%</span>';
        } else if($val_j>=50 && $val_j<80){
        	$val_j_text='<span class="inprocess">'.$val_j.'%</span>';
        } else if($val_j=='-' || empty($val_j)){
        	$val_j_text='<span class="faild">-</span>';
        } else {
        	$val_j_text='<span class="success">'.$val_j.'%</span>';
        }
        if(($val_k>5) || empty($val_d)){
        	$val_k_text='<span class="faild">'.$val_k.'%</span>';
        } else if($val_k>0 && $val_k<5){
        	$val_k_text='<span class="inprocess">'.$val_k.'%</span>';
        } else if($val_k=='-' || empty($val_k)){
        	$val_k_text='<span class="faild">-</span>';
        } else {
        	$val_k_text='<span class="success">'.$val_k.'%</span>';
        }
        if(($val_l>0 && $val_l<50) || empty($val_d)){
        	$val_l_text='<span class="faild">'.$val_l.'%</span>';
        } else if($val_l>=50 && $val_l<80){
        	$val_l_text='<span class="inprocess">'.$val_l.'%</span>';
        } else if($val_l=='-' || empty($val_l)){
        	$val_l_text='<span class="faild">-</span>';
        } else {
        	$val_l_text='<span class="success">'.$val_l.'%</span>';
        }
        $val_m_text=($val_m==0 && $val_m!='-')?'<span class="success">'.$val_m.'</span>':'<span class="faild">'.$val_m.'</span>';
        $val_n_text=($val_n==0 && $val_n!='-')?'<span class="success">'.$val_n.'</span>':'<span class="faild">'.$val_n.'</span>';
        $val_o_text=$val_o=='YES'?'<span class="success">'.$val_o.'</span>':'<span class="faild">'.$val_o.'</span>';
        $val_p_text=$val_p=='YES'?'<span class="success">'.$val_p.'</span>':'<span class="faild">'.$val_p.'</span>';
        if(($val_q>0 && $val_q<50) || empty($val_d)){
        	$val_q_text='<span class="faild">'.$val_q.'%</span>';
        } else if($val_q>=50 && $val_q<100){
        	$val_q_text='<span class="inprocess">'.$val_q.'%</span>';
        } else if($val_q=='-' || empty($val_q)){
        	$val_q_text='<span class="faild">-</span>';
        } else {
        	$val_q_text='<span class="success">'.$val_q.'%</span>';
        }
        if(($val_r>0 && $val_r<50) || empty($val_d)){
        	$val_r_text='<span class="faild">'.$val_r.'%</span>';
        } else if($val_r>=50 && $val_r<80){
        	$val_r_text='<span class="inprocess">'.$val_r.'%</span>';
        } else if($val_r=='-' || empty($val_r)){
        	$val_r_text='<span class="faild">-</span>';
        } else {
        	$val_r_text='<span class="success">'.$val_r.'%</span>';
        }
        $val_s_text=$val_s>0?'<span class="success">'.$val_s.'</span>':'<span class="faild">'.$val_s.'</span>';
        $val_t_text=$val_t>0?'<span class="success">'.$val_t.'</span>':'<span class="faild">'.$val_t.'</span>';
        $val_u_text=$val_u=='YES'?'<span class="success">'.$val_u.'</span>':'<span class="faild">'.$val_u.'</span>';
        $val_v_text=$val_v>0?'<span class="success">'.$val_v.'</span>':'<span class="faild">'.$val_v.'</span>';
        $val_w_text=$val_w>0?'<span class="success">'.$val_w.'</span>':'<span class="faild">'.$val_w.'</span>';
        $val_x_text=$val_x=='YES'?'<span class="success">'.$val_x.'</span>':'<span class="faild">'.$val_x.'</span>';
        $val_y_text=$val_y=='YES'?'<span class="success">'.$val_y.'</span>':'<span class="faild">'.$val_y.'</span>';
        $val_z_text=$val_z>0?'<span class="success">'.$val_z.'</span>':'<span class="faild">'.$val_z.'</span>';
        $val_za_text=$val_za>0?'<span class="success">'.$val_za.'</span>':'<span class="faild">'.$val_za.'</span>';

        $subdata['a'] = $val_a_text;
        $subdata['b'] = $val_b_text;
        $subdata['c'] = $val_c_text;
        $subdata['d'] = $val_d_text;
        $subdata['e'] = $val_e_text;
        $subdata['f'] = $val_f_text;
        $subdata['g'] = $val_g_text;
        $subdata['h'] = $val_h_text;
        $subdata['i'] = $val_i_text;
        $subdata['j'] = $val_j_text;
        $subdata['k'] = $val_k_text;
        $subdata['l'] = $val_l_text;
        $subdata['m'] = $val_m_text;
        $subdata['n'] = $val_n_text;
        $subdata['o'] = $val_o_text;
        $subdata['p'] = $val_p_text;
        $subdata['q'] = $val_q_text;
        $subdata['r'] = $val_r_text;
        $subdata['s'] = $val_s_text;
        $subdata['t'] = $val_t_text;
        $subdata['u'] = $val_u_text;
        $subdata['v'] = $val_v_text;
        $subdata['w'] = $val_w_text;
        $subdata['x'] = $val_x_text;
        $subdata['y'] = $val_y_text;
        $subdata['z'] = $val_z_text;
        $subdata['za'] = $val_za_text;

        return $subdata;

    }
    function notificationCount(){
		$this->db->select('certificationLogsID');
		$this->db->from('certification_logs');
		switch ($this->session->userdata('RoleName')) {
			case 'Facility':
				$this->db->where('facility','1');
				break;
			case 'District':
				$this->db->where('district','1');
				break;
			case 'State':
				$this->db->where('state','1');
				break;
			case 'Ministry':
				$this->db->where('ministry','1');
				break;
			default:
				break;
		}
		$query = $this->db->get();
    	return $query->num_rows();
    }
    function getNotification($searchData){
		$col =array(
		    0   =>  'CreatedOn',
		    1   =>  'CreatedOn',
		    2   =>  'msg',
		    3   =>  'CreatedOn',
		    4   =>  'UserName'
		);
		$this->db->select('certification_logs.*,users.UserName');
		$this->db->from('certification_logs');
		$this->db->join('users', 'users.UserID = certification_logs.UserID', 'inner');
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $queryTot = $this->db->get();

		$this->db->select('certification_logs.*,users.FirstName as UserName');
		$this->db->from('certification_logs');
		$this->db->join('users', 'users.UserID = certification_logs.UserID', 'inner');
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $this->db->limit($searchData['length'],$searchData['start']);
	    $query = $this->db->get();

	    $dataget=array();
	    $cnt=$searchData['start'];
		foreach ($query->result_array() as $key => $value) {
			if(in_array($searchData['RoleName'], array('Ministry','State'))){
				$link=base_url().'certification/approvalview/'.encryptor($value['CertificationID']);
			} else {
				$link=base_url().'certification/certificationview/'.encryptor($value['CertificationID']);
			}
			$subdata=array();
			$subdata[]=++$cnt;
			$subdata[]=$value['CreatedOn'];
			$subdata[]=$value['msg'];
			$subdata[]='<a class="btn btn-info" href="'.$link.'">View</a>';
			$subdata[]=$value['UserName'];
			$dataget[]=$subdata;
		}
		$data['data']=$dataget;
		$data['totalData']=$queryTot -> num_rows();
		$data['totalFilter']=$queryTot -> num_rows();

		$dataUpdate=array();
		switch ($this->session->userdata('RoleName')) {
			case 'Facility':
				$dataUpdate['facility']='0';
				break;
			case 'District':
				$dataUpdate['district']='0';
				$this->db->where('district','1');
				break;
			case 'State':
				$dataUpdate['state']='0';
				break;
			case 'Ministry':
				$dataUpdate['ministry']='0';
				break;
			default:
				break;
		}
		if(!empty($dataUpdate)){
			$this->db->update('certification_logs', $dataUpdate);
		}

		return $data;
    }
    function assessment_list_data($searchData){
		$col =array(
		    0   =>  'assessment_cronlog.CreatedOn',
		    1   =>  'states.StateName',
		    2   =>  'district.DistrictName',
		    3   =>  'facilities.FacilityName'
		);
		$this->db->select('assessment_cronlog.id');
		$this->db->from('assessment_cronlog');
		$this->db->join('facilities', 'facilities.FacilityNumber = assessment_cronlog.FacilityNumber', 'left');
		$this->db->join('states', 'facilities.StateID = states.StateID', 'left');
		$this->db->join('district', 'facilities.DistrictID = district.DistrictID', 'left');
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $queryTot = $this->db->get();

		$this->db->select('assessment_cronlog.*,states.StateName,district.DistrictName,facilities.FacilityName');
		$this->db->from('assessment_cronlog');
		$this->db->join('facilities', 'facilities.FacilityNumber = assessment_cronlog.FacilityNumber', 'left');
		$this->db->join('states', 'facilities.StateID = states.StateID', 'left');
		$this->db->join('district', 'facilities.DistrictID = district.DistrictID', 'left');
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    if($searchData['length']>0){
	    	$this->db->limit($searchData['length'],$searchData['start']);
		}
	    $query = $this->db->get();

	    $dataget=array();
	    $cnt=$searchData['start'];
		foreach ($query->result_array() as $key => $value) {
			$subdata=array();
			$subdata[]=++$cnt;
			$subdata[]=$value['StateName'];
			$subdata[]=$value['DistrictName'];
			$subdata[]=$value['FacilityName'];
			$subdata[]=$value['FacilityNumber'];
			$subdata[]=$value['filename'];
			$subdata[]=convert_datetime_show($value['fileDate']);
			$subdata[]=$value['status']==1?'Success':'Failed';
			$subdata[]=$value['remarks'];
			$subdata[]=convert_datetime_show($value['CreatedOn']);
			$dataget[]=$subdata;
		}
		$data['data']=$dataget;
		$data['totalData']=$queryTot -> num_rows();
		$data['totalFilter']=$queryTot -> num_rows();
		return $data;
    }
    function facility_update(){
		$this->db->select('facilities.FacilityNumber');
		$this->db->from('facilities');
		//$this->db->join('users', 'users.UserID = certification_logs.UserID', 'left');
		$this->db->where('facilities.IsActive','1');
		$this->db->where('facilities.FacilityNumber<>','');
		$this->db->where('facilities.cron_update',0);
	    $this->db->order_by('facilities.FacilityNumber','ASC');
	    $this->db->limit(100);
	    $query = $this->db->get();
		echo $this->db->last_query()."<br>";
	    
	    $dataget=array();
		foreach ($query->result_array() as $key => $value) {
			echo $url='https://nin.nhp.gov.in/api/facilities?api-key=AIkhSyD878mxnps32aCUQSOQXnxzc0PWVQsRkxq&nin_to_hfi='.$value['FacilityNumber'];
			$ch = curl_init();
			curl_setopt($ch,CURLOPT_URL,$url);
			curl_setopt($ch,CURLOPT_RETURNTRANSFER,true); 
			$output=curl_exec($ch);
			$data=json_decode($output,true);
    		curl_close($ch);
			if(isset($data['message']['status']) && $data['message']['status']=='success'){
				if(isset($data['result']['total_records']) && $data['result']['total_records']==1){
				  	// type check start
				  	$this->db->select('TypeDetailID');
				    $this->db->from('typedetail');
				    $this->db->where('TypeMasterID','4');
				    $this->db->where('TypeDetailCode',$data['data'][0]['phc_chc_type']);
				    $this->db->order_by('TypeDetailID', 'DESC');
				    $query = $this->db->get();
					if($query -> num_rows()>=1){
						$result_types = $query->row_array();
						$TypeDetailID=$result_types['TypeDetailID'];
					} else {
						$typesFac=array(
							'TypeMasterID'=>'4',
							'TypeDetailCode'=>$data['data'][0]['phc_chc_type'],
							'TypeDetailLogicalCode'=>$data['data'][0]['phc_chc_type'],
							'Sequence'=>'1',
							'IsActive'=>'1'
						);
						if($this->db->insert('typedetail', $typesFac)){
							$TypeDetailID=$this->db->insert_id();
						} else {
							$this->db->insert('typedetail', $typesFac);
							$TypeDetailID=$this->db->insert_id();
						}
					}
					// type check end
					// facility update start
					$dataAPI=array(
						'FacilityName'=>$data['data'][0]['hfi_name'],
						'Latitude'=>$data['data'][0]['latitude'],
						'Longitude'=>$data['data'][0]['longitude'],
						'Altitude'=>$data['data'][0]['altitude'],
						'Address'=>$data['data'][0]['house_number'].' '.$data['data'][0]['street'].' '.$data['data'][0]['landmark'].' '.$data['data'][0]['locality'],
						'pincode'=>$data['data'][0]['pincode'],
						'landLine'=>$data['data'][0]['landline_number'],
						'FacilityTypeDetailID'=>$TypeDetailID,
						'cron_update'=>'1',
						'cron_date'=>date('Y-m-d H:i:s')
					);
					$this->db->where_in('FacilityNumber', $value['FacilityNumber']);
					if ($this->db->update('facilities', $dataAPI) === FALSE){
						$dataErr=array(
							'cron_update'=>'0',
							'cron_date'=>date('Y-m-d H:i:s')
						);
						$this->db->where_in('FacilityNumber', $value['FacilityNumber']);
						$this->db->update('facilities', $dataErr);
					} else {

					}
					// facility update end
					// nodal start
				    $this->db->select('usermapping.UserID');
				    $this->db->from('usermapping');
				    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID AND usermapping.FacilityID>0', 'inner');
				    $this->db->where('facilities.FacilityNumber',$value['FacilityNumber']);
				    $this->db->where('usermapping.IsActive','1');
				    $queryUserID = $this->db->get();
					$result_user = $queryUserID->row_array();
					$UserID=$result_user['UserID'];


				  	$this->db->select('InchargeID');
				    $this->db->from('incharge');
				    $this->db->where('UserID',$UserID);
				    $this->db->where('TypeDetailID','438');
				    $this->db->where('IsActive','1');
				    $queryNodal = $this->db->get();
					if($queryNodal -> num_rows()>=1){
					    //$nodalUserID = $this->db->get();
						$nodalData = $queryNodal->row_array();
						$incharge=array(
							'Mobile'=>$data['data'][0]['in_charge_mobile'],
							'Email'=>$data['data'][0]['email'],
							'IsActive'=>'1',
							'ModifiedOn'=>date('Y-m-d h:i:s'),
							'ModifiedBy'=>'0',
							'cron_update'=>'1',
							'cron_date'=>date('Y-m-d h:i:s'),
						);						
						$this->db->where('InchargeID', $nodalData['InchargeID']);
						if ($this->db->update('incharge', $incharge) === FALSE){
							$dataErr=array(
								'cron_update'=>'0',
								'cron_date'=>date('Y-m-d H:i:s')
							);
							$this->db->where('InchargeID',$nodalData['InchargeID']);
							$this->db->update('incharge', $dataErr);
						} else {

						}
					} else {
						$incharge=array(
							'UserID'=>$UserID,
							'TypeDetailID'=>'438',
							'Mobile'=>$data['data'][0]['in_charge_mobile'],
							'Email'=>$data['data'][0]['email'],
							'IsActive'=>'1',
							'CreatedOn'=>date('Y-m-d h:i:s'),
							'CreatedBy'=>'0',
							'cron_update'=>'1',
							'cron_date'=>date('Y-m-d h:i:s'),
						);
						$this->db->insert('incharge', $incharge);
					}

				}
			} else {
				$dataErr=array(
					'cron_update'=>'1',
					'cron_date'=>date('Y-m-d H:i:s')
				);
				$this->db->where_in('FacilityNumber', $value['FacilityNumber']);
				$this->db->update('facilities', $dataErr);
			}
			echo "<pre>"; print_r($data); echo "</pre>";

			/*$subdata=array();
			$subdata[]=$value['FacilityNumber'];
			$dataget[]=$subdata;*/
		}
		echo "<pre>"; print_r($dataget); echo "</pre>";
    }
    function getRoles($role=''){
	  	$this->db->select('RoleID,RoleName');
	  	$this->db->from('role');
	  	if(!empty($role)){
	  		$this->db->where('RoleID',$role);	
	  	}
	    $this->db->where('IsActive','1');
	    $this->db->order_by('RoleName','ASC');
	    $queryRole = $this->db->get();    	
	    return $queryRole->result_array();    	
    }
    function getURLs(){
	  	$this->db->select('url.id,url.url,module.moduleName,url.formName,url.moduleID,url.pages');
	  	$this->db->from('url');
	  	$this->db->join('module', 'url.moduleID=module.id AND module.IsActive=1', 'inner');
	    $this->db->where('url.IsActive','1');
	    $this->db->order_by('module.moduleName','ASC');
	    $queryRole = $this->db->get();
	    return $queryRole->result_array();    	
    }
    function getUserAccess($role){
    	$data=array();
	  	$this->db->select('user_access.roleID,url.moduleID,user_access.urlID,user_access.access_add,user_access.access_edit,user_access.access_delete,user_access.access_view');
	  	$this->db->from('user_access');
	  	$this->db->join('url', 'url.id=user_access.urlID', 'inner');
	  	if(!empty($role)){
	  		$this->db->where('user_access.RoleID',$role);	
	  	}
	    $this->db->order_by('url.moduleID','ASC');
	    $queryUserAccess = $this->db->get();
	    foreach ($queryUserAccess->result_array() as $key => $value) {
	    	$data[$value['roleID']][$value['urlID']]=array(
	    			'access_add'=>$value['access_add'],
	    			'access_edit'=>$value['access_edit'],
	    			'access_delete'=>$value['access_delete'],
	    			'access_view'=>$value['access_view']
	    		);
	    }
	    return $data;
    }
    function updateRoles($data,$roles){
	  	$this->db->select('user_access.id,url.IsActive');
	  	$this->db->from('user_access');
	  	$this->db->join('url', 'url.id=user_access.urlID', 'left');
	  	$this->db->where('user_access.roleID',$data['RoleID']);
	  	$this->db->where('user_access.urlID',$data['frmID']);
	    $queryRole = $this->db->get();
	    $access_add=isset($roles['1'])?'1':'0';
	    $access_edit=isset($roles['2'])?'1':'0';
	    $access_delete=isset($roles['3'])?'1':'0';
	    $access_view=isset($roles['4'])?'1':'0';
	    if($queryRole->num_rows()==0){
	    	// insert access
	    	$inserData=array(
	    		'roleID'=>$data['RoleID'],
	    		'urlID'=>$data['frmID'],
	    		'access_add'=>$access_add,
	    		'access_edit'=>$access_edit,
	    		'access_delete'=>$access_delete,
	    		'access_view'=>$access_view,
	    		'IsActive'=>'1',
	    		'CreatedOn'=>date('Y-m-d H:i:s'),
	    		'CreatedBy'=>$data['user']
	    	);
			$this->db->insert('user_access', $inserData);
	    } else {
	    	//update access
	    	$queryRoleData=$queryRole->row_array();
	    	$inserData=array(
	    		'roleID'=>$data['RoleID'],
	    		'urlID'=>$data['frmID'],
	    		'access_add'=>$access_add,
	    		'access_edit'=>$access_edit,
	    		'access_delete'=>$access_delete,
	    		'access_view'=>$access_view,
	    		'IsActive'=>$queryRoleData['IsActive'],
	    		'ModifiedOn'=>date('Y-m-d H:i:s'),
	    		'ModifiedBy'=>$data['user']
	    	);
			$this->db->where_in('id', $queryRoleData['id']);
			$this->db->update('user_access', $inserData);
	    }
    }
    function getMenu(){
    	$url=array('url'=>array(),'menu'=>array());
	  	$this->db->select('module.id,module.moduleName,module.icon,module.sequence,module.controller,url.formName,url.url,sum(user_access.access_add+user_access.access_edit+user_access.access_delete+user_access.access_view) as tot,user_access.access_add,user_access.access_edit,user_access.access_delete,user_access.access_view,user_access.urlID,url.serial');
	  	$this->db->from('user_access');
	  	$this->db->join('url', 'url.id=user_access.urlID', 'inner');
	  	$this->db->join('module', 'url.moduleID=module.id', 'inner');
	  	$this->db->where('user_access.RoleID',$this->session->userdata('RoleID'));
	  	$this->db->where('user_access.IsActive','1');
	    $this->db->order_by('module.sequence','ASC');
	    $this->db->group_by('url.id');
	    $queryUserAccess = $this->db->get();
	    foreach ($queryUserAccess->result_array() as $key => $value) {
	    	if(empty($value['tot'])){ continue; }
	    	$url['url'][$value['url']]=array(
	    			'access_add'=>$value['access_add'],
	    			'access_edit'=>$value['access_edit'],
	    			'access_delete'=>$value['access_delete'],
	    			'access_view'=>$value['access_view']
	    		);
	    	if(isset($url['menu'][$value['sequence']])){
	    	$url['menu'][$value['sequence']]['url'][$value['serial']]=array(
	    					'url'=>$value['url'],
	    					'formName'=>$value['formName'],
	    					'access_add'=>$value['access_add'],
	    					'access_edit'=>$value['access_edit'],
	    					'access_delete'=>$value['access_delete'],
	    					'access_view'=>$value['access_view']
	    		);
	    	} else {
	    		$url['menu'][$value['sequence']]=array(
	    			'moduleName'=>$value['moduleName'],
	    			'controller'=>$value['controller'],
	    			'icon'=>$value['icon'],
	    			'url'=>array()
	    		);
				$url['menu'][$value['sequence']]['url'][$value['serial']]=array(
	    					'url'=>$value['url'],
	    					'formName'=>$value['formName'],
	    					'access_add'=>$value['access_add'],
	    					'access_edit'=>$value['access_edit'],
	    					'access_delete'=>$value['access_delete'],
	    					'access_view'=>$value['access_view']
	    		);
	    	}

	    }
	    return $url;  	
    }
    function checkPageAccessWeb($url,$roleName){
    	$accessData=$this->session->userdata('accessData');
    	if(!empty($accessData['url']) && array_key_exists($url, $accessData['url'])){
    		// able to access this url
    	} else {
    		redirect('/');
    	}
    }
    function checkPageActionWeb($url,$action,$roleName){
    	$accessData=$this->session->userdata('accessData');
    	if(!empty($accessData['url']) && array_key_exists($url, $accessData['url']) && $accessData['url'][$url][$action]=='1'){
    		return true;
    	} else {
    		return false;
    	}
    }
    function getuser($data){
    	$respone=array();
	    $this->db->select('users.UserID,users.UserName,users.FirstName');
	    $this->db->from('users');
	    $this->db->join('userrole', 'users.UserID=userrole.UserID AND userrole.IsActive=1', 'inner');
	    $this->db->where('userrole.RoleID',$data['search_role']);
	    $result = $this->db->get();
	    if($result->num_rows()>0){
	    	$data=array();
	    	/*foreach ($result->result_array() as $key => $value) {
	    		$data[]=array(
	    			'userID'=>$value['UserID'],
	    			'UserName'=>$value['UserName'],
	    			'FirstName'=>$value['FirstName'],
	    		);
	    	}*/
	    	$respone['data']=$result->result_array();
	    	$respone['code']='0';
	    	$respone['msg']=$this->config->item('errCodes')[0];
	    } else {
	    	$respone['code']='13';
	    	$respone['data']=array();
	    	$respone['msg']=$this->config->item('errCodes')[13];
	    }
	    return $respone;
    }
    function getstates($data){
    	$respone=array();
	    $this->db->select('states.StateID,states.StateName');
	    $this->db->from('states');
	    $this->db->where('states.IsActive','1');
	    $result = $this->db->get();
	    if($result->num_rows()>0){
	    	$respone['data']=$result->result_array();
	    	$respone['code']='0';
	    	$respone['msg']=$this->config->item('errCodes')[0];
	    } else {
	    	$respone['code']='13';
	    	$respone['data']=array();
	    	$respone['msg']=$this->config->item('errCodes')[13];
	    }
	    return $respone;
    }
    function getdistricts($data){
    	$respone=array();
	    $this->db->select('district.DistrictID,district.DistrictName,states.StateName,CONCAT(states.StateID,"_",district.DistrictID) AS DistrictVal');
	    $this->db->from('district');
	    $this->db->join('states', 'states.StateID = district.StateID AND states.IsActive="1"', 'inner');
	    if(!in_array('99999', $data['search_state'])){
	    	$this->db->where_in('district.StateID',$data['search_state']);
	    }
	    $this->db->where('district.IsActive','1');
	    //$this->db->order_by('states.StateName','ASC');
	    $this->db->order_by('district.DistrictName','ASC');
	    $result = $this->db->get();
	    if($result->num_rows()>0){
	    	$respone['data']=$result->result_array();
	    	$respone['code']='0';
	    	$respone['msg']=$this->config->item('errCodes')[0];
	    } else {
	    	$respone['code']='13';
	    	$respone['data']=array();
	    	$respone['msg']=$this->config->item('errCodes')[13];
	    }
	    return $respone;
    }
    function getfacilities($data){
    	$respone=array();
	    $this->db->select('facilities.FacilityID,CONCAT(district.DistrictName," ",states.StateName) as hintText,facilities.FacilityName,CONCAT(states.StateID,"_",district.DistrictID,"_",facilities.FacilityID) AS FacilityVal ');
	    $this->db->from('facilities');
	    $this->db->join('states', 'states.StateID = facilities.StateID AND states.IsActive="1"', 'inner');
	    $this->db->join('district', 'district.DistrictID = facilities.DistrictID AND district.IsActive="1"', 'inner');
		if(!in_array('99999', $data['search_state'])){
	    	$this->db->where_in('district.StateID',$data['search_state']);
	    }
		if(!in_array('99999', $data['search_district'])){
	    	$checkDis=explode('_',$data['search_district'][0]);
	    	if(!empty($checkDis[1])){
	    		foreach ($data['search_district'] as $key => $value) {
	    			$valArr=explode('_',$value);
	    			$data['search_district'][$key]=$valArr[1];
	    		}
	    	}
	    	$this->db->where_in('district.DistrictID',$data['search_district']);
	    }
	    $this->db->where('facilities.IsActive','1');
	    //$this->db->order_by('states.StateName','ASC');
	    $this->db->order_by('facilities.FacilityName','ASC');
	    $result = $this->db->get();
	    if($result->num_rows()>0){
	    	$respone['data']=$result->result_array();
	    	$respone['code']='0';
	    	$respone['msg']=$this->config->item('errCodes')[0];
	    } else {
	    	$respone['code']='13';
	    	$respone['data']=array();
	    	$respone['msg']=$this->config->item('errCodes')[13];
	    }
	    return $respone;
    }
    function getfacilitydata($ninnumber){
    	$dataresult=array();
		$this->db->select('facilities.FacilityID');
		$this->db->from('facilities');
		$this->db->join('states', 'facilities.StateID = states.StateID', 'inner');
		$this->db->join('district', 'facilities.DistrictID = district.DistrictID', 'inner');
		$this->db->join('typedetail', 'facilities.FacilityTypeDetailID = typedetail.TypeDetailID', 'inner');
		$this->db->where('facilities.FacilityNumber',$ninnumber);
	    $query = $this->db->get();
	    if($query->num_rows()>0){
			$dataFetched=$query->row_array();
			$dataresult['FacilityID']=$dataFetched['FacilityID'];
	    }
	    
	    $dataget=array();
		$url='https://nin.nhp.gov.in/api/facilities?api-key=AIkhSyD878mxnps32aCUQSOQXnxzc0PWVQsRkxq&nin_to_hfi='.$ninnumber;
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true); 
		$output=curl_exec($ch);
		$data=json_decode($output,true);
		curl_close($ch);
		if(isset($data['message']['status']) && $data['message']['status']=='success'){
			if(isset($data['result']['total_records']) && $data['result']['total_records']==1){
			  	// type check start
			  	$this->db->select('TypeDetailID');
			    $this->db->from('typedetail');
			    $this->db->where('TypeMasterID','4');
			    $this->db->where('TypeDetailCode',$data['data'][0]['phc_chc_type']);
			    $this->db->order_by('TypeDetailID', 'DESC');
			    $query = $this->db->get();
				if($query -> num_rows()>=1){
					$result = $query->row_array();
					$TypeDetailID=$result['TypeDetailID'];
				} else {
					$inserData=array(
						'TypeMasterID'=>'4',
						'TypeDetailCode'=>$data['data'][0]['phc_chc_type'],
						'TypeDetailLogicalCode'=>$data['data'][0]['phc_chc_type'],
						'Sequence'=>'1',
						'IsActive'=>'1'
					);
					if($this->db->insert('typedetail', $inserData)){
						$TypeDetailIDTypeDetailID=$this->db->insert_id();
					}
				}
				// type check end
			  	// states check start
			  	$stateCode=preg_replace('/[^A-Za-z0-9]/', '', trim($data['data'][0]['state_name']));
			  	$this->db->select('StateID');
			    $this->db->from('states');
			    $this->db->where('StateCode',$stateCode);
			    $query = $this->db->get();
				if($query -> num_rows()>=1){
					$result = $query->row_array();
					$StateID=$result['StateID'];
				} else {
					$typesFac=array(
						'CountryID'=>'1',
						'StateName'=>$data['data'][0]['state_name'],
						'StateCode'=>$stateCode,
						'ehr_code'=>$data['data'][0]['phc_chc_type'],
						'mapCode'=>'',
						'FacilityNum'=>0,
						'IsActive'=>'1'
					);
					if($this->db->insert('states', $inserData)){
						$StateID=$this->db->insert_id();
					}
				}
				// states check end
			  	// district check start
			  	$districtCode=preg_replace('/[^A-Za-z0-9]/', '', trim($data['data'][0]['district_name']));
			  	$this->db->select('DistrictID');
			    $this->db->from('district');
			    $this->db->where('DistrictCode',$districtCode);
			    $query = $this->db->get();
				if($query -> num_rows()>=1){
					$result = $query->row_array();
					$DistrictID=$result['DistrictID'];
				} else {
					$typesFac=array(
						'CountryID'=>'1',
						'DistrictName'=>$data['data'][0]['district_name'],
						'StateID'=>$StateID,
						'DistrictCode'=>$DistrictCode,
						'CensusCode'=>'',
						'IsHighPriority'=>0,
						'IsActive'=>'1'
					);
					if($this->db->insert('district', $inserData)){
						$DistrictID=$this->db->insert_id();
					}
				}
				// district check end
				$dataresult['FacilityNumber']=$ninnumber;
				$dataresult['FacilityName']=$data['data'][0]['hfi_name'];
				$dataresult['StateID']=$StateID;
				$dataresult['StateName']=$data['data'][0]['state_name'];
				$dataresult['DistrictID']=$DistrictID;
				$dataresult['DistrictName']=$data['data'][0]['district_name'];
				$dataresult['FacilityTypeDetailID']=$TypeDetailID;
				$dataresult['TypeDetailCode']=$data['data'][0]['phc_chc_type'];
				$dataresult['Latitude']=$data['data'][0]['latitude'];
				$dataresult['Longitude']=$data['data'][0]['longitude'];
				$dataresult['Altitude']=$data['data'][0]['altitude'];
				$dataresult['Address']=$data['data'][0]['house_number'].' '.$data['data'][0]['street'].' '.$data['data'][0]['landmark'].' '.$data['data'][0]['locality'];
				$dataresult['PinCode']=$data['data'][0]['pincode'];
				$dataresult['landLine']=$data['data'][0]['landline_number'];
			}
		} else {
			// no data get from api
		}
		return $dataresult;
    }
    function addupdatefacilitydetails($data){
    	$response=array();
    	if(isset($data['FacilityID']) && $data['FacilityID']>0){
			$dataUpdate=array(
				'FacilityName'=>$data['FacilityName'],
				'FacilityTypeDetailID'=>$data['FacilityTypeDetailID'],
				'Address'=>$data['Address'],
				'StateID'=>$data['landLine'],
				'DistrictID'=>$data['landLine'],
				'PinCode'=>$data['PinCode'],
				'landLine'=>$data['landLine'],
				'Longitude'=>$data['Longitude'],
				'Latitude'=>$data['Latitude'],
				'Altitude'=>$data['Altitude'],
				'services'=>$data['services'],
				
			);
			$this->db->where('FacilityNumber', $data['FacilityNumber']);
			if ($this->db->update('facilities', $dataUpdate)=== FALSE){
	            $response['code'] = '11';
	            $response['msg'] = $this->config->item('errCodes')[11];
			} else {
	            $response['code'] = '0';
	            $response['msg'] = $this->config->item('errCodes')[27];
			}
    	} else {
			$dataUpdate=array(
				'FacilityName'=>$data['FacilityName'],
				'FacilityNumber'=>$data['FacilityNumber'],
				'FacilityTypeDetailID'=>$data['FacilityTypeDetailID'],
				'Address'=>$data['Address'],
				'StateID'=>$data['StateID'],
				'DistrictID'=>$data['DistrictID'],
				'PinCode'=>$data['PinCode'],
				'landLine'=>$data['landLine'],
				'Longitude'=>$data['Longitude'],
				'Latitude'=>$data['Latitude'],
				'Altitude'=>$data['Altitude'],
				'services'=>$data['services'],
				'IsActive'=>1
			);
			$this->db->insert('facilities', $dataUpdate);
			$facilityID=$this->db->insert_id();
			if($facilityID>0){
	            $response['code'] = '0';
	            $response['msg'] = $this->config->item('errCodes')[0];
			} else {
	            $response['code'] = '11';
	            $response['msg'] = $this->config->item('errCodes')[11];
			}
    	}
    	return $response;
    }
	function facilitytype($facilitytype){
	  	$this->db->select('TypeDetailID');
	    $this->db->from('typedetail');
	    $this->db->where('TypeMasterID',4);
	    $this->db->where('IsActive',1);
	    $this->db->where('TypeDetailCode',$facilitytype);
	    $query = $this->db->get();
	    if($query->num_rows()>0){
	    	return array(
	    		'code'=>16,
	    		'msg'=>'Facility Type already exist'
	    	);
	    } else {
			$typesFac=array(
				'TypeMasterID'=>'4',
				'TypeDetailCode'=>$facilitytype,
				'TypeDetailLogicalCode'=>$facilitytype,
				'Sequence'=>'1',
				'IsActive'=>'1'
			);
			$this->db->insert('typedetail', $typesFac);
	    	return array(
	    		'code'=>'0',
	    		'msg'=>'Data saved successfully'
	    	);
	    }
	}
	function getfacilityType(){
	  	$this->db->select('TypeDetailID,TypeDetailCode');
	    $this->db->from('typedetail');
	    $this->db->where('TypeMasterID',4);
	    $this->db->where('IsActive',1);
	    $this->db->order_by('TypeDetailCode',1);
	    $query = $this->db->get();
	    if($query->num_rows()>0){
	    	$res=$query->result_array();
	    } else {
			$res=array();
		}
		return $res;
	}
	function facility_profile_check($facilityUserID){
		$this->session->set_userdata('IsProfileUpdated',1);
	    $this->db->select('facilities.FacilityID,facilities.services,facilities.FacilityName,facilities.FacilityNumber,facilities.Latitude,facilities.Longitude,facilities.Altitude,facilities.Address,facilities.PinCode,facilities.Address,facilities.landLine,facilities.FacilityTypeDetailID,usermapping.UserID,district.DistrictID,district.DistrictName,states.StateID,states.StateName,typedetail.TypeDetailCode');
	    $this->db->from('usermapping');
	    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
	    $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'inner');
	    $this->db->join('states', 'facilities.StateID=states.StateID', 'inner');
	    $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');	    
	    $this->db->where('usermapping.UserID',$facilityUserID);
	    $query = $this->db->get();
	    if(empty($query->num_rows())){
	    	$this->session->set_userdata('IsProfileUpdated', 0);
	    } else {		
		    $this->db->select('incharge.*');
		    $this->db->from('users');
		    $this->db->join('incharge', "users.UserID=incharge.UserID AND incharge.TypeDetailID=438", 'inner');
		    $this->db->where('users.UserID',$facilityUserID);
		    $this->db->where('incharge.IsActive','1');
		    $queryMain = $this->db->get();
		    if(empty($queryMain->num_rows())){
		    	$this->session->set_userdata('IsProfileUpdated', 0);
		    } else {
		    	$dataMain=$queryMain->row_array();
		    	if(empty($dataMain['FirstName']) || empty($dataMain['Mobile']) || empty($dataMain['Email']) ){
	    			$this->session->set_userdata('IsProfileUpdated', 0);
	    		}
		    }
			$data=$query->row_array();
	    	if(empty($data['FacilityNumber']) || empty($data['Latitude']) || empty($data['Longitude']) || empty($data['Address']) || empty($data['PinCode']) || empty($data['FacilityTypeDetailID']) || empty($data['services'])  ){
	    		$this->session->set_userdata('IsProfileUpdated', 0);
	    	}
	    }
	}

}