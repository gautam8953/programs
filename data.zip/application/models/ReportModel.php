<?php

class ReportModel extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	function checklistData($userId,$roleName,$search){
/* logic: get all facility latest assessment and loop through it.
in loop get latest record and another latest of different surveyID of same assesment type(baseline,otherline)
if elegible then show green all 
*/
        $data = array();
        $col = array(
            0 => 'FacilityName',
        );
		$where='';
        if(!empty($search['search']['value'])){
            $searchString=trim($search['search']['value']);
            $where.=' AND f.FacilityName like "%'.$searchString.'%"';
        }
		if(isset($search['search_state']) && !empty($search['search_state'])){
			$where.=' AND f.StateID='.$search['search_state'];
		}
		if(isset($search['search_district']) && !empty($search['search_district'])){
			$where.=' AND f.DistrictID='.$search['search_district'];
		}
		if(isset($search['search_facility']) && !empty($search['search_facility'])){
			$where.=' AND um.UserID='.$search['search_facility'];
		}
		if(isset($search['search_typeFacility']) && !empty($search['search_typeFacility'])){
			$search_typeFacility=str_replace('-',',', $search['search_typeFacility']);
			$where.=' AND f.FacilityName like "%'.trim($search_typeFacility).'%"';
		}
        if ($roleName == 'State') {
            $MappedState = $this->session->userdata('MappedState');
            if ($MappedState != '') {
                //$MappedStateArray = explode(",", $MappedState);
                //print_r($MappedStateArray);
                $where.=' AND f.StateID IN('.$MappedState.')';
                //$this->db->where_in('f.StateID', $MappedStateArray);
            }
        } else if ($roleName == 'District') {
            $MappedDistrict = $this->session->userdata('MappedDistrict');
            if ($MappedDistrict != '') {
                //$MappedDistrictArray = explode(",", $MappedDistrict);
                $where.=' AND f.DistrictID IN('.$MappedDistrict.')';
                //$this->db->where_in('f.DistrictID', $MappedDistrictArray);
            }
        } 
        else if ($roleName == 'Facility') {
            $userID = $this->session->userdata('UserID');
            //$this->db->where('um.UserID', $userID);
            $where.=' AND um.UserID ='.$userId;
        }
		$sqlTot="SELECT f.FacilityName,um.UserID,max(a.AnswerID) as ansId
from usermapping as um
INNER JOIN facilities as f ON(f.FacilityID=um.FacilityID AND um.FacilityID>0)
INNER JOIN answer as a on(a.UserID=um.UserID AND a.SurveyStatus='1')
WHERE 1 AND um.FacilityID>'0' ".$where."
GROUP BY a.UserID";
//echo "<br>";
		$queryTot =$this->db->query($sqlTot,NULL);
		$sql="SELECT f.FacilityName,um.UserID,max(a.AnswerID) as ansId
from usermapping as um
INNER JOIN facilities as f ON(f.FacilityID=um.FacilityID AND um.FacilityID>0)
INNER JOIN answer as a on(a.UserID=um.UserID AND a.SurveyStatus='1' AND a.IsActive='1')
WHERE 1 AND um.FacilityID>'0' ".$where."
GROUP BY a.UserID
order by ".$col[$search['order'][0]['column']]." ".$search['order'][0]['dir']." 
limit ".$search['start'].",".$search['length']."
";
		$query =$this->db->query($sql,NULL);
		$cnt=$search['start'];
		foreach ($query->result_array() as $key => $value) {
			$sqlIn="SELECT a.answerId,a.surveyID,a.clientScore,c.CategoryCode,s.SubCategoryCode,count(q.QuestionID) as quesTot,sum(ad.Answer) as answer
FROM `answer` as a
INNER JOIN answerdetail ad on(a.AnswerId=ad.AnswerID AND ad.IsActive='1')
INNER JOIN question q on(ad.QuestionID=q.QuestionID)
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) 
INNER join category c on (s.CategoryID=c.CategoryID) 
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
WHERE a.AnswerId='".$value['ansId']."'
GROUP BY s.SubCategoryCode
UNION 
SELECT a1.AnswerID,a1.surveyID,a1.clientScore,c.CategoryCode,s.SubCategoryCode,count(q.QuestionID) as quesTot,sum(ad.Answer) as answer
FROM `answer` as a
LEFT JOIN answer as a1 on(a.userID=a1.UserID AND a1.SurveyStatus='1' AND a.Sequence=a1.Sequence AND a.surveyID<>a1.SurveyID AND a1.IsActive='1' )
INNER JOIN answerdetail ad on(a1.AnswerId=ad.AnswerID AND ad.IsActive='1')
INNER JOIN question q on(ad.QuestionID=q.QuestionID)
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) 
INNER join category c on (s.CategoryID=c.CategoryID) 
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
WHERE a.AnswerId='".$value['ansId']."'
GROUP BY s.SubCategoryCode";
			$queryIn =$this->db->query($sqlIn,NULL);
			$lr=$ot=array();
			$lrQuesTot=$otQuesTot=$lrAnsTot=$otAnsTot=$lrPass=$otPass=0;
			foreach ($queryIn->result_array() as $keyIn => $valueIn) {				
				if(trim($valueIn['surveyID'])=='1'){
					if(trim($valueIn['SubCategoryCode'])=='Standard B3'){
						$lr['b3']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E18'){
						$lr['e18']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E19'){
						$lr['e19']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(!isset($lr['clientScore'])){
						if($valueIn['clientScore']==''){
							$lr['clientScore']='NA';
						} else {
							$lr['clientScore']=$valueIn['clientScore'];							
						}
					}
					if(isset($lr['cat'][$valueIn['CategoryCode']]['quesTot'])){
						$lr['cat'][$valueIn['CategoryCode']]['quesTot']+=$valueIn['quesTot'];
					} else {
						$lr['cat'][$valueIn['CategoryCode']]['quesTot']=$valueIn['quesTot'];
					}
					if(isset($lr['cat'][$valueIn['CategoryCode']]['answer'])){
						$lr['cat'][$valueIn['CategoryCode']]['answer']+=$valueIn['answer'];
					} else {
						$lr['cat'][$valueIn['CategoryCode']]['answer']=$valueIn['answer'];
					}
					/*if($valueIn['CategoryCode']=='G'){
						$lr['subcat'][$valueIn['SubCategoryCode']]=array('quesTot'=>$valueIn['quesTot'],'answer'=>$valueIn['answer']);
					}*/
					
					$lrQuesTot+=$valueIn['quesTot'];
					$lrAnsTot+=$valueIn['answer'];
				} else {
					if(trim($valueIn['SubCategoryCode'])=='Standard B3'){
						$ot['b3']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E18'){
						$ot['e18']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E19'){
						$ot['e19']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(!isset($ot['clientScore'])){
						if($valueIn['clientScore']==''){
							$ot['clientScore']='NA';
						} else {
							$ot['clientScore']=$valueIn['clientScore'];							
						}
					}
					if(isset($ot['cat'][$valueIn['CategoryCode']]['quesTot'])){
						$ot['cat'][$valueIn['CategoryCode']]['quesTot']+=$valueIn['quesTot'];
					} else {
						$ot['cat'][$valueIn['CategoryCode']]['quesTot']=$valueIn['quesTot'];
					}
					if(isset($ot['cat'][$valueIn['CategoryCode']]['answer'])){
						$ot['cat'][$valueIn['CategoryCode']]['answer']+=$valueIn['answer'];
					} else {
						$ot['cat'][$valueIn['CategoryCode']]['answer']=$valueIn['answer'];
					}
					/*if($valueIn['CategoryCode']=='G'){
						$ot['subcat'][$valueIn['SubCategoryCode']]=array('quesTot'=>$valueIn['quesTot'],'answer'=>$valueIn['answer']);
					}*/
					$otQuesTot+=$valueIn['quesTot'];
					$otAnsTot+=$valueIn['answer'];
				}
			}
			// query for cat4 start
			$sqlIn="(SELECT a.answerId,ad.Answer,a.surveyID,c.CategoryCode,s.SubCategoryCode,q.QuestionID,q.ParentID,q.Reference,q.Statement,q.Checkpoint
FROM `answer` as a INNER JOIN answerdetail ad on(a.AnswerId=ad.AnswerID AND ad.IsActive='1') INNER JOIN question q on(ad.QuestionID=q.QuestionID) INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) INNER join category c on (s.CategoryID=c.CategoryID) INNER JOIN survey on(c.SurveyID=survey.SurveyID) WHERE a.AnswerId='".$value['ansId']."' AND c.CategoryCode='G' ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC)  
UNION 
(SELECT a1.AnswerID,ad.Answer,a1.surveyID,c.CategoryCode,s.SubCategoryCode,q.QuestionID,q.ParentID,q.Reference,q.Statement,q.Checkpoint 
FROM `answer` as a LEFT JOIN answer as a1 on(a.userID=a1.UserID AND a1.SurveyStatus='1' AND a.Sequence=a1.Sequence AND a.surveyID<>a1.SurveyID AND a1.IsActive='1' ) INNER JOIN answerdetail ad on(a1.AnswerId=ad.AnswerID AND ad.IsActive='1') INNER JOIN question q on(ad.QuestionID=q.QuestionID) INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) INNER join category c on (s.CategoryID=c.CategoryID) INNER JOIN survey on(c.SurveyID=survey.SurveyID) WHERE a.AnswerId='".$value['ansId']."' AND c.CategoryCode='G' ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC)";
			$queryIn =$this->db->query($sqlIn,NULL);			
			foreach ($queryIn->result_array() as $keyIn => $valueIn) {				
				if(trim($valueIn['surveyID'])=='1'){
					if($valueIn['ParentID']=='0'){
						$ref=$valueIn['QuestionID'];
						$lr['subcat'][$ref]['Reference']=$valueIn['Reference'];
					} else {
						$ref=$valueIn['ParentID'];
					}
					if(isset($lr['subcat'][$ref]['Answer'])){
						$lr['subcat'][$ref]['Answer']+=$valueIn['Answer'];
					} else {
						$lr['subcat'][$ref]['Answer']=$valueIn['Answer'];
					}
					if(isset($lr['subcat'][$ref]['quesTot'])){
						$lr['subcat'][$ref]['quesTot']+=1;
					} else {
						$lr['subcat'][$ref]['quesTot']=1;
					}
				} else {
					if($valueIn['ParentID']=='0'){
						$ref=$valueIn['QuestionID'];
						$ot['subcat'][$ref]['Reference']=$valueIn['Reference'];
					} else {
						$ref=$valueIn['ParentID'];
					}
					if(isset($ot['subcat'][$ref]['Answer'])){
						$ot['subcat'][$ref]['Answer']+=$valueIn['Answer'];
					} else {
						$ot['subcat'][$ref]['Answer']=$valueIn['Answer'];
					}
					if(isset($ot['subcat'][$ref]['quesTot'])){
						$ot['subcat'][$ref]['quesTot']+=1;
					} else {
						$ot['subcat'][$ref]['quesTot']=1;
					}
				}
			}
			// query for cat4 end


			//echo "<pre>"; print_r($lr['subcat']); print_r($ot['subcat']); echo "</pre>";
			$cnt_data=++$cnt;
            $subdata = array();
            $subdata1 = array();
            if(empty($lr)){
            	$subdata=array_fill(0, 12, '<span class="normal_font" >NA</span>');
	            $subdata[0] = $cnt_data.'.1';
	            $subdata[1] = $value['FacilityName'];
	            $subdata[2] = 'LR';
            } else {
				$lrScore=(int)(($lrAnsTot/($lrQuesTot*2))*100);
				$lrb3=isset($lr['b3'])?$lr['b3']:0;
				$lre18=isset($lr['e18'])?$lr['e18']:0;
				$lre19=isset($lr['e19'])?$lr['e19']:0;
				$lrclientScore=isset($lr['clientScore'])?$lr['clientScore']:0;
				if($lrScore>=65){
					$lrPass++;
					$c1textLR='<span class="success_font" >'.$lrScore.'</span>';
				} else {
					$c1textLR='<span class="error_font" >'.$lrScore.'</span>';
				}
				if(empty($lr['cat'])){
					$c2textLR='';	
				} else {
					$lrCrt='1';
					$c2textLR='<table border="1" class="inner-table1" width="100%"><tr>';
					foreach ($lr['cat'] as $keyCat => $valueCat) {
						$c2textLR.='<td>'.$keyCat.'</td>';
					}
					$c2textLR.='</tr>';
					foreach ($lr['cat'] as $keyCat => $valueCat) {
						$percent=(int)round(($valueCat['answer']/($valueCat['quesTot']*2))*100);
						if($percent>=65){
							$percentText='<span class="success_font" >'.$percent.'%</span>';
						} else {
							$lrCrt='0';
							$percentText='<span class="error_font" >'.$percent.'%</span>';
						}
						$c2textLR.='<td>'.$percentText.'</td>';
					}
					$c2textLR.='</tr><table border="1" width="100%">';
					if($lrCrt=='1'){
						$lrPass++;
					}
				}
				if($lrb3>=65 && $lre18>=65 && $lre19>=65){
					$lrPass++;
					$c3textLR1='<span class="success_font" >'.$lrb3.'</span>';
					$c3textLR2='<span class="success_font" >'.$lre18.'</span>';
					$c3textLR3='<span class="success_font" >'.$lre19.'</span>';
				} else {
					$c3textLR1='<span class="error_font" >'.$lrb3.'</span>';
					$c3textLR2='<span class="error_font" >'.$lre18.'</span>';
					$c3textLR3='<span class="error_font" >'.$lre19.'</span>';
				}
				if(empty($lr['subcat'])){
					$c4textLR='';	
				} else {
					$lrCrt='1';$totLrC4=0;
					foreach ($lr['subcat'] as $keysubcat => $valuesubcat) {
						$percent=(int)(($valuesubcat['Answer']*100)/($valuesubcat['quesTot']*2));
						if($percent>45){
							$totLrC4++;
						} else {
							$lrCrt='0';
						}
					}					
					if($lrCrt=='1'){
						$lrPass++;
						$c4textLR='<span class="success_font" >'.$totLrC4.'/'.count($lr['subcat']).'</span>';
					} else {
						$c4textLR='<span class="error_font" >'.$totLrC4.'/'.count($lr['subcat']).'</span>';
					}
					//$c4textLR='<span class="success_font" >'.$totLrC4.'/</span><span class="error_font" >'.count($lr['subcat']).'</span>';
				}				
				if($lrclientScore>=65){
					$lrPass++;
					$c5textLR='<span class="success_font" >'.$lrclientScore.'</span>';
				} else {
					$c5textLR='<span class="error_font" >'.$lrclientScore.'</span>';
				}				
				if($lrPass==5){
					$lrPassText='<span class="success_font" >'.$lrPass.'</span>';
				} else {
					$lrPassText='<span class="error_font" >'.$lrPass.'</span>';
				}
				$subdata[] = $cnt_data.'.1';
	            $subdata[] = $value['FacilityName'];
	            $subdata[] = 'LR';
	            $subdata[] = $lrScore;
	            $subdata[] = $c1textLR;
	            $subdata[] = $c2textLR;
	            $subdata[] = $c3textLR1;
	            $subdata[] = $c3textLR2;
	            $subdata[] = $c3textLR3;
	            $subdata[] = $c4textLR;
	            $subdata[] = $c5textLR;
	            $subdata[] = $lrPassText;            	
            }
            if(empty($ot)){
            	$subdata1=array_fill(0, 12, '<span class="normal_font" >NA</span>');
            	$subdata1[0] = $cnt_data.'.2';
	            $subdata1[1] = $value['FacilityName'];
	            $subdata1[2] = 'OT';
            } else {
            	$otScore=(int)(($otAnsTot/($otQuesTot*2))*100);
				$otb3=isset($ot['b3'])?$ot['b3']:0;
				$ote18=isset($ot['e18'])?$ot['e18']:0;
				$ote19=isset($ot['e19'])?$ot['e19']:0;
				$otclientScore=isset($ot['clientScore'])?$ot['clientScore']:0;
				if($otScore>=65){
					$otPass++;
					$c1textOT='<span class="success_font" >'.$otScore.'</span>';
				} else {
					$c1textOT='<span class="error_font" >'.$otScore.'</span>';
				}
				if(empty($ot['cat'])){
					$c2textOT='';	
				} else {
					$otCrt='1';
					$c2textOT='<table border="1" class="inner-table1" width="100%"><tr>';
					foreach ($ot['cat'] as $keyCat => $valueCat) {
						$c2textOT.='<td>'.$keyCat.'</td>';
					}
					$c2textOT.='</tr>';
					foreach ($ot['cat'] as $keyCat => $valueCat) {
						$percent=(int)round(($valueCat['answer']/($valueCat['quesTot']*2))*100);
						if($percent>=65){
							$percentText='<span class="success_font" >'.$percent.'%</span>';
						} else {
							$otCrt='0';
							$percentText='<span class="error_font" >'.$percent.'%</span>';
						}
						$c2textOT.='<td>'.$percentText.'</td>';
					}
					$c2textOT.='</tr><table border="1" width="100%">';
					if($otCrt=='1'){
						$otPass++;
					}
				}
				if($otb3>=65 && $ote18>=65 && $ote19>=65){
					$otPass++;
					$c3textOT1='<span class="success_font" >'.$otb3.'</span>';
					$c3textOT2='<span class="success_font" >'.$ote18.'</span>';
					$c3textOT3='<span class="success_font" >'.$ote19.'</span>';
				} else {
					$c3textOT1='<span class="error_font" >'.$otb3.'</span>';
					$c3textOT2='<span class="error_font" >'.$ote18.'</span>';
					$c3textOT3='<span class="error_font" >'.$ote19.'</span>';
				}
				if(empty($ot['subcat'])){
					$c4textOT='';	
				} else {
					$otCrt='1';$totOtC4=0;
					foreach ($ot['subcat'] as $keysubcat => $valuesubcat) {
						$percent=(int)(($valuesubcat['Answer']*100)/($valuesubcat['quesTot']*2));
						if($percent>45){
							$totOtC4++;
						} else {
							$otCrt='0';
						}
					}					
					if($otCrt=='1'){
						$otPass++;
						$c4textOT='<span class="success_font" >'.$totOtC4.'/'.count($ot['subcat']).'</span>';
					} else {
						$c4textOT='<span class="error_font" >'.$totOtC4.'/'.count($ot['subcat']).'</span>';
					}
				}
				if($otclientScore>=65){
					$otPass++;
					$c5textOT='<span class="success_font" >'.$otclientScore.'</span>';
				} else {
					$c5textOT='<span class="error_font" >'.$otclientScore.'</span>';
				}
				if($otPass==5){
					$otPasstext='<span class="success_font" >'.$otPass.'</span>';
				} else {
					$otPasstext='<span class="error_font" >'.$otPass.'</span>';
				}
				$subdata1[] = $cnt_data.'.2';
	            $subdata1[] = $value['FacilityName'];
	            $subdata1[] = 'OT';
	            $subdata1[] = $otScore;
	            $subdata1[] = $c1textOT;
	            $subdata1[] = $c2textOT;
	            $subdata1[] = $c3textOT1;
	            $subdata1[] = $c3textOT2;
	            $subdata1[] = $c3textOT3;
	            $subdata1[] = $c4textOT;
	            $subdata1[] = $c5textOT;
	            $subdata1[] = $otPasstext;            	
            }
            $data[] = $subdata;
            $data[] = $subdata1;
		}

		return array('totalData'=>$queryTot->num_rows(),'totalFilter'=>$queryTot->num_rows(),'data'=>$data);
	}
	function checklistDataApp($userId,$roleName,$search){
        $data = array();
        $col = array(
            0 => 'FacilityName',
        );
		$where='';
        if(!empty($search['search']['value'])){
            $searchString=trim($search['search']['value']);
            $where.=' AND f.FacilityName like "%'.$searchString.'%"';
        }
		if(isset($search['search_state']) && !empty($search['search_state'])){
			$where.=' AND f.StateID='.$search['search_state'];
		}
		if(isset($search['search_district']) && !empty($search['search_district'])){
			$where.=' AND f.DistrictID='.$search['search_district'];
		}
		if(isset($search['search_facility']) && !empty($search['search_facility'])){
			$where.=' AND um.UserID='.$search['search_facility'];
		}		
		if(isset($search['search_typeFacility']) && !empty($search['search_typeFacility'])){
			$search_typeFacility=str_replace('-',',', $search['search_typeFacility']);
			$where.=' AND f.FacilityName like "%'.trim($search_typeFacility).'%"';
		}
        if ($roleName == 'State') {
            $MappedState = $search['MappedState'];
            if ($MappedState != '') {
                //$MappedStateArray = explode(",", $MappedState);
                //print_r($MappedStateArray);
                $where.=' AND f.StateID IN('.$MappedState.')';
                //$this->db->where_in('f.StateID', $MappedStateArray);
            }
        } else if ($roleName == 'District') {
            $MappedDistrict = $search['MappedDistrict'];
            if ($MappedDistrict != '') {
                //$MappedDistrictArray = explode(",", $MappedDistrict);
                $where.=' AND f.DistrictID IN('.$MappedDistrict.')';
                //$this->db->where_in('f.DistrictID', $MappedDistrictArray);
            }
        } 
        else if ($roleName == 'Facility') {
            $userID = $this->session->userdata('UserID');
            //$this->db->where('um.UserID', $userID);
            $where.=' AND um.UserID ='.$userId;
        }
		$sqlTot="SELECT f.FacilityName,um.UserID,max(a.AnswerID) as ansId
from usermapping as um
INNER JOIN facilities as f ON(f.FacilityID=um.FacilityID AND um.FacilityID>0)
INNER JOIN answer as a on(a.UserID=um.UserID AND a.SurveyStatus='1')
WHERE 1 AND um.FacilityID>'0' ".$where."
GROUP BY a.UserID";
//echo "<br>";
		$queryTot =$this->db->query($sqlTot,NULL);
		$sql="SELECT f.FacilityName,um.UserID,max(a.AnswerID) as ansId
from usermapping as um
INNER JOIN facilities as f ON(f.FacilityID=um.FacilityID AND um.FacilityID>0)
INNER JOIN answer as a on(a.UserID=um.UserID AND a.SurveyStatus='1' AND a.IsActive='1')
WHERE 1 AND um.FacilityID>'0' ".$where."
GROUP BY a.UserID
order by f.FacilityName
";
		$query =$this->db->query($sql,NULL);
		foreach ($query->result_array() as $key => $value) {
			$sqlIn="SELECT a.answerId,a.surveyID,a.clientScore,c.CategoryCode,s.SubCategoryCode,count(q.QuestionID) as quesTot,sum(ad.Answer) as answer
FROM `answer` as a
INNER JOIN answerdetail ad on(a.AnswerId=ad.AnswerID AND ad.IsActive='1')
INNER JOIN question q on(ad.QuestionID=q.QuestionID)
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) 
INNER join category c on (s.CategoryID=c.CategoryID) 
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
WHERE a.AnswerId='".$value['ansId']."'
GROUP BY s.SubCategoryCode
UNION 
SELECT a1.AnswerID,a1.surveyID,a1.clientScore,c.CategoryCode,s.SubCategoryCode,count(q.QuestionID) as quesTot,sum(ad.Answer) as answer
FROM `answer` as a
LEFT JOIN answer as a1 on(a.userID=a1.UserID AND a1.SurveyStatus='1' AND a.Sequence=a1.Sequence AND a.surveyID<>a1.SurveyID AND a1.IsActive='1' )
INNER JOIN answerdetail ad on(a1.AnswerId=ad.AnswerID AND ad.IsActive='1')
INNER JOIN question q on(ad.QuestionID=q.QuestionID)
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) 
INNER join category c on (s.CategoryID=c.CategoryID) 
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
WHERE a.AnswerId='".$value['ansId']."'
GROUP BY s.SubCategoryCode";
			$queryIn =$this->db->query($sqlIn,NULL);
			$lr=$ot=array();
			$lrQuesTot=$otQuesTot=$lrAnsTot=$otAnsTot=$lrPass=$otPass=0;
			foreach ($queryIn->result_array() as $keyIn => $valueIn) {				
				if(trim($valueIn['surveyID'])=='1'){
					if(trim($valueIn['SubCategoryCode'])=='Standard B3'){
						$lr['b3']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E18'){
						$lr['e18']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E19'){
						$lr['e19']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(!isset($lr['clientScore'])){
						if($valueIn['clientScore']==''){
							$lr['clientScore']='NA';
						} else {
							$lr['clientScore']=$valueIn['clientScore'];							
						}
					}
					if(isset($lr['cat'][$valueIn['CategoryCode']]['quesTot'])){
						$lr['cat'][$valueIn['CategoryCode']]['quesTot']+=$valueIn['quesTot'];
					} else {
						$lr['cat'][$valueIn['CategoryCode']]['quesTot']=$valueIn['quesTot'];
					}
					if(isset($lr['cat'][$valueIn['CategoryCode']]['answer'])){
						$lr['cat'][$valueIn['CategoryCode']]['answer']+=$valueIn['answer'];
					} else {
						$lr['cat'][$valueIn['CategoryCode']]['answer']=$valueIn['answer'];
					}
					/*if($valueIn['CategoryCode']=='G'){
						$lr['subcat'][$valueIn['SubCategoryCode']]=array('quesTot'=>$valueIn['quesTot'],'answer'=>$valueIn['answer']);
					}*/
					
					$lrQuesTot+=$valueIn['quesTot'];
					$lrAnsTot+=$valueIn['answer'];
				} else {
					if(trim($valueIn['SubCategoryCode'])=='Standard B3'){
						$ot['b3']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E18'){
						$ot['e18']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E19'){
						$ot['e19']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(!isset($ot['clientScore'])){
						if($valueIn['clientScore']==''){
							$ot['clientScore']='NA';
						} else {
							$ot['clientScore']=$valueIn['clientScore'];							
						}
					}
					if(isset($ot['cat'][$valueIn['CategoryCode']]['quesTot'])){
						$ot['cat'][$valueIn['CategoryCode']]['quesTot']+=$valueIn['quesTot'];
					} else {
						$ot['cat'][$valueIn['CategoryCode']]['quesTot']=$valueIn['quesTot'];
					}
					if(isset($ot['cat'][$valueIn['CategoryCode']]['answer'])){
						$ot['cat'][$valueIn['CategoryCode']]['answer']+=$valueIn['answer'];
					} else {
						$ot['cat'][$valueIn['CategoryCode']]['answer']=$valueIn['answer'];
					}
					/*if($valueIn['CategoryCode']=='G'){
						$ot['subcat'][$valueIn['SubCategoryCode']]=array('quesTot'=>$valueIn['quesTot'],'answer'=>$valueIn['answer']);
					}*/
					$otQuesTot+=$valueIn['quesTot'];
					$otAnsTot+=$valueIn['answer'];
				}
			}
			// query for cat4 start
			$sqlIn="(SELECT a.answerId,ad.Answer,a.surveyID,c.CategoryCode,s.SubCategoryCode,q.QuestionID,q.ParentID,q.Reference,q.Statement,q.Checkpoint
FROM `answer` as a INNER JOIN answerdetail ad on(a.AnswerId=ad.AnswerID AND ad.IsActive='1') INNER JOIN question q on(ad.QuestionID=q.QuestionID) INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) INNER join category c on (s.CategoryID=c.CategoryID) INNER JOIN survey on(c.SurveyID=survey.SurveyID) WHERE a.AnswerId='".$value['ansId']."' AND c.CategoryCode='G' ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC)  
UNION 
(SELECT a1.AnswerID,ad.Answer,a1.surveyID,c.CategoryCode,s.SubCategoryCode,q.QuestionID,q.ParentID,q.Reference,q.Statement,q.Checkpoint 
FROM `answer` as a LEFT JOIN answer as a1 on(a.userID=a1.UserID AND a1.SurveyStatus='1' AND a.Sequence=a1.Sequence AND a.surveyID<>a1.SurveyID AND a1.IsActive='1' ) INNER JOIN answerdetail ad on(a1.AnswerId=ad.AnswerID AND ad.IsActive='1') INNER JOIN question q on(ad.QuestionID=q.QuestionID) INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) INNER join category c on (s.CategoryID=c.CategoryID) INNER JOIN survey on(c.SurveyID=survey.SurveyID) WHERE a.AnswerId='".$value['ansId']."' AND c.CategoryCode='G' ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC)";
			$queryIn =$this->db->query($sqlIn,NULL);			
			foreach ($queryIn->result_array() as $keyIn => $valueIn) {				
				if(trim($valueIn['surveyID'])=='1'){
					if($valueIn['ParentID']=='0'){
						$ref=$valueIn['QuestionID'];
						$lr['subcat'][$ref]['Reference']=$valueIn['Reference'];
					} else {
						$ref=$valueIn['ParentID'];
					}
					if(isset($lr['subcat'][$ref]['Answer'])){
						$lr['subcat'][$ref]['Answer']+=$valueIn['Answer'];
					} else {
						$lr['subcat'][$ref]['Answer']=$valueIn['Answer'];
					}
					if(isset($lr['subcat'][$ref]['quesTot'])){
						$lr['subcat'][$ref]['quesTot']+=1;
					} else {
						$lr['subcat'][$ref]['quesTot']=1;
					}
				} else {
					if($valueIn['ParentID']=='0'){
						$ref=$valueIn['QuestionID'];
						$ot['subcat'][$ref]['Reference']=$valueIn['Reference'];
					} else {
						$ref=$valueIn['ParentID'];
					}
					if(isset($ot['subcat'][$ref]['Answer'])){
						$ot['subcat'][$ref]['Answer']+=$valueIn['Answer'];
					} else {
						$ot['subcat'][$ref]['Answer']=$valueIn['Answer'];
					}
					if(isset($ot['subcat'][$ref]['quesTot'])){
						$ot['subcat'][$ref]['quesTot']+=1;
					} else {
						$ot['subcat'][$ref]['quesTot']=1;
					}
				}
			}
			// query for cat4 end
			//echo "<pre>"; print_r($lr['subcat']); print_r($ot['subcat']); echo "</pre>";
			
            $subdata = array();
            $subdata1 = array();
            if(empty($lr)){
            	//$subdata=array_fill(0, 11, '<span class="normal_font" >NA</span>');
	            $subdata['param0'] = $value['FacilityName'];
	            $subdata['param1'] = 'LR';
	            $subdata['param2'] = '<span class="normal_font" >NA</span>';
	            $subdata['param3'] = '<span class="normal_font" >NA</span>';
	            $subdata['param4'] = '<span class="normal_font" >NA</span>';
	            $subdata['param5'] = '<span class="normal_font" >NA</span>';
	            $subdata['param6'] = '<span class="normal_font" >NA</span>';
	            $subdata['param7'] = '<span class="normal_font" >NA</span>';
	            $subdata['param8'] = '<span class="normal_font" >NA</span>';
	            $subdata['param9'] = '<span class="normal_font" >NA</span>';
	            $subdata['param10'] = '<span class="normal_font" >NA</span>';
            } else {
				$lrScore=(int)(($lrAnsTot/($lrQuesTot*2))*100);
				$lrb3=isset($lr['b3'])?$lr['b3']:0;
				$lre18=isset($lr['e18'])?$lr['e18']:0;
				$lre19=isset($lr['e19'])?$lr['e19']:0;
				$lrclientScore=isset($lr['clientScore'])?$lr['clientScore']:0;
				if($lrScore>=70){
					$lrPass++;
					$c1textLR='<span class="success_font" >'.$lrScore.'</span>';
				} else {
					$c1textLR='<span class="error_font" >'.$lrScore.'</span>';
				}
				if(empty($lr['cat'])){
					$c2textLR='';	
				} else {
					$lrCrt='1';
					$c2textLR='<table border="1" width="100%"><tr>';
					foreach ($lr['cat'] as $keyCat => $valueCat) {
						$c2textLR.='<td>'.$keyCat.'</td>';
					}
					$c2textLR.='</tr>';
					foreach ($lr['cat'] as $keyCat => $valueCat) {
						$percent=(int)round(($valueCat['answer']/($valueCat['quesTot']*2))*100);
						if($percent>=70){
							$percentText='<span class="success_font" >'.$percent.'%</span>';
						} else {
							$lrCrt='0';
							$percentText='<span class="error_font" >'.$percent.'%</span>';
						}
						$c2textLR.='<td>'.$percentText.'</td>';
					}
					$c2textLR.='</tr><table border="1" width="100%">';
					if($lrCrt=='1'){
						$lrPass++;
					}
				}
				if($lrb3>=70 && $lre18>=70 && $lre19>=70){
					$lrPass++;
					$c3textLR1='<span class="success_font" >'.$lrb3.'</span>';
					$c3textLR2='<span class="success_font" >'.$lre18.'</span>';
					$c3textLR3='<span class="success_font" >'.$lre19.'</span>';
				} else {
					$c3textLR1='<span class="error_font" >'.$lrb3.'</span>';
					$c3textLR2='<span class="error_font" >'.$lre18.'</span>';
					$c3textLR3='<span class="error_font" >'.$lre19.'</span>';
				}
				if(empty($lr['subcat'])){
					$c4textLR='';	
				} else {
					$lrCrt='1';$totLrC4=0;
					foreach ($lr['subcat'] as $keysubcat => $valuesubcat) {
						$percent=(int)(($valuesubcat['Answer']*100)/($valuesubcat['quesTot']*2));
						if($percent>50){
							$totLrC4++;
						} else {
							$lrCrt='0';
						}
					}					
					if($lrCrt=='1'){
						$lrPass++;
						$c4textLR='<span class="success_font" >'.$totLrC4.'/'.count($lr['subcat']).'</span>';
					} else {
						$c4textLR='<span class="error_font" >'.$totLrC4.'/'.count($lr['subcat']).'</span>';
					}
				}				
				if($lrclientScore>=70){
					$lrPass++;
					$c5textLR='<span class="success_font" >'.$lrclientScore.'</span>';
				} else {
					$c5textLR='<span class="error_font" >'.$lrclientScore.'</span>';
				}
	            $subdata['param0'] = $value['FacilityName'];
	            $subdata['param1'] = 'LR';
	            $subdata['param2'] = $lrScore;
	            $subdata['param3'] = $c1textLR;
	            $subdata['param4'] = $c2textLR;
	            $subdata['param5'] = $c3textLR1;
	            $subdata['param6'] = $c3textLR2;
	            $subdata['param7'] = $c3textLR3;
	            $subdata['param8'] = $c4textLR;
	            $subdata['param9'] = $c5textLR;
	            $subdata['param10'] = $lrPass;            	
            }
            if(empty($ot)){
            	//$subdata1=array_fill(0, 11, '<span class="normal_font" >NA</span>');
	            //$subdata1[0] = $value['FacilityName'];
	            //$subdata1[1] = 'OT';
	            $subdata1['param0'] = $value['FacilityName'];
	            $subdata1['param1'] = 'OT';
	            $subdata1['param2'] = '<span class="normal_font" >NA</span>';
	            $subdata1['param3'] = '<span class="normal_font" >NA</span>';
	            $subdata1['param4'] = '<span class="normal_font" >NA</span>';
	            $subdata1['param5'] = '<span class="normal_font" >NA</span>';
	            $subdata1['param6'] = '<span class="normal_font" >NA</span>';
	            $subdata1['param7'] = '<span class="normal_font" >NA</span>';
	            $subdata1['param8'] = '<span class="normal_font" >NA</span>';
	            $subdata1['param9'] = '<span class="normal_font" >NA</span>';
	            $subdata1['param10'] = '<span class="normal_font" >NA</span>';
            } else {
            	$otScore=(int)(($otAnsTot/($otQuesTot*2))*100);
				$otb3=isset($ot['b3'])?$ot['b3']:0;
				$ote18=isset($ot['e18'])?$ot['e18']:0;
				$ote19=isset($ot['e19'])?$ot['e19']:0;
				$otclientScore=isset($ot['clientScore'])?$ot['clientScore']:0;
				if($otScore>=70){
					$otPass++;
					$c1textOT='<span class="success_font" >'.$otScore.'</span>';
				} else {
					$c1textOT='<span class="error_font" >'.$otScore.'</span>';
				}
				if(empty($ot['cat'])){
					$c2textOT='';	
				} else {
					$otCrt='1';
					$c2textOT='<table border="1" width="100%"><tr>';
					foreach ($ot['cat'] as $keyCat => $valueCat) {
						$c2textOT.='<td>'.$keyCat.'</td>';
					}
					$c2textOT.='</tr>';
					foreach ($ot['cat'] as $keyCat => $valueCat) {
						$percent=(int)round(($valueCat['answer']/($valueCat['quesTot']*2))*100);
						if($percent>=70){
							$percentText='<span class="success_font" >'.$percent.'%</span>';
						} else {
							$otCrt='0';
							$percentText='<span class="error_font" >'.$percent.'%</span>';
						}
						$c2textOT.='<td>'.$percentText.'</td>';
					}
					$c2textOT.='</tr><table border="1" width="100%">';
					if($otCrt=='1'){
						$otPass++;
					}
				}
				if($otb3>=70 && $ote18>=70 && $ote19>=70){
					$otPass++;
					$c3textOT1='<span class="success_font" >'.$otb3.'</span>';
					$c3textOT2='<span class="success_font" >'.$ote18.'</span>';
					$c3textOT3='<span class="success_font" >'.$ote19.'</span>';
				} else {
					$c3textOT1='<span class="error_font" >'.$otb3.'</span>';
					$c3textOT2='<span class="error_font" >'.$ote18.'</span>';
					$c3textOT3='<span class="error_font" >'.$ote19.'</span>';
				}
				if(empty($ot['subcat'])){
					$c4textOT='';	
				} else {
					$otCrt='1';$totOtC4=0;
					foreach ($ot['subcat'] as $keysubcat => $valuesubcat) {
						$percent=(int)(($valuesubcat['Answer']*100)/($valuesubcat['quesTot']*2));
						if($percent>50){
							$totOtC4++;
						} else {
							$otCrt='0';
						}
					}					
					if($otCrt=='1'){
						$otPass++;
						$c4textOT='<span class="success_font" >'.$totOtC4.'/'.count($ot['subcat']).'</span>';
					} else {
						$c4textOT='<span class="error_font" >'.$totOtC4.'/'.count($ot['subcat']).'</span>';
					}
				}
				if($otclientScore>=70){
					$otPass++;
					$c5textOT='<span class="success_font" >'.$otclientScore.'</span>';
				} else {
					$c5textOT='<span class="error_font" >'.$otclientScore.'</span>';
				}
	            $subdata1['param0'] = $value['FacilityName'];
	            $subdata1['param1'] = 'OT';
	            $subdata1['param2'] = $otScore;
	            $subdata1['param3'] = $c1textOT;
	            $subdata1['param4'] = $c2textOT;
	            $subdata1['param5'] = $c3textOT1;
	            $subdata1['param6'] = $c3textOT2;
	            $subdata1['param7'] = $c3textOT3;
	            $subdata1['param8'] = $c4textOT;
	            $subdata1['param9'] = $c5textOT;
	            $subdata1['param10'] = $otPass;            	
            }
            $data[] = $subdata;
            $data[] = $subdata1;
		}
		return array('totalData'=>$queryTot->num_rows(),'totalFilter'=>$queryTot->num_rows(),'data'=>$data,'code'=>'0','msg'=>$queryTot->num_rows().' data received');
	}

	function checklistDataNational($userId,$roleName,$search){
        $data = array();
        $col = array(
            0 => 'FacilityName',
        );
		$where='';
        if(!empty($search['search']['value'])){
            $searchString=trim($search['search']['value']);
            $where.=' AND f.FacilityName like "%'.$searchString.'%"';
        }
		if(isset($search['search_state']) && !empty($search['search_state'])){
			$where.=' AND f.StateID='.$search['search_state'];
		}
		if(isset($search['search_district']) && !empty($search['search_district'])){
			$where.=' AND f.DistrictID='.$search['search_district'];
		}
		if(isset($search['search_facility']) && !empty($search['search_facility'])){
			$where.=' AND um.UserID='.$search['search_facility'];
		}
		if(isset($search['search_typeFacility']) && !empty($search['search_typeFacility'])){
			$search_typeFacility=str_replace('-',',', $search['search_typeFacility']);
			$where.=' AND f.FacilityName like "%'.trim($search_typeFacility).'%"';
		}
        if ($roleName == 'State') {
            $MappedState = $this->session->userdata('MappedState');
            if ($MappedState != '') {
                //$MappedStateArray = explode(",", $MappedState);
                //print_r($MappedStateArray);
                $where.=' AND f.StateID IN('.$MappedState.')';
                //$this->db->where_in('f.StateID', $MappedStateArray);
            }
        } else if ($roleName == 'District') {
            $MappedDistrict = $this->session->userdata('MappedDistrict');
            if ($MappedDistrict != '') {
                //$MappedDistrictArray = explode(",", $MappedDistrict);
                $where.=' AND f.DistrictID IN('.$MappedDistrict.')';
                //$this->db->where_in('f.DistrictID', $MappedDistrictArray);
            }
        } 
        else if ($roleName == 'Facility') {
            $userID = $this->session->userdata('UserID');
            //$this->db->where('um.UserID', $userID);
            $where.=' AND um.UserID ='.$userId;
        }
		$sqlTot="SELECT f.FacilityName,um.UserID,max(a.AnswerID) as ansId
from usermapping as um
INNER JOIN facilities as f ON(f.FacilityID=um.FacilityID AND um.FacilityID>0)
INNER JOIN answer as a on(a.UserID=um.UserID AND a.SurveyStatus='1')
WHERE 1 AND um.FacilityID>'0' ".$where."
GROUP BY a.UserID";
//echo "<br>";
		$queryTot =$this->db->query($sqlTot,NULL);
		$sql="SELECT f.FacilityName,um.UserID,max(a.AnswerID) as ansId
from usermapping as um
INNER JOIN facilities as f ON(f.FacilityID=um.FacilityID AND um.FacilityID>0)
INNER JOIN answer as a on(a.UserID=um.UserID AND a.SurveyStatus='1' AND a.IsActive='1')
WHERE 1 AND um.FacilityID>'0' ".$where."
GROUP BY a.UserID
order by ".$col[$search['order'][0]['column']]." ".$search['order'][0]['dir']." 
limit ".$search['start'].",".$search['length']."
";
		$query =$this->db->query($sql,NULL);
		$cnt=$search['start'];
		foreach ($query->result_array() as $key => $value) {
			$sqlIn="SELECT a.answerId,a.surveyID,a.clientScore,c.CategoryCode,s.SubCategoryCode,count(q.QuestionID) as quesTot,sum(ad.Answer) as answer
FROM `answer` as a
INNER JOIN answerdetail ad on(a.AnswerId=ad.AnswerID AND ad.IsActive='1')
INNER JOIN question q on(ad.QuestionID=q.QuestionID)
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) 
INNER join category c on (s.CategoryID=c.CategoryID) 
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
WHERE a.AnswerId='".$value['ansId']."'
GROUP BY s.SubCategoryCode
UNION 
SELECT a1.AnswerID,a1.surveyID,a1.clientScore,c.CategoryCode,s.SubCategoryCode,count(q.QuestionID) as quesTot,sum(ad.Answer) as answer
FROM `answer` as a
LEFT JOIN answer as a1 on(a.userID=a1.UserID AND a1.SurveyStatus='1' AND a.Sequence=a1.Sequence AND a.surveyID<>a1.SurveyID AND a1.IsActive='1' )
INNER JOIN answerdetail ad on(a1.AnswerId=ad.AnswerID AND ad.IsActive='1')
INNER JOIN question q on(ad.QuestionID=q.QuestionID)
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) 
INNER join category c on (s.CategoryID=c.CategoryID) 
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
WHERE a.AnswerId='".$value['ansId']."'
GROUP BY s.SubCategoryCode";
			$queryIn =$this->db->query($sqlIn,NULL);
			$lr=$ot=array();
			$lrQuesTot=$otQuesTot=$lrAnsTot=$otAnsTot=$lrPass=$otPass=0;
			foreach ($queryIn->result_array() as $keyIn => $valueIn) {				
				if(trim($valueIn['surveyID'])=='1'){
					if(trim($valueIn['SubCategoryCode'])=='Standard B3'){
						$lr['b3']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E18'){
						$lr['e18']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E19'){
						$lr['e19']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(!isset($lr['clientScore'])){
						if($valueIn['clientScore']==''){
							$lr['clientScore']='NA';
						} else {
							$lr['clientScore']=$valueIn['clientScore'];							
						}
					}
					if(isset($lr['cat'][$valueIn['CategoryCode']]['quesTot'])){
						$lr['cat'][$valueIn['CategoryCode']]['quesTot']+=$valueIn['quesTot'];
					} else {
						$lr['cat'][$valueIn['CategoryCode']]['quesTot']=$valueIn['quesTot'];
					}
					if(isset($lr['cat'][$valueIn['CategoryCode']]['answer'])){
						$lr['cat'][$valueIn['CategoryCode']]['answer']+=$valueIn['answer'];
					} else {
						$lr['cat'][$valueIn['CategoryCode']]['answer']=$valueIn['answer'];
					}
					/*if($valueIn['CategoryCode']=='G'){
						$lr['subcat'][$valueIn['SubCategoryCode']]=array('quesTot'=>$valueIn['quesTot'],'answer'=>$valueIn['answer']);
					}*/
					
					$lrQuesTot+=$valueIn['quesTot'];
					$lrAnsTot+=$valueIn['answer'];
				} else {
					if(trim($valueIn['SubCategoryCode'])=='Standard B3'){
						$ot['b3']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E18'){
						$ot['e18']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(trim($valueIn['SubCategoryCode'])=='Standard E19'){
						$ot['e19']=round(($valueIn['answer']/($valueIn['quesTot']*2))*100,0);
					}
					if(!isset($ot['clientScore'])){
						if($valueIn['clientScore']==''){
							$ot['clientScore']='NA';
						} else {
							$ot['clientScore']=$valueIn['clientScore'];							
						}
					}
					if(isset($ot['cat'][$valueIn['CategoryCode']]['quesTot'])){
						$ot['cat'][$valueIn['CategoryCode']]['quesTot']+=$valueIn['quesTot'];
					} else {
						$ot['cat'][$valueIn['CategoryCode']]['quesTot']=$valueIn['quesTot'];
					}
					if(isset($ot['cat'][$valueIn['CategoryCode']]['answer'])){
						$ot['cat'][$valueIn['CategoryCode']]['answer']+=$valueIn['answer'];
					} else {
						$ot['cat'][$valueIn['CategoryCode']]['answer']=$valueIn['answer'];
					}
					/*if($valueIn['CategoryCode']=='G'){
						$ot['subcat'][$valueIn['SubCategoryCode']]=array('quesTot'=>$valueIn['quesTot'],'answer'=>$valueIn['answer']);
					}*/
					$otQuesTot+=$valueIn['quesTot'];
					$otAnsTot+=$valueIn['answer'];
				}
			}
			// query for cat4 start
			$sqlIn="(SELECT a.answerId,ad.Answer,a.surveyID,c.CategoryCode,s.SubCategoryCode,q.QuestionID,q.ParentID,q.Reference,q.Statement,q.Checkpoint
FROM `answer` as a INNER JOIN answerdetail ad on(a.AnswerId=ad.AnswerID AND ad.IsActive='1') INNER JOIN question q on(ad.QuestionID=q.QuestionID) INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) INNER join category c on (s.CategoryID=c.CategoryID) INNER JOIN survey on(c.SurveyID=survey.SurveyID) WHERE a.AnswerId='".$value['ansId']."' AND c.CategoryCode='G' ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC)  
UNION 
(SELECT a1.AnswerID,ad.Answer,a1.surveyID,c.CategoryCode,s.SubCategoryCode,q.QuestionID,q.ParentID,q.Reference,q.Statement,q.Checkpoint 
FROM `answer` as a LEFT JOIN answer as a1 on(a.userID=a1.UserID AND a1.SurveyStatus='1' AND a.Sequence=a1.Sequence AND a.surveyID<>a1.SurveyID AND a1.IsActive='1' ) INNER JOIN answerdetail ad on(a1.AnswerId=ad.AnswerID AND ad.IsActive='1') INNER JOIN question q on(ad.QuestionID=q.QuestionID) INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) INNER join category c on (s.CategoryID=c.CategoryID) INNER JOIN survey on(c.SurveyID=survey.SurveyID) WHERE a.AnswerId='".$value['ansId']."' AND c.CategoryCode='G' ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC)";
			$queryIn =$this->db->query($sqlIn,NULL);			
			foreach ($queryIn->result_array() as $keyIn => $valueIn) {				
				if(trim($valueIn['surveyID'])=='1'){
					if($valueIn['ParentID']=='0'){
						$ref=$valueIn['QuestionID'];
						$lr['subcat'][$ref]['Reference']=$valueIn['Reference'];
					} else {
						$ref=$valueIn['ParentID'];
					}
					if(isset($lr['subcat'][$ref]['Answer'])){
						$lr['subcat'][$ref]['Answer']+=$valueIn['Answer'];
					} else {
						$lr['subcat'][$ref]['Answer']=$valueIn['Answer'];
					}
					if(isset($lr['subcat'][$ref]['quesTot'])){
						$lr['subcat'][$ref]['quesTot']+=1;
					} else {
						$lr['subcat'][$ref]['quesTot']=1;
					}
				} else {
					if($valueIn['ParentID']=='0'){
						$ref=$valueIn['QuestionID'];
						$ot['subcat'][$ref]['Reference']=$valueIn['Reference'];
					} else {
						$ref=$valueIn['ParentID'];
					}
					if(isset($ot['subcat'][$ref]['Answer'])){
						$ot['subcat'][$ref]['Answer']+=$valueIn['Answer'];
					} else {
						$ot['subcat'][$ref]['Answer']=$valueIn['Answer'];
					}
					if(isset($ot['subcat'][$ref]['quesTot'])){
						$ot['subcat'][$ref]['quesTot']+=1;
					} else {
						$ot['subcat'][$ref]['quesTot']=1;
					}
				}
			}
			// query for cat4 end


			//echo "<pre>"; print_r($lr['subcat']); print_r($ot['subcat']); echo "</pre>";
			$cnt_data=++$cnt;
            $subdata = array();
            $subdata1 = array();
            if(empty($lr)){
            	$subdata=array_fill(0, 12, '<span class="normal_font" >NA</span>');
            	$subdata[0] = $cnt_data.'.1';
	            $subdata[1] = $value['FacilityName'];
	            $subdata[2] = 'LR';
            } else {
				$lrScore=(int)(($lrAnsTot/($lrQuesTot*2))*100);
				$lrb3=isset($lr['b3'])?$lr['b3']:0;
				$lre18=isset($lr['e18'])?$lr['e18']:0;
				$lre19=isset($lr['e19'])?$lr['e19']:0;
				$lrclientScore=isset($lr['clientScore'])?$lr['clientScore']:0;
				if($lrScore>=70){
					$lrPass++;
					$c1textLR='<span class="success_font" >'.$lrScore.'</span>';
				} else {
					$c1textLR='<span class="error_font" >'.$lrScore.'</span>';
				}
				if(empty($lr['cat'])){
					$c2textLR='';	
				} else {
					$lrCrt='1';
					$c2textLR='<table class="inner-table1" border="1" width="100%"><tr>';
					foreach ($lr['cat'] as $keyCat => $valueCat) {
						$c2textLR.='<td>'.$keyCat.'</td>';
					}
					$c2textLR.='</tr>';
					foreach ($lr['cat'] as $keyCat => $valueCat) {
						$percent=(int)round(($valueCat['answer']/($valueCat['quesTot']*2))*100);
						if($percent>=70){
							$percentText='<span class="success_font" >'.$percent.'%</span>';
						} else {
							$lrCrt='0';
							$percentText='<span class="error_font" >'.$percent.'%</span>';
						}
						$c2textLR.='<td>'.$percentText.'</td>';
					}
					$c2textLR.='</tr><table border="1" width="100%">';
					if($lrCrt=='1'){
						$lrPass++;
					}
				}
				if($lrb3>=70 && $lre18>=70 && $lre19>=70){
					$lrPass++;
					$c3textLR1='<span class="success_font" >'.$lrb3.'</span>';
					$c3textLR2='<span class="success_font" >'.$lre18.'</span>';
					$c3textLR3='<span class="success_font" >'.$lre19.'</span>';
				} else {
					$c3textLR1='<span class="error_font" >'.$lrb3.'</span>';
					$c3textLR2='<span class="error_font" >'.$lre18.'</span>';
					$c3textLR3='<span class="error_font" >'.$lre19.'</span>';
				}
				if(empty($lr['subcat'])){
					$c4textLR='';	
				} else {
					$lrCrt='1';$totLrC4=0;
					foreach ($lr['subcat'] as $keysubcat => $valuesubcat) {
						$percent=(int)(($valuesubcat['Answer']*100)/($valuesubcat['quesTot']*2));
						if($percent>50){
							$totLrC4++;
						} else {
							$lrCrt='0';
						}
					}					
					if($lrCrt=='1'){
						$lrPass++;
						$c4textLR='<span class="success_font" >'.$totLrC4.'/'.count($lr['subcat']).'</span>';
					} else {
						$c4textLR='<span class="error_font" >'.$totLrC4.'/'.count($lr['subcat']).'</span>';
					}
				}				
				if($lrclientScore>=70){
					$lrPass++;
					$c5textLR='<span class="success_font" >'.$lrclientScore.'</span>';
				} else {
					$c5textLR='<span class="error_font" >'.$lrclientScore.'</span>';
				}				
				if($lrPass==5){
					$lrPassText='<span class="success_font" >'.$lrPass.'</span>';
				} else {
					$lrPassText='<span class="error_font" >'.$lrPass.'</span>';
				}
				$subdata[] = $cnt_data.'.1';
	            $subdata[] = $value['FacilityName'];
	            $subdata[] = 'LR';
	            $subdata[] = $lrScore;
	            $subdata[] = $c1textLR;
	            $subdata[] = $c2textLR;
	            $subdata[] = $c3textLR1;
	            $subdata[] = $c3textLR2;
	            $subdata[] = $c3textLR3;
	            $subdata[] = $c4textLR;
	            $subdata[] = $c5textLR;
	            $subdata[] = $lrPassText;            	
            }
            if(empty($ot)){
            	$subdata1=array_fill(0, 12, '<span class="normal_font" >NA</span>');
            	$subdata1[0] = $cnt_data.'.2';
	            $subdata1[1] = $value['FacilityName'];
	            $subdata1[2] = 'OT';
            } else {
            	$otScore=(int)(($otAnsTot/($otQuesTot*2))*100);
				$otb3=isset($ot['b3'])?$ot['b3']:0;
				$ote18=isset($ot['e18'])?$ot['e18']:0;
				$ote19=isset($ot['e19'])?$ot['e19']:0;
				$otclientScore=isset($ot['clientScore'])?$ot['clientScore']:0;
				if($otScore>=70){
					$otPass++;
					$c1textOT='<span class="success_font" >'.$otScore.'</span>';
				} else {
					$c1textOT='<span class="error_font" >'.$otScore.'</span>';
				}
				if(empty($ot['cat'])){
					$c2textOT='';	
				} else {
					$otCrt='1';
					$c2textOT='<table class="inner-table1" border="1" width="100%"><tr>';
					foreach ($ot['cat'] as $keyCat => $valueCat) {
						$c2textOT.='<td>'.$keyCat.'</td>';
					}
					$c2textOT.='</tr>';
					foreach ($ot['cat'] as $keyCat => $valueCat) {
						$percent=(int)round(($valueCat['answer']/($valueCat['quesTot']*2))*100);
						if($percent>=70){
							$percentText='<span class="success_font" >'.$percent.'%</span>';
						} else {
							$otCrt='0';
							$percentText='<span class="error_font" >'.$percent.'%</span>';
						}
						$c2textOT.='<td>'.$percentText.'</td>';
					}
					$c2textOT.='</tr><table border="1" width="100%">';
					if($otCrt=='1'){
						$otPass++;
					}
				}
				if($otb3>=70 && $ote18>=70 && $ote19>=70){
					$otPass++;
					$c3textOT1='<span class="success_font" >'.$otb3.'</span>';
					$c3textOT2='<span class="success_font" >'.$ote18.'</span>';
					$c3textOT3='<span class="success_font" >'.$ote19.'</span>';
				} else {
					$c3textOT1='<span class="error_font" >'.$otb3.'</span>';
					$c3textOT2='<span class="error_font" >'.$ote18.'</span>';
					$c3textOT3='<span class="error_font" >'.$ote19.'</span>';
				}
				if(empty($ot['subcat'])){
					$c4textOT='';	
				} else {
					$otCrt='1';$totOtC4=0;
					foreach ($ot['subcat'] as $keysubcat => $valuesubcat) {
						$percent=(int)(($valuesubcat['Answer']*100)/($valuesubcat['quesTot']*2));
						if($percent>50){
							$totOtC4++;
						} else {
							$otCrt='0';
						}
					}					
					if($otCrt=='1'){
						$otPass++;
						$c4textOT='<span class="success_font" >'.$totOtC4.'/'.count($ot['subcat']).'</span>';
					} else {
						$c4textOT='<span class="error_font" >'.$totOtC4.'/'.count($ot['subcat']).'</span>';
					}
				}
				if($otclientScore>=70){
					$otPass++;
					$c5textOT='<span class="success_font" >'.$otclientScore.'</span>';
				} else {
					$c5textOT='<span class="error_font" >'.$otclientScore.'</span>';
				}
				if($otPass==5){
					$otPassText='<span class="success_font" >'.$otPass.'</span>';
				} else {
					$otPassText='<span class="error_font" >'.$otPass.'</span>';
				}
				$subdata1[] = $cnt_data.'.2';
	            $subdata1[] = $value['FacilityName'];
	            $subdata1[] = 'OT';
	            $subdata1[] = $otScore;
	            $subdata1[] = $c1textOT;
	            $subdata1[] = $c2textOT;
	            $subdata1[] = $c3textOT1;
	            $subdata1[] = $c3textOT2;
	            $subdata1[] = $c3textOT3;
	            $subdata1[] = $c4textOT;
	            $subdata1[] = $c5textOT;
	            $subdata1[] = $otPassText;            	
            }
            $data[] = $subdata;
            $data[] = $subdata1;
		}

		return array('totalData'=>$queryTot->num_rows(),'totalFilter'=>$queryTot->num_rows(),'data'=>$data);
	}
    function getanalysis($searchData) {
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
		$col=array();
		if(!empty($this->session->userdata('showState'))){
			$col[]='s.StateName';
		}
		if(!empty($this->session->userdata('showDistrict'))){
			$col[]='d.DistrictName';
		}
		if(!empty($this->session->userdata('showFacilities'))){
			$col[]='f.facilityName';
		}
		$col[]='a.AssessmentDate';
		$col[]='sr.SurveyName';
		$col[]='c.CategoryName';
		$col[]='sub.SubCategoryName';
		$col[]='q.Reference';
		$col[]='q.Checkpoint';
		$col[]='a.Answer';

        $response = array();
        $this->db->select('a.answerId');
        $this->db->from('answer a');
        $this->db->join('answerdetail ad','a.AnswerID=ad.AnswerID AND ad.IsActive=1 ','inner');
        $this->db->join('question q','q.QuestionID=ad.QuestionID AND q.format=a.format','inner');
        $this->db->join('subcategory sub','q.SubcategoryID=sub.SubcategoryID AND sub.format=a.format','inner');
        $this->db->join('category c','sub.CategoryID=c.CategoryID AND c.format=a.format','inner');
        $this->db->join('survey sr','sr.SurveyID=a.SurveyID ','inner');
        $this->db->join('usermapping um','a.UserID=um.UserID AND um.UserID>0','inner');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
        if(!empty($searchData['search_state'])){
            $this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
            $this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
            $this->db->where('a.UserID',$searchData['search_facility']);
        }
        if(!empty($searchData['search_survey'])){
            $this->db->where_in('a.SurveyID',$searchData['search_survey']);
        }
        if(!empty($searchData['search_cat'])){
            $this->db->where_in('c.CategoryID',$searchData['search_cat']);
        }
        if(!empty($searchData['search_score'])){
            $this->db->where_in('ad.Answer',$searchData['search_score']);
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);
            if ($searchString == 'Completed') {
                $this->db->where("(a.SurveyStatus='1')", NULL, FALSE);
            } else {
                $this->db->where("(f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        $queryTot = $this->db->get();
        //echo $this->db->last_query()."<br>";

        $this->db->select('f.facilityName,s.StateName,d.DistrictName,a.AnswerId,a.AssessmentDate,c.CategoryName,sub.SubCategoryCode,q.Reference,q.Checkpoint,ad.Answer,ad.QuestionID,sr.SurveyName,c.CategoryCode,s.StateID,d.DistrictID,a.UserID,c.CategoryID,sub.SubcategoryID,sr.SurveyID');
        $this->db->from('answer a');
        $this->db->join('answerdetail ad','a.AnswerID=ad.AnswerID AND ad.IsActive=1 ','inner');
        $this->db->join('question q','q.QuestionID=ad.QuestionID AND q.format=a.format','inner');
        $this->db->join('subcategory sub','q.SubcategoryID=sub.SubcategoryID AND sub.format=a.format','inner');
        $this->db->join('category c','sub.CategoryID=c.CategoryID AND c.format=a.format','inner');
        $this->db->join('survey sr','sr.SurveyID=a.SurveyID ','inner');
        $this->db->join('usermapping um','a.UserID=um.UserID AND um.UserID>0','inner');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');

        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
        if(!empty($searchData['search_state'])){
            $this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
            $this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
            $this->db->where('a.UserID',$searchData['search_facility']);
        }
        if(!empty($searchData['search_survey'])){
            $this->db->where_in('a.SurveyID',$searchData['search_survey']);
        }
        if(!empty($searchData['search_cat'])){
            $this->db->where_in('c.CategoryID',$searchData['search_cat']);
        }
        if(!empty($searchData['search_score'])){
            $this->db->where_in('ad.Answer',$searchData['search_score']);
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);
            if ($searchString == 'Completed') {
                $this->db->where("(a.SurveyStatus='1')", NULL, FALSE);
            } else {
                $this->db->where("(f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
        $this->db->limit($this->input->post('length'), $this->input->post('start'));
        $query = $this->db->get();
        //echo $this->db->last_query()."<br>";

        $data['draw'] = $this->input->post('draw');
        $data['totalData'] = $queryTot->num_rows();
        $data['totalFilter'] = $queryTot->num_rows();
        $dataget = array();
        $cnt=$searchData['start'];
        foreach ($query->result() as $key => $value) {
		    $subdata=array();
		    $subdata[]=++$cnt;
    		if(!empty($value->Reference)){
                $Reference=$value->Reference;
                $parentID=$value->QuestionID;
            }
		    if($this->session->userdata('showState')){
		    	$subdata[]=$value->StateName;		    	
		    }
		    if($this->session->userdata('showDistrict')){
		    	$subdata[]=$value->DistrictName;		    	
		    }
		    if($this->session->userdata('showFacilities')){
		    	$subdata[]=$value->facilityName;		    	
		    }            
		    $subdata[]=convert_date_show($value->AssessmentDate);
		    $subdata[]=$value->SurveyName;
		    $subdata[]=$value->CategoryCode.'-'.$value->CategoryName;
		    $subdata[]=$value->SubCategoryCode;
		    $subdata[]=@$Reference;
		    $subdata[]=$value->Checkpoint;
		    $subdata[]=$value->Answer;
            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;

        return $data;
    }
    function monthly($searchData) {
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
		if(!empty($this->session->userdata('showState'))){
			$col[]='s.StateName';
		}
		if(!empty($this->session->userdata('showDistrict'))){
			$col[]='d.DistrictName';
		}
		if(!empty($this->session->userdata('showFacilities'))){
			$col[]='f.facilityName';
		}

        $response = array();
        $this->db->select('monthly.MonthlyID');
        $this->db->from('monthly');

        $this->db->join('usermapping um','monthly.UserID=um.UserID');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');

        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
        if(!empty($searchData['search_state'])){
            $this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
            $this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
            $this->db->where('monthly.UserID',$searchData['search_facility']);
        }
        if (!empty($searchData['fromMonth']) && !empty($searchData['fromMonth'])) {
            $search_form_date = '01-'.$searchData['fromMonth'];
            $this->db->where('DATE(monthly.ReportMonth)>=', convert_date_db($search_form_date));
        }
        if (!empty($searchData['toMonth']) && !empty($searchData['toMonth'])) {
            $search_to_date = '01-'.$searchData['toMonth'];
            $this->db->where('DATE(monthly.ReportMonth)<=', convert_date_db($search_to_date));
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);
            if ($searchString == 'Completed') {
                $this->db->where("(monthly.MonthlyStatus='1')", NULL, FALSE);
            } else if ($searchString == 'Incomplete') {
                $this->db->where("(monthly.MonthlyStatus='0')", NULL, FALSE);
            } else {
                $this->db->where("(monthly.CollectionDate='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.CreatedOn='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.ReportMonth='" . date('Y-m-01', strtotime($searchString)) . "' OR f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        $this->db->where('monthly.MonthlyStatus',1);
        $this->db->group_by('monthly.UserID');
        $queryTot = $this->db->get();


        $this->db->select('f.facilityName,s.StateName,d.DistrictName,monthly.MonthlyID,monthly.ReportMonth,sum(monthly.TotalDeliveries) as TotalDeliveries,sum(monthly.TotalMaternalDeaths) as TotalMaternalDeaths,sum(monthly.TotalStillBirths) as TotalStillBirths,sum(monthly.TotalLiveBirths) as TotalLiveBirths,sum(monthly.NumberNeonatalDeaths) as NumberNeonatalDeaths');
        $this->db->from('monthly');

        $this->db->join('usermapping um','monthly.UserID=um.UserID');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');

        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }

        if(!empty($searchData['search_state'])){
            $this->db->where('s.StateID',$searchData['search_state']);            
        }
        if(!empty($searchData['search_district'])){
            $this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
            $this->db->where('monthly.UserID',$searchData['search_facility']);
        }
        if (!empty($searchData['fromMonth']) && !empty($searchData['fromMonth'])) {
            $search_form_date = '01-'.$searchData['fromMonth'];
            $this->db->where('DATE(monthly.ReportMonth)>=', convert_date_db($search_form_date));
        }
        if (!empty($searchData['toMonth']) && !empty($searchData['toMonth'])) {
            $search_to_date = '01-'.$searchData['toMonth'];
            $this->db->where('DATE(monthly.ReportMonth)<=', convert_date_db($search_to_date));
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);
            if ($searchString == 'Completed') {
                $this->db->where("(monthly.MonthlyStatus='1')", NULL, FALSE);
            } else if ($searchString == 'Incomplete') {
                $this->db->where("(monthly.MonthlyStatus='0')", NULL, FALSE);
            } else {
                $this->db->where("(monthly.CollectionDate='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.CreatedOn='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.ReportMonth='" . date('Y-m-01', strtotime($searchString)) . "' OR f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        $this->db->where('monthly.MonthlyStatus',1);
        $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
        $this->db->group_by('monthly.UserID');
        $this->db->limit($this->input->post('length'), $this->input->post('start'));
        $query = $this->db->get();

        $data['draw'] = $this->input->post('draw');
        $data['totalData'] = $queryTot->num_rows();
        $data['totalFilter'] = $queryTot->num_rows();
        $surveyFormLevel = array('1' => 'Base Line', '2' => 'Mid Line', '3' => 'Top Line');
        $dataget = array();
        $cnt=$searchData['start'];
        $access_edit=$this->CommonModel->checkPageActionWeb('monthly/index','access_edit',$this->session->userdata('RoleName'));
        $access_view=$this->CommonModel->checkPageActionWeb('monthly/index','access_view',$this->session->userdata('RoleName'));
        foreach ($query->result() as $key => $value) {
            $subdata = array();
		    $subdata[]=++$cnt;
    		if(!empty($value->Reference)){
                $Reference=$value->Reference;
                $parentID=$value->QuestionID;
            }
		    if($this->session->userdata('showState')){
		    	$subdata[]=$value->StateName;		    	
		    }
		    if($this->session->userdata('showDistrict')){
		    	$subdata[]=$value->DistrictName;		    	
		    }
		    if($this->session->userdata('showFacilities')){
		    	$subdata[]=$value->facilityName;		    	
		    }
		    $subdata[]=$value->TotalDeliveries;
		    $subdata[]=$value->TotalMaternalDeaths;
		    $subdata[]=$value->TotalStillBirths;
		    $subdata[]=$value->TotalLiveBirths;
		    $subdata[]=$value->NumberNeonatalDeaths;

            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;

        return $data;
    }
	function getCertificationData($searchData){

        $data = array();
        $col = array(
            0 => 'FacilityName',
        );
	  	$this->db->select('f.facilityName');
	    $this->db->from('certification');
		$this->db->join('usermapping um','certification.UserID=um.UserID');
		$this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
		$this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
		$this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
		$this->db->join('typedetail tds','f.FacilityTypeDetailID=tds.TypeDetailID AND tds.IsActive=1', 'left');
		if(!empty($searchData['cond'])){
			$this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
		}
	    $this->db->where('certification.IsActive','1');
	    $this->db->where('certification.IsCurrent','1');
	    $this->db->where('certification.certificationStatus','1');
	    
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            // datatable search conditions
            if(strtolower($searchString)=='incomplete'){
                //$this->db->where("(answer.SurveyStatus='0')", NULL, FALSE);
            } else {
                $this->db->where("(f.FacilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%' OR tds.TypeDetailCode like '%".$searchString."%')", NULL, FALSE);
            }
        }
        if(!empty($searchData['search_state'])){
        	$this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
        	$this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
        	$this->db->where('certification.UserID',$searchData['search_facility']);
        }
        if(!empty($searchData['search_type'])){
        	$this->db->where('f.FacilityTypeDetailID',$searchData['search_type']);
        }
        if(!empty($searchData['search_cer_type'])){
        	$this->db->where('certification.level',$searchData['search_cer_type']);
        } else {
        	$this->db->where_in('certification.level',array('1','2'));
        }
	    $queryTot = $this->db->get();





	    $this->db->select('f.FacilityName,s.StateName,d.DistrictName,certification.CertificationID,certification.certification_type,certification.level,certification.status,tds.TypeDetailCode');
	    $this->db->from('certification');
		$this->db->join('usermapping um','certification.UserID=um.UserID');
		$this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
		$this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
		$this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
		$this->db->join('typedetail tds','f.FacilityTypeDetailID=tds.TypeDetailID AND tds.IsActive=1', 'left');
		if(!empty($searchData['cond'])){
		$this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
		}
	    $this->db->where('certification.IsActive','1');
	    $this->db->where('certification.IsCurrent','1');
	    $this->db->where('certification.certificationStatus','1');
	    
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            
            if(strtolower($searchString)=='incomplete'){
                //$this->db->where("(answer.SurveyStatus='0')", NULL, FALSE);
            } else {
                $this->db->where("(f.FacilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%' OR tds.TypeDetailCode like '%".$searchString."%')", NULL, FALSE);
            }
        }
        if(!empty($searchData['search_state'])){
        	$this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
        	$this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
        	$this->db->where('certification.UserID',$searchData['search_facility']);
        }
        if(!empty($searchData['search_type'])){
        	$this->db->where('f.FacilityTypeDetailID',$searchData['search_type']);
        }
        if(!empty($searchData['search_cer_type'])){
        	$this->db->where('certification.level',$searchData['search_cer_type']);
        } else {
        	$this->db->where_in('certification.level',array('1','2'));
        }
        //$this->db->group_by('answer.UserID');
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $this->db->limit($this->input->post('length'),$this->input->post('start'));
	    $query = $this->db->get();
	    $cnt=$searchData['start'];

        //$access_add=$this->CommonModel->checkPageActionWeb('facility/index','access_add',$this->session->userdata('RoleName'));
        $access_edit=$this->CommonModel->checkPageActionWeb('certification/approval','access_edit',$this->session->userdata('RoleName'));
        //$access_delete=$this->CommonModel->checkPageActionWeb('facility/index','access_delete',$this->session->userdata('RoleName'));
        $access_view=$this->CommonModel->checkPageActionWeb('certification/approval','access_view',$this->session->userdata('RoleName'));
		foreach ($query->result_array() as $key => $value) {
			$subdata=array();
			$subdata[]=++$cnt;
			switch ($value['certification_type']) {
				case 'lr':
					$certification_type='Labour Room';
					break;
				case 'ot':
					$certification_type='Operation Theater';
					break;
				case 'both':
					$certification_type='Labour Room & Operation Theater';
					break;	
				default:
					$certification_type='Labour Room';
					break;
			}
			if($searchData['RoleName']=='Ministry'){
            	$subdata[] = $value['StateName'];
        	}
        	if($searchData['RoleName']=='State' || $searchData['RoleName']=='Ministry'){
            	$subdata[] = $value['DistrictName'];
            }
            if($searchData['RoleName']=='District' || $searchData['RoleName']=='State' || $searchData['RoleName']=='Ministry' ){
            	$subdata[] = $value['FacilityName'];
            }
            $subdata[] = $value['TypeDetailCode'];
            $subdata[] = $this->config->item('certificationLevel')[$value['level']];
            $subdata[] = $certification_type;
            $subdata[] = $this->config->item('certificationStatus')[$value['status']];
            $data[] = $subdata;
		}

		return array('totalData'=>$queryTot->num_rows(),'totalFilter'=>$queryTot->num_rows(),'data'=>$data);
	}


	
}