<?php
class PreControllerHook {
	public function facility_profile_check() {
		$CI =& get_instance();
		$url=strtolower($CI->uri->segment(1)).'/'.strtolower($CI->uri->segment(2));
		if($CI->session->userdata('RoleName')=='Facility'){
			$IsProfileUpdated=$CI->session->userdata('IsProfileUpdated');
			if(empty($IsProfileUpdated)){
				$CI->CommonModel->facility_profile_check($CI->session->userdata('UserID'));
				$IsProfileUpdated=$CI->session->userdata('IsProfileUpdated');
			}
			if($IsProfileUpdated=='0' && $url!='user/profile' && $url!='user/login' && $url!='user/logout'){
				redirect('user/profile');
			}			
		}

	  	return;
	}

  
}