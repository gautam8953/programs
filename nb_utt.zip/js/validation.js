// JavaScript Document
function validateLabCategories()
{
	if(document.getElementById('category_name').value=='')
	{
		alert('Please Enter Category Name');
		document.getElementById('category_name').focus();
		return false;
	}
	else if(document.getElementById('category_description').value=='')
	{
		alert('Please Enter Category Description');
		document.getElementById('category_description').focus();
		return false;
	}	
}

function validateLaboratory()
{
	if(document.getElementById('labo_regis_code').value=='')
	{
		alert('Please Enter Lab Registration Code');
		document.getElementById('labo_regis_code').focus();
		return false;
	}
	if(document.getElementById('labo_name').value=='')
	{
		alert('Please Enter Laboratory Name');
		document.getElementById('labo_name').focus();
		return false;
	}	
	if(document.getElementById('address').value=='')
	{
		alert('Please Enter Address');
		document.getElementById('address').focus();
		return false;
	}
	/*
	if(document.getElementById('city').value=='0')
	{
		alert('Please Select City');
		document.getElementById('city').focus();
		return false;
	}
	*/
	if(document.getElementById('state').value=='0')
	{
		alert('Please Select State');
		document.getElementById('state').focus();
		return false;
	}
	if(document.getElementById('country').value=='0')
	{
		alert('Please Select Country');
		document.getElementById('country').focus();
		return false;
	}
	if(document.getElementById('zone').value=='0')
	{
		alert('Please Select Zone');
		document.getElementById('zone').focus();
		return false;
	}	
	if(document.getElementById('contactperson').value=='')
	{
		alert('Please Enter Contact Person Name');
		document.getElementById('contactperson').focus();
		return false;
	}
	/*
	if(document.getElementById('registration_date').value=='')
	{
		alert('Please Enter Registration Date');
		document.getElementById('registration_date').focus();
		return false;
	}
	*/	
}

function validateAccredationDoc()
{
	if(document.getElementById('document_no').value=='')
	{
		alert('Please Enter Document Number');
		document.getElementById('document_no').focus();
		return false;
	}	
	
	if(document.getElementById('document_title').value=='')
	{
		alert('Please Enter Document Title');
		document.getElementById('document_title').focus();
		return false;
	}
	if(document.getElementById('document_type').value=='0')
	{
		alert('Please Select Document Type');
		document.getElementById('document_type').focus();
		return false;
	}
	if(document.getElementById('issue_no').value=='')
	{
		alert('Please Enter Issue Number');
		document.getElementById('issue_no').focus();
		return false;
	}
	if(document.getElementById('issue_date').value=='')
	{
		alert('Please Enter Issue Date');
		document.getElementById('issue_date').focus();
		return false;
	}
	/*
	if(document.getElementById('cost').value=='')
	{
		alert('Please Enter Cost');
		document.getElementById('cost').focus();
		return false;
	}	
	if(document.getElementById('userfile').value=='')
	{
		alert('Please Select Document File');
		document.getElementById('userfile').focus();
		return false;
	}
	*/
	
	if(document.getElementById('userfile').value!='')
	{		
		var e = document.getElementById('userfile');		
		var valid_extensions = /(.doc|.pdf|.docx|.xls|.xlsx)$/i;
		if(valid_extensions.test(e.value))
		{
			//alert('Valid');
			//return true;
		} 
		else
		{			
			alert('Invalid File Type. Please Upload Only Valid Document');
			document.getElementById('userfile').focus();
			return false;
		}			
	}
}

function validateJobPosting()
{
	//alert('hello');
	if(document.getElementById('job_titile').value=='')
	{
		alert('Please Enter Job Title');
		document.getElementById('job_titile').focus();
		return false;
	}
	if(document.getElementById('jobdesc').value=='')
	{
		alert('Please Upload Job Description Document');
		document.getElementById('jobdesc').focus();
		return false;
	}
	if(document.getElementById('contact_person').value=='')
	{
		alert('Please Enter Contact Person Name');
		document.getElementById('contact_person').focus();
		return false;
	}
	if(document.getElementById('designation').value=='')
	{
		alert('Please Enter Designation');
		document.getElementById('designation').focus();
		return false;
	}
	if(document.getElementById('lastdateofapply').value=='')
	{
		alert('Please Select Last Date of Apply');
		document.getElementById('lastdateofapply').focus();
		return false;
	}	
	if(document.getElementById('applicationdoc').value=='')
	{
		alert('Please Upload Application  Document');
		document.getElementById('applicationdoc').focus();
		return false;
	}
	
	
	
	if(document.getElementById('jobdesc').value!='')
	{		
		var e = document.getElementById('jobdesc');
		var valid_extensions = /(.doc|.pdf|.docx|.xls|.xlsx)$/i;
		if(valid_extensions.test(e.value))
		{
			//alert('Valid');
			//return true;
		} 
		else
		{
			alert('Invalid File Type. Please Upload Only Valid Document');
			document.getElementById('jobdesc').focus();
			return false;
		}	
	}
	if(document.getElementById('applicationdoc').value!='')
	{		
		var d = document.getElementById('applicationdoc');
		var valid_extensions = /(.doc|.pdf|.docx|.xls|.xlsx)$/i;
		if(valid_extensions.test(d.value))
		{
			//alert('Valid');
			//return true;
		} 
		else
		{
			alert('Invalid File Type. Please Upload Only Valid Document');
			document.getElementById('applicationdoc').focus();
			return false;
		}	
	}
	
}

function validateProficiencyTestScheduleForm()
{
	if(document.getElementById('code').value=="")
	{
		alert('Please Enter Code Number');
		document.getElementById('code').focus();
		return false;
	}
	if(document.getElementById('programe_description').value=="")
	{
		alert('Please Program Description');
		document.getElementById('programe_description').focus();
		return false;
	}
	if(document.getElementById('facility_id').value=='0')
	{
		alert('Please Select Facility');
		document.getElementById('facility_id').focus();
		return false;
	}
	if(document.getElementById('field_id').value=='0')
	{
		alert('Please Select Field');
		document.getElementById('field_id').focus();
		return false;
	}
	if(document.getElementById('programe_name').value=='')
	{
		alert('Please Enter Progra Name');
		document.getElementById('programe_name').focus();
		return false;
	}
	if(document.getElementById('contact_person').value=='')
	{
		alert('Please Enter Contact Person');
		document.getElementById('contact_person').focus();
		return false;
	}
	if(document.getElementById('nodal_lab_name').value=='')
	{
		alert('Please Enter Nodal Lab Name');
		document.getElementById('nodal_lab_name').focus();
		return false;
	}
	if(document.getElementById('city').value=='0')
	{
		alert('Please Select City');
		document.getElementById('city').focus();
		return false;
	}
	if(document.getElementById('country').value=='0')
	{
		alert('Please Select Country');
		document.getElementById('country').focus();
		return false;
	}
	if(document.getElementById('last_date_of_registration').value=='')
	{
		alert('Please Select Last Date of Registration');
		document.getElementById('last_date_of_registration').focus();
		return false;
	}
	if(document.getElementById('programme_finish_date').value=='')
	{
		alert('Please Select Program Finish Date');
		document.getElementById('programme_finish_date').focus();
		return false;
	}	
}

function validateTraningAwarenessForm()
{
	if(document.getElementById('event_type_id').value=='0')
	{
		alert('Please Select Event Type');
		document.getElementById('event_type_id').focus();
		return false;
	}
	if(document.getElementById('program_name').value=="")
	{
		alert('Please Enter Program Name');
		document.getElementById('program_name').focus();
		return false;
	}
	if(document.getElementById('course_detail').value=="")
	{
		alert('Please Enter Course Details');
		document.getElementById('course_detail').focus();
		return false;
	}
	if(document.getElementById('venue').value=='')
	{
		alert('Please Enter Venue');
		document.getElementById('venue').focus();
		return false;
	}
	if(document.getElementById('contact_address').value=='')
	{
		alert('Please Enter Contact Address');
		document.getElementById('contact_address').focus();
		return false;
	}
	if(document.getElementById('city').value=='0')
	{
		alert('Please Select City');
		document.getElementById('city').focus();
		return false;
	}
	if(document.getElementById('state').value=='0')
	{
		alert('Please Select State');
		document.getElementById('state').focus();
		return false;
	}
	if(document.getElementById('phone').value=='')
	{
		alert('Please Enter Phone Number');
		document.getElementById('phone').focus();
		return false;
	}
	if(document.getElementById('country').value=='0')
	{
		alert('Please Select Country');
		document.getElementById('country').focus();
		return false;
	}
	if(document.getElementById('program_fees').value=='')
	{
		alert('Please Enter Program Fees');
		document.getElementById('program_fees').focus();
		return false;
	}
}

function validateNewsAbbouncementForm()
{	
	if(document.getElementById('clip_type').value=='0')
	{
		alert('Please Select Clip Type');
		document.getElementById('clip_type').focus();
		return false;
	}
	if(document.getElementById('headline').value=='')
	{
		alert('Please Enter Head Lines');
		document.getElementById('headline').focus();
		return false;
	}
	if(document.getElementById('clip_detail').value=='')
	{
		alert('Please Enter Clip Details');
		document.getElementById('clip_detail').focus();
		return false;
	}
	if(document.getElementById('date_of_clip').value=='')
	{
		alert('Please Select Date of Clipping');
		document.getElementById('date_of_clip').focus();
		return false;
	}
}

function validateCertificateForm()
{	
	if(document.getElementById('lab_id').value=='-1')
	{
		alert('Please Select Laboratory');
		document.getElementById('lab_id').focus();
		return false;
	}
	if(document.getElementById('certificate_no').value=='')
	{
		alert('Please Enter Certificate Number');
		document.getElementById('certificate_no').focus();
		return false;
	}
	/*
	if(document.getElementById('certificatedoc').value=='')
	{
		alert('Please Select Certificate Document');
		document.getElementById('certificatedoc').focus();
		return false;
	}
	*/
	if(document.getElementById('certificatedoc').value!='')
	{
		var c = document.getElementById('certificatedoc');		
		var valid_extensions = /(.doc|.pdf|.docx|.xls|.xlsx)$/i;
		if(valid_extensions.test(c.value))
		{
			//alert('Valid');
			//return true;
		} 
		else
		{
			alert('Invalid File Type. Please Upload Only Valid Document');
			document.getElementById('certificatedoc').focus();
			return false;
		}	
	}
	if(document.getElementById('nature_of_lab').value=='-1')
	{
		alert('Please Select Nature of Lab');
		document.getElementById('nature_of_lab').focus();
		return false;
	}
	if(document.getElementById('operationat').value=='-1' || document.getElementById('operationat').value=='')
	{
		alert('Please Select Facility');
		document.getElementById('operationat').focus();
		return false;
	}
	if(document.getElementById('issue_date').value=='')
	{
		alert('Please Select Issue Date');
		document.getElementById('issue_date').focus();
		return false;
	}
	if(document.getElementById('expiry_date').value=='')
	{
		alert('Please Select Expiry Date');
		document.getElementById('expiry_date').focus();
		return false;
	}
	if(document.getElementById('facility_id').value=='-1')
	{
		alert('Please Select Field');
		document.getElementById('facility_id').focus();
		return false;
	}
	if(document.getElementById('field_id').value=='-1')
	{
		alert('Please Select Discipline');
		document.getElementById('field_id').focus();
		return false;
	}
	if(document.getElementById('group_id').value=='-1')
	{
		alert('Please Select Group');
		document.getElementById('group_id').focus();
		return false;
	}
	if(document.getElementById('subgroup_id').value=='-1')
	{
		alert('Please Select Sub Group');
		document.getElementById('subgroup_id').focus();
		return false;
	}
	
}

function validateZoneForm()
{
	if(document.getElementById('zone_name').value=='')
	{
		alert('Please Enter Zone Name');
		document.getElementById('zone_name').focus();
		return false;
	}	
}

function validateClipTypeForm()
{
	if(document.getElementById('clip_name').value=='')
	{
		alert('Please Enter Clip Name');
		document.getElementById('clip_name').focus();
		return false;
	}	
}

function validateDocumentType()
{	
	if(document.getElementById('document_type_name').value=='')
	{
		alert('Please Enter Document Type Name');
		document.getElementById('document_type_name').focus();
		return false;
	}	
}

function validateEventTypeForm()
{
	if(document.getElementById('event_type_name').value=='')
	{
		alert('Please Enter Event Type Name');
		document.getElementById('event_type_name').focus();
		return false;
	}	
}

function validateNatureofLabForm()
{
	if(document.getElementById('nature_name').value=='')
	{
		alert('Please Enter Nature of Lab Name');
		document.getElementById('nature_name').focus();
		return false;
	}
}

function validateOperationatForm()
{
	if(document.getElementById('operation_name').value=='')
	{
		alert('Please Enter Operation At');
		document.getElementById('operation_name').focus();
		return false;
	}
}

function validatelabAccreditationUnderAbeyance()
{
	/*
	if(document.getElementById('lab_registration_code').value=='')
	{
		alert('Please Enter Lab Registration Code');
		document.getElementById('lab_registration_code').focus();
		return false;
	}
	
	if(document.getElementById('cno').value=='0')
	{
		alert('Please Certificate Number');
		document.getElementById('cno').focus();
		return false;
	}
	*/
	
	
	if(document.getElementById('lab_id').value=='0')
	{
		alert('Please Select Lab');
		document.getElementById('lab_id').focus();
		return false;
	}
	
	if(document.getElementById('remark').value=='')
	{
		alert('Please Enter Remark');
		document.getElementById('remark').focus();
		return false;
	}
	
}

function validateAssessorForm()
{
	
}

function validateEditJobPosting()
{

	//alert('hello');
	if(document.getElementById('job_titile').value=='')
	{
		alert('Please Enter Job Title');
		document.getElementById('job_titile').focus();
		return false;
	}	
	if(document.getElementById('contact_person').value=='')
	{
		alert('Please Enter Contact Person Name');
		document.getElementById('contact_person').focus();
		return false;
	}
	if(document.getElementById('designation').value=='')
	{
		alert('Please Enter Designation');
		document.getElementById('designation').focus();
		return false;
	}
	if(document.getElementById('lastdateofapply').value=='')
	{
		alert('Please Select Last Date of Apply');
		document.getElementById('lastdateofapply').focus();
		return false;
	}
	
	if(document.getElementById('jobdesc').value!='')
	{		
		var e = document.getElementById('jobdesc');
		var valid_extensions = /(.doc|.pdf|.docx|.xls|.xlsx)$/i;
		if(valid_extensions.test(e.value))
		{
			//alert('Valid');
			//return true;
		} 
		else
		{
			alert('Invalid File Type. Please Upload Only Valid Document');
			document.getElementById('jobdesc').focus();
			return false;
		}	
	}
	if(document.getElementById('applicationdoc').value!='')
	{		
		var d = document.getElementById('applicationdoc');
		var valid_extensions = /(.doc|.pdf|.docx|.xls|.xlsx)$/i;
		if(valid_extensions.test(d.value))
		{
			//alert('Valid');
			//return true;
		} 
		else
		{
			alert('Invalid File Type. Please Upload Only Valid Document');
			document.getElementById('applicationdoc').focus();
			return false;
		}	
	}
	

}
