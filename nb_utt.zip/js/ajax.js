var xmlHttp;

var divId;

var servername = location.protocol+"//"+window.location.hostname+"/nabl/portal/";



function stateChanged()

{

    if (xmlHttp.readyState==4)

    {

        if (xmlHttp.status == 200)

        {

            //alert(xmlHttp.responseText);

            document.getElementById(divId).innerHTML=xmlHttp.responseText;

        }

        else

        {

            alert("There was a problem while using XMLHTTP:\n" + xmlHttp.statusText);

        }

    }

}



function stateOptionChanged()

{

    if (xmlHttp.readyState==4)

    {

        if (xmlHttp.status == 200)

        {

			var responsevalue = xmlHttp.responseText;

			var expResponse = responsevalue.split("|");

			document.getElementById('displayjdate').innerHTML=expResponse[0];

			document.getElementById('displaystation').innerHTML=expResponse[1];

			document.getElementById('displayoption').innerHTML=expResponse[2];

        }

        else

        {

            alert("There was a problem while using XMLHTTP:\n" + xmlHttp.statusText);

        }

    }

}



function GetXmlHttpObject()

{



    var xmlHttp=null;

    try

    {

    	// Firefox, Opera 8.0+, Safari

        xmlHttp=new XMLHttpRequest();

    }

    catch (e)

    {

        // Internet Explorer

        try

        {            

		xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");

        }

        catch (e)

        {	

		xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");

        }

    }



    return xmlHttp;

}



function stateRetiredChanged()

{

	

    if (xmlHttp.readyState==4)

    {

        if (xmlHttp.status == 200)

        {

		if(xmlHttp.responseText=='00-00-0000')

		{

			alert("System can't generate the actual retirement date in case date of birth is after 1977. Please enter the retirement date manually.");

			var textbox = "<input name='retirementDate' id='retiredate' type='text' class='text-field' value='00-00-0000' size='25'/>";

			document.getElementById(divId).innerHTML=textbox;

		}

		else

		{

			document.getElementById(divId).innerHTML=xmlHttp.responseText;

		}

        }

        else

        {

            alert("There was a problem while using XMLHTTP:\n" + xmlHttp.statusText);

        }

    }

    

}



/**

	Function configureDraftOrderForOfficer(option, draftValues)

	

	Description:	Function will be used to add/updated/delete the draft order for a specific employee

	

	Arguments:		2, option(values, 'Add', 'Update', 'Delete') , draftValues

	

	Retunr value:	

	

 

 */



function stateDraftChanged()

{

	if (xmlHttp.readyState==4)

    {    	

        if (xmlHttp.status == 200)

        {        	

        	document.getElementById(divId).innerHTML=xmlHttp.responseText;

        	

		

        }

        else

        {

            alert("There was a problem while using XMLHTTP:\n" + xmlHttp.statusText);

        }

    }

    

}



function configureDraftOrderForOfficer(draftvalues, cnt, divname)

{

	//alert(draftvalues);	

	divId =divname+cnt;

	//alert(divId);

    xmlHttp=GetXmlHttpObject()    

    if (xmlHttp==null)

    {

        alert ("Your browser does not support AJAX!");

        return;

    }   

    xmlHttp.onreadystatechange=stateDraftChanged;   

    xmlHttp.open("GET",draftvalues,true);

    xmlHttp.send(null); 

}

function getCityList(stateid) {

	if (stateid != "") {

		divId = "cityajax";

		xmlHttp = GetXmlHttpObject();

		if (xmlHttp == null) {

			alert("Your browser does not support AJAX!");

			return;

		}

		//var url=servername+"/ajaxhelper/citylist/stateid/";

		var url = servername + "/helpers/getCityList.php?stateid=";

		url = url + stateid;

		xmlHttp.onreadystatechange = stateChanged;

		xmlHttp.open("GET", url, false);

		xmlHttp.send(null);

	}

}

function getFieldList(facilityid)

{

  if(facilityid!="")

  {

    divId = "field";

    

    xmlHttp = GetXmlHttpObject();    

    if (xmlHttp==null)

    {

        alert ("Your browser does not support AJAX!");

        return;

    }

    

    //var url=servername+"/ajaxhelper/citylist/stateid/";		

    var url=servername+"/helpers/getfieldList.php?facility=";

    url=url+facilityid;

    //alert(url);

    xmlHttp.onreadystatechange = stateChanged;

    xmlHttp.open("GET",url,false);



    xmlHttp.send(null);

     //clearing subgroup
	clearSubgroup();
	clearGroup();

  }

}



function getgroupList(fieldid)

{

  //alert('hello');

  if(fieldid!="")

  {

    divId ="group";

    xmlHttp = GetXmlHttpObject();   

    if (xmlHttp==null)

    {

        alert ("Your browser does not support AJAX!");

        return;

    }

    var url=servername+"/helpers/getgroupList.php?field=";    

    url=url+fieldid;

    //alert(url);

    xmlHttp.onreadystatechange = stateChanged;   

    xmlHttp.open("GET",url,false);



    xmlHttp.send(null);
    //clearing subgroup
	clearSubgroup();
	
  }

}



function getsubgroupList(groupid)

{

  if(groupid!="")

  {

    divId ="subgroup";

    xmlHttp = GetXmlHttpObject();   

    //xmlHttp=new XMLHttpRequest();

    if (xmlHttp==null)

    {

        alert ("Your browser does not support AJAX!");

        return;

    }

    

    var url=servername+"/helpers/getsubgroupList.php?group=";   

    url=url+groupid;

    xmlHttp.onreadystatechange = stateChanged;

    xmlHttp.open("GET",url,false);

    xmlHttp.send(null);

  }

}



function showLaboratory(certificateno)

{

	//alert('Certificate No ' + certificateno);

	if(certificateno!="")

	{

		divId = "laboratoryList";

		xmlHttp = GetXmlHttpObject();

		if(xmlHttp==null)

		{

			alert ("Your browser does not support AJAX!");

			return;

	 	}

		var url = servername+"/helpers/getlablist.php?cno=";

		url = url+certificateno;		

		xmlHttp.onreadystatechange = stateChanged;

		xmlHttp.open("GET",url,false);

		xmlHttp.send(null);

	}

}

/*
change BY Avinash @10-04-2017
*/
function getFieldListPro(facilityid) {
	if (facilityid != "") {
		divId = "field";
		xmlHttp = GetXmlHttpObject();
		if (xmlHttp == null) {
			alert("Your browser does not support AJAX!");
			return;
		}
		//var url=servername+"/ajaxhelper/citylist/stateid/";
		var url = servername + "/helpers/bindDiscipline.php?facility=";
		url = url + facilityid;
		xmlHttp.onreadystatechange = stateChanged;
		xmlHttp.open("GET", url, false);
		xmlHttp.send(null);
	}
}

function bindDiscipline() {
	var disc_id = '';
	var select_box = document.getElementById('field_id');
    for(i=0; i < select_box.length; i++) {
        if(select_box.options[i].selected){
            disc_id = disc_id + ',' + select_box.options[i].value;
        }
	}
	if (disc_id != "") {
		divId = "group";
		xmlHttp = GetXmlHttpObject();
		if (xmlHttp == null) {
			alert("Your browser does not support AJAX!");
			return;
		}
		//var url=servername+"/ajaxhelper/citylist/stateid/";
		var url = servername + "/helpers/bindGroup.php?field=";
		url = url + disc_id;
		xmlHttp.onreadystatechange = stateChanged;
		xmlHttp.open("GET", url, false);
		xmlHttp.send(null);
		//clearing subgroup
	    clearSubgroup();
	}

}