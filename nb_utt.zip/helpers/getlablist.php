<?php 
//if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
include '../application/DB/dbconnect.php';
$certificateno = "0";
if(isset($_GET['cno']) && $_GET['cno']=='0')
{
	$certificateno = "0";
}
else
{
	$str = explode("|",$_GET['cno']);
	$certificateno = $str[1];
}
$sql = "select lc.certificate_no, l.id as labid, l.lab_name, l.lab_registration_code from lab_certificate_tbl as lc inner join laboratory_tbl as l on lc.lab_id=l.id where lc.certificate_no=\"$certificateno\" and l.status=1 order by l.lab_registration_code, l.lab_name  ";
$res = mysql_query($sql);
$lab="<select name='lab_id' id='lab_id' style='width:150px;' class='list-menu' >";
$lab.="<option value='-1'>Please Select</option>";
while($row=mysql_fetch_assoc($res))
{
	$lab=$lab."<option value=" . $row['labid'] .">".$row['lab_registration_code']." : ".$row['lab_name']."</option>";
}
$lab .= "</select>";
echo $lab;
?>