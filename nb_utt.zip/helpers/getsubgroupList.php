<?php 
include '../application/DB/dbconnect.php';
$group = $_GET['group'];
$sql = "select * from lab_category_tbl where cat_id='$group' and isactive='1' ";
$res = mysql_query($sql);
$field="<select name='subgroup[]' class='list-menu' style='width:150px;' id='subgroup_id' size='15' multiple>";
//$field.="<option value='0' selected>Please Select</option>";
while($row=mysql_fetch_assoc($res))
{	
	$field=$field."<option value='".$group."_".$row['id']."-".$row['category_name']."'>".$row['category_name']."</option>";
}
$field .= "</select>";
echo $field;
?>