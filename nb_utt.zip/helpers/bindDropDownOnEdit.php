<?php 
//if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
include '../application/DB/dbconnect.php';
$certificateno = "0";

$field_id = intval($_REQUEST['f_id']);
$discipline_id = intval($_REQUEST['disc_id']);
$group_id = intval($_REQUEST['gp_id']);

$result = array();
//getting discipline
$sql = "select * from lab_category_tbl where cat_id='$field_id' and isactive='1' ";
$res = mysql_query($sql);
$discipline = "<option value='-1'>Please Select</option>";
while($row=mysql_fetch_assoc($res)) {
	$discipline .= "<option value=" . $row['id'] .">" . $row['category_name'] . "</option>";
}
$result['Discipline'] = $discipline;
//getting group
$sql = "select * from lab_category_tbl where cat_id='$discipline_id' and isactive='1' ";
$res = mysql_query($sql);
$group = "<option value='-1'>Please Select</option>";
while($row=mysql_fetch_assoc($res)) {
	$group .= "<option value=" . $row['id'] .">" . $row['category_name'] . "</option>";
}
$result['Group'] = $group;
//getting subgroup
$sql = "select * from lab_category_tbl where cat_id='$group_id' and isactive='1' ";
$res = mysql_query($sql);
$sub_group = '';
//$sub_group = "<option value='-1'>Please Select</option>";
while($row=mysql_fetch_assoc($res)) {
	$sub_group .= "<option value='".$group_id."_".$row['id']."-".$row['category_name']."'>".$row['category_name']."</option>";
}
$result['SubGroup'] = $sub_group;
//sending response
echo json_encode($result);
exit;
?>