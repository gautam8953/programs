<?php 
include '../application/DB/dbconnect.php';
$field = $_GET['field'];
$field = ltrim($field, ',');
$field = array_unique(explode(',',$field));

$response = "<select name='group_id' style='width:150px;' class='list-menu' id='group_id' onchange='getsubgroupList(this.value)'>";
$response .= "<option value='-1'>Please Select</option>";

foreach($field as $field_val) {
	$p_query = "select category_name from lab_category_tbl where id=$field_val and isactive='1' order by category_name asc";
	$p_res = mysql_query($p_query);
	$p_row = mysql_fetch_assoc($p_res);
	$response .= '<optgroup label="'.$p_row['category_name'].'">';
	
	$sql = "select id,category_name from lab_category_tbl where cat_id='$field_val' and isactive='1' ";
	$res = mysql_query($sql);
	while($row = mysql_fetch_assoc($res)) {
		$response .= "<option value=" . $row['id'] .">" . $row['category_name'] . "</option>";
	}
	
	$response .= '</optgroup>';
}

$response .= "</select>";
echo $response;
exit;
?>