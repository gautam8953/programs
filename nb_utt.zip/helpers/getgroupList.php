<?php 
include '../application/DB/dbconnect.php';
$field = $_GET['field'];
//$con = mysql_connect('localhost','root','acmet12');
//mysql_select_db('nabl',$con);
$sql = "select * from lab_category_tbl where cat_id='$field' and isactive='1' ";
$res = mysql_query($sql);
$field="<select name='group_id' style='width:150px;' class='list-menu' id='group_id' onchange='getsubgroupList(this.value)'>";
$field.="<option value='-1'>Please Select</option>";
while($row=mysql_fetch_assoc($res))
{
	$field=$field."<option value=" . $row['id'] .">" . $row['category_name'] . "</option>";
}
$field .= "</select>";
echo $field;
?>