<?php 
//if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
include '../application/DB/dbconnect.php';
$stateid = $_GET['stateid'];
$sql = "select * from cities where stateid='$stateid' order by name";
$res = mysql_query($sql);
$field="<select name='city' style='width:150px;' class='list-menu' id='field_id' >";
$field.="<option value='-1'>Please Select</option>";
while($row=mysql_fetch_assoc($res))
{
	$field=$field."<option value=" . $row['id'] .">" . $row['name'] . "</option>";
}
$field .= "</select>";
echo $field;
?>