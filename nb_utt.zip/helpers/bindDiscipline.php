<?php 
//if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
include '../application/DB/dbconnect.php';
$facilityid = $_GET['facility'];
$sql = "select id,category_name from lab_category_tbl where cat_id='$facilityid' and isactive='1' order by category_name";
$res = mysql_query($sql);
$field="<select name='field_id[]' style='width:150px;' class='list-menu' id='field_id' onchange='bindDiscipline();' multiple>";
$field.="<option value='-1'>Please Select</option>";
while($row=mysql_fetch_assoc($res))
{
	$field=$field."<option value=" . $row['id'] .">" . $row['category_name'] . "</option>";
}
$field .= "</select>";
echo $field;
?>