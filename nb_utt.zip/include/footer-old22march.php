<!--sdfasdfasdf
</body>
</html>-->
</td>
</tr>

</table>
</div>
												
																		<div class="clrfix"></div>
					</div>
				</div>		
				<div class="clrfix"></div>
			</div> 
			
			<!--bottom-->

			
                          <!-- -->
			<!--footer-->
			<div class="tpcontainerbottom">
				<div class="tpcontainerbottom1">Copyright  2012. NABL. All Rights Reserved. &nbsp;&nbsp;Powered by <a href="http://www.rvsolutions.in/" class="linkbota" target="_blank">RV Solutions Pvt. Ltd.</a></div>
		   <div class="tpcontainerbottom2"><ul class="menu"><li class="item145"><a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=108&amp;Itemid=145"><span>RTI Act 2005</span></a></li><li class="item146"><a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=109&amp;Itemid=146"><span>Useful Links</span></a></li><li class="item147"><a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=66&amp;Itemid=147"><span>Contact Us</span></a></li><li class="item149"><a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=110&amp;Itemid=149"><span>Disclaimer</span></a></li><li class="item150"><a href="/NABL/index.php?option=com_xmap&amp;sitemap=1&amp;Itemid=150"><span>Site Map</span></a></li></ul></div>				 <div class="clrfix"></div>
             
		</div>
	</div>
	</div>
</body>
</html>