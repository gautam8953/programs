<!--<html>
<head>
	<title><?php echo $title ?> - NABL - Lab Management</title>
</head>
<body>
	<link rel="stylesheet" type="text/css" href="css/jqueryslidemenu.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery.bgiframe.js"></script>
	<script type="text/javascript" src="js/jqueryslidemenu.js"></script>
	<script type="text/javascript" charset="utf-8">
		$(function() {
			$('#1').bgiframe();
			$('#2').bgiframe();
			$('#3').bgiframe();
			$('#4').bgiframe();
			$('#5').bgiframe();
			$('#6').bgiframe();
			$('#7').bgiframe();
			$('#8').bgiframe();
			$('#9').bgiframe();
			$('#10').bgiframe();
			$('#11').bgiframe();
			$('#12').bgiframe();
			$('#13').bgiframe();
			$('#14').bgiframe();
			$('#15').bgiframe();
			$('#16').bgiframe();
			$('#17').bgiframe();
			$('#18').bgiframe();
			$('#19').bgiframe();
			$('#20').bgiframe();
			$('#21').bgiframe();
			$('#22').bgiframe();
			$('#23').bgiframe();
			$('#24').bgiframe();
			$('#24').bgiframe();
		});
	</script>
	<div id="myslidemenu" class="jqueryslidemenu">
		<ul>
		  <li>
		  <img src="gifs/down.gif" class="downarrowclass" style="border: 0pt none ;">
		  <?php
		  		echo anchor('c=admin&m=index', 'Laboratory'); 
		  ?>
			<ul style="top: 30px; display: none; visibility: visible; left: 0px; width: 195px;">
			  <li id="1">
			  <?php
			  		echo anchor('c=labs&m=index', 'Manage Categoriess');
			  ?>			  
			  </li>
			  <li id="2">
			  <?php
			  		echo anchor('c=laboratory&m=index', 'Manage Laboratories');
			  ?>
			  </li>
			  <li id="3">
			  <?php
			  		echo anchor('c=accredationDoc&m=index&docType=both', 'Manage Free Documents');
			  ?>
			  </li>
			  <li id="4">
			  <?php
			  		echo anchor('c=accredationDoc&m=index&docType=newsletter', 'Manage News Letter');
			  ?>	
			  </li>
			  <li id="5">
			  <?php
			  		echo anchor('c=user&m=index', 'Manage Users');
			  ?>
			  </li>
			  <li id="6">
			  <?php
			  		echo anchor('c=jobs&m=index', 'Manage Job Postings');
			  ?>
			  </li>		
			  <li id="7">
			 <?php
			  		echo anchor('c=news&m=index', 'Manage News');
			  ?>
			  </li>	
			  	 <li id="8">
			  <?php
			  		echo anchor('c=news&m=index', 'Manage Announcements');
			  ?>
			  </li>	
			 <li id="9">
			  <?php
			  		echo anchor('c=protestschedule&m=index', 'Manage Proficiency Test Schedules');
			  ?>
			  </li>	
			  <li id="10">
			  <?php
			  		echo anchor('c=eventschedule&m=index', 'Manage Event Schedules');
			  ?>
			  </li>
			  <li id="11">
			  <?php
			  		echo anchor('c=certificate&m=index', 'Manage Certificates');
			  ?>
			  </li>			  
			</ul>
		  </li>
		</ul>
		<ul>
		  <li>
		  <img src="gifs/down.gif" class="downarrowclass" style="border: 0pt none ;">
		  <?php
		  		echo anchor('c=admin&m=index', 'Settings'); 
		  ?>
			<ul style="top: 30px; display: none; visibility: visible; left: 0px; width: 195px;">
			  <li id="12">
			  <?php
			  	echo anchor('c=facility&m=index', 'Manage Facility');
				?>
			  </li>
			  <li id="13">
			  <?php
			  	echo anchor('c=field&m=index', 'Manage Fields');
			?>
			  </li>
			  <li id="14">
			   <?php
			  	echo anchor('c=group&m=index', 'Manage Groups');
			 ?>
			  </li>
			  <li id="15">
			 <?php
			  	echo anchor('c=subgroup&m=index', 'Manage Sub Groups');
			?>
			  </li>
			  <li id="16">
			  <?php
			  	echo anchor('c=zone&m=index', 'Manage Zones');
			?>
			  </li>
			  <li id="17">
			  <?php
			  	echo anchor('c=documenttype&m=index', 'Manage Document Types');
			?>
			  </li>
			  <li id="18">
			 <?php
			  	echo anchor('c=cliptype&m=index', 'Manage Clip Types');
			?>
			  </li>
			  <li id="19">
			  <?php
			  	echo anchor('c=eventtype&m=index', 'Manage Event Types');
			?>
			  </li>
			  <li id="20">
			 <?php
			  	echo anchor('c=natureoflab&m=index', 'Manage Nature of Labs');
			?>
			  </li>
			  <li id="20">
			 <?php
			  	echo anchor('c=operationat&m=index', 'Manage Operation At');
			?>
			  </li>
			</ul>
		  </li>
		</ul>			
	  </div>
	  -->
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="joomla, Joomla" />
  <meta name="title" content="Mission Statement" />
  <meta name="author" content="Administrator" />
  <meta name="description" content="Joomla! - the dynamic portal engine and content management system" />
  <meta name="generator" content="" />

  <title>Mission Statement</title>
  <link href="/NABL/templates/mystore_plazza/favicon.ico" rel="shortcut icon" type="image/x-icon" />
  <style type="text/css">
    <!--

.osolCaptchaBlock{
	width:100%;
}
.osolCaptchaBlock label{
	
}
.osolCaptchaBlock table td{
	
	text-align:center;
}

    -->
  </style>
  <script type="text/javascript" src="/NABL/media/system/js/mootools.js"></script>
  <script type="text/javascript" src="/NABL/media/system/js/caption.js"></script>
  <script type="text/javascript" src="http://localhost/NABL//modules/mod_tpmenu/tpmenu/dropdown/menu.js.php?animated=Fx.Transitions.Bounce.easeOut"></script><link href="http://localhost/NABL/templates/mystore_plazza/css/dropdowntpmenu.css" rel="stylesheet" type="text/css" />

<link rel="shortcut icon" href="/NABL/templates/mystore_plazza/favicon.ico" />
<link rel="stylesheet" href="/NABL/templates/mystore_plazza/css/css.gzip.php?style=lite&amp;size=standard" type="text/css" />

<script type="text/javascript" src="/NABL/templates/mystore_plazza/scripts/js/template.js"></script>


<style type="text/css">

/*Example CSS for the two demo scrollers*/

#pscroller1{
width: 600px;
height: 70px;
/*border: 1px solid black;*/
/*background-color: lightyellow;*/
}

#pscroller2{
width: 550px;
height: 70px;
/*border: 1px solid black;*/
padding: 3px;
}

#pscroller2 a{
text-decoration: none;
}

.someclass{ //class to apply to your scroller(s) if desired
}

</style>

<script type="text/javascript">

/*Example message arrays for the two demo scrollers*/

var pausecontent=new Array()
pausecontent[0]='<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=115&amp;Itemid=146"><u>Attention : Calibration Laboratories & NABL Assessors</u> </a><br />NABL accepts 50 ppm as uncertainty contribution due to "g" value in cases where it is not measure.....'
pausecontent[1]='<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=115&amp;Itemid=146"><u>Invitation for Proposal / Quotation for Hosting, Maintenance & revamping of Existing NABL website</u> </a><br />NABL invites quotation for Hosting, Maintenance and revamping of Existing website with dual i.e.,.....'

var pausecontent2=new Array()
pausecontent2[0]='<a href="http://www.news.com">News.com: Technology and business reports</a>'
pausecontent2[1]='<a href="http://www.cnn.com">CNN: Headline and breaking news 24/7</a>'
pausecontent2[2]='<a href="http://news.bbc.co.uk">BBC News: UK and international news</a>'
</script>

<script type="text/javascript">

/***********************************************
* Pausing up-down scroller-  Dynamic Drive (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit http://www.dynamicdrive.com/ for this script and 100s more.
***********************************************/

function pausescroller(content, divId, divClass, delay){
this.content=content //message array content
this.tickerid=divId //ID of ticker div to display information
this.delay=delay //Delay between msg change, in miliseconds.
this.mouseoverBol=0 //Boolean to indicate whether mouse is currently over scroller (and pause it if it is)
this.hiddendivpointer=1 //index of message array for hidden div
document.write('<div id="'+divId+'" class="'+divClass+'" style="position: relative; overflow: hidden"><div class="innerDiv" style="position: absolute; width: 100%" id="'+divId+'1">'+content[0]+'</div><div class="innerDiv" style="position: absolute; width: 100%; visibility: hidden" id="'+divId+'2">'+content[1]+'</div></div>')
var scrollerinstance=this
if (window.addEventListener) //run onload in DOM2 browsers
window.addEventListener("load", function(){scrollerinstance.initialize()}, false)
else if (window.attachEvent) //run onload in IE5.5+
window.attachEvent("onload", function(){scrollerinstance.initialize()})
else if (document.getElementById) //if legacy DOM browsers, just start scroller after 0.5 sec
setTimeout(function(){scrollerinstance.initialize()}, 500)
}

// -------------------------------------------------------------------
// initialize()- Initialize scroller method.
// -Get div objects, set initial positions, start up down animation
// -------------------------------------------------------------------

pausescroller.prototype.initialize=function(){
this.tickerdiv=document.getElementById(this.tickerid)
this.visiblediv=document.getElementById(this.tickerid+"1")
this.hiddendiv=document.getElementById(this.tickerid+"2")
this.visibledivtop=parseInt(pausescroller.getCSSpadding(this.tickerdiv))
//set width of inner DIVs to outer DIV's width minus padding (padding assumed to be top padding x 2)
this.visiblediv.style.width=this.hiddendiv.style.width=this.tickerdiv.offsetWidth-(this.visibledivtop*2)+"px"
this.getinline(this.visiblediv, this.hiddendiv)
this.hiddendiv.style.visibility="visible"
var scrollerinstance=this
document.getElementById(this.tickerid).onmouseover=function(){scrollerinstance.mouseoverBol=1}
document.getElementById(this.tickerid).onmouseout=function(){scrollerinstance.mouseoverBol=0}
if (window.attachEvent) //Clean up loose references in IE
window.attachEvent("onunload", function(){scrollerinstance.tickerdiv.onmouseover=scrollerinstance.tickerdiv.onmouseout=null})
setTimeout(function(){scrollerinstance.animateup()}, this.delay)
}


// -------------------------------------------------------------------
// animateup()- Move the two inner divs of the scroller up and in sync
// -------------------------------------------------------------------

pausescroller.prototype.animateup=function(){
var scrollerinstance=this
if (parseInt(this.hiddendiv.style.top)>(this.visibledivtop+5)){
this.visiblediv.style.top=parseInt(this.visiblediv.style.top)-5+"px"
this.hiddendiv.style.top=parseInt(this.hiddendiv.style.top)-5+"px"
setTimeout(function(){scrollerinstance.animateup()}, 50)
}
else{
this.getinline(this.hiddendiv, this.visiblediv)
this.swapdivs()
setTimeout(function(){scrollerinstance.setmessage()}, this.delay)
}
}

// -------------------------------------------------------------------
// swapdivs()- Swap between which is the visible and which is the hidden div
// -------------------------------------------------------------------

pausescroller.prototype.swapdivs=function(){
var tempcontainer=this.visiblediv
this.visiblediv=this.hiddendiv
this.hiddendiv=tempcontainer
}

pausescroller.prototype.getinline=function(div1, div2){
div1.style.top=this.visibledivtop+"px"
div2.style.top=Math.max(div1.parentNode.offsetHeight, div1.offsetHeight)+"px"
}

// -------------------------------------------------------------------
// setmessage()- Populate the hidden div with the next message before it's visible
// -------------------------------------------------------------------

pausescroller.prototype.setmessage=function(){
var scrollerinstance=this
if (this.mouseoverBol==1) //if mouse is currently over scoller, do nothing (pause it)
setTimeout(function(){scrollerinstance.setmessage()}, 100)
else{
var i=this.hiddendivpointer
var ceiling=this.content.length
this.hiddendivpointer=(i+1>ceiling-1)? 0 : i+1
this.hiddendiv.innerHTML=this.content[this.hiddendivpointer]
this.animateup()
}
}

pausescroller.getCSSpadding=function(tickerobj){ //get CSS padding value, if any
if (tickerobj.currentStyle)
return tickerobj.currentStyle["paddingTop"]
else if (window.getComputedStyle) //if DOM2
return window.getComputedStyle(tickerobj, "").getPropertyValue("padding-top")
else
return 0
}

</script>

<script language="javascript" type="text/javascript">
<!--
/****************************************************
     Author: Eric King
     Url: http://redrival.com/eak/index.shtml
     This script is free to use as long as this info is left in
     Featured on Dynamic Drive script library (http://www.dynamicdrive.com)
****************************************************/
var win=null;
function NewWindow(mypage,myname,w,h,scroll,pos){
if(pos=="random"){LeftPosition=(screen.width)?Math.floor(Math.random()*(screen.width-w)):100;TopPosition=(screen.height)?Math.floor(Math.random()*((screen.height-h)-75)):100;}
if(pos=="center"){LeftPosition=(screen.width)?(screen.width-w)/2:100;TopPosition=(screen.height)?(screen.height-h)/2:100;}
else if((pos!="center" && pos!="random") || pos==null){LeftPosition=0;TopPosition=20}
settings='width='+w+',height='+h+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=no';
win=window.open(mypage,myname,settings);}
// -->
</script>
</head>
<body id="tpbody" class="mainbody">
	
    <div class="top">
    <div id="tpcontainer" style="width:960px;">
		<div class="tpcontainer-inner">
			<!--header-->
			<div class="tpcontainerheader">
				<div class="tpinner">
					<div class="tpheader1"><span class="logo"><a href="/NABL/logo.php" title="" onclick="NewWindow(this.href,'Nabl-logo','290','330','no','center');return false" onfocus="this.blur()"></a></span></div>

					                                              
					<div class="clrfix"></div>
                                                  <!--<div align="right" class="homediv" ><a href="http://rvsolutions.in">Main Home</a></div>-->
					                                 <div class="tpheader3"><div id="tp-mainnavwrap"><div id="tp-mainnav" class="clearfix"><ul class="clearfix"  id="tp-cssmenu"><li class="">
<a href="/NABL/index.php?option=com_content&amp;view=frontpage&amp;Itemid=123">Home</a></li><li class="active parent">
<a class="haschild" href="#">About NABL</a><ul><li class="active">
<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=99&amp;Itemid=71">Mission Statement</a></li><li class="">
<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=98&amp;Itemid=72">Introduction</a></li><li class="">
<a href="#">Organisational Structure</a></li><li class="">
<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=100&amp;Itemid=73">Accreditation Schems</a></li><li class="">

<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=106&amp;Itemid=75">International Recognition</a></li><li class="">
<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=101&amp;Itemid=74">Careers</a></li><li class="">
<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=97&amp;Itemid=119">List of Contact Persons</a></li>
</ul></li><li class="parent">
<a class="haschild" href="/NABL/index.php?option=com_content&amp;view=article&amp;id=105&amp;Itemid=81">Training &amp; Awareness Programs</a><ul><li class="">
<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=103&amp;Itemid=106">Introduction</a></li><li class="">
<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=104&amp;Itemid=107">Course Schedule</a></li>
</ul></li><li class="parent">
<a class="haschild" href="/NABL/index.php?option=com_content&amp;view=article&amp;id=111&amp;Itemid=91">Accreditation Documents</a><ul><li class="">

<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=112&amp;Itemid=92">News Letters</a></li>
</ul></li><li class="">
<a href="#">Laboratory Search</a></li><li class="parent">
<a class="haschild" href="#">Proficiency Testing</a><ul><li class="">
<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=102&amp;Itemid=77">Introduction</a></li><li class="">
<a href="/NABL/index.php?option=com_content&amp;view=article&amp;id=107&amp;Itemid=78">Program Schedule</a></li>
</ul></li>
</ul></div></div></div>				</div>
				
                              

				
			</div>
			
			<!--top-->

			<!---->
						<!--content-->
			<div class="tpcontainercontent">
				<!--advert1-->
				<!---->
				
				<!--left-->
                              <!--right-->
								
				<!--maincontent-->
	<div class="tpcontainermain bb">
					<div class="tpinner">
																		<!--<div class="clrfix"></div>-->
						
												<div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">

<tr>
		<td class="contentheading" width="100%">
					Laboratory			</td>

</table>

<table class="contentpaneopen">


<tr>
<td valign="top" class="main_article">
