<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="joomla, Joomla" />
  <meta name="title" content="Mission Statement" />
  <meta name="author" content="Administrator" />
  <meta name="description" content="Joomla! - the dynamic portal engine and content management system" />
  <meta name="generator" content="" />
  <title><?php echo $title; ?></title>
  <link href="../templates/mystore_plazza/favicon.ico" rel="shortcut icon" type="image/x-icon" />
  <script type="text/javascript" src="../media/system/js/mootools.js"></script>
  <script type="text/javascript" src="../media/system/js/caption.js"></script>
  <script type="text/javascript" src="../modules/mod_tpmenu/tpmenu/dropdown/menu.js.php?animated=Fx.Transitions.Bounce.easeOut"></script><link href="../templates/mystore_plazza/css/dropdowntpmenu.css" rel="stylesheet" type="text/css" />
<link href="../templates/mystore_plazza/css/custom-nabl.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="../templates/mystore_plazza/favicon.ico" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/css.gzip.php?style=lite&amp;size=standard" type="text/css" />
<script type="text/javascript" src="../templates/mystore_plazza/scripts/js/template.js"></script>
<script src="js/ajax.js"></script>
<script type="text/javascript">
function open_win(certificateid)
{
	//alert(certificateid);
	var cid = certificateid;
	
/*window.open("index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid], _blank")
window.open('index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid]', 'mywindow', 'location=1,status=1,scrollbars=1,width=100,height=100');
*/

//alert('index.php?c=search&m=searchlabcertificate&cno='+cid);

testwindow  = window.open('index.php?c=search&m=searchlabcertificate&cno='+cid , 'mywindow', 'scrollbars=no,menubar=no,height=200,width=600,resizable=yes,toolbar=no,location=no,status=no');
testwindow.moveTo(350, 300);

   

}
</script>
</head>
<center>
<body id="tpbody" class="mainbody">
    <div class="top-nabl">
    <div id="tpcontainer-nabl" style="width:960px;">
		<div class="tpcontainer-inner">
			<!--header-->
			<div class="tpcontainerheader">
				<div class="tpinner">
					<div class="tpheader1"><span class="logo"><a href="/nabl/logo.php" title="" onclick="NewWindow(this.href,'Nabl-logo','290','330','no','center');return false" onfocus="this.blur()"></a></span></div>
					                                              
					<div class="clrfix HindiLink"><a href="/index.php?option=com_content&amp;view=article&amp;id=116&amp;Itemid=95">
                   <img src="../templates/mystore_plazza/images/hindi.png" border="0"  /></a></div>
                                                  <!--<div align="right" class="homediv" ><a href="http://rvsolutions.in">Main Home</a></div>-->
<div class="tpheader3">
<div id="tp-mainnavwrap">
<div id="tp-mainnav" class="clearfix">
<ul class="clearfix"  id="tp-cssmenu">
<li class="active">

<a href="../index.php?option=com_content&amp;view=frontpage&amp;Itemid=123">Home</a></li>
<li class="parent">
<a class="haschild" href="../index.php?option=com_content&amp;view=article&amp;id=99&amp;Itemid=53">About NABL</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=99&amp;Itemid=71">Mission Statement</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=98&amp;Itemid=72">Introduction</a></li><li class="">
<a href="#">Organisational Structure</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=100&amp;Itemid=73">Accreditation Schemes</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=106&amp;Itemid=75">International Recognition</a></li><li class="">
<a href="../nabl/index.php?c=publicjobs&m=index">Careers</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=97&amp;Itemid=119">List of Contact Persons</a></li>

</ul></li>
<li class="parent">
<a class="haschild" href="#">Training</a><ul><li class="parent">
<a class="haschild" href="#">Workshops</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=98&amp;Itemid=160">Introduction</a></li><li class="">
<a href="../nabl/index.php?c=publiceventschedule&amp;m=index&amp;trainingType=1&amp;Itemid=161">Course Schedule</a></li>
</ul></li><li class="parent">
<a class="haschild" href="#">Seminars</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=120&amp;Itemid=163">Introduction</a></li><li class="">
<a href="../nabl/index.php?c=publiceventschedule&amp;m=index&amp;trainingType=5&amp;Itemid=164">Course Schedule</a></li>
</ul></li><li class="parent">

<a class="haschild" href="#">Awareness Programs</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=121&amp;Itemid=166">Introduction</a></li><li class="">
<a href="../nabl/index.php?c=publiceventschedule&amp;m=index&amp;trainingType=6&amp;Itemid=167">Course Schedule</a></li>
</ul></li><li class="parent">
<a class="haschild" href="#">Conclaves</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=122&amp;Itemid=169">Introduction</a></li><li class="">
<a href="../nabl/index.php?c=publiceventschedule&amp;m=index&amp;trainingType=7&amp;Itemid=170">Course Schedule</a></li>
</ul></li><li class="parent">
<a class="haschild" href="#">Assessor`s Training Course</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=123&amp;Itemid=172">Introduction</a></li><li class="">

<a href="../nabl/index.php?c=publiceventschedule&amp;m=index&amp;trainingType=8&amp;Itemid=173">Course Schedule</a></li>
</ul></li><li class="parent">
<a class="haschild" href="#">Laboratory Training Course</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=124&amp;Itemid=175">Introduction</a></li><li class="">
<a href="../nabl/index.php?c=publiceventschedule&amp;m=index&amp;trainingType=9&amp;Itemid=176">Course Schedule</a></li>
</ul></li>
</ul></li>
<li class="parent">
<a class="haschild" href="#">Publications</a><ul><li class="">
<a href="../nabl/index.php?c=publicaccredationdoc&amp;m=index&amp;docType=newsletter&amp;Itemid=92">News Letters</a></li><li class="">
<a href="../nabl/index.php?c=publicaccredationdoc&amp;m=index&amp;docType=both&amp;Itemid=199">NABL Documents</a></li><li class="">

<a href="../nabl/index.php?c=publicaccredationdoc&amp;m=index&amp;docType=misc&amp;Itemid=200">Miscellaneous</a></li>
</ul></li>
<li class="parent">
<a class="haschild" href="#">Laboratory Search</a><ul><li class="">
<a href="../nabl/index.php?c=search&amp;m=index&amp;Itemid=177">Accredited Laboratories</a></li><li class="">
<a href="../nabl/index.php?c=publicexpiredaccreditation&amp;m=index&amp;Itemid=178">Expired Accreditation</a></li><li class="">
	<!-- <a href="../nabl/index.php?c=publicinactiveaccreditation&amp;m=index&amp;Itemid=189">Inactive Laboratories</a></li><li class="">  -->
	<!-- <a href="../nabl/index.php?c=publiclabAccreditationUnderAbeyance&amp;m=index&amp;Itemid=179">Laboratory Accreditation under Abeyance</a></li><li class="">  -->
<a href="../nabl/index.php?c=publicsuspendedaccreditation&amp;m=index&amp;Itemid=180">Suspended Accreditations</a></li><!--<li class="">

<a href="../nabl/index.php?c=publicclosedaccreditation&amp;m=index&amp;Itemid=182">Closed Laboratories</a></li>--><li class="">
<a href="../nabl/index.php?c=publicforcedwithdrawalaccreditation&amp;m=index&amp;Itemid=183">Forced Withdrawal Accreditation</a></li>
<li class="">
<a href="../nabl/index.php?c=publicvoluntarywithdrawalaccreditation&amp;m=index&amp;Itemid=184">Voluntary Withdrawal accreditation</a>
</li>
<li class="">
<a href="../nabl/index.php?c=publicstatusapplicantlaboratories&amp;m=index&amp;Itemid=193">Miscellaneous</a></li>
<!-- 
<li class="">
<a href="../nabl/index.php?c=publicvoluntarywithdrawalaccreditation&amp;m=index&amp;Itemid=194">Voluntary Withdrawal accreditation</a>
</li>
 -->
</ul></li>
<li class="parent">
<a class="haschild" href="#">Proficiency Testing Provider</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=102&amp;Itemid=77">Introduction</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=152&amp;Itemid=275">PT Providers/Program</a></li>
</ul></li>
<li class="parent">
<a class="haschild" href="#">RMP</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=150&amp;Itemid=267">Introduction </a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=151&amp;Itemid=273">Accredited & Applicant RMP</a></li>

</ul></li>
<li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=118&amp;Itemid=192">Log In</a></li>
</ul>
</div>
</div>
</div>				
</div>
			</div>
			
			<!--top-->
