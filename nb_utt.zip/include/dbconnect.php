<?php
$con = mysql_connect('localhost','rvsolutions_nabl','');
mysql_select_db('rvsolutions_nabl',$con);

//$con = mysql_connect('localhost','root','');
//mysql_select_db('nabl',$con);
//echo "Hello - ";
?>
