<style>
    .col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}    
</style>


<div class="page-title">
  <div class="title_left">
    <h3>Anexture Form</h3>
  </div>

</div>

<div class="clearfix"></div>


<div class="main-content main-content-form-gr-h">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Anexture Form</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">                
                
                <div class="col-md-4">
                     <div class="form-group">
                    <label> State Name  : </label>
                    <span id="search_state" name="search_state"  ></span>
                    </div>                  
                </div>
                
                <div class="col-md-4">
                     <div class="form-group">
                      <label> District Name  : </label>
                        <span id="search_district" name="search_district"  ></span>
                    </div>                  
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label> Name of the Hospital  : </label>
                        <span id="facilityName" name="facilityName"  ></span>
                    </div>
                </div>
                <div class="col-md-4">
                        <div class="form-group">
                            <label> Date of Assessment  : </label>
                                <span id="submitDate" name="submitDate"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 1 : </label>
                            <span id="checklist_1" name="checklist_1"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 2 : </label>
                            <span id="checklist_2" name="checklist_2"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 3 : </label>
                            <span id="checklist_3" name="checklist_3"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 4 : </label>
                            <span id="checklist_4" name="checklist_4"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 5 : </label>
                            <span id="checklist_5" name="checklist_5"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 6 : </label>
                            <span id="checklist_6" name="checklist_6"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 7 : </label>
                            <span id="checklist_7" name="checklist_7"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 8 : </label>
                            <span id="checklist_8" name="checklist_8"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 9 : </label>
                            <span id="checklist_9" name="checklist_9"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 10 : </label>
                            <span id="checklist_10" name="checklist_10"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 11 : </label>
                            <span id="checklist_11" name="checklist_11"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 12 : </label>
                            <span id="checklist_12" name="checklist_12"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 13 : </label>
                            <span id="checklist_13" name="checklist_13"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 14 : </label>
                            <span id="checklist_14" name="checklist_14"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 15 : </label>
                            <span id="checklist_15" name="checklist_15"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 16 : </label>
                            <span id="checklist_16" name="checklist_16"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 17 : </label>
                            <span id="checklist_17" name="checklist_17"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 18 : </label>
                            <span id="checklist_18" name="checklist_18"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 19 : </label>
                            <span id="checklist_19" name="checklist_19"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 20 : </label>
                            <span id="checklist_20" name="checklist_20"  ></span>
                        </div>
                    </div>


                    <div class="col-md-12">
                        <div class="form-group">
                            <div class='input-group pull-right'>
                                <input type='hidden' name="anextureID" id="anextureID" value="<?php echo $this->uri->segment('3'); ?>" class="" />
                            </div>
                        </div>
                    </div>

            </div>
        </div>

            </div>
        </div>
    </div>
</div>