

<div class="main-content"> 
    <div class="container">
        <div class="login-page1 login-page-step1">
            <div class="logi-list">
              <form name="loginForm" id="loginForm" class="login-form login_form_mine" action="<?php echo base_url()."facility/pages"?>" method="post">
               <!-- <div class="col-md-12"> 
                    <div class="form-group">
                        <label>Select Facility <span>*</span></label>
                          <select name='facilityoption' class="form-control">
                            <option value=1>Labour Room </option>
                            <option value=2>Operation Theatre  </option>
                          </select>
                    </div>
                </div> 
-->

<style type="text/css">
  .selec-fac-rom{}
  .selec-fac-rom{}
  .selec-fac-rom{}
  .selec-fac-rom h3.titl1{     margin: 16px 0;
    font-size: 19px;
    float: left;
    width: 100%;
    font-weight: 500;
    color: #7b7b7b;
    line-height: 30px;
    border-bottom: 1px solid rgba(204, 204, 204, 0.33);
    padding-bottom: 11px;
    text-align: center;}
   .selec-fac-rom h3.titl1 i{    font-size: 24px;    padding-right: 12px;    color: #d54d32;}
  .login-page-step1 .logi-list{    width: 100%;}
  .selec-fac-rom .radio{    margin: 16px 0 !important;}
  .form-select-lig1{    clear: both;    float: left;    margin-bottom: 29px;}



</style>
                <div class="selec-fac-rom">
                  <div class="col-md-12">
                      <h3 class="titl1"><i class="fa fa-hospital-o" aria-hidden="true"></i> Select Facility for NQASDH</h3>
                      <div class="form-group form-select-lig1">
                        <div class="col-md-12">  
                                 <label class="radio inline"> 
                                  <input type="radio"   name='facilityoption' value="1" required="" <?php if(isset($surveyOption['labour']) && $surveyOption['labour']=='1'){ echo 'disabled'; } ?> checked="checked" >
                                  <span> Checklist for Labour Room </span> 
                                </label>
                        </div>

                        <div class="col-md-12">  
                                 <label class="radio inline"> 
                                  <input type="radio"   name='facilityoption' value="1" required="" <?php if(isset($surveyOption['ot']) && $surveyOption['ot']=='1'){ echo 'disabled'; } ?> checked="checked" >
                                  <span> Checklist for Operation Theatre </span> 
                                </label>
                        </div>
   
                      </div>
                  </div>
                </div>


                <div class="col-md-6 col-md-offset-3">
                    <div class="form-group">
                      <input name="facility" type=submit value=Submit class="btn"> 
                    </div>  
                </div>
              </form>
        </div>

    </div>
    
    </div>
</div><!--main-content --> 

<script src="<?php echo base_url();?>assets/js/facility/facility_options.js"></script>