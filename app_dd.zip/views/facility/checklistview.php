<style>
  #loader_mine {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

h3.title {
    font-size: 21px;
    font-weight: normal;
    margin: 10px 0px 20px 0px;
    position: relative;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>

<script>
  $(document).ready(function() {
           $('#loader_mine').hide();
           $('.main-content').show();
});
</script>
<div id="loader_mine"></div>  

<div class="page-title">
    <div class="title_left">
        <h3><?php echo isset($survey['survey'][$surveyId]['SurveyDesc'])?$survey['survey'][$surveyId]['SurveyDesc']:''; ?>
          <span>(View Only)</span>
           </h3>
    </div>

    <div class="title_right">
        
        <span class="downlo-btn-form">
            <a class="btn btn-info" href="<?php echo base_url();?>facility/surveyFormatDownload/<?php echo $this->uri->segment('4'); ?>/<?php echo encryptor($uriParamFormat); ?>" target="_blank" title="Download Labour Room Facility Form" class="formatDownload"> <i class="fa fa-file-text-o " aria-hidden="true"></i> Download Checklist Data</a> 
            <a class="btn btn-info" href="#" data-toggle="modal" data-target="#abbreviationModal">Abbreviation <i class="fa fa-question-circle" aria-hidden="true"></i></a>
          </span> 
    </div>
 
</div>

<div class="main-content" style="display: none;">  
  <div class="tab-head1">
    <div class="container">
      <div class="row">
        <div class="form-main-labour">
          <h3 class="title">
          </h3>
            <!-- SmartWizard html -->
            <div id="smartwizard">          
              <?php if(isset($survey['survey'][$surveyId]['category']) && count($survey['survey'][$surveyId]['category'])>0){ ?>
              <ul>
                <li tabindex="1"><a href="#step-0"><span><em>  </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>Assessment<br /></a></li>
                <?php foreach ($survey['survey'][$surveyId]['category'] as $keyCat => $valueCat) { ?>            
                <li tabindex="1"><a href="#step-<?php echo $keyCat; ?>"><span><em> <?php echo isset($valueCat['CategoryCode'])?$valueCat['CategoryCode']:''; ?> </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span><?php echo isset($valueCat['CategoryName'])?$valueCat['CategoryName']:''; ?><br /></a></li>
                <?php } ?>
              </ul>
              <?php } ?>

              <div> 
                <!-- assesment start -->
                <div id="step-0" class="check-view-oral">      
                  <div class="x_content">
                    <div class="col-md-3">
                          <div class="new-scrore-lsit">
                                <div class="card user-card2">
                                      <div class="card-block text-center">
                                          <h6 class="m-b-15"><?php
                                          if(isset($scoreData['score'][0]['SurveyName'])){
                                            echo $scoreData['score'][0]['SurveyName'];
                                          }
                                          ?></h6>
                                          <?php
                                          $quesTot=$AnsTot=0;
                                          foreach ($scoreData['score'] as $key => $value) {
                                            $quesTot+=$value['quesTot']*2;
                                            $AnsTot+=$value['answer'];
                                          }
                                          ?>
                                          <div class="risk-rate">
                                              <span><b><?php echo $otScore=(int)(((int)$AnsTot/(int)$quesTot)*100).'%';  ?></b></span>
                                          </div>
                                          
                                      </div>
                                      <button data-href="<?php echo base_url().'facility/viewscore/'.encryptor($scoreData['facility']['AnswerID']).'/'.encryptor($scoreData['facility']['format']); ?>" onclick="pageRedirect(this)" class="btn btn-warning btn-block p-t-15 p-b-15"><i class="fa fa-bar-chart"></i> Check Full Score</button>
                                  </div>

                          </div>

                          
                    </div>
                  <div class="col-md-9">
                  <div class="row">
                    <div class="form-rat-detail">                    
                      <div class="col-md-4 col-sm-6 col-xs-12">
                          <div class="form-group">
                              <label> Name of the Hospital <span class=""> : </span> <span class="normal_font" id="facilityName"></span></label>
                              
                          </div>
                      </div>
                      <div class="col-md-4 col-sm-6 col-xs-12">
                          <div class="form-group">
                              <label> Assessment Type <span class=""> : </span> <span class="normal_font" id="sequence"></span></label>
                              
                          </div>
                      </div>
                      <div class="col-md-4 col-sm-6 col-xs-12">
                          <div class="form-group">
                              <label> Date of Assessment <span class=""> : </span> <span class="normal_font" id="assessmentDate"></span></label>
                              
                          </div>
                      </div>
                      <div class="col-md-4 col-sm-6 col-xs-12">
                          <div class="form-group">
                              <label> Name of Assessor 1<span class=""> : </span> <span class="normal_font" id="assessorsName1"></span></label>
                              
                          </div>
                      </div>
                      
                      <div class="col-md-4 col-sm-6 col-xs-12">
                          <div class="form-group">
                              <label> Name of Assessee 1<span class=""> : </span> <span class="normal_font" id="assesseesName1"></span></label>
                              
                          </div>
                      </div>
                      <div class="col-md-4 col-sm-6 col-xs-12">
                          <div class="form-group">
                              <label> Name of Assessor 2<span class=""> : </span> <span class="normal_font" id="assessorsName2"></span></label>
                              
                          </div>
                      </div>
                      <div class="col-md-4 col-sm-6 col-xs-12">
                          <div class="form-group">
                              <label> Name of Assessee 2<span class=""> : </span> <span class="normal_font" id="assesseesName2"></span></label>
                          </div>
                      </div>
                      <div class="col-md-4 col-sm-6 col-xs-12">
                          <div class="form-group">
                              <label> Category of Assessment <span class=""> : </span> <span class="normal_font" id="assessmentType"></span></label>
                              
                          </div>
                      </div>
                      <div class="col-md-4 col-sm-6 col-xs-12">
                          <div class="form-group">
                              <label> Action plan Submission Date <span class=""> : </span> <span class="normal_font" id="submissionDate"></span></label>
                              
                          </div>
                      </div>
                      </div>

                      </div>
                      </div>

                    </div>
                </div>
        
                <!-- assessment end -->
                <!-- Catgory Start -->
                <?php if(isset($survey['survey'][$surveyId]['category']) && count($survey['survey'][$surveyId]['category'])>0){ ?>
                <?php foreach ($survey['survey'][$surveyId]['category'] as $keyCat => $valueCat) { ?>
                <div id="step-<?php echo $keyCat; ?>">
                  <div class="top-socre-card">
                    <span class="pull-left">Check Point Score</span>
                    <span class="pull-right">Standard Wise Score</span>
                  </div>
                  <!-- Subcatgory Start -->
                  <?php if(isset($valueCat['subcategory']) && count($valueCat['subcategory'])>0){ ?>
                  <?php foreach ($valueCat['subcategory'] as $keySubCat => $valueSubCat) { ?>
                  <div class="question-list">
                    
                    <h5 class="form-title"><?php echo isset($valueSubCat['SubCategoryCode'])?$valueSubCat['SubCategoryCode'].': ':''; echo isset($valueSubCat['SubCategoryName'])?$valueSubCat['SubCategoryName']:'';  ?><span class="pull-right" id="SubTot_<?php echo $valueSubCat['SubcategoryID']; ?>"></span><span class="pull-right" id="SubScore_<?php echo $valueSubCat['SubcategoryID']; ?>"></span></h5>
                    <div class="question-list1">
                      <div class="quest1">

                        <!-- questation Start -->
                        <?php if(isset($valueSubCat['questions']) && count($valueSubCat['questions'])>0){ ?>
                        <?php foreach ($valueSubCat['questions'] as $keyQues => $valueQues) { 
                          if(!empty($valueQues['Reference']) && !empty($valueQues['Statement'])){
                          ?>
                        <div class="col-md-12 col-sm-12 col-xs-12 bg_dark_gr">
                         <div class="quote1-full">
                           
                            <div class="quote-1-list">
                              <?php if(isset($valueQues['Reference']) && !empty($valueQues['Reference'])){ ?><div class="num-list"><?php echo $valueQues['Reference']; ?></div><?php } ?>
                              <div class="quotation-content"> 
                                <?php if(isset($valueQues['Statement']) && !empty($valueQues['Statement'])){ ?><h4><?php echo $valueQues['Statement']; ?></h4><?php } ?>
                              </div>
                           </div>
                         </div>
                        </div>
                        <?php  } ?>
                        <div class="col-md-12 col-sm-12 col-xs-12 bg_light_gr">
                         <div class="quote1-full  quote1-full2">                          
                           
                          <div class="col-md-8">  
                            <div class="quote-1-list">
                              <div class="num-list"></div>
                              <div class="quotation-content quotation_content_mine_mar"> 
                                <?php if(isset($valueQues['Checkpoint']) && !empty($valueQues['Checkpoint'])){ ?><h5><?php echo $valueQues['Checkpoint']; ?></h5><?php } ?>                               
                              </div>
                              <?php if(!empty($valueQues['Assesment']) || !empty($valueQues['Verification'])){ ?>
                              <div class="clearfix"></div>
                              <div class="">
                               <p class="new-point-method">
                                 <?php if(!empty($valueQues['Assesment'])){ ?>
                                <strong>Assessment method: </strong><?php echo $valueQues['Assesment']; ?></br>
                                <?php } ?>
                                <?php if(!empty($valueQues['Verification'])){ ?>
                                <strong>Verification: </strong><?php echo $valueQues['Verification']; ?>
                                <?php } ?>
                              </p>
                             </div>
                             <?php } ?>
                           </div>
                          </div>

                        <div class="col-md-4 text-center">  
                          <div class="quote-1-option">
                            <div class="maxl">
                              <div class="col-md-2"></div>
                              <div class="col-md-5">  
                               <span id="answer_<?php echo $keyQues; ?>" class="number-view" ></span>
                              </div>
                            </div>
                          </div>
                        </div>

                  </div>
                </div>  
                <!-- questation Ended -->
                <?php } ?>
                <?php } ?>
              </div>
            </div>                  
          </div>
          <?php } ?>
          <?php } ?>
          <!-- Subcatgory End -->

        </div>
        <?php } ?>			  
        <?php } ?>  
        <!-- Catgory End -->
        <input type='hidden' name="SurveyID" id="SurveyID" value="<?php echo $this->uri->segment('3'); ?>" class="" />
        <input type='hidden' name="ansId" id="ansId" value="<?php echo $this->uri->segment('4'); ?>" class="" />
      </div>
    </div>   
    
  </div>
</div>
</div>
</div>  
</div><!--main-content --> 

<!-- abbrevation modal start -->
  <div class="modal fade" id="abbreviationModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Assessment Methods </h4>
        </div>
        <div class="modal-body">
          <p>
          <span >Assessment Method – </span> Assessment Methods are given in adjacent column to checkpoint and provides aid to the assessors that how the information required for a specific checkpoint can be gathered. There are four assessment methods:</br></br>
          <span style="font-weight: bold;" >Observations (OB) – </span> Where information can be gathered though
          direct observation. e.g. Level of Cleanliness, Display of Protocols,
          Landscaping, Signage etc.</br></br>
          <span style="font-weight: bold;" >Staff Interview (SI) – </span> Information should be gathered by interacting the concerned staff to understand the current practices, competency, etc. such as steps in hand washing, method to clean
          floor, wearing gloves.</br></br>
          <span style="font-weight: bold;" >Record Review (RR) – </span> Where information can be extracted from the records available at the facility. Few examples are availability of filled-in Housekeeping checklist, culture report for microbial surveillance, minutes of meeting of infection control committee.</br></br>
          <span style="font-weight: bold;" >Patient Interview (PI) – </span> Some information may be gathered by interacting the patients or their attendants e.g. counselling of patients on hygiene.</br></br>
          </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!-- abbrevation modal end -->

<!-- previewModal modal start -->
  <div class="modal fade" id="previewModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Excel Format </h4>
        </div>
        <div class="modal-body">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!-- previewModal modal end -->

<!-- wizaard -->
<script src="<?php echo base_url();?>assets/js/notify.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>

