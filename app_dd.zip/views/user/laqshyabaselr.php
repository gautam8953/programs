<div class="page-title">
	<div class="title_left">
		<h3>Laqshya Facility Filled Baseline LR</h3>
	</div>  
</div>
<div class="clearfix"></div>

<div class="main-content"> 
	<div class="container">	  
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="x_panel">
					<div class="x_title">
						<h2>Laqshya Facility Filled Baseline LR</h2>
						<ul class="nav navbar-right panel_toolbox">
							<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
						</ul>
						<div class="clearfix"></div>
					</div>
					<div class="x_content">

						<div class="col-md-12">
							<div class="row mar-bottom30">	            
								<?php if(isset($search_options['State']) ){ $stateShow='block'; } else { $stateShow='none'; } ?>
								<div class="col-md-3 col-xs-12 mar-top-20" style="display: <?php echo $stateShow; ?>">
									<select id="search_state" name="search_state" onchange="change_state()" class="form-control" >
										<option value="">Select State</option>
										<?php foreach ($search_options['State'] as $key => $value) {  ?>
										<option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
										<?php } ?>
									</select>                    
								</div>

								<?php if(isset($search_options['District']) ){ $distShow='block'; } else { $distShow='none'; } ?>
								<div class="col-md-3 col-xs-12 mar-top-20" style="display: <?php echo $distShow; ?>">
									<select id="search_district" name="search_district" class="form-control">
										<option value="">Select District</option>
										<?php foreach ($search_options['District'] as $key => $value) { ?>
										<option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
										<?php } ?>
									</select>                    
								</div>
								
								<div class="col-md-3 col-xs-12 mar-top-20" style="display: <?php if($this->session->userdata('RoleName')=='District'){ echo 'none';  } else { echo 'block';  } ?>">
									<input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" style="display: none;" />
									<input type="hidden" name="aspirational" id="aspirational" value="<?php echo @$aspirational; ?>">
									<a href="javascript:void(0)" id="reset_btn" class="btn btn-primary">Reset</a>
								</div>
							</div>
						</hr>
					</div>		

					<table id="datatable" class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>State</th>
								<th>District</th>
								<th>Facility</th>
								<th>Nin No.</th>
								<th>Facility Type</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>        
</div>
</div>
