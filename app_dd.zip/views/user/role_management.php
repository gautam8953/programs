<div class="page-title">
  <div class="title_left">
    <h3>Role Management</h3>
  </div>
</div>
<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">	    
	    <div class="row">
	        <div class="col-md-12">
	        	<form name="search_form" id="search_form" action="" method="post">
	        	<div class="well">
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_role" name="search_role" class="form-control">
						<option value="0" <?php if(empty($selectedRole)){ echo ' selected="selected"'; } ?> >Select Role</option>
						<?php foreach ($rolesData as $key => $value) { ?>
						<option value="<?php echo $value['RoleID']; ?>" <?php if($selectedRole==$value['RoleID']){ echo ' selected="selected"'; } ?> ><?php echo $value['RoleName']; ?></option>
						<?php } ?>
					</select>                    
                </div>
                <div class="col-md-3 col-xs-12 mar-top-20">
                    <input id="btn_search" name="btn_search" type="submit" class="btn btn-danger" value="Search" />
                    <a href="" id="" class="btn btn-primary">Reset</a>
                </div>
            	</div>
            	</form>
            </div>
	    </div>
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Assign Role</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">
			    <form name="search_form" id="search_form" action="" method="post">
			      <table id="datatable" class="table table-striped table-bordered">
			        	<thead>
			            <tr>
			                <th>SN.</th>
			                <th>Role</th>
			                <th>Module</th>
			                <th>Form</th>
			                <th>Add</th>
			                <th>Edit</th>
			                <th>Delete</th>
			                <th>View</th>
			            </tr>
			        	</thead>
			            <tbody>
			            	<?php $i=0; foreach ($roles as $key => $value) { ?>
			            	<tr>
			            		<td><?php echo ++$i; ?></td>
			            		<td><?php echo $value['RoleName']; ?></td>
			            		<td colspan="6"></td>
			            	</tr>
			            	<?php 
			            	$j=0;
			            	$moduleName='' ;
			            	foreach ($urls as $keyUrl => $valueUrl) {
			            	$pages=explode(',', $valueUrl['pages']);
			            	if($moduleName!=$valueUrl['moduleName']){
			            		$k=0;
			            	?>
			            	<tr>
			            		<td><?php echo $i.'.'.++$j; ?></td>
			            		<td></td>
			            		<td><?php echo $valueUrl['moduleName']; ?></td>
			            		<td colspan="5"></td>
			            	</tr>
			            	<?php }	?>
			            	<tr>
			            		<td><?php echo $i.'.'.$j.'.'.++$k; ?></td>
			            		<td></td>
			            		<td></td>
			            		<td><?php echo $valueUrl['formName']; ?></td>
			            		<td><input type="checkbox" name="access[<?php echo $value['RoleID']; ?>][<?php echo $valueUrl['id']; ?>][1]" id="<?php echo 'add_'.$value['RoleID'].'_'.$valueUrl['moduleID'].'_'.$valueUrl['id'] ?>" <?php echo (isset($getUserAccess[$value['RoleID']][$valueUrl['id']]) && $getUserAccess[$value['RoleID']][$valueUrl['id']]['access_add']=='1')?'checked':''; ?> <?php if(!in_array('page_add', $pages)){ echo ' disabled="disabled"'; } ?> ></td>
			            		<td><input type="checkbox" name="access[<?php echo $value['RoleID']; ?>][<?php echo $valueUrl['id']; ?>][2]" id="<?php echo 'edit_'.$value['RoleID'].'_'.$valueUrl['moduleID'].'_'.$valueUrl['id'] ?>" <?php echo (isset($getUserAccess[$value['RoleID']][$valueUrl['id']]) && $getUserAccess[$value['RoleID']][$valueUrl['id']]['access_edit']=='1')?'checked':''; ?> <?php if(!in_array('page_edit', $pages)){ echo ' disabled="disabled"'; } ?> ></td>
			            		<td><input type="checkbox" name="access[<?php echo $value['RoleID']; ?>][<?php echo $valueUrl['id']; ?>][3]" id="<?php echo 'delete_'.$value['RoleID'].'_'.$valueUrl['moduleID'].'_'.$valueUrl['id'] ?>" <?php echo (isset($getUserAccess[$value['RoleID']][$valueUrl['id']]) && $getUserAccess[$value['RoleID']][$valueUrl['id']]['access_delete']=='1')?'checked':''; ?> <?php if(!in_array('page_delete', $pages)){ echo ' disabled="disabled"'; } ?> ></td>
			            		<td><input type="checkbox" name="access[<?php echo $value['RoleID']; ?>][<?php echo $valueUrl['id']; ?>][4]" id="<?php echo 'view_'.$value['RoleID'].'_'.$valueUrl['moduleID'].'_'.$valueUrl['id'] ?>" <?php echo (isset($getUserAccess[$value['RoleID']][$valueUrl['id']]) && $getUserAccess[$value['RoleID']][$valueUrl['id']]['access_view']=='1')?'checked':''; ?> <?php if(!in_array('page_view', $pages)){ echo ' disabled="disabled"'; } ?> ></td>
			            	</tr>
			            	<input type="hidden" name="access[<?php echo $value['RoleID']; ?>][<?php echo $valueUrl['id']; ?>][5]" value="1">
			            	<?php $moduleName=$valueUrl['moduleName']; } ?>
			            	<?php } ?>
			            	<?php if($this->CommonModel->checkPageActionWeb('user/role_management','access_edit',$this->session->userdata('RoleName'))){ ?>
			            	<tr>
			            		<td colspan="7"></td>
			            		<td><input class="btn btn-primary" type="submit" id="save" name="save"></td>
			            	</tr>
			            	<?php } ?>
			            </tbody>
			      </table>
			  	</form>
			    </div>
			  </div>
			</div>			
		</div>        
    </div>
</div>