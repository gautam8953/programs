</div>
<div class="clear"></div>
<footer>
            <div class="container">
                <div class="row" style="display: flex; align-items: center;">


                    <div class="col-md-12 col-sm-8 col-sm-12 col-xs-12 visitor-number">
                        Copyright &copy; 2018. LA<span style="color: #af2222;">Q</span>SHYA. All Rights Reserved.
                    </div>
                    <!-- <div class="col-md-6 col-sm-4 col-sm-6 col-xs-12 text-right footer-right">
                        <img src="<?php echo base_url(); ?>assets/images/nhm.png" alt="nhm">
                        <img src="<?php echo base_url(); ?>assets/images/nhsrc.png" alt="nhsrc">
                    </div> -->
                </div>
            </div>
        </footer>
 

  <!-- color changes -->
            <div class="color-theme">
                <a href="javascript:;"  class="theme-collapse-btn"><i class="fa fa-angle-left"></i></a>
                
                <ul>
                    <li><a class="black-bg" href="javascript:;" title="Black Theme" id="color1"><img src="<?php echo base_url(); ?>assets/images/black-theme.png" alt="Black Theme"></a></li>
                
                    <li><a class="white-bg" href="javascript:;" title="Default Theme" id="color2"><img src="<?php echo base_url(); ?>assets/images/default-theme.png" alt="Default Theme"></a></li>
                          
                    <li><a class="red-bg" href="javascript:;" title="Red Theme" id="color3"><img src="<?php echo base_url(); ?>assets/images/red-bg.png" alt="Red Theme"></a></li>

                    <li><a class="grey-bg" href="javascript:;" title="Grey Theme" id="color4"><img src="<?php echo base_url(); ?>assets/images/grey-theme.png" alt="Grey Theme"></a></li>
                </ul>

                  <h4> Color Theme</h4>

            </div>

            <!-- facility Type add modal start -->
              <div class="modal fade" id="searchNinModal" role="dialog">
                <div class="modal-dialog">
                
                  <!-- Modal content-->
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title">Search NIN Number</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                  <label> State </label>
                                    <select id="search_state_nin" name="search_state_nin" onchange="change_state_nin()" class="form-control">
                                        <option value="99999">Select State</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                  <label> District </label>
                                    <select id="search_district_nin" name="search_district_nin" onchange="" class="form-control">
                                        <option value="99999">Select District</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                  <label> Facility Name </label>
                                  <input maxlength="50" class="form-control" placeholder="Enter facility name" id="FacilityName_nin" name="FacilityName_nin" type="text" value="" >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                  <label> Facility Type </label>
                                  <input maxlength="50" class="form-control" placeholder="Enter facility Type" id="facility_type" name="facility_type" type="text" value="" >
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group mar-top-20">
                                    <label>&nbsp;</label>
                                    <input id="global_btn_search_nin" name="global_btn_search_nin" type="button" class="btn btn-primary" value="Search" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                        <table style="" id="ninDatatable" class="table table-striped table-bordered" width="100%">
                        <thead>
                        <tr>
                            <th>SN.</th>
                            <th>State</th>
                            <th>District</th>
                            <th>Facility</th>
                            <th>Facility Type</th>
                            <th>NIN Number</th>
                        </tr>
                        </thead>
                        <tbody>
                        </tbody>
                        </table>                                                    
                        </div>

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                  
                </div>
              </div>
            <!-- facility Type add modal end -->
            

<!-- date Picker -->
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/jquery.form.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/sweetalert.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>

<script src="<?php echo base_url();?>assets/js/bootstrap-select.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap-datetimepicker.min.js"></script>



    <!-- FastClick -->
    <script src="<?php echo base_url();?>assets/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url();?>assets/vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="<?php echo base_url();?>assets/vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="<?php echo base_url();?>assets/vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php echo base_url();?>assets/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url();?>assets/vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="<?php echo base_url();?>assets/vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="<?php echo base_url();?>assets/vendors/Flot/jquery.flot.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/Flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/Flot/jquery.flot.time.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/Flot/jquery.flot.stack.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="<?php echo base_url();?>assets/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <!-- <script src="<?php //echo base_url();?>assets/vendors/DateJS/build/date.js"></script> -->
    <!-- JQVMap -->
    <script src="<?php echo base_url();?>assets/vendors/jqvmap/dist/jquery.vmap.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo base_url();?>assets/vendors/moment/min/moment.min.js"></script>
    <!--<script src="<?php echo base_url();?>assets/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>-->

       <!-- Datatables -->
    <script src="<?php echo base_url();?>assets/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/pdfmake/build/vfs_fonts.js"></script>
 

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url();?>assets/js/custom.min.js"></script>

    <script src="<?php echo base_url();?>assets/js/custom.js"></script>

    <script src="<?php echo base_url();?>assets/js/custom-file-input.js"></script>

<!--<script src="<?php //echo base_url();?>assets/js/map-scripts/india-min.js"></script>-->
    



<?php
$file=$this->uri->segment(2); if(empty($file)){ $file='index'; }
$folder=$this->uri->segment(1); if(empty($folder)){ $file='user'; }
$scriptUrl='assets/js/'.strtolower($folder).'/'.strtolower($file).'.js';
if(file_exists($scriptUrl)){ echo '<script src="'.base_url().$scriptUrl.'"></script>'; }
?> 


<script>
function goBack() {
  window.history.back();
}
</script>
</body>
</html>