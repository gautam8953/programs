<?php

class CronModel extends CI_Model {
  function __construct() {
    parent::__construct();
  }

  public function assesmentcron(){

  }
  public function facilityData($text){
    $tetxArr=explode('_', $text);
    if(count($tetxArr)==3){
        $this->db->select('usermapping.UserID');
        $this->db->from('usermapping');
        $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID AND usermapping.FacilityID>0', 'inner');
        $this->db->where('facilities.FacilityNumber',$tetxArr[0]);
        $this->db->where('usermapping.IsActive','1');
        $queryUserID = $this->db->get();
        if($queryUserID->num_rows()==1){
        $result_user = $queryUserID->row_array();
        $UserID=@$result_user['UserID'];
        } else {
          $UserID=0;
        }
      if(strtolower(trim($tetxArr[1]))=='lr'){
        $SurveyID=1;
      } else if(strtolower(trim($tetxArr[1]))=='ot'){
        $SurveyID=2;
      } else {
        $SurveyID=0;
      }
      if(strtolower(trim($tetxArr[2]))=='baseline'){
        $sequence=1;
      } else if(strtolower(trim($tetxArr[2]))=='oters'){
        $sequence=2;
      } else if(strtolower(trim($tetxArr[2]))=='endline'){
        $sequence=3;
      } else {
        $sequence=0;
      }

    } else {
      $UserID=$SurveyID=$sequence=0;
    }
    $this->session->set_userdata(array('UserID'=>$UserID));
    $dataArr=array(
      'UserID'=>$UserID,
      'SurveyID'=>$SurveyID,
      'FacilityNumber'=>$tetxArr[0],
      'Sequence'=>$sequence,
    );
    return $dataArr;
  }
  public function assesmentlog($dataLog){
    if(!empty($dataLog['file'])){
      $data=array();
            $data['log']['filename']=@$dataLog['file'];
            $data['log']['FacilityNumber']=@$dataLog['FacilityNumber'];
      $data['log']['status']=@$dataLog['status'];
      $data['log']['remarks']=@$dataLog['msg'];
      $data['log']['fileDate']=@$dataLog['fileDate'];
      $data['log']['CreatedOn']=date('Y-m-d H:i:s');
      $this->db->insert('assessment_cronlog', $data['log']);
    }
  }
  function fileCheck($text){
    $file = FCPATH.'assets/uploads/cron_assessment/'.$text;
    $fileDate=date("Y-m-d H:i:s", filemtime($file));
      $this->db->select('fileDate');
      $this->db->from('assessment_cronlog');
      $this->db->where('filename',$text);
      $this->db->order_by('id', 'DESC');
      $this->db->limit('1');
      $queryFile = $this->db->get();

      if($queryFile->num_rows()>=1){
      $result_file = $queryFile->row_array();     
      if($result_file['fileDate']==$fileDate){
        return false;
      } else {
        return true;
      }
      } else {
        return true;
      }

  }
  function checkCategoryExist($survey,$cat,$format='A'){
      $this->db->select('CategoryID');
      $this->db->from('category');
      $this->db->where('SurveyID',$survey);
      $this->db->where('CategoryCode',trim($cat));
      $this->db->where('IsActive',1);
      $this->db->where('format',$format);
      $this->db->order_by('CategoryID', 'DESC');
      $this->db->limit('1');
      $query=$this->db->get();
      if($query->num_rows()>=1){
      $result= $query->row_array();     
      if(!empty($result['CategoryID'])){
        return $result['CategoryID'];
      } else {
        return 0;
      }
      } else {
        return 0;
      }   
  }
  function checkSubCategoryExist($survey,$cat,$subCat,$format='A'){
      $this->db->select('SubcategoryID');
      $this->db->from('subcategory');
      $this->db->join('category', 'category.CategoryID=subcategory.CategoryID AND category.IsActive=1 AND category.SurveyID='.$survey, 'inner');
      $this->db->where('subcategory.SubCategoryCode','Standard '.trim($subCat));
      $this->db->where('subcategory.IsActive',1);
      $this->db->where('subcategory.format',$format);
      $this->db->order_by('subcategory.SubcategoryID', 'DESC');
      $this->db->limit('1');
      $query=$this->db->get();
      if($query->num_rows()>=1){
      $result= $query->row_array();     
      if(!empty($result['SubcategoryID'])){
        return $result['SubcategoryID'];
      } else {
        return 0;
      }
      } else {
        return 0;
      }   
  }
  function checkMeasurableExist($survey,$cat,$subCat,$measurable,$format='A'){
      $this->db->select('QuestionID');
      $this->db->from('question');
      $this->db->join('subcategory', 'question.SubcategoryID=subcategory.SubcategoryID AND subcategory.IsActive=1 AND subcategory.format="'.$format.'"', 'inner');
      $this->db->join('category', 'category.CategoryID=subcategory.CategoryID AND category.IsActive=1 AND SurveyID='.$survey, 'inner');
      $this->db->where('question.Reference','ME '.trim($measurable));
      $this->db->where('question.IsActive',1);
      $this->db->where('question.format',$format);
      $this->db->order_by('question.QuestionID', 'DESC');
      $this->db->limit('1');
      $query=$this->db->get();
      if($query->num_rows()>=1){
      $result= $query->row_array();     
      if(!empty($result['QuestionID'])){
        return $result['QuestionID'];
      } else {
        return 0;
      }
      } else {
        return 0;
      }   
  }
    function checkQuestion($questionData,$format='A'){
      // find question and return its question ID
      //echo "<pre>"; print_r($questionData); echo "</pre>";
      $ques=preg_replace('/[^A-Za-z0-9]/', '', trim($questionData['checkpoint']));
      $this->db->select('QuestionID');
      $this->db->from('question');
      $this->db->join('subcategory', 'question.SubcategoryID=subcategory.SubcategoryID AND subcategory.IsActive=1 AND subcategory.format="'.$format.'"', 'inner');
      $this->db->join('category', 'category.CategoryID=subcategory.CategoryID AND category.IsActive=1 AND SurveyID='.$questionData['SurveyID'], 'inner');
      $this->db->where('question.checkpoint_code',trim($ques));
      $this->db->where('question.IsActive',1);
      $this->db->where('question.format',$format);
      $this->db->order_by('question.QuestionID', 'DESC');
      $this->db->limit('1');
      $query=$this->db->get();
      //echo $this->db->last_query();
      if($query->num_rows()>=1){
        $result= $query->row_array();     
        if(!empty($result['QuestionID'])){
          return $result['QuestionID'];
        } else {
          return 0;
        }
      } else {
        return 0;
      }
    }
    function getFacility($searchData){
      $faciltyType=trim($searchData['facilityType']);
      $this->db->select('FacilityID');
      $this->db->from('facilities');
      $this->db->join('states', "states.StateID=facilities.StateID AND states.IsActive=1 AND states.StateName='".trim($searchData['state'])."'", 'inner');
      $this->db->join('district', "district.DistrictID=facilities.DistrictID AND district.IsActive=1 AND states.StateID=district.StateID AND district.DistrictName='".trim($searchData['district'])."'", 'inner');
      $this->db->join('typedetail', 'typedetail.TypeDetailID=facilities.FacilityTypeDetailID AND typedetail.IsActive=1 AND typedetail.TypeMasterID=4  ', 'inner');
      $this->db->where('typedetail.TypeDetailCode',$faciltyType);
      $this->db->where('facilities.FacilityName',trim($searchData['FacilityName']));
      $this->db->where('facilities.IsActive',1);
      $this->db->limit('1');
      $query=$this->db->get();
      //echo $this->db->last_query();
      if($query->num_rows()>=1){
        $result= $query->row_array();     
        if(!empty($result['FacilityID'])){
          return $result['FacilityID'];
        } else {
          return 2693;
        }
      } else {
        return 2693;
      }

    }

}