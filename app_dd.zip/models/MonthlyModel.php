<?php

class MonthlyModel extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function saveMonthly($dataSave) {
        $response = array('code' => 15, 'msg' => 'Data saved successfully');
        $monthlyId = 0;
        if (!empty($dataSave)) {
            $this->db->select('MonthlyID,MonthlyStatus');
            $this->db->from('monthly');
            $this->db->where('UserID', $this->session->userdata('facilityUser'));
            //$this->db->where('ReportMonth',date('Y-m-01'));
            $this->db->where('ReportMonth', $dataSave['monthly']['ReportMonth']);
            //$this->db->where('MonthlyStatus <>','1');
            $this->db->order_by('MonthlyID', 'DESC');
            $query = $this->db->get();
            if ($this->session->userdata('facilityUser') != $this->session->userdata('UserID')) {
                $dataSave['monthly']['ParentUserID'] = $this->session->userdata('UserID');
            }
            if ($query->num_rows() >= 1) {
                $dataSave['monthly']['ModifiedOn'] = date('Y-m-01');
                $dataSave['monthly']['ModifiedBy'] = $this->session->userdata('UserID');
                $result_Ans = $query->result();
                $monthlyId = $result_Ans[0]->MonthlyID;
                if ($result_Ans[0]->MonthlyStatus <> 1) {
                    $this->db->where('MonthlyID', $monthlyId);
                    $this->db->update('monthly', $dataSave['monthly']);
                    $response['code'] = 0;
                    $response['status'] = $dataSave['monthly']['MonthlyStatus'];
                    $response['msg'] = 'Data saved successfully';
                } else {
                    $response['code'] = 14;
                    $response['status'] = $dataSave['monthly']['MonthlyStatus'];
                    $response['msg'] = 'Report already submitted';
                }
            } else {
                //$dataSave['monthly']['ReportMonth']=date('Y-m-01');
                $dataSave['monthly']['CreatedOn'] = date('Y-m-d');
                $dataSave['monthly']['CreatedBy'] = $this->session->userdata('UserID');
                if ($this->db->insert('monthly', $dataSave['monthly'])) {
                    $monthlyId = $this->db->insert_id();
                    $response['code'] = 0;
                    $response['monthlyId'] = $monthlyId;
                    $response['status'] = $dataSave['monthly']['MonthlyStatus'];
                    $response['msg'] = 'Data saved successfully';
                } else {
                    $this->db->insert('monthly', $dataSave['monthly']);
                    $monthlyId = $this->db->insert_id();
                    $response['code'] = 0;
                    $response['monthlyId'] = $monthlyId;
                    $response['status'] = $dataSave['monthly']['MonthlyStatus'];
                    $response['msg'] = 'Data saved successfully';
                }
            }

            $this->db->select('onetimeID,onetimeStatus');
            $this->db->from('onetime');
            $this->db->where('UserID', $this->session->userdata('facilityUser'));
            $this->db->order_by('onetimeID', 'DESC');
            $query = $this->db->get();
            if ($dataSave['monthly']['MonthlyStatus'] == '1') {
                $dataSave['oneTime']['onetimeStatus'] = '1';
            } else {
                $dataSave['oneTime']['onetimeStatus'] = '0';
            }
            if ($query->num_rows() >= 1) {
                $result_oneTime = $query->result();
                $onetimeID = $result_oneTime[0]->onetimeID;
                if ($result_oneTime[0]->onetimeStatus != '1') {
                    $this->db->where('onetimeID', $onetimeID);
                    $this->db->update('onetime', $dataSave['oneTime']);
                    $response['oneTime']['code'] = 0;
                    $response['oneTime']['monthlyId'] = $onetimeID;
                    $response['oneTime']['oneTimeStatus'] = $dataSave['oneTime']['onetimeStatus'];
                    $response['oneTime']['msg'] = 'Data updated successfully';
                }
            } else {
                if ($this->session->userdata('facilityUser') != $this->session->userdata('UserID')) {
                    $dataSave['oneTime']['ParentUserID'] = $this->session->userdata('UserID');
                }
                if ($this->db->insert('onetime', $dataSave['oneTime'])) {
                    $onetimeID = $this->db->insert_id();
                    $response['oneTime']['code'] = 0;
                    $response['oneTime']['onetimeID'] = $onetimeID;
                    $response['oneTime']['oneTimeStatus'] = $dataSave['oneTime']['onetimeStatus'];
                    $response['oneTime']['msg'] = 'Data saved successfully';
                } else {
                    $this->db->insert('onetime', $dataSave['oneTime']);
                    $onetimeID = $this->db->insert_id();
                    $response['oneTime']['code'] = 0;
                    $response['oneTime']['onetimeID'] = $onetimeID;
                    $response['oneTime']['oneTimeStatus'] = $dataSave['oneTime']['onetimeStatus'];
                    $response['oneTime']['msg'] = 'Data saved successfully';
                }
            }
        }
        return $response;
    }

    function getMonthly($facilityUser, $rptDate) {
        $response = array();
        $this->db->select('DATE_FORMAT(monthly.ReportMonth,"%d-%m-%Y") as ReportMonth,DATE_FORMAT(monthly.CollectionDate,"%d-%m-%Y") as CollectionDate,monthly.TotalDeliveries,monthly.TotalNormalVaginalDeliveries,monthly.TotalAssistedVaginalDeliveries,monthly.TotalCSections,monthly.TotalMaternalDeaths,monthly.MaternalAPH,monthly.MaternalPPH,monthly.MaternalSepsis,monthly.MaternalObstructedLabour,monthly.MaternalPIHEclampsia,monthly.MaternalOthers,monthly.TotalLiveBirths,monthly.TotalStillBirths,monthly.TotalFreshStillBirths,monthly.TotalMaceratedStillBirths,monthly.NumberNeonatalDeaths,monthly.NeonatalPrematurity,monthly.NeonatalSepsis,monthly.NeonatalAsphyxia,monthly.NeonatalOthers,monthly.TotalLowBirthWeightBabies,monthly.TotalPretermDeliveries,monthly.BirthCompanionNos,monthly.SafeBirthChecklist,monthly.CSectionOTSafeChecklist,monthly.RealTimePartograph,monthly.BreastfedNewborns,monthly.MCBSamplingLR,monthly.MCBSamplingOT,monthly.CSectionsInfection,monthly.PretermANCSInFacilitiesSNCU,monthly.NewbornsSNCUAsphyxia,monthly.NewbornsSNCUSepsis,monthly.InbornLBWKMC,monthly.SatisfiedDelivered,monthly.ReorganizedLR,monthly.AdequateStaffLR,monthly.OxytocinCount,monthly.MaternalDeathsReviewed,monthly.NeonatalDeaths,monthly.MaternalMissCases,monthly.ReferralCases,monthly.StockOutsInLR,monthly.StockOutsInOT,monthly.NQASCertification,monthly.MCHDHFunctional,monthly.LaQshyaMentoringVisitsConducted,monthly.QITeamMeetings,monthly.TrainingSessionConducted,monthly.CurrentLabourRoomQualityScore,monthly.CurrentMaternityOTQualityScore,monthly.CurrentOSCEScore,monthly.MonthlyStatus');
        $this->db->from('monthly');
        $this->db->where('monthly.UserID', $facilityUser);
        $this->db->where('monthly.ReportMonth', $rptDate);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            $data = $query->row_array();
            $response['code'] = 0;
            $response['msg'] = $query->num_rows() . ' rows get';
            $response['data'] = $data;
            $response['MonthlyStatus'] = $data['MonthlyStatus'];
            $response['rptDate'] = convert_date_show($rptDate);
        } else {
            $response['code'] = 1;
            $response['msg'] = '0 rows get';
            $response['rptDate'] = convert_date_show($rptDate);
            $response['data'] = array();
            $response['MonthlyStatus'] = '';
        }
        $this->db->select('usermapping.UserID,facilities.FacilityName,states.StateName,states.StateID,district.DistrictID,district.DistrictName,typedetail.TypeDetailID,typedetail.TypeDetailCode');
        $this->db->from('usermapping');
        $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
        $this->db->join('states', 'facilities.StateID=states.StateID', 'left');
        $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'left');
        $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');
        $this->db->where('usermapping.UserID', $facilityUser);
        $this->db->where('usermapping.FacilityID >', '0');
        $this->db->limit('1');
        $result = $this->db->get();
        $dataFacility = $result->row_array();
        $response['FacilityDetails'] = $dataFacility;
        return $response;
    }

    function getMonthlyView($page) {
        $response = array();
        $this->db->select('DATE_FORMAT(monthly.ReportMonth,"%M %Y") as ReportMonth,DATE_FORMAT(monthly.CollectionDate,"%d-%m-%Y") as CollectionDate,monthly.TotalDeliveries,monthly.TotalNormalVaginalDeliveries,monthly.TotalAssistedVaginalDeliveries,monthly.TotalCSections,monthly.TotalMaternalDeaths,monthly.MaternalAPH,monthly.MaternalPPH,monthly.MaternalSepsis,monthly.MaternalObstructedLabour,monthly.MaternalPIHEclampsia,monthly.MaternalOthers,monthly.TotalLiveBirths,monthly.TotalStillBirths,monthly.TotalFreshStillBirths,monthly.TotalMaceratedStillBirths,monthly.NumberNeonatalDeaths,monthly.NeonatalPrematurity,monthly.NeonatalSepsis,monthly.NeonatalAsphyxia,monthly.NeonatalOthers,monthly.TotalLowBirthWeightBabies,monthly.TotalPretermDeliveries,monthly.BirthCompanionNos,monthly.SafeBirthChecklist,monthly.CSectionOTSafeChecklist,monthly.RealTimePartograph,monthly.BreastfedNewborns,monthly.MCBSamplingLR,monthly.MCBSamplingOT,monthly.CSectionsInfection,monthly.PretermANCSInFacilitiesSNCU,monthly.NewbornsSNCUAsphyxia,monthly.NewbornsSNCUSepsis,monthly.InbornLBWKMC,monthly.SatisfiedDelivered,monthly.ReorganizedLR,monthly.AdequateStaffLR,monthly.OxytocinCount,monthly.MaternalDeathsReviewed,monthly.NeonatalDeaths,monthly.MaternalMissCases,monthly.ReferralCases,monthly.StockOutsInLR,monthly.StockOutsInOT,monthly.NQASCertification,monthly.MCHDHFunctional,monthly.LaQshyaMentoringVisitsConducted,monthly.QITeamMeetings,monthly.TrainingSessionConducted,monthly.CurrentLabourRoomQualityScore,monthly.CurrentMaternityOTQualityScore,monthly.CurrentOSCEScore,monthly.MonthlyStatus,monthly.UserID');
        $this->db->from('monthly');
        //$this->db->where('monthly.UserID', $facilityUser);
        $this->db->where('monthly.MonthlyID', $page);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            $data = $query->result_array();

            $this->db->select('usermapping.UserID,facilities.FacilityName,states.StateName,states.StateID,district.DistrictID,district.DistrictName,typedetail.TypeDetailID,typedetail.TypeDetailCode');
            $this->db->from('usermapping');
            $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
            $this->db->join('states', 'facilities.StateID=states.StateID', 'left');
            $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'left');
            $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');
            $this->db->where('usermapping.UserID', $data[0]['UserID']);
            $this->db->where('usermapping.FacilityID >', '0');
            $this->db->limit('1');
            $result = $this->db->get();
            $dataFacility = $result->result_array();
            $response['FacilityDetails'] = $dataFacility[0];

            $response['code'] = 0;
            $response['msg'] = $query->num_rows() . ' rows get';
            $response['data'] = $data;
            $response['MonthlyStatus'] = $data[0]['MonthlyStatus'];
        } else {
            $response['code'] = 1;
            $response['msg'] = '0 rows get';
            $response['data'] = array();
        }
        return $response;
    }

    function getOneTime_web($page,$facilityUser) {
        $response = array();
        $this->db->select('onetime.BaselineNQASChecklistLR,DATE_FORMAT(onetime.AssessmentMonthLR,"%d-%m-%Y") as AssessmentMonthLR,onetime.BaselineScoreLR,onetime.BaselineNQASChecklistOT,DATE_FORMAT(onetime.AssessmentMonthOT,"%d-%m-%Y") as AssessmentMonthOT,onetime.BaselineScoreOT,onetime.BaselineStaffCompetenceOSCE,onetime.AssessmentMonthOSCE,onetime.BaselineAvgOSCEScore,onetime.QualityTeamFacility,onetime.QualityCircleLR,onetime.QualityCircleOT,onetime.OrientationAttended,onetimeStatus');
        $this->db->from('onetime');
        //$this->db->join('monthly', 'monthly.UserID=onetime.UserID', 'left');
        //$this->db->where('monthly.MonthlyID', $page);
        //$this->db->group_by(array("onetime.UserID"));
        $this->db->where('onetime.UserID', $facilityUser);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            $data = $query->row_array();
            if (empty($data['AssessmentMonthLR']) || $data['AssessmentMonthLR'] == '1970-01-01') {
                $data['AssessmentMonthLR'] = '';
            }
            if ($data['BaselineScoreLR'] == null) {
                $data['BaselineScoreLR'] = '';
            }
            if (empty($data['AssessmentMonthOT']) || $data['AssessmentMonthOT'] == '1970-01-01') {
                $data['AssessmentMonthOT'] = '';
            }
            if ($data['BaselineScoreOT'] == null) {
                $data['BaselineScoreOT'] = '';
            }
            $response['code'] = 0;
            $response['onetimeStatus'] = $data['onetimeStatus'];
            $response['msg'] = $query->num_rows() . ' rows get';
            $response['data'] = $data;
        } else {
            $response['code'] = 1;
            $response['onetimeStatus'] = '';
            $response['msg'] = '0 rows get';
            $response['data'] = array();
        }
        return $response;
    }

    function getSearchData($searchData) {
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
        $col = array(
            0 => 'ReportMonth',
            1 => 'CollectionDate',
            2 => 'MonthlyStatus',
            3 => 'CreatedOn',
        );
        $response = array();
        $this->db->select('monthly.MonthlyID');
        $this->db->from('monthly');

        $this->db->join('usermapping um','monthly.UserID=um.UserID');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');

        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
        //$this->db->where('monthly.UserID', $userID);
        if(!empty($searchData['search_state'])){
            $this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
            $this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
            $this->db->where('monthly.UserID',$searchData['search_facility']);
        }
        if (!empty($searchData['search_months']) && empty($searchData['search_years'])) {
            $this->db->where('MONTH(monthly.ReportMonth)', $searchData['search_months']);
        }
        if (empty($searchData['search_months']) && !empty($searchData['search_years'])) {
            $this->db->where('YEAR(monthly.ReportMonth)', $searchData['search_years']);
        }
        if (!empty($searchData['search_months']) && !empty($searchData['search_years'])) {
            $search_date = $searchData['search_years'] . '-' . $searchData['search_months'] . '-01';
            $this->db->where('monthly.ReportMonth', $search_date);
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);
            if ($searchString == 'Completed') {
                $this->db->where("(monthly.MonthlyStatus='1')", NULL, FALSE);
            } else if ($searchString == 'Incomplete') {
                $this->db->where("(monthly.MonthlyStatus='0')", NULL, FALSE);
            } else {
                $this->db->where("(monthly.CollectionDate='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.CreatedOn='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.ReportMonth='" . date('Y-m-01', strtotime($searchString)) . "' OR f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        $queryTot = $this->db->get();

        $this->db->select('f.facilityName,s.StateName,d.DistrictName,monthly.MonthlyID,monthly.ReportMonth,monthly.CollectionDate,monthly.MonthlyStatus,monthly.CreatedOn');
        $this->db->from('monthly');

        $this->db->join('usermapping um','monthly.UserID=um.UserID');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');

        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
        //$this->db->where('monthly.UserID', $userID);
        if(!empty($searchData['search_state'])){
            $this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
            $this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
            $this->db->where('monthly.UserID',$searchData['search_facility']);
        }
        if (!empty($searchData['search_months']) && empty($searchData['search_years'])) {
            $this->db->where('MONTH(monthly.ReportMonth)', $searchData['search_months']);
        }
        if (empty($searchData['search_months']) && !empty($searchData['search_years'])) {
            $this->db->where('YEAR(monthly.ReportMonth)', $searchData['search_years']);
        }
        if (!empty($searchData['search_months']) && !empty($searchData['search_years'])) {
            $search_date = $searchData['search_years'] . '-' . $searchData['search_months'] . '-01';
            $this->db->where('monthly.ReportMonth', $search_date);
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);
            if ($searchString == 'Completed') {
                $this->db->where("(monthly.MonthlyStatus='1')", NULL, FALSE);
            } else if ($searchString == 'Incomplete') {
                $this->db->where("(monthly.MonthlyStatus='0')", NULL, FALSE);
            } else {
                $this->db->where("(monthly.CollectionDate='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.CreatedOn='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.ReportMonth='" . date('Y-m-01', strtotime($searchString)) . "' OR f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
        $this->db->limit($this->input->post('length'), $this->input->post('start'));
        $query = $this->db->get();

        $data['draw'] = $this->input->post('draw');
        $data['totalData'] = $queryTot->num_rows();
        $data['totalFilter'] = $queryTot->num_rows();
        $surveyFormLevel = array('1' => 'Base Line', '2' => 'Mid Line', '3' => 'Top Line');
        $dataget = array();
        $cnt=$searchData['start'];
        //$access_add=$this->CommonModel->checkPageActionWeb('facility/index','access_add',$this->session->userdata('RoleName'));
        $access_edit=$this->CommonModel->checkPageActionWeb('monthly/index','access_edit',$this->session->userdata('RoleName'));
        //$access_delete=$this->CommonModel->checkPageActionWeb('facility/index','access_delete',$this->session->userdata('RoleName'));
        $access_view=$this->CommonModel->checkPageActionWeb('monthly/index','access_view',$this->session->userdata('RoleName'));
        foreach ($query->result() as $key => $value) {
            $subdata = array();
            $subdata[]=++$cnt;
            $subdata[] = $value->StateName;
            $subdata[] = $value->DistrictName;
            $subdata[] = $value->facilityName;
            $subdata[] = date('F Y', strtotime($value->ReportMonth));
            $subdata[] = convert_date_show($value->CollectionDate);
            //$subdata[] = $value->MonthlyStatus ? 'Completed' : 'Incomplete';
            $subdata[]=$value->MonthlyStatus?'<span class="complete-status">Completed</span>':'<span class="incomplete-status">Incomplete</span>';
            $subdata[] = convert_date_show($value->CreatedOn);
            if (!$value->MonthlyStatus) {
                $actionLink='';
                if($access_edit){
                    $actionLink.='<button data-page="Edit" data-reqMonth="' . $value->ReportMonth . '" data-months="' . $value->MonthlyID . '" data-href="' . base_url() . 'monthly/add/' . encryptor($value->MonthlyID) . '" onclick="getPage(this)"  class="btn btn-primary btn-xs getScore view_edit_width" ><i class="glyphicon glyphicon-check"></i>Edit</button>';
                }                
                $subdata[] = $actionLink;
                $fromType = 'add';
            } else {
                $actionLink='';
                if($access_view){
                    $actionLink.='<button data-page="View" data-reqMonth="' . $value->ReportMonth . '" data-months="' . $value->MonthlyID . '" data-href="' . base_url() . 'monthly/view/' . encryptor($value->MonthlyID) . '" onclick="getPage(this)"  class="btn btn-primary btn-xs getScore view_edit_width" ><i class="glyphicon glyphicon-check"></i>View</button>';
                }                
                $subdata[] = $actionLink;
                $fromType = 'view';
            }

            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;

        return $data;
    }

    function checkMonthlyFacilityAdd($facilityUser) {
        if ($facilityUser) {
            $this->db->select('monthly.MonthlyID');
            $this->db->from('monthly');
            $this->db->where('monthly.UserID', $facilityUser);
            $this->db->where('monthly.ReportMonth', date('Y-m-01'));
            $result = $this->db->get();
            if ($result->num_rows() >= 1) {
                $response['code'] = $result->num_rows();
                $response['msg'] = $result->num_rows() . ' data get';
            } else {
                $response['code'] = '0';
                $response['msg'] = $result->num_rows() . ' data get';
            }
        } else {
            $response['code'] = '14';
            $response['msg'] = 'No Proper Data Submitted';
        }
        return $response;
    }

    function monthReportCheck($dateRpt, $facilityUser) {
        if ($facilityUser) {
            $this->db->select('monthly.MonthlyID,monthly.MonthlyStatus');
            $this->db->from('monthly');
            $this->db->where('monthly.UserID', $facilityUser);
            $this->db->where('monthly.ReportMonth', $dateRpt);
            $result = $this->db->get();
            $monthId = 0;
            if ($result->num_rows() >= 1) {
                $data = $result->result_array();
                if (isset($data[0]['MonthlyID'])) {
                    $monthId = $data[0]['MonthlyID'];
                } else {
                    $monthId = 0;
                }
                if ($data[0]['MonthlyStatus']) {
                    $response['code'] = '0';
                    $response['data'] = '<button data-page="View" id="redirectBtn" data-href="' . base_url() . 'monthly/view/' . encryptor($monthId) . '" onclick="getPage(this)" data-reqMonth="' . $dateRpt . '" data-months="' . $monthId . '" class="btn btn-primary getScore pull-right" >View</button>';
                    $response['monthId'] = $monthId;
                    $response['page'] = 'View';
                    $response['msg'] = ' View Page';
                } else {
                    $response['code'] = '0';
                    $response['data'] = '<button id="redirectBtn" data-page="Edit" data-href="' . base_url() . 'monthly/add/' . encryptor($monthId) . '" onclick="getPage(this)" data-reqMonth="' . $dateRpt . '" data-months="' . $monthId . '" class="btn btn-primary getScore pull-right" >Edit</button>';
                    $response['monthId'] = $monthId;
                    $response['page'] = 'Edit';
                    $response['msg'] = ' Edit Page';
                }
            } else {
                $response['code'] = '0';
                $response['data'] = '<button id="redirectBtn" data-page="Add" data-href="' . base_url() . 'monthly/add/' . encryptor($monthId) . '" onclick="getPage(this)" data-reqMonth="' . $dateRpt . '" data-months="0" class="btn btn-primary getScore" >Add</button>';
                $response['monthId'] = '0';
                $response['page'] = 'Add';
                $response['msg'] = ' Add Page';
            }
        } else {
            $response['code'] = '14';
            $response['msg'] = 'No Proper Data Submitted';
        }
        return $response;
    }

    function getSearchMonthlyReportQuery($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility) {
//        echo "AD";
        $this->db->select('s.StateName,d.DistrictName,f.FacilityName,f.FacilityNumber,f.stateID,f.districtId,um.UserID,m.*,ot.BaselineNQASChecklistLR,ot.BaselineNQASChecklistOT,ot.QualityTeamFacility,ot.QualityCircleLR,ot.QualityCircleOT,ot.OrientationAttended,ot.BaselineScoreOT,ot.BaselineScoreLR');
        $this->db->from('monthly as m');
        $this->db->join('onetime as ot', 'ot.UserID= m.UserID', 'inner');
        $this->db->join('usermapping as um', 'um.UserID= m.UserID', 'inner');
        $this->db->join('facilities as f', 'f.FacilityID= um.FacilityID', 'inner');
        $this->db->join('states as s', 's.StateID=f.StateID', 'inner');
        $this->db->join('district as d', 'd.DistrictID=f.DistrictID', 'inner');
        if ($this->session->userdata('RoleName') == 'State') {
            $MappedState = $this->session->userdata('MappedState');
            if ($MappedState != '') {
                $MappedStateArray = explode(",", $MappedState);
                $this->db->where_in('f.StateID', $MappedStateArray);
            }
        } else if ($this->session->userdata('RoleName') == 'District') {
            $MappedDistrict = $this->session->userdata('MappedDistrict');
            if ($MappedDistrict != '') {
                $MappedDistrictArray = explode(",", $MappedDistrict);
                $this->db->where_in('f.DistrictID', $MappedDistrictArray);
            }
        } 
        else if ($this->session->userdata('RoleName') == 'Facility') {
            $userID = $this->session->userdata('UserID');
            $this->db->where('um.UserID', $userID);
        }

//        $this->db->where('monthly.UserID', $userID);
        if (!empty($search_months) && empty($search_years)) {
//            print_r($search_years); die;
            $this->db->where('MONTH(m.ReportMonth)', $search_months);
        }
        if (empty($search_months) && !empty($search_years)) {
            $this->db->where('YEAR(m.ReportMonth)', $search_years);
        }
        if (!empty($search_months) && !empty($search_years)) {
            $search_date = $search_years . '-' . $search_months . '-01';
            $this->db->where('m.ReportMonth', $search_date);
        }
        //
        if (!empty($search_state)) {
//            print_r($search_years); die;
            $this->db->where('f.StateID', $search_state);
        }
        if (!empty($search_district)) {
//            print_r($search_years); die;
            $this->db->where('f.DistrictID', $search_district);
        }
        if (!empty($search_facility)) {
//            print_r($search_years); die;
            $this->db->where('um.UserID', $search_facility);
        }
         $this->db->order_by('m.ReportMonth', 'DESC');
        //

        /*if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);
            if ($searchString == 'Completed') {
                $this->db->where("(monthly.MonthlyStatus='1')", NULL, FALSE);
            } else if ($searchString == 'Incomplete') {
                $this->db->where("(monthly.MonthlyStatus='0')", NULL, FALSE);
            } else {
                $this->db->where("(monthly.CollectionDate='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.CreatedOn='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.ReportMonth='" . date('Y-m-01', strtotime($searchString)) . "')", NULL, FALSE);
            }
        }*/
    }
    function count_filtered_getSearchMonthlyReportData($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility) {
        $this->getSearchMonthlyReportQuery($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility);
        $query = $this->db->get();
        return $query->num_rows();
    }
    function getSearchMonthlyReportData($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility) {
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
        $col = array(0 => 's.StateName', 1 => 'd.DistrictName', 2 => 'f.FacilityName', 3 => 'f.FacilityName',);
        $response = array();
        $this->getSearchMonthlyReportQuery($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility);
        //$this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
        $this->db->order_by('f.FacilityName', 'ASC');
        $this->db->limit($this->input->post('length'), $this->input->post('start'));
        $query = $this->db->get();
//print_r($this->db->last_query());
        $data['draw'] = $this->input->post('draw');
        $data['totalData'] = $this->count_filtered_getSearchMonthlyReportData($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility);
        $data['totalFilter'] = $data['totalData'];

        $dataget = array();
        //echo "<pre>";
//print_r($subdata);
        $cnt=$this->input->post('start');
        foreach ($query->result() as $key => $value) {
            $subdata = array();
            $subdata[]=++$cnt;
            if (isset($search_options['State'])) {
                $subdata[] = $value->StateName;
            }
            if (isset($search_options['District'])) {
                $subdata[] = $value->DistrictName;
            }
            if (isset($search_options['Facility'])) {
                $subdata[] = $value->FacilityName;
            }
            $subdata[] = date('F Y', strtotime($value->ReportMonth));

            // indicator-1: C70+C73
            // indicator-1: BaselineNQASChecklistLR || $value->BaselineNQASChecklistOT
            // indicator-1: baseline completed (LR AND OT)
            if($value->BaselineNQASChecklistLR==1 || $value->BaselineNQASChecklistOT==1){
                $ind1='YES';
            } else {
                $ind1='No';
            }
            $subdata[] = $ind1;

            // indicator-2: C79+C80+C81
            // indicator-2: QualityTeamFacility+QualityCircleLR+QualityCircleOT
            // indicator-2: (Facility has setup facility level quality team)+(Facility has setup functional quality circle in Labour Room)+(Facility has setup functional quality circle in Maternity OT)
            // indicator-2: (QualityTeamFacility) || (QualityCircleLR) || (QualityCircleOT)
            if($value->QualityTeamFacility==1 || $value->QualityCircleLR==1 || $value->QualityCircleOT==1){
                $ind2='YES';
            } else {
                $ind2='No';
            }
            $subdata[] = $ind2;

            // indicator-3: C82
            // indicator-3: OrientationAttended
            // indicator-3: (Facility staff of LR and OT quality circles have attended district level or facility level orientation on LR Protocols, QI processes and RMC)
            // indicator-3: OrientationAttended
            if($value->OrientationAttended==1){
                $ind3='YES';
            } else {
                $ind3='No';
            }
            $subdata[] = $ind3;

            // indicator-4: c38*100/c11+c12
            // indicator-4: BirthCompanionNos*100/(TotalNormalVaginalDeliveries+TotalAssistedVaginalDeliveries)
            // indicator-4: (Number of normal deliveries conducted in presence of Birth Companion)*100/(Total Number of Normal Vaginal Deliveries)+(Total Number of Assisted Vaginal Deliveries)
            if(($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)>0){
                $ind4=($value->BirthCompanionNos*100)/($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries);
            } else {
                $ind4=0;
            }
            $subdata[] = formatValue($ind4);

            // indicator-5: c39*100/c11+c12
            // indicator-5: SafeBirthChecklist*100/(TotalNormalVaginalDeliveries+TotalAssistedVaginalDeliveries)
            // indicator-5: (Number of normal deliveries conducted using Safe Birth Checklist)*100/(Total Number of Normal Vaginal Deliveries)+(Total Number of Assisted Vaginal Deliveries)
            if(($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)>0){
                $ind5=($value->SafeBirthChecklist*100)/($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries);
            } else {
                $ind5=0;
            }
            $subdata[] = formatValue($ind5);

            // indicator-6: c40*100/c13
            // indicator-6: CSectionOTSafeChecklist*100/TotalCSections
            // indicator-6: (Number of planned and emergency C-Section operations where safe surgical checklist was used)*100/(Total Number of C-Sections)
            if($value->TotalCSections>0){
                $ind6=($value->CSectionOTSafeChecklist*100)/$value->TotalCSections;
            } else {
                $ind6=0;
            }
            $subdata[] = formatValue($ind6);

            // indicator-7: c41*100/c11+c12
            // indicator-7: RealTimePartograph*100/(TotalNormalVaginalDeliveries+TotalAssistedVaginalDeliveries)
            // indicator-7: (Number of normal deliveries conducted using real time Partograph)*100/(Total Number of Normal Vaginal Deliveries)+(Total Number of Assisted Vaginal Deliveries)
            if($value->TotalNormalVaginalDeliveries+$value->TotalAssistedVaginalDeliveries>0){
                $ind7=($value->RealTimePartograph*100)/($value->TotalNormalVaginalDeliveries+$value->TotalAssistedVaginalDeliveries);
            } else {
                $ind7=0;
            }
            $subdata[] = formatValue($ind7);

            // indicator-8: c42*100/(c13+c12+c11)
            // indicator-8: BreastfedNewborns*100/(TotalNormalVaginalDeliveries+TotalAssistedVaginalDeliveries+TotalCSections)
            // indicator-8: (Number of newborns delivered in facility who were breastfed within one hour of delivery)*100/(Total Number of Normal Vaginal Deliveries)+(Total Number of Assisted Vaginal Deliveries)+(Total Number of C-Sections)
            if($value->TotalAssistedVaginalDeliveries+$value->TotalNormalVaginalDeliveries+$value->TotalCSections>0){
                $ind8=($value->BreastfedNewborns*100)/($value->TotalAssistedVaginalDeliveries + $value->TotalNormalVaginalDeliveries + $value->TotalCSections);
            } else {
                $ind8=0;
            }
            $subdata[] = formatValue($ind8);

            // indicator-9: c47*100/(c11+c12+c13)
            // indicator-9: NewbornsSNCUAsphyxia*100/(TotalNormalVaginalDeliveries+TotalAssistedVaginalDeliveries+TotalCSections)
            // indicator-9: (Number of newborns delivered in facility developed birth asphyxia) * 100 / (Total Number of Normal Vaginal Deliveries)+(Total Number of Assisted Vaginal Deliveries)+(Total Number of C-Sections)
            if(($value->TotalNormalVaginalDeliveries+$value->TotalAssistedVaginalDeliveries+$value->TotalCSections)>0){
                $ind9=($value->NewbornsSNCUAsphyxia*100)/($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections);
            } else {
                $ind9=0;
            }
            $subdata[] = formatValue($ind9);

            // indicator-10: c48*100/( c11+c12+c13 )   
            // indicator-10: NewbornsSNCUSepsis*100/(TotalNormalVaginalDeliveries+TotalAssistedVaginalDeliveries+TotalCSections)
            // indicator-10: (Number of newborns delivered in facility developed sepsis)*100/(Total Number of Normal Vaginal Deliveries)+(Total Number of Assisted Vaginal Deliveries)+(Total Number of C-Sections)
            if(($value->TotalNormalVaginalDeliveries+$value->TotalAssistedVaginalDeliveries+$value->TotalCSections)>0){
                $ind10=($value->NewbornsSNCUSepsis*100)/($value->TotalNormalVaginalDeliveries+$value->TotalAssistedVaginalDeliveries+$value->TotalCSections);
            } else {
                $ind10=0;
            }
            $subdata[] = formatValue($ind10);

            // indicator-11: c45*100/c13
            // indicator-11: CSectionsInfection*100/TotalCSections
            // indicator-11: (Number of C-Sections operations in which surgical site infection developed within one month of operation)*100/(Total Number of C-Sections)
            if($value->TotalCSections>0){
                $ind11=($value->CSectionsInfection*100)/$value->TotalCSections;
            } else {
                $ind11=0;
            }
            $subdata[] = formatValue($ind11);

            // indicator-12: c46*100/c35
            // indicator-12: PretermANCSInFacilitiesSNCU*100/TotalPretermDeliveries
            // indicator-12: (Number of preterm cases where Antenatal Corticosteroids (ANCS) was administered in facilities)*100/(Total no. of Preterm Deliveries)
            if($value->TotalPretermDeliveries>0){
                $ind12=($value->PretermANCSInFacilitiesSNCU*100)/$value->TotalPretermDeliveries;
            } else {
                $ind12=0;
            }
            $subdata[] = formatValue($ind12);

            // indicator-13: c20*100/c14
            // indicator-13: MaternalPIHEclampsia*100/TotalMaternalDeaths
            // indicator-13: (PIH/Eclampsia)*100/(Total number of maternal deaths)
            if($value->TotalMaternalDeaths>0){
                $ind13=($value->MaternalPIHEclampsia*100)/$value->TotalMaternalDeaths;
            } else {
                $ind13=0;
            }
            $subdata[] = formatValue($ind13);

            // indicator-14: (c16+c17)*100/c14
            // indicator-14: (MaternalAPH+MaternalPPH)*100/TotalMaternalDeaths
            // indicator-14: (APH+PPH)*100/(Total number of maternal deaths)
            if($value->TotalMaternalDeaths>0){
                $ind14=(($value->MaternalAPH + $value->MaternalPPH)*100)/$value->TotalMaternalDeaths;
            } else {
                $ind14=0;
            }
            $subdata[] = formatValue($ind14);

            // indicator-15: c52
            // indicator-15: ReorganizedLR
            // indicator-15: Whether facility has reorganized labour room as per the guidelines?
            if($value->ReorganizedLR==1){
                $ind15='YES';
            } else {
                $ind15='NO';
            }
            $subdata[] = $ind15;

            // indicator-16: c53
            // indicator-16: AdequateStaffLR
            // indicator-16: Whether facility has adequate staff at labour rooms as per defined norms
            if($value->AdequateStaffLR==1){
                $ind16='YES';
            } else {
                $ind16='NO';
            }
            $subdata[] = $ind16;

            // indicator-17: c54*100/(c11+c12)
            // indicator-17: OxytocinCount*100/(TotalNormalVaginalDeliveries+TotalAssistedVaginalDeliveries)
            // indicator-17: (Number of deliveries conducted in facility where Oxytocin was administered within one minute of birth)*100/(Total Number of Normal Vaginal Deliveries)+(Total Number of Assisted Vaginal Deliveries)
            if($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries>0){
                $ind17=($value->OxytocinCount*100)/($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries);
            } else {
                $ind17=0;
            }
            $subdata[] = formatValue($ind17);

            // indicator-18: wrong get from form
            // indicator-18: C68
            // indicator-18: CurrentOSCEScore 
            // indicator-18: current osce score (remove) from form
            $ind18=$value->CurrentOSCEScore;
            $subdata[] = formatValue($ind18);

            // indicator-19: c58
            // indicator-19: ReferralCases
            // indicator-19: Number of Referral cases reviewed in the month 
            $ind19=$value->ReferralCases;
            $subdata[] = formatValue($ind19);

            // indicator-20: MaternalDeathsReviewed+NeonatalDeaths+MaternalMissCases
            // indicator-20: (Number of maternal deaths were reviewed in last month) + (Number of neonatal deaths were reviewed in last month) + (Number of Maternal Near Miss Cases were reviewed in last month)
            $ind20=$value->MaternalDeathsReviewed + $value->NeonatalDeaths + $value->MaternalMissCases;
            $subdata[] = formatValue($ind20);

            // indicator-21: c60
            // indicator-21: StockOutsInOT
            // indicator-21: Whether there was any stock outs of drugs and consumables in maternity OT
            if($value->StockOutsInOT==1){
                $ind21='YES';
            } else {
                $ind21='NO';
            }
            $subdata[] = $ind21;

            // indicator-22: (c25+c26)*100/(c11+c12+c13)
            // indicator-22: (TotalFreshStillBirths+TotalMaceratedStillBirths)*100/ (TotalNormalVaginalDeliveries+TotalAssistedVaginalDeliveries+TotalCSections)
            // indicator-22: (Total number of Fresh Still births)+(Total number of macerated still births)*100/(Total Number of Normal Vaginal Deliveries)+(Total Number of Assisted Vaginal Deliveries)+(Total Number of C-Sections)
            if($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections>0){
                $ind22=(($value->TotalFreshStillBirths + $value->TotalMaceratedStillBirths)*100)/($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections);
            } else {
                $ind22=0;
            }
            $subdata[] = formatValue($ind22);

            // indicator-23: SatisfiedDelivered * 100 / (TotalNormalVaginalDeliveries+TotalAssistedVaginalDeliveries+TotalCSections);
            // indicator-23: (Number of beneficiaries delivered last month who were either satisfied or highly satisfied)*100/(Total Number of Normal Vaginal Deliveries)+(Total Number of Assisted Vaginal Deliveries)+(Total Number of C-Sections)
            // =TotalDeliveries(Total Number of Deliveries)
            if($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections>0){
                $ind23=($value->SatisfiedDelivered*100)/($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections);
            } else {
                $ind23=0;
            }
            $subdata[] = formatValue($ind23);

            // indicator-24: c62
            // indicator-24: MCHDHFunctional
            // indicator-24: Whether MCH/DH has functional Obs ICU/Hybrid ICU/HDU
            if($value->MCHDHFunctional==1){
                $ind24='YES';
            } else {
                $ind24='NO';
            }
            $subdata[] = $ind24;

            // indicator-25: c43+c44;
            // indicator-25: MCBSamplingLR + MCBSamplingOT;
            // indicator-25: (Whether microbiological sampling from labour room is collected as per protocol) + (Whether microbiological sampling from Maternity OT is collected as per protocol);
            if($value->MCBSamplingLR==1 || $value->MCBSamplingOT==1){
                $ind25='YES';
            } else {
                $ind25='NO';
            }
            $subdata[] = $ind25;

            // indicator-26: (c66-c72)*100/c72;
            // indicator-26: (CurrentLabourRoomQualityScore-BaselineScoreLR)*100/BaselineScoreLR;
            // indicator-26: (Current Labour Room Quality Score)-(Baseline Score for Labour Room)*100 / (Baseline Score for Labour Room);
            if($value->BaselineScoreLR>0){
                $ind26=(($value->CurrentLabourRoomQualityScore-$value->BaselineScoreLR)*100)/$value->BaselineScoreLR;
            } else {
                $ind26=0;
            }
            $subdata[] = formatValue($ind26);

            // indicator-27: (c67-c75)*100/c75;
            // indicator-27: (CurrentMaternityOTQualityScore - BaselineScoreOT)*100/BaselineScoreOT;
            // indicator-27: (Current Maternity OT Quality Score) - (Baseline Score for Operation Theatre)*100 / (Baseline Score for Operation Theatre);
            if($value->BaselineScoreOT>0){
                $ind27=(($value->CurrentMaternityOTQualityScore-$value->BaselineScoreOT)*100)/$value->BaselineScoreOT;
            } else {
                $ind27=0;
            }
            $subdata[] = formatValue($ind27);

            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;
//echo "<pre>";
//print_r($subdata);
        return $data;
    }

    function reportData_certificate($searchData){
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
        $col = array(0 => 's.StateName', 1 => 'd.DistrictName', 2 => 'f.FacilityName', 3 => 'f.FacilityName',);

        $this->db->select('applied_date,status,userID');
        $this->db->from('certification');
        $this->db->where('CertificationID',encryptor($searchData['CertificationID'],'decrypt'));
        $query = $this->db->get();
        $certificateData=$query->row_array();

        $dateArray=array(
            Date("Y-m-01", strtotime($certificateData['applied_date']." -1 Month")),
            Date("Y-m-01", strtotime($certificateData['applied_date']." -2 Month")),
            Date("Y-m-01", strtotime($certificateData['applied_date']." -3 Month"))
        );

        $this->db->select('s.StateName,d.DistrictName,f.FacilityName,f.FacilityNumber,f.stateID,f.districtId,um.UserID,m.*,ot.BaselineNQASChecklistLR,ot.BaselineNQASChecklistOT,ot.QualityTeamFacility,ot.QualityCircleLR,ot.QualityCircleOT,ot.OrientationAttended,ot.BaselineScoreOT,ot.BaselineScoreLR');
        $this->db->from('monthly as m');
        $this->db->join('onetime as ot', 'ot.UserID= m.UserID', 'inner');
        $this->db->join('usermapping as um', 'um.UserID= m.UserID', 'inner');
        $this->db->join('facilities as f', 'f.FacilityID= um.FacilityID', 'inner');
        $this->db->join('states as s', 's.StateID=f.StateID', 'inner');
        $this->db->join('district as d', 'd.DistrictID=f.DistrictID', 'inner');
        if (!empty($certificateData['userID'])) {
            $this->db->where('um.UserID', $certificateData['userID']);
        }
        if(!empty($searchData['monthCount'])){
            $this->db->where('m.ReportMonth', Date("Y-m-01", strtotime($certificateData['applied_date']." -".encryptor($searchData['monthCount'],'decrypt')." Month")));
        } else {
            $this->db->where_in('m.ReportMonth', $dateArray);
        }

        $this->db->order_by('m.ReportMonth', 'DESC');
        $query = $this->db->get();
        
        $data['draw'] = $this->input->post('draw');
        $data['totalFilter'] = $query->num_rows();
        $data['totalData'] = $query->num_rows();

        $dataget = array();
        foreach ($query->result() as $key => $value) {
            $subdata = array();
            if (isset($search_options['State'])) {
                $subdata[] = $value->StateName;
            }
            if (isset($search_options['District'])) {
                $subdata[] = $value->DistrictName;
            }
            if (isset($search_options['Facility'])) {
                $subdata[] = $value->FacilityName;
            }
            $subdata[] = date('F Y', strtotime($value->ReportMonth));
            $subdata[] = ($value->BaselineNQASChecklistLR==1 && $value->BaselineNQASChecklistOT==1)?'YES':'No' ;
            $subdata[] = ($value->QualityTeamFacility==1 || $value->QualityCircleLR==1 || $value->QualityCircleOT==1)?'YES':'NO';
            $subdata[] = ($value->OrientationAttended==1)?'YES':'NO';
            $subdata[] = ($value->BirthCompanionNos==0)?0:formatValue(($value->BirthCompanionNos * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c38*100/c11+c12
            $subdata[] = ($value->SafeBirthChecklist==0)?0:formatValue(($value->SafeBirthChecklist * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c39*100/c11+c12
            $subdata[] = ($value->CSectionOTSafeChecklist==0)?0:formatValue(($value->CSectionOTSafeChecklist * 100) / $value->TotalCSections); // c40*100/c13
            $subdata[] = ($value->RealTimePartograph==0)?0:formatValue(($value->RealTimePartograph * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c41*100/c11+c12
            $subdata[] = ($value->BreastfedNewborns==0)?0:formatValue(($value->BreastfedNewborns * 100) / ($value->TotalAssistedVaginalDeliveries + $value->TotalNormalVaginalDeliveries + $value->TotalCSections)); // c42*100/(c13+c12+c11)
            $subdata[] = ($value->NewbornsSNCUAsphyxia==0)?0:formatValue(($value->NewbornsSNCUAsphyxia * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //c47*100/(c11+c12+13)
            $subdata[] = ($value->NewbornsSNCUSepsis==0)?0:formatValue(($value->NewbornsSNCUSepsis * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //c48*100/(c11+c12+13)
            $subdata[] = ($value->CSectionsInfection==0)?0:formatValue(($value->CSectionsInfection * 100) / ($value->TotalCSections)); // c45*100/c13
            $subdata[] = ($value->PretermANCSInFacilitiesSNCU==0)?0:formatValue(($value->PretermANCSInFacilitiesSNCU * 100) / ($value->TotalPretermDeliveries)); //c46*100/c35
            $subdata[] = ($value->MaternalPIHEclampsia==0)?0:formatValue(($value->MaternalPIHEclampsia * 100) / ($value->TotalMaternalDeaths)); // c20*100/c14
            $subdata[] = ($value->MaternalAPH + $value->MaternalPPH==0)?0:formatValue((($value->MaternalAPH + $value->MaternalPPH) * 100) / ($value->TotalMaternalDeaths)); // (c16+c17)*100/c14
            $subdata[] = ($value->ReorganizedLR==1)?'YES':'NO'; // c52
            $subdata[] = ($value->AdequateStaffLR==1)?'YES':'NO'; //c53
            $subdata[] = ($value->OxytocinCount==0)?0:formatValue(($value->OxytocinCount * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c54*100/(c11+c12)
            $subdata[] = ''; //current osce score (remove) from form
            $subdata[] = $value->ReferralCases; //c58
            $subdata[] = $value->MaternalDeathsReviewed + $value->NeonatalDeaths + $value->MaternalMissCases; //c55+c56+c57
            $subdata[] = ($value->StockOutsInOT==1)?'YES':'NO'; //c60
            $subdata[] = ($value->TotalFreshStillBirths + $value->TotalMaceratedStillBirths==0)?0:formatValue((($value->TotalFreshStillBirths + $value->TotalMaceratedStillBirths) * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //(c25+c26)*100/(c11+c12+c13)
            $subdata[] = ($value->SatisfiedDelivered==0)?0:formatValue(($value->SatisfiedDelivered * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //(c51)*100/(c11+c12+c13);
            $subdata[] = ($value->MCHDHFunctional==1)?'YES':'NO'; //c62
            $subdata[] = ($value->MCBSamplingLR==1 && $value->MCBSamplingOT==1)?'YES':'NO'; //c43+c44;
            $subdata[] =   (($value->CurrentLabourRoomQualityScore-$value->BaselineScoreLR*100)>0)?formatValue(($value->CurrentLabourRoomQualityScore-$value->BaselineScoreLR*100)/$value->BaselineScoreLR):0; //(c66-c72)*100/c72;
            $subdata[] = (($value->CurrentMaternityOTQualityScore-$value->BaselineScoreOT*100)>0)?formatValue(($value->CurrentMaternityOTQualityScore-$value->BaselineScoreOT*100)/$value->BaselineScoreOT):0;  //c67-c75*100/c75;




            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;
        if(!empty($searchData['monthCount'])){
            $data['monthdate'] = Date("F Y", strtotime($certificateData['applied_date']." -".encryptor($searchData['monthCount'],'decrypt')." Month"));
        } else {
            $data['monthdate'] = 'Last three months';
        }
        return $data;

    }
    function setMonthlyData($MonthlyID){
        $this->db->select('m.UserID,m.ReportMonth');
        $this->db->from('monthly as m');
        $this->db->where('m.MonthlyID', encryptor($MonthlyID,'decrypt'));
        $query = $this->db->get();
        $data=$query->row_array();
        $this->session->set_userdata('facilityUser', $data['UserID']);
        $this->session->set_userdata('setDataMonth', $data['ReportMonth']);
    }
    function getMonthlyUser($MonthlyID){
        $this->db->select('m.UserID');
        $this->db->from('monthly as m');
        $this->db->where('m.MonthlyID', encryptor($MonthlyID,'decrypt'));
        $query = $this->db->get();
        $data=$query->row_array();
        return $data['UserID'];
    }

}
