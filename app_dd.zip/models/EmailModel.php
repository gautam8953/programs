<?php

class EmailModel extends CI_Model {
	function __construct() {
		parent::__construct();
	}
    function send_laqshya_mail($data){
    	$userID=@$this->session->userdata('UserID');
    	$mailInsertlog=array('err'=>'','email_to'=>'','mail_sent'=>'faild','userid'=>$userID);
        $ci = get_instance();
        $ci->load->library('email');
        $config=$this->config->item('email_config');
        $ci->email->initialize($config);
        $ci->email->from($this->config->item('email_from_main'), $this->config->item('email_name_main'));
        if(isset($data['msg_fun']) && !empty($data['msg_fun'])){
            $msg=call_user_func_array(array($this, $data['msg_fun']), array($data['details']));
            //$msg=$this->EmailModel->$data['msg_fun']($data['details']);
            if(!empty($msg)){
        		$ci->email->message($msg);            	
            }
            $mailInsertlog['msg_fun']=$data['msg_fun'];
            $mailInsertlog['msg']=$msg;
        } else {
        	$mailInsertlog['msg_fun']='';
        }
        if(!empty($data['subject'])){
        	$subject=$data['subject'];
        } else {
        	$subject='Team LaQshya';
        }
        $ci->email->subject($subject);
        $mailInsertlog['subject']=$subject;
        if(!empty($data['to'])){
	        $ci->email->to($data['to']);
	        $mailInsertlog['email_to']=$data['to'];
	        $sendmail=$ci->email->send();
	        if($sendmail){
	        	$mailInsertlog['mail_sent']='sucess';
	        } else {
	        	$error=array();
				ob_start();
				$this->email->print_debugger();
				$error = ob_end_clean();
				$mailInsertlog['err']=$error;
	        }
        }
        if(!empty($data['form_url'])){
            $mailInsertlog['form_url']=$data['form_url'];
        }
        if(!empty($data['form_name'])){
            $mailInsertlog['form_name']=$data['form_name'];
        }
        $mailInsertlog['ip']=$this->input->ip_address();
        $this->db->insert('mail_log', $mailInsertlog);
        if($sendmail){
        	return true;
        } else {
        	return false;
        }
    }
	function update_password($data){
		ob_start();
		?>
<p>Hi <?php echo $data['name']; ?>,</p>
<p>Your LaQshya account password has changed successfully. Your new password is <?php echo $data['pswrd']; ?>.</p>
<p>if you have not changed the password please contact Administrator.</p>
		<?php
		$content = ob_get_contents();
		ob_end_clean();
		return $content;		
	}
	function certification_insert($data){
		ob_start();
		?>
<p>Hi <?php echo $data['name']; ?>,</p>
<p>Your LaQshya Certification has applied.</p>
		<?php
		$content = ob_get_contents();
		ob_end_clean();
		return $content;		
	}
    function user_creation($data){
        ob_start();
        ?>
<p>Hi <?php echo $data['name']; ?>,</p>
<p>Your LaQshya account has created sucessfully.</p>
<p>
username: <?php echo $data['username'] ?></br>
password: <?php echo $data['password'] ?></br>
</p>
        <?php
        $content = ob_get_contents();
        ob_end_clean();
        return $content;        
    }	




}