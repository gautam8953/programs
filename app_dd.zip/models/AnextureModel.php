<?php

class AnextureModel extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	function getSearchData($searchData){
		$data=array('draw'=>0,'totalData'=>0,'totalFilter'=>0,'data'=>array());
		$col=array();
		if(!empty($this->session->userdata('showState'))){
			$col[]='s.StateName';
		}
		if(!empty($this->session->userdata('showDistrict'))){
			$col[]='d.DistrictName';
		}
		if(!empty($this->session->userdata('showFacilities'))){
			$col[]='f.facilityName';
		}
		$col[]='anexture.submitDate';
		$col[]='anexture.isDraft';

	  	$this->db->select('anexture.anextureID');
	    $this->db->from('anexture');
		$this->db->join('usermapping um','anexture.UserID=um.UserID AND um.IsActive=1');
		$this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
		$this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
		$this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
		if(!empty($searchData['cond'])){
			$this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
		}
	    $this->db->where('anexture.IsActive','1');
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            $this->db->where("(anexture.submitDate='%".$searchString."%' OR f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%' )", NULL, FALSE);
        }
        if(!empty($searchData['search_state'])){
        	$this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
        	$this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
        	$this->db->where('anexture.UserID',$searchData['search_facility']);
        }
	    $queryTot = $this->db->get();

	    $this->db->select('f.facilityName,s.StateName,d.DistrictName,anexture.submitDate,anexture.isDraft,anexture.anextureID');
	    $this->db->from('anexture');
		$this->db->join('usermapping um','anexture.UserID=um.UserID');
		$this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
		$this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
		$this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
		if(!empty($searchData['cond'])){
			$this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
		}
	    $this->db->where('anexture.IsActive','1');
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            $this->db->where("(anexture.submitDate='%".$searchString."%' OR f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%' )", NULL, FALSE);
        }
        if(!empty($searchData['search_state'])){
        	$this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
        	$this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
        	$this->db->where('anexture.UserID',$searchData['search_facility']);
        }
        if($searchData['order'][0]['column']>0){
        	$colNo=$searchData['order'][0]['column']-1;
        } else {
        	$colNo=$searchData['order'][0]['column'];
        }
	    $this->db->order_by($col[$colNo], $searchData['order'][0]['dir']);
	    if($searchData['length']>0){
	    	$this->db->limit($this->input->post('length'),$this->input->post('start'));
		}
	    $query = $this->db->get();
	    

		$data['draw']=$this->input->post('draw');
		$data['totalData']=$queryTot -> num_rows();
		$data['totalFilter']=$queryTot -> num_rows();
		//$surveyFormLevel=$this->config->item('assesmentSequence');
		$dataget=array();
		$cnt=$searchData['start'];
		$access_edit=$this->CommonModel->checkPageActionWeb('anexture/index','access_edit',$this->session->userdata('RoleName'));
		$access_view=$this->CommonModel->checkPageActionWeb('anexture/index','access_view',$this->session->userdata('RoleName'));
		foreach ($query->result() as $key => $value) {
		    $subdata=array();
		    $subdata[]=++$cnt;
		    if($this->session->userdata('showState')){
		    	$subdata[]=$value->StateName;		    	
		    }
		    if($this->session->userdata('showDistrict')){
		    	$subdata[]=$value->DistrictName;		    	
		    }
		    if($this->session->userdata('showFacilities')){
		    	$subdata[]=$value->facilityName;		    	
		    }
		    $subdata[]=convert_date_show($value->submitDate);
		    $subdata[]=($value->isDraft==0)?'<span class="complete-status">Completed</span>':'<span class="incomplete-status">Incomplete</span>';
		    $actionLink='';
		    if($value->isDraft==1){
			    if($access_edit){
			    	$actionLink.='<button data-href="'.base_url().'anexture/add/'.encryptor($value->anextureID).'" onclick="pageRedirect(this)" data-ans="'.$value->anextureID.'" class="btn btn-primary btn-xs " ><i class="fa fa-floppy-o"></i> Edit</button>';
			    }			    			    
		    	$subdata[]=$actionLink;
		    } else {
			    if($access_view){
			    	$actionLink.='<button data-href="'.base_url().'anexture/view/'.encryptor($value->anextureID).'" onclick="pageRedirect(this)" class="btn btn-primary btn-xs " ><i class="fa fa-floppy-o"></i> View</button>';
			    }			    			    
		    	$subdata[]=$actionLink;
		    }
		    $dataget[]=$subdata;
		}
		$data['data']=$dataget;

		return $data;

	}

	function saveData($saveData){
		if(!empty($saveData['anextureID'])){
			$anextureID=encryptor($saveData['anextureID'],'decrypt');
			unset($saveData['anextureID']);
			$this->db->where('anextureID', $anextureID);
			$this->db->update('anexture', $saveData);
		} else {
		    if($this->db->insert('anexture', $saveData)){
				$anextureID=$this->db->insert_id();
			} else {
				$anextureID=0;
			}			
		}
		return $anextureID;
	}
	function anextureview($anextureID=null){
	    $this->db->select('anexture.*,f.facilityName,s.StateName,d.DistrictName');
	    $this->db->from('anexture');
        $this->db->join('usermapping as um', 'um.UserID= anexture.UserID', 'inner');
        $this->db->join('facilities as f', 'f.FacilityID= um.FacilityID', 'inner');
        $this->db->join('states as s', 's.StateID=f.StateID', 'inner');
        $this->db->join('district as d', 'd.DistrictID=f.DistrictID', 'inner');
	    $this->db->where('anexture.anextureID',encryptor($anextureID,'decrypt'));
	    $query = $this->db->get();
	    if($query -> num_rows()>0){
	    	$result=$query->row_array();
	    	//print_r($result);
	    	$dataget=array(
	    		'search_state'=>$result['StateName'],
	    		'search_district'=>$result['DistrictName'],
	    		'facilityName'=>$result['facilityName'],
	    		'submitDate'=>$result['submitDate'],
	    		'submitDate'=>$result['submitDate'],
	    		'checklist_1'=>$result['checklist_1'],
	    		'checklist_2'=>$result['checklist_2'],
	    		'checklist_3'=>$result['checklist_3'],
	    		'checklist_4'=>$result['checklist_4'],
	    		'checklist_5'=>$result['checklist_5'],
	    		'checklist_6'=>$result['checklist_6'],
	    		'checklist_7'=>$result['checklist_7'],
	    		'checklist_8'=>$result['checklist_8'],
	    		'checklist_9'=>$result['checklist_9'],
	    		'checklist_10'=>$result['checklist_10'],
	    		'checklist_11'=>$result['checklist_11'],
	    		'checklist_12'=>$result['checklist_12'],
	    		'checklist_13'=>$result['checklist_13'],
	    		'checklist_14'=>$result['checklist_14'],
	    		'checklist_15'=>$result['checklist_15'],
	    		'checklist_16'=>$result['checklist_16'],
	    		'checklist_17'=>$result['checklist_17'],
	    		'checklist_18'=>$result['checklist_18'],
	    		'checklist_19'=>$result['checklist_19'],
	    		'checklist_20'=>$result['checklist_20'],
	    	);
	    }
		$respone['data']=$dataget;
		$respone['code']=$query -> num_rows();
		$respone['msg']='data get';
		return $respone;
	}
	function anextureedit($anextureID=null){
	    $this->db->select('anexture.*,f.FacilityID,f.facilityName,s.StateID,s.StateName,d.DistrictID,d.DistrictName');
	    $this->db->from('anexture');
        $this->db->join('usermapping as um', 'um.UserID= anexture.UserID', 'inner');
        $this->db->join('facilities as f', 'f.FacilityID= um.FacilityID', 'inner');
        $this->db->join('states as s', 's.StateID=f.StateID', 'inner');
        $this->db->join('district as d', 'd.DistrictID=f.DistrictID', 'inner');
	    $this->db->where('anexture.anextureID',encryptor($anextureID,'decrypt'));
	    $query = $this->db->get();
	    if($query -> num_rows()>0){
	    	$result=$query->row_array();
	    	$dataget=array(
	    		'StateID'=>$result['StateID'],
	    		'search_state'=>$result['StateName'],
	    		'DistrictID'=>$result['DistrictID'],
	    		'search_district'=>$result['DistrictName'],
	    		'facilityName'=>$result['facilityName'],
	    		'FacilityID'=>$result['FacilityID'],
	    		'submitDate'=>$result['submitDate'],
	    		'submitDate'=>$result['submitDate'],
	    		'checklist_1'=>$result['checklist_1'],
	    		'checklist_2'=>$result['checklist_2'],
	    		'checklist_3'=>$result['checklist_3'],
	    		'checklist_4'=>$result['checklist_4'],
	    		'checklist_5'=>$result['checklist_5'],
	    		'checklist_6'=>$result['checklist_6'],
	    		'checklist_7'=>$result['checklist_7'],
	    		'checklist_8'=>$result['checklist_8'],
	    		'checklist_9'=>$result['checklist_9'],
	    		'checklist_10'=>$result['checklist_10'],
	    		'checklist_11'=>$result['checklist_11'],
	    		'checklist_12'=>$result['checklist_12'],
	    		'checklist_13'=>$result['checklist_13'],
	    		'checklist_14'=>$result['checklist_14'],
	    		'checklist_15'=>$result['checklist_15'],
	    		'checklist_16'=>$result['checklist_16'],
	    		'checklist_17'=>$result['checklist_17'],
	    		'checklist_18'=>$result['checklist_18'],
	    		'checklist_19'=>$result['checklist_19'],
	    		'checklist_20'=>$result['checklist_20'],
	    	);
	    }
		$respone['data']=$dataget;
		$respone['code']=$query -> num_rows();
		$respone['msg']='data get';
		return $respone;
	}

}