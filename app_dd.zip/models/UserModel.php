<?php

class UserModel extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	function loginCheck($username,$password,$ip,$device='web'){
		include_once(APPPATH.'libraries/cryptojs-aes.php');
		$response=array();
		$this->db->select('users.UserName,incharge.FirstName,incharge.LastName,incharge.Pic,users.UserID,role.RoleID,role.RoleName');
		$this->db->from('users');
		$this->db->join('incharge', 'users.UserID=incharge.UserID AND incharge.TypeDetailID=438 AND incharge.IsActive=1', 'left');
		$this->db->where('users.UserName',$username);
		$this->db->where('users.Password',$password);
		$this->db->where('users.IsActive','1');
		$this->db->join('userrole', 'users.UserID = userrole.UserID AND userrole.IsActive="1"', 'inner');
		$this->db->join('role', 'userrole.RoleID = role.RoleID AND role.IsActive="1"', 'inner');		
		$queryLogin = $this->db->get();

		$LoginStatus=$queryLogin -> num_rows()>=1?1:0;

		$this->db->select('Attempts,LoginTime');
		$this->db->from('loginhistory');
		$this->db->where('RemoteAddress',$ip);
		$this->db->order_by('LoginhistoryID', 'DESC');
		$this->db->limit('1');
		$query = $this->db->get();

		if($LoginStatus){
			if($query -> num_rows()>=1){
				$result_Attempt = $query->result();
				$start_date = new DateTime($result_Attempt[0]->LoginTime);
				$since_start = $start_date->diff(new DateTime(date('Y-m-d H:i:s')));
				$timeElapsed=explode(':',$since_start->format("%a:%H:%I:%S"));
				if($since_start->days>0 || $since_start->h>0 || $since_start->i>15 || $result_Attempt[0]->Attempts<=5){
					$Attempts=0;
				} else {
					$Attempts=$result_Attempt[0]->Attempts+1;
				}
			} else {
				$Attempts=0;
			}
		} else {
			if($query -> num_rows()>=1){
				$result_Attempt = $query->result();
				$Attempts=$result_Attempt[0]->Attempts+1;
			} else {
				$Attempts=1;
			}			
		}


		if($queryLogin -> num_rows() >= 1){
			 $result_set = $queryLogin->result();
			 $userID=$result_set[0]->UserID;
		} else {			
			 $result_set = FALSE;
			 $userID=0;
		}
		$data=array(
			'UserID'=>$userID,
			'UserName'=>$username,
			'Password'=>$password,
			'RemoteAddress'=>$ip,
			'LoginStatus'=>$LoginStatus,
			'Attempts'=>$Attempts,
		);
		if($Attempts==0){
			$response['code']=20;
			$response['msg']='Login Successfully';
		} else if($Attempts<=5){
			$response['code']=21;
			$response['msg']=$this->config->item('errCodes')[21];
		} else {
			$response['code']=22;
			$response['msg']=$this->config->item('errCodes')[22];
		}
		if($Attempts<=5){
			if($this->db->insert('loginhistory', $data)){
				$LoginHisID=$this->db->insert_id();
			} else {
				$this->db->insert('loginhistory', $data);
				$LoginHisID=$this->db->insert_id();
			}
			if($LoginHisID>0 && $userID>0){
				if(isset($_SERVER['HTTP_ORIGIN'])){
					$origin=$_SERVER['HTTP_ORIGIN'];
				} else{
					$origin=@$_SERVER['HTTP_REFERER'];
				}
				$callTime=date('Y-m-d H:i:s');
				$APIKey= cryptoJsAesEncrypt(API_SALT, $LoginHisID.'_'.$userID.'_'.$origin.'_'.$callTime);
				//$APIKey= encryptor($LoginHisID.'_'.$userID);
				$dataAPI=array(					
					'LoginhistoryID'=>$LoginHisID,
					'Token'=>$APIKey,
					'LastActive'=>$callTime,
					'Origin'=>$origin,
				);
				$this->db->select('UsertokenID');
				$this->db->from('usertoken');
				$this->db->where('UserID',$userID);
				$this->db->order_by('UsertokenID', 'DESC');
				$this->db->limit('1');
				$queryToken = $this->db->get();
				//if($device=='App'){
					if($queryToken -> num_rows() >= 1){
						$result_token = $queryToken->result();
						$usertokenID=$result_token[0]->UsertokenID;
						$this->db->where('UsertokenID', $usertokenID);
						$this->db->update('usertoken', $dataAPI);
					} else {
						$dataAPI['UserID']=$userID;
						$this->db->insert('usertoken', $dataAPI);
						$usertokenID=$this->db->insert_id();
					}
				//}				

			  	$sqlState="SELECT GROUP_CONCAT(DISTINCT StateID) as mappedStates FROM `usermapping` WHERE `UserID`='".$result_set[0]->UserID."' and IsActive='1'";
			    $queryState = $this->db->query($sqlState, NULL);
			    $resultState=$queryState->row_array();
			    if(isset($resultState['mappedStates'])){
			    	$MappedState=$resultState['mappedStates'];
			    } else {
			    	$MappedState='';
			    }
			  	$sqlDistrict="SELECT GROUP_CONCAT(DISTINCT DistrictID) as mappedDis FROM `usermapping` WHERE `UserID`='".$result_set[0]->UserID."' and IsActive='1'";
			    $queryDistrict = $this->db->query($sqlDistrict, NULL);
			    $resultDistrict=$queryDistrict->row_array();
			    if(isset($resultDistrict['mappedDis'])){
			    	$MappedDistrict=$resultDistrict['mappedDis'];
			    } else {
			    	$MappedDistrict='';
			    }
			  	$sqlFacility="SELECT GROUP_CONCAT(DISTINCT FacilityID) as mappedFacilities FROM `usermapping` WHERE `UserID`='".$result_set[0]->UserID."' and IsActive='1'";
			    $queryFacility = $this->db->query($sqlFacility, NULL);
			    $resultFacility=$queryFacility->row_array();
			    if(isset($resultFacility['mappedFacilities'])){
			    	$mappedFacilities=$resultFacility['mappedFacilities'];
			    } else {
			    	$mappedFacilities='';
			    }
			    $showFacilities=$showDistrict=$showState=1;
			    if($result_set[0]->RoleName=='Facility'){
			    	$showFacilities=$showDistrict=$showState=0;
			    }
			    if($result_set[0]->RoleName=='District'){
			    	$showDistrict=$showState=0;
			    }
			    if($result_set[0]->RoleName=='State'){
			    	$showState=0;
			    }
				if($usertokenID>0){
					$user_data=array(
						'UserID'=>$result_set[0]->UserID,
						'UserName'=>$result_set[0]->UserName,
						'RoleID'=>$result_set[0]->RoleID,
						'FirstName'=>$result_set[0]->FirstName,
						'LastName'=>$result_set[0]->LastName,
						'profile_pic'=>$result_set[0]->Pic,
						'RoleName'=>$result_set[0]->RoleName,
						'MappedState'=>$MappedState,
						'MappedDistrict'=>$MappedDistrict,
						'mappedFacilities'=>$mappedFacilities,
						'showState'=>$showState,
						'showDistrict'=>$showDistrict,
						'showFacilities'=>$showFacilities,
						'APIKey'=>$APIKey,
					);
					if($result_set[0]->RoleName=='Facility'){
					    $this->db->select('facilities.services');
					    $this->db->from('usermapping');
					    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID AND usermapping.FacilityID>0', 'inner');	    
					    $this->db->where('usermapping.UserID',$result_set[0]->UserID);
					    $queryServices = $this->db->get();
						$dataServices=$queryServices->row_array();
						// if login as facility save userID for future work
						$user_data['facilityUser']=$result_set[0]->UserID;
						$user_data['facilityServices']=$dataServices['services'];
					}					
					$this->session->set_userdata($user_data);
					$this->session->set_userdata('accessData', $this->CommonModel->getMenu());
					$response['data']=$user_data;
				} else {
					$response['code']=23;
					$response['msg']=$this->config->item('errCodes')[23];
				}				
			} else {
				$response['code']=24;
				$response['msg']=$this->config->item('errCodes')[24];
			}
			
		}
		return $response;

	}
	function logout($token){
		include_once(APPPATH.'libraries/cryptojs-aes.php');
		$tokenCheck=cryptoJsAesDecrypt(API_SALT,$token);
		$tokenData=explode('_', $tokenCheck);
		$updateToken=array(
			'LastActive'=>date('2018-01-01 18:48:04')
		);
		$this->db->where('usertoken.UserID',$tokenData[1]);
		$this->db->where('usertoken.LoginhistoryID',$tokenData[0]);
		$this->db->update('usertoken', $updateToken);
		$this->session->sess_destroy();
	}
	function roleData($userID){
		$this->db->select('users.UserName,users.UserID,role.RoleID,role.RoleName');
		$this->db->from('users');
		$this->db->where('users.UserID',$userID);
		$this->db->join('userrole', 'users.UserID = userrole.UserID ', 'inner');
		$this->db->join('role', 'userrole.RoleID = role.RoleID ', 'inner');
		$queryRole = $this->db->get();
		$roleData=$queryRole->result_array();
		$role=$roleData[0]['RoleName'];
		$data=array();
		if(!empty($role)){
		switch ($role) {
			case 'Facility':
			    $this->db->select('users.UserID,usermapping.FacilityID,facilities.FacilityName');
			    $this->db->from('users');
			    $this->db->join('usermapping', 'users.UserID=usermapping.UserID', 'inner');
			    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
			    $this->db->where('users.UserID',$userID);
			    $this->db->order_by('facilities.FacilityName','ASC');
			    $query = $this->db->get();
				$FacilityAssigned=$query->row();
				$data['Facility']=$FacilityAssigned;
				break;
			case 'District':
			    $this->db->select('usermapping.DistrictID,district.DistrictName');
			    $this->db->from('users');
			    $this->db->join('usermapping', 'users.UserID=usermapping.UserID', 'inner');
			    $this->db->join('district', 'usermapping.DistrictID=district.DistrictID', 'inner');
			    $this->db->where('users.UserID',$userID);
			    $this->db->order_by('district.DistrictName','ASC');
			    $query = $this->db->get();
				$DistrictAssigned=$query->result_array();
				$data['District']=$DistrictAssigned;
				$data['Facility']=array();
				break;
			case 'State':
			    $this->db->select('usermapping.StateID,states.StateName');
			    $this->db->from('users');
			    $this->db->join('usermapping', 'users.UserID=usermapping.UserID', 'inner');
			    $this->db->join('states', 'usermapping.StateID=states.StateID', 'inner');
			    $this->db->where('users.UserID',$userID);
			    $this->db->order_by('states.StateName','ASC');
			    $query = $this->db->get();
				$StatesAssigned=$query->result_array();
				$data['State']=$StatesAssigned;
				$data['District']=array();
				$data['Facility']=array();
				break;
			case 'Ministry':
			    $this->db->select('states.StateID,states.StateName');
			    $this->db->from('states');
			    $this->db->where('states.IsActive','1');
			    $this->db->order_by('states.StateName','ASC');
			    $query = $this->db->get();
				$MinistryState=$query->result_array();
				$data['State']=$MinistryState;
				$data['District']=array();
				$data['Facility']=array();
				break;
			case 'NHSRC':
			    $this->db->select('states.StateID,states.StateName');
			    $this->db->from('states');
			    $this->db->where('states.IsActive','1');
			    $this->db->order_by('states.StateName','ASC');
			    $query = $this->db->get();
				$MinistryState=$query->result_array();
				$data['State']=$MinistryState;
				$data['District']=array();
				$data['Facility']=array();
				break;
			default:
				$data=array();
				break;
		}
		$data['role']=$role;
		$response['code']='0';
		$response['data']=$data;
		$response['msg']=$this->config->item('errCodes')[10];
		} else {
			$response['code']='13';
			$response['msg']=$this->config->item('errCodes')[13];
		}
		return $response;
	}
	function getFacilityDataNoUser($districID,$searchData){
		$col =array(
		    0   =>  'FacilityName',
		    1   =>  'StateName',
		    2   =>  'DistrictName',
		    3   =>  'FacilityName'
		);
	    $this->db->select('facilities.FacilityID,facilities.FacilityName,usermapping.UserID,district.DistrictID,district.DistrictName,states.StateID,states.StateName');
	    $this->db->from('facilities');
	    $this->db->join('usermapping', 'usermapping.FacilityID=facilities.FacilityID', 'LEFT');
	    $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'inner');
	    $this->db->join('states', 'facilities.StateID=states.StateID', 'inner');
	    $this->db->where('facilities.DistrictID',$districID);
	    $this->db->where('usermapping.UserID IS NULL', NULL, FALSE);
		if(!empty($searchData['search']['value'])){
			$searchString=trim($searchData['search']['value']);
			$this->db->where("(facilities.FacilityName like '%".$searchString."%' OR district.DistrictName like '%".$searchString."%' OR states.StateName like '%".$searchString."%')", NULL, FALSE);
		}
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $query = $this->db->get();
	    $dataget=array();
	    $cnt=$searchData['start'];
		foreach ($query->result_array() as $key => $value) {
			$subdata=array();
			$subdata[]='<input type="checkbox" value="'.$value['FacilityID'].'" name="facility[]" onclick="facilities(this)" >'.++$cnt;
			$subdata[]=$value['StateName'];
			$subdata[]=$value['DistrictName'];
			$subdata[]=$value['FacilityName'];
			$dataget[]=$subdata;
		}
		$data['data']=$dataget;
		$data['totalData']=$query -> num_rows();
		$data['totalFilter']=$query -> num_rows();
		return $data;
	}
	function getFacilityData($districID,$searchData,$stateID=0){
		$col =array(
		    0   =>  'FacilityName',
		    1   =>  'StateName',
		    2   =>  'DistrictName',
		    3   =>  'FacilityName'
		);
	    $this->db->select('facilities.FacilityID');
	    $this->db->from('facilities');
	    $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'inner');
	    $this->db->join('states', 'facilities.StateID=states.StateID', 'inner');
	    if(!empty($districID)){
	    	$this->db->where('facilities.DistrictID',$districID);
	    }
	    if(!empty($stateID)){
	    	$this->db->where('facilities.StateID',$stateID);
	    }
	    $this->db->where('facilities.IsActive', $searchData['opt']);
		if(!empty($searchData['search']['value'])){
			$searchString=trim($searchData['search']['value']);
			$this->db->where("(facilities.FacilityName like '%".$searchString."%' OR facilities.FacilityNumber like '%".$searchString."%' OR district.DistrictName like '%".$searchString."%' OR states.StateName like '%".$searchString."%')", NULL, FALSE);
		}
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $queryTot = $this->db->get();

	    $this->db->select('facilities.FacilityID,facilities.FacilityName,facilities.FacilityNumber,facilities.IsActive,district.DistrictID,district.DistrictName,states.StateID,states.StateName');
	    $this->db->from('facilities');
	    $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'inner');
	    $this->db->join('states', 'facilities.StateID=states.StateID', 'inner');
	    if(!empty($districID)){
	    	$this->db->where('facilities.DistrictID',$districID);
	    }
	    if(!empty($stateID)){
	    	$this->db->where('facilities.StateID',$stateID);
	    }
	    $this->db->where('facilities.IsActive', $searchData['opt']);
		if(!empty($searchData['search']['value'])){
			$searchString=trim($searchData['search']['value']);
			$this->db->where("(facilities.FacilityName like '%".$searchString."%' OR facilities.FacilityNumber like '%".$searchString."%' OR district.DistrictName like '%".$searchString."%' OR states.StateName like '%".$searchString."%')", NULL, FALSE);
		}
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $this->db->limit($this->input->post('length'),$this->input->post('start'));
	    $query = $this->db->get();
	    $dataget=array();
	    $cnt=$this->input->post('start');
		foreach ($query->result_array() as $key => $value) {
			$subdata=array();
			$subdata[]='<input type="checkbox" value="'.encryptor($value['FacilityID']).'" name="facility[]" onclick="facilities(this)" > '.++$cnt;
			$subdata[]=$value['StateName'];
			$subdata[]=$value['DistrictName'];
			$subdata[]=$value['FacilityName'];
			$subdata[]=$value['FacilityNumber'];
			$subdata[]=$value['IsActive']=='1'?'Active':'InActive';
			$dataget[]=$subdata;
		}
		$data['data']=$dataget;
		$data['totalData']=$queryTot -> num_rows();
		$data['totalFilter']=$queryTot -> num_rows();
		return $data;
	}
	function mapFacility($facilities,$userID,$mapType){
		try {
			$dataAPI=array(
				'IsActive'=>(int)$mapType
			);
			$this->db->where_in('FacilityID', $facilities);
			$this->db->update('facilities', $dataAPI);
			return $response=array('code'=>0,'msg'=>$this->config->item('errCodes')[0]);
		} catch(Exception $e) {
			return $response=array('code'=>11,'msg'=>$this->config->item('errCodes')[11],'excp'=>$e->getMessage());
		}

	}
	function getFacilityAssessmentData($districID,$searchData){
		$col =array(
		    0   =>  'FacilityName',
		    1   =>  'StateName',
		    2   =>  'DistrictName',
		    3   =>  'FacilityName'
		);
	    $this->db->select('facilities.FacilityID,facilities.FacilityName,facilities.AssesmentCheck,district.DistrictID,district.DistrictName,states.StateID,states.StateName');
	    $this->db->from('facilities');
	    $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'inner');
	    $this->db->join('states', 'facilities.StateID=states.StateID', 'inner');
	    $this->db->where('facilities.DistrictID',$districID);
	    $this->db->where('facilities.AssesmentCheck', $searchData['opt']);
		if(!empty($searchData['search']['value'])){
			$searchString=trim($searchData['search']['value']);
			$this->db->where("(facilities.FacilityName like '%".$searchString."%' OR district.DistrictName like '%".$searchString."%' OR states.StateName like '%".$searchString."%')", NULL, FALSE);
		}
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $queryTot = $this->db->get();


	    $this->db->select('facilities.FacilityID,facilities.FacilityName,facilities.AssesmentCheck,district.DistrictID,district.DistrictName,states.StateID,states.StateName');
	    $this->db->from('facilities');
	    $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'inner');
	    $this->db->join('states', 'facilities.StateID=states.StateID', 'inner');
	    $this->db->where('facilities.DistrictID',$districID);
	    $this->db->where('facilities.AssesmentCheck', $searchData['opt']);
		if(!empty($searchData['search']['value'])){
			$searchString=trim($searchData['search']['value']);
			$this->db->where("(facilities.FacilityName like '%".$searchString."%' OR district.DistrictName like '%".$searchString."%' OR states.StateName like '%".$searchString."%')", NULL, FALSE);
		}
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $this->db->limit($this->input->post('length'),$this->input->post('start'));
	    $query = $this->db->get();
	    $dataget=array();
	    $cnt=$this->input->post('start');
		foreach ($query->result_array() as $key => $value) {
			$subdata=array();
			$subdata[]='<input type="checkbox" value="'.encryptor($value['FacilityID']).'" name="facility[]" onclick="facilities(this)" >'.++$cnt;
			$subdata[]=$value['StateName'];
			$subdata[]=$value['DistrictName'];
			$subdata[]=$value['FacilityName'];
			$subdata[]=$value['AssesmentCheck']=='3'?'Endline Facility':'Other Facility';
			$dataget[]=$subdata;
		}
		$data['data']=$dataget;
		$data['totalData']=$queryTot -> num_rows();
		$data['totalFilter']=$queryTot -> num_rows();
		return $data;
	}
	function failitiesAssessment($facilities,$userID,$mapType){
		try {
			$dataAPI=array(
				'AssesmentCheck'=>$mapType
			);
			$this->db->where_in('FacilityID', $facilities);
			$this->db->update('facilities', $dataAPI);
			return $response=array('code'=>0,'msg'=>$this->config->item('errCodes')[0]);
		} catch(Exception $e) {
			return $response=array('code'=>11,'msg'=>$this->config->item('errCodes')[11],'excp'=>$e->getMessage());
		}

	}
	function forgetpassword($userId){
	    $this->db->select('incharge.FirstName,incharge.LastName,incharge.Email,users.IsActive');
	    $this->db->from('users');
	    $this->db->join('incharge', 'users.UserID=incharge.UserID AND incharge.TypeDetailID=438 AND incharge.IsActive=1', 'left');
	    $this->db->where('users.UserName',$userId);
	    $this->db->where('users.IsActive','1');
	    $this->db->limit('1');
	    $query = $this->db->get();
	    if($query -> num_rows()>0){
	    	$userdata=$query->row();
	    	if(!empty($userdata->Email)){
		    	$password=$this->CommonModel->createRandamPassword();
		    	$check=$this->updatePassword($userId,$password);
		    	if($check=='1'){			        
			        $dataMail=array();
			        $dataMail['details']['email']=$userdata->Email;
			        $dataMail['details']['name']=$userdata->FirstName.' '.$userdata->LastName;
			        $dataMail['details']['pswrd']=$password;
			        $dataMail['msg_fun']='update_password';
			        $dataMail['subject']='Laqshya password reset';
			        $dataMail['to']=$userdata->Email;
			        $dataMail['form_url']='user/login';
			        $dataMail['form_name']='Forget Password';
		    		if($this->EmailModel->send_laqshya_mail($dataMail)){
		    			$response=array('code'=>16,'msg'=>'new password has generated. Please check your email for new password');
		    		} else {
		    			$response=array('code'=>18,'msg'=>$this->config->item('errCodes')[18]);
		    		}
		    	} else {
		    		$response=array('code'=>11,'msg'=>$this->config->item('errCodes')[11]);
		    	}
	    	} else {
	    		$response=array('code'=>16,'msg'=>'Please update email-id first');
	    	}
	    } else {
	    	$response=array('code'=>16,'msg'=>'Please enter a valid username');
	    }
		return $response;
	}
	function updatePassword($userId,$password){
		try {
			$dataAPI=array(
				'Password'=>md5($password)
			);
			$this->db->where_in('UserName', $userId);
			if ($this->db->update('users', $dataAPI) === FALSE){
			    return '0';
			} else {
			    return '1';
			}
		} catch(Exception $e) {
			return '0';
		}
	}
	function changepassword($userId,$oldPassword,$confirmPassword){
	    $this->db->select('incharge.FirstName,incharge.LastName,incharge.Email,users.Password,users.IsActive');
	    $this->db->from('users');
	    $this->db->join('incharge', 'incharge.UserID=users.UserID AND incharge.TypeDetailID=438 AND incharge.IsActive=1', 'inner');
	    $this->db->where('users.UserName',$userId);
	    $this->db->where('users.IsActive','1');
	    $this->db->limit('1');
	    $query = $this->db->get();
	    if($query -> num_rows()>0){
	    	$userdata=$query->row();
	    	if(!empty($userdata->Email)){
		    	if($userdata->Password==md5($oldPassword)){
			    	$check=$this->updatePassword($userId,$confirmPassword);
			    	if($check=='1'){
				        $ci = get_instance();
				        $dataMail=array();
				        $dataMail['email']=$userdata->Email;
				        $dataMail['name']=$userdata->FirstName.' '.$userdata->LastName;
				        $dataMail['pswrd']=$confirmPassword;
				        $msg=$this->EmailModel->update_password($dataMail);
				        $ci->load->library('email');
				        $config=$this->config->item('email_config');
				        $ci->email->initialize($config);
				        $ci->email->from($this->config->item('email_from_main'), $this->config->item('email_name_main'));
				        $ci->email->to($userdata->Email);
				        $ci->email->subject('Laqshya password changed');
				        $ci->email->message($msg);		       
			    		if($ci->email->send()){
			    			$response=array('code'=>0,'msg'=>'new password updated Successfully. Please check your email for new password');
			    		} else {
			    			$response=array('code'=>18,'msg'=>$this->config->item('errCodes')[18]);
			    		}
			    	} else {
			    		$response=array('code'=>11,'msg'=>$this->config->item('errCodes')[11]);
			    	}
		    	} else {
		    		$response=array('code'=>16,'msg'=>'Old password does not match');
		    	}
	    	} else {
	    		$response=array('code'=>16,'msg'=>'Please update email-id first');
	    	}

	    } else {
	    	$response=array('code'=>16,'msg'=>'Please enter a valid username');
	    }
		return $response;
	

	}
	function getFacilityDetails($userID){
	    $this->db->select('facilities.FacilityID,facilities.services,facilities.FacilityName,facilities.FacilityNumber,facilities.Latitude,facilities.Longitude,facilities.Altitude,facilities.Address,facilities.PinCode,facilities.Address,facilities.landLine,facilities.ot_services,facilities.FacilityTypeDetailID,facilities.facilitytype_other,usermapping.UserID,district.DistrictID,district.DistrictName,states.StateID,states.StateName,typedetail.TypeDetailCode');
	    $this->db->from('usermapping');
	    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
	    $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'inner');
	    $this->db->join('states', 'facilities.StateID=states.StateID', 'inner');
	    $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');
	    
	    $this->db->where('usermapping.UserID',$userID);
	    $query = $this->db->get();
		return $query->row_array();
	}
	function getProfileDetails($userID=0,$type){
		if($type=='main'){
			$TypeDetailID='438';
		} else if($type=='facility'){
		  	$this->db->select('UserID');
		    $this->db->from('usermapping');
		    $this->db->join('facilities', "facilities.FacilityID=usermapping.FacilityID AND usermapping.FacilityID>0", 'inner');
		    $this->db->where('facilities.FacilityNumber',$userID);
		    $query = $this->db->get();
		    if($query->num_rows()>0){
		    	$datafacility=$query->row_array();
		    	$userID=$datafacility['UserID'];
		    	$TypeDetailID='438';
		    } else {
		    	$userID=0;
		    	$TypeDetailID='0';  // make it any wrong id
		    }
		} else {
			$TypeDetailID='439';
		}
		
	    $this->db->select('incharge.*');
	    $this->db->from('users');
	    $this->db->join('incharge', "users.UserID=incharge.UserID AND incharge.TypeDetailID=$TypeDetailID", 'inner');
	    $this->db->where('users.UserID',$userID);
	    $this->db->where('incharge.IsActive','1');
	    $query = $this->db->get();
		return $query->row_array();
	}
	function profileUpdate($data,$userId){
		$err=array();
		// /echo "<pre>"; print_r($data); die;
		if(isset($data['facility'])){
		    $this->db->select('facilities.FacilityID');
		    $this->db->from('usermapping');
		    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID AND usermapping.FacilityID>0', 'inner');
		    $this->db->where('usermapping.UserID',$userId);
		    $this->db->where('usermapping.IsActive','1');
		    $query = $this->db->get();
			$facilityData=$query->row_array();
			if($facilityData['FacilityID']>0){	
				$this->db->where('FacilityID', $facilityData['FacilityID']);
				if ($this->db->update('facilities', $data['facility']) === FALSE){
				    $err['facility']='Error updating data';
				} else {
					$this->session->set_userdata('facilityServices', $data['facility']['services']);
				}
			} else {
				$err['facility']='No Facility data found';
			}
		}
		if(isset($data['main'])){
		    $this->db->select('incharge.InchargeID');
		    $this->db->from('incharge');
		    $this->db->where('incharge.UserID',$userId);
		    $this->db->where('incharge.IsActive','1');
		    $this->db->where('incharge.TypeDetailID','438');
		    $query = $this->db->get();
			$inchargeData=$query->row_array();
			if($inchargeData['InchargeID']>0){
				$this->db->where('InchargeID', $inchargeData['InchargeID']);
				if ($this->db->update('incharge', $data['main']) === FALSE){
				    $err['main']='Error updating data';
				}
			} else {
				$data['main']['IsActive']='1';
				$data['main']['TypeDetailID']='438';
				$data['main']['UserID']=$userId;
				if(!$this->db->insert('incharge', $data['main'])){
					$err['main']='Error saving data';
				}
			}
			$updateUserData=array(
				'FirstName'=>$data['main']['FirstName'].' '.$data['main']['LastName']
			);
			$this->db->where('UserID', $userId);
			$this->db->update('users', $updateUserData);
			if(!isset($err['main']) && isset($data['main']['Pic']) ){
				$this->session->set_userdata('profile_pic', $data['main']['Pic']);
			}
			if(!isset($err['main']) ){
				$this->session->set_userdata('FirstName', $data['main']['FirstName']);
				$this->session->set_userdata('LastName', $data['main']['LastName']);
			}
		}
		if(isset($data['nodal'])){
		    $this->db->select('incharge.InchargeID');
		    $this->db->from('incharge');
		    $this->db->where('incharge.UserID',$userId);
		    $this->db->where('incharge.IsActive','1');
		    $this->db->where('incharge.TypeDetailID','439');
		    $query = $this->db->get();
			$inchargeData=$query->row_array();
			if($inchargeData['InchargeID']>0){
				$this->db->where('InchargeID', $inchargeData['InchargeID']);
				if ($this->db->update('incharge', $data['nodal']) === FALSE){
				    $err['nodal']='Error updating data';
				}
			} else {
				$data['nodal']['IsActive']='1';
				$data['nodal']['TypeDetailID']='439';
				$data['nodal']['UserID']=$userId;
				if(!$this->db->insert('incharge', $data['nodal'])){
					$err['nodal']='Error saving data';
				}
			}			
		}
		if(empty($err)){
			$response= array('code'=>0,'msg'=>$this->config->item('errCodes')[0]);
		} else {
			$response=array('code'=>16,'msg'=>'Please updaet Data again');
		}
		//print_r($response); print_r($err); die('test');
		return $response;
	}
	function rolesdata(){
        $this->db->select('role.RoleID,role.RoleName,role.IsActive');
        $this->db->from('role');
        $this->db->order_by('RoleName', 'ASC');
        $query = $this->db->get();
		return $query->result_array();
	}
	function rolesdataUser(){
        $this->db->select('role.RoleID,role.RoleName,role.IsActive');
        $this->db->from('role');
        $this->db->where('role.IsActive', '1');
        $this->db->where_not_in('role.RoleID', array(3,4,7,10));
        $this->db->order_by('RoleName', 'ASC');
        $query = $this->db->get();
		return $query->result_array();
	}
  function roledataForm($RoleID){
    $this->db->select('role.RoleID,role.RoleName,role.IsActive');
    $this->db->from('role');
    $this->db->where('role.RoleID', $RoleID);
    $this->db->limit('1');
    $query = $this->db->get();
    return $query->row_array();    
  }
	function saveRoles($userID,$roles,$RoleID){
		try {
		    $this->db->select('role.RoleID,role.RoleName,role.IsActive');
		    $this->db->from('role');
		    $this->db->where('role.RoleName', $roles['RoleName']);
		    if($RoleID>0){
		    	$this->db->where('role.RoleID!=', $RoleID);
		    }
		    $query = $this->db->get();
		    $checkCnd=$query->num_rows();
		    if(empty($checkCnd)){
				if($RoleID>0){
					$this->db->where('RoleID', $RoleID);
					if ($this->db->update('role', $roles)=== FALSE){
					    $response['code']='11';
					    $response['msg']=$this->config->item('errCodes')[11];
					    $response['data']=$RoleID;
					} else {
					    $response['code']='0';
					    $response['msg']=$this->config->item('errCodes')[0];
					    $response['data']=$RoleID;					
					}
				} else {
					if($this->db->insert('role', $roles)){
					    $response['code']='0';
					    $response['msg']=$this->config->item('errCodes')[0];
					    $response['data']=$this->db->insert_id();
					} else {
					    $response['code']='11';
					    $response['msg']=$this->config->item('errCodes')[11];
					    $response['data']='0';
					}				
				}		    	
		    } else {
			    $response['code']='16';
			    $response['msg']='Role name already exists';
			    $response['data']='0';		    	
		    }


		} catch(Exception $e) {
		    $response['code']='14';
		    $response['msg']=$this->config->item('errCodes')[14];
		    $response['data']='0';
		}
		return $response;
	}
	function getUserlist($searchData){

        $data = array();
        $col = array(
            0 => 'u.UserName',
            1 => 'u.FirstName',
            2 => 'u.UserName',
            3 => 'u.RoleName',
            4 => 'u.IsActive',
        );
	  	$this->db->select('u.UserID');
	    $this->db->from('users u');
		$this->db->join('userrole ur', 'u.UserID=ur.UserID ', 'left');
		$this->db->join('role r','ur.RoleID=r.RoleID AND ur.RoleID NOT IN(3,4,7,10) ', 'inner');
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            if(strtolower($searchString)=='active'){ 
                $this->db->where("(u.IsActive='1')", NULL, FALSE);
            } else {
                $this->db->where("(u.UserName like '%".$searchString."%' OR u.FirstName like '%".$searchString."%' OR r.RoleName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        if(!empty($searchData['search_role'])){
        	$this->db->where('ur.RoleID',$searchData['search_role']);
        }
	    $queryTot = $this->db->get();

	  	$this->db->select('u.UserID,u.UserName,u.FirstName,u.CreatedOn,r.RoleName,u.IsActive');
	    $this->db->from('users u');
		$this->db->join('userrole ur', 'u.UserID=ur.UserID ', 'left');
		$this->db->join('role r','ur.RoleID=r.RoleID AND ur.RoleID NOT IN(3,4,7,10) ', 'inner');
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            if(strtolower($searchString)=='active'){ 
                $this->db->where("(u.IsActive='1')", NULL, FALSE);
            } else if(strtolower($searchString)=='inactive'){ 
                $this->db->where("(u.IsActive='0')", NULL, FALSE);
            } else {
                $this->db->where("(u.UserName like '%".$searchString."%' OR u.FirstName like '%".$searchString."%' OR r.RoleName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        if(!empty($searchData['search_role'])){
        	$this->db->where('ur.RoleID',$searchData['search_role']);
        }
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $this->db->limit($this->input->post('length'),$this->input->post('start'));
	    $query = $this->db->get();
	    $cnt=$searchData['start'];

        //$access_add=$this->CommonModel->checkPageActionWeb('user/userlist','access_add',$this->session->userdata('RoleName'));
        $access_edit=$this->CommonModel->checkPageActionWeb('user/userlist','access_edit',$this->session->userdata('RoleName'));
        //$access_delete=$this->CommonModel->checkPageActionWeb('user/userlist','access_delete',$this->session->userdata('RoleName'));
        $access_view=$this->CommonModel->checkPageActionWeb('user/userlist','access_view',$this->session->userdata('RoleName'));
		foreach ($query->result_array() as $key => $value) {
			$subdata=array();
			$subdata[]=++$cnt;
			$subdata[] = $value['FirstName'];
			$subdata[] = $value['UserName'];
			$subdata[] = $value['RoleName'];
			$subdata[] = convert_datetime_show($value['CreatedOn']);
			$subdata[] = $value['IsActive']==1?'Active':'InActive';
			$checkListUrl='reports/checklist';
			$actionLink='';
			if($access_edit){
				$actionLink.='<button data-href="'.base_url().'user/add/'.encryptor($value['UserID']).'"  onclick="pageRedirect(this)" class="btn btn-warning btn-xs view" >Edit</button>';
			}
			$subdata[] = $actionLink;			
			$data[] = $subdata;
		}

		return array('totalData'=>$queryTot->num_rows(),'totalFilter'=>$queryTot->num_rows(),'data'=>$data);
	}
	function add($dataSave){
		try {
			if($dataSave['UserID']>0){
				$this->db->where('UserID', $dataSave['UserID']);
				if ($this->db->update('users', $dataSave['user'])=== FALSE){
				    $response['code']='11';
				    $response['msg']=$this->config->item('errCodes')[11];
				    $response['data']=$dataSave['UserID'];
				} else {
				    $response['code']='0';
				    $response['msg']=$this->config->item('errCodes')[0];
				    $response['data']=$dataSave['UserID'];					
				}
			} else {
				if($this->db->insert('users', $dataSave['user'])){
				    $response['code']='0';
				    $response['msg']=$this->config->item('errCodes')[0];
				    $response['data']=$this->db->insert_id();
				} else {
				    $response['code']='11';
				    $response['msg']=$this->config->item('errCodes')[11];
				    $response['data']='0';
				}				
			}
			if($response['data']>0){
				// for mapping
				$this->db->where('UserID', $response['data']);
				$this->db->delete('usermapping');
				$dataMapArr=array();
				$stateList=array();
				if(empty($dataSave['user']['usertype'])){
					if(!empty($dataSave['mapping']['search_state']) && count($dataSave['mapping']['search_state'])>0){
						foreach ($dataSave['mapping']['search_state'] as $key => $value) {
							if($value!='99999'){
								$stateList[$value]=array('district'=>'99999');
							}
						}
					}
					if(!empty($dataSave['mapping']['search_district']) && count($dataSave['mapping']['search_district'])>0){
						foreach ($dataSave['mapping']['search_district'] as $key => $value) {
							if($value!='99999'){
								$districtsArr=explode('_', $value);
								if($stateList[$districtsArr[0]]['district']=='99999'){
									unset($stateList[$districtsArr[0]]['district']);
									$stateList[$districtsArr[0]]['district'][$districtsArr[1]]=array('facility'=>'99999');
								} else {
									$stateList[$districtsArr[0]]['district'][$districtsArr[1]]=array('facility'=>'99999');
								}								
							}
						}
					}
					if(!empty($dataSave['mapping']['FacilityID']) && count($dataSave['mapping']['FacilityID'])>0){
						foreach ($dataSave['mapping']['FacilityID'] as $key => $value) {
							if($value!='99999'){
								$facilityArr=explode('_', $value);
								if($stateList[$facilityArr[0]]['district'][$facilityArr[1]]['facility']=='99999'){
									unset($stateList[$facilityArr[0]]['district'][$facilityArr[1]]['facility']);
									$stateList[$facilityArr[0]]['district'][$facilityArr[1]]['facility'][$facilityArr[2]]=$facilityArr[2];
								} else {
									$stateList[$facilityArr[0]]['district'][$facilityArr[1]]['facility'][$facilityArr[2]]=$facilityArr[2];
								}								
							}
						}
					}
				} else {
					// admin user
				}
				if(!empty($stateList)){
					foreach ($stateList as $keyState => $valueState) {
						if($valueState['district']=='99999' && !is_array($valueState['district'])){
							$dataMapArr[]=array(
								'UserID'=>$response['data'],
								'StateID'=>$keyState,
								'DistrictID'=>0,
								'FacilityID'=>0,
								'IsActive'=>1,
						    	'CreatedOn'=>$dataSave['date'],
						    	'CreatedBy'=>$dataSave['userID']
							);
						} else {
							foreach ($valueState['district'] as $keyDistrict => $valueDistrict) {
								if($valueDistrict['facility']=='99999' && !is_array($valueDistrict['facility'])){
									$dataMapArr[]=array(
										'UserID'=>$response['data'],
										'StateID'=>$keyState,
										'DistrictID'=>$keyDistrict,
										'FacilityID'=>0,
										'IsActive'=>1,
								    	'CreatedOn'=>$dataSave['date'],
								    	'CreatedBy'=>$dataSave['userID']
									);
								} else {
									if(is_array($valueDistrict['facility'])){
										foreach ($valueDistrict['facility'] as $keyFacility => $valueFacility) {
											$dataMapArr[]=array(
												'UserID'=>$response['data'],
												'StateID'=>$keyState,
												'DistrictID'=>$keyDistrict,
												'FacilityID'=>$keyFacility,
												'IsActive'=>1,
										    	'CreatedOn'=>$dataSave['date'],
										    	'CreatedBy'=>$dataSave['userID']
											);										
										}										
									}
								}								
							}
						}

					}					
				}
				
				if(!empty($dataMapArr)){
					$this->db->insert_batch('usermapping', $dataMapArr);
				}
				// for role
			    $this->db->select('userrole.UserRoleID');
			    $this->db->from('userrole');
			    $this->db->where('userrole.UserID', $response['data']);
			    $query = $this->db->get();
			    $checkCnd=$query->num_rows();
			    if(empty($checkCnd)){
			    	$dataSave['role']['UserID']=$response['data'];
			    	$dataSave['role']['IsActive']=1;
			    	$dataSave['role']['CreatedOn']=$dataSave['date'];
			    	$dataSave['role']['CreatedBy']=$dataSave['userID'];
			    	$this->db->insert('userrole', $dataSave['role']);
			    } else {
			    	$dataSave['role']['UserID']=$response['data'];
			    	//$dataSave['role']['IsActive']=(int)$dataSave['user']['IsActive'];
			    	$dataSave['role']['ModifiedOn']=$dataSave['date'];
			    	$dataSave['role']['ModifiedBy']=$dataSave['userID'];
					$this->db->where('UserID', $response['data']);
					$this->db->update('userrole', $dataSave['role']);
			    }
			    // for incharge
			    $this->db->select('incharge.InchargeID');
			    $this->db->from('incharge');
			    $this->db->where('incharge.UserID', $response['data']);
			    $this->db->where('incharge.TypeDetailID', '438');
			    $query = $this->db->get();
			    $checkCnd=$query->num_rows();
			    if(empty($checkCnd)){
			    	$dataSave['incharge']['UserID']=$response['data'];
			    	$dataSave['incharge']['TypeDetailID']='438';
			    	$dataSave['incharge']['IsActive']=1;
			    	$dataSave['incharge']['CreatedOn']=$dataSave['date'];
			    	$dataSave['incharge']['CreatedBy']=$dataSave['userID'];
			    	$this->db->insert('incharge', $dataSave['incharge']);
			    } else {
			    	$dataSave['incharge']['UserID']=$response['data'];
			    	//$dataSave['incharge']['IsActive']=(int)$dataSave['user']['IsActive'];
			    	$dataSave['incharge']['ModifiedOn']=$dataSave['date'];
			    	$dataSave['incharge']['ModifiedBy']=$dataSave['userID'];
					$this->db->where('UserID', $response['data']);
					$this->db->where('TypeDetailID', '438');
					$this->db->update('incharge', $dataSave['incharge']);
			    }
			}
		} catch(Exception $e) {
		    $response['code']='14';
		    $response['msg']=$this->config->item('errCodes')[14];
		    $response['data']='0';
		}
		return $response;
	}
	function getUserData($userID){
	  	$this->db->select('u.UserID,u.usertype,u.UserName,u.FirstName,u.IsActive,ur.RoleID,i.Email,i.Mobile');
	    $this->db->from('users u');
		$this->db->join('userrole ur', 'u.UserID=ur.UserID ', 'left');
		$this->db->join('incharge i', 'i.UserID=u.UserID AND i.TypeDetailID=438', 'left');
	    $this->db->where('u.UserID',$userID);
	    $query = $this->db->get();
	    $data=$query->row_array();
	    $mappedArr=array();
	    $qry='SELECT GROUP_CONCAT(DISTINCT StateID) as StateID
FROM `usermapping` 
WHERE `UserID`="'.$userID.'" AND StateID>0
GROUP BY UserID';	    
		$query=$this->db->query($qry);
		$result=$query->row_array();
		$mappedArr['StateID']=$result['StateID'];

		$qry='SELECT GROUP_CONCAT(DISTINCT concat(StateID,"_",DistrictID)) as DistrictID
FROM `usermapping` 
WHERE `UserID`="'.$userID.'" AND DistrictID>0
GROUP BY UserID';	    
		$query=$this->db->query($qry);
		$result=$query->row_array();
		$mappedArr['DistrictID']=$result['DistrictID'];

		$qry='SELECT GROUP_CONCAT(DISTINCT concat(StateID,"_",DistrictID,"_",FacilityID)) as FacilityID
FROM `usermapping` 
WHERE `UserID`="'.$userID.'" AND FacilityID>0
GROUP BY UserID';	    
		$query=$this->db->query($qry);
		$result=$query->row_array();
		$mappedArr['FacilityID']=$result['FacilityID'];
		
		$data['mapping']=$mappedArr;
	    return $data;
	}
	function checkusername($UserName){
	  	$this->db->select('u.UserID');
	    $this->db->from('users u');
	    $this->db->where('u.UserName',$UserName);
	    $query = $this->db->get();
	    if($query->num_rows()>0){
	    	return array(
	    		'code'=>16,
	    		'msg'=>'UserName already exist'
	    	);
	    } else {
	    	return array(
	    		'code'=>'0',
	    		'msg'=>''
	    	);
	    }
	}
	function getUserMapping($search_user){
		$data=array();
	  	$this->db->select('u.FirstName,r.RoleName');
	    $this->db->from('users u');
	    $this->db->join('userrole ur', 'u.UserID=ur.UserID AND ur.IsActive=1', 'inner');
	    $this->db->join('role r','ur.RoleID=r.RoleID', 'inner');
	    $this->db->where('u.UserID',$search_user);
	    $query = $this->db->get();
	    $dataUser=$query->row_array();

	  	$this->db->select('um.UsermappingID,um.UserID,s.StateName,s.StateID,d.DistrictName,d.DistrictID,um.AssignedFacilities');
	    $this->db->from('usermapping um');
	    $this->db->join('states s','s.StateID=um.StateID', 'left');
	    $this->db->join('district d','d.DistrictID=um.DistrictID', 'left');
	    $this->db->where('um.UserID',$search_user);
	    $this->db->where('um.IsActive','1');
	    $query = $this->db->get();
	    $i=1;
	    if($query->num_rows()>0){
		    foreach ($query->result_array() as $key => $value) {
		    	if(empty($value['AssignedFacilities'])){
		    		$state=empty($value['StateName'])?'All':$value['StateName'];
		    		$district=empty($value['DistrictName'])?'All':$value['DistrictName'];
			    	$data[]=array(
		    		'SN' => $i++, 
		    		'state' => $state, 
		    		'district' => $district, 
		    		'facility' => 'All', 
		    		'user' => $dataUser['FirstName'], 
		    		'role' => $dataUser['RoleName'], 
		    		'action' => '<button onclick="removeRow(this)" class="btn btn-danger btn-xs getAssesment getAssesment1 view" ><i class="fa fa-eye"></i>Remove</button>', 
		    		'StateID' => $value['StateID'], 
		    		'DistrictID' => $value['DistrictID'], 
		    		);
		    	} else {
				  	$this->db->select('f.FacilityID,f.FacilityName,s.StateName,s.StateID,d.DistrictName,d.DistrictID');
				    $this->db->from('facilities f');
				    $this->db->join('states s','s.StateID=f.StateID', 'left');
				    $this->db->join('district d','d.DistrictID=f.DistrictID', 'left');
				    $this->db->where_in('f.FacilityID',explode(',',$value['AssignedFacilities']));
				    $this->db->where('f.IsActive','1');
				    $queryFacility = $this->db->get();
				    if($queryFacility->num_rows()>0){
				    	foreach ($queryFacility->result_array() as $keyF => $valueF) {
					    	$data[]=array(
				    		'SN' => $i++, 
				    		'state' => $valueF['StateName'], 
				    		'district' => $valueF['DistrictName'], 
				    		'facility' => $valueF['FacilityName'], 
				    		'user' => $dataUser['FirstName'], 
				    		'role' => $dataUser['RoleName'], 
				    		'action' => '<button onclick="removeRow(this)" class="btn btn-danger btn-xs getAssesment getAssesment1 view" ><i class="fa fa-eye"></i>Remove</button>', 
				    		'StateID' => $valueF['StateID'], 
				    		'DistrictID' => $valueF['DistrictID'], 
				    		);				    		
				    	}
				    }
		    	}
		    }
	    } else {
	    	$data[]=array(
	    		'SN' => $i++, 
	    		'state' => 'All', 
	    		'district' => 'All', 
	    		'facility' => 'All', 
	    		'user' => $dataUser['FirstName'], 
	    		'role' => $dataUser['RoleName'], 
	    		'action' =>'<button onclick="removeRow(this)" class="btn btn-danger btn-xs getAssesment getAssesment1 view" ><i class="fa fa-eye"></i>Remove</button>', 
	    		'StateID' => '0', 
	    		'DistrictID' => '0', 
	    	);
	    }

	    return array(
	    	'code'=>0,
	    	'msg'=>'sucess',
	    	'row'=>count($data),
	    	'data'=>$data
	    );
	}
	function getMappeduserdata($searchData){

        $data = array();
        $col = array(
            0 => 'u.UserName',
            1 => 'u.FirstName',
            2 => 'u.UserName',
            3 => 'u.RoleName',
            4 => 'u.IsActive',
        );
	  	$this->db->select('u.UserID');
	    $this->db->from('users u');
		$this->db->join('userrole ur', 'u.UserID=ur.UserID AND ur.IsActive=1', 'left');
		$this->db->join('role r','ur.RoleID=r.RoleID AND ur.RoleID NOT IN(3,4,7,10) ', 'inner');
		$this->db->join('usermapping um', 'um.UserID=u.UserID AND um.IsActive=1', 'left');
	    $this->db->join('states s','s.StateID=um.StateID', 'left');
	    $this->db->join('district d','d.DistrictID=um.DistrictID', 'left');
	    $this->db->join('facilities f','um.AssignedFacilities=f.FacilityID', 'left');
		
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            if(strtolower($searchString)=='active'){ 
                $this->db->where("(u.IsActive='1')", NULL, FALSE);
            } else if(strtolower($searchString)=='inactive'){ 
                $this->db->where("(u.IsActive='0')", NULL, FALSE);
            } else {
                $this->db->where("(u.UserName like '%".$searchString."%' OR u.FirstName like '%".$searchString."%' OR r.RoleName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        if(!empty($searchData['search_role'])){
        	$this->db->where('ur.RoleID',$searchData['search_role']);
        }
	    $queryTot = $this->db->get();

	  	$this->db->select('u.UserID,u.UserName,u.FirstName,u.CreatedOn,r.RoleName,u.IsActive');
	    $this->db->from('users u');
		$this->db->join('userrole ur', 'u.UserID=ur.UserID ', 'left');
		$this->db->join('role r','ur.RoleID=r.RoleID AND ur.RoleID NOT IN(3,4,7,10) ', 'inner');
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            if(strtolower($searchString)=='active'){ 
                $this->db->where("(u.IsActive='1')", NULL, FALSE);
            } else if(strtolower($searchString)=='inactive'){ 
                $this->db->where("(u.IsActive='0')", NULL, FALSE);
            } else {
                $this->db->where("(u.UserName like '%".$searchString."%' OR u.FirstName like '%".$searchString."%' OR r.RoleName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        if(!empty($searchData['search_role'])){
        	$this->db->where('ur.RoleID',$searchData['search_role']);
        }
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $this->db->limit($this->input->post('length'),$this->input->post('start'));
	    $query = $this->db->get();
//echo $this->db->last_query()."<br>";
	    $cnt=$searchData['start'];

        //$access_add=$this->CommonModel->checkPageActionWeb('user/userlist','access_add',$this->session->userdata('RoleName'));
        $access_edit=$this->CommonModel->checkPageActionWeb('user/mappeduserdata','access_edit',$this->session->userdata('RoleName'));
        //$access_delete=$this->CommonModel->checkPageActionWeb('user/userlist','access_delete',$this->session->userdata('RoleName'));
        $access_view=$this->CommonModel->checkPageActionWeb('user/mappeduserdata','access_view',$this->session->userdata('RoleName'));
		foreach ($query->result_array() as $key => $value) {

		  	$this->db->select('GROUP_CONCAT(s.StateName) as StateName, GROUP_CONCAT(d.DistrictName) as DistrictName,GROUP_CONCAT(um.AssignedFacilities) as AssignedFacilities');
		    $this->db->from('usermapping um');
		    $this->db->join('states s','s.StateID=um.StateID', 'left');
		    $this->db->join('district d','d.DistrictID=um.DistrictID', 'left');
		    $this->db->where('um.UserID',$value['UserID']);
		    $this->db->where('um.IsActive','1');
		    $this->db->group_by('um.UserID');
		    $query = $this->db->get();
		    $facilityData=$query->row_array();

    		$state=empty($facilityData['StateName'])?'All':$facilityData['StateName'];
    		$district=empty($facilityData['DistrictName'])?'All':$facilityData['DistrictName'];
    		if(empty($facilityData['AssignedFacilities'])){
    			$facilities='All';
    		} else{
			  	$this->db->select('GROUP_CONCAT(f.FacilityName) as FacilityName');
			    $this->db->from('facilities f');
			    $this->db->where_in('f.FacilityID',explode(',',$facilityData['AssignedFacilities']));
			    $this->db->where('f.IsActive','1');
			    $queryFacility = $this->db->get();
			    $facilitiesData=$queryFacility->row_array();
			    $facilities=$facilitiesData['FacilityName'];			       			
    		}
			$subdata=array();
			$subdata[]=++$cnt;
			$subdata[] = $value['RoleName'];
			$subdata[] = $value['FirstName'];
			$subdata[] = $state;
			$subdata[] = $district;
			$subdata[] = $facilities;
			$subdata[] = $value['IsActive']==1?'Active':'InActive';
			$checkListUrl='reports/checklist';
			$actionLink='';
			if($access_edit){
				$actionLink.='<button data-href="'.base_url().'user/add/'.encryptor($value['UserID']).'"  onclick="pageRedirect(this)" class="btn btn-warning btn-xs view" >Edit</button>';
			}
			$subdata[] = $actionLink;			
			$data[] = $subdata;

		}

		return array('totalData'=>$queryTot->num_rows(),'totalFilter'=>$queryTot->num_rows(),'data'=>$data);
	}



}