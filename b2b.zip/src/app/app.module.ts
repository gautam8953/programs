import { BrowserModule } from '@angular/platform-browser';
//import { MultiSelectAllModule } from '@syncfusion/ej2-angular-dropdowns';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';


import { HttpClientModule } from '@angular/common/http';
// import { NgHttpLoaderModule } from 'ng-http-loader';
import { UserService } from './services/user.service';
import { TokenService } from './services/token.service';
import { AuthService } from './services/auth.service';
import { AfterLoginService } from './services/after-login.service';
import { BeforeLoginService } from './services/before-login.service';
import { CommonService } from './services/common.service';

import { HeaderComponent } from './components/includes/header/header.component';
import { FooterComponent } from './components/includes/footer/footer.component';
import { LoginComponent } from './components/login/login.component';
import { CompanyComponent } from './components/company/company.component';
import { SearchComponent } from './components/search/search.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { MainComponent } from './components/main/main.component';
import { RegisterComponent } from './components/register/register.component';
import { ForgetPasswordComponent } from './components/forget-password/forget-password.component';
import { CompanyProfileComponent } from './components/company-profile/company-profile.component';
import { AddServiceComponent } from './components/add-service/add-service.component';
import { ManageServicesComponent } from './components/manage-services/manage-services.component';
import { PortalHeaderComponent } from './components/includes/portal-header/portal-header.component';
import { PortalFooterComponent } from './components/includes/portal-footer/portal-footer.component';
import { PortalLeftMenuComponent } from './components/includes/portal-left-menu/portal-left-menu.component';

import { MenuComponent } from './components/includes/menu/menu.component';
import { TopSectorsComponent } from './components/main/top-sectors/top-sectors.component';
import { AllServicesComponent } from './components/main/all-services/all-services.component';
import { ListCompanyContactsComponent } from './components/list-company-contacts/list-company-contacts.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { CompanyServicesComponent } from './components/company-services/company-services.component';

import { AngularEditorModule } from '@kolkov/angular-editor';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    CompanyComponent,
    SearchComponent,
    NotFoundComponent,
    MainComponent,
    RegisterComponent,
    ForgetPasswordComponent,
    CompanyProfileComponent,
    AddServiceComponent,
    ManageServicesComponent,
    PortalHeaderComponent,
    PortalFooterComponent,
    PortalLeftMenuComponent,
    MenuComponent,
    TopSectorsComponent,
    AllServicesComponent,
    ListCompanyContactsComponent,
    DashboardComponent,
    CompanyServicesComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AngularEditorModule, 
    //MultiSelectAllModule,
    // NgHttpLoaderModule.forRoot()
  ],
  providers: [UserService,CommonService,TokenService,AuthService,AfterLoginService,BeforeLoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }
