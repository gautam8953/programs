import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BeforeLoginService } from './services/before-login.service';
import { AfterLoginService } from './services/after-login.service';

import { MainComponent } from './components/main/main.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { SearchComponent } from './components/search/search.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { ForgetPasswordComponent } from './components/forget-password/forget-password.component';
import { CompanyProfileComponent } from './components/company-profile/company-profile.component';
import { AddServiceComponent } from './components/add-service/add-service.component';
import { ManageServicesComponent } from './components/manage-services/manage-services.component';
import { CompanyComponent } from './components/company/company.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ListCompanyContactsComponent } from './components/list-company-contacts/list-company-contacts.component';
import { CompanyServicesComponent } from './components/company-services/company-services.component';

const routes: Routes = [
   {path: '', component: MainComponent},
   {path: 'login', component: LoginComponent,canActivate: [BeforeLoginService]},
   {path: 'register', component: RegisterComponent},
   {path: 'forget-password', component: ForgetPasswordComponent},
   {path: 'search', component: SearchComponent},
   {path: 'company/:id', component: CompanyComponent},
   {path: 'company-services/:companyID/:id', component: CompanyServicesComponent},
   {path: 'dashboard', component: DashboardComponent,canActivate: [AfterLoginService]},
   {path: 'company-profile', component: CompanyProfileComponent,canActivate: [AfterLoginService]},
   {path: 'add-service', component: AddServiceComponent,canActivate: [AfterLoginService]},
   {path: 'manage-service', component: ManageServicesComponent,canActivate: [AfterLoginService]},
   {path: 'company-contacts', component: ListCompanyContactsComponent,canActivate: [AfterLoginService]},
   {path: '**', component: NotFoundComponent},   
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
