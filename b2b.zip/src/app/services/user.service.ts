import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

const httpOptions = {
  headers: new HttpHeaders({'Authorization': "Bearer "+localStorage.getItem('token')})
}

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseurl = environment.apiBaseUrl;
  private imageBaseUrl = environment.imageBaseUrl;

  constructor(private http:HttpClient) { }

  register(data){
    return this.http.post(`${this.baseurl}/register`,data);
  }

  login(data){
    return this.http.post(`${this.baseurl}/login`,data);
  }

  getUserDetails(){
    return this.http.post(`${this.baseurl}/getUser`,'',httpOptions);
  }

  update(data){
    return this.http.post(`${this.baseurl}/update`,data,httpOptions);
  }

  addServices(data){
    return this.http.post(`${this.baseurl}/addServices`,data,httpOptions);
  }

  getServices(data){
    return this.http.post(`${this.baseurl}/getServices`,data,httpOptions);
  }
  getCompanyContacts(data){
    return this.http.post(`${this.baseurl}/getContact`,data,httpOptions);
  }

}
