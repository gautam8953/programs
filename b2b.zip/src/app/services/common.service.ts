import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

const httpOptions = {
  headers: new HttpHeaders({'Authorization': "Bearer "+localStorage.getItem('token')})
}

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  private apiBaseUrl = environment.apiBaseUrl;
  private imageBaseUrl = environment.imageBaseUrl;

  constructor(private http:HttpClient) { }

  getcountry(){
    return this.http.post(`${this.apiBaseUrl}/country`,'');
  }

  getstates(data){
    return this.http.post(`${this.apiBaseUrl}/states`,data);
  }

  getDistrict(data){
    return this.http.post(`${this.apiBaseUrl}/district`,data);
    //return this.http.post(`${this.baseurl}/district/${stateID}`,data);
  }
  getCity(data){
    return this.http.post(`${this.apiBaseUrl}/city`,data);
  }
  companyTypes(){
    return this.http.post(`${this.apiBaseUrl}/companyTypes`,'');
  }
  sectors(data){
    return this.http.post(`${this.apiBaseUrl}/sector`,data);
  }
  getServices(data){
    return this.http.post(`${this.apiBaseUrl}/services`,data);
  }
  getCompanies(data){
    return this.http.post(`${this.apiBaseUrl}/company`,data);
  }
  getCompanyDetails(data,companyId){
    return this.http.post(`${this.apiBaseUrl}/companyDetails/${companyId}`,data);
  }
  getCompanyServices(data,companyId){
    return this.http.post(`${this.apiBaseUrl}/companyServices/${companyId}`,data);
  }
  getCompanyTopServices(data,companyId){
    return this.http.post(`${this.apiBaseUrl}/companyServices/${companyId}`,data);
  }
  companyContact(data){
    return this.http.post(`${this.apiBaseUrl}/contact`,data);
  }
  companyServiceData(data){
    return this.http.post(`${this.apiBaseUrl}/companyServiceData`,data);
  }
  getSectorServicesData(data){
    return this.http.post(`${this.apiBaseUrl}/getSectorService`,data);
  }
  getCompanySectorServicesData(data,companyId){
    return this.http.post(`${this.apiBaseUrl}/getCompanyService/${companyId}`,data);
  }
  getSectorSubServiceData(data,companyId){
    return this.http.post(`${this.apiBaseUrl}/getSectorSubService/${companyId}`,data);
  }
  getCompanySurviceSubService(data,companyId){
    return this.http.post(`${this.apiBaseUrl}/getServiceSubService/${companyId}`,data);
  }

}
