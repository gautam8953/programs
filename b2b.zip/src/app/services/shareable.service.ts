import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShareableService {
  
  private messageSource = new BehaviorSubject('default message');
  private companySource = new BehaviorSubject<any>({});
  currentMessage = this.messageSource.asObservable();
  currentCompanies = this.companySource.asObservable();


  constructor() { }

  changeMessage(message: string) {
    this.messageSource.next(message)
  }
  changeCompanies(data) {
    this.companySource.next(data)
  }

}
