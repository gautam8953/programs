import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';
import { ShareableService } from "src/app/services/shareable.service";


@Component({
  selector: 'app-serach',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  apiBaseUrl=environment.apiBaseUrl;
  imageBaseUrl=environment.imageBaseUrl;
  thumbImageBaseUrl=environment.thumbImageBaseUrl;
  companies=[];
  sectorServices=[];

  constructor(
    private Common:CommonService,
    private sharebaleData: ShareableService
  ) { }

  ngOnInit() {
    this.sharebaleData.currentCompanies.subscribe(dataShared => this.companies = dataShared);
    this.getSectorServices();
  }

  getSectorServices(){
    let dataSend={};
    this.Common.getSectorServicesData(dataSend).subscribe(
      data=>this.handleSectorServicesData(data),
      error=>console.log(error)
    );        
  }
  handleSectorServicesData(data){
    this.sectorServices=data.data;
  }
  getSectorCompany(sectorID){
    console.log(sectorID);
  }
  getServiceCompany(sectorID,serviceID){
    console.log(sectorID+' '+serviceID);
  }

}
