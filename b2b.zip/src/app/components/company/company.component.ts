import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
  appBaseUrl=environment.appBaseUrl;
  apiBaseUrl=environment.apiBaseUrl;
  imageBaseUrl=environment.imageBaseUrl;
  thumbImageBaseUrl=environment.thumbImageBaseUrl;
  
  validateForm: FormGroup;
  submitted = false;
  errors:any=[];
  res_message=null;
  res_message_class=null;
  companyId=null;

  companyDeatils:any={};
  companyServices:any=null;
  companyTopServices:any=null;
  CompanySectorServices=[];

  constructor(
    private router: ActivatedRoute,
    private formBuilder: FormBuilder,
    private Common:CommonService
  ) { }

  ngOnInit() {
    this.companyId=this.router.snapshot.paramMap.get('id');
    this.validateForm = this.formBuilder.group({
      subject: ['', [Validators.required]],
      email: ['', [Validators.required,Validators.email]],
      fullName: ['', [Validators.required]],
      mobile: ['', [Validators.required,Validators.maxLength(10),Validators.minLength(10),Validators.pattern("^[0-9]*$")]],
      message: ['', [Validators.required]],
      companyID:[this.companyId,[]]
    });

    this.getCompanyDeatils(this.companyId);
    this.getCompanyServices(this.companyId);
    this.getCompanyTopServices(this.companyId);
    this.getCompanySectorServices();
  }
  
  get formControls() { return this.validateForm.controls; }

  getCompanyDeatils(companyId){
    let dataSend={};
    this.Common.getCompanyDetails(dataSend,companyId).subscribe(
      data=>this.handleCompanyDetailsData(data),
      error=>console.log(error)
    );
  }
  handleCompanyDetailsData(data){
    this.companyDeatils=data.data;    
  }
  getCompanyServices(companyId){
    let dataSend={};
    this.Common.getCompanyServices(dataSend,companyId).subscribe(
      data=>this.handleCompanyServicesData(data),
      error=>console.log(error)
    );
  }
  handleCompanyServicesData(data){
    this.companyServices=data.data;
  }
  getCompanyTopServices(companyId){
    let dataSend={};
    dataSend['ser.isTop']=1;
    this.Common.getCompanyTopServices(dataSend,companyId).subscribe(
      data=>this.handleCompanyTopServicesData(data),
      error=>console.log(error)
    );
  }
  handleCompanyTopServicesData(data){
    this.companyTopServices=data.data;
  }

  onCompanyContactSubmit(){
    this.submitted = true;
    console.log(this.validateForm.value);
    if (this.validateForm.valid) {
      this.Common.companyContact(this.validateForm.value).subscribe(
        data=>this.handleCompanyContactResponse(data),
        error=>this.handleCompanyContactErrors(error)
      );
    } else {
      return;
    }
  }
  handleCompanyContactResponse(response){
    this.res_message=response.res_message;
    this.res_message_class=response.res_message_class;
  }
  handleCompanyContactErrors(responseError){
    this.errors=responseError.error;
  }
  
  getCompanySectorServices(){
    let dataSend={};
    //dataSend['companyName']=this.messageMine;
    this.Common.getCompanySectorServicesData(dataSend,this.companyId).subscribe(
      data=>this.handleCompanySectorServicesData(data),
      error=>console.log(error)
    );        
  }
  handleCompanySectorServicesData(data){
    this.CompanySectorServices=data.data;
  }
  getCompanySectorSubService(sectorID){
    let dataSend={};
    this.Common.getSectorSubServiceData(dataSend,this.companyId).subscribe(
      data=>this.handleSectorSubServiceData(data),
      error=>console.log(error)
    );
  }
  handleSectorSubServiceData(data){
    //this.companyServices=data.data;
  }
  getCompanySurviceSubService(sectorID,serviceID){
    let dataSend={};
    this.Common.getCompanySurviceSubService(dataSend,this.companyId).subscribe(
      data=>this.handleSectorSubServiceData(data),
      error=>console.log(error)
    );
  }
  scroll(el: HTMLElement) {
    el.scrollIntoView();
  }


}
