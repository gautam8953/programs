import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-company-services',
  templateUrl: './company-services.component.html',
  styleUrls: ['./company-services.component.css']
})
export class CompanyServicesComponent implements OnInit {
  apiBaseUrl=environment.apiBaseUrl;
  imageBaseUrl=environment.imageBaseUrl;
  thumbImageBaseUrl=environment.thumbImageBaseUrl;

  validateForm: FormGroup;
  submitted = false;
  errors:any=[];
  res_message=null;
  res_message_class=null;
  
  serviceDetails:any=[];
  id=null;
  companyID=null;
  CompanySectorServices=[];

  constructor(
    private Common:CommonService,
    private formBuilder: FormBuilder,
    private router: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.companyID=this.router.snapshot.paramMap.get('companyID');
    this.id=this.router.snapshot.paramMap.get('id');
    this.validateForm = this.formBuilder.group({
      subject: ['', [Validators.required]],
      email: ['', [Validators.required,Validators.email]],
      fullName: ['', [Validators.required]],
      mobile: ['', [Validators.required,Validators.maxLength(10),Validators.minLength(10),Validators.pattern("^[0-9]*$")]],
      message: ['', [Validators.required]],
      companyID:[this.companyID,[]]
    });

    this.getCompanySectorServices();
    this.getServiceData();
  }
  get formControls() { return this.validateForm.controls; }
  getServiceData(){
    let dataSend={};
    dataSend['id']=this.id;
    dataSend['companyID']=this.companyID;
    this.Common.companyServiceData(dataSend).subscribe(
      data=>this.handleServiceData(data),
      error=>console.log(error)
    );    
  }
  handleServiceData(data){
    this.serviceDetails=data.data;
    console.log(this.serviceDetails);

  }
  scroll(el: HTMLElement) {
    el.scrollIntoView();
  }
  onCompanyContactSubmit(){
    this.submitted = true;
    console.log(this.validateForm.value);
    if (this.validateForm.valid) {
      this.Common.companyContact(this.validateForm.value).subscribe(
        data=>this.handleCompanyContactResponse(data),
        error=>this.handleCompanyContactErrors(error)
      );
    } else {
      return;
    }
  }
  handleCompanyContactResponse(response){
    this.res_message=response.res_message;
    this.res_message_class=response.res_message_class;
  }
  handleCompanyContactErrors(responseError){
    this.errors=responseError.error;
  }
  getCompanySectorServices(){
    let dataSend={};
    //dataSend['companyName']=this.messageMine;
    this.Common.getCompanySectorServicesData(dataSend,this.companyID).subscribe(
      data=>this.handleCompanySectorServicesData(data),
      error=>console.log(error)
    );        
  }
  handleCompanySectorServicesData(data){
    this.CompanySectorServices=data.data;
  }

}
