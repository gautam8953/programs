import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { UserService } from 'src/app/services/user.service';
import { TokenService } from 'src/app/services/token.service';
import { CommonService } from 'src/app/services/common.service';

declare var $: any;

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  validateForm: FormGroup;
  submitted = false;

  public form = {
    logo: File = null,
    logoName:null, 
    certificate: File = null,
    certificateName:null,
    password:null,
    password_confirmation:null
  };
  res_message=null;
  res_message_class=null;
  errors:any=[];
  public states=[];
  public districts=[];

  constructor(
    private User:UserService,
    private Token:TokenService,
    private router: Router,
    private formBuilder: FormBuilder,
    private Common:CommonService
    ) { }

  ngOnInit() {
    let today = new Date();
    $(".datepicker").datepicker({
      dateFormat: 'dd-mm-yy',
      maxDate: today
    });
    
    this.getstates();
    this.validateForm = this.formBuilder.group({
      companyName: ['', [Validators.required,Validators.maxLength(100)]],
      address: ['', [Validators.required,Validators.maxLength(254)]],
      state: [null, [Validators.required ]],
      district: [null, [Validators.required]],
      mobile: ['', [Validators.required,Validators.maxLength(10),Validators.minLength(10),Validators.pattern("^[0-9]*$") ]],
      email: ['', [Validators.required,Validators.email]],
      iecCode: ['', [Validators.required,Validators.maxLength(10)]],
      dateOfIssue: ['', []],
      panNumber: ['', []],
      dateOfEstablishment: ['', []],
      password: ['', [Validators.required,Validators.minLength(3)]],
      password_confirmation: ['', [Validators.required,Validators.minLength(3)]],
    });

  }
  get formControls() { return this.validateForm.controls; }

  onLogoChange(event){
    if(event.target.files.length){
      this.form.logo = event.target.files[0];
      this.form.logoName=event.target.files[0].name;
    } else {
      this.form.logo = null;
      this.form.logoName=null;
    }
  }
  onCertificateChange(event){
    if(event.target.files.length){
      this.form.certificate = event.target.files[0];
      this.form.certificateName=event.target.files[0].name;
    } else {
      this.form.certificate = null;
      this.form.certificateName=null;      
    }

  }
  onSubmit(){
    this.submitted = true;
    const formData = new FormData();
    formData.append('companyName', this.validateForm.value.companyName);
    formData.append('address', this.validateForm.value.address);
    formData.append('state', this.validateForm.value.state);
    formData.append('district', this.validateForm.value.district);
    formData.append('mobile', this.validateForm.value.mobile);
    formData.append('email', this.validateForm.value.email);
    formData.append('logo', this.form.logo);
    formData.append('iecCode', this.validateForm.value.iecCode);
    formData.append('dateOfIssue', this.validateForm.value.dateOfIssue);
    formData.append('panNumber', this.validateForm.value.panNumber);
    formData.append('dateOfEstablishment', this.validateForm.value.dateOfEstablishment);
    formData.append('certificate', this.form.certificate);
    formData.append('password', this.validateForm.value.password);
    formData.append('password_confirmation', this.validateForm.value.password_confirmation);    

    if (this.validateForm.valid) {
      this.User.register(formData).subscribe(
        data=>this.handleResponse(data),
        error=>this.handleErrors(error)
      );
    } else {
      window.scrollTo(0, 0);
      return;
    }


  }
  handleResponse(response){
    window.scrollTo(0, 0);
    this.res_message=response.res_message;
    this.res_message_class=response.res_message_class;
    if(response.res_message_class=='success'){
      setTimeout(() => {
        this.router.navigate(['/login']);
      }, 3000);      
    }
  }
  handleErrors(responseError){
    window.scrollTo(0, 0);
    this.errors=responseError.error;
  }

  getstates(){
    let dataSend={};
    this.Common.getstates(dataSend).subscribe(
      data=>this.handleStateData(data),
      error=>console.log(error)
    );
  }
  handleStateData(data){
    this.states=data.data
  }

  change_state(stateID : number){
    if(stateID==0){
      this.states=[];
    } else {
      let dataSend={};
      dataSend['stateID']=stateID;
      this.Common.getDistrict(dataSend).subscribe(
        data=>this.handleDistrictData(data),
        error=>console.log(error)
      );
    }

  }
  handleDistrictData(data){
    this.districts=data.data;
  }

}
