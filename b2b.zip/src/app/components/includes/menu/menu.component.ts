import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { environment } from './../../../../environments/environment';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  sectors:any=[];
  apiBaseUrl=environment.apiBaseUrl;
  imageBaseUrl=environment.imageBaseUrl;
  
  constructor(
    private Common:CommonService
  ) { }

  ngOnInit() {
    this.getSectors();
  }
  getSectors(){
    let dataSend={};
    this.Common.sectors(dataSend).subscribe(
      data=>this.handleSectorData(data),
      error=>console.log(error)
    );    
  }
  handleSectorData(data){
    this.sectors=data.data;
  }

}
