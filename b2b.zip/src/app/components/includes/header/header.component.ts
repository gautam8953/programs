import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';
import { TokenService } from 'src/app/services/token.service';
import { ShareableService } from "src/app/services/shareable.service";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css',
]
})
export class HeaderComponent implements OnInit {  
  appBaseUrl=environment.appBaseUrl;

  validateForm: FormGroup;
  // define the JSON of data


  public loggedIn: boolean;
  constructor(
    private Auth: AuthService,
    private router: Router,
    private Token: TokenService,
    private formBuilder: FormBuilder,
    private sharebaleData: ShareableService,
    private Common:CommonService
  ) { }

  ngOnInit() {
    this.validateForm = this.formBuilder.group({
      companyName:  ['', []],
    });
    this.Auth.authStatus.subscribe(value => this.loggedIn = value);
    this.getCompanies({});
  }
  getCompanies(dataSend){
    this.Common.getCompanies(dataSend).subscribe(
      data=>this.handleSectorData(data),
      error=>console.log(error)
    );        
  }
  handleSectorData(data){
    this.sharebaleData.changeCompanies(data.data);
  }

  logout(event: MouseEvent) {
    event.preventDefault();
    this.Auth.changeAuthStatus(false);
    localStorage.clear();
    //this.Token.remove();
    //localStorage.removeItem('userID');
    //localStorage.removeItem('entityID');
    this.router.navigateByUrl('/login');
  }
  onSubmit(){ 
    let datasend={};
    datasend['companyName']=this.validateForm.value.companyName;
    this.getCompanies(datasend);
    this.router.navigate(['/search']);


  }

}
