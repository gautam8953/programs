import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PortalLeftMenuComponent } from './portal-left-menu.component';

describe('PortalLeftMenuComponent', () => {
  let component: PortalLeftMenuComponent;
  let fixture: ComponentFixture<PortalLeftMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PortalLeftMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PortalLeftMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
