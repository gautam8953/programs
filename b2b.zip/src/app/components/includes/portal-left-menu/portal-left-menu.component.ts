import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';
import { TokenService } from 'src/app/services/token.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'

import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-portal-left-menu',
  templateUrl: './portal-left-menu.component.html',
  styleUrls: ['./portal-left-menu.component.css']
})
export class PortalLeftMenuComponent implements OnInit {
  imageBaseUrl=environment.imageBaseUrl;
  thumbImageBaseUrl=environment.thumbImageBaseUrl;
  appBaseUrl=environment.appBaseUrl;

  name = localStorage.getItem('name');
  logo = this.thumbImageBaseUrl+"/"+localStorage.getItem('logo');
  email = localStorage.getItem('emailID');
  currentUrl=null;
  constructor(
    private Auth: AuthService,
    private router: Router,
    private Token: TokenService,
    private formBuilder: FormBuilder
  ) { }

 
  ngOnInit() {
    this.currentUrl=this.router.url;
  }
    
  logout(event: MouseEvent) {
    event.preventDefault();
    this.Auth.changeAuthStatus(false);
    this.Token.remove();
    localStorage.removeItem('userID');
    localStorage.removeItem('entityID');
    this.router.navigateByUrl('/login');
  }

}
