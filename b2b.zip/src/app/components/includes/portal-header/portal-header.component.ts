import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portal-header',
  templateUrl: './portal-header.component.html',
  styleUrls: ['./portal-header.component.css']
  
})
export class PortalHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    // console.log(localStorage);
  }

}
