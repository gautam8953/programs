import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { UserService } from 'src/app/services/user.service';
import { CommonService } from 'src/app/services/common.service';


@Component({
  selector: 'app-add-service',
  templateUrl: './add-service.component.html',
  styleUrls: ['./add-service.component.css']
})
export class AddServiceComponent implements OnInit {

// 
public gameList: { [key: string]: Object }[] = [
  { Id: '', Keyword: '' },];
// map the appropriate columns to fields property
public fields: object = {text: 'Keyword', value: 'Id'};
public box : string = 'Box';
public placeholder: string = 'Enter your keyword';

// 



  validateForm: FormGroup;
  submitted = false;
  errors:any=[];
  sectors:any=[];
  services:any=[];
  res_message=null;
  res_message_class=null;
  icon: File = null;
  iconName=null;
  brochure: File = null;
  brochureName=null;
  isTops=[{"id":0,"isTopName":"No"},{"id":1,"isTopName":"Yes"}];

  constructor(
    private User:UserService,
    private router: Router,
    private formBuilder: FormBuilder,
    private Common:CommonService        
  ) { }

  ngOnInit() {
    this.validateForm = this.formBuilder.group({
      serviceName: ['', [Validators.required]],
      descriptions: ['', [Validators.required]],
      keywords: ['', [Validators.required]],
      sector: ['', [Validators.required]],
      service: ['', [Validators.required]],
      contactName: ['', [Validators.required]],
      contactEmail: ['', [Validators.required,Validators.email]],
      contactMobile: ['', [Validators.required,Validators.maxLength(10),Validators.minLength(10),Validators.pattern("^[0-9]*$")]],
      icon: ['', []],
      brochure: ['', []],
      isTop: [0, []]
    });
    this.getServiceDetails();
    this.getSectors();
    
  }

  get formControls() { return this.validateForm.controls; }

  getServiceDetails(){    
    this.validateForm.controls['sector'].setValue(null);
    this.validateForm.controls['service'].setValue(null);
  }

  onIconChange(event){
    if(event.target.files.length){
      this.icon = event.target.files[0];
      this.iconName=event.target.files[0].name;
    } else {
      this.icon = null;
      this.iconName=null;      
    }
  }
  onBrochureChange(event){
    if(event.target.files.length){
      this.brochure = event.target.files[0];
      this.brochureName=event.target.files[0].name;
    } else {
      this.brochure = null;
      this.brochureName=null;      
    }
  }

  onSubmit(){
    this.submitted = true;
    const formData = new FormData();
    formData.append('serviceName', this.validateForm.value.serviceName);
    formData.append('descriptions', this.validateForm.value.descriptions);
    formData.append('keywords', this.validateForm.value.keywords);
    formData.append('sectorID', this.validateForm.value.sector);
    formData.append('serviceID', this.validateForm.value.service);
    formData.append('contactName', this.validateForm.value.contactName);
    formData.append('contactEmail', this.validateForm.value.contactEmail);
    formData.append('contactMobile', this.validateForm.value.contactMobile);
    formData.append('isTop', this.validateForm.value.isTop);
    formData.append('icon', this.icon);
    formData.append('brochure', this.brochure);

    if (this.validateForm.valid) {
      this.User.addServices(formData).subscribe(
        data=>this.handleResponse(data),
        error=>this.handleErrors(error)
      );
    } else {
      this.scrollTotopPage();
      console.log('false');
      return;
    }
    
    
    
  }
  handleResponse(response){
    this.scrollTotopPage();
    this.res_message=response.res_message;
    this.res_message_class=response.res_message_class;
    // if(response.res_message_class=='success'){
    //   setTimeout(() => {
    //     this.router.navigate(['/login']);
    //   }, 3000);      
    // }
  }
  handleErrors(responseError){
    this.scrollTotopPage();
    this.errors=responseError.error;
  }

  getSectors(){
    let dataSend={};
    this.Common.sectors(dataSend).subscribe(
      data=>this.handleSectorData(data),
      error=>console.log(error)
    );    
  }
  handleSectorData(data){
    this.sectors=data.data;
  }

  change_sector(sectorID: number){
    let dataSend={};
    dataSend['sectorID']=sectorID;    
    this.Common.getServices(dataSend).subscribe(
      data=>this.handleServicesData(data),
      error=>console.log(error)
    );
  }
  handleServicesData(data){
    this.services=data.data;
  }
  scrollTotopPage(){
    window.scrollTo(0, 0);
  }

}
