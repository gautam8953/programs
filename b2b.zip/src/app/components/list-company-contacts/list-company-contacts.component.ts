import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-list-company-contacts',
  templateUrl: './list-company-contacts.component.html',
  styleUrls: ['./list-company-contacts.component.css']
})
export class ListCompanyContactsComponent implements OnInit {
  companyContacts:any=[];
  constructor(
    private User:UserService,
  ) { }

  ngOnInit() {
    this.getCompanyContacts();
  }
  getCompanyContacts(){
    let dataSend={};
    this.User.getCompanyContacts(dataSend).subscribe(
      data=>this.handleCompanyContactsData(data),
      error=>console.log(error)
    );    
  }
  handleCompanyContactsData(data){
    this.companyContacts=data.data;
  }

}
