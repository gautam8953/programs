import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCompanyContactsComponent } from './list-company-contacts.component';

describe('ListCompanyContactsComponent', () => {
  let component: ListCompanyContactsComponent;
  let fixture: ComponentFixture<ListCompanyContactsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListCompanyContactsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListCompanyContactsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
