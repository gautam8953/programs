import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { UserService } from 'src/app/services/user.service';
import { TokenService } from 'src/app/services/token.service';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';

import { AngularEditorConfig } from '@kolkov/angular-editor';

@Component({
  selector: 'app-company-profile',
  templateUrl: './company-profile.component.html',
  styleUrls: ['./company-profile.component.css']
})
export class CompanyProfileComponent implements OnInit {
  
  name = 'Angular 6';
  htmlContent = '';
  config: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: '15rem',
    minHeight: '5rem',
    placeholder: 'Enter text here...',
    translate: 'no',   
    defaultFontName: 'Arial',
    customClasses: [
      {
        name: "quote",
        class: "quote",
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: "titleText",
        class: "titleText",
        tag: "h1",
      },
    ]
  };

  apiBaseUrl=environment.apiBaseUrl;
  imageBaseUrl=environment.imageBaseUrl;
  thumbImageBaseUrl=environment.thumbImageBaseUrl;
  validateForm: FormGroup;
  submitted = false;
  errors:any=[];
  res_message=null;
  res_message_class=null;  
  countries=[];
  states=[];
  districts=[];
  cities=[];
  companyTypes=[];
  logo: File = null;
  logoName=null;
  logoUrl=null;
  logoError:any=null;

  constructor(
    private User:UserService,
    private Token:TokenService,
    private router: Router,
    private formBuilder: FormBuilder,
    private Common:CommonService    
  ) { }

  ngOnInit() {
    this.getUserDetails();
    this.getCompanyType();
    this.getCountry();
    this.validateForm = this.formBuilder.group({
      companyName: ['', [Validators.required]],
      companyType: ['', [Validators.required ]],
      companyRegstrationNumber: ['', [Validators.required ]],
      websiteUrl: ['', []],
      companyLogo1: ['', [Validators.required]],
      companyDescription: ['', []],
      keywords: ['', [Validators.required ]],
      streetAddress: ['', [Validators.required ]],
      address1: ['', []],
      address2: ['', []],
      country: ['', []],
      state: ['', []],
      district: ['', []],
      zip: ['', []],
      code1: ['', []],
      area1: ['', []],
      telephone1: ['', []],
      totalEmployee: ['', []],
      salesTurnOver: ['', [Validators.maxLength(4),Validators.pattern("^[0-9]*$")]],
    });

  }

  get formControls() { return this.validateForm.controls; }

  onLogoChange(event){
    if(event.target.files.length){
      this.logo = event.target.files[0];
      this.logoName = event.target.files[0].name;
      this.validateForm.controls['companyLogo1'].setValue(event.target.files[0].name);
    } else {
      this.logo = null;
      this.logoName = null;
    }
    
    

    
    
  }

  onSubmit(){
    this.submitted = true;
    const formData = new FormData();
    formData.append('companyName', this.validateForm.value.companyName);
    formData.append('companyType', this.validateForm.value.companyType);
    formData.append('companyRegstrationNumber', this.validateForm.value.companyRegstrationNumber);
    formData.append('websiteUrl', this.validateForm.value.websiteUrl);
    formData.append('companyLogo1', this.validateForm.value.companyLogo1);
    formData.append('companyDescription', this.validateForm.value.companyDescription);
    formData.append('keywords', this.validateForm.value.keywords);
    formData.append('streetAddress', this.validateForm.value.streetAddress);
    formData.append('address1', this.validateForm.value.address1);
    formData.append('address2', this.validateForm.value.address2);
    formData.append('country', this.validateForm.value.country);
    formData.append('state', this.validateForm.value.state);
    formData.append('district', this.validateForm.value.district);
    formData.append('zip', this.validateForm.value.zip);
    formData.append('countryCode1', this.validateForm.value.code1);
    formData.append('areaCode1', this.validateForm.value.area1);
    formData.append('telephone1', this.validateForm.value.telephone1);
    formData.append('totalEmployee', this.validateForm.value.totalEmployee);
    formData.append('salesTurnOver', this.validateForm.value.salesTurnOver);
    formData.append('logo', this.logo);



    if (this.validateForm.valid) {
      this.User.update(formData).subscribe(
        data=>this.handleResponse(data),
        error=>this.handleErrors(error)
      );
    } else {
      this.scrollTotopPage();
      console.log('false');
      return;
    }
    
    
    
  }
  handleResponse(response){
    this.scrollTotopPage();
    this.res_message=response.res_message;
    this.res_message_class=response.res_message_class;
    this.getUserDetails();
    // if(response.res_message_class=='success'){
    //   setTimeout(() => {
    //     this.router.navigate(['/login']);
    //   }, 3000);      
    // }
  }
  handleErrors(responseError){
    this.scrollTotopPage();
    this.errors=responseError.error;
    this.logoError=this.errors.error.logo.toString();
  }

  getUserDetails(){
    this.User.getUserDetails().subscribe(
      data=>this.handleUserDetailsData(data),
      error=>this.handleUserError(error)
    );    
  }
  handleUserDetailsData(data){
    localStorage.setItem('logo',data.data.companyLogo);
    this.validateForm.controls['companyName'].setValue(data.data.companyName);
    this.validateForm.controls['companyType'].setValue(data.data.companyType);
    this.validateForm.controls['companyRegstrationNumber'].setValue(data.data.companyRegstrationNumber);
    this.validateForm.controls['websiteUrl'].setValue(data.data.websiteUrl);
    this.validateForm.controls['companyLogo1'].setValue(data.data.companyLogo);
    this.validateForm.controls['companyDescription'].setValue(data.data.companyDescription);
    this.validateForm.controls['keywords'].setValue(data.data.keywords);
    this.validateForm.controls['streetAddress'].setValue(data.data.streetAddress);
    this.validateForm.controls['address1'].setValue(data.data.address1);
    this.validateForm.controls['address2'].setValue(data.data.address2);
    this.validateForm.controls['country'].setValue(data.data.countryID);
    this.validateForm.controls['state'].setValue(data.data.stateID);
    this.validateForm.controls['district'].setValue(data.data.districtID);
    this.validateForm.controls['zip'].setValue(data.data.zip);
    this.validateForm.controls['totalEmployee'].setValue(data.data.totalEmployee);
    this.validateForm.controls['salesTurnOver'].setValue(data.data.salesTurnOver);
// console.log(data.data.companyLogo);
    let telephone1=[];
    
    if(data.data.telephone1!=null && data.data.telephone1!=''){
      telephone1=data.data.telephone1.split('-');
    }
    
    if(telephone1.length==3){
      this.validateForm.controls['code1'].setValue(telephone1[0]);
      this.validateForm.controls['area1'].setValue(telephone1[1]);
      this.validateForm.controls['telephone1'].setValue(telephone1[2]);      
    }

    this.logoName=null;

    this.change_country(data.data.countryID);
    this.change_state(data.data.stateID);
    this.change_district(data.data.districtID);
    
  }
  handleUserError(error){
    console.log(error.status);
  }
  getCompanyType(){
    this.Common.companyTypes().subscribe(
      data=>this.handleCompanyTypeData(data),
      error=>console.log(error)
    );
  }
  handleCompanyTypeData(data){
    this.companyTypes=data.data;
  }
  getCountry(){
    this.Common.getcountry().subscribe(
      data=>this.handleCountryData(data),
      error=>console.log(error)
    );
  }
  handleCountryData(data){
    this.countries=data.data;
  }
  change_country(countryID: number){
    let dataSend={};
    dataSend['countryID']=countryID;    
    this.Common.getstates(dataSend).subscribe(
      data=>this.handleStateData(data),
      error=>console.log(error)
    );
  }
  handleStateData(data){
    this.states=data.data
  }
  change_state(stateID: Number){
    let dataSend={};
    dataSend['stateID']=stateID;    
    this.Common.getDistrict(dataSend).subscribe(
      data=>this.handleDistrictData(data),
      error=>console.log(error)
    );
  }
  handleDistrictData(data){
    this.districts=data.data
  }
  change_district(districtID: Number){
    let dataSend={};
    dataSend['districtID']=districtID;    
    this.Common.getCity(dataSend).subscribe(
      data=>this.handleCityData(data),
      error=>console.log(error)
    );
  }
  handleCityData(data){
    this.cities=data.data
  }
  scrollTotopPage(){
    window.scrollTo(0, 0);
  }

}
