import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-manage-services',
  templateUrl: './manage-services.component.html',
  styleUrls: ['./manage-services.component.css']
})
export class ManageServicesComponent implements OnInit {
  services:any=[];

  constructor(
    private User:UserService,
  ) { }

  ngOnInit() {
    this.getServices();
  }
  getServices(){
    let dataSend={};
    this.User.getServices(dataSend).subscribe(
      data=>this.handleServicesData(data),
      error=>console.log(error)
    );    
  }
  handleServicesData(data){
    this.services=data.data;
  }
}
