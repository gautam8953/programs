import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { UserService } from 'src/app/services/user.service';
import { TokenService } from 'src/app/services/token.service';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  appBaseUrl=environment.appBaseUrl;

  validateForm: FormGroup;
  submitted = false;
  errors:any=[];
  res_message=null;
  res_message_class=null;

  constructor(
    private User:UserService,
    private Token:TokenService,
    private router: Router,
    private Auth:AuthService,
    private formBuilder: FormBuilder
    ) { }

    ngOnInit() {
      this.validateForm = this.formBuilder.group({
        username: ['', [Validators.required, Validators.minLength(1),Validators.maxLength(50)]],
        password: ['', [Validators.required, Validators.minLength(1),Validators.maxLength(25) ]]
      });
    }

    get formControls() { return this.validateForm.controls; }

  onSubmit(){
    this.submitted = true;
    if (this.validateForm.valid) {
      this.User.login(this.validateForm.value).subscribe(
        data=>this.handleResponse(data),
        error=>this.handleErrors(error)
      );
    } else {
      return;
    }
  }

  handleResponse(response){
    window.scrollTo(0, 0);
    this.Token.handle(response.data.access_token);
    localStorage.setItem('userID',response.data.userID);
    localStorage.setItem('entityID',response.data.entityID);
    localStorage.setItem('emailID',response.data.email);
    localStorage.setItem('logo',response.data.logo);
    localStorage.setItem('name',response.data.companyName);
    this.Auth.changeAuthStatus(true);
    this.res_message=response.res_message;
    this.res_message_class=response.res_message_class;    
    setTimeout(() => {
      window.location.href = this.appBaseUrl+"/dashboard";
      //this.router.navigate(['/company-profile']);
    }, 3000);
  }

  handleErrors(responseError){
    window.scrollTo(0, 0);
    if(responseError.error.res_message){
      this.res_message=responseError.error.res_message;
      this.res_message_class=responseError.error.res_message_class;
      this.errors=[];
    } else {
      this.errors=responseError.error.error;
      this.res_message=null;
    }
  }

}
