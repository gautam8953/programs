import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-all-services',
  templateUrl: './all-services.component.html',
  styleUrls: ['./all-services.component.css']
})
export class AllServicesComponent implements OnInit {
  apiBaseUrl=environment.apiBaseUrl
  imageBaseUrl=environment.imageBaseUrl;
  thumbImageBaseUrl=environment.thumbImageBaseUrl;

  sectors:any=[];
  services:any=[];
  sectorCode=null;

  constructor(
    private Common:CommonService
  ) { }

  ngOnInit() {
    this.getSectors();
  }
  getSectors(){
    let dataSend={};
    this.Common.sectors(dataSend).subscribe(
      data=>this.handleSectorData(data),
      error=>console.log(error)
    );    
  }
  handleSectorData(data){
    this.sectors=data.data;
    this.sectorCode=data.data[0].sectorCode;
    this.getServiceDetails(data.data[0].id,data.data[0].sectorCode);    
  }
  getServiceDetails(sectorID,sectorCode){
    this.sectorCode=sectorCode;
    let dataSend={};
    dataSend['sectorID']=sectorID;    
    this.Common.getServices(dataSend).subscribe(
      data=>this.handleServicesData(data),
      error=>console.log(error)
    );
  }
  handleServicesData(data){
    this.services=data.data;
  }

}
