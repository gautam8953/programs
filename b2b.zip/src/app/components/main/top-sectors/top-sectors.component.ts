import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-top-sectors',
  templateUrl: './top-sectors.component.html',
  styleUrls: ['./top-sectors.component.css']
})
export class TopSectorsComponent implements OnInit {
  apiBaseUrl=environment.apiBaseUrl
  imageBaseUrl=environment.imageBaseUrl;
  thumbImageBaseUrl=environment.thumbImageBaseUrl;
  isLoader=false;
  sectorsTop:any=[];

  constructor(
    private Common:CommonService
  ) { }

  ngOnInit() {
    this.isLoader=true;
    this.getSectors();
  }
  getSectors(){
    let dataSend={};
    dataSend['isTop']=1;
    this.Common.sectors(dataSend).subscribe(
      data=>this.handleSectorData(data),
      error=>console.log(error)
    );    
  }
  handleSectorData(data){
    this.sectorsTop=data.data;
  }

}
