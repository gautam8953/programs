export const environment = {
  production: true,
  appBaseUrl: 'http://dev-india-service-b2b.demosl-02.rvsolutions.in',
  backendBaseUrl: 'http://backend.dev-india-service-b2b.demosl-02.rvsolutions.in',
  apiBaseUrl: 'http://backend.dev-india-service-b2b.demosl-02.rvsolutions.in/api',
  imageBaseUrl: 'http://backend.dev-india-service-b2b.demosl-02.rvsolutions.in/public/uploads',
  thumbImageBaseUrl: 'http://backend.dev-india-service-b2b.demosl-02.rvsolutions.in/public/uploads/thumbnail',  
};
