<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ApiMonthly extends CI_Controller {

    public function __construct() {
        parent :: __construct();
        $this->load->model('MonthlyModel');
        $this->load->model('FacilityModel');
    }

    public function index() {
        
    }

    public function save() {
        $response = array();
        $dataSave = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $facilityUser = $data['facilityUser'];
                    $this->session->set_userdata('facilityUser', $data['facilityUser']);
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey'] = $this->session->userdata('APIKey');
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey'] = $this->session->userdata('APIKey');
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data = array('status'=>$this->input->post('status'));
                    foreach ($this->input->post('data') as $key => $value) {
                        $data[$value['name']] = $value['value'];
                    }
                    $facilityUser = $this->session->userdata('facilityUser');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $dataSave['monthly'] = array(
            'UserID' => $facilityUser,
            'ReportMonth' => isset($data['ReportMonth']) ? $data['ReportMonth'] != '' ? convert_date_db($data['ReportMonth']) : NULL : NULL,
            'CollectionDate' => isset($data['CollectionDate']) ? $data['CollectionDate'] != '' ? convert_date_db($data['CollectionDate']) : NULL : NULL,
            'TotalDeliveries' => isset($data['TotalDeliveries']) ? $data['TotalDeliveries'] != '' ? $data['TotalDeliveries'] : NULL : NULL,
            'TotalNormalVaginalDeliveries' => isset($data['TotalNormalVaginalDeliveries']) ? $data['TotalNormalVaginalDeliveries'] != '' ? $data['TotalNormalVaginalDeliveries'] : NULL : NULL,
            'TotalAssistedVaginalDeliveries' => isset($data['TotalAssistedVaginalDeliveries']) ? $data['TotalAssistedVaginalDeliveries'] != '' ? $data['TotalAssistedVaginalDeliveries'] : NULL : NULL,
            'TotalCSections' => isset($data['TotalCSections']) ? $data['TotalCSections'] != '' ? $data['TotalCSections'] : NULL : NULL,
            'TotalMaternalDeaths' => isset($data['TotalMaternalDeaths']) ? $data['TotalMaternalDeaths'] != '' ? $data['TotalMaternalDeaths'] : NULL : NULL,
            'MaternalAPH' => isset($data['MaternalAPH']) ? $data['MaternalAPH'] != '' ? $data['MaternalAPH'] : NULL : NULL,
            'MaternalPPH' => isset($data['MaternalPPH']) ? $data['MaternalPPH'] != '' ? $data['MaternalPPH'] : NULL : NULL,
            'MaternalSepsis' => isset($data['MaternalSepsis']) ? $data['MaternalSepsis'] != '' ? $data['MaternalSepsis'] : NULL : NULL,
            'MaternalObstructedLabour' => isset($data['MaternalObstructedLabour']) ? $data['MaternalObstructedLabour'] != '' ? $data['MaternalObstructedLabour'] : NULL : NULL,
            'MaternalPIHEclampsia' => isset($data['MaternalPIHEclampsia']) ? $data['MaternalPIHEclampsia'] != '' ? $data['MaternalPIHEclampsia'] : NULL : NULL,
            'MaternalOthers' => isset($data['MaternalOthers']) ? $data['MaternalOthers'] != '' ? $data['MaternalOthers'] : NULL : NULL,
            'TotalLiveBirths' => isset($data['TotalLiveBirths']) ? $data['TotalLiveBirths'] != '' ? $data['TotalLiveBirths'] : NULL : NULL,
            'TotalStillBirths' => isset($data['TotalStillBirths']) ? $data['TotalStillBirths'] != '' ? $data['TotalStillBirths'] : NULL : NULL,
            'TotalFreshStillBirths' => isset($data['TotalFreshStillBirths']) ? $data['TotalFreshStillBirths'] != '' ? $data['TotalFreshStillBirths'] : NULL : NULL,
            'TotalMaceratedStillBirths' => isset($data['TotalMaceratedStillBirths']) ? $data['TotalMaceratedStillBirths'] != '' ? $data['TotalMaceratedStillBirths'] : NULL : NULL,
            'NumberNeonatalDeaths' => isset($data['NumberNeonatalDeaths']) ? $data['NumberNeonatalDeaths'] != '' ? $data['NumberNeonatalDeaths'] : NULL : NULL,
            'NeonatalPrematurity' => isset($data['NeonatalPrematurity']) ? $data['NeonatalPrematurity'] != '' ? $data['NeonatalPrematurity'] : NULL : NULL,
            'NeonatalSepsis' => isset($data['NeonatalSepsis']) ? $data['NeonatalSepsis'] != '' ? $data['NeonatalSepsis'] : NULL : NULL,
            'NeonatalAsphyxia' => isset($data['NeonatalAsphyxia']) ? $data['NeonatalAsphyxia'] != '' ? $data['NeonatalAsphyxia'] : NULL : NULL,
            'NeonatalOthers' => isset($data['NeonatalOthers']) ? $data['NeonatalOthers'] != '' ? $data['NeonatalOthers'] : NULL : NULL,
            'TotalLowBirthWeightBabies' => isset($data['TotalLowBirthWeightBabies']) ? $data['TotalLowBirthWeightBabies'] != '' ? $data['TotalLowBirthWeightBabies'] : NULL : NULL,
            'TotalPretermDeliveries' => isset($data['TotalPretermDeliveries']) ? $data['TotalPretermDeliveries'] != '' ? $data['TotalPretermDeliveries'] : NULL : NULL,
            'BirthCompanionNos' => isset($data['BirthCompanionNos']) ? $data['BirthCompanionNos'] != '' ? $data['BirthCompanionNos'] : NULL : NULL,
            'SafeBirthChecklist' => isset($data['SafeBirthChecklist']) ? $data['SafeBirthChecklist'] != '' ? $data['SafeBirthChecklist'] : NULL : NULL,
            'CSectionOTSafeChecklist' => isset($data['CSectionOTSafeChecklist']) ? $data['CSectionOTSafeChecklist'] != '' ? $data['CSectionOTSafeChecklist'] : NULL : NULL,
            'RealTimePartograph' => isset($data['RealTimePartograph']) ? $data['RealTimePartograph'] != '' ? $data['RealTimePartograph'] : NULL : NULL,
            'BreastfedNewborns' => isset($data['BreastfedNewborns']) ? $data['BreastfedNewborns'] != '' ? $data['BreastfedNewborns'] : NULL : NULL,
            'MCBSamplingLR' => isset($data['MCBSamplingLR']) ? $data['MCBSamplingLR'] != '' ? $data['MCBSamplingLR'] : NULL : NULL,
            'MCBSamplingOT' => isset($data['MCBSamplingOT']) ? $data['MCBSamplingOT'] != '' ? $data['MCBSamplingOT'] : NULL : NULL,
            'CSectionsInfection' => isset($data['CSectionsInfection']) ? $data['CSectionsInfection'] != '' ? $data['CSectionsInfection'] : NULL : NULL,
            'PretermANCSInFacilitiesSNCU' => isset($data['PretermANCSInFacilitiesSNCU']) ? $data['PretermANCSInFacilitiesSNCU'] != '' ? $data['PretermANCSInFacilitiesSNCU'] : NULL : NULL,
            'NewbornsSNCUAsphyxia' => isset($data['NewbornsSNCUAsphyxia']) ? $data['NewbornsSNCUAsphyxia'] != '' ? $data['NewbornsSNCUAsphyxia'] : NULL : NULL,
            'NewbornsSNCUSepsis' => isset($data['NewbornsSNCUSepsis']) ? $data['NewbornsSNCUSepsis'] != '' ? $data['NewbornsSNCUSepsis'] : NULL : NULL,
            'InbornLBWKMC' => isset($data['InbornLBWKMC']) ? $data['InbornLBWKMC'] != '' ? $data['InbornLBWKMC'] : NULL : NULL,
            'SatisfiedDelivered' => isset($data['SatisfiedDelivered']) ? $data['SatisfiedDelivered'] != '' ? $data['SatisfiedDelivered'] : NULL : NULL,
            'ReorganizedLR' => isset($data['ReorganizedLR']) ? $data['ReorganizedLR'] != '' ? $data['ReorganizedLR'] : NULL : NULL,
            'AdequateStaffLR' => isset($data['AdequateStaffLR']) ? $data['AdequateStaffLR'] != '' ? $data['AdequateStaffLR'] : NULL : NULL,
            'OxytocinCount' => isset($data['OxytocinCount']) ? $data['OxytocinCount'] != '' ? $data['OxytocinCount'] : NULL : NULL,
            'MaternalDeathsReviewed' => isset($data['MaternalDeathsReviewed']) ? $data['MaternalDeathsReviewed'] != '' ? $data['MaternalDeathsReviewed'] : NULL : NULL,
            'NeonatalDeaths' => isset($data['NeonatalDeaths']) ? $data['NeonatalDeaths'] != '' ? $data['NeonatalDeaths'] : NULL : NULL,
            'MaternalMissCases' => isset($data['MaternalMissCases']) ? $data['MaternalMissCases'] != '' ? $data['MaternalMissCases'] : NULL : NULL,
            'ReferralCases' => isset($data['ReferralCases']) ? $data['ReferralCases'] != '' ? $data['ReferralCases'] : NULL : NULL,
            'StockOutsInLR' => isset($data['StockOutsInLR']) ? $data['StockOutsInLR'] != '' ? $data['StockOutsInLR'] : NULL : NULL,
            'StockOutsInOT' => isset($data['StockOutsInOT']) ? $data['StockOutsInOT'] != '' ? $data['StockOutsInOT'] : NULL : NULL,
            'NQASCertification' => isset($data['NQASCertification']) ? $data['NQASCertification'] != '' ? $data['NQASCertification'] : NULL : NULL,
            'MCHDHFunctional' => isset($data['MCHDHFunctional']) ? $data['MCHDHFunctional'] != '' ? $data['MCHDHFunctional'] : NULL : NULL,
            'LaQshyaMentoringVisitsConducted' => isset($data['LaQshyaMentoringVisitsConducted']) ? $data['LaQshyaMentoringVisitsConducted'] != '' ? $data['LaQshyaMentoringVisitsConducted'] : NULL : NULL,
            'QITeamMeetings' => isset($data['QITeamMeetings']) ? $data['QITeamMeetings'] != '' ? $data['QITeamMeetings'] : NULL : NULL,
            'TrainingSessionConducted' => isset($data['TrainingSessionConducted']) ? $data['TrainingSessionConducted'] != '' ? $data['TrainingSessionConducted'] : NULL : NULL,
            'CurrentLabourRoomQualityScore' => isset($data['CurrentLabourRoomQualityScore']) ? $data['CurrentLabourRoomQualityScore'] != '' ? $data['CurrentLabourRoomQualityScore'] : NULL : NULL,
            'CurrentMaternityOTQualityScore' => isset($data['CurrentMaternityOTQualityScore']) ? $data['CurrentMaternityOTQualityScore'] != '' ? $data['CurrentMaternityOTQualityScore'] : NULL : NULL,
            'CurrentOSCEScore' => isset($data['CurrentOSCEScore']) ? $data['CurrentOSCEScore'] != '' ? $data['CurrentOSCEScore'] : NULL : NULL,
            'MonthlyStatus' => $data['status'] == 'save' ? '1' : '0',
        );
        $dataSave['oneTime'] = array(
            'UserID' => $facilityUser,
            'BaselineNQASChecklistLR' => isset($data['BaselineNQASChecklistLR']) ? $data['BaselineNQASChecklistLR'] != '' ? $data['BaselineNQASChecklistLR'] : NULL : NULL,
            'AssessmentMonthLR' => isset($data['AssessmentMonthLR']) ? $data['AssessmentMonthLR'] != '' ? convert_date_db($data['AssessmentMonthLR']) : NULL : NULL,
            'BaselineScoreLR' => isset($data['BaselineScoreLR']) ? $data['BaselineScoreLR'] != '' ? $data['BaselineScoreLR'] : NULL : NULL,
            'BaselineNQASChecklistOT' => isset($data['BaselineNQASChecklistOT']) ? $data['BaselineNQASChecklistOT'] != '' ? $data['BaselineNQASChecklistOT'] : NULL : NULL,
            'AssessmentMonthOT' => isset($data['AssessmentMonthOT']) ? $data['AssessmentMonthOT'] != '' ? convert_date_db($data['AssessmentMonthOT']) : NULL : NULL,
            'BaselineScoreOT' => isset($data['BaselineScoreOT']) ? $data['BaselineScoreOT'] != '' ? $data['BaselineScoreOT'] : NULL : NULL,
            'BaselineStaffCompetenceOSCE' => isset($data['BaselineStaffCompetenceOSCE']) ? $data['BaselineStaffCompetenceOSCE'] != '' ? $data['BaselineStaffCompetenceOSCE'] : NULL : NULL,
            'AssessmentMonthOSCE' => isset($data['AssessmentMonthOSCE']) ? $data['AssessmentMonthOSCE'] != '' ? convert_date_db($data['AssessmentMonthOSCE']) : NULL : NULL,
            'BaselineAvgOSCEScore' => isset($data['BaselineAvgOSCEScore']) ? $data['BaselineAvgOSCEScore'] != '' ? $data['BaselineAvgOSCEScore'] : NULL : NULL,
            'QualityTeamFacility' => isset($data['QualityTeamFacility']) ? $data['QualityTeamFacility'] != '' ? $data['QualityTeamFacility'] : NULL : NULL,
            'QualityCircleLR' => isset($data['QualityCircleLR']) ? $data['QualityCircleLR'] != '' ? $data['QualityCircleLR'] : NULL : NULL,
            'QualityCircleOT' => isset($data['QualityCircleOT']) ? $data['QualityCircleOT'] != '' ? $data['QualityCircleOT'] : NULL : NULL,
            'OrientationAttended' => isset($data['OrientationAttended']) ? $data['OrientationAttended'] != '' ? $data['OrientationAttended'] : NULL : NULL,
        );

        if(!empty($facilityUser) && !empty($dataSave['monthly']['ReportMonth']) ){
            $response = $this->MonthlyModel->saveMonthly($dataSave);
        } else {
            $response['code']='9';
            $response['msg']=$this->config->item('errCodes')[9];
        }        
        if (isset($dataHeader['device']) && $dataHeader['device'] == 'app') {
            $response['APIKey'] = $this->session->userdata('APIKey');
        }        
        echo json_encode($response);
        exit;
    }

    function getMonthly() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $facilityUser = $data1['facilityUser'];
                    $setDataMonth = $data1['setDataMonth'];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey'] = $this->session->userdata('APIKey');
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey'] = $this->session->userdata('APIKey');
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $facilityUser = $this->session->userdata('facilityUser');
                    $setDataMonth = $this->session->userdata('setDataMonth');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $response = $this->MonthlyModel->getMonthly($facilityUser, $setDataMonth);
        if (isset($dataHeader['device']) && $dataHeader['device'] == 'app') {
            if(!empty($response['data'][0]['CollectionDate'])){
                $response['data'][0]['CollectionDate']=convert_date_show($response['data'][0]['CollectionDate']);
            }
            if(!empty($response['data'][0]['ReportMonth'])){                
                $response['data'][0]['ReportMonth']=convert_date_show($response['data'][0]['ReportMonth']);
            }
            $response['APIKey'] = $this->session->userdata('APIKey');
        }        
        echo json_encode($response);
        exit;
    }

    function getMonthlyView() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $page = $data['setMonthViewPage'];
                    $facilityUser = $data['facilityUser'];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey'] = $this->session->userdata('APIKey');
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey'] = $this->session->userdata('APIKey');
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $page = $this->session->userdata('setMonthViewPage');
                    //$facilityUser = $this->session->userdata('facilityUser');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($page)){
            $response = $this->MonthlyModel->getMonthlyView($page);
        } else {
            $response['code']='9';
            $response['msg']=$this->config->item('errCodes')[9];
        }
        
        if (isset($dataHeader['device']) && $dataHeader['device'] == 'app') {
            $response['APIKey'] = $this->session->userdata('APIKey');
        }
        echo json_encode($response);
        exit;
    }

    function getOneTime() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $facilityUser = $data1['facilityUser'];
                    $response = $this->MonthlyModel->getOneTime($facilityUser);
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey'] = $this->session->userdata('APIKey');
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey'] = $this->session->userdata('APIKey');
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    //$data = $this->input->post();
                    $page=$this->session->userdata('setMonthViewPage');
                    $response = $this->MonthlyModel->getOneTime_web($page);
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }        
        if (isset($dataHeader['device']) && $dataHeader['device'] == 'app') {
            $response['APIKey'] = $this->session->userdata('APIKey');
        }
        echo json_encode($response);
        exit;
    }

    public function getSearchData() {
        if ($this->CommonModel->checkAPIWebUser()) {
            $searchData = $this->input->post();
            if($this->session->userdata('RoleName')=='State'){
                $searchData['cond']=array('mappedField'=>'f.StateID','mappedData'=>$this->session->userdata('MappedState'));
            }
            if($this->session->userdata('RoleName')=='District'){
                $searchData['cond']=array('mappedField'=>'f.DistrictID','mappedData'=>$this->session->userdata('MappedDistrict'));
            }
            if($this->session->userdata('RoleName')=='Facility'){
                $searchData['cond']=array('mappedField'=>'um.UserID','mappedData'=>$this->session->userdata('UserID'));
            }
            $searchData['search_months'] = $this->input->post('search_months');
            $searchData['search_years'] = $this->input->post('search_years');
            $data = $this->MonthlyModel->getSearchData($searchData);

            $json_data = array(
                "draw" => intval($data['draw']),
                "recordsTotal" => intval($data['totalData']),
                "recordsFiltered" => intval($data['totalFilter']),
                "data" => $data['data']
            );
            echo json_encode($json_data);
        } else {
            $json_data = array(
                "draw" => 0,
                "recordsTotal" => 0,
                "recordsFiltered" => 0,
                "data" => array()
            );
            echo json_encode($json_data);            
        }
    }

    function checkMonthlyFacilityAdd() {
        $response = array('code' => '1', 'New Entry not allowed');
        if ($this->input->method(true) == 'POST') {
            $data = apache_request_headers();
            $device = $this->input->post('device');
            if (strtolower($device) == 'web') {
                if (!$this->CommonModel->checkAPIWebUser()) {
                    $response['code'] = '11';
                    $response['msg'] = 'Not Logged In';
                } else {
                    // true do code here
                    $response = $this->MonthlyModel->checkMonthlyFacilityAdd($this->session->userdata('facilityUser'));
                }
            } else {
                // do app code here
                $response['code'] = '5';
                $response['msg'] = $this->config->item('errCodes')[5];
            }
        } else {
            $response['code'] = '1';
            $response['msg'] = 'Bad Request Method';
        }
        echo json_encode($response);
        exit;
    }

    function setViewPage() {
        if ($this->CommonModel->checkAPIWebUser()) {
        $this->session->set_userdata('setMonthViewPage', $this->input->post('setData'));
        $this->session->set_userdata('setDataMonth', $this->input->post('setDataMonth'));
        if (TRUE) {
            $response['code'] = '0';
        } else {
            $response['code'] = '1';
        }
        echo json_encode($response);
    }
    }

    function monthReportCheck(){
        $response=array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        $data=array();
        $this->load->model('UserModel');
        if(isset($dataHeader['device']) || isset($dataHeader['token'])){
            if($this->input->method(true) == 'POST'){
                if($this->CommonModel->checkAppRequest($dataHeader)){
                    // get data and process api requrest
                    $data1=$this->CommonModel->getApiData();
                    $month = $data1['reportMonths'];
                    $year = $data1['reportYears'];
                    $facilityUser = $data1['facilityUser'];
                    $dateRpt = $year . '-' . $month . '-01';
                } else {
                    $response['code']='5';
                    $response['msg']=$this->config->item('errCodes')[5];
                    echo json_encode($response);
                    exit;
                }               
            } else {
                $response['code']='8';
                $response['msg']=$this->config->item('errCodes')[8];
                echo json_encode($response);
                exit;
            }
        } else {
            if($this->input->method(true) == 'POST'){
                if($this->CommonModel->checkAPIWebUser()){
                    // get data and process web requrest
                    $month = $this->input->post('reportMonths');
                    $year = $this->input->post('reportYears');
                    $facilityUser = $this->session->userdata('facilityUser');
                    $dateRpt = $year . '-' . $month . '-01';
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($facilityUser) && !empty($month) && !empty($year)){
            $response = $this->MonthlyModel->monthReportCheck($dateRpt, $facilityUser);
        } else {
            $response['code']='9';
            $response['msg']=$this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit; 
    }

    /*function monthReportCheck() {
        $response = array();
        if ($this->input->method(true) == 'POST') {
            $data = apache_request_headers();
            $device = $this->input->post('device');
            if (strtolower($device) == 'web') {
                if (!$this->CommonModel->checkAPIWebUser()) {
                    $response['code'] = '11';
                    $response['msg'] = 'Not Logged In';
                } else {
                    // true do code here

                    
                }
            } else {
                // do app code here
                $response['code'] = '2';
                $response['msg'] = $this->config->item('errCodes')[2];
            }
        } else {
            $response['code'] = '1';
            $response['msg'] = 'Bad Request Method';
        }
        echo json_encode($response);
        exit;
    }*/

    public function getSearchDataAll() {
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $userIdRole = $this->session->userdata('RoleID');
                    $userRoleName = $this->session->userdata('RoleName');
                    $userId = $this->session->userdata('UserID');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if (!empty($userIdRole) && !empty($userRoleName) && !empty($userId)) {
            switch ($userRoleName) {
                case 'District':
                    $facilityData = $this->CommonModel->facilitySearchData($userId);
                    $respones['states'] = array();
                    $respones['district'] = array();
                    $respones['facility'] = array();
                    $respones['facilityType'] = array();
                    break;
                case 'State':
                    $facilityData = $this->CommonModel->facilitySearchData($userId);
                    $respones['states'] = array();
                    $respones['district'] = array();
                    $respones['facility'] = array();
                    $respones['facilityType'] = array();
                    break;
                case 'Ministry':
                    $facilityData = $this->CommonModel->facilitySearchData($userId);
                    $respones['states'] = array();
                    $respones['district'] = array();
                    $respones['facility'] = array();
                    $respones['facilityType'] = array();
                    break;
                default:
                    $facilityData = $this->CommonModel->facilitySearchData($userId);
                    if (!empty($facilityData)) {
                        $respones['states'] = array('value' => $facilityData[0]['StateID'], 'text' => $facilityData[0]['StateName']);
                        $respones['district'] = array('value' => $facilityData[0]['DistrictID'], 'text' => $facilityData[0]['DistrictName']);
                        $respones['facility'] = array('value' => $facilityData[0]['UserID'], 'text' => $facilityData[0]['FacilityName']);
                        $respones['facilityType'] = array('value' => $facilityData[0]['TypeDetailID'], 'text' => $facilityData[0]['TypeDetailCode']);
                    } else {
                        $respones['states'] = array();
                        $respones['district'] = array();
                        $respones['facility'] = array();
                        $respones['facilityType'] = array();
                    }
                    break;
            }
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit;
    }
    
    public function getSearchMonthlyReportData() {
        if ($this->CommonModel->checkAPIWebUser()) {
        $searchData = $this->input->post();
        $search_months = $this->input->post('search_months');
        $search_years = $this->input->post('search_years');
        $search_state = $this->input->post('search_state');
        $search_district = $this->input->post('search_district');
        $search_facility = $this->input->post('search_facility');
        $search_options = $this->FacilityModel->getSearchOptions();
//                print_r($search_options); die;
//                echo "B"; die;
        $data = $this->MonthlyModel->getSearchMonthlyReportData($search_months, $search_years, $searchData,$search_options,$search_state,$search_district,$search_facility );
        //$this->session->set_userdata('facilityUser', $userID);

        $json_data = array(
            "draw" => intval($data['draw']),
            "recordsTotal" => intval($data['totalData']),
            "recordsFiltered" => intval($data['totalFilter']),
            "data" => $data['data']
        );
        echo json_encode($json_data);
        }
    }
    public function reportData_certificate() {
        if ($this->CommonModel->checkAPIWebUser()) {
        $searchData = $this->input->post();
        $data = $this->MonthlyModel->reportData_certificate($searchData);
        $json_data = array(
            "draw" => intval($data['draw']),
            "recordsTotal" => intval($data['totalData']),
            "recordsFiltered" => intval($data['totalFilter']),
            "data" => $data['data']
        );
            echo json_encode($json_data);
        }
    }
    function setMonthlyData() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey'] = $this->session->userdata('APIKey');
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey'] = $this->session->userdata('APIKey');
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $MonthlyID = $this->input->post('MonthlyID');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $setData=$this->MonthlyModel->setMonthlyData($MonthlyID);
        if($setData){
            $response['code']='0';
        } else {
            $response['code']='1';
        }
        echo json_encode($response);
        exit;
    }



}
