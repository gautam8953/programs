<?php

class AuditModel extends CI_Model {
	function __construct() {
		parent::__construct();
	}

	function save_csection($data){
		$response=array('code'=>26,'msg'=>$this->config->item('errCodes')[26]);
		if(empty($data['id'])){
			$data['main']['CreatedOn']=date('Y-m-d H:i:s');
			$data['main']['CreatedBy']=$data['user'];
			$this->db->insert('csection', $data['main']);
			$csectionID=$this->db->insert_id();
			if($csectionID>0){
				// insert success
				$response['code']=0;
				$response['msg']=$this->config->item('errCodes')[0];
				$response['csectionID']=encryptor($csectionID);
			} else {
				// insert falied
				$response['code']=11;
				$response['msg']=$this->config->item('errCodes')[11];
				$response['csectionID']=0;
			}
		} else {
			// edit mode
				$data['main']['ModifiedOn']=date('Y-m-d H:i:s');
				$data['main']['ModifiedBy']=$data['user'];
				$this->db->where('id', $data['id']);
				if ($this->db->update('csection', $data['main'])=== FALSE){
					$response['code']=11;
					$response['msg']=$this->config->item('errCodes')[11];
					$response['csectionID']=encryptor($data['id']);
				} else {
					$response['code']=0;
					$response['msg']=$this->config->item('errCodes')[27];
					$response['csectionID']=encryptor($data['id']);
				}
		}
		return $response;
	}
	function getSearchDataCsection($searchData){

        $data = array();
        $col = array(
            0 => 'FacilityName',
        );
	  	$this->db->select('f.facilityName');
	    $this->db->from('csection');
		$this->db->join('usermapping um','csection.userID=um.UserID');
		$this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
		$this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
		$this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
		if(!empty($searchData['cond'])){
			$this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
		}
	    $this->db->where('csection.IsActive','1');
	    if($searchData['RoleName']!='Facility'){
	    	$this->db->where('csection.status','1');
	    }
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            if(strtolower($searchString)=='completed' || strtolower($searchString)=='complete'){ 
                $this->db->where("(csection.status='1')", NULL, FALSE);
            } else if(strtolower($searchString)=='incomplete'){
                $this->db->where("(csection.status='0')", NULL, FALSE);
            } else {
                $this->db->where("(f.FacilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        if(!empty($searchData['search_state'])){
        	$this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
        	$this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
        	$this->db->where('csection.userID',$searchData['search_facility']);
        }
	    $queryTot = $this->db->get();

	    $this->db->select('f.FacilityName,s.StateName,d.DistrictName,csection.userID,csection.id,csection.status,csection.dos');
	    $this->db->from('csection');

		$this->db->join('usermapping um','csection.userID=um.UserID');
		$this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
		$this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
		$this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
		if(!empty($searchData['cond'])){
		$this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
		}
	    $this->db->where('csection.IsActive','1');
	    if($searchData['RoleName']!='Facility'){
	    	$this->db->where('csection.status','1');
	    }
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            if(strtolower($searchString)=='completed' || strtolower($searchString)=='complete'){ 
                $this->db->where("(csection.status='1')", NULL, FALSE);
            } else if(strtolower($searchString)=='incomplete'){
                $this->db->where("(csection.status='0')", NULL, FALSE);
            } else {
                $this->db->where("(f.FacilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        if(!empty($searchData['search_state'])){
        	$this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
        	$this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
        	$this->db->where('csection.userID',$searchData['search_facility']);
        }
	    $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
	    $this->db->limit($this->input->post('length'),$this->input->post('start'));
	    $query = $this->db->get();
	    $cnt=$searchData['start'];

        //$access_add=$this->CommonModel->checkPageActionWeb('audit/index','access_add',$this->session->userdata('RoleName'));
        $access_edit=$this->CommonModel->checkPageActionWeb('audit/index','access_edit',$this->session->userdata('RoleName'));
        //$access_delete=$this->CommonModel->checkPageActionWeb('audit/index','access_delete',$this->session->userdata('RoleName'));
        $access_view=$this->CommonModel->checkPageActionWeb('audit/index','access_view',$this->session->userdata('RoleName'));
		foreach ($query->result_array() as $key => $value) {
			$subdata=array();
			$subdata[]=++$cnt;
			if($searchData['RoleName']=='Ministry'){
            	$subdata[] = $value['StateName'];
        	}
        	if($searchData['RoleName']=='State' || $searchData['RoleName']=='Ministry'){
            	$subdata[] = $value['DistrictName'];
            }
            if($searchData['RoleName']=='District' || $searchData['RoleName']=='State' || $searchData['RoleName']=='Ministry' ){
            	$subdata[] = $value['FacilityName'];
            }
			$subdata[] = convert_date_show($value['dos']);
			$subdata[] = $value['status']==1?'Submitted':'Draft';
			$checkListUrl='reports/checklist';
			if($value['status']==1){
				$actionLink='';
				if($access_view){
					$actionLink.='<button data-href="'.base_url().'audit/csectionview/'.encryptor($value['id']).'"  onclick="pageRedirect(this)" class="btn btn-warning btn-xs view" >View</button>';
				}
				$subdata[] = $actionLink;
			} else {
				$actionLink='';
				if($access_edit){
					$actionLink.='<button data-href="'.base_url().'audit/csection/'.encryptor($value['id']).'"  onclick="pageRedirect(this)" class="btn btn-warning btn-xs view" >Edit</button>';
				}
				$subdata[] = $actionLink;
			}
			
			$data[] = $subdata;
		}

		return array('totalData'=>$queryTot->num_rows(),'totalFilter'=>$queryTot->num_rows(),'data'=>$data);
	}
	function getCsectionData($id){
		$this->db->select('csection.*,f.FacilityName');
		$this->db->from('csection');
		$this->db->join('usermapping um','csection.UserID=um.UserID AND um.IsActive=1','inner');
		$this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
		$this->db->where('id',$id);
		$query = $this->db->get();
		if($query->num_rows()>0){
			return $query->row_array();
		} else {
			return array();
		}

	}





}