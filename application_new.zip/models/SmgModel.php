<?php

class SmgModel extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function saveData($saveData) {
        if ($this->db->insert('smg_report', $saveData)) {
            $ansId = $this->db->insert_id();
        } else {
            $ansId = 0;
        }
        return $ansId;
    }

    function getSearchData($userID, $searchData, $search_state) {
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
        $col = array(
            //0 => 'sr.stateId',
            0 => 'name',
            1 => 'department',
            2 => 'designation',
            3 => 'designationSmg',
            4 => 'email',
            5 => 'mobile'
        );
        $this->db->select('count(sr.id) recordCount');
        $this->db->from('smg_report as sr');
        $this->db->join('states as s', 's.StateId= sr.stateId', 'inner');
        if ($this->session->userdata('RoleName') == 'State') {
            $this->db->where('sr.userId', $userID);
        }
        $this->db->where('sr.isActive', 1);
        if ($search_state != '') {
            $this->db->where('sr.stateId', $search_state);
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);

            $this->db->where("(sr.name like '%" . $searchString . "%' OR sr.department like '%" . $searchString . "%' OR sr.designation like '%" . $searchString . "%' OR sr.designationSmg like '%" . $searchString . "%' OR sr.mobile like '%" . $searchString . "%' OR sr.email like '%" . $searchString . "%')", NULL, FALSE);
        }
        $queryTot = $this->db->get();
        $row = $queryTot->result();
        $totalRecordCount = $row[0]->recordCount;
//        var_dump($this->db->last_query());

        $this->db->select('s.StateName,sr.id,sr.name,sr.department,sr.designation,sr.designationSmg,sr.email,sr.mobile');
        $this->db->from('smg_report as sr');
        $this->db->join('states as s', 's.StateId= sr.stateId', 'inner');
        if ($this->session->userdata('RoleName') == 'State') {
            $this->db->where('sr.userId', $userID);
        }
        $this->db->where('sr.isActive', 1);
        if ($search_state != '') {
            $this->db->where('sr.stateId', $search_state);
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);

            $this->db->where("(sr.name like '%" . $searchString . "%' OR sr.department like '%" . $searchString . "%' OR sr.designation like '%" . $searchString . "%' OR sr.designationSmg like '%" . $searchString . "%' OR sr.mobile like '%" . $searchString . "%' OR sr.email like '%" . $searchString . "%')", NULL, FALSE);
        }
//        print_r($col[$searchData['order'][0]['column']]);
        $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
        $this->db->limit($this->input->post('length'), $this->input->post('start'));
        $query = $this->db->get();
//var_dump($searchData['order'][0]['dir']);
        $data['draw'] = $this->input->post('draw');
//        $data['totalData'] = $queryTot->num_rows();
        $data['totalData'] = $totalRecordCount;
        $data['totalFilter'] = $totalRecordCount;
//        $surveyFormLevel = $this->config->item('assesmentSequence');
        $dataget = array();
        $cnt=$this->input->post('start');

        //$access_add=$this->CommonModel->checkPageActionWeb('facility/index','access_add',$this->session->userdata('RoleName'));
        $access_edit=$this->CommonModel->checkPageActionWeb('smg/index','access_edit',$this->session->userdata('RoleName'));
        $access_delete=$this->CommonModel->checkPageActionWeb('smg/index','access_delete',$this->session->userdata('RoleName'));
        //$access_view=$this->CommonModel->checkPageActionWeb('facility/index','access_view',$this->session->userdata('RoleName'));
        foreach ($query->result() as $key => $value) {
            $subdata = array();
            $subdata[]=++$cnt;
            $valId=encryptor($value->id);
//            $subdata[] = $surveyFormLevel[$value->Sequence];
//            $subdata[] = $value->StateName;
            $subdata[] = "<span id='name_span_".$valId."'>".$value->name."</span><span><input type='hidden' id='name_".$valId."' maxlength='20' name='name' value='".$value->name."'/></span>";
            $subdata[] = "<span id='department_span_".$valId."'>".$value->department."</span><span><input type='hidden' id='department_".$valId."' maxlength='20' name='name' value='".$value->department."'/></span>";
            $subdata[] = "<span id='designation_span_".$valId."'>".$value->designation."</span><span><input type='hidden' id='designation_".$valId."' maxlength='20' name='name' value='".$value->designation."'/></span>";
            $subdata[] = "<span id='designationSmg_span_".$valId."'>".$value->designationSmg."</span><span><input type='hidden' id='designationSmg_".$valId."' maxlength='20' name='name' value='".$value->designationSmg."'/></span>";
            $subdata[] = "<span id='email_span_".$valId."'>".$value->email."</span><span><input type='hidden' id='email_".$valId."' name='name' maxlength='20' value='".$value->email."'/></span>";
            $subdata[] = "<span id='mobile_span_".$valId."'>".$value->mobile."</span><span><input type='hidden' id='mobile_".$valId."' name='name' maxlength='13' minlength='10' class='nums' value='".$value->mobile."'/></span>";
            $actionLink='';
            if($access_edit){
                $actionLink.='<button data-href="" id="edit_'.$valId.'" onclick="editInline(\''.$valId.'\')" class="btn btn-primary btn-xs view_edit_width"><i class="glyphicon glyphicon-check"></i> Edit</button> '
                    . '<button data-href="" style="display:none" id="cancel_'.$valId.'" onclick="cancelInline(\''.$valId.'\')" class="btn btn-warning btn-xs "><i class="glyphicon glyphicon-remove"></i> Cancel</button>   '
                     . '<button data-href="" style="display:none" id="update_'.$valId.'" onclick="updateInline(\''.$valId.'\')" class="btn btn-success btn-xs "><i class="glyphicon glyphicon-ok"></i> Update</button>   ';
            }
            if($access_delete){
                $actionLink.='<button data-href="" data-val="' . $valId . '"  onclick="removeDataRow(\'' . $valId . '\')" class="btn btn-danger btn-xs deleteRow "><i class="glyphicon glyphicon-trash"></i> Remove</button>';
            }
            $subdata[] = $actionLink;
            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;

        return $data;
    }

    function updateRecord($table, $id, $data) {
        $condition = array('id' => $id);
        $this->db->where($condition);
        if($this->db->update($table, $data)=== FALSE){
            return false;
        } else {
            return true;            
        }
    }

}
