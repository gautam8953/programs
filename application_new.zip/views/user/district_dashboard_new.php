<?php ob_start();
$pertot=array('a'=>'0','b'=>'0','c'=>'0','d'=>'0');
 //echo "<pre>"; print_r($data); echo "</pre>"; die ?>
<div class="page-title">
  <div class="title_left">
    <h3>Dashboard</h3>
  </div>

  
</div>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


<div class="clearfix"></div>

<div class="main-content">

<div class="analytics-sparkle-area">
            <div class="container">


            	 <!-- -------------- New Dashboard Sec 1------------------------>
                    <div class="row">
    <div class="col-md-4 col-sm-12">
        <div class="analytics-sparkle-line analytics-sparkle-line-frt reso-mg-b-30">
            <div class="analytics-content top-board1">
                <div class="board-icons-1 ">
                    <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/total-hospital.png" alt="total hostpital"></div>
                </div>
                <div class="board-deatils">
                    <h5>Total LaQshya Facilities</h5>
                    <a href="<?php echo base_url(). "user/laqshyafacility "; ?>">
                        <?php $totalLaQshya=isset($data['totalLaQshya'])?$data['totalLaQshya']:'0'; ?>
                            <h2><span class="counter count"><?php echo $totalLaQshya; ?></span></h2> </a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-8 col-sm-12">
        <div class="row">
        <div class="list-dashboard-icon1">
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/medical-collage.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils">
                            <h5>Medical Colleges</h5>
                            <a href="<?php echo base_url(). "user/laqshyafacility/Medical_College "; ?>">
                                <?php $totalMedFacility=isset($data['totalMedFacility'])?$data['totalMedFacility']:'0'; $per=0; $per=round(($totalMedFacility/$totalLaQshya)*100,2); ?>
                                    <h2><span class="counter count"><?php echo $totalMedFacility; ?></span></h2> </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/district-hospital.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils">
                            <h5>District Hospitals</h5>
                            <a href="<?php echo base_url(). "user/laqshyafacility/District_Hospital "; ?>">
                                <?php $totalDisFacility=isset($data['totalDisFacility'])?$data['totalDisFacility']:'0'; $per=0; $per=round(($totalDisFacility/$totalLaQshya)*100,2); ?>
                                    <h2><span class="counter count"><?php echo $totalDisFacility ?></span></h2> </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/local-total-hospital.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils">
                            <h5>Sub-divisional Hospitals</h5>
                            <a href="<?php echo base_url(). "user/laqshyafacility/Sub-divisional_Hospital "; ?>">
                                <?php $totalSubDivFacility=isset($data['totalSubDivFacility'])?$data['totalSubDivFacility']:'0'; $per=0; $per=round(($totalSubDivFacility/$totalLaQshya)*100,2); ?>
                                    <h2><span class="counter count"><?php echo $totalSubDivFacility ?></span></h2> </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/CHCs-icon.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils">
                            <h5>CHCs</h5>
                            <a href="<?php echo base_url(). "user/laqshyafacility/CHC "; ?>">
                                <?php $totalCHC=isset($data['totalCHC'])?$data['totalCHC']:'0'; $per=0; $per=round(($totalCHC/$totalLaQshya)*100,2); ?>
                                    <h2><span class="counter count"><?php echo $totalCHC ?></span></h2> </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/medical-report-total.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils"> <a href="<?php echo base_url(). "user/laqshyafacility/FRU "; ?>"><h5>FRUs</h5> <?php $totalFRU=isset($data['totalFRU'])?$data['totalFRU']:'0'; $per=0; $per=round(($totalFRU/$totalLaQshya)*100,2); ?><h2><span class="counter count"><?php echo $totalFRU; ?></span></h2> </a></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/total-heart.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils"> <a href="<?php echo base_url(). "user/laqshyafacility/Others "; ?>"><h5>Others</h5> <?php $totalOtherFacility=isset($data['totalOtherFacility'])?$data['totalOtherFacility']:'0'; $per=0; $per=round(($totalOtherFacility/$totalLaQshya)*100,2); ?><h2><span class="counter count"><?php echo $totalOtherFacility ?></span></h2> </a></div>
                    </div>
                </div>
            </div>
        </div>
       </div>
     </div>
    </div>

                <!-- -------------- New Dashboard Sec 1 ended ------------------------>


			<div class="row">
				<div class="col-sm-12 col-xs-12 ">
				  <div class="x_panel bg-proce-bar-tag">
				    <div class="x_title">
				      <h2>LaQshya Program Indicators- Status </h2>
				      <ul class="nav navbar-right panel_toolbox">
				        <li>
				        	<a class="collapse-link">
				        		<i class="fa fa-chevron-up"></i>
				        	</a>
				        </li>
				      </ul>
			            <div class="pull-right">
                          <select class="" id="facility" onchange="monthly_indicator_fun();">
                            <option value='' >Select Facility</option>
                            <?php 
                            if(isset($data['facilities'])){
                              foreach ($data['facilities'] as $keyD => $valueD) {
                                echo "<option value='".$valueD['UserID']."' >".$valueD['FacilityName']."</option>";
                              }                                
                            }
                            ?>
                          </select>			            	
			              <select class="" id="monthly_indicator_date" onchange="monthly_indicator_fun();">
			                <?php 
			                $month=date('Y').'-'.date('m');
			                $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
			                foreach ($this->config->item('years') as $keyYear => $valueYear) {
			                  foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
			                    $monthVal=$valueYear."-".$keyMonth;
			                    if($monthVal==$monthDefault){
			                      $seletedText=" selected='selected' ";
			                    } else {
			                      $seletedText='';
			                    }
			                    echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
			                    if($monthVal==$month){
			                      break 2;
			                    }
			                  }
			                } 
			                ?>
			              </select>
			            </div>
				      <div class="clearfix"></div>
				    </div>
				    <div class="x_content">  
				    	<div id="monthly_indicator_loader" class="loader-s" style="display: none;"></div>
				    	<!-- district started -->
	        			<div id="otherIndicator" class="col-md-12">
	        				<div class="bar-list-process">
	        				<div class="row">
			        				<div class="col-md-6">

							           <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores</p></h3>
							        </div>
							        <div class="col-md-6">
							            <div class="progress-outer">
							                <div class="progress" id="val_a">
							                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
							                    <div class="progress-value"><span>0</span>%</div>
							                </div>
							            </div>
							        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_b">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_c">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage of deliveries are attended by a birth companion</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_d">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"> <i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage deliveries are conducted using safe birth checklist in Labour Room</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_e">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage of deliveries are conducted using Safe Surgery checklist in Maternity OT</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer" id="val_f">
						                <div class="progress">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage of deliveries for which Partograph is generated using real-time information in at least</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_g">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage breastfeeding within 1 hour</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_h">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Neonatal asphyxia rate in Inborn Babies</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_i">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Neonatal sepsis rate in-born babies</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_j">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Surgical Site infection Rate in Maternity OT</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_k">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Antenatal corticosteroid administration rate in case in preterm labour </p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_l">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Pre-eclampsia, eclampsia & PIH related mortality</p> </h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_m">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> APH/PPH related mortality </p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_n">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility Labour Room is reorganized as labour room standardization guidelines </p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_o">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility Labour room has staffing as per defined norms </p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_p">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage of Women, administered Oxytocin, immediately after birth </p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_q">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> OSCE Score </p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_r">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility conducts referral audit on Monthly basis </p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_s">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility conducts Maternal death, Neonatal death and near-miss on monthly basis</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_t">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility report zero stock outs in Labour Room & Maternity OT</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_u">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Still Birth Rate	</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_v">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage of beneficiaries who were either satisfied or highly satisfied	</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_w">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> functional Obs ICU/Hybrid ICU/HDU?	</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_x">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Microbiological Surveillance in OT & LR	</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_y">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Labour Room Quality Score Improvement from Baseline	</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_z">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>

					        <div class="row">
						        <div class="col-md-6">
						            <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Maternity OT Quality Score Improvement from Baseline	</p></h3>
						        </div>
						        <div class="col-md-6">
						            <div class="progress-outer">
						                <div class="progress" id="val_za">
						                    <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
						                    <div class="progress-value"><span>0</span>%</div>
						                </div>
						            </div>
						        </div>
					        </div>
					    </div>
		        		</div>
		        		<!-- district ended -->
                        <!-- facility started -->
                        <div id="facilityIndicator" class="col-md-12" style="display: none;">
                          <div id="faclity_monthly_indicator">
                                <table id="datatable" class="table table-striped table-bordered my-table-width" width="100%">
                                    <thead>
                                        <tr>
                                          <th>Indicator</th>
                                          <th>Current Status</th>
                                          <th>Target</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                            <td title="Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores">Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores</td>
                                            <td id="a"></td>
                                            <td>Baseline Assessment & Reporting done</td>
                                        </tr>
                                        <tr>
                                            <td title="Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots">Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots</td>
                                            <td id="b"></td>
                                            <td>At least one Meeting in month</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI">Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI</td>
                                            <td id="c"></td>
                                            <td>All staff Trained </td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage of deliveries are attended by a birth companion">Percentage of deliveries are attended by a birth companion</td>
                                            <td id="d"></td>
                                            <td>90%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage deliveries are conducted using safe birth checklist in Labour Room">Percentage deliveries are conducted using safe birth checklist in Labour Room </td>
                                            <td id="e"></td>
                                            <td>90%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage of deliveries are conducted using  Safe Surgery checklist in Maternity OT">Percentage of deliveries are conducted using  Safe Surgery checklist in Maternity OT</td>
                                            <td id="f"></td>
                                            <td>90%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage of deliveries for which Partograph is generated using real-time information in at least">Percentage of deliveries for which Partograph is generated using real-time information in at least </td>
                                            <td id="g"></td>
                                            <td>90%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage breastfeeding within 1 hour">Percentage breastfeeding within 1 hour </td>
                                            <td id="h"></td>
                                            <td>80%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Neonatal asphyxia rate in Inborn Babies"> Neonatal asphyxia rate in Inborn Babies </td>
                                            <td id="i"></td>
                                            <td>80%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Neonatal sepsis rate in-born babies"> Neonatal sepsis rate in-born babies </td>
                                            <td id="j"></td>
                                            <td>80%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Surgical Site infection Rate in Maternity OT"> Surgical Site infection Rate in Maternity OT </td>
                                            <td id="k"></td>
                                            <td>5%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Antenatal corticosteroid administration rate in case in preterm labour">Antenatal corticosteroid administration rate in case in preterm labour</td>
                                            <td id="l"></td>
                                            <td>80%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Pre-eclampsia, eclampsia & PIH related mortality">Pre-eclampsia, eclampsia & PIH related mortality</td>
                                            <td id="m"></td>
                                            <td>0</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="APH/PPH related mortality"> APH/PPH related mortality </td>
                                            <td id="n"></td>
                                            <td>0</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility Labour Room is reorganized as labour room standardization guidelines">Facility Labour Room is reorganized as labour room standardization guidelines</td>
                                            <td id="o"></td>
                                            <td>Reorganized</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility Labour room has staffing as per defined norms">Facility Labour room has staffing as per defined norms </td>
                                            <td id="p"></td>
                                            <td>Full Staffing </td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage of Women, administered Oxytocin, immediately after birth.">Percentage of Women, administered Oxytocin, immediately after birth.</td>
                                            <td id="q"></td>
                                            <td>100%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="OSCE Score">OSCE Score </td>
                                            <td id="r"></td>
                                            <td>80%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility conducts referral audit on Monthly basis">Facility conducts referral audit on Monthly basis</td>
                                            <td id="s"></td>
                                            <td>Monthly</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility conducts Maternal death, Neonatal death and near-miss on monthly basis">Facility conducts Maternal death, Neonatal death and near-miss on monthly basis</td>
                                            <td id="t"></td>
                                            <td>Monthly</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility report zero stock outs in Labour Room & Maternity OT">Facility report zero stock outs in Labour Room & Maternity OT</td>
                                            <td id="u"></td>
                                            <td>0</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Still Birth Rate">Still Birth Rate </td>
                                            <td id="v"></td>
                                            <td></td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage of beneficiaries  who were either satisfied or highly satisfied">Percentage of beneficiaries  who were either satisfied or highly satisfied</td>
                                            <td id="w"></td>
                                            <td></td>
                                        </tr>
                                        <tr>                                    
                                            <td title="functional Obs ICU/Hybrid ICU/HDU?">functional Obs ICU/Hybrid ICU/HDU?</td>
                                            <td id="x"></td>
                                            <td></td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Microbiological Surveillance in OT & LR">Microbiological Surveillance in OT & LR </td>
                                            <td id="y"></td>
                                            <td></td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Labour Room Quality Score Improvement from Baseline">Labour Room Quality Score Improvement from Baseline </td>
                                            <td id="z"></td>
                                            <td></td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Maternity OT Quality Score Improvement from Baseline">Maternity OT Quality Score Improvement from Baseline </td>
                                            <td id="za"></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                    </tbody>
                                </table>                    
                          </div>                            
                        </div>
                        <!-- facility ended -->

		    		</div>
		    		</div>
		    	</div>
	    	</div>
 




           
            <!-- <div class="row">
				<div class="col-sm-12 col-xs-12">
				  <div class="x_panel">
				    <div class="x_title">
				      <h2>LaQshya Program Indicators- Status </h2>
				      <ul class="nav navbar-right panel_toolbox">
				        <li>
				        	<a class="collapse-link">
				        		<i class="fa fa-chevron-up"></i>
				        	</a>
				        </li>
				      </ul>
			            <div class="pull-right">
			              <select class="dateChangeClass" id="monthly_indicator_date" data-changeFunction="monthly_indicator">
			                <?php 
			                /*$month=date('Y').'-'.date('m');
			                $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
			                foreach ($this->config->item('years') as $keyYear => $valueYear) {
			                  foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
			                    $monthVal=$valueYear."-".$keyMonth;
			                    if($monthVal==$monthDefault){
			                      $seletedText=" selected='selected' ";
			                    } else {
			                      $seletedText='';
			                    }
			                    echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
			                    if($monthVal==$month){
			                      break 2;
			                    }
			                  }
			                }*/ 
			                ?>
			              </select>
			            </div>
				      <div class="clearfix"></div>
				    </div>
				    <div class="x_content">  
	        			<div class="col-md-12">
	        				<div id="monthly_indicator" style="width: 100%; height: 100%;"></div>
		        		</div>
		    		</div>
		    		</div>
		    	</div>
	    	</div> -->  


		  	<!-- charts box started -->
            <div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
				  <div class="x_panel">
				    <div class="x_title">
				      <h2>LaQshya Status</h2>
				        <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			        <li class="new-btn-status-certificate"><a href="<?php echo base_url() ?>reports/certification"><img src="<?php echo base_url() ?>/assets/images/report-icon-new.png" alt="Reports">View Certification Status</a></li>
			      </ul>
				    </div>
				    <div class="x_content servi-list-1">
				    	<div class="row" >
				    			<div class="col-md-4">
				                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
				 	
				                            <div class="analytics-content" >
				                            	  <?php 
													$dataGet=!empty($data['box']['stateOr']['stateOrFac'])?$data['box']['stateOr']['stateOrFac']:'0'; 
													$total=!empty($data['box']['stateOr']['Facilities'])?$data['box']['stateOr']['Facilities']:'0';
													$per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
													?>

				                            	 <div class="half-chart-line">
				                            	 	<div id="pacman" class="chart-srou-1" style="width:150px; height:150px;">
				                            	 		
				                            	 	</div>
				                            	 	<span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
				                            	 </div>


				                            	<div class="chart-new-link1"> 
					                            	 
						                                <h5>State Orientation</h5>
						                               
					                               
					                            </div>




				                               
								 

				                                <script type="text/javascript">
											     	 google.charts.load("current", {packages:["corechart"]});
											      google.charts.setOnLoadCallback(drawChart);
											      function drawChart() {
											        var hello = <?php echo $dataGet; ?>;
											        var hello1 = <?php echo $total; ?>;
											        
											        var data = google.visualization.arrayToDataTable([
											          ['State Orientation', 'Percentage'],
											          ['Completed', hello],
											          ['Total', hello1],
											          
											        ]);

											        var options = {
											          pieHole: 0.7,
											          tooltip: {text: 'value'},
											          legend: 'none',
											          
											          pieSliceText: 'none',
											          pieStartAngle: 270,
											          slices: {
											            0: { color: '<?php echo $classCode; ?>' },
											            1: { color: '#d3d3d3'},
											            
											          },
											          backgroundColor: { fill:'transparent' },

											          
		 
											          chartArea: {
													    left: 5,
													    top: 10,
													    right:0,
													    
	        											width: 150,  height:150,
	        											backgroundColor: {
														        stroke: '#fff',
														        strokeWidth: 1
														    }
														}
											        };

											        var chart = new google.visualization.PieChart(document.getElementById('pacman'));
											        chart.draw(data, options);
											      }
											    </script>
				                            </div>
				                        </div>
				                    </div>







				                    <div class="col-md-4">
				                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
				 	
				                            <div class="analytics-content" >
				                            	  <?php 
													$dataGet=!empty($data['box']['StateApLR']['StateappliedLR'])?$data['box']['StateApLR']['StateappliedLR']:'0';
													$total=!empty($data['box']['StateApLR']['Facilities'])?$data['box']['StateApLR']['Facilities']:'0';
													$per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
													?>

				                            	 <div class="half-chart-line">
				                            	 	<div id="pacman1" class="chart-srou-1" style="width:150px; height:150px;">
				                            	 		
				                            	 	</div>
				                            	 	<span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
				                            	 </div>


				                            	<div class="chart-new-link1"> 
					                            	 
						                                <h5>Facilities Applied For State Certification For LR</h5>
						                               
					                                
					                            </div>




				                               
								 

				                                <script type="text/javascript">
											     	 google.charts.load("current", {packages:["corechart"]});
											      google.charts.setOnLoadCallback(drawChart);
											      function drawChart() {
											        var hello = <?php echo $dataGet; ?>;
											        var hello1 = <?php echo $total; ?>;
											        
											        var data = google.visualization.arrayToDataTable([
											          ['Facilities Applied For State Certification For LR', 'Percentage'],
											          ['Applied', hello],
											          ['Total', hello1],
											          
											        ]);

											        var options = {
											          pieHole: 0.7,
											          tooltip: {text: 'value'},
											          legend: 'none',
											          
											          pieSliceText: 'none',
											          pieStartAngle: 270,
											          slices: {
											            0: { color: '<?php echo $classCode; ?>' },
											            1: { color: '#d3d3d3'},
											            
											          },
											          backgroundColor: { fill:'transparent' },

											          
		 
											          chartArea: {
													    left: 5,
													    top: 10,
													    right:0,
													    
	        											width: 150,  height:150,
	        											backgroundColor: {
														        stroke: '#fff',
														        strokeWidth: 1
														    }
														}
											        };

											        var chart = new google.visualization.PieChart(document.getElementById('pacman1'));
											        chart.draw(data, options);
											      }
											    </script>
				                            </div>
				                        </div>
				                    </div>



				                    <div class="col-md-4">
				                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
				 	
				                            <div class="analytics-content" >
				                            	  <?php 
														$dataGet=!empty($data['box']['StateApOT']['StateappliedOT'])?$data['box']['StateApOT']['StateappliedOT']:'0';
														$total=!empty($data['box']['StateApOT']['Facilities'])?$data['box']['StateApOT']['Facilities']:'0';
														$per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
														?>

				                            	 <div class="half-chart-line">
				                            	 	<div id="pacman2" class="chart-srou-1" style="width:150px; height:150px;">
				                            	 		
				                            	 	</div>
				                            	 	<span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
				                            	 </div>


				                            	<div class="chart-new-link1"> 
					                            	 
						                                <h5>Facilities Applied For State Certification For OT</h5>
						                               
					                                 
					                            </div>




				                               
								 

				                                <script type="text/javascript">
											     	 google.charts.load("current", {packages:["corechart"]});
											      google.charts.setOnLoadCallback(drawChart);
											      function drawChart() {
											        var hello = <?php echo $dataGet; ?>;
											        var hello1 = <?php echo $total; ?>;
											        
											        var data = google.visualization.arrayToDataTable([
											          ['Facilities Applied For State Certification For OT', 'Percentage'],
											          ['Applied', hello],
											          ['Total ', hello1],
											          
											        ]);

											        var options = {
											          pieHole: 0.7,
											          tooltip: {text: 'value'},
											          legend: 'none',
											          
											          pieSliceText: 'none',
											          pieStartAngle: 270,
											          slices: {
											            0: { color: '<?php echo $classCode; ?>' },
											            1: { color: '#d3d3d3'},
											            
											          },
											          backgroundColor: { fill:'transparent' },

											          
		 
											          chartArea: {
													    left: 5,
													    top: 10,
													    right:0,
													    
	        											width: 150,  height:150,
	        											backgroundColor: {
														        stroke: '#fff',
														        strokeWidth: 1
														    }
														}
											        };

											        var chart = new google.visualization.PieChart(document.getElementById('pacman2'));
											        chart.draw(data, options);
											      }
											    </script>
				                            </div>
				                        </div>
				                    </div>

                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['StateIpLR']['StateInprocessLR'])?$data['box']['StateIpLR']['StateInprocessLR']:'0';
                                                    $total=!empty($data['box']['StateIpLR']['Facilities'])?$data['box']['StateIpLR']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);

                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman1-StateInprocessLR" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities In-process For State Certification For LR</h5>
                                                       
                                                    
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities In-process For State Certification For LR', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman1-StateInprocessLR'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                        $dataGet=!empty($data['box']['StateIpOT']['StateInprocessOT'])?$data['box']['StateIpOT']['StateInprocessOT']:'0';
                                                        $total=!empty($data['box']['StateIpOT']['Facilities'])?$data['box']['StateIpOT']['Facilities']:'0';
                                                        $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                        ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman2-StateInprocessOT" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities In-process For State Certification For OT</h5>
                                                       
                                                     
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities In-process For State Certification For OT', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman2-StateInprocessOT'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>


				                    <div class="col-md-4">
				                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
				 	
				                            <div class="analytics-content" >
				                            	  <?php 
														$dataGet=!empty($data['box']['StatecLR']['StatecertifiedLR'])?$data['box']['StatecLR']['StatecertifiedLR']:'0';
														$total=!empty($data['box']['StatecLR']['Facilities'])?$data['box']['StatecLR']['Facilities']:'0';
														$per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
														?>

				                            	 <div class="half-chart-line">
				                            	 	<div id="pacman3" class="chart-srou-1" style="width:150px; height:150px;">
				                            	 		
				                            	 	</div>
				                            	 	<span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
				                            	 </div>


				                            	<div class="chart-new-link1"> 
					                            	  
						                                <h5>Facilities Received State Certification For LR </h5>
						                               
					                                
					                            </div>




				                               
								 

				                                <script type="text/javascript">
											     	 google.charts.load("current", {packages:["corechart"]});
											      google.charts.setOnLoadCallback(drawChart);
											      function drawChart() {
											        var hello = <?php echo $dataGet; ?>;
											        var hello1 = <?php echo $total; ?>;
											        
											        var data = google.visualization.arrayToDataTable([
											          ['Facilities Received State Certification For LR', 'Percentage'],
											          ['Received', hello],
											          ['Total ', hello1],
											          
											        ]);

											        var options = {
											          pieHole: 0.7,
											          tooltip: {text: 'value'},
											          legend: 'none',
											          
											          pieSliceText: 'none',
											          pieStartAngle: 270,
											          slices: {
											            0: { color: '<?php echo $classCode; ?>' },
											            1: { color: '#d3d3d3'},
											            
											          },
											          backgroundColor: { fill:'transparent' },

											          
		 
											          chartArea: {
													    left: 5,
													    top: 10,
													    right:0,
													    
	        											width: 150,  height:150,
	        											backgroundColor: {
														        stroke: '#fff',
														        strokeWidth: 1
														    }
														}
											        };

											        var chart = new google.visualization.PieChart(document.getElementById('pacman3'));
											        chart.draw(data, options);
											      }
											    </script>
				                            </div>
				                        </div>
				                    </div>




				                    <div class="col-md-4">
				                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
				 	
				                            <div class="analytics-content" >
				                            	  <?php 
													$dataGet=!empty($data['box']['StatecOT']['StatecertifiedOT'])?$data['box']['StatecOT']['StatecertifiedOT']:'0';
													$total=!empty($data['box']['StatecOT']['Facilities'])?$data['box']['StatecOT']['Facilities']:'0';
													$per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
													?>

				                            	 <div class="half-chart-line">
				                            	 	<div id="pacman4" class="chart-srou-1" style="width:150px; height:150px;">
				                            	 		
				                            	 	</div>
				                            	 	<span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
				                            	 </div>


				                            	<div class="chart-new-link1"> 
					                            	 
						                                <h5>Facilities Received State Certification For OT </h5>
						                               
					                                 
					                            </div>




				                               
								 

				                                <script type="text/javascript">
											     	 google.charts.load("current", {packages:["corechart"]});
											      google.charts.setOnLoadCallback(drawChart);
											      function drawChart() {
											        var hello = <?php  echo $dataGet; ?>;
											        var hello1 = <?php echo $total; ?>;
											        
											        var data = google.visualization.arrayToDataTable([
											          ['Facilities Received State Certification For OT', 'Percentage'],
											          ['Received', hello],
											          ['Total ', hello1],
											          
											        ]);

											        var options = {
											          pieHole: 0.7,
											          tooltip: {text: 'value'},
											          legend: 'none',
											          
											          pieSliceText: 'none',
											          pieStartAngle: 270,
											          slices: {
											            0: { color: '<?php echo $classCode; ?>' },
											            1: { color: '#d3d3d3'},
											            
											          },
											          backgroundColor: { fill:'transparent' },

											          
		 
											          chartArea: {
													    left: 5,
													    top: 10,
													    right:0,
													    
	        											width: 150,  height:150,
	        											backgroundColor: {
														        stroke: '#fff',
														        strokeWidth: 1
														    }
														}
											        };

											        var chart = new google.visualization.PieChart(document.getElementById('pacman4'));
											        chart.draw(data, options);
											      }
											    </script>
				                            </div>
				                        </div>
				                    </div>



				                    <div class="col-md-4">
				                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
				 	
				                            <div class="analytics-content" >
				                            	  <?php 
													$dataGet=!empty($data['box']['ApLR']['AppliedLR'])?$data['box']['ApLR']['AppliedLR']:'0';
													$total=!empty($data['box']['ApLR']['Facilities'])?$data['box']['ApLR']['Facilities']:'0';
													$per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
													?>

				                            	 <div class="half-chart-line">
				                            	 	<div id="pacman5" class="chart-srou-1" style="width:150px; height:150px;">
				                            	 		
				                            	 	</div>
				                            	 	<span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
				                            	 </div>


				                            	<div class="chart-new-link1"> 
					                            	 
						                                <h5>Facilities Applied For National Certification For LR </h5>
						                               
					                                 
					                            </div>




				                               
								 

				                                <script type="text/javascript">
											     	 google.charts.load("current", {packages:["corechart"]});
											      google.charts.setOnLoadCallback(drawChart);
											      function drawChart() {
											        var hello = <?php  echo $dataGet; ?>;
											        var hello1 = <?php echo $total; ?>;
											        
											        var data = google.visualization.arrayToDataTable([
											          ['Facilities Applied For National Certification For LR', 'Percentage'],
											          ['Applied', hello],
											          ['Total ', hello1],
											          
											        ]);

											        var options = {
											          pieHole: 0.7,
											          tooltip: {text: 'value'},
											          legend: 'none',
											          
											          pieSliceText: 'none',
											          pieStartAngle: 270,
											          slices: {
											            0: { color: '<?php echo $classCode; ?>' },
											            1: { color: '#d3d3d3'},
											            
											          },
											          backgroundColor: { fill:'transparent' },

											          
		 
											          chartArea: {
													    left: 5,
													    top: 10,
													    right:0,
													    
	        											width: 150,  height:150,
	        											backgroundColor: {
														        stroke: '#fff',
														        strokeWidth: 1
														    }
														}
											        };

											        var chart = new google.visualization.PieChart(document.getElementById('pacman5'));
											        chart.draw(data, options);
											      }
											    </script>
				                            </div>
				                        </div>
				                    </div>




				                    <div class="col-md-4">
				                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
				 	
				                            <div class="analytics-content" >
				                            	  <?php 
													$dataGet=!empty($data['box']['ApOT']['AppliedOT'])?$data['box']['ApOT']['AppliedOT']:'0';
													$total=!empty($data['box']['ApOT']['Facilities'])?$data['box']['ApOT']['Facilities']:'0';
													$per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
													?>

				                            	 <div class="half-chart-line">
				                            	 	<div id="pacman6" class="chart-srou-1" style="width:150px; height:150px;">
				                            	 		
				                            	 	</div>
				                            	 	<span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
				                            	 </div>


				                            	<div class="chart-new-link1"> 
					                            	 
						                                <h5>Facilities Applied For National Certification For OT </h5>
						                               
					                                 
					                            </div>

 
								 

				                                <script type="text/javascript">
											     	 google.charts.load("current", {packages:["corechart"]});
											      google.charts.setOnLoadCallback(drawChart);
											      function drawChart() {
											        var hello = <?php  echo $dataGet; ?>;
											        var hello1 = <?php echo $total; ?>;
											        
											        var data = google.visualization.arrayToDataTable([
											          ['Facilities Applied For National Certification For OT', 'Percentage'],
											          ['Applied', hello],
											          ['Total ', hello1],
											          
											        ]);

											        var options = {
											          pieHole: 0.7,
											          tooltip: {text: 'value'},
											          legend: 'none',
											          
											          pieSliceText: 'none',
											          pieStartAngle: 270,
											          slices: {
											            0: { color: '<?php echo $classCode; ?>' },
											            1: { color: '#d3d3d3'},
											            
											          },
											          backgroundColor: { fill:'transparent' },

											          
		 
											          chartArea: {
													    left: 5,
													    top: 10,
													    right:0,
													    
	        											width: 150,  height:150,
	        											backgroundColor: {
														        stroke: '#fff',
														        strokeWidth: 1
														    }
														}
											        };

											        var chart = new google.visualization.PieChart(document.getElementById('pacman6'));
											        chart.draw(data, options);
											      }
											    </script>
				                            </div>
				                        </div>
				                    </div>

                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['IpLR']['InprocessLR'])?$data['box']['IpLR']['InprocessLR']:'0';
                                                    $total=!empty($data['box']['IpLR']['Facilities'])?$data['box']['IpLR']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman5-InprocessLR" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities In-process For National Certification For LR </h5>
                                                       
                                                     
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php  echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities In-process For National Certification For LR', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman5-InprocessLR'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>




                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['IpOT']['InprocessOT'])?$data['box']['IpOT']['InprocessOT']:'0';
                                                    $total=!empty($data['box']['IpOT']['Facilities'])?$data['box']['IpOT']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman6-InprocessOT" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities In-process For National Certification For OT </h5>
                                                       
                                                     
                                                </div>

 
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php  echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities In-process For National Certification For OT', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman6-InprocessOT'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>


				                    <div class="col-md-4">
				                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
				 	
				                            <div class="analytics-content" >
				                            	  <?php 
													$dataGet=!empty($data['box']['cLR']['CertifiedLR'])?$data['box']['cLR']['CertifiedLR']:'0';
													$total=!empty($data['box']['cLR']['Facilities'])?$data['box']['cLR']['Facilities']:'0';
													$per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
													?>

				                            	 <div class="half-chart-line">
				                            	 	<div id="pacman7" class="chart-srou-1" style="width:150px; height:150px;">
				                            	 		
				                            	 	</div>
				                            	 	<span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
				                            	 </div>


				                            	<div class="chart-new-link1"> 
					                            	 
						                                <h5>Facilities Received National Certification For LR </h5>
						                               
					                                 
					                            </div>

 
								 

				                                <script type="text/javascript">
											     	 google.charts.load("current", {packages:["corechart"]});
											      google.charts.setOnLoadCallback(drawChart);
											      function drawChart() {
											        var hello = <?php  echo $dataGet; ?>;
											        var hello1 = <?php echo $total; ?>;
											        
											        var data = google.visualization.arrayToDataTable([
											          ['Facilities Received National Certification For LR', 'Percentage'],
											          ['Received', hello],
											          ['Total ', hello1],
											          
											        ]);

											        var options = {
											          pieHole: 0.7,
											          tooltip: {text: 'value'},
											          legend: 'none',
											          
											          pieSliceText: 'none',
											          pieStartAngle: 270,
											          slices: {
											            0: { color: '<?php echo $classCode; ?>' },
											            1: { color: '#d3d3d3'},
											            
											          },
											          backgroundColor: { fill:'transparent' },

											          
		 
											          chartArea: {
													    left: 5,
													    top: 10,
													    right:0,
													    
	        											width: 150,  height:150,
	        											backgroundColor: {
														        stroke: '#fff',
														        strokeWidth: 1
														    }
														}
											        };

											        var chart = new google.visualization.PieChart(document.getElementById('pacman7'));
											        chart.draw(data, options);
											      }
											    </script>
				                            </div>
				                        </div>
				                    </div>



				                    <div class="col-md-4">
				                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
				 	
				                            <div class="analytics-content" >
				                            	  <?php 
													$dataGet=!empty($data['box']['cOT']['CertifiedOT'])?$data['box']['cOT']['CertifiedOT']:'0';
													$total=!empty($data['box']['cOT']['Facilities'])?$data['box']['cOT']['Facilities']:'0';
													$per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
													?>

				                            	 <div class="half-chart-line">
				                            	 	<div id="pacman8" class="chart-srou-1" style="width:150px; height:150px;">
				                            	 		
				                            	 	</div>
				                            	 	<span class=" par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
				                            	 </div>


				                            	<div class="chart-new-link1"> 
					                            	 
						                                <h5>Facilities Received National Certification For OT </h5>
						                               
					                                 
					                            </div>

 
								 

				                                <script type="text/javascript">
											     	 google.charts.load("current", {packages:["corechart"]});
											      google.charts.setOnLoadCallback(drawChart);
											      function drawChart() {
											        var hello = <?php  echo $dataGet; ?>;
											        var hello1 = <?php echo $total; ?>;
											        
											        var data = google.visualization.arrayToDataTable([
											          ['Facilities Received National Certification For OT', 'Percentage'],
											          ['Received', hello],
											          ['Total ', hello1],
											          
											        ]);

											        var options = {
											          pieHole: 0.7,
											          tooltip: {text: 'value'},
											          legend: 'none',
											          
											          pieSliceText: 'none',
											          pieStartAngle: 270,
											          slices: {
											            0: { color: '<?php echo $classCode; ?>' },
											            1: { color: '#d3d3d3'},
											            
											          },
											          backgroundColor: { fill:'transparent' },

											          
		 
											          chartArea: {
													    left: 5,
													    top: 10,
													    right:0,
													    
	        											width: 150,  height:150,
	        											backgroundColor: {
														        stroke: '#fff',
														        strokeWidth: 1
														    }
														}
											        };

											        var chart = new google.visualization.PieChart(document.getElementById('pacman8'));
											        chart.draw(data, options);
											      }
											    </script>
				                            </div>
				                        </div>
				                    </div>



 

				                    </div>




				    </div>
				  </div>
				</div>
			</div>



		  	<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12 text-center">
					<a href="#" id="view-more-btn" class="view-more-btn " title="View All Dashboard Sections"><i class="fa fa-arrow-down hvr-bob" aria-hidden="true"></i> View more</a> 
				</div>
			</div>

<div class="hidden-dash-bard">
		  	<div class="row">
		  		<!-- charts box started -->
			<div class="col-md-6 col-sm-12 col-xs-12">
			  <div class="x_panel short-panel1">
			    <div class="x_title">
			      <h2>Maternal Death Cause</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			      <div class="pull-right">
					<select class="dateChangeClass" id="piechart_MatDeath_date" data-changeFunction="piechart_MatDeath" data-msg="piechart_MatDeath_msg" data-loader="piechart_MatDeath_loader">
						<?php 
						$month=date('Y').'-'.date('m');
						$monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
						foreach ($this->config->item('years') as $keyYear => $valueYear) {
							foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
								$monthVal=$valueYear."-".$keyMonth;
								if($monthVal==$monthDefault){
									$seletedText=" selected='selected' ";
								} else {
									$seletedText='';
								}
								echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
								if($monthVal==$month){
									break 2;
								}
							}
						} 
						?>
					</select>			      	
			      </div>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">  
        			<div class="col-md-12">
        				<div id="piechart_MatDeath" ></div>
        				<div id="piechart_MatDeath_loader" class="loader-s" style="display: none;"></div>
        				<div id="piechart_MatDeath_msg" class="msg-center" style="display: none;"></div>
	        		</div>
	    		</div>
	    		</div>
	    	</div>
			<div class="col-md-6 col-sm-12 col-xs-12">
			  	<div class="x_panel short-panel1">
				    <div class="x_title">
				      <h2>Neonatal Death Cause</h2>
				      <ul class="nav navbar-right panel_toolbox">
				        <li>
				        	<a class="collapse-link">
				        		<i class="fa fa-chevron-up"></i>
				        	</a>
				        </li>
				      </ul>
				      <div class="pull-right">
						<select class="dateChangeClass" id="piechart_NeonDeath_date" data-changeFunction="piechart_NeonDeath"  data-msg="piechart_NeonDeath_msg" data-loader="piechart_NeonDeath_loader">
							<?php 
							$month=date('Y').'-'.date('m');
							$monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
							foreach ($this->config->item('years') as $keyYear => $valueYear) {
								foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
									$monthVal=$valueYear."-".$keyMonth;
									if($monthVal==$monthDefault){
										$seletedText=" selected='selected' ";
									} else {
										$seletedText='';
									}
									echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
									if($monthVal==$month){
										break 2;
									}
								}
							} 
							?>
						</select>			      	
				      </div>
				      <div class="clearfix"></div>
				    </div>
				    <div class="x_content">  
	        			<div class="col-md-12">
	        				<div id="piechart_NeonDeath"></div>
	                        <div id="piechart_NeonDeath_loader" class="loader-s" style="display: none;"></div>
	                        <div id="piechart_NeonDeath_msg" class="msg-center" style="display: none;"></div>
		        		</div>
		    		</div>
	    		</div>
	    	</div>
			<div class="col-md-6 col-sm-12 col-xs-12">
			  <div class="x_panel short-panel1">
			    <div class="x_title">
			      <h2>Still Birth</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			      <div class="pull-right">
					<select class="dateChangeClass" id="piechart_StillBirth_date" data-changeFunction="piechart_StillBirth" data-msg="piechart_StillBirth_msg" data-loader="piechart_StillBirth_loader">
						<?php 
						$month=date('Y').'-'.date('m');
						$monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
						foreach ($this->config->item('years') as $keyYear => $valueYear) {
							foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
								$monthVal=$valueYear."-".$keyMonth;
								if($monthVal==$monthDefault){
									$seletedText=" selected='selected' ";
								} else {
									$seletedText='';
								}
								echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
								if($monthVal==$month){
									break 2;
								}
							}
						} 
						?>
					</select>			      	
			      </div>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">  
        			<div class="col-md-12">
        				<div id="piechart_StillBirth" ></div>
                        <div id="piechart_StillBirth_loader" class="loader-s" style="display: none;"></div>
                        <div id="piechart_StillBirth_msg" class="msg-center" style="display: none;"></div>
	        		</div>
	    		</div>
	    	</div>
	    	</div>
			<div class="col-md-6 col-sm-12 col-xs-12">
			  <div class="x_panel short-panel1">
			    <div class="x_title">
			      <h2>Normal VS C-Section Deliveries</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			      <div class="pull-right">
					<select class="dateChangeClass" id="piechart_Deliveries_date" data-changeFunction="piechart_Deliveries" data-msg="piechart_Deliveries_msg" data-loader="piechart_Deliveries_loader">
						<?php 
						$month=date('Y').'-'.date('m');
						$monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
						foreach ($this->config->item('years') as $keyYear => $valueYear) {
							foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
								$monthVal=$valueYear."-".$keyMonth;
								if($monthVal==$monthDefault){
									$seletedText=" selected='selected' ";
								} else {
									$seletedText='';
								}
								echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
								if($monthVal==$month){
									break 2;
								}
							}
						} 
						?>
					</select>			      	
			      </div>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">  
        			<div class="col-md-12">
        				<div id="piechart_Deliveries"></div>
                        <div id="piechart_Deliveries_loader" class="loader-s" style="display: none;"></div>
                        <div id="piechart_Deliveries_msg" class="msg-center" style="display: none;"></div>
	        		</div>
	    		</div>
	    	</div>
	    	</div>
			
			
			<!-- charts box ended -->
		  	</div>






        </div><!-- conatiener -->
 </div>
  </div>
 
<span id="jstip"></span>
  
<?php 
$out2 = ob_get_contents();
ob_end_clean();
echo $out2;
?>

	<script type="text/javascript">

	function piechart_MatDeath_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
	    var params = {};
	    params['device'] = 'web';
	    params['csrf_token']=$.cookie("csrf_cookie");
	    params['searchType'] = 'piechart_MatDeath';
	    params['searchDate'] = searchDate;    
      	var piechart_MatDeath_text=[];
      	$.ajax({
	        url: pageMainUrl + 'ApiUser/getMinistryChart',
	        data: params,
	        type: 'POST',
	        dataType : "json",
	        async: false,
	        success: function (result) {
	        	$('#piechart_MatDeath_loader').hide();
	        	$('#piechart_MatDeath_msg').hide();
	        	if(parseInt(result.length)>2){
	        		$('#piechart_MatDeath').show();
	        		piechart_MatDeath_text = result;
			        var data = google.visualization.arrayToDataTable(piechart_MatDeath_text);
			        var options = {
			          title: '',          
			          //'chartArea': {height: "100%",width: "100%" },
			          is3D: true,
			          'width':500,
                     'height':300,
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
			        };
			        var chart = new google.visualization.PieChart(document.getElementById('piechart_MatDeath'));
			        chart.draw(data, options);
	        	} else{
	        		$('#piechart_MatDeath').hide();
	        		$('#piechart_MatDeath_msg').show().html('No Data Found');
	        	}
	        	
	        }
	    });

      }		
	}
	function piechart_NeonDeath_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
	    var params = {};
	    params['device'] = 'web';
	    params['csrf_token']=$.cookie("csrf_cookie");
	    params['searchType'] = 'piechart_NeonDeath';
	    params['searchDate'] = searchDate;    
      	var piechart_NeonDeath_text=[];
      	$.ajax({
	        url: pageMainUrl + 'ApiUser/getMinistryChart',
	        data: params,
	        type: 'POST',
	        dataType : "json",
	        async: false,
	        success: function (result) {
	        	$('#piechart_NeonDeath_loader').hide();
	        	$('#piechart_NeonDeath_msg').hide();
                if(parseInt(result.length)>2){
                    $('#piechart_NeonDeath').show();
                    piechart_NeonDeath_text = result;
			        var data = google.visualization.arrayToDataTable(piechart_NeonDeath_text);
			        var options = {
			          title: '',          
			          //'chartArea': {height: "100%",width: "100%" },
			          is3D: true,
			          'width':500,
                     'height':300,
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
			        };
			        var chart = new google.visualization.PieChart(document.getElementById('piechart_NeonDeath'));
			        chart.draw(data, options);
                } else{
                    $('#piechart_NeonDeath').hide();
                    $('#piechart_NeonDeath_msg').show().html('No Data Found');
                }
	        }
	    });

      }
	}
	function piechart_StillBirth_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
	    var params = {};
	    params['device'] = 'web';
	    params['csrf_token']=$.cookie("csrf_cookie");
	    params['searchType'] = 'piechart_StillBirth';
	    params['searchDate'] = searchDate;    
      	var piechart_StillBirth_text=[];
      	$.ajax({
	        url: pageMainUrl + 'ApiUser/getMinistryChart',
	        data: params,
	        type: 'POST',
	        dataType : "json",
	        async: false,
	        success: function (result) {
                $('#piechart_StillBirth_loader').hide();
                $('#piechart_StillBirth_msg').hide();
                if(parseInt(result.length)>2){
                $('#piechart_StillBirth').show();
                piechart_StillBirth_text = result;
		        var data = google.visualization.arrayToDataTable(piechart_StillBirth_text);
		        var options = {
			          title: '',          
			          //'chartArea': {height: "100%",width: "100%" },
			          is3D: true,
			          'width':500,
                     'height':300,
                     colors: ['#36c', '#dc3912'],
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
			        };
		        var chart = new google.visualization.PieChart(document.getElementById('piechart_StillBirth'));
		        chart.draw(data, options);
                } else{
                    $('#piechart_StillBirth').hide();
                    $('#piechart_StillBirth_msg').show().html('No Data Found');
                }
	        }
	    });

      }
	}
	function piechart_Deliveries_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
	    var params = {};
	    params['device'] = 'web';
	    params['csrf_token']=$.cookie("csrf_cookie");
	    params['searchType'] = 'piechart_Deliveries';
	    params['searchDate'] = searchDate;    
      	var piechart_Deliveries_text=[];
      	$.ajax({
	        url: pageMainUrl + 'ApiUser/getMinistryChart',
	        data: params,
	        type: 'POST',
	        dataType : "json",
	        async: false,
	        success: function (result) {
                $('#piechart_Deliveries_loader').hide();
                $('#piechart_Deliveries_msg').hide();
                if(parseInt(result.length)>2){
                    $('#piechart_Deliveries').show();
                    piechart_Deliveries_text = result;
			        var data = google.visualization.arrayToDataTable(piechart_Deliveries_text);
			        var options = {
			          title: '',          
			          //'chartArea': {height: "100%",width: "100%" },
			          is3D: true,
			          'width':500,
                     'height':300,
                     colors: ['#36c', '#ff9900','#dc3912'],
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
			        };
			        var chart = new google.visualization.PieChart(document.getElementById('piechart_Deliveries'));
			        chart.draw(data, options);
                } else{
                    $('#piechart_Deliveries').hide();
                    $('#piechart_Deliveries_msg').show().html('No Data Found');
                }
	        }
	    });
      }
	}
	function monthly_indicator_fun(){
		$('#monthly_indicator_loader').css({'display':'block'});
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchDate'] = $('#monthly_indicator_date').val();
        if($('#facility').val()==''){
            // for ministry,state and district
            params['searchType'] = 'monthly_indicator';
        } else {
            // for facility
            params['searchType'] = 'faclity_monthly_indicator';
            params['facility'] = $('#facility').val();
        }
          var monthly_indicator_text=[];
          $.ajax({
            url: pageMainUrl + 'ApiUser/getMinistryChart',
            data: params,
            type: 'POST',
            dataType : "json",
            async: false,
            success: function (result) {
                $('#monthly_indicator_loader').css({'display':'none'});
                if($('#facility').val()==''){
                    $('#facilityIndicator').hide();
                    $('#otherIndicator').show();
	            	$(result.data).each(function(keyData,valData){
						$('#'+valData.id+' .progress-bar').attr('style', 'width:'+valData.val+'%');
						$('#'+valData.id+' .progress-value span').html(valData.val);
	                    $('#'+valData.id+' .progress-bar').removeClass('success inprocess faild');
	                    $('#'+valData.id+' .progress-bar').addClass(valData.class);
	            	});
				    $('.progress-value > span').each(function(){
				        $(this).prop('Counter',0).animate({
				            Counter: $(this).text()
				        },{
				            duration: 1500,
				            easing: 'swing',
				            step: function (now){
				                $(this).text(Math.ceil(now));
				            }
				        });
				    });
				} else {
                    $('#facilityIndicator').show();
                    $('#otherIndicator').hide();
                  $('#a').html(result.a);
                  $('#b').html(result.b);
                  $('#c').html(result.c);
                  $('#d').html(result.d);
                  $('#e').html(result.e);
                  $('#f').html(result.f);
                  $('#g').html(result.g);
                  $('#h').html(result.h);
                  $('#i').html(result.i);
                  $('#j').html(result.j);
                  $('#k').html(result.k);
                  $('#l').html(result.l);
                  $('#m').html(result.m);
                  $('#n').html(result.n);
                  $('#o').html(result.o);
                  $('#p').html(result.p);
                  $('#q').html(result.q);
                  $('#r').html(result.r);
                  $('#s').html(result.s);
                  $('#t').html(result.t);
                  $('#u').html(result.u);
                  $('#v').html(result.v);
                  $('#w').html(result.w);
                  $('#x').html(result.x);
                  $('#y').html(result.y);
                  $('#z').html(result.z);
                  $('#za').html(result.za);					
				}
            }
        });
        //$('#monthly_indicator').show();
      
  }
	function monthly_indicator_fun1(searchDate=''){
	  google.charts.load("current", {packages:["corechart"]});
	  google.charts.setOnLoadCallback(drawChart);
	  function drawChart() {
	        var params = {};
	        params['device'] = 'web';
	        params['csrf_token']=$.cookie("csrf_cookie");
	        params['searchType'] = 'monthly_indicator';
	        params['searchDate'] = searchDate;    
	          var monthly_indicator_text=[];
	          $.ajax({
	            url: pageMainUrl + 'ApiUser/getMinistryChart',
	            data: params,
	            type: 'POST',
	            dataType : "json",
	            async: false,
	            success: function (result) {
	              monthly_indicator_text = result;
	            }
	        });
            $('#monthly_indicator').show();
	        var data = google.visualization.arrayToDataTable(monthly_indicator_text);	          
	    var view = new google.visualization.DataView(data);
	    view.setColumns([0, 1,
	     { calc: "stringify",
	     sourceColumn: 1,
	     type: "string",
	     role: "annotation" },
	     2]);
	    var options = {      
	      chartArea: {     
	        left:500,top:25,width:'100%',height:'90 %'
	      },
	      width: '100%',
	      height: 1000,
	      bar: {groupWidth: "90%"},
	      legend: { position: "none" },
	    };
	    var chart = new google.visualization.BarChart(document.getElementById("monthly_indicator"));
	    chart.draw(view, options);
	  }
      
  }

	$('document').ready(function(){
		piechart_MatDeath_fun();
		piechart_NeonDeath_fun();
		piechart_StillBirth_fun();
		piechart_Deliveries_fun();
		monthly_indicator_fun();
		$('.dateChangeClass').change(function(){
			var searchDate=$(this).val();
			var functionName=$(this).attr('data-changeFunction');
			var loaderName=$(this).attr('data-loader');
			$('#'+loaderName).show();
			$('#'+functionName).hide();
			switch(functionName) {
			  case 'piechart_MatDeath':
			    piechart_MatDeath_fun(searchDate);
			    break;
			  case 'piechart_NeonDeath':
			    piechart_NeonDeath_fun(searchDate);
			    break;
			  case 'piechart_StillBirth':
			    piechart_StillBirth_fun(searchDate);
			    break;
			  case 'piechart_Deliveries':
			    piechart_Deliveries_fun(searchDate);
			    break;
			  default:
			    // code block
			}
		});

	});
    </script>






<script type="text/javascript">
	
	$("#view-more-btn").click(function(){
		$(".hidden-dash-bard").show();
		$(this).remove();
		return false;
	});

$(document).ready(function(){
	$('.count').each(function () {
	    $(this).prop('Counter',0).animate({
	        Counter: $(this).text()
	    }, {
	        duration: 4000,
	        easing: 'swing',
	        step: function (now) {
	            $(this).text(Math.ceil(now));
	        }
	    });
	});
});



</script>
 