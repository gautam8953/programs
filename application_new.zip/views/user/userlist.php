<div class="page-title">
  <div class="title_left">
    <h3>Users</h3>
  </div>

  
</div>

<div class="clearfix"></div>

<div class="main-content carti-c"> 
    <div class="container">	  
    <div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>User List</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">	    
	   
		        <div class="col-md-12">
		        	<div class="row mar-bottom30">
	                <div class="col-md-3 col-xs-12 mar-top-20">
	                	<select id="search_role" name="search_role" class="form-control" onchange="change_role()" >
							<option value="">Select Roles</option>
							<?php  foreach ($roles as $key => $value) {  ?>
							<option value="<?php echo $value['RoleID']; ?>" ><?php echo $value['RoleName']; ?></option>
							<?php } ?>
						</select>                    
	                </div>
	                <div class="col-md-3 col-xs-12 mar-top-20">
	                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" style="display: none;" />
	                    <a href="javascript:void(0)" id="reset_btn" class="btn btn-primary">Reset</a>
	                </div>
	            	</div>
	            	<hr>
		        </div>		
			      <table id="datatable" class="table table-striped table-bordered">
			        <thead>
			            <tr>
			                <th>SN.</th>
			                <th>Name</th>
			                <th>User Name</th>
			                <th>Role Name</th>
			                <th>Created Data</th>
			                <th>Status</th>
			                <th>Action</th>
			            </tr>
			            </thead>
			            <tbody>
			            </tbody>
			      </table>
			    </div>
			  </div>
			</div>
		</div>        
    </div>
</div>
