<div class="page-title">
    <div class="title_left">
        <h3>Assessment Form</h3>
    </div>

    <div class="title_right">
        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
            <div class="input-group" style="float: right;">
                <a href="<?php echo base_url() . "facility/assesment"; ?>" id="addBtn" class="btn btn-success disabled pull-right">Add</a>
            </div>
        </div>
    </div>
</div>

<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">	    

        <div class="row">
            <div class="col-md-12">
                <?php if (isset($search_options['Facility'])) { ?>
                    <?php
                    $attr = array("class" => "form-horizontal", "role" => "form", "id" => "form1", "name" => "form1");
                    echo form_open("facility/data", $attr);
                    ?>

                    <?php if (isset($search_options['State'])) { ?>
                        <div class="col-md-3">
                            <select id="search_state" name="search_state" onchange="change_state()" class="form-control">
                                <option value="">Select State</option>
                                <?php foreach ($search_options['State'] as $key => $value) { ?>
                                    <option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
                                <?php } ?>
                            </select>                    
                        </div>
                    <?php } ?>
                    <?php if (isset($search_options['District'])) { ?>
                        <div class="col-md-3">
                            <select id="search_district" name="search_district" onchange="change_district()" class="form-control">
                                <option value="">Select District</option>
                                <?php foreach ($search_options['District'] as $key => $value) { ?>
                                    <option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
                                <?php } ?>
                            </select>                    
                        </div>
                    <?php } ?>
                    <?php if (isset($search_options['Facility'])) { ?>
                        <div class="col-md-3">
                            <select id="search_facility" name="search_facility" class="form-control">
                                <option value="">Select Facility</option>
                            </select>                    
                        </div>
                    <?php } ?>
                    <div class="col-md-3">
                        <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" />
                        <a href="<?php echo base_url() . "facility/index"; ?>" class="btn btn-primary">Reset</a>
                    </div>
                    <?php echo form_close(); ?>
                <?php } ?>

            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Assessment Form</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                            <!--<li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Settings 1</a>
                                </li>
                                <li><a href="#">Settings 2</a>
                                </li>
                              </ul>
                            </li>-->
                            <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                            </li>-->
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">

                        <table id="datatable" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Assessment Type</th>
                                    <th>Type</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>        
    </div>
</div>