import { Component, OnInit } from '@angular/core';
import { UsersService } from '../services/users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  users:any;
  constructor(private usersService:UsersService) { }

  ngOnInit() {
    this.getUsersData();
    //this.users=this.usersService.getData();
    //console.log(this.users);
  }

  getUsersData(){
    this.usersService.getData().subscribe(res=>{
      console.log(res);
    });
    console.log('fh');
  }
}
