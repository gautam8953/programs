import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class UsersService {
  data:any;
  usersUrl: string = 'http://localhost:8000/user';
  constructor(private http: HttpClient) { }

  getData(){
    return this.http.get(this.usersUrl);
    
    // return this.data=[
    //   {'name':'test 1'},
    //   {'name':'test 2'},
    //   {'name':'test 3'},
    //   {'name':'test 4'},
    // ];
  }
}
