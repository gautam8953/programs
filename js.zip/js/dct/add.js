$(document).ready(function () {
    $('#assesmentForm').submit(function () {
        $("#bodyLoad").addClass('loader');
        $("#loader_overlay").show();
        $(this).ajaxSubmit({
            beforeSubmit: showRequest,
            success: showResponse,
            type: 'POST',
            dataType: 'json',
            data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false;
    });
});

function showResponse(responseText, statusText, xhr, $form) {
    $("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
    if (parseInt(responseText.code) == 0) {
        swal('Data successfully submitted').then((value) => {
            window.location.reload();
        });
//        $("#msgDiv").removeClass('alert-danger');
//        $("#msgDiv").addClass('alert-success').show();
    } else {
        swal('Error occured during saving data...Please try again');
//        $('#assesment').prop('disabled', false);
//        $("#msgDiv").removeClass('alert-success');
//        $("#msgDiv").addClass('alert-danger').show();
    }

    $("#LoginMsg").text(responseText.msg);


}
function showRequest(formData, jqForm, options) {
    var totalRow = ($("div[id^='totalDiv_']").length);
    var check = '0';
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    for (var i = 1; i <= totalRow; i++) {
        if ($('#search_state_' + i).val() == '' || $('#search_state_' + i).val() == 'undefined') {
            $('#search_state_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#search_state_' + i).removeClass('erroShow');
        }
        if ($('#search_district_' + i).val() == '' || $('#search_district_' + i).val() == 'undefined') {
            $('#search_district_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#search_district_' + i).removeClass('erroShow');
        }

        if ($('#name_' + i).val() == '' || $('#name_' + i).val() == 'undefined') {
            $('#name_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#name_' + i).removeClass('erroShow');
//        $('#name'+i).closest('.form-group').removeClass('has-error');
        }

        if ($('#department_' + i).val() == '' || $('#department_' + i).val() == 'undefined') {
            $('#department_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#department_' + i).removeClass('erroShow');
        }

        if ($('#designation_' + i).val() == '' || $('#designation_' + i).val() == 'undefined') {
            $('#designation_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#designation_' + i).removeClass('erroShow');
        }

        if ($('#designation_smg_' + i).val() == '' || $('#designation_smg_' + i).val() == 'undefined') {
            $('#designation_smg_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#designation_smg_' + i).removeClass('erroShow');
        }

        if ($('#email_' + i).val() == '' || $('#email_' + i).val() == 'undefined' || (!emailReg.test($('#email_' + i).val()))) {
            $('#email_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#email_' + i).removeClass('erroShow');
        }

        if ($('#mobile_' + i).val() == '' || $('#mobile_' + i).val() == 'undefined') {
            $('#mobile_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#mobile_' + i).removeClass('erroShow');
        }

    }
    if (check != '0') {
//        $('#assesment').prop('disabled', false);
        $("#bodyLoad").removeClass('loader');
        $("#loader_overlay").hide();
        return false;

    }
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    return true;
}
function change_state(StateID, rowId) {
//    console.log(StateID);
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = StateID;
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district_' + rowId).html('<option value="">Select District</option>');
            if (parseInt(result.data.length) > 0) {
                $.each(result.data, function (key, val) {
                    $('#search_district_' + rowId).append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
            if (parseInt($('#search_district option').length) >= 2) {
                $('#search_district_' + rowId).val($('#search_district_' + rowId + ' option:eq(1)').val());
//                change_district();
            }
//            $('#search_facility').html('<option value="">Select Facility</option>');
        }
    });
}