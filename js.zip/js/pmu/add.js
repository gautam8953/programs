$(document).ready(function () {

    if($('#pmudataID').val()=='1'){
        getPmuData();

       
    }

    if ($('#search_state').length) {
        if ($('#search_state option').length == '2') {
            $('#search_state').val($('#search_state option:eq(1)').val());
            change_state();
            $('#change_state').closest('.form-group').parent().hide();
        }
    } else {
        if ($('#search_district option').length == '2') {
            $('#search_district').val($('#search_district option:eq(1)').val());
            change_district();
            $('#search_district').closest('.form-group').parent().hide();
        }
    }

    $('#uploaForms').submit(function () {

        $("#bodyLoad").addClass('loader');
        $("#loader_overlay").show();
        $(this).ajaxSubmit({
            beforeSubmit: showRequest,
            success: showResponse,
            type: 'POST',
            dataType: 'json',
            data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false;
    });

    validate_assesment();

});

function showResponse(responseText, statusText, xhr, $form) {
    $("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
    $('.errDivUpload').html('');
    $('#excelfile').val('');
    $('#uploaForms input[type="text"]').val('');
    $('#uploaForms select').not('#survey,#surveyType,#assessment,#checklist_format').val('');
    $("label[for='excelfile']").children('span').text('');
    $('.selectpicker').selectpicker('refresh');
    if(responseText.hasOwnProperty('errdesc')){
        swal(responseText.errdesc);
    } else {
        swal(responseText.msg);
    }    
    if (responseText.hasOwnProperty('err')) {
        if(parseInt(responseText.err.length)>0){
            $('.errDivUpload').append('<table id="errTableUpload"><thead><tr><th align="left">Checkpoint</th><th align="left">Compliance</th></tr></thead><tbody>');
            $.each(responseText.err, function (key, val) {
                $('#errTableUpload').append('<tr><td align="left">' + val[2] + '</td><td align="left">' + val[3] + '</td></tr>');
            });
            $('.errDivUpload').append('</tbody></table>');
        }
    }
}
function showRequest(formData, jqForm, options) {
    var check = '0';
    if($('#pmuName').val()==''){
        swal('Please select nmae first');
        check = '1';
    }
    if($('#Date_of_visit').val()==''){
        swal('Please enter Date of visit');
        check = '1';
    }

    if(parseInt($('#search_facility').length)>0){
        if($('#search_facility').val()==''){
            swal('Please select facility');
            check = '1';
        }
    }
    if ($('#Keyfindings').val() == '' && $('#pmudataID').val()!='1' ) {
        swal('Please select Key findings file first');
        //$('#excelfile').closest('.form-group').addClass('has-error');
        check = '1';
    } else {
        var validExts = new Array(".xlsx", ".xls", ".csv",".docx",".doc",".pdf");
        var fileExt = $('#Keyfindings').val();
        fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
        if (validExts.indexOf(fileExt) < 0  && $('#pmudataID').val()!='1') {
        swal('Please choose only file');
            $('#Keyfindings').val('');
            $("label[for='Keyfindings']").children('span').text('');
            //$('#excelfile').closest('.form-group').addClass('has-error');
            check = '1';
        } else {
            //$('#excelfile').closest('.form-group').removeClass('has-error');
        }
    }
    if ($('#recommendations').val() == '' && $('#pmudataID').val()!='1') {
        swal('Please select Recommendations file first');
        //$('#excelfile').closest('.form-group').addClass('has-error');
        check = '1';
    } else {
        var validExts = new Array(".xlsx", ".xls", ".csv",".docx",".doc",".pdf");
        var fileExt = $('#recommendations').val();
        fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
        if (validExts.indexOf(fileExt) < 0  && $('#pmudataID').val()!='1') {
        swal('Please choose only excel file');
            $('#recommendations').val('');
            $("label[for='recommendations']").children('span').text('');
            //$('#excelfile').closest('.form-group').addClass('has-error');
            check = '1';
        } else {
            //$('#excelfile').closest('.form-group').removeClass('has-error');
        }
    }
    if (check != '0') {

        $("#bodyLoad").removeClass('loader');
        $("#loader_overlay").hide();
        return false;
    }
    return true;
}
function checkFilekey(fileobj) {
    var validExts = new Array(".xlsx", ".xls", ".csv",".docx",".doc",".pdf");
    var fileExt = fileobj.value;
    fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
    if (validExts.indexOf(fileExt) < 0) {
        swal('Please choose only excel file');
        $('#Keyfindings').val('');
        $("label[for='Keyfindings']").children('span').text('');
        //$(fileobj).closest('.form-group').addClass('has-error');
        return false;
    } else {
        //$(fileobj).closest('.form-group').removeClass('has-error');
    }
}

function checkFileRec(fileobj) {
    var validExts = new Array(".xlsx", ".xls", ".csv",".docx",".doc",".pdf");
    var fileExt = fileobj.value;
    fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
    if (validExts.indexOf(fileExt) < 0) {
        swal('Please choose only excel file');
        $('#recommendations').val('');
        $("label[for='recommendations']").children('span').text('');
        //$(fileobj).closest('.form-group').addClass('has-error');
        return false;
    } else {
        //$(fileobj).closest('.form-group').removeClass('has-error');
    }
}
function change_district() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'facility';
    params['searchData'] = $('#search_district').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_facility').html('<option value="">Select Facility</option>');
            if (result.data) {
                if (parseInt(result.data.length) > 0) {
                    $.each(result.data, function (key, val) {
                        $('#search_facility').append($("<option></option>").attr("value", val.UserID).text(val.FacilityName));
                    });
                    if ($('#search_facility').length) {
                        if (parseInt($('#search_facility option').length) == 2) {
                            $('#search_facility').val($('#search_facility option:eq(1)').val());
                            $('#btn_search').trigger('click');
                        }
                    }
                }
            }
        }
    });
}

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="">Select District</option>');
            if (parseInt(result.data.length) > 0) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
            if (parseInt($('#search_district option').length) >= 2) {
                $('#search_district').val($('#search_district option:eq(1)').val());
                change_district();
            }
            $('#search_facility').html('<option value="">Select Facility</option>');
        }
    });
}
function change_facility(ths){
    $('#search_facility').selectpicker('refresh');
}
function validate_assesment(){
     var params={};
     var search_facility=parseInt($('#search_facility').val())||0;
     var pmuName=$('#pmuName').val();
   
     params['device']='web';
     params['csrf_token']=$.cookie("csrf_cookie");
     params['search_facility']=search_facility;
    params['pmuName']=pmuName;

     $.ajax({
         url: pageMainUrl+'ApiPmu/validate_assesment', 
         data: params, 
         type: 'POST', 
         success: function(result){
             console.log(result);
         }
     });    
}


function getPmuData(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['pmuId']=$('#pmuID').val();
    $.ajax({
        url: pageMainUrl+'ApiPmu/pmuDataEdit', 
        data: params, 
        type: 'POST', 
        dataType: 'json',
        async:false, 
        success: function(result){
            
            
            $("#Keyfindings_file").attr("href",result.urlval+result.data.Keyfindings);
            $("#recommendations_file").attr("href",result.urlval+result.data.recommendations);
            $("#keyFind").val(result.data.Keyfindings);
            $("#recfile").val(result.data.recommendations);
           
            
            $('#Date_of_visit').val(result.data.Date_of_visit);

           $('#search_facility').html('<option value="'+result.data.FacilityUserID+'">'+result.data.FacilityName+'</option>');
            if($('#search_state').length){
                $('#search_state').append('<option value="'+result.data.StateID+'">'+result.data.StateName+'</option>');
                $('#search_state').val(result.data.StateID);
            }
            if($('#search_district').length){
                $('#search_district').append('<option value="'+result.data.DistrictID+'">'+result.data.DistrictName+'</option>');
                $('#search_district').val(result.data.DistrictID);
            }

            if($('#pmuName').length){
                $('#pmuName').append('<option value="'+result.data.UserID+'">'+result.data.FirstName+'</option>');
                $('#pmuName').val(result.data.UserID);
            }

                   /* $('#search_state').val(result.data.StateID);
                    $('#search_state').selectpicker('refresh');
                    change_state();
                    $('#search_district').val(result.data.DistrictID);
                    $('#search_district').selectpicker('refresh');
                    change_district();
                    $('#search_facility').val(result.data.FacilityUserID);
                    $('#search_facility').selectpicker('refresh');
                    change_facility();*/
        }
    }); 
}