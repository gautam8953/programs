$(document).ready(function () {
  
    $('#hrForm').submit(function() {
        $(this).ajaxSubmit({
          beforeSubmit:  showRequest,
          success: showResponse,
          type: 'POST',
          dataType: 'json',
          data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false; 
    });

});


function showResponse(responseText, statusText, xhr, $form)  {
  //alert(responseText);

    if(parseInt(responseText.code)==0){
      swal(responseText.msg).then((value) => {
        window.location.replace(window.location.href);
      });
 
    } else {
      swal(responseText.msg);
      
    }    

    
}
function showRequest(formData, jqForm, options) { 
 //alert("SDBFHBSDJ");

   //alert(formData);
    var check='0';
   //alert($('#FacilityName').val().length);
    
    if($('#FacilityName').val().length > 1){
    //  alert(formData);
      var main_check='0';
      if($.trim($('#FacilityHead').val())==''){
        check='1';
        $('#FacilityHead').closest('.form-group').addClass('has-error');
      } else {
        $('#FacilityHead').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#Gynecologist').val())==''){
        check='1';
        $('#Gynecologist').closest('.form-group').addClass('has-error');
      } else {
        $('#Gynecologist').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#Pediatrician').val())==''){
        check='1';
        $('#Pediatrician').closest('.form-group').addClass('has-error');
      } else {
        $('#Pediatrician').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#Anesthetist').val())==''){
        check='1';
        $('#Anesthetist').closest('.form-group').addClass('has-error');
      } else {
        $('#Anesthetist').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#MedicalOfficer').val())==''){
        check='1';
        $('#MedicalOfficer').closest('.form-group').addClass('has-error');
      } else {
        $('#MedicalOfficer').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#FacilityTypeDetailID').val())=='' || $('#FacilityTypeDetailID').val()==undefined){
        check='1';
        $('#FacilityTypeDetailID').closest('.form-group').addClass('has-error');
      } else {
        $('#FacilityTypeDetailID').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#lr_staff_name').val())==''){
        check='1';
        $('#lr_staff_name').closest('.form-group').addClass('has-error');
      } else {
        $('#lr_staff_name').closest('.form-group').removeClass('has-error');
      }
       if($.trim($('#ot_staff_name').val())==''){
        check='1';
        $('#ot_staff_name').closest('.form-group').addClass('has-error');
      } else {
        $('#ot_staff_name').closest('.form-group').removeClass('has-error');
      }
       if($.trim($('#total_sba_trained').val())==''){
        check='1';
        $('#total_sba_trained').closest('.form-group').addClass('has-error');
      } else {
        $('#total_sba_trained').closest('.form-group').removeClass('has-error');
      }
       if($.trim($('#total_lab_trained').val())==''){
        check='1';
        $('#total_lab_trained').closest('.form-group').addClass('has-error');
      } else {
        $('#total_lab_trained').closest('.form-group').removeClass('has-error');
      }
       if($.trim($('#avg_delivery_month').val())==''){
        check='1';
        $('#avg_delivery_month').closest('.form-group').addClass('has-error');
      } else {
        $('#avg_delivery_month').closest('.form-group').removeClass('has-error');
      }
       if($.trim($('#avg_section_month').val())==''){
        check='1';
        $('#avg_section_month').closest('.form-group').addClass('has-error');
      } else {
        $('#avg_section_month').closest('.form-group').removeClass('has-error');
      }
       if($.trim($('#total_laborbeds').val())==''){
        check='1';
        $('#total_laborbeds').closest('.form-group').addClass('has-error');
      } else {
        $('#total_laborbeds').closest('.form-group').removeClass('has-error');
      }
       if($('input[name="IsTrained"]:checked').length == 0){
        check='1';
        $('#IsTrained').closest('.form-group').addClass('has-error');
      } else {
        $('#IsTrained').closest('.form-group').removeClass('has-error');
      }

        if($('input[name="MaternityProtocol"]:checked').length == 0){
        check='1';
        $('#MaternityProtocol').closest('.form-group').addClass('has-error');
      } else {
        $('#MaternityProtocol').closest('.form-group').removeClass('has-error');
      }
        if($('input[name="QualityProtocol"]:checked').length == 0){
        check='1';
        $('#QualityProtocol').closest('.form-group').addClass('has-error');
      } else {
        $('#QualityProtocol').closest('.form-group').removeClass('has-error');
      }
        if($('input[name="IsSkillsLab"]:checked').length == 0){
        check='1';
        $('#IsSkillsLab').closest('.form-group').addClass('has-error');
      } else {
        $('#IsSkillsLab').closest('.form-group').removeClass('has-error');
      }
        if($('input[name="avbl_eq_in_lr"]:checked').length == 0){
        check='1';
        $('#avbl_eq_in_lr').closest('.form-group').addClass('has-error');
      } else {
        $('#avbl_eq_in_lr').closest('.form-group').removeClass('has-error');
      }
        if($('input[name="avbl_eq_in_ot"]:checked').length == 0){
        check='1';
        $('#avbl_eq_in_ot').closest('.form-group').addClass('has-error');
      } else {
        $('#avbl_eq_in_ot').closest('.form-group').removeClass('has-error');
      }
      if($('input[name="avbl_drg_in_lr"]:checked').length == 0){
        check='1';
        $('#avbl_drg_in_lr').closest('.form-group').addClass('has-error');
      } else {
        $('#avbl_drg_in_lr').closest('.form-group').removeClass('has-error');
      }
      if($('input[name="avbl_drg_in_ot"]:checked').length == 0){
        check='1';
        $('#avbl_drg_in_ot').closest('.form-group').addClass('has-error');
      } else {
        $('#avbl_drg_in_ot').closest('.form-group').removeClass('has-error');
      }

    }

//alert(check);
    if(check!='0'){
      return false;
    } else {
        return true;
    }
	
    //return true;
}