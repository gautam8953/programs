$(document).ready(function () {
    $('#assesmentForm').submit(function () {
        $(this).ajaxSubmit({
            beforeSubmit: showRequest,
            success: showResponse,
            type: 'POST',
            dataType: 'json',
            data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false;
    });
});

function showResponse(responseText, statusText, xhr, $form) {
    $("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
    if (parseInt(responseText.code) == 0) {
        swal('Data successfully submitted').then((value) => {
            window.location.reload();
        });
        //$("#msgDiv").removeClass('alert-danger');
        //$("#msgDiv").addClass('alert-success').show();
    } else {
        swal('Error occured during saving data...Please try again');        
        //$('#assesment').prop('disabled', false);
        //$("#msgDiv").removeClass('alert-success');
        //$("#msgDiv").addClass('alert-danger').show();
    }

    $("#LoginMsg").text(responseText.msg);


}
function validateEmail(email) {
//    alert(email);
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    return emailReg.test(email);
}
function showRequest(formData, jqForm, options) {
    var totalRow = ($("div[id^='totalDiv_']").length);
    var check = '0';
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

    for (var i = 1; i <= totalRow; i++) {
        if ($('#search_state_' + i).val() == '' || $('#search_state_' + i).val() == 'undefined') {
            $('#search_state_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#search_state_' + i).removeClass('erroShow');
        }

        if ($('#name_' + i).val() == '' || $('#name_' + i).val() == 'undefined') {
            $('#name_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#name_' + i).removeClass('erroShow');
//        $('#name'+i).closest('.form-group').removeClass('has-error');
        }

        if ($('#department_' + i).val() == '' || $('#department_' + i).val() == 'undefined') {
            $('#department_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#department_' + i).removeClass('erroShow');
        }

        if ($('#designation_' + i).val() == '' || $('#designation_' + i).val() == 'undefined') {
            $('#designation_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#designation_' + i).removeClass('erroShow');
        }

        if ($('#designation_smg_' + i).val() == '' || $('#designation_smg_' + i).val() == 'undefined') {
            $('#designation_smg_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#designation_smg_' + i).removeClass('erroShow');
        }

        if (($('#email_' + i).val() == '' || $('#email_' + i).val() == 'undefined') || (!emailReg.test($('#email_' + i).val()))) {
            $('#email_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#email_' + i).removeClass('erroShow');
        }

        if ($('#mobile_' + i).val() == '' || $('#mobile_' + i).val() == 'undefined') {
            $('#mobile_' + i).addClass('erroShow');
            check = '1';
        } else {
            $('#mobile_' + i).removeClass('erroShow');
        }

    }
    if (check != '0') {
//        $('#assesment').prop('disabled', false);
$("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
        return false;
        
    }
    
    return true;
}