$(document).ready(function () {
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();

    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl + 'ApiUser/getstates',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (result.code=='0') {
                if (result.hasOwnProperty('data') && parseInt($('#search_state').length) > 0) {
                    $('#search_state').html('<option value="" >All State</option>');
                    $.each(result.data, function (key, val) {
                        $('#search_state').append($("<option></option>").attr("value", val.StateID).text(val.StateName));
                    });
                }
                $('#search_district').html('<option value="" >All District</option>');
                $('#facilityName').html('<option value="" >All Facility</option>');
                $('.selectpicker').selectpicker('refresh');
            }
        }
    });

    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 50,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "order": [[ 0, "ASC" ]],
        "ajax": {
            url: pageMainUrl + "ApiUser/getMappeduserdata",
            type: "post",
            data: function (d) {
                $("#bodyLoad").removeClass('loader');
                $("#loader_overlay").hide();
                d.search_role = $('#search_role').val();
                d.search_user = $('#search_user').val();
                d.search_state = $('#search_state').val();
                d.search_district = $('#search_district').val();
                d.facilityName = $('#facilityName').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        drawCallback: function () {
        }
    });

    $('#btn_search').click(function () {
        datatableData.ajax.reload();
    });
     $("#reset_btn").click(function () {
        $('select').prop('selectedIndex', 0);
        $('.selectpicker').selectpicker('refresh');
        datatableData.ajax.reload();
    });

});

function getuser(ths){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['search_role']=$('#search_role').val();
    $.ajax({
        url: pageMainUrl+'apiuser/getuser', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#search_user').html('<option value="">Select User</option>');
            if(parseInt(result.data.length)>0){
                $.each(result.data,function(key,val){
                    $('#search_user').append($("<option></option>").attr("value",val.UserID).text(val.FirstName).attr("data-subtext",val.UserName));
                });
            }
            $('#search_state,#search_district,#facilityName,#mapped_state,#mapped_district,#mapped_facility').val('');
            $('.selectpicker').selectpicker('refresh');
            $('#btn_search').triger('click');
        }
    });
}
function change_state(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['search_state']=$('#search_state').val();
    $.ajax({
        url: pageMainUrl+'ApiUser/getdistricts',
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#search_district').html('<option value="">All District</option>');
            if(parseInt(result.data.length)>0){
                $.each(result.data,function(key,val){
                    $('#search_district').append($("<option></option>").attr("value",val.DistrictID).text(val.DistrictName).attr("data-subtext",val.StateName));
                });
            }
            $('#facilityName').html('<option value="">All Facility</option>');
            $('.selectpicker').selectpicker('refresh');
            $('#btn_search').triger('click');
        }
    });
}
function change_district(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['search_state']=$('#search_state').val();
    params['search_district']=$('#search_district').val();
    $.ajax({
        url: pageMainUrl+'ApiUser/getfacilities',
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#facilityName').html('<option value="">All Facility</option>');
            if(parseInt(result.data.length)>0){
                $.each(result.data,function(key,val){
                    $('#facilityName').append($("<option></option>").attr("value",val.FacilityID).text(val.FacilityName).attr("data-subtext",val.hintText));
                });
            }
            $('.selectpicker').selectpicker('refresh');
            $('#btn_search').triger('click');
        }
    });
}
function change_user(){
    $('#btn_search').triger('click');
}
