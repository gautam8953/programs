$(document).ready(function () {

    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 50,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "order": [[ 0, "ASC" ]],
        "ajax": {
            url: pageMainUrl + "ApiUser/getUserlist",
            type: "post",
            data: function (d) {
                $("#bodyLoad").removeClass('loader');
                $("#loader_overlay").hide();
                d.search_role = $('#search_role').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        drawCallback: function () {
        }
    });

    $('#btn_search').click(function () {
        datatableData.ajax.reload();
    });
     $("#reset_btn").click(function () {
        $('select').prop('selectedIndex', 0);
        $('.selectpicker').selectpicker('refresh');
        datatableData.ajax.reload();
    });
});

function change_role(){
    $('#btn_search').trigger('click');
}