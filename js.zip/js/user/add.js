$('document').ready(function(){
  var params = {};
  params['device'] = 'web';
  params['csrf_token']=$.cookie("csrf_cookie");
  $.ajax({
      url: pageMainUrl + 'ApiUser/getstates',
      data: params,
      type: 'POST',
      dataType: 'json',
      async: false,
      success: function (result) {
          if (result.code=='0') {
              if (result.hasOwnProperty('data') && parseInt($('#search_state').length) > 0) {
                  //$('#search_state').html('<option value="" >Select State</option>');
                  $('#search_state').html('<option value="99999" >All State</option>');
                  $.each(result.data, function (key, val) {
                      $('#search_state').append($("<option></option>").attr("value", val.StateID).text(val.StateName));
                  });
              }
              $('#search_district').html('<option value="99999" >All District</option>');
              $('#FacilityName').html('<option value="99999" >All Facility</option>');
              $('.selectpicker').selectpicker('refresh');
          }
          if($('#UserID').val()!=''){
            check_state();
          }
      }
  });

  $('#userForm').submit(function(){
      $(this).ajaxSubmit({
        beforeSubmit:  showRequest,
        success: showResponse,
        type: 'POST',
        dataType: 'json',
        data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
      });
      return false; 
  });

  if($('#UserID').val()!=''){
    is_admin();
  }

});

function showResponse(responseText, statusText, xhr, $form)  {
    $("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
    if(parseInt(responseText.code)==0){
        swal(responseText.msg).then((value) => {
            window.location.replace(pageMainUrl+"user/userlist");
        });
    } else {
      swal(responseText.msg);
      $('#userFrm').prop('disabled',false);
    }
}
function showRequest(formData, jqForm, options) {
    var check='0';
    $('#userFrm').prop('disabled',true);
    if($('input[name="FirstName"]').val()==''){
      $('input[name="FirstName"]').closest('.form-group').addClass('has-error');  
      check=1;   
    } else {
      $('input[name="FirstName"]').closest('.form-group').removeClass('has-error');
    }

    if($('input[name="UserName"]').val()==''){
      $('input[name="UserName"]').closest('.form-group').addClass('has-error');  
      check=1;   
    } else {
      $('input[name="UserName"]').closest('.form-group').removeClass('has-error');
    }

    if($('input[name="Email"]').val()==''){
      $('input[name="Email"]').closest('.form-group').addClass('has-error');  
      check=1;   
    } else {
      $('input[name="Email"]').closest('.form-group').removeClass('has-error');
    }
    if($('input[name="Mobile"]').val()==''){
      $('input[name="Mobile"]').closest('.form-group').addClass('has-error');  
      check=1;   
    } else {
      $('input[name="Mobile"]').closest('.form-group').removeClass('has-error');
    }
    if($('select[name="search_state[]"]').val()=='' || $('select[name="search_state[]"]').val()==undefined){
      $('select[name="search_state[]"]').closest('.form-group').addClass('has-error');  
      check=1;   
    } else {
      $('select[name="search_state[]"]').closest('.form-group').removeClass('has-error');
    }
    if($('select[name="search_district[]"]').val()=='' || $('select[name="search_district[]"]').val()==undefined){
      $('select[name="search_district[]"]').closest('.form-group').addClass('has-error');  
      check=1;   
    } else {
      $('select[name="search_district[]"]').closest('.form-group').removeClass('has-error');
    }
    if($('select[name="FacilityName[]"]').val()=='' || $('select[name="FacilityName[]"]').val()==undefined){
      $('select[name="FacilityName[]"]').closest('.form-group').addClass('has-error');  
      check=1;   
    } else {
      $('select[name="FacilityName[]"]').closest('.form-group').removeClass('has-error');
    }

    if($('#UserID').val()==''){
      if($('input[name="Password"]').val()==''){
        $('input[name="Password"]').closest('.form-group').addClass('has-error');  
        check=1;   
      } else {
        $('input[name="Password"]').closest('.form-group').removeClass('has-error');
      }      
    }
    if($('input[name="Password"]').val()!='' && ($('input[name="Password"]').val()!=$('input[name="Password1"]').val())){
    	$('input[name="Password"]').closest('.form-group').addClass('has-error');
    	$('input[name="Password1"]').closest('.form-group').addClass('has-error');
      check=1;   
    }
    if(check!='0'){
      $('#userFrm').prop('disabled',false);
      return false;
    }
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    return true; 
}
function checkusername(){
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['UserName'] = $('#UserName').val();
    $.ajax({
        url: pageMainUrl + 'ApiUser/checkusername',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (result.code!='0') {
                swal(result.msg);
                $('#UserName').val('');
            }
        }
    });
}
function is_admin(){
  if($('#usertype').val()==1){    
    $('.state,.district,.facility').hide('');
  } else {
    $('.state,.district,.facility').show('');
  }
  $('#search_state,#search_district,#FacilityName').val('');
}
function change_state(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['search_state']=$('#search_state').val();
    $.ajax({
        url: pageMainUrl+'ApiUser/getdistricts',
        data: params, 
        type: 'POST', 
        dataType: 'json',
        async: false, 
        success: function(result){
            $('#search_district').html('<option value="99999">All District</option>');
            if(params['search_state']!='' && params['search_state']!=null ){
              if(parseInt(result.data.length)>0){
                  $.each(result.data,function(key,val){
                      $('#search_district').append($("<option></option>").attr("value",val.DistrictVal).text(val.DistrictName).attr("data-subtext",val.StateName));
                  });
              }
            }
            $('#FacilityName').html('<option value="99999">All Facility</option>');
            $('.selectpicker').selectpicker('refresh');
            
            if($('#UserID').val()!=''){
              check_district();
            }
        }
    });
    if ($("#search_state option[value=99999]:selected").length > 0){
      $("#search_state option[value!=99999]").removeAttr('selected');
    }
}
function change_district(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['search_state']=$('#search_state').val();
    params['search_district']=$('#search_district').val();
    $.ajax({
        url: pageMainUrl+'ApiUser/getfacilities',
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        async: false,
        success: function(result){
            $('#FacilityName').html('<option value="99999">All Facility</option>');
            if(params['search_district']!='' && params['search_district']!=null){
              if(parseInt(result.data.length)>0){
                  $.each(result.data,function(key,val){
                      $('#FacilityName').append($("<option></option>").attr("value",val.FacilityVal).text(val.FacilityName).attr("data-subtext",val.hintText));
                  });
              }
            }
            $('.selectpicker').selectpicker('refresh');
            
            if($('#UserID').val()!=''){
              check_facility();
            }
        }
    });
    if ($("#search_district option[value=99999]:selected").length > 0){
      $("#search_district option[value!=99999]").removeAttr('selected');
    }
}
function change_facility(){
    if ($("#FacilityName option[value=99999]:selected").length > 0){
      $("#FacilityName option[value!=99999]").removeAttr('selected');
    }
    $('.selectpicker').selectpicker('refresh');
}
function check_state(){
  if($('#StateID').val()!=''){
    var states=$('#StateID').val();
    var statesArr=states.split(',');
    $.each(statesArr,function(key,vals){
      if(vals!=''){
        $('#search_state option[value="'+vals+'"]').attr("selected",true);
        $('#search_state').selectpicker('refresh');
      }
    });    
  } else {
    $('#search_state option[value="99999"]').attr("selected",true);
  }
  $('#search_state').selectpicker('refresh');
  change_state();
}
function check_district(){
  if($('#DistrictID').val()!=''){
    var district=$('#DistrictID').val();
    var districtArr=district.split(',');
    $.each(districtArr,function(key,vals){
      if(vals!=''){
        $('#search_district option[value="'+vals+'"]').attr("selected",'selected');        
      }
    });    
  } else {
    $('#search_district option[value="99999"]').attr("selected",'selected');
  }
  $('#search_district').selectpicker('refresh');
  change_district();
}
function check_facility(){
  if($('#FacilityID').val()!=''){
    var facility=$('#FacilityID').val();
    var facilityArr=facility.split(',');
    $.each(facilityArr,function(key,vals){
      if(vals!=''){
        $('#FacilityName option[value="'+vals+'"]').attr("selected",'selected');        
      }
    });    
  } else {
    $('#FacilityName option[value="99999"]').attr("selected",'selected');
  }
  $('#FacilityName').selectpicker('refresh');
}