$(document).ready(function () {

    $('#profileForm').submit(function() {
        $(this).ajaxSubmit({
          beforeSubmit:  showRequest,
          success: showResponse,
          type: 'POST',
          dataType: 'json',
          data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false; 
    });

});

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="0">Select District</option>');
            if (result.hasOwnProperty('data')) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
        }
    });
}

function checkFile(fileobj) {
    var validExts = new Array(".jpg", ".jpeg", ".png",".bmp",".JPG", ".JPEG", ".PNG",".BMP");
    var fileExt = fileobj.value;
    fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
    if (validExts.indexOf(fileExt) < 0) {
        swal('Please choose only Image file');
        var ids=$(fileobj).attr('id');
        $('#'+ids).val('');
        $("label[for='"+ids+"']").children('span').text('');
        return false;
    }
}

function showResponse(responseText, statusText, xhr, $form)  {
    if(parseInt(responseText.code)==0){
      swal(responseText.msg).then((value) => {
        window.location.replace(window.location.href);
      });
      /*setTimeout(function() { 
        window.location.replace(window.location.href);
      }, 6000);*/
      
      //$("#msgDiv").removeClass('alert-danger');
      //$("#msgDiv").addClass('alert-success').show();
    } else {
      swal(responseText.msg);
      //$("#msgDiv").removeClass('alert-success');
      //$("#msgDiv").addClass('alert-danger').show();
    }    

    
}
function showRequest(formData, jqForm, options) { 
    /*var check='0';

    if(oldPassword==''){
      $('#oldPassword').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#oldPassword').closest('.form-group').removeClass('has-error');
    }
    if(check!='0'){
      return false;
    } else {
        return true;
    }*/
    return true;
}
function checkFacilityAssessment(ths){
  var params = {};
  var searchType=$(ths).val();
  console.log(searchType);
  params['device'] = 'web';
  params['csrf_token']=$.cookie("csrf_cookie");
  params['searchType'] = searchType;
  $.ajax({
      url: pageMainUrl + 'ApiUser/checkFacilityAssessment',
      data: params,
      type: 'POST',
      dataType: 'json',
      success: function (result) {
          if(result.code=='16'){
            swal(result.msg);
            $('#services_'+result.type).prop('checked',true);
          }
      }
  });
     
}