$(document).ready(function () {

    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 5,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "order": [[ 2, "desc" ]],
        "ajax": {
            url: pageMainUrl + "ApiUser/getlaqshyabaseotData",
            type: "post",
            data: function (d) {
                d.search_state = $('#search_state').val();
                d.search_district = $('#search_district').val();
                d.aspirational = $('#aspirational').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        drawCallback: function () {
            $("#bodyLoad").removeClass('loader');
            $("#loader_overlay").hide();
        }
    });

    if (parseInt($('#search_state option').length) == 2) {
        $('#search_state').val($('#search_state option:eq(1)').val());
        $('#search_state').closest('div').hide();
        change_state();
    }
    if ($('#search_district option').length == '2') {
        $('#search_district').val($('#search_district option:eq(1)').val());
        $('#search_district').closest('div').hide();
    }

    $('#btn_search').click(function () {
        datatableData.ajax.reload();
    });
     $("#reset_btn").click(function () {
        if ($('#search_district option').length>2) {
            $('#search_district').val($('#search_district option:eq(0)').val());
        }
        if ($('#search_state option').length>2) {
            $('#search_state').val($('#search_state option:eq(0)').val());
        }
        $('.selectpicker').selectpicker('refresh');
        datatableData.ajax.reload();
    });
     $('#search_district,#search_state').change(function(){
        datatableData.ajax.reload();
     });
     $('.selectpicker').selectpicker('refresh');


});

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="">Select District</option>');
            if (parseInt(result.data.length) > 0) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
            $('.selectpicker').selectpicker('refresh');
        }
    });
}

