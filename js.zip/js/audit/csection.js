
$(document).ready(function () {

    $("#smartwizard").on("showStep", function (e, anchorObject, stepNumber, stepDirection, stepPosition) {
        if (stepPosition === 'first') {
            $("#prev-btn").addClass('disabled');
            $('.btnPreview').hide();
            $('.saveBtn').hide();
        } else if (stepPosition === 'final') {
            $("#next-btn").addClass('disabled');
            $('.btnPreview').hide();
            $('.saveBtn').show();
        } else {
            $("#prev-btn").removeClass('disabled');
            $("#next-btn").removeClass('disabled');
            $('.btnPreview').hide();
            $('.saveBtn').hide();
        }
    });

    // Toolbar extra buttons
    var btnSaveQues = $('<button></button>').text('Submit')
            .addClass('btn btn-success saveBtn')
            .on('click', function () {
                save_data('all');
            });

    var btnDraftQues = $('<button></button>').text('Save as Draft')
            .addClass('btn btn-info draftBtn')
            .on('click', function () {
                save_data('draft');
            });

    var btnPreview = $('<button></button>').text('Preview')
            .addClass('btn btn-info btnPreview')
            .on('click', function () {
                preview_data();
            });

    // Smart Wizard
    $('#smartwizard').smartWizard({
        selected: 0,
        theme: 'default',
        transitionEffect: 'fade',
        labelFinish: 'Finish',
        showStepURLhash: false,
        keyNavigation: false,
        toolbarSettings: {toolbarPosition: 'both',
            toolbarButtonPosition: 'end',
            toolbarExtraButtons: [btnDraftQues,btnPreview,btnSaveQues]
        },
        anchorSettings: {
            anchorClickable: true, // Enable/Disable anchor navigation
            enableAllAnchors: true, // Activates all anchors clickable all times
            markDoneStep: true, // add done css
            enableAnchorOnDoneStep: true // Enable/Disable the done steps navigation
        },
    });    

    // Set selected theme on page refresh
    $("#smartwizard").on("leaveStep", function(e, anchorObject, stepNumber, stepDirection) {
        console.log('step '+stepNumber+' Leaved');
        return true;
    });

    setTimeout(function () {
        $(".sw-btn-next, .sw-btn-prev").click(function () {
            $("html, body").animate({scrollTop: 0}, "slow");
            return false;
        });
    }, 500);
    if($('#csectionID').val()==''){
        $('.baby_in_utero,.previous_caesarean_section,.special_care').hide();
    }
    $('.selectpicker').selectpicker('refresh');

    $('#doa').blur(function(){
        if($('#docs').val()!=''){
            var doa=$('#doa').val().split('-');
            var docs=$('#docs').val().split('-');
            var d1 = new Date(doa[2],doa[1],doa[0]);
            var d2 = new Date(docs[2],docs[1],docs[0]);
            if(d1.getTime()>d2.getTime()){
                swal('Date of admission should be less than Date of delivery by CS');
            }
        }        
    });
    $('#docs').blur(function(){
        if($('#doa').val()!=''){
            var doa=$('#doa').val().split('-');
            var docs=$('#docs').val().split('-');
            var d1 = new Date(docs[2],docs[1],docs[0]);
            var d2 = new Date(doa[2],doa[1],doa[0]);
            if(d1.getTime()<d2.getTime()){
                swal('Date of delivery by CS should be less than Date of admission');
            }
        }        
    });


});

function save_data(saveType) {
    if(saveType=='all'){
        $('input,select').parents(".form-group").removeClass('has-error');
        var blankInput=$('#smartwizard input').not('#baby_in_utero,#transferred_facility,#caesarean_sections_count,#csectionID').filter(function(){
            return ($.trim($(this).val())=='' && $(this).attr("name"));
        });
        if(parseInt(blankInput.length)>0){
            $.each(blankInput,function(idx,val){
                $(this).parents(".form-group").addClass('has-error');
            });
            swal('please fill all fields');
            return false;
        }
        var blankSelect=$('#smartwizard select').filter(function(){
            return $(this).val()=='';
        });
        if(parseInt(blankSelect.length)>0){
            $.each(blankSelect,function(idx,val){
                $(this).parents(".form-group").addClass('has-error');
            });
            swal('please fill all fields');
            return false;
        }        
        if($('#previous_caesarean_section').val()=='1'){
            if(parseInt($('#caesarean_sections_count').val())>0){
                $('#previous_caesarean_section').parents(".form-group").removeClass('has-error');
            } else {
                $('#previous_caesarean_section').parents(".form-group").addClass('has-error');
                return false;
            }
        } else {
            $('#caesarean_sections_count').val('0');
        }
        // check for input all filled
    }

    if(saveType=='all'){
        swal({
            title: "Do you really want to submit the assessment ?",
            text: "Please have a re-look before submission. Once submission is done, information can't be edited. ",
            buttons: true,
            dangerMode: true,           
        }).then((willDelete) => {
            if (willDelete) {
                save_cont(saveType);
                console.log('saved');
            } else {
                console.log('cancled');
            }
        });        
    } else {
        save_cont(saveType);
        console.log('Draft Button clicked');
    }

}

function save_cont(saveType){
    var formData = new FormData();
    $('#smartwizard input,select').each(function(){
        //if($(this).val()!=''){
            if($(this).attr('type')=='file'){
                formData.append($(this).attr('name'), $(this)[0].files[0]);
            } else {
                formData.append($(this).attr('name'), $(this).val());
            }            
        //}

    });
    formData.append('saveType', saveType);
    formData.append('csrf_token', $.cookie("csrf_cookie"));
    
    $.ajax({
        url: pageMainUrl+"ApiAudit/save_csection",
        data: formData, 
        type: 'POST', 
        dataType: 'json', 
        cache: false,
        contentType: false,
        processData: false,
        success: function(result){
            if(result.hasOwnProperty('csectionID')){
              $('#csectionID').val(result.csectionID);
            }            
            swal(result.msg).then((value) => {
                if(saveType=='all' && result.code=='0'){
                    window.location.replace(pageMainUrl + 'audit/index');
                } else {
                    //window.location.replace(window.location.href);
                }
            });
        }
    });

}
function baby_in_utero(ths){
    if($(ths).val()=='1'){
        $('.baby_in_utero').show();
    } else {
        $('.baby_in_utero').hide();
        $('.baby_in_utero input').val('');
    }

}
function previous_caesarean_section(ths){
    if($(ths).val()=='1'){
        $('.previous_caesarean_section').show();
    } else {
        $('.previous_caesarean_section').hide();
        $('.previous_caesarean_section input').val('');
    }

}
function special_care(ths){
    if($(ths).val()=='1'){
        $('.special_care').show();
    } else {
        $('.special_care').hide();
        //$('.special_care select').val('');
    }

}