
$(document).ready(function () {

    $("#smartwizard").on("showStep", function (e, anchorObject, stepNumber, stepDirection, stepPosition) {
        if (stepPosition === 'first') {
            $("#prev-btn").addClass('disabled');
        } else if (stepPosition === 'final') {
            $("#next-btn").addClass('disabled');
        } else {
            $("#prev-btn").removeClass('disabled');
            $("#next-btn").removeClass('disabled');
        }
    });

    // Toolbar extra buttons

    var btnPreview = $('<button></button>').text('Preview')
            .addClass('btn btn-info btnPreview')
            .on('click', function () {
                preview_data();
            });

    // Smart Wizard
    $('#smartwizard').smartWizard({
        selected: 0,
        theme: 'default',
        transitionEffect: 'fade',
        labelFinish: 'Finish',
        showStepURLhash: false,
        keyNavigation: false,
        toolbarSettings: {toolbarPosition: 'both',
            toolbarButtonPosition: 'end',
            toolbarExtraButtons: []
        },
        anchorSettings: {
            anchorClickable: true, // Enable/Disable anchor navigation
            enableAllAnchors: true, // Activates all anchors clickable all times
            markDoneStep: true, // add done css
            enableAnchorOnDoneStep: true // Enable/Disable the done steps navigation
        },
    });    

    // Set selected theme on page refresh
    $("#smartwizard").on("leaveStep", function(e, anchorObject, stepNumber, stepDirection) {
        console.log('step '+stepNumber+' Leaved');
        return true;
    });

    setTimeout(function () {
        $(".sw-btn-next, .sw-btn-prev").click(function () {
            $("html, body").animate({scrollTop: 0}, "slow");
            return false;
        });
    }, 500);



});

