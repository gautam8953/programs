$(document).ready(function(){

    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['ansId']=$('#ansId').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/assesmentDataView', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#facilityName').text(result.data.FacilityName);
            $('#assessmentDate').text(result.data.AssessmentDate);
            $('#assessorsName1').text(result.data.AssessorsName1);
            $('#assessorsName2').text(result.data.AssessorsName2);
            $('#assesseesName1').text(result.data.AssesseesName1);
            $('#assesseesName2').text(result.data.AssesseesName2);
            $('#assessmentType').text(result.data.AssessmentType);
            $('#submissionDate').text(result.data.start_date);
            $('#facilityAvailable').text(result.data.FacilityAvailable);
            $('#sequence').text(result.data.Sequence);
            $('#assesment').attr('data-type',result.survey);
        }
    });
    $('#assesment').click(function(){
        if($('#assesment').attr('data-type')!=''){
            var redirectUrl=pageMainUrl+'facility'+'/'+$('#assesment').attr('data-type')+'/'+$('#ansId').val();
            window.location.replace(redirectUrl);
        }        
    });

});

