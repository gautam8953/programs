$(document).ready(function(){
  // Step show event
  $("#smartwizard").on("showStep", function(e, anchorObject, stepNumber, stepDirection, stepPosition) {
     if(stepPosition === 'first'){
         $("#prev-btn").addClass('disabled');
     } else if(stepPosition === 'final'){
         $("#next-btn").addClass('disabled');
     } else{
         $("#prev-btn").removeClass('disabled');
         $("#next-btn").removeClass('disabled');
     }
  });
  // Smart Wizard
  $('#smartwizard').smartWizard({
          selected: 0,
          theme: 'default',
          transitionEffect:'fade',
          labelFinish:'Finish',
          showStepURLhash: false,
          toolbarSettings: {toolbarPosition: 'both',
                            toolbarButtonPosition: 'end',
                            toolbarExtraButtons: []
                          },
                          anchorSettings: {
                anchorClickable: true, // Enable/Disable anchor navigation
                enableAllAnchors: true, // Activates all anchors clickable all times
                markDoneStep: true, // add done css
                enableAnchorOnDoneStep: true // Enable/Disable the done steps navigation
            },
  });
  //$(".sw-toolbar-top").remove();

	var params={};
	params['device']='web';
  params['csrf_token']=$.cookie("csrf_cookie");
	params['survey']='1';
	params['ansId']=$('#ansId').val();
	$.ajax({
		url: pageMainUrl+'ApiFacility/questionsAns', 
		data: params, 
		type: 'POST', 
		dataType: 'json', 
		success: function(result){
      if(result.data.surveyStatus=='0'){
        window.location.href=pageMainUrl+'facility/labourFacility/'+$('#ansId').val();
        //$('.saveBtn').attr('disabled',true);
        //$('.draftBtn').attr('disabled',true);
      }
			if(result.data.category){
				$.each(result.data.category,function(index,dataVal){
					$.each(dataVal.questions,function(indexQues,valQues){
						$('#answer_'+indexQues).text(valQues);
					});					
				})
			}
		}
	});
	
});