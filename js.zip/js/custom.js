
/* theme changes */


$(".theme-collapse-btn").click(function(){
	$(".color-theme").toggleClass("show");
});

 $('document').ready(function(){
  
 
  if(getCookie("bgcolor") !=""){
     $('#bg-color').addClass(getCookie("bgcolor"));
  }
  $(color1).click(function(){
    
   $('#bg-color').addClass("red");
   $('#bg-color').removeClass("white");
   $('#bg-color').removeClass("grey");
   $('#bg-color').removeClass("pink");
   $('#bg-color').removeClass("green");
   $('#bg-color').removeClass("orange");
   setCookie("bgcolor", "red", 7);
  
   //$('.logo-img').attr('src','http://demosl56.rvsolutions.in/csir-iip/website-iip/iih-and-training/wp-content/uploads/sites/54/2018/06/micrologo.png');
   //$('.logo-img').attr('src','');
   $('.right-logo-img').attr('src','');
 });
 
  $(color2).click(function(){
     $('#bg-color').addClass("white");
     $('#bg-color').removeClass("red");
     $('#bg-color').removeClass("grey");
     $('#bg-color').removeClass("pink");
     $('#bg-color').removeClass("green");
     $('#bg-color').removeClass("orange");
     setCookie("bgcolor", "white", 7);
     //$('.logo-img').attr('src','http://demosl56.rvsolutions.in/csir-iip/website-iip/iih-and-training/wp-content/uploads/sites/54/2018/06/micrologo.png');
     $('.right-logo-img').attr('src','');
 });
 $(color3).click(function(){
     $('#bg-color').addClass("pink");
     $('#bg-color').removeClass("red");
     $('#bg-color').removeClass("white");
     $('#bg-color').removeClass("grey");
     $('#bg-color').removeClass("green");
     $('#bg-color').removeClass("orange");
     setCookie("bgcolor", "pink", 7);
     //$('.logo-img').attr('src','http://demosl56.rvsolutions.in/csir-iip/website-iip/iih-and-training/wp-content/uploads/sites/54/2018/06/micrologo.png');
     $('.right-logo-img').attr('src','');
 });
 $(color4).click(function(){
     $('#bg-color').addClass("grey");
     $('#bg-color').removeClass("red");
     $('#bg-color').removeClass("white");
     $('#bg-color').removeClass("pink");
     $('#bg-color').removeClass("green");
     $('#bg-color').removeClass("orange");
     setCookie("bgcolor", "grey", 7);
     //$('.logo-img').attr('src','http://demosl56.rvsolutions.in/csir-iip/website-iip/iih-and-training/wp-content/uploads/sites/54/2018/06/micrologo.png');
     $('.right-logo-img').attr('src','');
 });



  });

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires+"; path=/";
} 
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
}

/* theme changes ended */



var speed = 5000;
canTick = true;

$(document).ready(function() {
	$('.ticker-container ul div').each(function(i) {
		if ($(window).width() >= 500) {
			$(this).find('li').width($(window).width() - parseInt($(this).css('left')));
		}
		if (i == 0) {
			$(this).addClass('ticker-active');
		} else {
			$(this).addClass('not-active');
		}
		if ($(this).find('li').height() > 30) {
			$(this).find('li').css({
				'height': '20px',
				'width': '200%',
				'text-align': 'left',
				'padding-left': '5px'
			});
			$(this).find('li').css('width', $(this).find('li span').width());
		}
	});
	startTicker();
	animateTickerElementHorz();
	$('[data-toggle="tooltip"]').tooltip();

	$('#logout').click(function(){
		var params={};
		params['device']='web';
		params['csrf_token']=$.cookie("csrf_cookie");
		$.ajax({
			url: pageMainUrl+'ApiUser/logout', 
			data: params, 
			type: 'POST', 
			dataType: 'json', 
			success: function(result){
        		window.location.href = pageMainUrl+"user/index";
    		}
    	});
	});

	$('.ticker-container').on('mouseover', function() {
		canTick = false;
	});

	$('.ticker-container').on('mouseout', function() {
		canTick = true;
	});

	$('#playButton').click(function () {
	    $('#carousel-example-generic').carousel('cycle');
		$(this).hide();
		$("#pauseButton").show();
		
	});
	$('#pauseButton').click(function () {
	    $('#carousel-example-generic').carousel('pause');
		$(this).hide();
		$('#playButton').show();
	});

	$('.datepicker').datetimepicker({format: 'DD-MM-YYYY'});

	$('.datetimepicker').datetimepicker({
     format:'DD/MM/YYYY HH:mm:ss',
}).datetimepicker('show');

    $('.datemonth').datetimepicker({
        viewMode: 'years',
        format: 'MM-YYYY'
    }).on("dp.update", function (e) {
            changeDate(this);
        });;	

	$(".nums").keypress(function (e) {
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        	//$(this).next('div').text("Digits Only").show().fadeOut("slow");
            return false;
    	}
   	});
	$(".nums").keyup(function (e) {
        if(this.hasAttribute('data-max')){
            console.log($(this).val());
            if(parseFloat($(this).val())>parseFloat($(this).attr('data-max'))){
                $(this).val('');
                return false;
            }
        }
        if(this.hasAttribute('data-min')){
            if(parseFloat($(this).val())<parseFloat($(this).attr('data-min'))){
                $(this).val('');
                return false;
            }
        }

   });
	$('.emailID').blur(function(){
		var email=$(this).val();
		var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if(!regex.test(email)){
			$(this).val('');
			swal('Invalid Email-ID');
		}
	})

});

$(window).resize(function() {
	$('.ticker-container ul div').each(function(i) {
		if ($(this).find('li').height() > 30) {
			$(this).css({
				'height': '20px',
				'width': '200%',
				'text-align': 'left',
				'padding-left': '5px'
			});
			$(this).find('li').css('width', $(this).find('li span').width());
		}
	});
});

function startTicker() {
	setInterval(function() {
		if (canTick) {
			$('.ticker-container ul div.ticker-active')
				.removeClass('ticker-active')
				.addClass('remove');
			if ($('.ticker-container ul div.remove').next().length) {
				$('.ticker-container ul div.remove')
					.next()
					.addClass('next');
			} else {
				$('.ticker-container ul div')
					.first()
					.addClass('next');
			}
			$('.ticker-container ul div.next')
				.removeClass('not-active next')
				.addClass('ticker-active');
			setTimeout(function() {
				$('.ticker-container ul div.remove')
					.css('transition', '0s ease-in-out')
					.removeClass('remove')
					.addClass('not-active finished');
				if ($(window).width() < 500) {
					if ($('.ticker-container ul div.finished li').width() < $(window).width()) {
						$('.ticker-container ul div.finished').removeClass('finished');
					}
				} else {
					if ($('.ticker-container ul div.finished li').width() < ($(window).width() - (parseInt($('.ticker-container ul div.ticker-active').css('left')) + 15))) {
						$('.ticker-container ul div.finished').removeClass('finished');
					}
				}
				setTimeout(function() {
					$('.ticker-container ul div')
						.css('transition', '0.25s ease-in-out');
				}, 75);
				animateTickerElementHorz();
			}, 250);
		}
	}, speed);
}

function animateTickerElementHorz() {
	if ($(window).width() < 500) {
		if ($('.ticker-container ul div.ticker-active li').width() > $(window).width()) {
			setTimeout(function() {
				$('.ticker-container ul div.ticker-active li').animate({
					'margin-left': '-' + (($('.ticker-container ul div.ticker-active li').width() - $(window).width()) + 15)
				}, speed - (speed / 5), 'swing', function() {
					setTimeout(function() {
						$('.ticker-container ul div.finished').removeClass('finished').find('li').css('margin-left', 0);
					}, ((speed / 5) / 2)); 
				});
			}, ((speed / 5) / 2));
		}
	} else {
		if ($('.ticker-container ul div.ticker-active li').width() > ($(window).width() - parseInt($('.ticker-container ul div.ticker-active').css('left')))) {
			setTimeout(function() {
				$('.ticker-container ul div.ticker-active li').animate({
					'margin-left': Math.abs($('.ticker-container ul div.ticker-active li').width() - ($(window).width() - parseInt($('.ticker-container ul div.ticker-active').css('left'))) + 15) * -1
				}, speed - (speed / 5), 'swing', function() {
					setTimeout(function() {
						$('.ticker-container ul div.finished').removeClass('finished').find('li').css('margin-left', 0);
					}, ((speed / 5) / 2)); 
				});
			}, ((speed / 5) / 2));
		}
	}
}

function pageRedirect(ths){
	window.location.href = $(ths).attr('data-href');
}
function pageReplace(ths){
	window.location.replace($(ths).attr('data-href'));
}


