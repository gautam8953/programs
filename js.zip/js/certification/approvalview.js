
$(document).ready(function () {

    $("#smartwizard").on("showStep", function (e, anchorObject, stepNumber, stepDirection, stepPosition) {
        if (stepPosition === 'first') {
            $("#prev-btn").addClass('disabled');
            $('.btnPreview').hide();
            $('.saveBtn').hide();
        } else if (stepPosition === 'final') {
            $("#next-btn").addClass('disabled');
            $('.btnPreview').hide();
            $('.saveBtn').show();
        } else {
            $("#prev-btn").removeClass('disabled');
            $("#next-btn").removeClass('disabled');
            $('.btnPreview').hide();
            $('.saveBtn').hide();
        }
    });

    // Toolbar extra buttons
    var btnSaveQues = $('<button></button>').text('Submit')
            .addClass('btn btn-success saveBtn')
            .on('click', function () {
                save_data('all');
            });

    var btnDraftQues = $('<button></button>').text('Save as Draft')
            .addClass('btn btn-info draftBtn')
            .on('click', function () {
                save_data('draft');
            });

    var btnPreview = $('<button></button>').text('Preview')
            .addClass('btn btn-info btnPreview')
            .on('click', function () {
                preview_data();
            });

    // Smart Wizard
    $('#smartwizard').smartWizard({
        selected: 0,
        theme: 'default',
        transitionEffect: 'fade',
        labelFinish: 'Finish',
        showStepURLhash: false,
        keyNavigation: false,
        toolbarSettings: {toolbarPosition: 'both',
            toolbarButtonPosition: 'end',
            //toolbarExtraButtons: [btnPreview,btnSaveQues]
        },
        anchorSettings: {
            anchorClickable: true, // Enable/Disable anchor navigation
            enableAllAnchors: true, // Activates all anchors clickable all times
            markDoneStep: true, // add done css
            enableAnchorOnDoneStep: true // Enable/Disable the done steps navigation
        },
    });    

    // Set selected theme on page refresh
    $("#smartwizard").on("leaveStep", function(e, anchorObject, stepNumber, stepDirection) {
        console.log('step '+stepNumber+' Leaved');
        return true;
    });

    setTimeout(function () {
        $(".sw-btn-next, .sw-btn-prev").click(function () {
            $("html, body").animate({scrollTop: 0}, "slow");
            return false;
        });
    }, 500);



});

function save_data(saveType) {
    if(saveType=='all'){
        // check for input all filled
    }

    if(saveType=='all'){
        swal({
            title: "Do you really want to submit the form ?",
            text: "Please have a re-look before submission.  ",
            buttons: true,
            dangerMode: true,           
        }).then((willDelete) => {
            if (willDelete) {
                save_cont(saveType);
                console.log('saved');
            } else {
                console.log('cancled');
            }
        });        
    } else {
        save_cont(saveType);
        console.log('Draft Button clicked');
    }

}


function save_cont(saveType){
    var formData = new FormData();
    $('#smartwizard input').each(function(){
        //if($(this).val()!=''){
            if($(this).attr('type')=='file'){
                formData.append($(this).attr('name'), $(this)[0].files[0]);
            } else {
                formData.append($(this).attr('name'), $(this).val());
            }            
        //}

    });
    formData.append('saveType', saveType);
    
    $.ajax({
        url: pageMainUrl+"ApiCertification/save",
        data: formData, 
        type: 'POST', 
        dataType: 'json', 
        cache: false,
        contentType: false,
        processData: false,
        success: function(result){
            if(result.hasOwnProperty('CertificationID')){
              $('#CertificationID').val(result.CertificationID);
            }            
            swal(result.msg).then((value) => {
                if(saveType=='all' && result.code=='0'){
                    window.location.replace(pageMainUrl + 'certification/index');
                } else {
                    //window.location.replace(window.location.href);
                }
            });
        }
    });

}