$(document).ready(function () {
    if($('#search_typeMain').val()=='State'){
        $('#search_type').html('<option value="State">State Certification</option><option value="National">National Certification</option>');                        
    } else {
        $('#search_type').html('<option value="National">National Certification</option><option value="State">State Certification</option>');
    }

    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 20,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "order": [[0, "ASC" ]],        
        "ajax": {
            url: pageMainUrl + "ApiReports/checklistData",
            type: "post",
            beforeSend: function (request) {                
                if($('#search_type').val()=='State'){
                    $('#datatable thead').html('<tr><th data-toggle="tooltip" title="SN. ">SN.</th><th style="width: 20%" data-toggle="tooltip" title="Facility ">Facility</th><th data-toggle="tooltip" title="Department">Department</th><th  data-toggle="tooltip" title="Peer Score/State Score ">Peer Score/State Score</th><th data-toggle="tooltip" title="Criterion I - Overall Score of the department (LR / OT shall be ≥70% ">Criterion I </th><th data-toggle="tooltip" title="Criterion II- Score of each Area of Concern of department (LR/OT) shall be 70% ">Criterion II </th><th colspan="3" data-toggle="tooltip" title="Criterion III- Individual scores of three core Standards (B3,E18 and E19) shall be ≥70% ">Criterion III </th><th data-toggle="tooltip" title="Criterion IV- Individual Score in each Applicable Quality Standard>60%">Criterion IV </th><th data-toggle="tooltip" title="Criterion V – Client Satisfaction of the department shall be more ≥80% ">Criterion V </th><th data-toggle="tooltip" title="Total Criterion ">Total Criterion</th></tr><tr><th></th><th></th><th></th><th></th><th></th><th></th><th>B3</th><th>E18</th><th>E19</th><th></th><th></th><th></th></tr>');
                    $('#criteria_1').text('65');
                    $('#criteria_2').text('65');
                    $('#criteria_3').text('65');
                    $('#criteria_4').text('45');
                    $('#criteria_5').text('65');

                } else {
                    $('#datatable thead').html('<tr><th data-toggle="tooltip" title="SN. ">SN.</th><th style="width: 20%" data-toggle="tooltip" title="Facility ">Facility</th><th data-toggle="tooltip" title="Department">Department</th><th  data-toggle="tooltip" title="Peer Score/State Score ">Peer Score/State Score</th><th data-toggle="tooltip" title="Criterion I - Overall Score of the department (LR / OT shall be ≥70% ">Criterion I </th><th data-toggle="tooltip" title="Criterion II- Score of each Area of Concern of department (LR/OT) shall be 70% ">Criterion II </th><th colspan="3" data-toggle="tooltip" title="Criterion III- Individual scores of three core Standards (B3,E18 and E19) shall be ≥70% ">Criterion III </th><th data-toggle="tooltip" title="Criterion IV- Individual Score in each Applicable Quality Standard>60%">Criterion IV </th><th data-toggle="tooltip" title="Criterion V – Client Satisfaction of the department shall be more ≥80% ">Criterion V </th><th data-toggle="tooltip" title="Total Criterion ">Total Criterion</th></tr><tr><th></th><th></th><th></th><th></th><th></th><th></th><th>B3</th><th>E18</th><th>E19</th><th></th><th></th><th></th></tr>');
                    $('#criteria_1').text('70');
                    $('#criteria_2').text('70');
                    $('#criteria_3').text('70');
                    $('#criteria_4').text('50');
                    $('#criteria_5').text('70');
                }
            },
            data: function (d) {
                $("#bodyLoad").removeClass('loader');
                $("#loader_overlay").hide();
                d.search_type = $('#search_type').val();
                d.search_state = $('#search_state').val();
                d.search_district = $('#search_district').val();
                d.search_facility = $('#search_facility').val();
                d.search_typeFacility = $('#search_typeFacility').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        }
    });

    $('#btn_search').click(function () {
        datatableData.ajax.reload();
    });
    $("#reset_btn").click(function () {
        datatableData.ajax.reload();
    });

    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl + 'ApiUser/roleData',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (result.code=='0') {
                if(result.data.role=='Ministry'){

                } else if(result.data.role=='State'){

                } else if(result.data.role=='District'){
                    $('#search_state').closest('div').hide();
                } else {
                    $('#search_state').closest('div').hide();
                    $('#search_district').closest('div').hide();
                    $('#search_facility').closest('div').hide();
                    //$('.searchDiv').hide();
                }
                if (result.data.hasOwnProperty('District') && parseInt($('#search_district').length) > 0) {
                    $('#search_district').html('<option value="">Select District</option>');
                    $.each(result.data.District, function (key, val) {
                        $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                    });
                    if ($('#search_district').length) {
                        if (parseInt($('#search_district option').length) == 2) {
                            $('#search_district').val($('#search_district option:eq(1)').val());
                            datatableData.ajax.reload();
                            change_district1();
                        }
                    }
                }
                if (result.data.hasOwnProperty('State') && parseInt($('#search_state').length) > 0) {
                    $('#search_state').html('<option value="">Select State</option>');
                    $.each(result.data.State, function (key, val) {
                        $('#search_state').append($("<option></option>").attr("value", val.StateID).text(val.StateName));
                    });
                    if ($('#search_state').length) {
                        if (parseInt($('#search_state option').length) == 2) {
                            $('#search_state').val($('#search_state option:eq(1)').val());
                            change_state();
                        }
                    }
                }

            }
        }
    });

});

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="">Select District</option>');
            if (result.hasOwnProperty('data')) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }            
        }
    });
    $('#btn_search').trigger('click');
}

function change_district() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'facility';
    params['searchData'] = $('#search_district').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_facility').html('<option value="">Select Facility</option>');
            if (result.data) {
                if (parseInt(result.data.length) > 0) {
                    $.each(result.data, function (key, val) {
                        $('#search_facility').append($("<option></option>").attr("value", val.UserID).text(val.FacilityName));
                    });                    
                }
            }
        }
    });
    $('#btn_search').trigger('click');
}

function change_facility(){
    $('#btn_search').trigger('click');
}
function change_district1() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'facility';
    params['searchData'] = $('#search_district').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_facility').html('<option value="">Select Facility</option>');
            if (result.data) {
                if (parseInt(result.data.length) > 0) {
                    $.each(result.data, function (key, val) {
                        $('#search_facility').append($("<option></option>").attr("value", val.UserID).text(val.FacilityName));
                    });
                }
            }
        }
    });
}