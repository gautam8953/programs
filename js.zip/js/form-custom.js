////////////////////////////// wizard ///////////////////////////



$(document).ready(function () {



    // Step show event
    $("#smartwizard").on("showStep", function (e, anchorObject, stepNumber, stepDirection, stepPosition) {
        if (stepPosition === 'first') {
            $("#prev-btn").addClass('disabled');
            /*$(".draftBtn").removeClass('saveBtn');
            $('.draftBtn').text('Save as Draft');*/
            $('.btnPreview').hide();
            $('.saveBtn').hide();
        } else if (stepPosition === 'final') {
           /* $(".draftBtn").addClass('saveBtn');
            $('.draftBtn').text('Save');*/
            $("#next-btn").addClass('disabled');
            $('.btnPreview').show();
            $('.saveBtn').show();
        } else {
            /*$(".draftBtn").removeClass('saveBtn');
            $('.draftBtn').text('Save as Draft');*/
            $("#prev-btn").removeClass('disabled');
            $("#next-btn").removeClass('disabled');
            $('.btnPreview').hide();
            $('.saveBtn').hide();
        }
    });




    // Toolbar extra buttons
    var btnSaveQues = $('<button></button>').text('Submit')
            .addClass('btn btn-success saveBtn')
            .on('click', function () {
                //$('#smartwizard').smartWizard("reset");
                save_data('all');
            });

    var btnDraftQues = $('<button></button>').text('Save as Draft')
            .addClass('btn btn-info draftBtn')
            .on('click', function () {
                save_data('draft');
            });

    var btnPreview = $('<button></button>').text('Preview')
            .addClass('btn btn-info btnPreview')
            .on('click', function () {
                preview_data();
            });

    // Smart Wizard
    $('#smartwizard').smartWizard({
        selected: 0,
        theme: 'default',
        transitionEffect: 'fade',
        labelFinish: 'Finish',
        showStepURLhash: false,
        keyNavigation: false,
        toolbarSettings: {toolbarPosition: 'both',
            toolbarButtonPosition: 'end',
            toolbarExtraButtons: [btnDraftQues,btnPreview,btnSaveQues]
        },
        anchorSettings: {
            anchorClickable: true, // Enable/Disable anchor navigation
            enableAllAnchors: true, // Activates all anchors clickable all times
            markDoneStep: true, // add done css
            enableAnchorOnDoneStep: true // Enable/Disable the done steps navigation
        },
    });

    //$(".sw-toolbar-top").remove();

    // Set selected theme on page refresh

    $("#smartwizard").on("leaveStep", function(e, anchorObject, stepNumber, stepDirection) {
        if(stepNumber=='0'){ 
            var check=assessmentSave();
            if(check=='0'){
                return false
            }
        }
        return true;
    });
    $('.quote1-full input[type=radio]').click(function () {
        $(this).closest('.quote1-full').removeClass('has-error');
        $(this).closest('.quote1-full').removeClass('ansCleared');
        $(this).closest('.quote1-full').find('.uncheckRadio:first').show();
        $(this).closest('.quote1-full').addClass('autosave');
        //autosave(this);
    });
    $('.quote1-full .uncheckRadio').click(function () {
        $(this).closest('.quote1-full').find('input[type=radio]').prop('checked', false);
        $(this).closest('.quote1-full').addClass('ansCleared');
        $(this).hide();
        autosave(this);
    });

    setTimeout(function () {
        $(".sw-btn-next, .sw-btn-prev").click(function () {

            $("html, body").animate({scrollTop: 0}, "slow");
            return false;
        });

    }, 500);

    $('#previewModal').on('hide.bs.modal', function (e) {
      $('#previewModal').find('.modal-body').html('');
    });

    $('#previewModal').on('show.bs.modal', function () {
        $('.modal .modal-body').css('overflow-y', 'auto'); 
        $('.modal .modal-body').css('max-height', $(window).height() * 0.7);
    });

    setInterval(function(){ 
        if($('#ansId').val()!=''){
            var saveData=$('.autosave');
            if(parseInt(saveData.length)>0){
                $(saveData).each(function(){
                    var radObj=$(this).find('input[type="radio"]:checked');
                    if(radObj.length=='1'){
                      autosave(radObj);
                    }                
                });                
            $.notify("Saved successfully", "success");
            }            
        }
    }, 60000);

});

function save_data(saveType) {
    /*if ($('.draftBtn').hasClass('saveBtn')) {
        var saveType = 'all';
    } else {
        var saveType = 'draft';
    }*/
    //if($('#ansId').val()==''){
        var check=assessmentSave();
        if(check=='0'){
            swal('Error saving data, Please try again');
            $('.draftBtn').prop('disabled', false);
            $('.saveBtn').prop('disabled', false);
        }        
        //return false
    //}
    $('.draftBtn').prop('disabled', true);
    $('.saveBtn').prop('disabled', true);
    var params = {};
    if (saveType == 'all') {
        var radioCheck = '0';
        $('[id^=step-]').each(function () {
            var cat = $(this).attr('id');
            var catCheeck = '0';
            if(cat=='step-0'){                
            } else {
                $.each($("#" + cat + " .quote1-full2"), function (index, elem) {
                    if (parseInt($(elem).find('input[type=radio]:checked').length) == 0) {
                        $(elem).addClass('has-error');
                        radioCheck = '1';
                        catCheeck = '1';
                    } else {
                        $(elem).removeClass('has-error');
                    }
                });
            }
            if (catCheeck != '0') {
                $('#smartwizard a[href="#' + cat + '"]').attr('style', 'color: #ffb3b3 !important');
            } else {
                $('#smartwizard a[href="#' + cat + '"]').attr('style', 'color: #ffffff !important');
            }
        });

        if (radioCheck != '0') {
            swal('Please fill all questions');
            $('.draftBtn').prop('disabled', false);
            $('.saveBtn').prop('disabled', false);
            return false;
        } else {
            var check='1';
            if($('#sequence').val()=='' || $('#sequence').val()=='0'){
              $('#sequence').closest('.form-group').addClass('has-error');
              check='0';
            } else {
              $('#sequence').closest('.form-group').removeClass('has-error');
            }
            if($('#assessmentDate').val()=='' || $('#assessmentDate').val()=='undefined'){
              $('#assessmentDate').closest('.form-group').addClass('has-error');
              check='0';
            } else {
              params['assessmentDate']=$('#step-0 #assessmentDate').val();
              $('#assessmentDate').closest('.form-group').removeClass('has-error');
            }
            if($.trim($('#assessorsName1').val())=='' || $('#assessorsName1').val()=='undefined'){
              $('#assessorsName1').closest('.form-group').addClass('has-error');
              check='0';
            } else {
              params['assessorsName1']=$('#step-0 #assessorsName1').val();
              $('#assessorsName1').closest('.form-group').removeClass('has-error');
            }
            if($.trim($('#assesseesName1').val())=='' || $('#assesseesName1').val()=='undefined'){
              $('#assesseesName1').closest('.form-group').addClass('has-error');
              check='0';
            } else {
              params['assesseesName1']=$('#step-0 #assesseesName1').val();
              $('#assesseesName1').closest('.form-group').removeClass('has-error');
            }
            if(check!='1'){
                swal('Please fill all fields');
                $('#smartwizard a[href="#step-0"]').attr('style', 'color: #ffb3b3 !important');
                $('.draftBtn').prop('disabled', false);
                $('.saveBtn').prop('disabled', false);
                return false;
            } else {
                params['status'] = 'save';
                swal({
                    title: "Do you really want to submit the assessment ?",
                    text: "Please have a re-look before submission. Once submission is done, information can't be edited. ",
                   // icon: "warning",
                   
                    buttons: true,
                    dangerMode: true,
                   
                }).then((willDelete) => {
                    if (willDelete) {
                        params['status'] = 'save';
                        save_continue(params);
                    } else {
                        params['status'] = 'draft';
                        //save_continue(params);
                        $('.draftBtn').prop('disabled', false);
                        $('.saveBtn').prop('disabled', false);
                    }
                });                
            }

        }
    } else {
        params['status'] = 'draft';
        save_continue(params);
    }

}

function save_continue(params) {
    var checkedAns = $('.sw-container input[type=radio]:checked');
    var clearedAns = $('.sw-container .ansCleared').find('input[type=radio]:first');
    var ansData = {};
    var ansDataCleared = {};
    if (parseInt(checkedAns.length) > 0) {
        $.each(checkedAns, function (index, elem) {
            var ques = $(elem).attr('id');
            var ans = $(elem).val();
            ansData[ques] = ans;
        });
    }
    if (parseInt(clearedAns.length) > 0) {
        $.each(clearedAns, function (index, elem) {
            var ques = $(elem).attr('id').split('_');
            ansDataCleared[ques[1]] = ques[1];
        });
    }
    params['survey'] = $('#SurveyID').val();
    params['ansId'] = $('#ansId').val();
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['answer'] = ansData;
    params['answerCleared'] = ansDataCleared;
    $.ajax({
        url: pageMainUrl + 'ApiFacility/saveAns',
        data: params,
        type: 'POST',
        dataType: 'json',
        beforeSend: function() {
            $("#bodyLoad").addClass('loader');
            $("#loader_overlay").show();
        },
        success: function (result) {
            $("#bodyLoad").removeClass('loader');
            $("#loader_overlay").hide();
            if (parseInt(result.code) == 0) {
                swal(result.msg).then((value) => {
                    $('.draftBtn').prop('disabled', false);
                    $('.saveBtn').prop('disabled', false);
                    if (result.status == 'save') {
                        window.location.replace(pageMainUrl + 'facility/score/' + result.ansId);
                    } else {
                        //window.location.replace(window.location.href);
                    }
                });

            }
        }
    });
}

function preview_data(){
    $('[id^="step-"]:not(#step-0)').each(function(){
        var ids=$(this).attr('id');
        var headingText=$('#smartwizard a[href="#'+ids+'"]').text();
        var html=$('#'+ids).clone();
        $(html).find('.quote-top-bar').html('<h2>'+headingText+'</h2>');
        $.each($(html).find('.quote-1-option'),function(key,obj){
            var radioname=$(obj).find('input:first').attr('name');
            var ans=$('#smartwizard input[name="'+radioname+'"]:checked').val()||'';
            $(obj).html('<span>'+ans+'</span>');
        });
        $('#previewModal').find('.modal-body').append(html);
    });
    $('#previewModal [id^="step-"]').show();
    $('#previewModal.modal-content').css('height',$(window).height()*0.8);

    $('#previewModal').modal('show');
}

function autosave(ths){
    var ids=$(ths).attr('id').split('_');
    var params={};
    params['csrf_token']=$.cookie("csrf_cookie");
    if(ids[0]=='answer'){
        params['type']='save';
        params['ans']=$(ths).val();
    } else {
        params['type']='clear';
    }
    params['question']=ids[1];
    params['ansId'] = $('#ansId').val();
    if(parseInt(params['question'])>0 && params['type']!=''){
        $.ajax({
            url: pageMainUrl + 'ApiFacility/checklistsave',
            data: params,
            type: 'POST',
            dataType: 'json',
            success: function (result) {
                console.log(result);
                if(result.code=='0'){
                    //$.notify("Saved successfully", "success");
                    if(params['type']=='save'){
                        $(ths).closest('.quote1-full').removeClass('autosave');
                    } else {
                        $(ths).closest('.quote1-full').removeClass('ansCleared');                        
                    }
                } else {
                    //$.notify("data not saved, please try again","success",{autoHide: true,clickToHide: true,});
                }
                
            }
        });        
    }
}
function assessmentSave(){
    var check='1';
    var params = {};
    if($('#facilityName').val()=='' || $('#facilityName').val()=='undefined'){
      $('#facilityName').closest('.form-group').addClass('has-error');
      swal('Please select facility first');
      check='0';
    } else {
      params['facilityName']=$('#step-0 #facilityName').val();
      $('#facilityName').closest('.form-group').removeClass('has-error');
    }
/*    if($('#assessmentDate').val()=='' || $('#assessmentDate').val()=='undefined'){
      $('#assessmentDate').closest('.form-group').addClass('has-error');
      check='0';
    } else {
      params['assessmentDate']=$('#step-0 #assessmentDate').val();
      $('#assessmentDate').closest('.form-group').removeClass('has-error');
    }
    if($('#assessorsName1').val()=='' || $('#assessorsName1').val()=='undefined'){
      $('#assessorsName1').closest('.form-group').addClass('has-error');
      check='0';
    } else {
      params['assessorsName1']=$('#step-0 #assessorsName1').val();
      $('#assessorsName1').closest('.form-group').removeClass('has-error');
    }
    if($('#assesseesName1').val()=='' || $('#assesseesName1').val()=='undefined'){
      $('#assesseesName1').closest('.form-group').addClass('has-error');
      check='0';
    } else {
      params['assesseesName1']=$('#step-0 #assesseesName1').val();
      $('#assesseesName1').closest('.form-group').removeClass('has-error');
    }
    if($('#assessmentType').val()=='' || $('#assessmentType').val()=='undefined'){
      $('#assessmentType').closest('.form-group').addClass('has-error');
      check='0';
    } else {
      $('#assessmentType').closest('.form-group').removeClass('has-error');
    }*/
    params['assessmentDate']=$('#step-0 #assessmentDate').val();
    params['assessorsName1']=$('#step-0 #assessorsName1').val();
    params['assesseesName1']=$('#step-0 #assesseesName1').val();

    params['sequence']=$('#step-0 #sequence').val();
    params['assessorsName2']=$('#step-0 #assessorsName2').val();
    params['assesseesName2']=$('#step-0 #assesseesName2').val();
    params['assessment']=$('#step-0 #assessment').val();
    params['submissionDate']=$('#step-0 #submissionDate').val();
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['SurveyID']=$('#SurveyID').val();
    params['ansId'] = $('#ansId').val();
    if(check=='1'){
        $.ajax({
            url: pageMainUrl+'ApiFacility/assesment', 
            data: params, 
            type: 'POST', 
            dataType: 'json',
            async: false,
            success: function(result){
                if(result.code=='0'){
                    $('#ansId').val(result.ansId);                    
                } else {

                }
            }
        });
        if($('#ansId').val()==''){
            return '0';
        } else {
            return '1';
        }        
    } else {
        return '0';        
    }
}

// 1 min 60000
/*var myVar = setInterval(myTimer, 1800000);
function myTimer() {
  swal({
    title: "save data?",
    text: "To avoid loosing data, plese save data as draft...",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      params['status']='draft';
      //save_continue(params);
    }
  });
}*/