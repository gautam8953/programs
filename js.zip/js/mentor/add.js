$(document).ready(function () {

    if ($('#search_state').length) {
        if ($('#search_state option').length == '2') {
            $('#search_state').val($('#search_state option:eq(1)').val());
            change_state();
            $('#change_state').closest('.form-group').parent().hide();
        }
    } else {
        if ($('#search_district option').length == '2') {
            $('#search_district').val($('#search_district option:eq(1)').val());
            change_district();
            $('#search_district').closest('.form-group').parent().hide();
        }
    }

    $('#uploaForms').submit(function () {

        $("#bodyLoad").addClass('loader');
        $("#loader_overlay").show();
        $(this).ajaxSubmit({
            beforeSubmit: showRequest,
            success: showResponse,
            type: 'POST',
            dataType: 'json',
            data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false;
    });

    validate_assesment();

});

function showResponse(responseText, statusText, xhr, $form) {
    $("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
    $('.errDivUpload').html('');
    $('#excelfile').val('');
    $('#uploaForms input[type="text"]').val('');
    $('#uploaForms select').not('#survey,#surveyType,#assessment,#checklist_format').val('');
    $("label[for='excelfile']").children('span').text('');
    $('.selectpicker').selectpicker('refresh');
    if(responseText.hasOwnProperty('errdesc')){
        swal(responseText.errdesc);
    } else {
        swal(responseText.msg);
    }    
    if (responseText.hasOwnProperty('err')) {
        if(parseInt(responseText.err.length)>0){
            $('.errDivUpload').append('<table id="errTableUpload"><thead><tr><th align="left">Checkpoint</th><th align="left">Compliance</th></tr></thead><tbody>');
            $.each(responseText.err, function (key, val) {
                $('#errTableUpload').append('<tr><td align="left">' + val[2] + '</td><td align="left">' + val[3] + '</td></tr>');
            });
            $('.errDivUpload').append('</tbody></table>');
        }
    }
}
function showRequest(formData, jqForm, options) {
    var check = '0';
    if($('#assessmentDate').val()==''){
        swal('Please select assessment date first');
        check = '1';
    }
    if($('#assessorsName1').val()==''){
        swal('Please enter assessors 1');
        check = '1';
    }
    if($('#assesseesName1').val()==''){
        swal('Please enter assessees 1');
        check = '1';
    }
    if(parseInt($('#search_facility').length)>0){
        if($('#search_facility').val()==''){
            swal('Please select facility');
            check = '1';
        }
    }
    if ($('#Keyfindings').val() == '') {
        swal('Please select excel file first');
        //$('#excelfile').closest('.form-group').addClass('has-error');
        check = '1';
    } else {
        var validExts = new Array(".xlsx", ".xls", ".csv");
        var fileExt = $('#Keyfindings').val();
        fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
        if (validExts.indexOf(fileExt) < 0) {
        swal('Please choose only excel file');
            $('#Keyfindings').val('');
            $("label[for='Keyfindings']").children('span').text('');
            //$('#excelfile').closest('.form-group').addClass('has-error');
            check = '1';
        } else {
            //$('#excelfile').closest('.form-group').removeClass('has-error');
        }
    }
    if (check != '0') {

        $("#bodyLoad").removeClass('loader');
        $("#loader_overlay").hide();
        return false;
    }
    return true;
}
function checkFile(fileobj) {
    var validExts = new Array(".xlsx", ".xls", ".csv");
    var fileExt = fileobj.value;
    fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
    if (validExts.indexOf(fileExt) < 0) {
        swal('Please choose only excel file');
        $('#excelfile').val('');
        $("label[for='excelfile']").children('span').text('');
        //$(fileobj).closest('.form-group').addClass('has-error');
        return false;
    } else {
        //$(fileobj).closest('.form-group').removeClass('has-error');
    }
}
function change_district() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'facility';
    params['searchData'] = $('#search_district').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_facility').html('<option value="">Select Facility</option>');
            if (result.data) {
                if (parseInt(result.data.length) > 0) {
                    $.each(result.data, function (key, val) {
                        $('#search_facility').append($("<option></option>").attr("value", val.UserID).text(val.FacilityName));
                    });
                    if ($('#search_facility').length) {
                        if (parseInt($('#search_facility option').length) == 2) {
                            $('#search_facility').val($('#search_facility option:eq(1)').val());
                            $('#btn_search').trigger('click');
                        }
                    }
                }
            }
        }
    });
}

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="">Select District</option>');
            if (parseInt(result.data.length) > 0) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
            if (parseInt($('#search_district option').length) >= 2) {
                $('#search_district').val($('#search_district option:eq(1)').val());
                change_district();
            }
            $('#search_facility').html('<option value="">Select Facility</option>');
        }
    });
}

function validate_assesment(){
     var params={};
     var search_facility=parseInt($('#search_facility').val())||0;
     var pmuName=$('#pmuName').val();
   
     params['device']='web';
     params['csrf_token']=$.cookie("csrf_cookie");
     params['search_facility']=search_facility;
    params['pmuName']=pmuName;

     $.ajax({
         url: pageMainUrl+'ApiPmu/validate_assesment', 
         data: params, 
         type: 'POST', 
         success: function(result){
             console.log(result);
         }
     });    
}