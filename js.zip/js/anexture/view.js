$(document).ready(function(){

    var anextureID=$('#anextureID').val();
    var params={};
    var urlNew=pageMainUrl+'Apianexture/anextureview/'+anextureID;
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: urlNew, 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            if(result.code=='1'){
                $('#search_state').text(result.data.search_state);
                $('#search_district').text(result.data.search_district);
                $('#facilityName').text(result.data.facilityName);
                $('#submitDate').text(result.data.submitDate);
                $('#checklist_1').text(result.data.checklist_1);
                $('#checklist_2').text(result.data.checklist_2);
                $('#checklist_3').text(result.data.checklist_3);
                $('#checklist_4').text(result.data.checklist_4);
                $('#checklist_5').text(result.data.checklist_5);
                $('#checklist_6').text(result.data.checklist_6);
                $('#checklist_7').text(result.data.checklist_7);
                $('#checklist_8').text(result.data.checklist_8);
                $('#checklist_9').text(result.data.checklist_9);
                $('#checklist_10').text(result.data.checklist_10);
                $('#checklist_11').text(result.data.checklist_11);
                $('#checklist_12').text(result.data.checklist_12);
                $('#checklist_13').text(result.data.checklist_13);
                $('#checklist_14').text(result.data.checklist_14);
                $('#checklist_15').text(result.data.checklist_15);
                $('#checklist_16').text(result.data.checklist_16);
                $('#checklist_17').text(result.data.checklist_17);
                $('#checklist_18').text(result.data.checklist_18);
                $('#checklist_19').text(result.data.checklist_19);
                $('#checklist_20').text(result.data.checklist_20);
            }
        }
    });


});

