$(document).ready(function(){

/*    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl+'ApiFacility/assesmentData', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            if(result.data.facilityName){
              $('#facilityName').html('<option value="'+result.data.facilityUser+'">'+result.data.FacilityName+'</option>');
            }
        }
    });*/

    $('#assesmentForm').submit(function() {
        $(this).ajaxSubmit({
          beforeSubmit:  showRequest,
          success: showResponse,
          type: 'POST',
          dataType: 'json',
          data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false; 
    }); 

    $('.selectpicker').selectpicker('refresh');
});

function showResponse(responseText, statusText, xhr, $form)  {
    $("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
    if(parseInt(responseText.code)==0){
      $("#msgDiv").removeClass('alert-danger');
      $("#msgDiv").addClass('alert-success').show();
    } else {
      $('#assesment').prop('disabled',false);
      $("#msgDiv").removeClass('alert-success');
      $("#msgDiv").addClass('alert-danger').show();
    }
    
    $("#LoginMsg").text(responseText.msg);
    setTimeout(function() { 
    if(parseInt(responseText.code)==0){
      window.location.href = pageMainUrl+"anexture/index";
    }
    }, 3000);

}
function showRequest(formData, jqForm, options) { 
    var check='0';
    $('#assesment').prop('disabled',true);
    if($('#submitDate').val()=='' || $('#submitDate').val()=='undefined'){
      $('#submitDate').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#submitDate').closest('.form-group').removeClass('has-error');
    }
    if(check!='0'){
      $('#assesment').prop('disabled',false);
      return false;
    }
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    return true; 
}



function change_district(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType']='facility';
    params['searchData']=$('#search_district').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/getSearchOptions', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#facilityName').html('<option value="">Select Facility</option>');
            if(result.data){
                if(parseInt(result.data.length)>0){
                    $.each(result.data,function(key,val){
                        $('#facilityName').append('<option value="'+val.UserID+'">'+val.FacilityName+'</option>');
                    });
                    $('#facilityName').selectpicker('refresh');
                }                
            }
        }
    });
}

function change_state(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType']='district';
    params['searchData']=$('#search_state').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/getSearchOptions', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#search_district').html('<option value="">Select District</option>');
            if(parseInt(result.data.length)>0){
                $.each(result.data,function(key,val){
                    $('#search_district').append($("<option></option>").attr("value",val.DistrictID).text(val.DistrictName));
                });
            }
            $('#facilityName').html('<option value="">Select Facility</option>');
        }
    });    
}

function change_facility(ths){
    $('.selectpicker').selectpicker('refresh');
}