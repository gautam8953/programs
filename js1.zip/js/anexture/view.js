$(document).ready(function(){

    var anextureID=$('#anextureID').val();
    var params={};
    var urlNew=pageMainUrl+'Apianexture/anextureview/'+anextureID;
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: urlNew, 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            if(result.code=='1'){
                $('#search_state').text(result.data.search_state);
                $('#search_district').text(result.data.search_district);
                $('#facilityName').text(result.data.facilityName);
                $('#submitDate').text(result.data.submitDate);
                $('#checklist_1').text(result.data.checklist_1);
            }
        }
    });


});

