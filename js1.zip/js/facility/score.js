
  $('document').ready(function(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['ansId']=$('#ansId').val();
    $.ajax({
      url:pageMainUrl+"ApiFacility/score",
      'data':params,
      'type':'post',
      'dataType':'json',
      'success':function(result){
        var totScore=0;
        $('#assementName').text(result.data.score[0].SurveyDesc);
        $('#totScore').prev().text(result.data.score[0].SurveyName+' Score');
        var totmarks=0;
        $.each(result.data.score,function(key,val){
          if(parseFloat(val.score)>=65){
            var classTxt='success';
          } else if(parseFloat(val.score)>=40 && parseFloat(val.score)<=65){
            var classTxt='inprocess';
          } else {
            var classTxt='faild';
          }

          $('#score tbody').append('<tr class="'+classTxt+'"><td class="text-center">'+val.CategoryCode+'</td><td class="text-center">'+val.CategoryName+'</td><td class="text-right">'+val.answer+'</td><td class="text-right">'+val.quesTot*2+'</td><td class="text-right">'+val.score+'%</td></tr>');
          totmarks=parseInt(totmarks)+parseInt(val.answer);
          totScore=parseInt(totScore)+parseInt(val.quesTot*2);
        });
        //console.log(totmarks+'_'+totScore);
        var finalScore=parseInt(parseFloat(parseInt(totmarks)/parseInt(totScore))*100);        
        if(parseFloat(finalScore)>=65){
          var classTxt='success';
        } else if(parseFloat(finalScore)>=40 && parseFloat(finalScore)<=65){
          var classTxt='inprocess';
        } else {
          var classTxt='faild';
        }
        $('#totScore').text(finalScore+'%');
        $('#totScore').closest('.rtst-bx-scr').addClass(classTxt);
        if(result.data.hasOwnProperty('standered_data')){
          $('#standardScore thead').append('<tr>');
          $.each(result.data.standered_data,function(keyCat,valCat){
            $('#standardScore thead tr').append('<th>'+valCat.CategoryCode+' - '+valCat.CategoryName+'</th>');
          });
          $('#standardScore thead').append('</tr>');
        }
        if(result.data.hasOwnProperty('standered_data')){
          $('#standardScore tbody').append('<tr>');
          $.each(result.data.standered_data,function(keyCat,valCat){
            var innerData='<table>';
            $.each(valCat.standered,function(keySubCat,valSubCat){
              if(parseFloat(valSubCat.score)>=65){
                var classTxt='success';
                var classTxt1='success1';
              } else if(parseFloat(valSubCat.score)>=40 && parseFloat(valSubCat.score)<=65){
                var classTxt='inprocess';
                var classTxt1='inprocess1';
              } else {
                var classTxt='faild';
                var classTxt1='faild1';
              }

              innerData+='<tr>';
              innerData+='<td>';

              innerData+='<table class="'+classTxt+'">';
              innerData+='<tr class="'+classTxt1+'"><th colspan="2">'+valSubCat.SubCategoryCode+'</th></tr>';
              innerData+='<tr class="'+classTxt1+'"><td>Answer:</td><td>'+valSubCat.answer+'</td></tr>';
              innerData+='<tr class="'+classTxt1+'"><td>Total:</td><td>'+(valSubCat.quesTot)*2+'</td></tr>';
              innerData+='<tr class="'+classTxt1+'"><td>Score:</td><td>'+valSubCat.score+'%</td></tr>';
              innerData+='</table>';

              innerData+='</td>';
              innerData+='</tr>';

            });
            innerData+='</table>';
            
            $('#standardScore tbody tr:first').append('<td>'+innerData+'</td>');
          });
          $('#standardScore tbody').append('</tr>');
        }
      }

    });   
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['ansId']=$('#ansId').val();
    $.ajax({
      url:pageMainUrl+"ApiFacility/scoreRemarks",
      'data':params,
      'type':'post',
      'dataType':'json',
      'success':function(result){
        if(parseInt(Object.keys(result.data).length)>0){
          $.each(result.data,function(keyData,valData){
            var count=1;
            $.each(valData,function(key,val){
              if(count=='1'){
                $('input[name="q'+val.remarksType+'[]"]').val(val.remarks);
              } else {
                addAns('q'+val.remarksType);
                $('.q'+val.remarksType+':last input[type="text"]').val(val.remarks);
              }
              count=count+1;
            });
          });
          //$('#scoreForm input[type="submit"]').attr('disabled',true);
          $('.actionDiv').hide();
          $('#scoreForm input[type="submit"]').remove();
        }
      }
    });

    $('#scoreForm').submit(function(e) {
      e.preventDefault();
    swal({
        title: "Do you really want to submit the Score ?",
        text: "Please have a re-look before submission. Once submission is done, information can't be edited. ",
       // icon: "warning",
       
        buttons: true,
        dangerMode: true,
       
    }).then((willDelete) => {
        if (willDelete) {
          $(this).ajaxSubmit({
            beforeSubmit:  showRequest,
            success: showResponse,
            type: 'POST',
            dataType: 'json',
            data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
          });
        } else {
            return false;
        }
    });



        
    });

  });
  function addAns(ques){
    $('.'+ques+':last').after($('.'+ques+':first').clone());
    $('.'+ques+':last input[type="text"]').val('');
  }
  function removeAns(ques,ths){
    $(ths).closest('.'+ques).remove();
  }
function showResponse(responseText, statusText, xhr, $form)  {
    if(parseInt(responseText.code)==0){
      $("#msgDiv").removeClass('alert-danger');
      $("#msgDiv").addClass('alert-success').show();
    } else {
      $("#msgDiv").removeClass('alert-success');
      $("#msgDiv").addClass('alert-danger').show();
    }
    
    $("#LoginMsg").text(responseText.msg);
    setTimeout(function() { 
    if(parseInt(responseText.code)==0){
      window.location.href = pageMainUrl+"facility/index";
    }
    }, 3000);

}
function showRequest(formData, jqForm, options) {     
    return true; 
}