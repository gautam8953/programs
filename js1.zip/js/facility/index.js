$(document).ready(function () {

    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 20,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "order": [[0, "desc" ]],
        "ajax": {
            url: pageMainUrl + "ApiFacility/getSearchData",
            type: "post",
            data: function (d) {
                $("#bodyLoad").removeClass('loader');
                $("#loader_overlay").hide();
                d.search_facility = $('#search_facility').val();
                d.search_district = $('#search_district').val();
                d.search_state = $('#search_state').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        drawCallback: function () {
        },
        "dom":"Blfrtip",
        buttons: [
                   {
                    extend: 'excel',
                    text: 'Export to Excel',
                    extension: '.xlsx',
                    exportOptions: {
                        columns: "thead th:not(.noExport)"
                       
                    },
                   
                  }
            ]
    });


    /*if ($('#search_state').length) {
        $('#search_state').val($('#search_state option:eq(1)').val());
        change_state();
    } else {
        $('#search_district').val($('#search_district option:eq(1)').val());
        change_district();
        if ($('#search_district option').length == '2') {
            $('#search_district').closest('div').hide();
        }
    }*/

    $('#btn_search').click(function () {
        datatableData.ajax.reload();
    });
     $("#reset_btn").click(function () {
        $('select').prop('selectedIndex', 0);
        $('.selectpicker').selectpicker('refresh');
        datatableData.ajax.reload();
    });
/*     $('#search_facility,#search_district,#search_district').change(function(){
        datatableData.ajax.reload();
     });*/
});



function getScore(ths) {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['ans'] = $(ths).attr('data-ans');
    $.ajax({
        url: pageMainUrl + 'ApiFacility/facilityScore',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (result.code == '0') {
                window.location.href = pageMainUrl + "facility/score";
            } else {

            }
        }
    });
}

function change_district() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'facility';
    params['searchData'] = $('#search_district').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        async:false,
        success: function (result) {
            $('#search_facility').html('<option value="">Select Facility</option>');
            if (result.data) {
                if (parseInt(result.data.length) > 0) {
                    $.each(result.data, function (key, val) {
                        $('#search_facility').append($("<option></option>").attr("value", val.UserID).text(val.FacilityName));
                    });
                    /*if ($('#search_facility').length) {
                        if (parseInt($('#search_facility option').length) == 2) {
                            $('#search_facility').val($('#search_facility option:eq(1)').val());
                            $('#btn_search').trigger('click');
                        }
                    }*/
                }
            }
        }
    });
    $('#btn_search').trigger('click');
}

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        async:false,
        success: function (result) {
            $('#search_district').html('<option value="">Select District</option>');
            if (result.hasOwnProperty('data') && parseInt(result.data.length) > 0) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
            /*if (parseInt($('#search_district option').length) >= 2) {
                $('#search_district').val($('#search_district option:eq(1)').val());
                change_district();
            }*/
            
            
        }
    });
    $('#search_facility').html('<option value="">Select Facility</option>');
    $('#btn_search').trigger('click');
}

function getAssesment(ths) {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['ans'] = $(ths).attr('data-ans');
    $.ajax({
        url: pageMainUrl + 'ApiFacility/facilityScore',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (result.code == '0') {
                window.location.href = pageMainUrl + "facility/assesmentData";
            } else {

            }
        }
    });
}
function getPage(ths) {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['ans'] = $(ths).attr('data-ans');
    $.ajax({
        url: pageMainUrl + 'ApiFacility/facilityScore',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (result.code == '0') {
                window.location.href = $(ths).attr('data-href');
            } else {

            }
        }
    });
}

function clientScore(ths){
    $('#assessmentID').val($(ths).attr('data-assessment'));
    $('#clientScore').val($(ths).attr('data-clientScore'));
}

function saveClientScore() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['clientScore'] = $('#clientScore').val();
    params['assessmentID'] = $('#assessmentID').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/saveClientScore',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            swal(result.msg)
            if(result.code=='0'){
                $('#clientScore').val('');
                $('#assessmentID').val('');
                $("#clientScoreModal .close").click();
                $('#btn_search').trigger('click');
            }
        }
    });
}

function change_facility(){
    $('#btn_search').trigger('click');
}