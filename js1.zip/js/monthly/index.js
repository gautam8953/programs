$(document).ready(function () {
    $("#bodyLoad").addClass('loader');
        $("#loader_overlay").show();
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 5,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "order": [[1, "ASC" ]],
        "ajax": {
            url: pageMainUrl + "ApiMonthly/getSearchData",
            type: "post",
            data: function (d) {
                d.search_facility = $('#search_facility').val();
                d.search_district = $('#search_district').val();
                d.search_state = $('#search_state').val();
                d.search_years = $('#search_years').val();
                d.search_months = $('#search_months').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        success:function(){
             
        },
        drawCallback: function () {
            $("#loader_overlay").hide();
            $("#bodyLoad").removeClass('loader');
            /*var params={};
             params['device']='web';
             params['facility']=$('#search_facility').val();
             $.ajax({
             url: pageMainUrl+'ApiMonthly/checkMonthlyFacilityAdd', 
             data: params, 
             type: 'POST', 
             dataType: 'json', 
             success: function(result){
             if(result.code=='0'){
             $('#addBtn').removeClass('disabled');
             } else {
             $('#addBtn').addClass('disabled');
             }
             }
             });*/
        }
    });


    /*if ($('#search_state').length) {
        $('#search_state').val($('#search_state option:eq(1)').val());
        change_state();
    } else {
        $('#search_district').val($('#search_district option:eq(1)').val());
        change_district();
        if ($('#search_district option').length == '2') {
            $('#search_district').closest('div').hide();
        }
    }*/

    $('#btn_search').click(function () {
        $("#bodyLoad").addClass('loader');
        $("#loader_overlay").show();
        datatableData.ajax.reload();
        /*if ($('#search_facility') && $('#search_facility').val() != '') {
            //datatableData.ajax.reload();
        } else {
            $("#loader_overlay").hide();
            $("#bodyLoad").removeClass('loader');   
            swal('Please select facility');
        }*/
    });
    $("#reset_btn").click(function () {
        $('select').prop('selectedIndex', 0);        
        $('.selectpicker').selectpicker('refresh');
        datatableData.ajax.reload();
    });
     
     $('#search_months').change(function(){
        datatableData.ajax.reload();
     });
     $('#search_years').change(function(){
        datatableData.ajax.reload();
     });

});



function getPage(ths) {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['setData'] = $(ths).attr('data-months');
    params['setDataMonth'] = $(ths).attr('data-reqMonth');
    $.ajax({
        url: pageMainUrl + 'ApiMonthly/setViewPage',
        data: params,
        type: 'POST',
        dataType: 'json',
        async: false,
        success: function (result) {
            window.location.href = $(ths).attr('data-href');
        }
    });
}

function change_district() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'facility';
    params['searchData'] = $('#search_district').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        async:false,
        success: function (result) {
            $('#search_facility').html('<option value="">Select Facility</option>');
            if (result.data) {
                if (parseInt(result.data.length) > 0) {
                    $.each(result.data, function (key, val) {
                        $('#search_facility').append($("<option></option>").attr("value", val.UserID).text(val.FacilityName));
                    });
                    /*if ($('#search_facility').length) {
                        if (parseInt($('#search_facility option').length) == 2) {
                            $('#search_facility').val($('#search_facility option:eq(1)').val());
                            $('#btn_search').trigger('click');
                        }
                    }*/
                }
            }
        }
    });
    $('#btn_search').trigger('click');
}

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="">Select District</option>');
            if (parseInt(result.data.length) > 0) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
            /*if (parseInt($('#search_district option').length) >= 2) {
                $('#search_district').val($('#search_district option:eq(1)').val());
                change_district();
            }*/
            
        }
    });
    $('#search_facility').html('<option value="">Select Facility</option>');
    $('#btn_search').trigger('click');
}

function showAddModel() {
    $('#addModal').modal('show');
}
function checkData() {
    if ($('#reportMonths').val() == '') {
        swal('Please select Month');
        return false;
    }
    if ($('#reportYears').val() == '') {
        swal('Please select Year');
        return false;
    }
    var reportMonths = $('#reportMonths').val();
    var reportYears = $('#reportYears').val();
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'monthReportCheck';
    params['reportMonths'] = reportMonths;
    params['reportYears'] = reportYears;
    $.ajax({
        url: pageMainUrl + 'ApiMonthly/monthReportCheck',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#resultDiv').html(result.data);
        }
    });
}

function change_facility(){
    $('#btn_search').trigger('click');
}