$(document).ready(function () {
    if($("#datatable").length){
        $("#bodyLoad").addClass('loader');
        $("#loader_overlay").show();        
    }

    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 50,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "ajax": {
            url: pageMainUrl + "ApiUser/getSearchFacility",
            type: "post",
            data: function (d) {
                $("#bodyLoad").removeClass('loader');
                $("#loader_overlay").hide();
                d.search_state = $('#search_state').val();
                d.search_district = $('#search_district').val();
                d.opt = $('#opt').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        }
    });

    $('#btn_search').click(function () {
        if ($('#search_district') && $('#search_district').val() != '') {
            datatableData.ajax.reload();
        } else {
            $("#bodyLoad").removeClass('loader');
            $("#loader_overlay").hide();
            swal('Please select District First');
        }
    });
    $('#btn_search_nin').click(function () {
        var FacilityNumberSearch= $('#FacilityNumberSearch').val();
        var url= pageMainUrl + "user/mapfacility/"+FacilityNumberSearch;
        if(FacilityNumberSearch==''){
            swal('Please enter nin number');
        } else {
            window.location.href=url;
        }
       
    });
    $('#btn_search_type').click(function () {
        var FacilityTypeSearch= $('#FacilityTypeSearch').val();
        if(FacilityTypeSearch!=''){
            var params = {};
            params['device'] = 'web';
            params['csrf_token']=$.cookie("csrf_cookie");
            $.ajax({
                url: pageMainUrl + 'ApiUser/facilitytype/'+FacilityTypeSearch,
                data: params,
                type: 'POST',
                dataType: 'json',
                success: function (result) {
                    swal(result.msg);
                    if (result.code=='0') {
                        $("#addFacilityTypeModal .close").click()
                    }
                }
            });            
        } else {
            swal('Please enter facility type');
        }
       
    });
    $("#reset_btn").click(function () {
        $('#search_state').val('0');
        $('#search_district').html('<option value="0">Select District</option>');
        datatableData.ajax.reload();
    });

    $('#search_district').change(function () {
        if ($('#search_district') && $('#search_district').val() != '') {
            datatableData.ajax.reload();
        } else {
        }
    });

    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl + 'ApiUser/roleData',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (result.code=='0') {
                if(result.data.role=='Ministry'){

                } else if(result.data.role=='State'){

                } else if(result.data.role=='District'){
                    $('#search_state').closest('div').hide();
                } else {
                    window.location.href=pageMainUrl;
                }
                if (result.data.hasOwnProperty('District') && parseInt($('#search_district').length) > 0) {
                    $('#search_district').html('<option value="0">Select District</option>');
                    $.each(result.data.District, function (key, val) {
                        $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                    });
                    if ($('#search_district').length) {
                        if (parseInt($('#search_district option').length) == 2) {
                            $('#search_district').val($('#search_district option:eq(1)').val());
                            $('#btn_search').trigger('click');
                        }
                    }
                }
                if (result.data.hasOwnProperty('State') && parseInt($('#search_state').length) > 0) {
                    $('#search_state').html('<option value="0">Select State</option>');
                    $.each(result.data.State, function (key, val) {
                        $('#search_state').append($("<option></option>").attr("value", val.StateID).text(val.StateName));
                    });
                    if ($('#search_state').length) {
                        if (parseInt($('#search_state option').length) == 2) {
                            $('#search_state').val($('#search_state option:eq(1)').val());
                            change_state();
                        }
                    }
                }
            }
        }
    });

    $('#facilityForm').submit(function () {
        $(this).ajaxSubmit({
            beforeSubmit: showRequest,
            success: showResponse,
            type: 'POST',
            dataType: 'json',
            data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false;
    });



});

function showResponse(responseText, statusText, xhr, $form) {
    $('#profileBtn').removeAttr('disabled');
    if(parseInt(responseText.code)==0){
      swal(responseText.msg).then((value) => {
        window.location.replace(pageMainUrl+'user/mapfacility');
      });
    } else {
      swal(responseText.msg);
    }
}
function showRequest(formData, jqForm, options) {
    $('#profileBtn').attr('disabled',true);
    var check = '0';
    var msg='Please fill all fields';
    if ($('#FacilityName').val() == '') {
        $('#FacilityName').closest('.form-group').addClass('has-error');
        msg='Please Enter facility name';
        check = '1';
    } else {
        $('#FacilityName').closest('.form-group').removeClass('has-error');
    }
    if ($('#FacilityNumber').val() == '') {
        $('#FacilityNumber').closest('.form-group').addClass('has-error');
        msg='Please Enter Nin number';
        check = '1';
    } else {
        $('#FacilityNumber').closest('.form-group').removeClass('has-error');
    }
    if ($('#TypeDetailCode').val() == '') {
        $('#TypeDetailCode').closest('.form-group').addClass('has-error');
        msg='Please Enter facility type';
        check = '1';
    } else {
        $('#TypeDetailCode').closest('.form-group').removeClass('has-error');
    }
    if ($('#Address').val() == '') {
        $('#Address').closest('.form-group').addClass('has-error');
        msg='Please Enter facility address';
        check = '1';
    } else {
        $('#Address').closest('.form-group').removeClass('has-error');
    }
    if ($('#StateName').val() == '' || $('#StateID').val() == '') {
        $('#StateName').closest('.form-group').addClass('has-error');
        msg='Please Enter facility state';
        check = '1';
    } else {
        $('#StateName').closest('.form-group').removeClass('has-error');
    }
    if ($('#DistrictName').val() == '' || $('#DistrictID').val() == '') {
        $('#DistrictName').closest('.form-group').addClass('has-error');
        msg='Please Enter facility state';
        check = '1';
    } else {
        $('#DistrictName').closest('.form-group').removeClass('has-error');
    }
    if ($('#DistrictName').val() == '' || $('#DistrictID').val() == '') {
        $('#DistrictName').closest('.form-group').addClass('has-error');
        msg='Please Enter facility state';
        check = '1';
    } else {
        $('#DistrictName').closest('.form-group').removeClass('has-error');
    }
    if ($('#Latitude').val() == '' ) {
        $('#Latitude').closest('.form-group').addClass('has-error');
        msg='Please Enter facility Latitude';
        check = '1';
    } else {
        $('#Latitude').closest('.form-group').removeClass('has-error');
    }
    if ($('#Longitude').val() == '' ) {
        $('#Longitude').closest('.form-group').addClass('has-error');
        msg='Please Enter facility Longitude';
        check = '1';
    } else {
        $('#Longitude').closest('.form-group').removeClass('has-error');
    }
    if (parseInt($('[name="services"]:checked').length)==0) {
        $('[name="services"]').closest('.form-group').addClass('has-error');
        msg='Please select facility type';
        check = '1';
    } else {
        $('[name="services"]').closest('.form-group').removeClass('has-error');
    }

    if(check!='0'){
      $('#profileBtn').removeAttr('disabled');
      return false;
    } else {
        return true;
    }     
    return true;
}

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="0">Select District</option>');
            if (result.hasOwnProperty('data')) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
        }
    });
    $('#btn_search').trigger('click');
}

function facilities(ths){
        if($(ths).is(':checked')){
            var checkedFacility=$(ths).val();
            var varfacilityCheck=$('input[name="addedFacility[]"]').filter(function(){
                return $(this).val()==checkedFacility;
            });
            if(varfacilityCheck.length==0){
                $('#failitiesAdd').append('<input type="hidden" value="'+checkedFacility+'" name="addedFacility[]">');
            }
        } else {
            var checkedFacility=$(ths).val();
            var varfacilityCheck=$('input[name="addedFacility[]"]').filter(function(){
                return $(this).val()==checkedFacility;
            }).remove();
        }
}

function map_user(mapType){
    var mappedFacilities=$('input[name="addedFacility[]"]').filter(function(){
                return $(this).val()!='';
            });
    if(mappedFacilities.length>0){
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['mapType'] = mapType;
        params['facilities'] = $('#failitiesAdd').serializeArray();
        $.ajax({
            url: pageMainUrl + 'ApiUser/map_facility',
            data: params,
            type: 'POST',
            dataType: 'json',
            success: function (result) {
                swal(result.msg).then((value) => {
                    $('#failitiesAdd').html('');
                    $('#btn_search').trigger('click');
                });
            }
        });        
    } else {
        swal('No facility selected');
        return false;
    }
}

function change_type(ths){
    if($(ths).val()=='1'){
        $('#btn_facility_map').prop('disabled',true);
        $('#btn_facility_remove').prop('disabled',false);
        $('#btn_search').trigger('click');
    } else {
        $('#btn_facility_map').prop('disabled',false);
        $('#btn_facility_remove').prop('disabled',true);
        $('#btn_search').trigger('click');
    }
}
function checkFacilityAssessment(ths){
    if($('#FacilityID').val()!=''){
  var params = {};
  var searchType=$(ths).val();
  params['device'] = 'web';
  params['csrf_token']=$.cookie("csrf_cookie");
  params['searchType'] = searchType;
  $.ajax({
      url: pageMainUrl + 'ApiUser/checkFacilityAssessment',
      data: params,
      type: 'POST',
      dataType: 'json',
      success: function (result) {
          if(result.code=='16'){
            swal(result.msg);
            $('#services_'+result.type).prop('checked',true);
          }
      }
  });        
    }

     
}