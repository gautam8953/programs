$(document).ready(function () {
    $('.captcha-refresh').on('click', function () {
        $.get(pageMainUrl + 'user/refresh', function (data) {
            $('#image_captcha').html(data);

        });
        $('#captcha').val('');
    });
    $('#loginForm').submit(function () {
        $(this).ajaxSubmit({
            beforeSubmit: showRequest,
            success: showResponse,
            type: 'POST',
            dataType: 'json',
            data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false;
    });

});
function showResponse(responseText, statusText, xhr, $form) {
    $("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
    if (parseInt(responseText.code) == 20) {
        window.location.href = pageMainUrl;
        /*$("#msgDiv").removeClass('alert-danger');
         $("#msgDiv").addClass('alert-success').show();*/
    } else {
        $('.captcha-refresh').trigger('click');
        $("#msgDiv").removeClass('alert-success');
        $("#msgDiv").addClass('alert-danger').show();
        $("#LoginMsg").text(responseText.msg);
        $('#captcha').val('');
    }

    /*setTimeout(function() { 
     if(parseInt(responseText.code)==0){
     window.location.href = pageMainUrl+"facility/index";
     }
     }, 3000);*/

}
function showRequest(formData, jqForm, options) {
    var check = '0';
    var msg='Please fill all fields';
    if ($('#username').val() == '') {
        $('#username').closest('.form-group').addClass('has-error');
        msg='Please Enter username';
        check = '1';
    } else {
        $('#username').closest('.form-group').removeClass('has-error');
        //$('#username').css("background-color", "#ffffff");
    }
    if ($('#password').val() == '') {
        $('#password').closest('.form-group').addClass('has-error');
        msg='Please Enter password';
        check = '1';
    } else {
        $('#password').closest('.form-group').removeClass('has-error');
        //$('#password').css("background-color", "#ffffff");
    }
     if ($('#captcha').val() == '') {
        $('#captcha').closest('.form-group').addClass('has-error');
        msg='Please solve captcha';
        check = '1';
    } else {
        $('#captcha').closest('.form-group').removeClass('has-error');
        //$('#password').css("background-color", "#ffffff");
    }
    if (!$('#checkbox2').is(":checked")) {
        check = '1';
        msg='Please accept terms and conditions';
    }
    if (check != '0') {
        $("#msgDiv").removeClass('alert-success');
        $("#msgDiv").addClass('alert-danger').show();
        $("#LoginMsg").text(msg);
        return false;
    }
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    return true;
}

function resetPassword(){
    if($('#userId').val()!=''){
        var params={};
        params['device']='web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['username']=$('#userId').val();
        $.ajax({
            url: pageMainUrl + 'ApiUser/forgetpassword',
            data: params,
            type: 'POST',
            dataType: 'json',
            success: function (result) {
                swal(result.msg);                
            }
        });
    } else {
        swal('Please enter username');
    }
    

} 