<?php include 'include/header_main.php'; ?>	
<script src="js/jquery.js"></script>
<style type="text/css">
    .tableListingMe {
        float: left;
        margin-right: 5px;
        margin-top: 5px;
    }
</style>
<!--top-->
<!--content-->
<div class="tpcontainercontent">
    <!--advert1-->
    <!--left-->
    <!--right-->			
    <!--maincontent-->
    <div class="tpcontainermain bb">
        <div class="tpinner">
            <!--<div class="clrfix"></div>-->				
            <div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">
                    <tr>
                        <td class="contentheading" width="100%">Laboratory Search</td>
                    </tr>
                </table>

                <table class="contentpaneopen" style="width:945px;" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                        <td valign="top" class="main_article">
                            <table width="100%"  border="0" cellspacing="1" cellpadding="0">
                                <tr>
                                    <td>
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
                                                <tr>
                                                    <td colspan="4" class="LaboratoryGridHead LabPaddingLeft">Laboratory Search</td>
                                                </tr>
                                                <tr><td colspan="4" height="10px">&nbsp;</td></tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">Laboratory ID</td>
                                                    <td class="LabTdRight" valign="top"><input name="lab_registration_code" type="text" id="lab_registration_code" value="<?php echo isset($lab_registration_code)?$lab_registration_code:''; ?>"></td>
                                                    <td class="LabTdLeft" valign="top">Laboratory Name</td>
                                                    <td class="LabTdRight" valign="top"><input name="labname" type="text" id="labname" value="<?php echo isset($labName)?$labName:''; ?>"></td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top" id="country_col" >Certificate No.</td> 
                                                    <td class="LabTdRight" valign="top"><input name="certificate_no" type="text" id="certificate_no" value="<?php echo $certificate_no; ?>"></td>
                                                    <td class="LabTdLeft" valign="top" id="country_col" >Country<span style="color:red;">&nbsp;*</span></td>
                                                    <td class="LabTdRight" valign="top"  id="country_val">
                                                        <select style="width:150px;" name="country" id="country-dropdown" onchange="getCountry(this.value);">
                                                            <option value="0">Please Select</option>
                                                            <?php
                                                            foreach ($country as $data) {
                                                                ?>
                                                                <option value="<?php echo $data[id]; ?>" <?php echo ($selectedCountry == $data[id]) ? 'selected' : ''; ?>><?php echo $data[name]; ?></option>
                                                            <?php }
                                                            ?>
                                                        </select>
                                                    </td>
                                                </tr>
                                                <tr id="countryRow" style="display:none;">
                                                    <td class="LabTdLeft" valign="top" id="state_col">State </td>
                                                    <td class="LabTdRight" valign="top" id="state_val"><?php echo $state; ?></td>
                                                    <td class="LabTdLeft" valign="top" id="city_col">City </td>
                                                    <td class="LabTdRight" valign="top" id="city_val"><div id="cityajax"><?php echo $city; ?></div></td>
                                                </tr>

                                                <tr><td colspan="4" height="5px"></td></tr>

                                                <tr>
                                                    <td class="LabTdLeft" valign="top">Zone</td>
                                                    <td class="LabTdRight" valign="top">
                                                        <?php echo $zone; ?>
                                                        <!-- <select style="width:150px;" name="country" id="country-dropdown" onchange="getCountry(this.value);">
                                                            <option value="0">Please Select</option>
                                                            <?php
                                                            foreach ($country as $data) {
                                                                ?>
                                                                <option value="<?php echo $data[id]; ?>" <?php echo ($selectedCountry == $data[id]) ? 'selected' : ''; ?>><?php echo $data[name]; ?></option>
                                                            <?php }
                                                            ?>
                                                        </select> -->
                                                    </td>
                                                    <td class="LabTdLeft" valign="top">Nature of Lab</td>
                                                    <td class="LabTdRight" valign="top"><?php echo $natureoflab; ?></td>
                                                </tr>

                                                <tr><td colspan="4" height="10px">&nbsp;</td></tr>

                                                <tr>
                                                    <td class="LabTdLeft" valign="top">Field</td>
                                                    <td class="LabTdRight" valign="top"><?php echo $facilitydropdown; ?></td>
                                                    <td class="LabTdLeft" valign="top">Facility</td>
                                                    <td class="LabTdRight" valign="top">
                                                        <?php echo $operationat; ?>
                                                    </td>

                                                    </td>
                                                </tr>

                                                <tr><td colspan="4" height="5px"></td></tr>

                                                <tr>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">Discipline</td>
                                                    <td class="LabTdRight" valign="top">
                                                        <div id='field'>
                                                            <?php
                                                            if (($_POST['submit'] == "Search" || $pagination == "yes") && $fielddropdown != "") {
                                                                echo $fielddropdown;
                                                            } else {
                                                                ?>
                                                                <select name="field_id[]" id="field_id" style="width:150px;">
                                                                    <option value='-1'>Please Select</option>
                                                                </select>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">Group</td>
                                                    <td class="LabTdRight" valign="top">
                                                        <div id='group'>
                                                            <?php
                                                            if (($_POST['submit'] == "Search" || $pagination == "yes") && $groupdropdown != "") {
                                                                echo $groupdropdown;
                                                            } else {
                                                                ?>
                                                                <select name="group_id" id="group_id" style="width:150px;">
                                                                    <option value="-1">Please Select</option>
                                                                </select>
                                                                <?php
                                                            }
                                                            ?>				
                                                        </div>
                                                    </td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">Sub Group </td>
                                                    <td class="LabTdRight" valign="top">
                                                        <div id='subgroup'>

                                                            <?php
                                                            if (($_POST['submit'] == "Search" || $pagination == "yes") && $subgroupdropdown != "") {
                                                                echo $subgroupdropdown;
                                                            } else {
                                                                ?>
                                                                <select name="subgroup[]" id="subgroup_id" size="10" multiple style="width:150px;">
                                                                    <option value="-1" >Please Select</option>
                                                                </select>
                                                                <?php
                                                            }
                                                            ?>

                                                        </div>
                                                    </td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">

                                                    </td>
                                                </tr>
                                                <tr><td colspan="4" height="10px"><hr /></td></tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top"><font color="#000000"><strong><em>Looking For Keyword</em></strong></font></td>
                                                    <td class="LabTdRight" valign="top"><input type="text" name="searchword" id="searchword" value="<?php echo $searchKeyword; ?>" /></td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                </tr>  
                                                <tr><td colspan="4" height="5px"></td></tr>            
                                                <tr>
                                                    <td align="center" colspan="4" valign="top"><center>
                                                    <input onclick="return get_data(this);" type="button" name="submit" value="Search">
                                                    &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;
                                                    <input onclick="return get_data(this);" id="export-excel" class="btn btn-primary" name="export-excel" value="Export to excel" type="button">&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;
                                                    <input type="button" name="button" id="button" value="Reset" onclick="javascript: return resetpage();" />
                                                    </center></td>
                                                </tr>
                                                <tr><td colspan="4" height="5px"></td></tr>
                                            </table></br>
                                                <div>
                                                    
                                                </div>



                                        <table id="rowDataShow" width="100%" border="0" cellpadding="0" cellspacing="0">











                                        </table>

                                        <table width='700' border='0' cellspacing='0' cellpadding='5'>
                                            <tr>
                                                <td align='left' valign='top' colspan='2'>pagination</td>
                                            </tr>
                                        </table>


                                    </td>
                                </tr>
                            </table>

                        </td>
                    </tr>

                </table>
            </div>

            <div class="clrfix"></div>
        </div>
    </div>		
    <div class="clrfix"></div>
</div> 

<!--bottom-->

<!-- -->
<!--footer-->
<?php include 'include/footer_main.php'; ?>	
</div>
</div>
</div>

<div id="templetData" style="display: none;">
    <table width="465px" border="0" cellspacing="0" cellpadding="0" class="Border LabBg tableListingMe" >
        <tbody>
        <tr>
            <td width="120px" height="50px" class="LabPaddingLeft" valign="top"><b>Lab Name :</b></td>
            <td width="0px" height="40px" class="LabPaddingLeft" valign="top"><font color="#666666"><b>M.S Test House</b></font></td>   
            <td width="5" height="40px">&nbsp;</td>
        </tr>                                                   
        <tr>
            <td style="height:5px;" colspan="3"></td>
        </tr>
        <tr>
            <td height="140px" class="LabPaddingLeft" valign="top"><b>Address :</b></td>
            <td class="LabPaddingLeft" valign="top">
                Abhiyanta Nagar, Z-Sector, Plot No. 09, Ashiyana Nagar
                <br>Patna - 800025<br>BIHAR<br>                                                     
                INDIA
            </td>
            <td width="5">&nbsp;</td>
        </tr>                                                                                         
        <tr>
            <td style="height:5px;" colspan="3"></td>
        </tr>
        <tr>
            <td class="LabPaddingLeft" valign="top"><b>Tel No. :</b></td>
            <td class="LabPaddingLeft" valign="top">0900606267</td>
            <td width="5">&nbsp;</td>
        </tr>
        <tr>
            <td style="height:5px;" colspan="3"></td>
        </tr>
        <tr>
            <td class="LabPaddingLeft" valign="top"><b>Fax No. :</b></td>
            <td class="LabPaddingLeft" valign="top"></td>
            <td width="5">&nbsp;</td>
        </tr>
        <tr><td style="height:5px;" colspan="3"></td></tr>
        <tr>
            <td class="LabPaddingLeft" valign="top" height="40px"><b>Email :</b></td>
            <td class="LabPaddingLeft" valign="top">msenterprises506@gmail.com, mstesthouse@gmail.com</td>
            <td width="5">&nbsp;</td>
        </tr>
        <tr><td style="height:5px;" colspan="3"></td></tr>
        <tr>
            <td class="LabPaddingLeft" valign="top"><b>Contact Person :</b></td>
            <td class="LabPaddingLeft" valign="top">Mr. Kanwareshwar Kumar</td>
            <td width="5">&nbsp;</td>
        </tr>
        <tr><td style="height:5px;" colspan="3"></td></tr> 
        <tr>
            <td class="LabBotBg" colspan="3">                                                 
                <a href="#" onclick="return open_win(5425)"> Click here to View the Scope of Accreditation</a>
                &nbsp;
            </td>                                                                      
        </tr><tr>
            <td class="LabBotBg" colspan="3">&nbsp;</td>                           
        </tr><tr>
            <td class="LabBotBg" colspan="3">&nbsp;</td>                           
        </tr></tbody>
    </table>    
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    $("#search-form").submit(function (event) {
        if ($("#country-dropdown").val() == '0')
        {
            alert("Please select country.");
            return false;
        }
        return true;
    });

$( document ).ready(function() {

});
function resetpage() {
    var servername = "http://" + window.location.hostname + "/nabl/";
    window.location = "index.php?c=search&m=index";
}

function get_data(ths){
    var params = {};
    params['setData'] = $(ths).attr('data-months');
    params['setDataMonth'] = $(ths).attr('data-reqMonth');
    $.ajax({
        url: <?php echo $_SERVER["REQUEST_URI"]; ?>,
        data: params,
        type: 'POST',
        dataType: 'json',
        async: false,
        success: function (result) {
            window.location.href = $(ths).attr('data-href');
        }
    });

}
</script>

</body>
</html>