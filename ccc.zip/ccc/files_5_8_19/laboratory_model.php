<?php
class laboratory_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_lab_all_laboratory($num)
	{		
		$this->load->helper('url');	
		$offset = $this->input->get('per_page');	
		$labcode = "";
		$labname = "";		
	    $labcode = $this->input->post('labcode');
	    $labname = $this->input->post('labname');
		$query = $this->db->select('*');
		$query = $this->db->from('laboratory_tbl');
		if($labcode!="")
		{
			$query = $this->db->where('lab_registration_code',$labcode);
		}
		if($labname!="")
		{
			$query = $this->db->like('lab_name',$labname);
		}
		$query = $this->db->order_by('lab_registration_code','lab_name');
		$query = $this->db->get('', $num, $offset);
		return $query->result_array();		
	}

	public function count_all_labs()
	{		
		//$offset = $this->input->get('per_page');	
		$labcode1 = "";
		$labname1 = "";		
	    $labcode1 = $this->input->post('labcode');
	    $labname1 = $this->input->post('labname');
		$query1 = $this->db->select('*');
		$query1 = $this->db->from('laboratory_tbl');
		if($labcode1!="")
		{
			$query1 = $this->db->where('lab_registration_code',$labcode1);
		}
		if($labname1!="")
		{
			$query1 = $this->db->like('lab_name',$labname1);
		}
		$query1 = $this->db->order_by('lab_registration_code','lab_name');
		$query1 = $this->db->get('');
		return $query1->result_array();
	}
	
	public function get_InactiveLaboratories($num)
	{
		$offset = $this->input->get('per_page');
		$whereCond = array('status'=>0);		
		$this->db->select('l.id, l.lab_name, l.lab_registration_code, l.lab_address');
		$this->db->from('laboratory_tbl as l');
		$this->db->where($whereCond);
		$this->db->order_by('l.lab_registration_code');
		$query = $this->db->get('',$num,$offset);
		return $query->result_array();
	}
	
	public function count_InactiveLaboratories()
	{		
		$query = $this->db->get_where('laboratory_tbl', array('status'=>0));
		return $query->result_array();
	}
	
	
	public function get_laboratory_details($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->select('*');
			$query = $this->db->from('laboratory_tbl');
			$query = $this->db->where('status',1);
			$query = $this->db->order_by('lab_registration_code','lab_name');
			$query = $this->db->get('');
			return $query->result_array();
		}

		$query = $this->db->get_where('laboratory_tbl', array('id' => $id));
		//print_r($query->row_array());
		return $query->row_array();
	}
	
	public function get_states($id = FALSE)
	{       $this->db->order_by("name", "asc");
		if ($id === FALSE)
		{
			$query = $this->db->get('states');
			return $query->result_array();
		}

		$query = $this->db->get_where('states', array('id' => $id));	
		return $query->row_array();
	}
	
	public function get_city($id = FALSE)
	{       $this->db->order_by("name", "asc");
		if ($id === FALSE)
		{
			$query = $this->db->get('cities');
			return $query->result_array();
		}

		$query = $this->db->get_where('cities', array('id' => $id));		
		return $query->row_array();
	}
	
	public function get_country($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('country');
			return $query->result_array();
		}

		$query = $this->db->get_where('country', array('id' => $id));		
		return $query->row_array();
	}
	
	
	
	public function get_zone($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('zone_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('zone_tbl', array('id' => $id));	
		return $query->row_array();
	}
	
	public function viewLaboratory()
	{
		$labid = $this->input->get('lno');
		//die();
		$this->db->select("l.*, city.name as cityName, s.name as stateName, c.name as countryName, z.zone_name as zoneName");	
		$this->db->from('laboratory_tbl As l');
		$this->db->join('cities As city', 'l.city=city.id','left');					
		$this->db->join('states As s', 'l.state=s.id','left');
		$this->db->join('country As c', 'l.country=c.id','left');
		$this->db->join('zone_tbl As z', 'l.zone=z.id','left');
		$this->db->where('l.id',$labid);
		$query = $this->db->get();
		return $query->result_array();
	}
	
	public function set_laboratory()
	{		
		$this->load->helper('url');		
		
		$arrmsg = array();
		
		if($this->input->post('registration_date')!="")
		{
		$regisDate = explode('-',$this->input->post('registration_date'));
		$regisDate = array_reverse($regisDate);	
		$newRegistrationDate = implode('-',$regisDate);		
		}
		else 
		{
			$newRegistrationDate = "0000-00-00";
		}
		
		if($this->checkUniqueLabRegistrationCode($this->input->post('labo_regis_code')))
		{
			$arrmsg['duplicate'] = "duplicate";
			return $arrmsg;
		}
		else
		{		
			//echo "Anshu - ";	
			$data = array(
							'lab_name' => $this->input->post('labo_name'),
							'lab_registration_code' => $this->input->post('labo_regis_code'),
							'lab_address' => $this->input->post('address'),
							'city' => $this->input->post('city'),
							'state' => $this->input->post('state'),
							'country' => $this->input->post('country'),
							'zone' => $this->input->post('zone'),
							'otherzone' => $this->input->post('otherzone'),
							'pincode' => $this->input->post('pincode'),
							'contact_person' => $this->input->post('contactperson'),
							'designation' => $this->input->post('designation'),
							'phone' => $this->input->post('phone'),	
							'emailid' => $this->input->post('emailid'),	
							'fax' => $this->input->post('fax'),	
							'registration_date' => $newRegistrationDate,	
							'status'=>1,
							'request_from'=>'web',
							'createdby' => '1'
			);
			if($this->db->insert('laboratory_tbl', $data))
			{
				//echo "IF - ";
					//$this->db->insert('laboratory_tbl', $data);
					$arrmsg['success']="success";
					return $arrmsg;
					
			}
			else 
			{
				//echo "ELSE - ";
				$arrmsg['unsuccess'] = "unsuccess";
				return $arrmsg;
			}
			
			
			
		}
		
	}

	public function set_laboratoryApi($data)
	{		

        $databck=array();
        $databck['datasent']=serialize($data);
        $databck['type_data']='lab';
       // $this->db->insert('api_data', $databck);

		
		$arrmsg = array();
		
		if($data['registration_date']!="")
		{
			
		$newRegistrationDate =  date("Y-m-d", strtotime($data['registration_date']));	
		}
		else 
		{
			$newRegistrationDate = "0000-00-00";
		}
		
		//if($this->checkUniqueLabRegistrationCode($data['labo_regis_code']))
		//{
		//	$arrmsg['duplicate'] = "duplicate";
		//	return $arrmsg;
		//}
		//else
		//{	

            $countrydata = trim($data['country']);
            $condcsc = array('name' => $countrydata);
            $country_id = $this->select_record('id','country', $condcsc);
/*            if($country_id==''){
                $arrmsg['status'] = "Country not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }*/
            if(empty($country_id)){
                $dataToSave=array();
                $dataToSave['name']=$countrydata;
                //$dataToSave['iso_code']=$countrydata;
                //$dataToSave['phone_code']=$countrydata;
                $dataToSave['isActive']='1';
                $dataToSave['createdBy']='500';
                $dataToSave['CreatedOn']=date('Y-m-d H:i:s');
                if($this->db->insert('country', $dataToSave)){
                  $country_id=$this->db->insert_id();
                } else {
                    $arrmsg['status'] = "Error Saving Country Data";
                    $arrmsg['statusCode'] = 4;
                    return $arrmsg;
                }
            } else {

            }


            $statedata = trim($data['state']);
            $condcs = array('name' => $statedata);
            $state_id = $this->select_record('id','states', $condcs);
/*            if($state_id==''){
                $arrmsg['status'] = "State not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }*/
            if(empty($state_id)){
                $dataToSave=array();
                $dataToSave['country_id']=$country_id;
                $dataToSave['name']=$statedata;
                $dataToSave['isActive']='1';
                $dataToSave['createdBy']='500';
                $dataToSave['CreatedOn']=date('Y-m-d H:i:s');
                if($this->db->insert('states', $dataToSave)){
                  $state_id=$this->db->insert_id();
                } else {
                    $arrmsg['status'] = "Error Saving State Data";
                    $arrmsg['statusCode'] = 4;
                    return $arrmsg;
                }
            } else {

            }

		    $citydata = trim($data['city']);
            $condc = array('name' => $citydata);
            $city_id = $this->select_record('id','cities', $condc);
/*            if($city_id==''){
                $arrmsg['status'] = "City not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }*/
            if(empty($city_id)){
                $dataToSave=array();
                $dataToSave['stateid']=$state_id;
                $dataToSave['name']=$citydata;
                $dataToSave['isActive']='1';
                $dataToSave['createdBy']='500';
                $dataToSave['CreatedOn']=date('Y-m-d H:i:s');
                if($this->db->insert('cities', $dataToSave)){
                  $city_id=$this->db->insert_id();
                } else {
                    $arrmsg['status'] = "Error Saving City Data";
                    $arrmsg['statusCode'] = 4;
                    return $arrmsg;
                }
            } else {

            }

            $zonedata = trim($data['zone']);
            $condcse = array('zone_name' => $zonedata);
            $zone_id = $this->select_record('id','zone_tbl', $condcse);
/*            if($zone_id==''){
                $arrmsg['status'] = "Zone not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }*/
            if(empty($zone_id)){
                $dataToSave=array();
                $dataToSave['zone_name']=$zonedata;
                $dataToSave['createdby']='500';
                $dataToSave['createdon']=date('Y-m-d H:i:s');
                if($this->db->insert('zone_tbl', $dataToSave)){
                  $zone_id=$this->db->insert_id();
                } else {
                    $arrmsg['status'] = "Error Saving Zone Data";
                    $arrmsg['statusCode'] = 4;
                    return $arrmsg;
                }
            } else {

            }







	
	
			//echo "Anshu - ";	
			$dataapi = array(
							'lab_name' => $data['labo_name'],
							'lab_registration_code' =>$data['labo_regis_code'],
							'lab_address' =>$data['address'],
							'city' =>  $city_id,
							'state' => $state_id,
							'country' => $country_id,
							'zone' => $zone_id,
							'pincode' =>$data['pincode'],
							'contact_person' =>$data['contactperson'],
							'designation' =>$data['designation'],
							'phone' =>$data['phone'],	
							'emailid' =>$data['emailid'],	
							'fax' =>$data['fax'],	
							'registration_date' =>$newRegistrationDate,	
							'status'=>'1',
							'request_from'=>'api',
							'createdby' => '1'
			);
                        
                  // print_r($dataapi);die;
                        if($this->checkUniqueLabRegistrationCode($data['labo_regis_code']))
		{
                            //echo'updare';die;
                        $this->db->update('laboratory_tbl', $dataapi, array('lab_registration_code'=>$data['labo_regis_code']));
			$arrmsg['duplicate'] = "duplicate";
			return $arrmsg;
                }else{
                    $this->db->insert('laboratory_tbl', $dataapi);
                    $arrmsg['success']="success";
					return $arrmsg;
                }
//			if($this->db->insert('laboratory_tbl', $dataapi))
//			{
//				    //echo "IF - ";
//					//$this->db->insert('laboratory_tbl',$data);
//					$arrmsg['success']="success";
//					return $arrmsg;
//					
//			}
//			else 
//			{
//				//echo "ELSE - ";
//				$arrmsg['unsuccess'] = "unsuccess";
//				return $arrmsg;
//			}
			
			
			
		//}
		
	}

	public function set_laboratoryApi_kunal($data)
	{		
		 
		
		$arrmsg = array();
		
		if($data['registration_date']!="")
		{
			
		$newRegistrationDate =  date("Y-m-d", strtotime($data['registration_date']));	
		}
		else 
		{
			$newRegistrationDate = "0000-00-00";
		}
		
		if($this->checkUniqueLabRegistrationCode($data['labo_regis_code']))
		{
			$arrmsg['duplicate'] = "duplicate";
			return $arrmsg;
		}
		else
		{	

		    $citydata = trim($data['city']);

            $condc = array('name' => $citydata);
            $city_id = $this->select_record('id','cities', $condc);

            if($city_id==''){
                $arrmsg['status'] = "City not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }



            $statedata = trim($data['state']);

            $condcs = array('name' => $statedata);
            $state_id = $this->select_record('id','states', $condcs);

            if($state_id==''){
                $arrmsg['status'] = "State not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }


            $countrydata = trim($data['country']);

            $condcsc = array('name' => $countrydata);
            $country_id = $this->select_record('id','country', $condcsc);

            if($country_id==''){
                $arrmsg['status'] = "Country not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }

            $zonedata = trim($data['zone']);

            $condcse = array('zone_name' => $zonedata);
            $zone_id = $this->select_record('id','zone_tbl', $condcse);

            if($zone_id==''){
                $arrmsg['status'] = "Zone not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }
	
	
			//echo "Anshu - ";	
			$dataapi = array(
							'lab_name' => $data['labo_name'],
							'lab_registration_code' =>$data['labo_regis_code'],
							'lab_address' =>$data['address'],
							'city' =>  $city_id,
							'state' => $state_id,
							'country' => $country_id,
							'zone' => $zone_id,
							'pincode' =>$data['pincode'],
							'contact_person' =>$data['contactperson'],
							'designation' =>$data['designation'],
							'phone' =>$data['phone'],	
							'emailid' =>$data['emailid'],	
							'fax' =>$data['fax'],	
							'registration_date' =>$newRegistrationDate,	
							'status'=>'1',
							'request_from'=>'api',
							'createdby' => '1'
			);
			if($this->db->insert('laboratory_tbl', $dataapi))
			{
				    //echo "IF - ";
					//$this->db->insert('laboratory_tbl',$data);
					$arrmsg['success']="success";
					return $arrmsg;
					
			}
			else 
			{
				//echo "ELSE - ";
				$arrmsg['unsuccess'] = "unsuccess";
				return $arrmsg;
			}
			
			
			
		}
		
	}

	public function update_laboratory($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		if($this->input->post('registration_date')!="")
		{
			$regisDate = explode('-',$this->input->post('registration_date'));
			$regisDate = array_reverse($regisDate);	
			$newRegistrationDate = implode('-',$regisDate);		
		}
		else 
		{
			$newRegistrationDate = "0000-00-00";
		}
                
              
             $countrydata = $this->input->post('country');
            $condcsc = array('name' => $countrydata);
            $country_id = $this->select_record('id','country', $condcsc);
          //  print_r($country_id);die;
/*            if($country_id==''){
                $arrmsg['status'] = "Country not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }*/
            if(empty($country_id)){
                $dataToSave=array();
                $dataToSave['name']=$countrydata;
                //$dataToSave['iso_code']=$countrydata;
                //$dataToSave['phone_code']=$countrydata;
                $dataToSave['isActive']='1';
                $dataToSave['createdBy']='500';
                $dataToSave['CreatedOn']=date('Y-m-d H:i:s');
                if($this->db->insert('country', $dataToSave)){
                  $country_id=$this->db->insert_id();
                } else {
                    $arrmsg['status'] = "Error Saving Country Data";
                    $arrmsg['statusCode'] = 4;
                    return $arrmsg;
                }
            } 


            $statedata = $this->input->post('state');
            $condcs = array('name' => $statedata);
            $state_id = $this->select_record('id','states', $condcs);
/*            if($state_id==''){
                $arrmsg['status'] = "State not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }*/
            if(empty($state_id)){
                $dataToSave=array();
                $dataToSave['country_id']=$country_id;
                $dataToSave['name']=$statedata;
                $dataToSave['isActive']='1';
                $dataToSave['createdBy']='500';
                $dataToSave['CreatedOn']=date('Y-m-d H:i:s');
                if($this->db->insert('states', $dataToSave)){
                  $state_id=$this->db->insert_id();
                } else {
                    $arrmsg['status'] = "Error Saving State Data";
                    $arrmsg['statusCode'] = 4;
                    return $arrmsg;
                }
            } 

		    $citydata = $this->input->post('city');
                    //print_r($citydata);die;
            $condc = array('name' => $citydata);
            $city_id = $this->select_record('id','cities', $condc);
/*            if($city_id==''){
                $arrmsg['status'] = "City not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }*/
            if(empty($city_id)){
                $dataToSave=array();
                $dataToSave['stateid']=$state_id;
                $dataToSave['name']=$citydata;
                $dataToSave['isActive']='1';
                $dataToSave['createdBy']='500';
                $dataToSave['CreatedOn']=date('Y-m-d H:i:s');
                if($this->db->insert('cities', $dataToSave)){
                  $city_id=$this->db->insert_id();
                } else {
                    $arrmsg['status'] = "Error Saving City Data";
                    $arrmsg['statusCode'] = 4;
                    return $arrmsg;
                }
            } 

            $zonedata = $this->input->post('zone');
            $condcse = array('zone_name' => $zonedata);
            $zone_id = $this->select_record('id','zone_tbl', $condcse);
/*            if($zone_id==''){
                $arrmsg['status'] = "Zone not found.";
                $arrmsg['statusCode'] = 4;
                return $arrmsg;
            }*/
            if(empty($zone_id)){
                $dataToSave=array();
                $dataToSave['zone_name']=$zonedata;
                $dataToSave['createdby']='500';
                $dataToSave['createdon']=date('Y-m-d H:i:s');
                if($this->db->insert('zone_tbl', $dataToSave)){
                  $zone_id=$this->db->insert_id();
                } else {
                    $arrmsg['status'] = "Error Saving Zone Data";
                    $arrmsg['statusCode'] = 4;
                    return $arrmsg;
                }
            } else {

            }

           
            
            
		$data = array(
						'lab_name' => $this->input->post('labo_name'),
						'lab_registration_code' => $this->input->post('labo_regis_code'),
						'lab_address' => $this->input->post('address'),
						'city' => $city_id,
						'state' => $state_id,
						'country' => $country_id,
						'zone' => $zone_id,
						'otherzone' => $this->input->post('otherzone'),
						'pincode' => $this->input->post('pincode'),
						'contact_person' => $this->input->post('contactperson'),
						'designation' => $this->input->post('designation'),
						'phone' => $this->input->post('phone'),	
						'emailid' => $this->input->post('emailid'),	
						'fax' => $this->input->post('fax'),	
						'registration_date' => $newRegistrationDate,
						'modifiedby' => '1',
						'modifiedon' => date('Y-m-d h:i:s')
		);
            //  print_r($data);die;
		return $this->db->update('laboratory_tbl', $data, array('lab_registration_code'=>$id));
	}

	public function delete_laboratory($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		return $this->db->delete('laboratory_tbl',  array('id'=>$id));
	}
	
	public function update_status_laboratory($status, $id)
	{		
		//$this->load->helper('url');
		if($status==1)
		{
			if($this->db->update('laboratory_tbl', array('status'=>0), array('id'=>$id)))
					return true;
			else 
					return false;	
		}
		if($status==0)
		{
			if($this->db->update('laboratory_tbl', array('status'=>1), array('id'=>$id)))
					return true;
			else 
					return false;
		}	
		
	}
	
	public function checkUniqueLabRegistrationCode($labcode)
	{
		$query = $this->db->get_where('laboratory_tbl', array('lab_registration_code'=>$labcode));
		return $query->row_array();
	}
	
	public function search_lab($num)
	{
		$this->load->helper('url');	
		$offset = $this->input->get('per_page');		
	    $labcode = $this->input->post('labcode');
	    $labname = $this->input->post('labname');
		$query = $this->db->select('*');
		$query = $this->db->from('laboratory_tbl');
		if($labcode!="")
		{
			$query = $this->db->where('lab_registration_code',$labcode);
		}
		if($labname!="")
		{
			$query = $this->db->like('lab_name',$labname);
		}
		$query = $this->db->order_by('lab_registration_code','lab_name');
		$query = $this->db->get('', $num, $offset);
		return $query->result_array();		
	}
	
	public function get_all_laboratory()
	{		
		$query = $this->db->select('*');
		$query = $this->db->from('laboratory_tbl');	
		$query = $this->db->order_by('lab_registration_code','lab_name');
		$query = $this->db->get('');
		return $query->result_array();		
	}


	    // by kunal for get single column from table.
    function select_record($column_name, $table, $condition = "") {
        $this->db->select($column_name);
        $this->db->from($table);
        if ($condition) {
            foreach ($condition as $k => $v) {
                $this->db->where($k, $v);
            }
        }
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            foreach ($query->result() as $row1) {
                
            }
            return $row1->$column_name;
        } else {
            return false;
        }
    }

    function select_recordbyName($column_name, $table, $cat_id, $cat_name) {
        $this->db->select($column_name);
        $this->db->from($table);
        if ($cat_id) {

            $this->db->where('cat_id', $cat_id);
        }
        if ($cat_name) {

            $this->db->like('category_name', ltrim($cat_name));
        }
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            foreach ($query->result() as $row1) {
                
            }
            return $row1->$column_name;
        } else {
            return false;
        }
    }
}