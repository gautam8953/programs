<?php

class Api extends CI_Controller {

    public function __construct() {

        parent::__construct();

        $this->load->model('certificate_model');
        $this->load->model('laboratory_model');
    }

    public function add_certificate() {


        $message = array();

        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data)) {
            $data = $this->input->post();
        }
        if(isset($data['certificate_no'])){
          $data['certificate_no'] =  str_replace("'", "", $data['certificate_no']);
        }
        $tokenData = 'admin-' . date('d-m-Y');
        $response_token = base64_decode($data['token']);

        	//echo "<pre>"; print_r($data); echo "</pre>";
            //die;

        $response = array();
        if ($tokenData == $response_token) {

            if ($data['lab_id'] == '' || $data['certificate_url']== '' || $data['certificate_no'] == '' || $data['nature_of_lab'] == '' || (count($data['operationat']) < 1) || $data['issue_date'] == '' || $data['extend_upto'] == '' || $data['facility_id'] == '' || $data['group_id'] == '' || (count($data['subgroupsList']) < 1) || $data['expiry_date'] == '' || (count($data['newdescipline']) < 1)) {
                $message['status'] = 'Required parameter are missing.';
                if ($data['lab_id'] == '') {
                    $message['status'] = 'Laboratory is Required.';
                } else if ($data['certificate_url'] == '') {
                    $message['status'] = 'Certificate Url is Required.';
                }else if ($data['certificate_no'] == '') {
                    $message['status'] = 'Certificate No is Required.';
                } else if ($data['nature_of_lab'] == '') {
                    $message['status'] = 'Nature of Lab is Required.';
                } else if (count($data['operationat']) < 1) {
                    $message['status'] = 'Facility  is Required.';
                } else if ($data['issue_date'] == '') {
                    $message['status'] = 'Issue Date  is Required.';
                } else if ($data['expiry_date'] == '') {
                    $message['status'] = 'Expiry Date  is Required.';
                } else if ($data['extend_upto'] == '') {
                    $message['status'] = 'Extend upto Date  is Required.';
                } else if ($data['facility_id'] == '') {
                    $message['status'] = 'Facility is Required.';
                } else if ($data['group_id'] == '') {
                    $message['status'] = 'Group is Required.';
                } else if ((count($data['subgroupsList']) < 1)) {
                    $message['status'] = 'Sub Group is Required.';
                } else if ((count($data['newdescipline']) < 1)) {
                    $message['status'] = 'Discipline  is Required.';
                }

                $message['statusCode'] = '4';
            } else {
                //$data = $this->CommonModel->getApiData();
                if ($data) {//($this->form_validation->run() === FALSE)

                    $cermsg = $this->certificate_model->set_certificateApi($data);
                    // print_r($cermsg);

                    if(isset($cermsg['statusCode'])){
                            $message['status'] = $cermsg['status'];
                            $message['statusCode'] =  $cermsg['statusCode'];
                    }
                    if (isset($cermsg) ) {
                      /*  if (isset($cermsg['duplicate']) && $cermsg['duplicate'] == "duplicate") {
                            $message['status'] = 'Certificate Already Exists';
                            $message['statusCode'] = '3';
                            //duplicate error
                        }*/
                        if (isset($cermsg['unsuccess']) && $cermsg['unsuccess'] == "unsuccess") {
                            $message['status'] = 'Unable To Add Certificate';
                            $message['statusCode'] = '1';
                            //unable to insert error
                        }
                    }
                    if (isset($cermsg) ) {

                        if (isset($cermsg['success']) && $cermsg['success'] == "success") {

                            $certificateid = $cermsg['cid'];
                            if ($certificateid != "") {

                                include './application/controllers/class.pdf2txt.php';
                                include './application/controllers/Upload.php';
                                $uploadObj = new Upload();
                                $data['certInfo1'] = $uploadObj->do_uploadApi("certificatedoc", $certificateid);
                                $ext = $this->get_file_extension($_FILES['certificatedoc']['name']);
                                $userDoc = "uploads/" . $certificateid . "." . $ext;
                                $content = "";
                                if ($ext == "doc") {
                                    $content = $this->parseWord($userDoc);
                                }
                                if ($ext == "docx") {
                                    $content = $this->readDocx($userDoc);
                                }
                                if ($ext == "pdf") {

                                   
                                    $a = new PDF2Text();
                                    $a->setFilename($userDoc);
                                    $a->decodePDF();
                                    $content = $a->output();
                                }

                                $data['certInfo11'] = $uploadObj->do_uploadApi("certificatedoc2", $certificateid);
                                $ext2 = $this->get_file_extension($_FILES['certificatedoc2']['name']);
                                $userDoc1 = "uploads/" . $certificateid . "_sample_format." . $ext2;
                                $content2 = "";
                                if ($ext2 == "doc") {
                                    $content2 = $this->parseWord($userDoc1);
                                }
                                if ($ext2 == "docx") {
                                    $content2 = $this->readDocx($userDoc1);
                                }
                                if ($ext2 == "pdf") {

                                   
                                    $a = new PDF2Text();
                                    $a->setFilename($userDoc1);
                                    $a->decodePDF();
                                    $content2 = $a->output();
                                }





                                //echo "<pre>"; print_r($_FILES); echo "</pre>";
                                //die;
                                //$this->load->model('certificate_model');
                               // $this->certificate_model->updateCertificateDocument($certificateid, $content);
                                if($_FILES['certificatedoc2']['name']!=''){
                                 $this->certificate_model->updateCertificateDocument2($certificateid, $content2);
                               }
                            }
                            $this->load->helper('url');
                            $message['status'] = 'Certificate  Created';
                            $message['statusCode'] = '2';
                        }
                    }
                    //$this->load->helper('url');	
                    //$message['status']='Certificate Added';		
                }
            }
        } else {
            $message['status'] = 'Token not valid.';
            $message['statusCode'] = '5';
        }
        echo json_encode($message);
    }


    public function add_laboratory(){
       

        $message = array();

        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data)) {
            $data = $this->input->post();
        }
      
//        $tokenData = 'admin-' . date('d-m-Y');
//        $response_token = base64_decode($data['token']);
       // echo "<pre>";
      // print_r($tokenData);
      // print_r($data); echo "</pre>";
        //die;
        $response = array();
//        if ($tokenData == $response_token) {

            if ($data['labo_name'] == '' || $data['labo_regis_code']== '' || $data['address'] == '' || $data['state'] == ''  || $data['country'] == '' || $data['zone'] == '' || $data['contactperson']=='') {
                $message['status'] = 'Required parameter are missing.';
                if ($data['labo_name'] == '') {
                    $message['status'] = 'Laboratory Name is Required.';
                } else if ($data['labo_regis_code'] == '') {
                    $message['status'] = 'Lab Registration code is Required.';
                }else if ($data['address'] == '') {
                    $message['status'] = 'Address is Required.';
                } else if ($data['state'] == '') {
                    $message['status'] = 'State is Required.';
                }  else if ($data['country'] == '') {
                    $message['status'] = 'Country is Required.';
                } else if ($data['zone'] == '') {
                    $message['status'] = 'Zone  is Required.';
                }else if ($data['contactperson'] == '') {
                    $message['status'] = 'Contact Person  is Required.';
                } 

                $message['statusCode'] = '4';
            }else {
            
            if ($data) {
            $msg = array();
            $msg=$this->laboratory_model->set_laboratoryApi($data);


            //$this->load->helper('url');
             if(isset($msg['statusCode'])){
                                $message['status'] = $msg['status'];
                                $message['statusCode'] =  $msg['statusCode'];
                        }
            
            if(isset($msg['duplicate']) && $msg['duplicate']=="duplicate")
            {
                
//                $data= $this->laboratory_model->update_laboratory($data['labo_regis_code']);
//                if($data){
                    $message['status'] = 'Laboratory updated Succefuly';
                            $message['statusCode'] = '3';
               // }
                            
                
            }
            
            if(isset($msg['success']) && $msg['success']=="success")
            {
                            $message['status'] = 'Laboratory Added';
                            $message['statusCode'] = '2';
                
            }
            if(isset($msg['unsuccess']) && $msg['unsuccess']=="unsuccess")
            {

                            $message['status'] = 'Unable To Add Laboratory';
                            $message['statusCode'] = '1';
               
            }           
          }
       }
//      }
//        else{
//            $message['status'] = 'Token not valid.';
//            $message['statusCode'] = '5';
//        }
        echo json_encode($message);
       

    }

    function parseWord($userDoc) {
        $fileHandle = fopen($userDoc, "r");
        $word_text = @fread($fileHandle, filesize($userDoc));
        $line = "";
        $tam = filesize($userDoc);
        $nulos = 0;
        $caracteres = 0;
        for ($i = 1536; $i < $tam; $i++) {
            $line .= $word_text[$i];

            if ($word_text[$i] == 0) {
                $nulos++;
            } else {
                $nulos = 0;
                $caracteres++;
            }

            if ($nulos > 1996) {
                break;
            }
        }
        //echo $caracteres;	
        $lines = explode(chr(0x0D), $line);
        //$outtext = "<pre>";	
        $outtext = "";
        foreach ($lines as $thisline) {
            $tam = strlen($thisline);
            if (!$tam) {
                continue;
            }

            $new_line = "";
            for ($i = 0; $i < $tam; $i++) {
                $onechar = $thisline[$i];
                if ($onechar > chr(240)) {
                    continue;
                }

                if ($onechar >= chr(0x20)) {
                    $caracteres++;
                    $new_line .= $onechar;
                }

                if ($onechar == chr(0x14)) {
                    $new_line .= "</a>";
                }

                if ($onechar == chr(0x07)) {
                    $new_line .= "\t";
                    if (isset($thisline[$i + 1])) {
                        if ($thisline[$i + 1] == chr(0x07)) {
                            $new_line .= "\n";
                        }
                    }
                }
            }
            //troca por hiperlink
            $new_line = str_replace("HYPERLINK", "<a href=", $new_line);
            $new_line = str_replace("\o", ">", $new_line);
            $new_line .= "\n";

            //link de imagens
            $new_line = str_replace("INCLUDEPICTURE", "<br><img src=", $new_line);
            $new_line = str_replace("\*", "><br>", $new_line);
            $new_line = str_replace("MERGEFORMATINET", "", $new_line);
            $outtext .= nl2br($new_line);
        }
        return $outtext;
    }

    /// for .docx only 
    function readDocx($filePath) {
        // Create new ZIP archive
        $zip = new ZipArchive;
        $dataFile = 'word/document.xml';
        // Open received archive file
        if (true === $zip->open($filePath)) {
            // If done, search for the data file in the archive
            if (($index = $zip->locateName($dataFile)) !== false) {
                // If found, read it to the string
                $data = $zip->getFromIndex($index);
                // Close archive file
                $zip->close();
                // Load XML from a string
                // Skip errors and warnings
                $xml = DOMDocument::loadXML($data, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
                // Return data without XML formatting tags

                $contents = explode('\n', strip_tags($xml->saveXML()));
                $text = '';
                foreach ($contents as $i => $content) {
                    $text .= $contents[$i];
                }
                return $text;
            }
            $zip->close();
        }
        // In case of failure return empty string
        return "";
    }

    function get_file_extension($file_name) {
        return end(explode('.', $file_name));
    }
    function update_lab(){
        $message = array();

        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data)) {
            $data = $this->input->post();
        }
        
        
    }
    

}
