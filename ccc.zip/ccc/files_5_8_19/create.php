<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){
                //For date of birth
                $('#registration_date').datepicker({ yearRange: '1930:2020' } );
            });
        </script>
        <script language='JavaScript' type='text/javascript' src='JScript/formValidator.js'></script>                    

<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">

<tr>
<td align="center">
<?php //echo validation_errors(); ?>
<?php echo form_open('c=laboratory&m=create') ?>
<div class="tpcontainermainc" style="width: 960px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add Laboratory</td>
</tr>
<tr>
<td style="height:15px;">
</td>
</tr>
<tr>
<td>
<div style="overflow:auto; width:930px;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
Add Laboratory
</td>
</tr>
<tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="215px" align="left" class="LabPaddingLeft">Laboratory Registration Code *</td>
              <td width="250px" align="left"> <input name="labo_regis_code" type="text" id="labo_regis_code" ></td>
              <td width="200px" align="left">Laboratory Name * </td>
              <td width="265px" align="left"><input name="labo_name" type="text" id="labo_name"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td  align="left" class="LabPaddingLeft">Address *</td>
              <td align="left">
              <textarea name="address" id="address" id="address" cols="26" rows="3"></textarea>
             <!--  <input name="address" type="text" id="address">  -->
              </td>
              <td align="left">City </td>
              <td align="left"><select name="city" id="city" style="width:150px;">
                <option value="0" selected>Please Select</option>
	            <?php                     	
	              	for($i=0;$i<count($city);$i++)
	              	{ 
	              ?>
	                	<option value="<?php echo $city[$i]['id'] ?>"><?php echo $city[$i]['name'] ;?></option>
	              <?php
	              	} 
	             ?>
                </select></td>
            </tr>
           <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
                 <td align="left"  class="LabPaddingLeft space"  style="display:none" ></td>
              <td align="left"  class="LabPaddingLeft st">State *</td>
              <td align="left">
              <select name="state" id="state"  style="width:150px;">
                <option value="0" selected>Please Select</option>
	            <?php                     	
	              	for($i=0;$i<count($state);$i++)
	              	{ 
	              ?>
	                	<option value="<?php echo $state[$i]['id'] ?>"><?php echo $state[$i]['name'] ;?></option>
	              <?php
	              	} 
	             ?>                
              </select>
              </td>
              <td align="left">Country * </td>
              <td align="left"> 
              <select name="country" id="country"  onchange="somefunction()"   style="width:150px;">
              <option value="0" selected>Please Select</option>
	            <?php                     	
	              	for($i=0;$i<count($country);$i++)
	              	{ 
	              ?>
	                	<option value="<?php echo $country[$i]['id'] ?>"><?php echo $country[$i]['name'] ;?></option>
	              <?php
	              	} 
	             ?> 
              </select>              
              </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            
            <tr>
            
              <td align="left"  class="LabPaddingLeft zonal">Zone * </td>
              <td align="left">             
              <select name="zone" id="zone"  style="width:150px;">
              <option value="0" selected>Please Select</option>
	            <?php                     	
	              	for($i=0;$i<count($zone);$i++)
	              	{ 
	              ?>
	                	<option value="<?php echo $zone[$i]['id'] ?>"><?php echo $zone[$i]['zone_name'] ;?></option>
	              <?php
	              	} 
	             ?>                
              </select>
              </td>
              <td align="left"  class="LabPaddingLeft space"  style="display:none" ></td>
              <td align="left">Pincode </td>
              <td align="left"><input name="pincode" type="text" id="pincode" > </td>
            </tr>
            
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td align="left" class="LabPaddingLeft">Contact Person *</td>
              <td align="left"><input name="contactperson" type="text" id="contactperson"></td>
              <td align="left">Designation</td>
              <td align="left"><input name="designation" type="text" id="designation"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td align="left" class="LabPaddingLeft">Phone</td>
              <td align="left"><input name="phone" type="text" id="phone"></td>
              <td align="left">Email ID </td>
              <td align="left"><input name="emailid" type="text" id="emailid"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td align="left" class="LabPaddingLeft">Fax</td>
              <td align="left"><input name="fax" type="text" id="fax"></td>
              <td align="left">Registration Date </td>
              <td align="left"> <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="registration_date" type="text" id="registration_date">
              <?php  //echo $this->calendar->generate(); ?></td>
            </tr>
            <tr>
<td style="height:20px;" colspan="4">
</td>
</tr>
            <tr>
              <td colspan="4" align="center">
              <center>
             <input type="submit" name="submit" value="Submit" onclick="javascript:return validateLaboratory();">
                <input type="reset" name="reset" value="Reset">
             <?php
			  		echo anchor('c=laboratory&m=index', 'Back');
			  ?>   </center>     
                </td>              
            </tr>
            <tr>
<td style="height:10px;" colspan="4">
</td>
</tr>
          </table>
</form>
</div>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
 </form> 
 </td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
function somefunction(){
 if($("#country").val() == "1"){
   $("#zone").show();
   $(".zonal").show();
   $(".st").show();
   $("#state").show();
   $(".space").hide();
 }else{
   $("#zone").hide();
   $("#state").hide();
    $(".zonal").hide();
    $(".st").hide();
    $(".space").show();
    
    
 }
}


</script>
<!--
$(function(){
    $('#country').change(function(){
       var opt = $(this).val();
        if(opt == '1'){
            $('#zone').hide();
            $('#state').hide();
        }else{
            $('#zone').show();
            $('#state').show();
        }
    });
});-->