<?php

class searchlab_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function search($limit) {

    }

    public function get_city($stateID=0,$id=0) {
        $this->db->select('id,name');
        $this->db->from('cities');
        $searchArr=array();
        if($id>0){
            $searchArr['id']=$id;
        }
        if($stateID>0){
            $searchArr['stateid']=$stateID;
        }
        $this->db->where($searchArr);
        $query = $this->db->get();
        return $query->result_array();
    }



}
