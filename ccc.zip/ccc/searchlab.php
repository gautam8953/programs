<?php

class Searchlab extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('search_model');
        $this->load->model('searchlab_model');
        $this->load->model('laboratory_model');
        $this->load->model('certificate_model');
        $this->load->library('dropdown');
    }

    public function index() {
        $this->load->model('zone_model');
        $data=array();
        $data['country'] = $this->laboratory_model->get_country();
        $seachData=array();            
        if(isset($_POST['search-form'])){
            //$data['state'] = $this->search_model->get_state(51);
            //$data['city'] = $this->searchlab_model->get_city(2,5);
        }
        $data['zone'] = $this->dropdown->zoneDropDwon('zone', 'zone', '', '', '');
        //$data['zone'] = $this->zone_model->selectAllZone('', '');
        $data['natureoflab'] = $this->dropdown->natureoflabDropDwon('natureoflab', 'natureoflab', '', '', '');
        $data['facilitydropdown'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id', 'getFieldListPro(this.value)', '', '');
        $data['operationat'] = $this->dropdown->operationAtDropDwon('operationat[]', 'operationat', '', '', '');

        $data=$data+$seachData;        
        //$data['natureoflab'] = $this->dropdown->natureoflabDropDwon('natureoflab', 'natureoflab', '', '', '');

        //echo "<pre>"; print_r($data['zone']); echo "</pre>";
        $this->load->view('searchlab/index', $data);

    }



}
