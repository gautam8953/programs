$(document).ready(function(){

    if($('#anextureID').val()!=''){
        var anextureID=$('#anextureID').val();
        var params={};
        var urlNew=pageMainUrl+'Apianexture/anextureEdit/'+anextureID;
        params['device']='web';
        params['csrf_token']=$.cookie("csrf_cookie");
        $.ajax({
            url: urlNew, 
            data: params, 
            type: 'POST', 
            dataType: 'json', 
            success: function(result){
                if(result.code=='1'){
                    $('#submitDate').val(result.data.submitDate);
                    $('#checklist_1').val(result.data.checklist_1);
                    $('#checklist_2').val(result.data.checklist_2);
                    $('#checklist_3').val(result.data.checklist_3);
                    $('#checklist_4').val(result.data.checklist_4);
                    $('#checklist_5').val(result.data.checklist_5);
                    $('#checklist_6').val(result.data.checklist_6);
                    $('#checklist_7').val(result.data.checklist_7);
                    $('#checklist_8').val(result.data.checklist_8);
                    $('#checklist_9').val(result.data.checklist_9);
                    $('#checklist_10').val(result.data.checklist_10);
                    $('#checklist_11').val(result.data.checklist_11);
                    $('#checklist_12').val(result.data.checklist_12);
                    $('#checklist_13').val(result.data.checklist_13);
                    $('#checklist_14').val(result.data.checklist_14);
                    $('#checklist_15').val(result.data.checklist_15);
                    $('#checklist_16').val(result.data.checklist_16);
                    $('#checklist_17').val(result.data.checklist_17);
                    $('#checklist_18').val(result.data.checklist_18);
                    $('#checklist_19').val(result.data.checklist_19);
                    $('#checklist_20').val(result.data.checklist_20);
                    $('#search_state').val(result.data.StateID);
                    $('#search_state').selectpicker('refresh');
                    change_state();
                    $('#search_district').val(result.data.DistrictID);
                    $('#search_district').selectpicker('refresh');
                    change_district();
                    $('#facilityName').val(result.data.FacilityID);
                    $('#facilityName').selectpicker('refresh');
                    change_facility();
                }
            }
        });        
    }

    $('#assesmentForm').submit(function() {
        var btn = $(this).find("input[type=submit]:focus" ).val();
        $(this).ajaxSubmit({
          beforeSubmit:  showRequest,
          success: showResponse,
          type: 'POST',
          dataType: 'json',
          data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie"),'btn':btn}
        });
        return false; 
    }); 

    $('.selectpicker').selectpicker('refresh');
});

function showResponse(responseText, statusText, xhr, $form)  {
    $("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
    swal(responseText.msg).then((value) => {
        if(responseText.sts=='0'){
            window.location.href = pageMainUrl+"anexture/index";
        } else {
            //window.location.replace(window.location.href);
        }
    });

}
function showRequest(formData, jqForm, options) {
    var check='0';
    $('#assesment').prop('disabled',true);
    if($('#submitDate').val()=='' || $('#submitDate').val()=='undefined'){
      $('#submitDate').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#submitDate').closest('.form-group').removeClass('has-error');
    }
    if(check!='0'){
      $('#assesment').prop('disabled',false);
      return false;
    }
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    return true; 
}



function change_district(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType']='facility';
    params['searchData']=$('#search_district').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/getSearchOptions', 
        data: params, 
        type: 'POST', 
        async:false,
        dataType: 'json', 
        success: function(result){
            $('#facilityName').html('<option value="">Select Facility</option>');
            if(result.data){
                if(parseInt(result.data.length)>0){
                    $.each(result.data,function(key,val){
                        $('#facilityName').append('<option value="'+val.UserID+'">'+val.FacilityName+'</option>');
                    });
                    $('#facilityName').selectpicker('refresh');
                }                
            }
            $('#facilityName').selectpicker('refresh');
        }
    });
}

function change_state(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType']='district';
    params['searchData']=$('#search_state').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/getSearchOptions', 
        data: params, 
        type: 'POST',
        async:false, 
        dataType: 'json', 
        success: function(result){
            $('#search_district').html('<option value="">Select District</option>');
            if(parseInt(result.data.length)>0){
                $.each(result.data,function(key,val){
                    $('#search_district').append($("<option></option>").attr("value",val.DistrictID).text(val.DistrictName));
                });
            }
            $('#facilityName').html('<option value="">Select Facility</option>');
            $('#search_district').selectpicker('refresh');
        }
    });    
}

function change_facility(ths){
    $('#facilityName').selectpicker('refresh');
}