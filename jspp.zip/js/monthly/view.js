$(document).ready(function(){      
  // Step show event
  var optionsRadio=[];
optionsRadio[0] = "No";
optionsRadio[1] = "Yes";
optionsRadio[2] = 'In progress';
  $("#smartwizard").on("showStep", function(e, anchorObject, stepNumber, stepDirection, stepPosition) {
     if(stepPosition === 'first'){
         $(".saveBtn").hide();
         $(".saveBtn").addClass('disabled');
         $("#prev-btn").addClass('disabled');
     } else if(stepPosition === 'final'){
         $(".saveBtn").show();
         $(".saveBtn").removeClass('disabled');
         $("#next-btn").addClass('disabled');
     } else{
         $(".saveBtn").hide();
         $(".saveBtn").addClass('disabled');
         $("#prev-btn").removeClass('disabled');
         $("#next-btn").removeClass('disabled');
     }
  });

  // Toolbar extra buttons
  var btnSave = $('<button></button>').text('Save')
                                   .addClass('btn btn-success disabled saveBtn')
                                   .on('click', function(){ 
                                      save_data('save');
                                    });
                                   
  var btnDraft = $('<button></button>').text('Draft Save')
                                   .addClass('btn btn-info draftBtn')
                                   .on('click', function(){ 
                                      save_data('draft');
                                   });

  // Smart Wizard
  $('#smartwizard').smartWizard({
          selected: 0,
          theme: 'default',
          transitionEffect:'fade',
          labelFinish:'Finish',
          showStepURLhash: false,
          toolbarSettings: {toolbarPosition: 'both',
                            toolbarButtonPosition: 'end',
                            toolbarExtraButtons: []
                          },
                          anchorSettings: {
                anchorClickable: true, // Enable/Disable anchor navigation
                enableAllAnchors: true, // Activates all anchors clickable all times
                markDoneStep: true, // add done css
                enableAnchorOnDoneStep: true // Enable/Disable the done steps navigation
            },
  });

  var params={};
  params['device']='web';
  params['MonthlyID']=$('#MonthlyID').val();
  params['csrf_token']=$.cookie("csrf_cookie");
  $.ajax({
    url: pageMainUrl+'ApiMonthly/getMonthlyView', 
    data: params, 
    type: 'POST', 
    dataType: 'json', 
    success: function(result){
          if(parseInt(result.code)=='0'){
            $.each(result.data[0],function(index,val){
              if($('#'+index).hasClass('radioOpt')){
                $('#'+index).text(optionsRadio[val]);
              } else {
                $('#'+index).text(val);  
              }
            });
          }
          $('#FacilityState').text(result.FacilityDetails.StateName);
          $('#FacilityDistrict').text(result.FacilityDetails.DistrictName);
          $('#FacilityType').text(result.FacilityDetails.TypeDetailCode);
          $('#FacilityName').text(result.FacilityDetails.FacilityName);
      }
    });
  var params={};
  params['device']='web';
  params['MonthlyID']=$('#MonthlyID').val();
  params['csrf_token']=$.cookie("csrf_cookie");
  $.ajax({
    url: pageMainUrl+'ApiMonthly/getOneTime', 
    data: params, 
    type: 'POST', 
    dataType: 'json', 
    success: function(result1){
          if(parseInt(result1.code)==0 ){
            $.each(result1.data,function(index,val){
              if($('#'+index).hasClass('radioOpt')){
                $('#'+index).text(optionsRadio[val]);
              } else {
                $('#'+index).text(val);  
              }
            });
          }
      }
    });

});



 

