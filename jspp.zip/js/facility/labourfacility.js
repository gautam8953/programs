$(document).ready(function(){
	var params={};
	params['device']='web';
	params['csrf_token']=$.cookie("csrf_cookie");
	params['survey']='1';
	params['ansId']=$('#ansId').val();
	$.ajax({
		url: pageMainUrl+'ApiFacility/questionsAns', 
		data: params, 
		type: 'POST', 
		dataType: 'json', 
		success: function(result){
			if(result.data.category){
				$.each(result.data.category,function(index,dataVal){
					$('a[href="#step-'+index+'"]').click();
					$.each(dataVal.questions,function(indexQues,valQues){
						$('#answer_'+indexQues+'_'+valQues).attr('checked',true);
						$('#uncheckRadio_'+indexQues).show();
					});
					if(parseInt($('#step-'+index+' .quote1-full2').length)==parseInt($('#step-'+index+' input[type=radio]:checked').length)){
						$('.sw-btn-next').click();
					}
				})
			}
			if(result.data.surveyStatus=='1'){
				window.location.href=pageMainUrl+'Facility/index';
				/*$('.saveBtn').attr('disabled',true);
				$('.draftBtn').attr('disabled',true);*/
			}
		}
	});
	$('.formatDownload').click(function(){
		var params={};
		var catSelected=$('#smartwizard li').filter('.active').find('a').attr('href');
		var catSelectedArr=catSelected.split('-');
		params['device']='web';
		params['csrf_token']=$.cookie("csrf_cookie");
		params['survey']='1';
		params['catgory']=catSelectedArr[1];
		$.ajax({
			url: pageMainUrl+'facility/setFormatData', 
			data: params, 
			type: 'POST', 
			success: function(result){
				var url=pageMainUrl+'facility/surveyFormatDownload';
				window.open(url,'_blank' );
			}
		});
	});

    $('#uploaForm').submit(function() {
        $(this).ajaxSubmit({
          beforeSubmit:  showRequest,
          success: showResponse,
          type: 'POST',
          dataType: 'json',
          data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false; 
    }); 

});

function showResponse(responseText, statusText, xhr, $form)  {
    if(parseInt(responseText.code)==0){
      swal('data uploaded successfully');
      //window.location.href = pageMainUrl+"facility/index";
    } else {
    	$('.errDivUpload').append('<table id="errTableUpload"><thead><tr><th class="text-center">Reference</th><th class="text-center">question</th><th class="text-center">Answer</th></tr></thead><tbody>');
    	$.each(responseText.err,function(key,val){
          $('#errTableUpload').append('<tr><td class="text-center">'+val.A+'</td><td class="text-center">'+val.C+'</td><td class="text-center">'+val.D+'</td></tr>');
        });
    	$('.errDivUpload').append('</tbody></table>');
    }
}
function showRequest(formData, jqForm, options) { 
    var check='0';
    if($('#excelfile').val()==''){
      $('#excelfile').closest('.form-group').addClass('has-error');
      check='1';
    } else {
	    var validExts = new Array(".xlsx", ".xls", ".csv");
	    var fileExt = $('#excelfile').val();
	    fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
	    if (validExts.indexOf(fileExt) < 0) {
	      $('#excelfile').closest('.form-group').addClass('has-error');
	      check='1';
	    } else {
	  		$('#excelfile').closest('.form-group').removeClass('has-error');  	
	    }
    }        

    if(check!='0'){
      return false;
    }
    return true; 
}
function checkFile(fileobj) {
    var validExts = new Array(".xlsx", ".xls", ".csv");
    var fileExt = fileobj.value;
    fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
    if (validExts.indexOf(fileExt) < 0) {
      $(fileobj).closest('.form-group').addClass('has-error');
      return false;
    }
}