$(document).ready(function(){ 
  $('#resetForm').submit(function(){
      $(this).ajaxSubmit({
        beforeSubmit:  showRequest,
        success: showResponse,
        type: 'POST',
        dataType: 'json',
        data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
      });
      return false; 
  });
});
function showResponse(responseText, statusText, xhr, $form)  {
    if(parseInt(responseText.code)==0){
      $("#msgDiv").removeClass('alert-danger');
      $("#msgDiv").addClass('alert-success').show();
    } else {
      $("#msgDiv").removeClass('alert-success');
      $("#msgDiv").addClass('alert-danger').show();
    }    
    $("#LoginMsg").text(responseText.msg);
    setTimeout(function() { 
    if(parseInt(responseText.code)==0){
      window.location.href = pageMainUrl+"user/login";
    }
    }, 3000);

}
function showRequest(formData, jqForm, options) { 
    var check='0';
    if($('#username').val()==''){
      $('#username').closest('.form-group').addClass('has-error');
      //$('#username').css("background-color", "#ffb3b3");
      check='1';
    } else {
      $('#username').closest('.form-group').removeClass('has-error');
      //$('#username').css("background-color", "#ffffff");
    }
    if($('#password').val()==''){
      $('#password').closest('.form-group').addClass('has-error');
      //$('#password').css("background-color", "#ffb3b3");
      check='1';
    } else {
      $('#password').closest('.form-group').removeClass('has-error');
      //$('#password').css("background-color", "#ffffff");
    }
    if(check!='0'){
      return false;
    }
    $("#msgDiv").removeClass('alert-success');
    $("#msgDiv").addClass('alert-danger').show();
    $("#LoginMsg").text("Page not available");
    return false; 
}