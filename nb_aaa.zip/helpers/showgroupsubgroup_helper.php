<?php // showgroupsubgroup_helper.php
if(!defined('BASEPATH')) exit('No direct script access allowed');

function showGroupSubGroup($cid)
{
    $CI =& get_instance();
    $query = $CI->db->query("SELECT DISTINCT(csgt.group_id), gt.category_name as groupName, getGroupSubGroupName(csgt.certificate_id, csgt.group_id) As subGroupName FROM certificate_sub_group_tbl AS csgt INNER JOIN lab_category_tbl AS gt ON csgt.group_id=gt.id WHERE csgt.certificate_id=$cid");
    return $query->result_array();
 }
?>
