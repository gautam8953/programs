			<!--header-->
				<?php include 'include/header_main.php'; ?>	
			<!--top-->
			
			<!--top-->
			<!---->
						<!--content-->
			<div class="tpcontainercontent">
				<!--advert1-->
				<!---->
				
				<!--left-->
				                               <!--right-->
								
				<!--maincontent-->
		<div class="tpcontainermain bb">
					<div class="tpinner">
																		<!--<div class="clrfix"></div>-->
						
												<div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">
<tr>
		<td class="contentheading" width="100%">
		 <?php
		 if(isset($_GET['clipType']) && $_GET['clipType']=="news")
		 {
		 	   echo "News ";
		 } 
		 if(isset($_GET['clipType']) && $_GET['clipType']=="announcement")
		 {
		 	   echo "Announcement ";
		 } 
		 ?>				
					
		</td>
					</tr>
</table>

<table class="contentpaneopen" style="width:945px;" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" class="main_article">
<?php
if(count($news)>0){
?>
<table align="center" width="930px" border="1">
<tr>
<th width="35%" align="left" valign="middle" class="LaboratoryGridHead LabPaddingLeft">Head Line</th>
<th width="65%" align="left" valign="middle" class="LaboratoryGridHead LabPaddingLeft">Details</th>
<!-- 
<th width="20%" align="left" valign="middle" class="LaboratoryGridHead LabPaddingLeft">Date of Clipping</th>
-->

<?php
$i=0;
foreach ($news as $news_item){ ?>

<tr> 
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['headline'] ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['clip_detail'] ?></td>
    <!-- 
    	<td class="LabPaddingLeft" valign="top"><?php //echo $news_item['date_of_clip'] ?></td>
    -->
    </tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Record Found ";
}
if(isset($pagination) && $pagination="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>

</td>
</tr>

</table>
</div>
												
																		<div class="clrfix"></div>
					</div>
				</div>		
				<div class="clrfix"></div>
			</div> 
			
			<!--bottom-->
			
                          <!-- -->
			<!--footer-->
			<?php include 'include/footer_main.php'; ?>             
		</div>
	</div>
	</div>
</body>
</html>
