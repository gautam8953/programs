			<!--header-->
				<?php include 'include/header_main.php'; ?>	
				<script type="text/javascript">
				function open_win(eventid)
				{	
					var eid = eventid;	
					testwindow  = window.open('index.php?c=publicprotestschedule&m=view&protestid='+eid , 'mywindow', 'scrollbars=no,menubar=no,height=350,width=800,resizable=yes,toolbar=no,location=no,status=no');
					testwindow.moveTo(350, 300);  
				
				}
				</script>
			<!--top-->
			
			<!--top-->
			<!---->
						<!--content-->
			<div class="tpcontainercontent">
				<!--advert1-->
				<!---->
				
				<!--left-->
				                               <!--right-->
								
				<!--maincontent-->
		<div class="tpcontainermain bb">
					<div class="tpinner">
																		<!--<div class="clrfix"></div>-->
						
												<div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">
<tr>
		<td class="contentheading" width="100%">
				
		Proficiency Testing -> Course Schedule			
		</td>
					</tr>
</table>

<table class="contentpaneopen" style="width:945px;" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" class="main_article">
<?php
if(count($protestsch)>0){
?>
<table align="center" border="1" cellpadding="0" cellspacing="0" width="100%" class="Border">
<tr>
<td class="LaboratoryGridHead LabPaddingLeft" width="10%" valign="middle"  >&nbsp;&nbsp;Code</td>
<td class="LaboratoryGridHead LabPaddingLeft" width="50%" valign="middle"  >Program Name</td>
<td class="LaboratoryGridHead LabPaddingLeft" width="20%" valign="middle" >Last Date of Registration</td>
<td class="LaboratoryGridHead LabPaddingLeft" width="20%" valign="middle"  >Program Finish Date</td>
<?php
$i=0;
foreach ($protestsch as $protestsch_item){ ?>

<tr>	  
    <td class="LabPaddingLeft" valign="top">&nbsp;&nbsp;<?php echo $protestsch_item['code'] ?></td>
    <td class="LabPaddingLeft" valign="top">
    <a href='#' onclick='return open_win("<?php echo $protestsch_item['id']; ?>")'>
     <?php echo $protestsch_item['programe_name'] ?>
     </a>     
    </td>   
           
    <td class="LabPaddingLeft" valign="top">
    <?php 
    	//echo $protestsch_item['last_date_of_registration']; 
    	$lastregiDate = explode('-',$protestsch_item['last_date_of_registration']); 
        $lastregiDate = array_reverse($lastregiDate);
        echo $lastregiDate = implode('/',$lastregiDate);
    	
    ?>
    </td>
    <td class="LabPaddingLeft" valign="top">
    <?php     
    	//echo $protestsch_item['programme_finish_date'];
    	$pfDate = explode('-',$protestsch_item['programme_finish_date']); 
        $pfDate = array_reverse($pfDate);
        echo $pfDate = implode('/',$pfDate);
    ?>
    </td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Record Found ";
}
if(isset($pagination) && $pagination="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>

</td>
</tr>

</table>
</div>
												
																		<div class="clrfix"></div>
					</div>
				</div>		
				<div class="clrfix"></div>
			</div> 
			
			<!--bottom-->
			
                          <!-- -->
			<!--footer-->
			<?php include 'include/footer_main.php'; ?>
             
		</div>
	</div>
	</div>
</body>
</html>
