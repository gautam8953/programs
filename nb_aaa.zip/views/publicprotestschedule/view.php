<script src="js/ajax.js"></script>
<script src="js/jquery.js"></script>
<link href="../templates/mystore_plazza/css/custom.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/css.gzip.php?style=lite&amp;size=standard" type="text/css" />
<style type="text/css">
body {
	background-color:#FFF;
	margin:0 auto;
}
	
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
Proficiency Testing -> Course Schedule
</td>
</tr>
<tr>
<td style="height:5px;" colspan="4">
</td>
</tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'> Code No</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['code']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Program Name</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['programe_name']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Description</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['programe_description']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Contact Person</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['contact_person']; ?>
              </td>
            </tr>
            <tr>
              <td class='LabTdLeft' valign='top'>Field</td>
              <td class='LabTdRight' valign='top'><?php echo $labs['facilityName']; ?></td>
              <td class='LabTdLeft' valign='top'>Nodal Lab Name</td>
              <td class='LabTdRight' valign='top'><?php echo $labs['nodal_lab_name']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Discipline</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['fieldName']?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Designation</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['designation']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Contact Address</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['contact_address']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>City</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['cityName']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>State</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['stateName']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Country</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['countryName']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Pincode</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['pin']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Phone</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['phone']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Fax</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['fax']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Email ID</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $labs['emailid']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Last Date of Regn.</td>
              <td width="30%" class='LabTdRight' valign='top'>              
             <?php
              		$lastregiDate = explode('-',$labs['last_date_of_registration']); 
              		$lastregiDate = array_reverse($lastregiDate);
              		$lastregiDate = implode('/',$lastregiDate);

              		$pfDate = explode('-',$labs['programme_finish_date']); 
              		$pfDate = array_reverse($pfDate);
              		$pfDate = implode('/',$pfDate);
              ?>
              <?php echo $lastregiDate; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Program Finish Date </td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $pfDate; ?></td>
            </tr>
            <tr>
<td style="height:5px;" colspan="4">
</td>
</tr>      
</table>
