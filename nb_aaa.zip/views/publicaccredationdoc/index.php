			<!--header-->
				<?php include 'include/header_main.php'; ?>	
			<!--top-->	
			<!---->
						<!--content-->
			<div class="tpcontainercontent">
				<!--advert1-->
				<!---->
				
				<!--left-->
				                               <!--right-->
								
				<!--maincontent-->
		<div class="tpcontainermain bb">
					<div class="tpinner">
																		<!--<div class="clrfix"></div>-->
						
												<div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">
<tr>
		<td class="contentheading" width="100%">
		
					
					<?php
						if(isset($_GET['docType']) && $_GET['docType']=="newsletter")
						{
							echo "News Letter";
						}
						else if(isset($_GET['docType']) && $_GET['docType']=="both")
						{
							echo "Accreditation Documents";
						}						
						else if(isset($_GET['docType']) && $_GET['docType']=="misc")
						{
							echo "Miscellaneous Documents";
						}
						
						
					?>	
					</td>
					</tr>
</table>

<table class="contentpaneopen" style="width:945px;" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" class="main_article">
<?php
if(count($news)>0){
?>
<table align="center" width="930px" border="1">
<tr>
<td width="105" class="LaboratoryGridHead LabPaddingLeft" valign="top">Document No.</td>
<td width="328" class="LaboratoryGridHead LabPaddingLeft" valign="top">Document Title</td>
<td width="44"  class="LaboratoryGridHead LabPaddingLeft" valign="top">Issue No.</td>
<td width="77"  class="LaboratoryGridHead LabPaddingLeft" valign="top">Issue Date</td>
<td width="114" class="LaboratoryGridHead LabPaddingLeft" valign="top">Last Amendment No.</td>
<td width="112" class="LaboratoryGridHead LabPaddingLeft" valign="top">Last Amendment Date</td>
<td width="104" class="LaboratoryGridHead LabPaddingLeft" valign="top">View Document</td>
<?php
$i=0;
foreach ($news as $news_item){ ?>

<tr>	 
     <td class="LabPaddingLeft" valign="top">&nbsp;<?php echo $news_item['document_no'] ?></td>
     <td class="LabPaddingLeft" valign="top"><?php echo $news_item['document_title'] ?></td>     
     <td class="LabPaddingLeft" valign="top"><?php echo $news_item['issue_no'] ?></td>
     <td class="LabPaddingLeft" valign="top">
     <?php 
     		//echo $news_item['issue_date'];
     		$issueDate = explode('-',$news_item['issue_date']); 
       		$issueDate = array_reverse($issueDate);
            echo $issueDate = implode('/',$issueDate);
     ?>
     </td>
     <td class="LabPaddingLeft" valign="top"><?php echo $news_item['last_amendment_no'] ?></td>
     <td class="LabPaddingLeft" valign="top">
     <?php 
     	if($news_item['last_amendment_date']=="0000-00-00")
     	{
     		echo "";
     	}
     	else 
     	{
     		//echo $news_item['last_amendment_date']; 
     		$lastamdmtDate = explode('-',$news_item['last_amendment_date']); 
       		$lastamdmtDate = array_reverse($lastamdmtDate);
            echo $lastamdmtDate = implode('/',$lastamdmtDate);
     	}
     ?>
     </td> 
     <td class="LabPaddingLeft" valign="top"> 
      <?php
        $doctype= $news_item['document_type'];
        $fileName = $news_item['document_file_name'];
      	$path = "././uploads/".$news_item['document_file_name']; 
      	if($fileName!="")
      	{
      ?>
      		 <!-- <a href="<?php //echo $path; ?>"; target='_blank'>  -->
		     <a href='././file_download.php?filename=<?php echo $fileName; ?>' target="_blank">
		     <?php
		     if($doctype=="free")
		     {
		     	echo "Free Download";
		     } 
		     if($doctype=="paid")
		     {
		     	echo "Paid Document";
		     }
		    if($doctype=="newsletter")
		     {
		     	echo "News Letter Document";
		     }
		     if($doctype=="misc")
		     {
		     	echo "Miscellaneous Document";
		     }     
		     ?>
		     </a>
      <?php 
      	}
      ?>		            
      </td>       
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Record Found ";
}
if(isset($pagination) && $pagination="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>

</td>
</tr>

</table>
</div>
												
																		<div class="clrfix"></div>
					</div>
				</div>		
				<div class="clrfix"></div>
			</div> 
			
			<!--bottom-->
			
                          <!-- -->
			<!--footer-->
			<?php include 'include/footer_main.php'; ?>
             
		</div>
	</div>
	</div>
</body>
</html>
