
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add Event Type</td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=eventtype&m=create">Create Event Type</a>
</td>
</tr>
<tr>
<td>
<?php
if(count($eventtype)>0){
?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="Border">
<tr>
<td class="LaboratoryGridHead LabPaddingLeft">Si No</td>
<td class="LaboratoryGridHead ">Event Type Name</td>
<td class="LaboratoryGridHead ">Action</td>
<?php
$i=0;
foreach ($eventtype as $eventtype_items){ ?>
<tr>
	<td class="LabPaddingLeft"><?php echo ++$i;?></td>
    <td><?php echo $eventtype_items['event_type_name'] ?></td>   
    <td><a href="index.php?c=eventtype&m=edit_type_type&id=<?php echo $eventtype_items['id'];?>">Edit</a>|
    <a href="index.php?c=eventtype&m=delete_event_type&id=<?php echo $eventtype_items['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this ?')"
    >Delete</a>
</td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Event Type Found ";
}
if(isset($pagination) && $pagination=="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>

</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>