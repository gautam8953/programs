
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Manage Facility</td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=operationat&m=create">Add Facility</a>
</td>
</tr>
<tr>
<td>
<div style="overflow:auto; width:930px;">
<?php
if(count($operationat)>0){
?>
<table align="center" border="1" cellpadding="0" cellspacing="0" width="100%">
<tr>
<!-- <td class="LaboratoryGridHead LabPaddingLeft">Si No</td>  -->
<td width="500px" class="LaboratoryGridHead LabPaddingLeft" >Facility Name</td>
<td width="500px" class="LaboratoryGridHead LabPaddingLeft" >Action</td>
<?php
$i=0;
foreach ($operationat as $operationat_items){ ?>
<tr>
	<!-- <td class="LabPaddingLeft"><?php //echo ++$i;?></td>  -->
    <td class="LabPaddingLeft"><?php echo $operationat_items['operation_name'] ?></td>   
    <td class="LabPaddingLeft"><a href="index.php?c=operationat&m=edit_operationat&id=<?php echo $operationat_items['id'];?>">Edit</a>|
    <a href="index.php?c=operationat&m=delete_operationat&id=<?php echo $operationat_items['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this ?')"
    >Delete</a>
</td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Record Found ";
}
if(isset($pagination) && $pagination=="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>