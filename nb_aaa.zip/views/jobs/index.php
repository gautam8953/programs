
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Manage Job Posting</td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=jobs&m=create">Add Job Posting</a>
</td>
</tr>
<tr>
<td>
<?php

if(count($news)>0){
?>
<div style="overflow:auto; width:930px;">
<table align="center" border="1" cellpadding="0" cellspacing="0" width="100%">
<tr>
<!-- <td class="LaboratoryGridHead LabPaddingLeft" style="width:5%">Si No</td>  -->
<td class="LaboratoryGridHead LabPaddingLeft" style="width:24%">Job Title</td>
<td class="LaboratoryGridHead LabPaddingLeft" style="width:24%">Contact Person</td>
<td class="LaboratoryGridHead LabPaddingLeft" style="width:13%">Job Desc. Doc</td>
<td class="LaboratoryGridHead LabPaddingLeft" style="width:13%">Application Doc</td>
<td class="LaboratoryGridHead LabPaddingLeft" style="width:16%">Last Date For Apply</td>
<td class="LaboratoryGridHead LabPaddingLeft" style="width:10%">Action</td>
<?php
$i=0;
foreach ($news as $news_item){ ?>

<tr>
	<!-- <td class="LabPaddingLeft" valign="top"><?php //echo ++$i;?></td>  -->
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['job_titile'] ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['contact_person'] ?></td>
    <td class="LabPaddingLeft" valign="top">
    <?php
    	$jobfileName = $news_item['job_description_file_name'];
      	$path = "././uploads/".$news_item['job_description_file_name']; 
    ?>  
    
    <a href='././file_download.php?filename=<?php echo $jobfileName; ?>' target="_blank">
    View Document</a>   
    </td>
    <td class="LabPaddingLeft" valign="top">
    <?php
    	$appfileName = $news_item['uploaded_application_name'];
      	$path = "././uploads/".$news_item['uploaded_application_name'];
    ?>  
    <a href='././file_download.php?filename=<?php echo $appfileName; ?>' target="_blank">
    View Document
    </a>
    </td>
    <td class="LabPaddingLeft" valign="top">
    <?php 
    		//echo $news_item['lastdateofapply'];             		
            $applylastDate = explode('-',$news_item['lastdateofapply']); 
            $applylastDate = array_reverse($applylastDate);
            echo $applylastDate = implode('/',$applylastDate); 
    ?>
    </td>
    <td class="LabPaddingLeft" valign="top"><a href="index.php?c=jobs&m=editjob&id=<?php echo $news_item['id'];?>">Edit</a>|
    <a href="index.php?c=jobs&m=deletejob&id=<?php echo $news_item['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete it ?')"
    >Delete</a>
</td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Job Posting Found ";
}
if(isset($pagination) && $pagination=="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>