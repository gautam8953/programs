<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){
                //For date of birth
                $('#postingdate').datepicker({ yearRange: '1930:2020' } );
                $('#lastdateofapply').datepicker({ yearRange: '1930:2020' } );
            });
</script>
<?php //echo validation_errors(); ?>
<?php echo form_open_multipart('c=jobs&m=create') ?>


<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add Jobs Posting</td>
</tr>
<tr><td style="height:15px;"></td></tr>
<tr>
<td>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
Add Jobs Posting
</td>
</tr>
<tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Job Title *</td>
              <td width="30%" align="left"><input name="job_titile" type="text" id="job_titile"></td>
              <td width="20%" align="left">Job Description Document *</td>
              <td width="30%" align="left"><input name="jobdesc" type="file" id="jobdesc"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Contact Person *</td>
              <td width="30%" align="left"><input name="contact_person" type="text" id="contact_person"></td>
              <td width="20%" align="left">Designation *</td>
              <td width="30%" align="left"><input name="designation" type="text" id="designation"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Email ID </td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="emailid" type="text" id="emailid"></td>
              <td width="20%" align="left">Postting Date </td>
              <td width="30%" align="left"><input name="postingdate" type="text" id="postingdate">
			</td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Last Date To Apply * </td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
             <input name="lastdateofapply" type="text" id="lastdateofapply"></td>
              <td width="20%" align="left">Application Document * </td>
              <td width="30%" align="left"><input name="applicationdoc" type="file" id="applicationdoc"> </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td colspan="4" align="center">
              <center>
              <input type="submit" name="submit" value="Upload" onclick="javascript:return validateJobPosting();">              
                
                <input type="reset" name="reset" value="Reset" >
                
                <?php
			  		echo anchor('c=jobs&m=index', 'Back'); 
			    ?>         </center>     
                </td>              
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
          </table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>












