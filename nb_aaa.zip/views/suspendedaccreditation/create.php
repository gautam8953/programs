<script type="text/javascript" src="js/ajax.js"></script>
<?php //echo validation_errors(); ?>
<?php echo form_open_multipart('c=suspendedaccreditation&m=create') ?>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add Suspended Accreditation</td>
</tr>
<tr>
<td style="height:15px;">
</td>
</tr>
<tr>
<td>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
Add Suspended Accreditation
</td>
</tr>
<tr>
<td style="height:5px;" colspan="4">
</td>
</tr>
			<!-- 
		            <tr>
		              <td width="20%" align="left" class="LabPaddingLeft">Lab Registration Code</td>
		              <td width="30%" align="left">
		              <input type="text" name="lab_registration_code" id="lab_registration_code" value="" />             
		              </td>
		              <td width="50%" colspan="2">&nbsp;</td>             
		            </tr>             
		            <tr>
		             <td style="height:5px;" colspan="4">&nbsp;</td>
		            </tr>
            -->
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Certificate Number</td>
              <td width="30%" align="left">
              <?php echo $certificate_no; ?>
                      
              </td>
              <td width="50%" colspan="2">&nbsp;</td>             
            </tr>    
            
          <tr>
             <td style="height:5px;" colspan="4">&nbsp;</td>
            </tr>
            
             <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Select Lab</td>
              <td width="30%" align="left">
              <div id="laboratoryList">
              <?php echo $lab_names; ?>   
              </div>  
              </td>
              <td width="50%" colspan="2">&nbsp;</td>             
             </tr> 
             
            <tr>
             <td style="height:5px;" colspan="4">&nbsp;</td>
            </tr>
             
             <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Field</td>
              <td width="30%" align="left">
              <?php echo $facilitydropdown;?>
              </td>
              <td width="50%" colspan="2">&nbsp;</td>             
             </tr> 
             
            <tr>
             <td style="height:5px;" colspan="4">&nbsp;</td>
            </tr>
            
             <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Discipline</td>
              <td width="30%" align="left">
              <div id='field'>
              <select name="field_id" id="field_id" style="width:150px;">
              <option value="-1">Please Select</option>
              </select>            
              </div>
              </td>
              <td width="50%" colspan="2">&nbsp;</td>             
             </tr>
             
            
            <tr>
             <td style="height:5px;" colspan="4">&nbsp;</td>
            </tr>
                        
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Remark</td>
              <td width="30%" align="left">
              <textarea rows="3" cols="26" name="remark" id="remark"></textarea>
              </td>
              <td width="50%" colspan="2">&nbsp;</td>             
            </tr>
            
          <tr>
             <td style="height:5px;" colspan="4">&nbsp;</td>
         </tr>            
            <tr>
<td style="height:5px;" colspan="4">
</td>
</tr>
            <tr>              
              <td>&nbsp;</td>
              <td colspan="2" align="left">             
              <input type="submit" name="submit" value="Submit" onclick="javascript:return validatelabAccreditationUnderAbeyance();">              
              <input type="reset" name="reset" value="Reset" >         
                <?php
			  		echo anchor('c=suspendedaccreditation&m=index', 'Back'); 
			    ?>
                </td>
               <td>&nbsp;</td>   
            </tr>
            
     <tr>

</td>
</tr>
          </table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>












