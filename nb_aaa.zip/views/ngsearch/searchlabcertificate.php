<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<style>
.table-setting {
    margin-bottom: 15px;
    margin-left: 9px;
    margin-right: 9px;
}
</style>
<script src="js/ajax.js"></script>
<script src="js/jquery.js"></script>
<link href="../templates/mystore_plazza/css/custom.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/css.gzip.php?style=lite&amp;size=standard" type="text/css" />

<?php echo form_open_multipart('c=certificate&m=view') ?>
<table width="700px"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="middle">	      
	<table align="center" width="100%" border="1" cellspacing="0" cellpadding="0" style="background:#ffffff;">	
    <tr>
    <td width="690px" class="LaboratoryGridHead LabPaddingLeft">Certificate</td></tr>
	<tr>
	<td width="690px" align="center" valign="top">
	<?php	
		//print_r($certificatedata);
		if(count($certificatedata)>0)
		{		
			$subgroustr = "";
			$i=0; $cnt=0;
			//print_r($certificatedata);
			echo '<table style="margin-left: 1cm;">';
			echo '<tr> <th align="left"><font size="2">Lab Name&nbsp;:&nbsp;</font></th> <th align="left">' . $certificatedata[0]['lab_name'] . '</th> </tr>';
			echo '<tr> <th valign="top"><font size="2">Address&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;</font></th> <th align="left">';
				$address = $certificatedata[0]['lab_address'];
				$city = $certificatedata[0]['City'];
				$state = $certificatedata[0]['State'];
				$country = $certificatedata[0]['Country'];
				$pincode = $certificatedata[0]['pincode'];
				
				if(!empty($address) && $address != 'NULL')
					echo $address.'<br/>';
				
				if(!empty($city) && $city != 'NULL')
					echo $city . ',';
				if(!empty($pincode) && $pincode != 'NULL')
					echo ' Pin - ' . $pincode.'<br/>';
				
				if(!empty($state) && $state != 'NULL')
					echo $state.' , ';
				if(!empty($country) && $country != 'NULL')
					echo $country;
			echo '</th></tr>';
			echo '</table>';
			
			//echo "&nbsp;&nbsp;&nbsp;<font size='2'><b>Lab Name &nbsp;&nbsp; - &nbsp;&nbsp; ".$certificatedata[0]['lab_name']."</b></font><br/>";
			
			foreach($certificatedata as $cdata)
			{
				$fileName = $cdata['certificate_file'];				
				$issueDate = explode('-',$cdata['issue_date']); 
		        $issueDate = array_reverse($issueDate);
		        $issueDate = implode('/',$issueDate);
		        		        
		        $expiryDate = explode('-',$cdata['expiry_date']);
		        $expiryDate = array_reverse($expiryDate);
		        $expiryDate = implode('/',$expiryDate);
				
				$extendDate = explode('-',$cdata['extend_date']);
		        $extendDate = array_reverse($extendDate);
		        $extendDate = implode('/',$extendDate);
				$extendDate = (empty($extendDate) || $extendDate==='00/00/0000' ) ? '-' : $extendDate;

		        echo "<table border='1' width='900px' cellpadding='0' cellspacing='0'>
		        	  <tr>
		              <td align='center'>";
				echo "<table width='900px' border='0' cellspacing='0' cellpadding='0'>";
				/*
				if($i==0)
				{
					echo "<tr>
						   <td  width='150px' class='LabTdLeft' valign='top'>Lab Name </td>   
						   <td  width='150px' class='LabTdRight' valign='top' colspan='3'>$cdata[lab_name]</td>
							
						  </tr>";
				}
				else 
				{
					echo "<tr><td height='10px' colspan='4'>&nbsp;</td></tr>";
				}
				*/
				echo "<tr>
					    <td width='125px' class='LabTdLeft' valign='top'>Field</td>
					    <td width='125px' class='LabTdRight' valign='top'>$cdata[facilityName]</td>
					    <td width='125px' align='left' valign='top'><font color='#666666'><b>Discipline</b></font></td>
					    <td width='125px' class='LabTdRight' valign='top'>$cdata[discipline_name]</td>
  					  </tr>
					  <tr>
					    <td class='LabTdLeft' valign='top'>Certificate No. </td>
					   <td class='LabTdRight' valign='top'>
					    <a href='././file_download.php?filename=$fileName' target='_blank'>
					   	$cdata[certificate_no]</a>
					    </td>
					   <td class='LabTdLeft' valign='top'>&nbsp;</td>
					    <td class='LabTdRight' valign='top'>&nbsp;</td>
  						</tr>
					  <tr>
					    <td class='LabTdLeft' valign='top'>Issue Date</td>
					   <td class='LabTdRight' valign='top'>$issueDate</td>
					   <td align='left' valign='top'><font color='#666666'><b>Valid Upto</b></font></td>
					    <td class='LabTdRight' valign='top'>$expiryDate</td>
						
  					</tr>	
					<tr> <td  class='LabTdLeft' align='left' valign='top'><font color='#666666'><b>Extend Upto</b></font></td>
					    <td class='LabTdRight' valign='top'>$extendDate</td> </tr>
					</table>";	
					   	$i = $i+1;					
			echo "<table width='600px' border='1px' cellspacing='0' cellpadding='0' class='table-setting'>							 
						    <tr>
							<td width='300px' class='LabTdLeft' valign='top'>Discipline </td>
						    <td width='300px' class='LabTdLeft' valign='top'>Group </td>
						    <td width='300px' class='LabTdLeft' valign='top'>Sub Group</td>
						    </tr>";	
            /*							
			for($b=0;$b<count($gnsdata);$b++)
			{
				$data = $gnsdata[$b];
				for($c=0;$c<count($data);$c++)
				{
					 $certificateid = $data[$c]['certificate_id'];
					 if($certificateid==$cdata['cid'])
					 {					 		            
					     $subGroup = explode(",",$data[$c]['subGroupName']);
					    $groupName = $data[$c]['groupName'];
					    echo  "<tr>
							   <td class='LabTdLeft' valign='top'>".$groupName."</td>
							   <td align='left' valign='top'>";					        					    
							   for($y=0;$y<count($subGroup);$y++)
							   {
									 echo $subGroup[$y];	
							   }
					echo "</td></tr>
						  <tr>
						  <td width='300px' class='LabTdLeft' valign='top'>&nbsp;</td>
						  <td width='300px' align='left' valign='top'>&nbsp;</td>
						  </tr>"; 
					 }				
				}
			}	
			*/
			foreach($gnsdata[$cnt] as $datum) {
				echo "<tr>
						  <td align='left' style='padding-left: 0.2cm;' valign='top'>".$datum['Discipline']."</td>
						  <td align='left' style='padding-left: 0.2cm;' valign='top'>".$datum['Groupname']."</td>
						  <td align='left' style='padding-left: 0.2cm;' valign='top'>".$datum['Subgroup']."</td>
				     </tr>"; 
			}
			 echo "</table>";			 
			 echo "</td></tr><br/></table>";
			 $cnt++;
			}			
			?>		
	<?php 
		}
	?>
	<br/>
	</td>
	</tr>	
	</table>
	</td>
  </tr>
</table>
</form>
</html>