			<!--header-->
				<?php include 'include/header_main.php'; ?>	
			<!--top-->
			<!---->
						<!--content-->
			<div class="tpcontainercontent">
				<!--advert1-->
				<!---->
				
				<!--left-->
				                               <!--right-->
								
				<!--maincontent-->
		<div class="tpcontainermain bb">
					<div class="tpinner">
																		<!--<div class="clrfix"></div>-->
						
												<div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">
<tr>
		<td class="contentheading" width="100%">
					Lab Accreditation Under Abeyance		</td>
					</tr>
</table>

<table class="contentpaneopen" style="width:945px;" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" class="main_article">
<?php
if(count($laccua)>0){
?>
<table align="center" border="1" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="20%" class="LaboratoryGridHead LabPaddingLeft">Registration Code</td>
<td width="40%" class="LaboratoryGridHead LabPaddingLeft">Lab Name</td>
<td width="20%" class="LaboratoryGridHead LabPaddingLeft">Certificate Number</td>
<td width="20%" class="LaboratoryGridHead LabPaddingLeft">Remark</td>
<?php
$i=0;
foreach ($laccua as $laccua_item){ ?>

<tr>	
    <td class="LabPaddingLeft" valign="top"><?php echo $laccua_item['lab_registration_code'] ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $laccua_item['lab_name'] ?></td>    
    <td class="LabPaddingLeft" valign="top"><?php echo $laccua_item['certificate_no'] ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $laccua_item['remark'] ?></td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Record Found ";
}
if(isset($pagination) && $pagination="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>

</td>
</tr>

</table>
</div>
												
																		<div class="clrfix"></div>
					</div>
				</div>		
				<div class="clrfix"></div>
			</div> 
			
			<!--bottom-->
			
                          <!-- -->
			<!--footer-->
			<?php include 'include/footer_main.php'; ?>             
		</div>
	</div>
	</div>
</body>
</html>
