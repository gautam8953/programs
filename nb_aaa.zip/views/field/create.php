<h2>Create a Lab Field</h2>
<?php echo validation_errors(); ?>
<?php echo form_open('c=field&m=create') ?>
	<label for="title">Field Name</label>
	<input type="text" name="field_name" id="field_name" /><br />    
    <label for="title">Facility Name</label>
    <?php echo $facilitydropdown;?><br />
	<input type="submit" name="submit" value="Create Field" />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="reset" name="reset" value="Reset">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php
			  	echo anchor('c=field&m=index', 'back');
	?>
</form>
