<h2 align="center">Lab Field</h2>
<h3 align="center"><a href="index.php?c=field&m=create">Create Field</a></h3>
<?php

if(count($fields)>0){
?>
<table align="center" border="1">
<tr>
<th>Si No</th>
<th>Field Name</th>
<th>Facility Name</th>
<th>Action</th>
<?php
$i=0;
foreach ($fields as $fields_item){ ?>

<tr>
	<td><?php echo ++$i;?></td>
    <td><?php echo $fields_item['field_name'] ?></td>
    <td><?php echo $fields_item['facility_name'] ?></td>    
    <td><a href="index.php?c=field&m=editfield&id=<?php echo $fields_item['id'];?>">Edit</a>|
    <a href="index.php?c=field&m=deletefield&id=<?php echo $fields_item['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this subgroup ?')"
    >Delete</a>

</td>
</tr>
<?php
}
?>

</table>
<?php
}else{
	echo "No Field Found ";
}
if(isset($pagination) && $pagination=="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>