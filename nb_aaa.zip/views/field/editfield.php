<h2>Edit a Lab Subgroup</h2>

<?php echo validation_errors(); ?>

<?php echo form_open('c=field&m=editfield&id='.$_GET['id']) ?>

	<label for="title">Field Name</label>
	<input type="text" name="field_name" id="field_name"  value="<?php echo $field['field_name']?>"/><br />

     <label for="title">Facility Name</label>
    <?php echo $facilitydropdown?> <br/>

	<input type="submit" name="submit" value="Update Field" />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="reset" name="reset" value="Reset">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php
			  	echo anchor('c=field&m=index', 'back');
	?>

</form>
