<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){
                //For date of birth
                $('#account_expiry_date').datepicker({ yearRange: '1930:2020' } );
            });
</script>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Edit Assessor</td>
</tr>
<tr>
<td class="LabAlighRight">

</td>
</tr>
<tr>
<td>
<?php echo validation_errors(); ?>
<?php echo form_open('c=assessor&m=edit&id='.$_GET['id']) ?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="80%">
<tr>
<td class="LabPaddingLeft" style="height:30px;"><label for="title">Assessor Name / User Name</label></td>
<td><input type="text" name="username" id="username" value="<?php echo $assessor['username']; ?>" /></td>
</tr>
 
<tr>
<td class="LabPaddingLeft" style="height:30px;"><label for="title">Assessor Code</label></td>
<td><input type="text" name="assessor_code" id="assessor_code" value="<?php echo $assessor['assessor_code']; ?>" /></td>
</tr>

<tr>
<td class="LabPaddingLeft" style="height:30px;"><label for="title">Registration Code</label></td>
<td><input type="text" name="registration_code" id="registration_code" value="<?php echo $assessor['registration_code']; ?>" /></td>
</tr>

<tr>
<td class="LabPaddingLeft" style="height:30px;"><label for="title">Account Expiry Date</label></td>
<td>
<link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
         <?php
					$accountExpiryDate = explode('-',$assessor['account_expiry_date']); 
              		$accountExpiryDate = array_reverse($accountExpiryDate);
              		$accountExpiryDate = implode('-',$accountExpiryDate);
         
         ?>
<input type="text" name="account_expiry_date" id="account_expiry_date" value="<?php echo $accountExpiryDate; ?>" />
</td>
</tr> 
    <tr>
    <td></td>
    <td align="left" style="height:30px;">
	<input type="submit" name="submit" value="Submit" onclick="javascript:return validateAssessorForm();" />
	<input type="reset" name="reset" value="Reset">
    <?php
			  	echo anchor('c=assessor&m=index', 'Back');
	?>
</td>
</tr>
</table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>