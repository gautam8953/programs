<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){
                //For date of birth
                $('#account_expiry_date').datepicker({ yearRange: '1930:2020' } );
            });
        </script>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add Assessor</td>
</tr>
<tr>
<td class="LabAlighRight">

</td>
</tr>
<tr>
<td>
<?php //echo validation_errors(); ?>
<?php echo form_open('c=assessor&m=create') ?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="80%">
<tr>
<td class="LabPaddingLeft" style="height:30px;"><label for="title">Assessor Name / User Name</label></td>
<td><input type="text" name="username" id="username" /></td>
</tr>
 
<tr>
<td class="LabPaddingLeft" style="height:30px;"><label for="title">Assessor Code</label></td>
<td><input type="text" name="assessor_code" id="assessor_code" /></td>
</tr>

<tr>
<td class="LabPaddingLeft" style="height:30px;"><label for="title">Registration Code</label></td>
<td><input type="text" name="registration_code" id="registration_code" /></td>
</tr>

<tr>
<td class="LabPaddingLeft" style="height:30px;"><label for="title">Account Expiry Date</label></td>
<td>
<link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
<input type="text" name="account_expiry_date" id="account_expiry_date" />
</td>
</tr> 
    <tr>
    <td></td>
    <td align="left" style="height:30px;">
	<input type="submit" name="submit" value="Submit" onclick="javascript:return validateAssessorForm();" />
	<input type="reset" name="reset" value="Reset">
    <?php
			  	echo anchor('c=assessor&m=index', 'Back');
	?>
</td>
</tr>
</table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
