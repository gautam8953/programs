<?php
session_start();
if(isset($_POST['submit'])&& $_POST['submit']=="Log In")
{
	$con = mysql_connect('localhost','root','');
	mysql_select_db('nablnew',$con);
	$username = $_POST['username'];
	$password = $_POST['password'];
	$sql = "SELECT * FROM jos_assessor_tbl where username=\"$username\" AND assessor_code=\"$password\" ";
	$res = mysql_query($sql);
	if($rs=mysql_fetch_array($res))
	{
		echo $_SESSION['assessname']= $rs['username'];
		//die();
		header("Location: http://localhost/NABL/index.php?option=com_content&view=article&id=95&Itemid=190");
	}
	
}

 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="joomla, Joomla" />
  <meta name="title" content="Mission Statement" />
  <meta name="author" content="Administrator" />
  <meta name="description" content="Joomla! - the dynamic portal engine and content management system" />
  <meta name="generator" content="" />
  <title><?php echo $title; ?></title>
  <link href="../templates/mystore_plazza/favicon.ico" rel="shortcut icon" type="image/x-icon" />
  <script type="text/javascript" src="../media/system/js/mootools.js"></script>
  <script type="text/javascript" src="../media/system/js/caption.js"></script>
  <script type="text/javascript" src="../modules/mod_tpmenu/tpmenu/dropdown/menu.js.php?animated=Fx.Transitions.Bounce.easeOut"></script><link href="../templates/mystore_plazza/css/dropdowntpmenu.css" rel="stylesheet" type="text/css" />
<link href="../templates/mystore_plazza/css/custom.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="../templates/mystore_plazza/favicon.ico" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/css.gzip.php?style=lite&amp;size=standard" type="text/css" />
<script type="text/javascript" src="../templates/mystore_plazza/scripts/js/template.js"></script>
<script type="text/javascript">
function open_win(certificateid)
{
	//alert(certificateid);
	var cid = certificateid;
	
/*window.open("index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid], _blank")
window.open('index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid]', 'mywindow', 'location=1,status=1,scrollbars=1,width=100,height=100');
*/

//alert('index.php?c=search&m=searchlabcertificate&cno='+cid);

testwindow  = window.open('index.php?c=search&m=searchlabcertificate&cno='+cid , 'mywindow', 'scrollbars=no,menubar=no,height=200,width=600,resizable=yes,toolbar=no,location=no,status=no');
testwindow.moveTo(350, 300);

   

}
</script>
</head>
<body id="tpbody" class="mainbody">
	
    <div class="top">
    <div id="tpcontainer" style="width:960px;">
		<div class="tpcontainer-inner">
			<!--header-->
			<div class="tpcontainerheader">
				<div class="tpinner">
					<div class="tpheader1"><span class="logo"><a href="../logo.php" title="" onclick="NewWindow(this.href,'Nabl-logo','290','330','no','center');return false" onfocus="this.blur()"></a></span></div>
					                                              
					<div class="clrfix"></div>
                                                  <!--<div align="right" class="homediv" ><a href="http://rvsolutions.in">Main Home</a></div>-->
					                                 <div class="tpheader3"><div id="tp-mainnavwrap"><div id="tp-mainnav" class="clearfix"><ul class="clearfix"  id="tp-cssmenu"><li class="">
<a href="../index.php?option=com_content&amp;view=frontpage&amp;Itemid=123">Home</a></li><li class="">
<a class="haschild" href="../index.php?option=com_content&amp;view=article&amp;id=99&amp;Itemid=53">About NABL</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=99&amp;Itemid=71">Mission Statement</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=98&amp;Itemid=72">Introduction</a></li><li class="">
<a href="#">Organisational Structure</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=100&amp;Itemid=73">Accreditation Schems</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=106&amp;Itemid=75">International Recognition</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=101&amp;Itemid=74">Careers</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=97&amp;Itemid=119">List of Contact Persons</a></li>
</ul></li><li class="parent">
<a class="haschild" href="../index.php?option=com_content&amp;view=article&amp;id=105&amp;Itemid=81">Training &amp; Awareness Programs</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=103&amp;Itemid=106">Introduction</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=104&amp;Itemid=107">Course Schedule</a></li>
</ul></li><li class="active parent">
<a class="haschild" href="../nabl/index.php?c=publicaccredationdoc&m=index&docType=both">Accreditation Documents</a><ul><li class="active">
<a href="../nabl/index.php?c=publicaccredationdoc&m=index&docType=newsletter">News Letters</a></li>
</ul></li><li class="">
<a href="../nabl/index.php?c=search&m=index">Laboratory Search</a></li><li class="parent">
<a class="haschild" href="../index.php?option=com_content&amp;view=article&amp;id=102&amp;Itemid=76">Proficiency Testing</a><ul><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=102&amp;Itemid=77">Introduction</a></li><li class="">
<a href="../index.php?option=com_content&amp;view=article&amp;id=107&amp;Itemid=78">Program Schedule</a></li>
</ul></li>
</ul></div></div></div>				</div>
				
                              

				
			</div>
			
			<!--top-->
			<!---->
						<!--content-->
			<div class="tpcontainercontent">
				<!--advert1-->
				<!---->
				
				<!--left-->
				                               <!--right-->
								
				<!--maincontent-->
		<div class="tpcontainermain bb">
					<div class="tpinner">
																		<!--<div class="clrfix"></div>-->
						
												<div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">
</table>


<table class="contentpaneopen" style="width:945px;" border="0" cellpadding="0" cellspacing="0">


<tr>
<td valign="top" class="main_article">

<?php //echo validation_errors(); ?>
<?php //echo form_open('c=assessor&m=loginassessors') ?>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Assessor Login</td>
</tr>
<tr><td height="30px"></td></tr>
<tr>
<td align="center">
<form action="#" name="assessorlogin" id="assessorlogin" method="post" >
<div class="div">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" valign="middle" colspan="2" height="10" >
     </td>
            </tr>
             <tr>
              <td align="center" valign="middle" colspan="2">
              <font color="red">
              <?php
              if(isset($msg) && $msg!="")              
               	echo $msg; 
               ?></font>
              </td>
            </tr>
            
            <tr>
              <td align="left" valign="middle">User Name</td>
              <td align="left" valign="middle"><input name="username" type="text" id="username" /></td>
            </tr>
            <tr>
              <td align="left" valign="middle" height="30px">Password</td>
              <td align="left" valign="middle"><input name="password" type="password" id="password" /></td>
            </tr>
            <tr>
			  <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">
              <input type="submit" name="submit" value="Log In" onclick="javascript:return validateLoginForm();" />
              </td>
            </tr>
        </table> 
        </div>
</form> 
</td>
</tr>
<tr><td height="30px"></td></tr>
<tr><td height="30px"></td></tr>
</table>
</div>
</body>
<!--sdfasdfasdf
</body>
</html>-->
</td>
</tr>

</table>
</div>
												
																		<div class="clrfix"></div>
					</div>
				</div>		
				<div class="clrfix"></div>
			</div> 
			
			<!--bottom-->
			
                          <!-- -->
			<!--footer-->
			<div class="tpcontainerbottom">
				<div class="tpcontainerbottom1">Copyright � 2012. NABL. All Rights Reserved. &nbsp;&nbsp;Powered by <a href="http://www.rvsolutions.in/" class="linkbota" target="_blank">RV Solutions Pvt. Ltd.</a></div>
		   <div class="tpcontainerbottom2"><ul class="menu"><li class="item145"><a href="../index.php?option=com_content&amp;view=article&amp;id=108&amp;Itemid=145"><span>RTI Act 2005</span></a></li><li class="item146"><a href="../index.php?option=com_content&amp;view=article&amp;id=109&amp;Itemid=146"><span>Useful Links</span></a></li><li class="item147"><a href="../index.php?option=com_content&amp;view=article&amp;id=66&amp;Itemid=147"><span>Contact Us</span></a></li><li class="item149"><a href="../index.php?option=com_content&amp;view=article&amp;id=110&amp;Itemid=149"><span>Disclaimer</span></a></li><li class="item150"><a href="../index.php?option=com_xmap&amp;sitemap=1&amp;Itemid=150"><span>Site Map</span></a></li></ul></div>				 <div class="clrfix"></div>
                <div class="moculeBanner"></div>			</div>
             
		</div>
	</div>
	</div>
</body>
</html>
