<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Assessor</td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=assessor&m=create">Add Assessor</a>
</td>
</tr>
<tr>
<td>
<?php
if(count($assessor)>0){
?>
<div style="overflow:auto; width:930px;" class="Border">
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td class="LaboratoryGridHead LabPaddingLeft">Si No</td>
<td class="LaboratoryGridHead">Assessor Name / User Name</td>
<td class="LaboratoryGridHead">Assessor Code</td>
<td class="LaboratoryGridHead">Registration Code</td>
<td class="LaboratoryGridHead">Account Expiry Date</td>
<td class="LaboratoryGridHead">Action</td>
<?php
$i=0;
foreach ($assessor as $assessor_items){ ?>
<tr>
	<td class="LabPaddingLeft"><?php echo ++$i;?></td>
    <td><?php echo $assessor_items['username'] ?></td>   
    <td><?php echo $assessor_items['assessor_code'] ?></td>  
    <td><?php echo $assessor_items['registration_code'] ?></td>  
    <td><?php echo $assessor_items['account_expiry_date'] ?></td>    
    <td><a href="index.php?c=assessor&m=edit&id=<?php echo $assessor_items['id'];?>">Edit</a>|
    <a href="index.php?c=assessor&m=delete&id=<?php echo $assessor_items['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this ?')"
    >Delete</a>
</td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Records Found ";
}
if(isset($pagination) && $pagination="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>