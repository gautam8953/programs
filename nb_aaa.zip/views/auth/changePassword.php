<?php echo validation_errors(); ?>
<?php echo form_open('c=auth&m=changePassword') ?>
<!DOCTYPE html>
<head>
<style type="text/css">
.div
{
border:1px solid #a1a1a1;
padding:20px; 
background:#eeeeee;
width:300px;
margin:0 auto;
height:auto;
border-radius:15px;
-moz-border-radius:15px; /* Firefox 3.6 and earlier */
}
</style>
<script language="JavaScript" type="text/javascript">
function compareLength()
{
	if(document.getElementById('newpassword').value!=document.getElementById('renewpassword').value)
	{
		alert('Password Doesn\'t Match');
		document.getElementById('newpassword').focus();
		return false;
	}
}
</script>
</head>
<body>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Change Password</td>
</tr>
<tr><td height="30px"></td></tr>
<tr>
<td align="center">
<div class="div">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" valign="middle" colspan="2" height="10" >
     </td>
            </tr>
             <tr>
              <td align="center" valign="middle" colspan="2">
              <font color="red">
              <?php
              if(isset($msg) && $msg!="")              
               	echo $msg; 
               ?></font>
              </td>
            </tr>
            <tr>
              <td align="left" valign="middle" height="30px">Old Password</td>
              <td align="left" valign="middle">
              <input name="oldpassword" type="password" id="oldpassword">
              </td>
            </tr>
            <tr>
              <td align="left" valign="middle" height="30px">New Password</td>
              <td align="left" valign="middle">
              <input name="newpassword" type="password" id="newpassword">
              </td>
            </tr>
            <tr>
              <td align="left" valign="middle" height="30px">Confirm New Password</td>
              <td align="left" valign="middle">
              <input name="renewpassword" type="password" id="renewpassword">
              </td>
            </tr>
            <tr>
			  <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">
              <input type="submit" name="submit" value="Update Password" onClick="return compareLength();"></td>
            </tr>
        </table> </form> 
        </div>
</td>
</tr>
<tr><td height="30px"></td></tr>
<tr><td height="30px"></td></tr>
</table>
</div>
</body>
