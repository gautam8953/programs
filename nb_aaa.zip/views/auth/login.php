<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
 <title><?php echo $title; ?></title> 
  <link href="../templates/mystore_plazza/favicon.ico" rel="shortcut icon" type="image/x-icon" />
<script type="text/javascript">
function validateLoginForm()
{
	if(document.getElementById('username').value=='')
	{
		alert('Please Enter User Name');
		document.getElementById('username').focus();
		return false;
	}
	
	if(document.getElementById('password').value=='')
	{
		alert('Please Enter Password');
		document.getElementById('password').focus();
		return false;
	}
}
</script>
  <script type="text/javascript" src="../media/system/js/mootools.js"></script>
  <script type="text/javascript" src="../media/system/js/caption.js"></script>
  <script type="text/javascript" src="../modules/mod_tpmenu/tpmenu/dropdown/menu.js.php?animated=Fx.Transitions.Bounce.easeOut"></script>
  <link href="../templates/mystore_plazza/css/dropdowntpmenu.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="../templates/mystore_plazza/favicon.ico" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/css.gzip.php?style=lite&amp;size=standard" type="text/css" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/custom.css" type="text/css" />
<script type="text/javascript" src="../templates/mystore_plazza/scripts/js/template.js"></script>

<style type="text/css"> 
.div
{
border:1px solid #a1a1a1;
padding:20px; 
background:#eeeeee;
width:300px;
margin:0 auto;
height:auto;
border-radius:15px;
-moz-border-radius:15px; /* Firefox 3.6 and earlier */
}
</style>

</head>
<center>
<body id="tpbody" class="mainbody">
    <div class="top">
    <div id="tpcontainer" style="width:960px;">
		<div class="tpcontainer-inner">
			<!--header-->
			<div class="tpcontainerheader">
				<div class="tpinner">
					<div class="tpheader1"><span class="logo"><a href="../logo.php" title="" onclick="NewWindow(this.href,'Nabl-logo','290','330','no','center');return false" onfocus="this.blur()"></a></span></div>
                    <div class="clrfix"></div>
                    <div class="tpheader3"><div id="tp-mainnavwrap">
                                                     <div id="tp-mainnav" class="clearfix">
                                                     
</div></div></div>				</div>
</div>
			
			<!--top-->

			<!---->
						<!--content-->
			<div class="tpcontainercontent">
				<!--advert1-->
				<!---->
				
				<!--left-->
                              <!--right-->
								
				<!--maincontent-->
	<div class="tpcontainermain bb">
					<div class="tpinner">
<!--<div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">

<tr>
		<td class="contentheading" width="100%">
					Laboratory			</td>

</table>-->

<table class="contentpaneopen">


<tr>
<td valign="top" class="main_article">

<?php //echo validation_errors(); ?>
<?php echo form_open('c=auth&m=login') ?>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Login</td>
</tr>
<tr><td height="30px"></td></tr>
<tr>
<td align="center">
<div class="div">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" valign="middle" colspan="2" height="10" >
     </td>
            </tr>
             <tr>
              <td align="center" valign="middle" colspan="2">
              <font color="red">
              <?php
              if(isset($msg) && $msg!="")              
               	echo $msg; 
               ?></font>
              </td>
            </tr>
            
            <tr>
              <td align="left" valign="middle">User Name</td>
              <td align="left" valign="middle"><input name="username" type="text" id="username" /></td>
            </tr>
            <tr>
              <td align="left" valign="middle" height="30px">Password</td>
              <td align="left" valign="middle"><input name="password" type="password" id="password" /></td>
            </tr>
            <tr>
			  <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">
              <input type="submit" name="submit" value="Log In" onclick="javascript:return validateLoginForm();" />
              </td>
            </tr>
        </table> 
        </div>
</form> 
</td>
</tr>
<tr><td height="30px"></td></tr>
<tr><td height="30px"></td></tr>
</table>
</div>
</body>
<!--sdfasdfasdf
</body>
</html>-->
</td>
</tr>

</table>
</div>
												
																		<div class="clrfix"></div>
					</div>
				</div>		
				<div class="clrfix"></div>
			</div> 
			
			<!--bottom-->

			
                          <!-- -->
			<!--footer-->
			<div class="tpcontainerbottom">
				<div class="tpcontainerbottom1">Copyright  2012. NABL. All Rights Reserved. &nbsp;&nbsp;Powered by <a href="http://www.rvsolutions.in/" class="linkbota" target="_blank">RV Solutions Pvt. Ltd.</a></div>
				 <div class="clrfix"></div>
             
		</div>
	</div>
	</div>
    </center>
</body>
</html>
