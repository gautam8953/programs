<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Lab Facility</td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=facility&m=create">Create New Facility</a>
</td>
</tr>
<tr>
<td>
<?php

if(count($results)>0){
?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="Border">
<tr>
<td class="LaboratoryGridHead LabPaddingLeft">Si No</td>
<td class="LaboratoryGridHead">Category Name</td>
<td class="LaboratoryGridHead">Description</td>
<td class="LaboratoryGridHead">Action</td>
<?php
$i=0;
foreach ($results as $results_item){ ?>

<tr>
	<td class="LabPaddingLeft"><?php echo ++$i;?></td>
    <td><?php echo $results_item['facility_name'] ?></td>
    <td><?php echo $results_item['facility_description'] ?></td>
    <td><a href="index.php?c=facility&m=editfacility&id=<?php echo $results_item['id'];?>">Edit</a>|
    <a href="index.php?c=facility&m=deletefacility&id=<?php echo $results_item['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this category ?')"
    >Delete</a>

</td>
</tr>
<?php
}	
?>

</table>
<?php
}else{
	echo "No Facilites ";
}
if(isset($pagination) && $pagination=="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}

 
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>