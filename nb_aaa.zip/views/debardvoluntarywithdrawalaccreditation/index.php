<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Manage Debarred Accreditation</td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=debardvoluntarywithdrawalaccreditation&m=create">Add Debarred Accreditation</a>
</td>
</tr>
<tr>
<td>
<?php

if(count($laccua)>0){
?>
<div style="overflow:auto; width:930px;">
<table align="center" border="1" cellpadding="0" cellspacing="0" width="100%">
<tr>
<!-- <td class="LaboratoryGridHead LabPaddingLeft">Si No</td>  -->
<td width="150px" class="LaboratoryGridHead LabPaddingLeft">Registration Code</td>
<td width="230px" class="LaboratoryGridHead LabPaddingLeft">Lab Name</td>
<td width="150px" class="LaboratoryGridHead LabPaddingLeft">Certificate Number</td>
<td width="150px" class="LaboratoryGridHead LabPaddingLeft">Discipline</td>
<td width="150px" class="LaboratoryGridHead LabPaddingLeft">Remark</td>
<td width="150px" class="LaboratoryGridHead LabPaddingLeft">Debarred</td>
<td width="100px" class="LaboratoryGridHead LabPaddingLeft">Action</td>
<?php
$i=0;
foreach ($laccua as $laccua_item){ ?>

<tr>
	<!-- <td class="LabPaddingLeft"><?php //echo ++$i;?></td>  -->
    <td class="LabPaddingLeft"><?php echo $laccua_item['lab_registration_code'] ?></td>
    <td class="LabPaddingLeft"><?php echo $laccua_item['lab_name'] ?></td>    
    <td class="LabPaddingLeft"><?php echo $laccua_item['certificate_no'] ?></td>
    <td class="LabPaddingLeft"><?php echo $laccua_item['discipline'] ?></td>
    <td class="LabPaddingLeft"><?php echo $laccua_item['remark'] ?></td>
	<td class="LabPaddingLeft"><?php echo $laccua_item['debarred'] ?></td>
    <td class="LabPaddingLeft"><a href="index.php?c=debardvoluntarywithdrawalaccreditation&m=edit&id=<?php echo $laccua_item['id'];?>">Edit</a>|
    <a href="index.php?c=debardvoluntarywithdrawalaccreditation&m=delete&id=<?php echo $laccua_item['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete it ?')"
    >Delete</a>
</td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Record Found ";
}
if(isset($pagination) && $pagination=="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>