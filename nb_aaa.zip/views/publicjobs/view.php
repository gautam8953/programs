<script src="js/ajax.js"></script>
<script src="js/jquery.js"></script>
<link href="../templates/mystore_plazza/css/custom.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/css.gzip.php?style=lite&amp;size=standard" type="text/css" />
<style type="text/css">
body {
	background-color:#FFF;
	margin:0 auto;
}
	
</style>
<table class="contentpaneopen" style="width:800px;" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" class="main_article">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
Careers</td>
</tr>
<tr>
<td style="height:5px;" colspan="4">
</td>
</tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Job Title</td>
              <td width="30%" align="left"><?php echo $news['job_titile']; ?></td>
              <td width="20%" align="left">Description Form</td>
              <td width="30%" align="left">
              <?php
              	$jobfileName = $news['job_description_file_name'];
		      	$desformpath = "././uploads/".$news['job_description_file_name'];
		   	  ?>  
		     <a href='././file_download.php?filename=<?php echo $jobfileName; ?>' target="_blank">
		     Download Form</a>   
              </td>
            </tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Contact Person</td>
              <td width="30%" align="left"><?php echo $news['contact_person']; ?></td>
              <td width="20%" align="left">Designation</td>
              <td width="30%" align="left"><?php echo $news['designation']; ?></td>
            </tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Email ID</td>
              <td width="30%" align="left">
              <?php echo $news['emailid']; ?></td>
              <td width="20%" align="left">Posting Date</td>
              <td width="30%" align="left"> <?php
              		$psotingDate = explode('-',$news['postingdate']); 
              		$psotingDate = array_reverse($psotingDate);
              		$psotingDate = implode('/',$psotingDate);
              		
              		$applylastDate = explode('-',$news['lastdateofapply']); 
              		$applylastDate = array_reverse($applylastDate);
              		$applylastDate = implode('/',$applylastDate); 
              		
              ?>              
             <?php 
             	if($news['postingdate']=="0000-00-00")
             	{
             		echo "";
             	}
             	else 
             	{
             		echo $psotingDate;
             	}
             ?></td>
            </tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Last Date To Apply</td>
              <td width="30%" align="left"> 
              <?php echo $applylastDate; ?></td>
              <td width="20%" align="left">Application Form </td>
              <td width="30%" align="left">
               <?php
                $appfileName = $news['uploaded_application_name'];
		      	$appformpath = "././uploads/".$news['uploaded_application_name'];
		   	   ?>  
		     <a href='././file_download.php?filename=<?php echo $appfileName; ?>' target="_blank">
		     Download Form</a>                
              </td>
            </tr>
            <tr>
<td style="height:5px;" colspan="4">
</td>
</tr>           
            <tr>
<td style="height:5px;" colspan="4">
</td>
</tr>
          </table>

</td>
</tr>
</table>
