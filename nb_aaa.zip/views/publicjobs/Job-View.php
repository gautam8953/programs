			<!--header-->
				<?php include 'include/header_main.php'; ?>	
				<script type="text/javascript">
				function open_win(jobid)
				{	
					//var jid = jobid;	
					//testwindow  = window.open('index.php?c=publicjobs&m=view&jobid='+jid , 'mywindow', //'scrollbars=no,menubar=no,height=170,width=800,resizable=yes,toolbar=no,location=no,status=no');
					//testwindow.moveTo(350, 300);  
				
				}
				</script>
			<!--top-->
			
			<!---->
						<!--content-->
			<div class="tpcontainercontent">
				<!--advert1-->
				<!---->
				
				<!--left-->
				                               <!--right-->
								
				<!--maincontent-->
		<div class="tpcontainermain bb">
					<div class="tpinner">
																		<!--<div class="clrfix"></div>-->
						
												<div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">
<tr>
					</tr>
					<tr>
		<td class="contentheading" width="100%">
				
		Home -> Careers			
		</td>
					</tr>
</table>
<table class="contentpaneopen" style="width:945px;" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" class="main_article">
	<?php echo "No Record Found "; ?>

</td>
</tr>

</table>
</div>
												
																		<div class="clrfix"></div>
					</div>
				</div>		
				<div class="clrfix"></div>
			</div> 
			
			<!--bottom-->			
                          <!-- -->
			<!--footer-->
			<?php include 'include/footer_main.php'; ?>             
		</div>
	</div>
	</div>
</body>
</html>
