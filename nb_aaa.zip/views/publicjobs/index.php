			<!--header-->
				<?php include 'include/header_main.php'; ?>	
				<script type="text/javascript">
				function open_win(jobid)
				{	
					var jid = jobid;	
					testwindow  = window.open('index.php?c=publicjobs&m=view&jobid='+jid , 'mywindow', 'scrollbars=no,menubar=no,height=170,width=800,resizable=yes,toolbar=no,location=no,status=no');
					testwindow.moveTo(350, 300);  
				
				}
				</script>
			<!--top-->
			
			<!---->
						<!--content-->
			<div class="tpcontainercontent">
				<!--advert1-->
				<!---->
				
				<!--left-->
				                               <!--right-->
								
				<!--maincontent-->
		<div class="tpcontainermain bb">
					<div class="tpinner">
																		<!--<div class="clrfix"></div>-->
						
												<div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">
<tr>
		<td class="contentheading" width="100%">
					Careers
					<br/>
					<hr>					
					Following Vaccancies Currently Exists At NABL				
		</td>
					</tr>
</table>

<table class="contentpaneopen" style="width:945px;" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" class="main_article">
<?php
if(count($jobs)>0){
?>
<table align="center" border="1" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td class="LaboratoryGridHead LabPaddingLeft" width="20%" valign="middle" >Job Title</td>
<td class="LaboratoryGridHead LabPaddingLeft" width="20%" valign="middle">Contact Person</td>
<td class="LaboratoryGridHead LabPaddingLeft" width="20%" valign="middle">Last Date</td>
<td class="LaboratoryGridHead LabPaddingLeft" width="20%" valign="middle">Application Form</td>
<td class="LaboratoryGridHead LabPaddingLeft" width="20%" valign="middle">Description Form</td>
<?php
$i=0;
foreach ($jobs as $jobs_items){ ?>

<tr>	      
    <td class="LabPaddingLeft" valign="top">
    <a href='#' onclick='return open_win("<?php echo $jobs_items['id']; ?>")'>
     <?php echo $jobs_items['job_titile'] ?>
     </a>     
    </td>   
    <td class="LabPaddingLeft" valign="top"><?php echo $jobs_items['contact_person'] ?></td>       
    <td class="LabPaddingLeft" valign="top">
    <?php 
    		//echo $jobs_items['lastdateofapply']; 
    		$applylastDate = explode('-',$jobs_items['lastdateofapply']); 
            $applylastDate = array_reverse($applylastDate);
            echo $applylastDate = implode('/',$applylastDate); 
    ?>
    </td>
    <td class="LabPaddingLeft" valign="top">
    <?php
    	$appfileName = $jobs_items['uploaded_application_name'];
      	$appformpath = "././uploads/".$jobs_items['uploaded_application_name'];
    ?>  
    <a href='././file_download.php?filename=<?php echo $appfileName; ?>' target="_blank">
    Download Form</a>    
    </td>
     <td class="LabPaddingLeft" valign="top">
    <?php
    	$jobfileName = $jobs_items['job_description_file_name'];
      	$descformpath = "././uploads/".$jobs_items['job_description_file_name'];
    ?>  
    <a href='././file_download.php?filename=<?php echo $jobfileName; ?>' target="_blank">   
    Download Form</a>
    </td>
    
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Record Found ";
}
if(isset($pagination) && $pagination="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>

</td>
</tr>

</table>
</div>
												
																		<div class="clrfix"></div>
					</div>
				</div>		
				<div class="clrfix"></div>
			</div> 
			
			<!--bottom-->			
                          <!-- -->
			<!--footer-->
			<?php include 'include/footer_main.php'; ?>             
		</div>
	</div>
	</div>
</body>
</html>
