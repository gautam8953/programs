
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add Document Type</td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=documenttype&m=create">Create Document Type</a>
</td>
</tr>
<tr>
<td>
<?php
if(count($doctype)>0){
?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="Border">
<tr>
<td class="LaboratoryGridHead LabPaddingLeft">Si No</td>
<td class="LaboratoryGridHead">Document Type Name</td>
<td class="LaboratoryGridHead ">Action</td>
<?php
$i=0;
foreach ($doctype as $doctype_items){ ?>
<tr>
	<td class="LabPaddingLeft"><?php echo ++$i;?></td>
    <td><?php echo $doctype_items['document_type_name'] ?></td>   
    <td><a href="index.php?c=documenttype&m=edit_document_type&id=<?php echo $doctype_items['id'];?>">Edit</a>|
    <a href="index.php?c=documenttype&m=delete_document_type&id=<?php echo $doctype_items['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this ?')"
    >Delete</a>
</td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Zone Found ";
}
if(isset($pagination) && $pagination=="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>