
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Create a Document Type</td>
</tr>
<tr>
<td class="LabAlighRight">

</td>
</tr>
<tr>
<td>
<?php echo validation_errors(); ?>
<?php echo form_open('c=documenttype&m=create') ?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="80%">
<tr>
<td class="LabPaddingLeft" style="height:30px;"><label for="title">Document Type Name</label></td>
<td>
<input type="text" name=document_type_name id="document_type_name"  />
</td>
	</tr>
    
    <tr>
    <td></td>
    <td align="left" style="height:30px;">
	<input type="submit" name="submit" value="Create Document Type" onclick="javascript:return validateDocumentType();" />
	<input type="reset" name="reset" value="Reset">
    <?php
			  	echo anchor('c=documenttype&m=index', 'Back');
	?>
</td>
</tr>
</table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>