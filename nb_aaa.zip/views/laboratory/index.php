<script type="text/javascript">				
				function open_lab_win(labid)
				{
					//alert(certificateid);
					var lid = labid;
					
				/*window.open("index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid], _blank")
				window.open('index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid]', 'mywindow', 'location=1,status=1,scrollbars=1,width=100,height=100');
				*/
				//alert('index.php?c=search&m=searchlabcertificate&cno='+cid);
				testwindow  = window.open('index.php?c=laboratory&m=view&lno='+lid , 'mywindow', 'scrollbars=yes,menubar=no,height=500,width=800,resizable=yes,toolbar=no,location=no,status=no');
				testwindow.moveTo(100, 100);
				}
				
</script>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Manage Laboratory</td>
</tr>

<tr>
<td align="center" valign="middle">
<br/>
<?php echo form_open('c=laboratory&m=index') ?>

<table width="600" border="0" cellspacing="5" cellpadding="5" class="Border">
  <tr>
    <td class="LaboratoryGridHead LabPaddingLeft" valign="middle" colspan="3">Search Laboratory</td>   
  </tr>
  <tr>
    <td width="200" class="LabPaddingLeft" valign="middle"><b>Lab Name</b></td>
    <td width="200" class="LabPaddingLeft" valign="middle"><b>Lab Registration Code</b></td>
    <td width="200" class="LabPaddingLeft" valign="middle">&nbsp;</td>
  </tr>
  <tr>
    <td class="LabPaddingLeft" valign="middle"><input type="text" name="labname" id="labname" /></td>
    <td class="LabPaddingLeft" valign="middle"><input type="text" name="labcode" id="labcode" /></td>
    <td class="LabPaddingLeft"  valign="middle"><input type="submit" name="submit" id="submit" value="Search" /></td>
  </tr>
  <tr>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle">&nbsp;</td>
  </tr>
  </table>
</form>
</td>
</tr>

<tr>
<td class="LabAlighRight">
<a href="index.php?c=laboratory&m=create">Add New Laboratory</a>
</td>
</tr>
<tr>
<td>
<?php
if(count($news)>0){
?>
<div style="overflow:auto; width:930px;">
<?php echo "<b>".count($total_rows)." Records Found</b>"; ?>
<table width="100%" align="center" border="1" cellpadding="0" cellspacing="0">
<tr>
<!-- <th width="5%" class="LaboratoryGridHead LabPaddingLeft">Si No</th>  -->
<th width="14%" class="LaboratoryGridHead LabPaddingLeft">Registration Code</th>
<th width="20%" class="LaboratoryGridHead LabPaddingLeft">Lab Name</th>
<th width="23%" class="LaboratoryGridHead LabPaddingLeft">Lab Address</th>
<th width="18%" class="LaboratoryGridHead LabPaddingLeft">Contact Person</th>
<th width="15%" class="LaboratoryGridHead LabPaddingLeft">Activate/Deactivate</th>
<th width="8%" class="LaboratoryGridHead LabPaddingLeft">Action</th>
<?php
$i=0;
foreach ($news as $news_item){
$labid = $news_item['id']; ?>
<tr>
	<!-- <td class="LabPaddingLeft" valign="top"><?php //echo ++$i;?></td>  -->
    <td class="LabPaddingLeft" valign="top"><?php echo "<a href='#' onClick=open_lab_win($labid)>".$news_item['lab_registration_code']."</a>"; ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['lab_name'] ?></td>    
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['lab_address'] ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['contact_person'] ?></td>        
    <td class="LabPaddingLeft" valign="top">
    <?php 
    	if($news_item['status']==0)
    	{
    		echo "<a href='index.php?c=laboratory&m=updateLabStatus&status=0&labid=$labid'>Activate</a>";
    	}
    	if($news_item['status']==1)
    	{
    		echo "<a href='index.php?c=laboratory&m=updateLabStatus&status=1&labid=$labid'>Deactivate</a>";
    	} 
    ?>
    </td>
    <td class="LabPaddingLeft" valign="top"><a href="index.php?c=laboratory&m=editlaboratory&id=<?php echo $news_item['id'];?>">Edit</a>|
    <a href="index.php?c=laboratory&m=deletelaboratory&id=<?php echo $news_item['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this category ?')"
    >Delete</a>

</td>
</tr>
<?php
}
?>

</table>
<?php
}else{
	echo "No Laboratory Found ";
}
if(isset($pagination) && $pagination=="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>