<script src="js/ajax.js"></script>
<script src="js/jquery.js"></script>
<link href="../templates/mystore_plazza/css/custom.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/css.gzip.php?style=lite&amp;size=standard" type="text/css" />
<style type="text/css">
body {	
	margin:0 auto;
	
</style>
<?php echo form_open_multipart('c=laboratory&m=view') ?>
<table width="790px"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="middle">	      
	<table width="790px" border="0" cellspacing="0" cellpadding="0" class="Border" bgcolor="#FFF">	
    <tr>
    <td class="LaboratoryGridHead LabPaddingLeft">Laboratory</td></tr>
	<tr>
	<td>
	<?php	
		//print_r($certificatedata);
		if(count($labdata)>0)
		{				
			//$i=0;
			foreach($labdata as $cdata)
			{	
				if($cdata['registration_date']=="0000-00-00")
				{
					$regsDate = "";
				}	
				else 
				{
					$regsDate = $cdata['registration_date'];
				}        
				echo "<table width='790' border='0' cellspacing='0' cellpadding='0'>
					  <tr>
					   <td  class='LabTdLeft' valign='top'>Registration Code </td>   
						 <td  class='LabTdRight' valign='top'>$cdata[lab_registration_code]</td>
						<td  class='LabTdLeft' valign='top'>Lab Name</td>
						<td  class='LabTdRight' valign='top'>$cdata[lab_name]</td>
					  </tr>
					  <tr>
					    <td class='LabTdLeft' valign='top'>Address</td>
					   <td class='LabTdRight' valign='top'>$cdata[lab_address]</td>
					   <td class='LabTdLeft' valign='top'>City</td>
					    <td class='LabTdRight' valign='top'>$cdata[cityName]</td>
					     </tr>
					  <tr>
					    <td class='LabTdLeft' valign='top'>State</td>
					   <td class='LabTdRight' valign='top'>$cdata[stateName]</td>
					   <td class='LabTdLeft' valign='top'>Country</td>
					    <td class='LabTdRight' valign='top'>$cdata[countryName]</td>
  					</tr>
  					
  					<tr>
					    <td class='LabTdLeft' valign='top'>Zone</td>
					   <td class='LabTdRight' valign='top'>$cdata[zoneName]</td>
					   <td class='LabTdLeft' valign='top'>Pin Code</td>
					    <td class='LabTdRight' valign='top'>$cdata[pincode]</td>
  					</tr>
					  <tr>
					    <td class='LabTdLeft' valign='top'>Contact Person</td>
					   <td class='LabTdRight' valign='top'>$cdata[contact_person]</td>
					    <td class='LabTdLeft' valign='top'>Designation</td>
					    <td class='LabTdRight' valign='top'>$cdata[designation]</td>
  </tr>					 
					  <tr>
					    <td class='LabTdLeft' valign='top'>Phone</td>
					    <td class='LabTdRight' valign='top'>$cdata[phone] </td>
					    <td class='LabTdLeft' valign='top'>Email Id</td>
					    <td class='LabTdRight' valign='top'>$cdata[emailid]</td>
				      </tr>
				       <tr>
					    <td class='LabTdLeft' valign='top'>Fax</td>
					    <td class='LabTdRight' valign='top'>$cdata[fax] </td>
					    <td class='LabTdLeft' valign='top'>Registration Date</td>
					    <td class='LabTdRight' valign='top'>$regsDate</td>
				      </tr>
					</table>";
			}			 
			?>
			
	<?php 
		}
	?>
	</td>
	</tr>	
	</table>
	</td>
  </tr>
</table>
</form>
