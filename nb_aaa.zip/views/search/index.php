<?php include 'include/header_main.php'; ?>	
<script src="js/jquery.js"></script>
<script type="text/javascript">
/*
function open_win(certificateid,fieldid)
{
	var cid = certificateid;
	if(fieldid!=''){ var fid="&fid="+fieldid; }
	
testwindow  = window.open('index.php?c=search&m=searchlabcertificate&cno='+cid+fid , 'mywindow', 'scrollbars=yes,menubar=no,height=700,width=720,resizable=yes,toolbar=no,location=no,status=no');
testwindow.moveTo(100, 100);
}

function resetpage()
{
	var servername = "http://"+window.location.hostname+"/nabl/";
	window.location= "index.php?c=search&m=index";	
}
*/
function open_win(certificateid)
{
	//,fieldid
	//alert(fieldid);
	var cid = certificateid;
	//if(fieldid!=''){ var fid="&fid="+fieldid; }
	//var fid = fieldid;
	
/*window.open("index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid], _blank")
window.open('index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid]', 'mywindow', 'location=1,status=1,scrollbars=1,width=100,height=100');
*/
//alert('index.php?c=search&m=searchlabcertificate&cno='+cid);
//testwindow  = window.open('index.php?c=search&m=searchlabcertificate&cno='+cid+fid , 'mywindow', 'scrollbars=yes,menubar=no,height=700,width=720,resizable=yes,toolbar=no,location=no,status=no');
testwindow  = window.open('index.php?c=search&m=searchlabcertificate&cno='+cid, 'mywindow', 'scrollbars=yes,menubar=no,height=700,width=1000,resizable=yes,toolbar=no,location=no,status=no');
testwindow.moveTo(100, 100);
}

function resetpage()
{
	var servername = "http://"+window.location.hostname+"/nabl/";
	window.location= "index.php?c=search&m=index";	
}

function clearSubgroup() {
	$("#subgroup_id option").remove();
	$('#subgroup_id').html('<option value="-1" selected>Please Select</option>');
}
function getCountry(val)
{
	if(val=='1')
	{
		document.getElementById("city_col").removeAttribute("style");
		document.getElementById("city_val").removeAttribute("style");
		document.getElementById("state_col").removeAttribute("style");
		document.getElementById("state_val").removeAttribute("style");
	}
	else{
		document.getElementById("city_col").style.display="none";
		document.getElementById("city_val").style.display="none";
		document.getElementById("state_val").style.display="none";
		document.getElementById("state_col").style.display="none";
	}
	
}
</script>
<!--top-->
<!--content-->
<div class="tpcontainercontent">
<!--advert1-->
<!--left-->
<!--right-->			
<!--maincontent-->
<div class="tpcontainermain bb">
<div class="tpinner">
<!--<div class="clrfix"></div>-->				
<div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">
<tr>
	<td class="contentheading" width="100%">Laboratory Search</td>
</tr>
</table>

<table class="contentpaneopen" style="width:945px;" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" class="main_article">
<?php echo validation_errors(); ?>
<?php echo form_open_multipart('c=search&m=index','id="search-form"') ?>
<table width="100%"  border="0" cellspacing="1" cellpadding="0">
  <tr>
    <td>  
    <?php
    $labName = "";
   	$location = "";
   	$searchKeyword = "";
    if(isset($searchFormData))
    {
   		$labName = $searchFormData['labName1'];
   		$location = $searchFormData['location1'];
   		$searchKeyword = $searchFormData['searchword'];
    }
	//$facility_id1=$searchFormData['facility_id1'];    
	if($searchFormData['field_id1']!='') $field_id1=$searchFormData['field_id1'];    
    ?> 
	<form action="" method="post" enctype="multipart/form-data" name="form1" >	 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
                <tr>
                <td colspan="4" class="LaboratoryGridHead LabPaddingLeft">Laboratory Search</td>
              </tr>
              <tr><td colspan="4" height="10px">&nbsp;</td></tr>
               <tr>
					<td class="LabTdLeft" valign="top">Laboratory Name</td>
					<td class="LabTdRight" valign="top"><input name="labname" type="text" id="labname" value="<?php echo $labName; ?>"></td>
				
					<td class="LabTdLeft" valign="top" id="country_col" >Country<span style="color:red;">&nbsp;*</span></td>
					 <td class="LabTdRight" valign="top"  id="country_val">
					 <select name="country" id="country-dropdown" onchange="getCountry(this.value);">
					 <option value="0">Please Select</option>
					 <?php  foreach($country as $data)
					 { 
						 ?>
						
						<option value="<?php echo $data[id];?>" <?php echo ($selectedCountry == $data[id]) ? 'selected': ''; ?>><?php echo $data[name] ;?></option>
					<?php 
					}	?>
					 </select>
					 
					 </td>
              </tr>
              
               <tr><td colspan="4" height="5px"></td></tr>
               
              <tr>
                <td class="LabTdLeft" valign="top">Zone</td>
                 <td class="LabTdRight" valign="top">
                   <?php echo $zone; ?>
                 </td>
				<td class="LabTdLeft" valign="top" style="display:none;" id="state_col">State </td>
				<td class="LabTdRight" valign="top"  style="display:none;" id="state_val"><?php echo $state ;?></td>
                
				 
				
					 
				
                  </tr>
               <tr><td colspan="4" height="5px"></td></tr>
              <tr>
                 <td class="LabTdLeft" valign="top">Nature of Lab</td>
                <td class="LabTdRight" valign="top"><?php echo $natureoflab;  ?></td>
				 <td class="LabTdLeft" valign="top" style="display:none;" id="city_col">City </td>
                 <td class="LabTdRight" valign="top"  style="display:none;" id="city_val"><div id="cityajax"><?php echo $city ;?></div></td>
              
              </tr>

              
               <tr><td colspan="4" height="10px">&nbsp;</td></tr>
              
              <tr>
                 <td class="LabTdLeft" valign="top">Field</td>
                 <td class="LabTdRight" valign="top"><?php echo $facilitydropdown; ?></td>
                 <td class="LabTdLeft" valign="top">Facility</td>
                 <td class="LabTdRight" valign="top">
                 <?php echo $operationat; ?>
                 </td>
				
				</td>
              </tr>
              
               <tr><td colspan="4" height="5px"></td></tr>
               
               <tr>
                 <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">&nbsp;</td>
                 <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">&nbsp;</td>
               </tr>
               <tr>
                 <td class="LabTdLeft" valign="top">Discipline</td>
                 <td class="LabTdRight" valign="top">
                 <div id='field'>
				<?php
				if(($_POST['submit']=="Search" || $pagination=="yes") && $fielddropdown!="")
				{					
					echo $fielddropdown;
				} 
				else 
				{					
					?>
					<select name="field_id[]" id="field_id" style="width:150px;">
	                <option value='-1'>Please Select</option>
	                </select>
					<?php 
				}
				?>
				</div>
                 </td>
                 <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">&nbsp;</td>
               </tr>
               <tr>
                 <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">&nbsp;</td>
                 <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">&nbsp;</td>
               </tr>
               <tr>
                 <td class="LabTdLeft" valign="top">Group</td>
                 <td class="LabTdRight" valign="top">
                <div id='group'>
				<?php
				if(($_POST['submit']=="Search" || $pagination=="yes") && $groupdropdown!="")
				{					
					echo $groupdropdown;
				} 
				else 
				{					
					?>
					<select name="group_id" id="group_id" style="width:150px;">
                  		<option value="-1">Please Select</option>
                	</select>
					<?php 
				}
				?>				
                </div>
                 </td>
                 <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">&nbsp;</td>
               </tr>
               <tr>
                 <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">&nbsp;</td>
                 <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">&nbsp;</td>
               </tr>
               <tr>
                 <td class="LabTdLeft" valign="top">Sub Group </td>
                 <td class="LabTdRight" valign="top">
				 <div id='subgroup'>
				 
				<?php
				if(($_POST['submit']=="Search" || $pagination=="yes") && $subgroupdropdown!="")
				{					
					echo $subgroupdropdown;
				} 
				else 
				{					
					?>
						<select name="subgroup[]" id="subgroup_id" size="10" multiple style="width:150px;">
			                <option value="-1" >Please Select</option>
			             </select>
					<?php 
				}
				?>
			
                </div>
				</td>
                 <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">
				
				</td>
              </tr>
               <tr><td colspan="4" height="10px">
               <hr />             
               </td></tr>
               <tr>
                 <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">&nbsp;</td>
                 <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">&nbsp;</td>
               </tr>
               <tr>
                <td class="LabTdLeft" valign="top"><font color="#000000"><strong><em>Looking For Keyword</em></strong></font></td>
                 <td class="LabTdRight" valign="top"><input type="text" name="searchword" id="searchword" value="<?php echo $searchKeyword; ?>" /></td>
                <td class="LabTdLeft" valign="top">&nbsp;</td>
                 <td class="LabTdRight" valign="top">&nbsp;</td>
              </tr>  
              <tr><td colspan="4" height="5px"></td></tr>            
              <tr>
                <td align="center" colspan="4" valign="top"><center><input type="submit" name="submit" value="Search">
                  &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;
                <input type="button" name="button" id="button" value="Reset" onclick="javascript: return resetpage();" />
                </center></td>
              </tr>
              <tr><td colspan="4" height="5px"></td></tr>
          </table></br>
		<?php 
		if(isset($_POST['submit']) && count($rows)>0){?>
		<div>
			<input id="export-excel" class="btn btn-primary" name="export-excel" value="Export to excel" type="submit">
		</div>
		<?php } ?>
    </form>
    <table width="100%" border="0" cellpadding="0" cellspacing="0">	
    <?php
	
	if(isset($rows) && count($rows)>0)
	{		
		echo "<tr><td style='text-align:left; padding-top:10px;'><b>	
					Total ".count($rows)." Records Found</b></td></tr>";
		echo "<tr>
    <td class='LaboratoryGridHead LabPaddingLeft'>Search Results</td></tr>";
		//echo "<tr><td align='right'></td></tr>";
	} 
	else 
	{
		//echo "<tr><td align='left'>No Record Found</td></tr>";
	}
	?>
    
		
	</table>
	<table width="100%" border="0" cellpadding="0" cellspacing="0">	
    <tr><td height="5px"></td></tr>
	
	<?php	
		//print_r($labdata);
		//echo "Count - ".count($labdata);
		if(isset($labdata) && count($labdata)>0)
		{		
			$i=0;
			$x=1;
			//count($labdata);
			echo "<tr>";
			
			while($i<count($labdata))//foreach($labdata as $labdata_items)
			{
				//echo $content = $labdata[$i]['file_content'];die();
				$operationatstr = str_replace(",", "\n", $labdata[$i]['opertaionAtName']);
				$address = $labdata[$i]['lab_address'];
				$city = $labdata[$i]['cityName'];
				$designation = $labdata[$i]['designation'];
				$pincode = $labdata[$i]['pincode'];
				$phone = $labdata[$i]['phone'];
				$fax = $labdata[$i]['fax'];
				$email = $labdata[$i]['emailid'];
				
				if($pincode=="NULL")			
					$pincode = "";	
				else 
				   $pincode = " ".$pincode;
				
				if($phone=="NULL")				
					$phone = "";	
				
				if($fax=="NULL")				
					$fax = "";

				if($email=="NULL")	
				{	
					$email = "";
				}
				else 
				{
					//$email = "NOT NULL";
				}
					
				if($address=="NULL")				
					$address = "";				
				else 				
					$address = $address;		
				if($labdata[$i]['stateName'] == 'OTHERS')
					$state = '';
				else
					$state = $labdata[$i]['stateName'];
				
				if($city=='0')				
					$str = $pincode."<br/>".$state;
				if($city!='0')				
					$str = "<br/>".$labdata[$i]['cityName']." -".$pincode."<br>".$state."<br/>";
				
				if($designation=="NULL")				
					$designation = "";				
				
				
				echo "<td width='100%' valign='top'>";
				echo "<table width='465px' border='0' cellspacing='0' cellpadding='0'>
  						<tr>
					    <td align='left' valign='middle'>
					<table width='465px' border='0' cellspacing='0' cellpadding='0' class='Border LabBg'>
					  <tr>
						<td width='120px' height='50px' class='LabPaddingLeft' valign='top'><b>Lab Name :</b></td>   
						<td width='0px' height='40px' class='LabPaddingLeft' valign='top'><font color='#666666'><b>".$labdata[$i]['lab_name']."</b></font></td>   
						<td width='5' height='40px'>&nbsp;</td>
						</tr>												   	
					   <tr><td style='height:5px;' colspan='3'></td></tr>
					   
					   <tr>
						<td height='140px' class='LabPaddingLeft' valign='top' ><b>Address :</b></td>
						<td class='LabPaddingLeft' valign='top'>
						".$address."
						".$str." 													
						".$labdata[$i]['countryName']."
						</td>
						<td width='5'>&nbsp;</td>
						</tr>												  										  
					  <tr><td style='height:5px;' colspan='3'></td></tr>
						
					  <tr>
						<td class='LabPaddingLeft' valign='top' ><b>Tel No. :</b></td>
						<td class='LabPaddingLeft' valign='top'>".$phone."</td>
						<td width='5'>&nbsp;</td>
						</tr>
					  <tr><td style='height:5px;' colspan='3'></td></tr>		
																		
					  <tr>
						<td class='LabPaddingLeft' valign='top'><b>Fax No. :</b></td>
						<td class='LabPaddingLeft' valign='top'>".$fax."</td>
						<td width='5'>&nbsp;</td>
						</tr>
					  <tr><td style='height:5px;' colspan='3'></td></tr>
							
					  <tr>
						<td class='LabPaddingLeft' valign='top' height='40px'><b>Email :</b></td>
						<td class='LabPaddingLeft' valign='top'>".$email."</td>
						<td width='5'>&nbsp;</td>
						</tr>
					  <tr><td style='height:5px;' colspan='3'></td></tr>							  
					 
					 
					 <tr>
						<td class='LabPaddingLeft' valign='top'><b>Contact Person :</b></td>
						<td class='LabPaddingLeft' valign='top'>".$labdata[$i]['contact_person']."</td>
						<td width='5'>&nbsp;</td>
						</tr>
					 <tr><td style='height:5px;' colspan='3'></td></tr>	
					  ";
					if($labdata[$i]['id']!="")
					{
					  //<a href='#' onclick='return open_win(".$labdata[$i]['id'].",".$field_id1.")'> Click here to View the Scope of Accreditation</a>
					  echo "<tr>
							<td class='LabBotBg' colspan='3'> 												  
							<a href='#' onclick='return open_win(".$labdata[$i]['id'].")'> Click here to View the Scope of Accreditation</a>
							&nbsp;
							</td>												 					   
							</tr>";
					}
					else 
					{
						echo "<tr>
							<td class='LabBotBg' colspan='3'>&nbsp;</td>												 					   
							</tr>";
					}												
												  
					echo "</table>								
								</td>				
					 	 </tr>
						</table><br/>";				
				if($i==0 && count($labdata)==1)
				{					
					echo "</td></tr>";
				}
				
				if($x%2==1)
				{
					echo "</td>";				
				}
				if($x%2==0)
				{
					echo "</td></tr>";
				}	
				$i = $i + 1;
				$x = $x + 1;
			}			 
			?>
			
	<?php 
		} 	
		else 
		{
			echo "<table width='700' border='0' cellspacing='0' cellpadding='5'>
					  <tr>
						   <td align='center' valign='top' colspan='2'><b>No Record Found</b></td> 
				   </tr>
				  </table";
		}	

		?>
		</table>
		<?php 
		if(isset($pagination) && $pagination=="yes")
		{
			echo "<table width='700' border='0' cellspacing='0' cellpadding='5'>
					  <tr>
						   <td align='left' valign='top' colspan='2'>".$this->pagination->create_links()."</td> 
				  </tr>
				  </table";
		}
		
	?>

	
	</td>
  </tr>
</table>
</form>

</td>
</tr>

</table>
</div>

<div class="clrfix"></div>
</div>
</div>		
<div class="clrfix"></div>
</div> 

<!--bottom-->

<!-- -->
<!--footer-->
		<?php include 'include/footer_main.php'; ?>	
		</div>
	</div>
	</div>
	<script> getCountry(<?php echo $selectedCountry; ?>); </script>
	<script>
	$( "#search-form" ).submit(function( event ) {
		if($("#country-dropdown").val()== '0')
		{
			alert("Please select country.");
			return false;
		}
		return true;
	});
	</script>
</body>
</html>