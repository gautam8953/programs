<h2>Create a Lab Subgroup</h2>

<?php echo validation_errors(); ?>

<?php echo form_open('c=subgroup&m=create') ?>



	<label for="title">Subgroup Name</label>
	<input type="text" name="subgroup_name" /><br />
    
    <label for="title">Group Name</label>
    <?php echo $groupdropdown;?><br />

	<label for="text">Description</label>
	<textarea name="subgroup_description"></textarea><br />

	<input type="submit" name="submit" value="Create Subgroup" />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="reset" name="reset" value="Reset">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php
			 echo anchor('c=subgroup&m=index', 'Back');
	?>

</form>
