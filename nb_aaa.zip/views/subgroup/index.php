<h2 align="center">Lab Subgroup</h2>
<h3 align="center"><a href="index.php?c=subgroup&m=create">Create New subgroup</a></h3>
<?php

if(count($news)>0){
?>
<table align="center" border="1">
<tr>
<th>Si No</th>
<th>Subgroup Name</th>
<th>Group Name</th>
<th>Description</th>
<th>Action</th>
<?php
$i=0;
foreach ($news as $news_item){ ?>

<tr>
	<td><?php echo ++$i;?></td>
    <td><?php echo $news_item['sub_group_name'] ?></td>
    <td><?php echo $news_item['group_name'] ?></td>
    <td><?php echo $news_item['sub_group_description'] ?></td>
    <td><a href="index.php?c=subgroup&m=editsubgroup&id=<?php echo $news_item['id'];?>">Edit</a>|
    <a href="index.php?c=subgroup&m=deletesubgroup&id=<?php echo $news_item['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this subgroup ?')"
    >Delete</a>

</td>
</tr>
<?php
}
?>

</table>
<?php
}else{
	echo "No Subgroup Found ";
}
if(isset($pagination) && $pagination=="yes")
{ 
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>