<h2>Edit a Lab Subgroup</h2>

<?php echo validation_errors(); ?>

<?php echo form_open('c=subgroup&m=editsubgroup&id='.$_GET['id']) ?>

	<label for="title">subgroup Name</label>
	<input type="text" name="subgroup_name"  value="<?php echo $subgroup['sub_group_name']?>"/><br />

     <label for="title">Group Name</label>
    <?php echo $groupdropdown?> <br/>
    
	<label for="text">Description</label>
	<textarea name="subgroup_description"><?php echo $subgroup['sub_group_description']?></textarea><br />

	<input type="submit" name="submit" value="Update subgroup" />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="reset" name="reset" value="Reset">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php
			 echo anchor('c=subgroup&m=index', 'Back');
	?>

</form>
