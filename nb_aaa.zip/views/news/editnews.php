<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){                
                $('#date_of_clip').datepicker({ yearRange: '1930:2020' } );   
                $('#end_date').datepicker({ yearRange: '1930:2020' } );             
            });
</script>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Edit News / Announcement</td>
</tr>
<tr>
<td class="LabAlighRight">
&nbsp;
</td>
</tr>
<tr>
<td>
<?php echo validation_errors(); ?>
<?php echo form_open('c=news&m=editnews&id='.$_GET['id']) ?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="80%">
  <tr>
    <td align="center" valign="middle">
    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
      <tr>
        <td align="center" valign="middle">      
          <table width="100%" border="0" cellspacing="0" cellpadding="9">            
            <tr>
              <td class="LabPaddingLeft" style="height:30px;" valign="middle">Clip Type * </td>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">     
              <?php
              	$newssel = "";
              	$annsel = "";
              	$sel = "";
              	
              	$clipType = $news['clip_type'];
              	if($clipType=="news")
              		$newssel = "selected";
              	else if($clipType=="announcement")
              		$annsel = "selected";
              	else 
              		$sel = "selected";
              		
              	
                 ?>                 
              <select name="clip_type" id="clip_type" style="width:128px;">              
              <option value="0"            <?php echo $sel; ?>>Please Select</option>
              <option value="news"         <?php echo $newssel; ?>>News</option>
              <option value="announcement" <?php echo $annsel; ?>>Announcement</option>
              </select></td>
            </tr>
            <tr>
              <td class="LabPaddingLeft" style="height:30px;" valign="middle">Head Line * </td>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle"><input name="headline" type="text" id="headline" value="<?php echo $news['headline']; ?>" /></td>
            </tr>
            <tr>
              <td class="LabPaddingLeft" style="height:30px;" valign="middle">Clipping Details * </td>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">
              <textarea name="clip_detail" id="clip_detail" style="width:300px;"><?php echo $news['clip_detail']; ?></textarea></td>
            </tr>
            <tr>
              <td class="LabPaddingLeft" style="height:30px;" valign="middle">Date of Clipping * </td>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">
              <?php
              		$clipDate = explode('-',$news['date_of_clip']); 
              		$clipDate = array_reverse($clipDate);
              		$clipDate = implode('-',$clipDate);
              ?>
              <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="date_of_clip" type="text" id="date_of_clip" value="<?php echo $clipDate; ?>"></td>
            </tr>
            
            <tr>
              <td class="LabPaddingLeft" style="height:30px;" valign="middle">Clipping End Date </td>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">
               <?php
               		if($news['end_date']==NULL)
               		{
               			$clipEndDate = "";
               		}
               		else 
               		{
	              		$clipEndDate = explode('-',$news['end_date']); 
	              		$clipEndDate = array_reverse($clipEndDate);
	              		$clipEndDate = implode('-',$clipEndDate);
               		}
              ?>
              <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="end_date" type="text" id="end_date" value="<?php echo $clipEndDate; ?>">
              </td>
            </tr>
            
            <tr>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle" colspan="2">
              <input type="submit" name="submit" value="Submit" onclick="javascript:return validateNewsAbbouncementForm();">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset" name="reset" value="Reset">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <?php
			  		echo anchor('c=news&m=index', 'Back');
			    ?>
                </td>              
            </tr>
          </table>
        </td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>