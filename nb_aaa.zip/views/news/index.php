<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add News / Announcement</td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=news&m=create">Add News / Announcement</a>
</td>
</tr>
<tr>
<td>
<?php
if(count($news)>0){
?>
<div style="overflow:auto; width:930px;" >
<table align="center" border="1" cellpadding="0" cellspacing="0" width="100%">
<tr>
<!-- <th width="5%" class="LaboratoryGridHead LabPaddingLeft">Si No</th>  -->
<th width="200px" class="LaboratoryGridHead LabPaddingLeft" align="top">Head Line</th>
<th width="130px" class="LaboratoryGridHead LabPaddingLeft" align="top">Cliping type</th>
<th width="240px" class="LaboratoryGridHead LabPaddingLeft" align="top">Cliping Details</th>
<th width="80px" class="LaboratoryGridHead LabPaddingLeft" align="top">Date of Clipping</th>
<th width="80px" class="LaboratoryGridHead LabPaddingLeft" align="top">Clipping End Date</th>
<th width="100px" class="LaboratoryGridHead LabPaddingLeft" align="top">Activate / Deactivate</th>
<th width="100px" class="LaboratoryGridHead LabPaddingLeft" align="top">Action</th>
<?php
$i=0;
foreach ($news as $news_item){ 
	$id = $news_item['id'];
?>

<tr>
<!-- <td class="LabPaddingLeft" valign="top"><?php //echo ++$i;?></td>  -->
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['headline'] ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['clip_type'] ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['clip_detail'] ?></td>
    <td class="LabPaddingLeft" valign="top">
    <?php 
    	//echo $news_item['date_of_clip']; 
    	$clipDate = explode('-',$news_item['date_of_clip']);
        $clipDate = array_reverse($clipDate);
        echo $clipDate = implode('/',$clipDate);
    ?>
    </td>  
    <td class="LabPaddingLeft" valign="top">
    <?php 
    	if($news_item['end_date']==NULL)
    	{
    		echo $clipEndDate = "";
    	}
    	else 
    	{
    		$clipEndDate = explode('-',$news_item['end_date']);
	        $clipEndDate = array_reverse($clipEndDate);
	        echo $clipEndDate = implode('/',$clipEndDate);
    	}
    	
    ?>
    </td>  
    <td class="LabPaddingLeft" valign="top">
    <?php 
    	if($news_item['status']==0)
    	{
    		echo "<a href='index.php?c=news&m=updateStatus&status=0&id=$id'>Activate</a>";
    	}
    	if($news_item['status']==1)
    	{
    		echo "<a href='index.php?c=news&m=updateStatus&status=1&id=$id'>Deactivate</a>";
    	} 
    ?>
    </td>          
    <td class="LabPaddingLeft" valign="top"><a href="index.php?c=news&m=editnews&id=<?php echo $news_item['id'];?>">Edit</a>|
    <a href="index.php?c=news&m=deletenews&id=<?php echo $news_item['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this category ?')"
    >Delete</a>

</td>
</tr>
<?php
}
?>

</table>
<?php
}else{
	echo "No News Found ";
}
if(isset($pagination) && $pagination=="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>