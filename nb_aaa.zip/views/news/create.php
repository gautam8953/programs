<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){
                //For date of birth
                $('#date_of_clip').datepicker({ yearRange: '1930:2020' } );
                $('#end_date').datepicker({ yearRange: '1930:2020' } );
            });
        </script>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add News / Announcement</td>
</tr>
<tr>
<td class="LabAlighRight">
&nbsp;
</td>
</tr>
<tr>
<td>
<?php echo validation_errors(); ?>
<?php echo form_open('c=news&m=create') ?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="80%">
  <tr>
    <td align="center" valign="middle">
   <table align="center" border="0" cellpadding="0" cellspacing="0" width="80%">
      <tr>
        <td align="center" valign="middle">
          <table width="100%" border="0" cellspacing="0" cellpadding="9">            
            <tr>
              <td class="LabPaddingLeft" style="height:30px;" valign="middle">Clip Type * </td>
              <td  align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">                      
              <select name="clip_type" id="clip_type" style="width:128px;">
              <option value="0" selected>Please Select</option>
              <option value="news">News</option>
              <option value="announcement">Announcement</option>
              </select></td>
            </tr>
            <tr>
              <td class="LabPaddingLeft" style="height:30px;" valign="middle">Head Line * </td>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle"><input name="headline" type="text" id="headline"></td>
            </tr>
            <tr>
              <td class="LabPaddingLeft" style="height:30px;" valign="middle">Clipping Details * </td>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">
              <textarea name="clip_detail" id="clip_detail" style="width:300px;"></textarea></td>
            </tr>
            <tr>
              <td class="LabPaddingLeft" style="height:30px;" valign="middle">Date of Clipping * </td>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">
              <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="date_of_clip" type="text" id="date_of_clip">
              </td>
            </tr>
                        
            <tr>
              <td class="LabPaddingLeft" style="height:30px;" valign="middle">Clipping End Date </td>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">
              <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="end_date" type="text" id="end_date">
              </td>
            </tr>
            
            <tr>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle" colspan="2">
              <input type="submit" name="submit" value="Submit" onclick="javascript:return validateNewsAbbouncementForm();">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset" name="reset" value="Reset">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <?php
			  		echo anchor('c=news&m=index', 'Back');
			    ?>
                </td>              
            </tr>
          </table>
        </td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
