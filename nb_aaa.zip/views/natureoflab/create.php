
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add a Nature of Lab</td>
</tr>
<tr>
<td class="LabAlighRight">

</td>
</tr>
<tr>
<td>
<?php //echo validation_errors(); ?>
<?php echo form_open('c=natureoflab&m=create') ?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="80%">
<tr>
<td class="LabPaddingLeft" style="height:30px;"><label for="title">Nature of Lab Name</label></td>
<td><input type="text" name="nature_name" id="nature_name" /></td>
	</tr>
    
    <tr>
    <td></td>
    <td align="left" style="height:30px;">
	<input type="submit" name="submit" value="Add Nature of Lab" onclick="javascript:return validateNatureofLabForm();" />
	<input type="reset" name="reset" value="Reset">
    <?php
			 echo anchor('c=natureoflab&m=index', 'Back');
	?>    
</td>
</tr>
</table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>