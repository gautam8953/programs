			<!--header-->
				<?php include 'include/header_main.php'; ?>	
				<script type="text/javascript">
				function open_win(eventid)
				{	
					var eid = eventid;	
					testwindow  = window.open('index.php?c=publiceventschedule&m=view&eventid='+eid , 'mywindow', 'scrollbars=no,menubar=no,height=350,width=800,resizable=yes,toolbar=no,location=no,status=no');
					testwindow.moveTo(350, 300);  
				
				}
				</script>
			<div class="tpcontainercontent">
		<div class="tpcontainermain bb">
					<div class="tpinner">
					<div class="tpcontainermainc" style="width: 940px">
                    <table class="contentpaneopen detail">
<tr>
		<td class="contentheading" width="100%">
				<?php 	
				//print_r($evtscde);
				if(count($evtscde)>0)
				{			
					for($i=0;$i<1;$i++)
					{ 
						echo $evtscde[$i]['event_type_name']." Course Details ";
					}					
				}
				else 
				{
					echo "Course Details ";
				}
				?>	
							
				</td>
					</tr>
</table>

<table class="contentpaneopen" style="width:945px;" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" class="main_article">
<?php
if(count($evtscde)>0){
?>
<table align="center" border="1" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td class="LaboratoryGridHead LabPaddingLeft" width="35%" valign="middle" >Program Name</td>
<td class="LaboratoryGridHead LabPaddingLeft" width="35%" valign="middle" >Venue</td>
<td class="LaboratoryGridHead LabPaddingLeft" width="15%" valign="middle" >Start Date</td>
<td class="LaboratoryGridHead LabPaddingLeft" width="15%" valign="middle" >Finish Date</td>
<?php
$i=0;
foreach ($evtscde as $evtscde_item){ ?>
</tr>
<tr>	      
    <td class="LabPaddingLeft" valign="top">
    <a href='#' onclick='return open_win("<?php echo $evtscde_item['eventId']; ?>")'>
     <?php echo $evtscde_item['program_name'] ?>
     </a>     
    </td>   
    <td class="LabPaddingLeft" valign="top"><?php echo $evtscde_item['venue'] ?></td>       
    <td class="LabPaddingLeft" valign="top">
    <?php 
    		//echo $evtscde_item['start_date'];
    		$startDate = explode('-',$evtscde_item['start_date']); 
            $startDate = array_reverse($startDate);
            echo $startDate = implode('/',$startDate);
    ?>
    </td>
    <td class="LabPaddingLeft" valign="top">
    <?php 
    		//echo $evtscde_item['end_date']; 
    		$endDate = explode('-',$evtscde_item['end_date']); 
            $endDate = array_reverse($endDate);
            echo $endDate = implode('/',$endDate);
    ?>
    </td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Record Found ";
}
if(isset($pagination) && $pagination="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>

</td>
</tr>

</table>
</div>
												
																		<div class="clrfix"></div>
					</div>
				</div>		
				<div class="clrfix"></div>
			</div> 
			<?php include 'include/footer_main.php'; ?>             
		</div>
	</div>
	</div>
</body>
</center>
</html>
