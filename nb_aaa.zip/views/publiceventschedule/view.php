<script src="js/ajax.js"></script>
<script src="js/jquery.js"></script>
<link href="../templates/mystore_plazza/css/custom.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/css.gzip.php?style=lite&amp;size=standard" type="text/css" />
<style type="text/css">
body {
	background-color:#FFF;
	margin:0 auto;
}
	
</style>
<table class="contentpaneopen" style="width:800px;" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" class="main_article">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
<?php echo $courseDetails['event_type_name']." Course Details "; ?> 
</td>
</tr>
<tr>
<td style="height:5px;" colspan="4">
</td>
</tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Event Type</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['event_type_name']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Name of Program</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['program_name']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Course Details</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['course_detail']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Venue</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['venue']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Contact Person </td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['contact_person']; ?></td>
              <td class='LabTdLeft' valign='top'>Designation</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['designation']; ?>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Contact Address</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['contact_address']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Pincode </td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['pin']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>City</td>
              <td width="30%" class='LabTdRight' valign='top'><?php  echo $courseDetails['cityname']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Phone</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['phone']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>State </td>
              <td width="30%" class='LabTdRight' valign='top'><?php  echo $courseDetails['statename']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Fax</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['fax']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Country</td>
              <td width="30%" class='LabTdRight' valign='top'><?php  echo $courseDetails['countryname']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Email ID</td>
              <td width="30%" align="left"><?php echo $courseDetails['emailid']; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Start Date </td>
              <td width="30%" class='LabTdRight' valign='top'>
              <?php
              		$startDate = explode('-',$courseDetails['start_date']); 
              		$startDate = array_reverse($startDate);
              		$startDate = implode('/',$startDate);

              		$endDate = explode('-',$courseDetails['end_date']); 
              		$endDate = array_reverse($endDate);
              		$endDate = implode('/',$endDate)              
              ?>              
              <?php echo $startDate; ?>
              </td>
              <td width="20%" class='LabTdLeft' valign='top'>End Date</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $endDate; ?></td>
            </tr>
            <tr>
              <td width="20%" class='LabTdLeft' valign='top'>Program Fees (INR)</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['program_fees']; ?></td>
              <td width="20%" class='LabTdLeft' valign='top'>Remark</td>
              <td width="30%" class='LabTdRight' valign='top'><?php echo $courseDetails['remark']?></td>
            </tr>
            <tr>
			<td style="height:5px;" colspan="4">
			</td>
			</tr>		
            <tr>
<td style="height:5px;" colspan="4">
</td>
</tr>
          </table>

</td>
</tr>
</table>
