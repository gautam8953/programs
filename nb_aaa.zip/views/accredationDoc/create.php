<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){
                //For date of birth
                $('#issue_date').datepicker({ yearRange: '1930:2020' } );
                $('#last_amendment_date').datepicker({ yearRange: '1930:2020' } );
            });
        </script>
<?php //echo validation_errors(); ?>
<?php echo form_open_multipart('c=accredationDoc&m=create') ?>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add Document</td>
</tr>
<tr>
<td style="height:15px;">
</td>
</tr>
<tr>
<td>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
Add Document
</td>
</tr>
<tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Document No: * </td>
              <td width="30%" align="left"><input name="document_no" type="text" id="document_no"></td>
              <td width="20%" align="left">Document Title: * </td>
              <td width="30%" align="left"><input name="document_title" type="text" id="document_title"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Document Type: *</td>
              <td width="30%" align="left">
              <select name="document_type" id="document_type" style="width:137px;">
              <option value="0" selected>Please Select</option>
              <option value="newsletter">News Letters</option>
              <option value="free">NABL Free Documents</option>
              <option value="paid">NABL Paid Documents</option>
              <option value="misc">Miscellanenous</option>
               <!--        
                <?php                     	
	              	//for($i=0;$i<count($docType);$i++)
	              	//{ 
	             ?>
                	<option value="<?php //echo $docType[$i]['id'] ?>"><?php //echo $docType[$i]['document_type_name'] ;?></option>
                <?php
	              	//} 
	             ?>
	              -->
              </select></td>
              <td width="20%" align="left">Issue No.:  * </td>
              <td width="30%" align="left"><input name="issue_no" type="text" id="issue_no"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Issue Date: * </td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="issue_date" type="text" id="issue_date"></td>
              <td width="20%" align="left">Last Amendment No.: </td>
              <td width="30%" align="left"><input name="last_amendment_no" type="text" id="last_amendment_no"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Last Amendment Date:</td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="last_amendment_date" type="text" id="last_amendment_date"></td>
              <td width="20%" align="left">Cost (INR): </td>
              <td width="30%" align="left"><input name="cost" type="text" id="cost"> </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Upload Document:*</td>
              <td width="30%" align="left"><input name="userfile" type="file" id="userfile"></td>
              <td width="20%" align="left"></td>
              <td width="30%" align="left"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td colspan="4" align="center">
              <center>
              <input type="submit" name="submit" value="Upload" onclick="javascript:return validateAccredationDoc();">
                <input type="reset" name="reset" value="Reset">
                <?php
			  		echo anchor('c=accredationDoc&m=index', 'Back');
			    ?>          </center>     
                </td>              
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
          </table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
