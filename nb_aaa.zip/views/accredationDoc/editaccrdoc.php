<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){                
                $('#issue_date').datepicker({ yearRange: '1930:2020' } );   
                $('#last_amendment_date').datepicker({ yearRange: '1930:2020' } );    
            });
</script>
<?php echo validation_errors(); ?>
<?php echo form_open_multipart('c=accredationDoc&m=editaccrdoc&id='.$_GET['id']) ?>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Edit Document </td>
</tr>
<tr>
<td style="height:15px;">
</td>
</tr>
<tr>
<td>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
Edit Document
</td>
</tr>
<tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Document No * </td>
              <td width="30%" align="left"> <input name="document_no" type="text" id="document_no" value="<?php echo $news['document_no']; ?>" /></td>
              <td width="20%" align="left">Document Title * </td>
              <td width="30%" align="left">  <input name="document_title" type="text" id="document_title" value="<?php echo $news['document_title']; ?>" /></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Document Type *</td>
              <td width="30%" align="left">
              <?php 
              	$doctype =  $news['document_type'];
              	$nsel = "";
              	$fsel = "";
              	$psel = "";
              	$msel = "";
              	$sel = "";
              	if($doctype=="newsletter")
              	{
              		$nsel = "selected";
              	}
              	else if($doctype=="free")
              	{
              		$fsel = "selected";
              	}
              	else if($doctype=="paid")
              	{
              		$psel = "selected";
              	}
              	else if($doctype=="misc")
              	{
              		$msel = "selected";
              	}
              	else 
              	{
              		$sel = "selected";
              	}
              ?>
              <select name="document_type" id="document_type">
              <option value="0"          <?php echo $sel; ?>>Please Select</option>
              <option value="newsletter" <?php echo $nsel; ?>>News Letters</option>
              <option value="free"       <?php echo $fsel; ?>>NABL Free Documents</option>
              <option value="paid"       <?php echo $psel; ?>>NABL Paid Documents</option>
              <option value="misc"       <?php echo $msel; ?>>Miscellanenous</option>
              </select></td>
              <td width="20%" align="left">Issue No.  * </td>
              <td width="30%" align="left"> <input name="issue_no" type="text" id="issue_no"  value="<?php echo $news['issue_no']; ?>" /></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Issue Date * </td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <?php
              		$issueDate = explode('-',$news['issue_date']); 
              		$issueDate = array_reverse($issueDate);
              		$issueDate = implode('-',$issueDate);
              		
              		$lastamendDate = explode('-',$news['last_amendment_date']); 
              		$lastamendDate = array_reverse($lastamendDate);
              		$lastamendDate = implode('-',$lastamendDate);              		
              		if($lastamendDate=="00-00-0000")
              		{
              			$lastamendDate = "";
              		}
              		
              		
              ?>
               <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
			  <input name="issue_date" type="text" id="issue_date" value="<?php echo $issueDate; ?>" /></td>
              <td width="20%" align="left">Last Amendment No. </td>
              <td width="30%" align="left"> <input name="last_amendment_no" type="text" id="last_amendment_no" value="<?php echo $news['last_amendment_no']; ?>" /></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Last Amendment Date.</td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="last_amendment_date" type="text" id="last_amendment_date" value="<?php echo $lastamendDate; ?>"  /></td>
              <td width="20%" align="left">Cost (INR)</td>
              <td width="30%" align="left"><input name="cost" type="text" id="cost" value="<?php echo $news['cost']; ?>" />   </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Upload Document *</td>
              <td width="30%" align="left"> <input name="userfile" type="file" id="userfile"></td>
              <td width="20%" align="left"></td>
              <td width="30%" align="left"></td>
            </tr>
            
            <tr><td style="height:5px;" colspan="4"></td></tr>
            <tr>
              <td colspan="4" align="center">
              <center>
             <input type="submit" name="submit" value="Upload" onclick="javascript:return validateAccredationDoc();">
                <input type="reset" name="reset" value="Reset">
                <?php
			  		echo anchor('c=accredationDoc&m=index', 'Back');
			    ?>          </center>     
                </td>              
            </tr>
            <tr>
<td style="height:5px;" colspan="4">
</td>
</tr>
          </table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
</form>
