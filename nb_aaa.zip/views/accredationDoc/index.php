<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Manage NABL Documents </td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=accredationDoc&m=create">Add NABL Document</a>
</td>
</tr>
<tr>
<td>
<?php
//print_r($news);
if(count($news)>0){
?>
<div style="overflow:auto; width:930px;">
<table align="center" border="1" cellpadding="0" cellspacing="0" width="100%">
<tr>
<!-- <td width="7%" class="LaboratoryGridHead LabPaddingLeft" >Si No</td>  -->
<td width="20%" class="LaboratoryGridHead LabPaddingLeft">Document No</td>
<td width="19%" class="LaboratoryGridHead LabPaddingLeft">Document Title</td>
<td width="13%" class="LaboratoryGridHead LabPaddingLeft">Document Type</td>
<td width="10%" class="LaboratoryGridHead LabPaddingLeft">Issue Date</td>
<td width="12%" class="LaboratoryGridHead LabPaddingLeft">View Document</td>
<th width="16%" class="LaboratoryGridHead LabPaddingLeft">Activate/Deactivate</th>
<td width="10%" class="LaboratoryGridHead LabPaddingLeft">Action</td>
<?php
$i=0;
foreach ($news as $news_item){ 	
	$id= $news_item['id'];
?>

<tr>
	<!--  <td class="LabPaddingLeft" valign="top"><?php //echo ++$i;?></td>  -->
     <td class="LabPaddingLeft" valign="top"><?php echo $news_item['document_no'] ?></td> 
     <td class="LabPaddingLeft" valign="top"><?php echo $news_item['document_title'] ?></td>    
     <td class="LabPaddingLeft" valign="top"><?php echo $news_item['document_type'] ?></td>     
     <td class="LabPaddingLeft" valign="top">
     <?php 
     	//echo $news_item['issue_date'];
     	$issueDate = explode('-',$news_item['issue_date']); 
        $issueDate = array_reverse($issueDate);
        echo $issueDate = implode('/',$issueDate);
     ?>
     </td>     
     <td class="LabPaddingLeft" valign="top">
     <?php 
     		$doctype= $news_item['document_type'];
     		$fileName = $news_item['document_file_name'];
     		if($fileName!="")
     		{
     	?>
     			<a href='././file_download.php?filename=<?php echo $fileName; ?>' target="_blank">
			    <?php
			     if($doctype=="free")
			     {
			     	echo "Free Download";
			     } 
			     if($doctype=="paid")
			     {
			     	echo "Paid Document";
			     }
			    if($doctype=="newsletter")
			     {
			     	echo "News Letter Document";
			     }
			     if($doctype=="misc")
			     {
			     	echo "Miscellaneous Document";
			     }
			     ?>
			     </a>
     	<?php 
     		}		
     ?>
     
     </td> 
     <td class="LabPaddingLeft" valign="top">
    <?php 
    	if($news_item['status']==0)
    	{
    		echo "<a href='index.php?c=accredationDoc&m=updateStatus&status=0&id=$id'>Activate</a>";
    	}
    	if($news_item['status']==1)
    	{
    		echo "<a href='index.php?c=accredationDoc&m=updateStatus&status=1&id=$id'>Deactivate</a>";
    	} 
    ?>
    </td>        
     <td class="LabPaddingLeft" valign="top"><a href="index.php?c=accredationDoc&m=editaccrdoc&id=<?php echo $id;?>">Edit</a>|
    <a href="index.php?c=accredationDoc&m=deleteaccrdoc&id=<?php echo $id;?>" onclick="Javascript: return confirm('Are you sure you want to delete ?')"
    >Delete</a>

</td>
</tr>
<?php
}
?>

</table>
<?php
}else{
	echo "No Record Found ";
}
if(isset($pagination) && $pagination="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
