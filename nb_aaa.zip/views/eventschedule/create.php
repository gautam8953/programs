<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){               
                $('#start_date').datepicker({ yearRange: '1930:2020' } );
                $('#end_date').datepicker({ yearRange: '1930:2020' } );
            });
</script>
<?php echo validation_errors(); ?>
<?php echo form_open('c=eventschedule&m=create') ?>



<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add Training</td>
</tr>
<tr>
<td style="height:15px;">
</td>
</tr>
<tr>
<td>
<div style="overflow:auto; width:930px;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
Add Training
</td>
</tr>
<tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Event Type * </td>
              <td width="30%" align="left"> 
              <select name="event_type_id" id="event_type_id" style="width: 150px;">
                <option value="1" selected>Please Select</option>
                <?php                     	
	              	for($i=0;$i<count($eventType);$i++)
	              	{ 
	              ?>
                	<option value="<?php echo $eventType[$i]['id'] ?>"><?php echo $eventType[$i]['event_type_name'] ;?></option>
                <?php
	              	} 
	             ?>
              </select></td>
              <td width="20%" align="left">Name of Program *  </td>
              <td width="30%" align="left"><input name="program_name" type="text" id="program_name"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft"> Course Details * </td>
              <td width="30%" align="left"><textarea name="course_detail" cols="30" rows="3" id="course_detail"></textarea></td>
              <td width="20%" align="left">Venue * </td>
              <td width="30%" align="left"><textarea name="venue" cols="30" rows="3" id="venue"></textarea></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Contact Person </td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="contact_person" type="text" id="contact_person"></td>
              <td width="20%" align="left">Designation</td>
              <td width="30%" align="left"><input name="designation" type="text" id="designation"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Contact Address *</td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <textarea name="contact_address" cols="30" rows="3" id="contact_address"></textarea> </td>
              <td width="20%" align="left">Pincode</td>
              <td width="30%" align="left"><input name="pin" type="text" id="pin"> </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">City * </td>
              <td width="30%" align="left">
              <select name="city" id="city" style="width: 150px;" >
                <option value="1" selected>Please Select</option>
                <?php                     	
	              	for($i=0;$i<count($city);$i++)
	              	{ 
	              ?>
                <option value="<?php echo $city[$i]['id'] ?>"><?php echo $city[$i]['name'] ;?></option>
                <?php
	              	} 
	             ?>
              </select></td>
              <td width="20%" align="left">Phone * </td>
              <td width="30%" align="left"><input name="phone" type="text" id="phone"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">State *</td>
              <td width="30%" align="left"><select name="state" id="state" style="width: 150px;" >
                <option value="0" selected>Please Select</option>
                <?php                     	
	              	for($i=0;$i<count($state);$i++)
	              	{ 
	              ?>
                <option value="<?php echo $state[$i]['id'] ?>"><?php echo $state[$i]['name'] ;?></option>
                <?php
	              	} 
	             ?>
              </select></td>
              <td width="20%" align="left">Fax</td>
              <td width="30%" align="left"><input name="fax" type="text" id="fax"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Country *  </td>
              <td width="30%" align="left">
              <select name="country" id="country" style="width:150px;">
              <option value="0" selected>Please Select</option>
	            <?php                     	
	              	for($i=0;$i<count($country);$i++)
	              	{ 
	              ?>
	                	<option value="<?php echo $country[$i]['id'] ?>"><?php echo $country[$i]['name'] ;?></option>
	              <?php
	              	} 
	             ?> 
              </select>
              
              </td>
              <td width="20%" align="left">Email ID </td>
              <td width="30%" align="left"><input name="emailid" type="text" id="emailid"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Start Date  </td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="start_date" type="text" id="start_date"></td>
              <td width="20%" align="left">End Date </td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="end_date" type="text" id="end_date"></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Program Fees (INR) * </td>
              <td width="30%" align="left"><input name="program_fees" type="text" id="program_fees"></td>
              <td width="20%" align="left" >Remark</td>
              <td width="30%" align="left">
              <textarea name="remark" id="remark" cols="20" rows="3" ></textarea>
              </td>
            </tr>
           <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td colspan="4" align="center">
              <center>
             <input type="submit" name="submit" value="Submit" onclick="javascript:return validateTraningAwarenessForm();">
                <input type="reset" name="reset" value="Reset">
                <?php
			  		echo anchor('c=eventschedule&m=index', 'Back');
			    ?>     </center>     
                </td>              
            </tr>
            <tr>
<td style="height:5px;" colspan="4">
</td>
</tr>
          </table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
 </form> 
