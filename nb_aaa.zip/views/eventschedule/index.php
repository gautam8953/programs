
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Manage Training</td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=eventschedule&m=create">Add Training</a>
</td>
</tr>
<tr>
<td>
<?php
if(count($news)>0){
?>
<div style="overflow:auto; width:930px;">
<table width="100%" align="center" border="1" cellpadding="4" cellspacing="1">
<tr>
<!-- <td class="LaboratoryGridHead LabPaddingLeft" style="width:5%">Si No</td>  -->
<td class="LaboratoryGridHead LabPaddingLeft"  style="width:30%" >Program Name</td>
<td class="LaboratoryGridHead LabPaddingLeft" style="width:15%"  >Course Details</td>
<td class="LaboratoryGridHead LabPaddingLeft" style="width:10%"  >Start Date</td>
<td class="LaboratoryGridHead LabPaddingLeft" style="width:10%"  >End Date</td>
<th class="LaboratoryGridHead LabPaddingLeft" style="width:20%"  >Activate / Deactivate</th>
<td class="LaboratoryGridHead LabPaddingLeft" style="width:10%"  >Action</td>
<?php
$i=0;
foreach ($news as $news_item){ 
	$id = $news_item['id'];
?>
<tr>
	<!-- <td class="LabPaddingLeft" valign="top"><?php //echo ++$i;?></td>  -->  
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['program_name'] ?></td>   
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['course_detail'] ?></td>       
    <td class="LabPaddingLeft" valign="top">
    <?php 
    		//echo $news_item['start_date']; 
    		$startDate = explode('-',$news_item['start_date']); 
            $startDate = array_reverse($startDate);
            $startDate = implode('/',$startDate);
            if($startDate=="00/00/0000")
            {
            	echo "";
            }
            else 
            {
            	echo $startDate;
            }
    ?>
    </td>
    <td class="LabPaddingLeft" valign="top">
    <?php     		
    		//echo $news_item['end_date'];
    		$endDate = explode('-',$news_item['end_date']); 
            $endDate = array_reverse($endDate);
            $endDate = implode('/',$endDate);
			if($endDate=="00/00/0000")
            {
            	echo "";
            }
            else 
            {
            	echo $endDate;
            }
    ?>
    </td> 
    <td class="LabPaddingLeft" valign="top">
    <?php 
    	if($news_item['status']==0)
    	{
    		echo "<a href='index.php?c=eventschedule&m=updateStatus&status=0&id=$id'>Activate</a>";
    	}
    	if($news_item['status']==1)
    	{
    		echo "<a href='index.php?c=eventschedule&m=updateStatus&status=1&id=$id'>Deactivate</a>";
    	} 
    ?>
    </td>   
    <td class="LabPaddingLeft" valign="top"><a href="index.php?c=eventschedule&m=editschedule&id=<?php echo $news_item['id'];?>">Edit</a>|
    <a href="index.php?c=eventschedule&m=deleteschedule&id=<?php echo $news_item['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this category ?')"
    >Delete</a>

</td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Record Found ";
}
if(isset($pagination) && $pagination=="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>

</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>