<script src="js/ajax.js"></script>
<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
    $(document).ready(function () {
        //For date of birth
        $('#issue_date').datepicker({yearRange: '1930:2020'});
        $('#expiry_date').datepicker({yearRange: '1930:2020'});
        $('#extend_upto').datepicker({yearRange: '1930:2020'});
    });
</script>
<script language='JavaScript' type='text/javascript'>
    /*
     function addsubgroups()
     {
     var subgroups = document.getElementById('subgroup_id').value;
     tempArr = subgroups.split("-");
     subGroupShowStr = tempArr[1];
     subGroupHideStr = tempArr[0];	
     var opt = document.createElement('option');  
     document.getElementById('subgroupsList').options.add(opt);     
     opt.text = subGroupShowStr;
     opt.value = subGroupHideStr;
     opt.selected=true;
     }
     
     function deletesubgroups()
     {
     var i;
     selectbox =  document.getElementById('subgroupsList');
     for(i=selectbox.options.length-1;i>=0;i--)
     {
     if(selectbox.options[i].selected)
     {
     selectbox.remove(i);
     }
     }
     }
     */
    /*
     function addsubgroups()
     {
     var existsShowSubGroup = document.getElementById('show_multiple_subgroups').innerHTML;
     var existsHideSubGroup = document.getElementById('multiplesubgroups').value;
     
     var subgroups = document.getElementById('subgroup_id').value;
     tempArr1 = subgroups.split("-");	
     subGroupShowStr = existsShowSubGroup+'<br/>'+tempArr1[1];	
     subGroupHideStr = existsHideSubGroup+','+tempArr1[0];
     document.getElementById('show_multiple_subgroups').innerHTML = subGroupShowStr;
     document.getElementById('multiplesubgroups').value = subGroupHideStr;
     //alert(document.getElementById('multiplesubgroups').value);
     }
     */
</script>
<div class="tpcontainermainc" style="width: 940px">
    <table class="contentpaneopen detail">

        <tr>
            <td align="center">
                <?php echo validation_errors(); ?>
                <?php echo form_open_multipart('c=certificate&m=editcertificate&id=' . $_GET['id']) ?>
                <div class="tpcontainermainc" style="width: 940px">
                    <table class="contentpaneopen detail">
                        <tr>
                            <td class="contentheading">Edit Certificate</td>
                        </tr>
                        <tr>
                            <td style="height:15px;">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div style="overflow:auto; width:930px;">
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
                                        <tr>
                                            <td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
                                                Edit Certificate
                                            </td>
                                        </tr>
                                        <tr><td style="height:10px;" colspan="4"></td></tr>
                                        <tr>
                                            <td width="22%" align="left" class="LabPaddingLeft">Laboratory *</td>
                                            <td width="75%" align="left" colspan="3">
                                                <select name="lab_id" id="lab_id" style="width:150px;">
                                                    <option value="1" selected>Please Select</option>
                                                    <?php
                                                    for ($i = 0; $i < count($lab); $i++) {
                                                        $selected = '';
                                                        if ($lab[$i]['id'] == $news['lab_id'])
                                                            $selected = 'selected';
                                                        ?>
                                                        <option value="<?php echo $lab[$i]['id'] ?>" <?php echo $selected; ?> ><?php echo $lab[$i]['lab_registration_code'] . " : " . $lab[$i]['lab_name']; ?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select></td>              
                                        </tr>
                                        <tr><td style="height:10px;" colspan="4"></td></tr>
                                        <tr>
                                            <td width="22%" align="left" class="LabPaddingLeft">Certificate File *</td>
                                            <td width="32%" align="left"> 
                                                <input name="certificatedoc" type="file" id="certificatedoc">
                                                <br/>
                                                <a href="././file_download.php?filename=<?php echo $news['certificate_file']; ?>" target="_blank">
                                                    <?php echo $news['certificate_no']; ?>
                                                </a>
                                            </td>
                                            <td width="21%" align="left">Certificate No * </td>
                                            <td width="25%" align="left"><input name="certificate_no" type="text" id="certificate_no" value="<?php echo $news['certificate_no']; ?>" /> 

                                            </td>
                                        </tr>
                                        <tr><td style="height:10px;" colspan="4"></td></tr>
                                        <tr>
                                            <td align="left" class="LabPaddingLeft">Nature of Lab *</td>
                                            <td align="left"><select name="nature_of_lab" id="nature_of_lab">
                                                    <option value="-1" selected>Please Select</option>
                                                    <?php
                                                    for ($i = 0; $i < count($nolab); $i++) {
                                                        $selected = '';
                                                        if ($nolab[$i]['id'] == $news['nature_of_lab'])
                                                            $selected = 'selected';
                                                        ?>
                                                        <option value="<?php echo $nolab[$i]['id'] ?>" <?php echo $selected; ?> ><?php echo $nolab[$i]['nature_name']; ?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select></td>
                                            <td align="left">Facility * <br/>
                                                <span class="LabSubText"> <strong>(Press Ctrl for multiple selection)</strong></span></td>
                                            <td align="left"><?php
                                                    echo $operat;
                                                    ?></td>
                                        </tr>
                                        <tr><td style="height:10px;" colspan="4"></td></tr>
                                        <tr>
                                            <td width="22%" align="left" class="LabPaddingLeft">Issue Date *</td>
                                            <td width="32%" align="left">
<?php
$isseueDate = explode('-', $news['issue_date']);
$isseueDate = array_reverse($isseueDate);
$isseueDate = implode('-', $isseueDate);

$expiryDate = explode('-', $news['expiry_date']);
$expiryDate = array_reverse($expiryDate);
$expiryDate = implode('-', $expiryDate);
/* added by niraj.lal.rahi */
$extend_date = explode('-', $news['extend_date']);
$extend_date = array_reverse($extend_date);
$extend_date = implode('-', $extend_date);
$extend_date = (empty($extend_date) || $extend_date === '00-00-0000' ) ? '' : $extend_date;
/* end here */
?>
                                                <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
                                                <script src="js/ui.datepicker.js"></script>  
                                                <input name="issue_date" type="text" id="issue_date" value="<?php echo $isseueDate; ?>" /> 
                                            </td>
                                            <td width="21%" align="left"><span class="LabPaddingLeft">Expiry Date * </span></td>
                                            <td width="25%" align="left">
                                                <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
                                                <script src="js/ui.datepicker.js"></script>
                                                <input name="expiry_date" type="text" id="expiry_date" value="<?php echo $expiryDate; ?>" /></td>
                                        </tr>
                                        <tr><td style="height:10px;" colspan="4"></td></tr>
                                        <tr>
                                            <td align="left" class="LabPaddingLeft">Field * </td>
                                            <td align="left"><?php echo $facilitydropdown; ?></td>
                                            <td align="left">Extend upto * </td>
                                            <td align="left">  
                                                <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
                                                <script src="js/ui.datepicker.js"></script>
                                                <input name="extend_upto" type="text" id="extend_upto" value ="<?php echo $extend_date; ?>" />
                                            </td>
                                        </tr>

                                        <tr><td  colspan="4"><hr width="98%" style="margin-top:18px;"></td></tr>
                                        <tr><td style="height:10px;" colspan="4"></td></tr>
                                        <tr>

                                            <td width="22%" align="left" class="LabPaddingLeft">Discipline * </td>
                                            <td width="32%" align="left">
                                                <div id='field'>
<?php echo $fielddropdown; ?>
                                                </div> 
                                            </td>

                                            <td align="left" class="LabPaddingLeft">Group *</td>
                                            <td align="left">
                                                <div id="group">
<?php echo $groupdropdown; ?>                            
                                                </div>
                                            </td>

                                            </td>
                                        </tr>

                                        <!--
                            <tr><td style="height:10px;" colspan="4"></td></tr>
                                        
                            <tr>
                              <td align="left" class="LabPaddingLeft">Group *</td>
                              <td align="left">
                              <div id="group">
<?php //echo $groupdropdown;  ?>                            
                              </div>
                              </td>
                              <td align="left"></td>
                              <td align="left">&nbsp;</td>
                            </tr>
                                        -->
                                        <tr><td style="height:10px;" colspan="4"></td></tr>
                                        <tr>
                                            <td align="left" class="LabPaddingLeft">Sub Group *</td>
                                            <td align="left">
                                                <div id="subgroup">
                                                    <select name="subgroup[]" id="subgroup_id" style="width:150px;" size='15' multiple >
                                                        <option value="0" selected>Please Select</option>
                                                    </select>                          
                                                </div> 
                                            </td>
                                            <td align="center">
                                                <input type="button" name="add" id="add" value="Add" onclick="javascript:return addsubgroups()" />
                                                <br/>
                                                <br/>
                                                <input type="button" style="display:none;" name="remove" id="remove" value="Remove" onclick="javascript:return deletesubgroups()" /> 

                                            </td>
                                            <!--
                                <td align="left" valign="top">              
<?php /*
  $str = explode(",",$news['subGroupName']);
  echo "<select name='subgroupsList[]' size='10' id='subgroupsList' multiple>";
  for($a=0;$a<count($str);$a++)
  {
  $tempStr = explode('-',$str[$a]);
  echo "<option value='$tempStr[1]' selected='selected'>$tempStr[0]</option>";
  }
  echo "</select>";

 */
?>
                                            -->
                                            <!--
                                                      <input type="hidden" name="multiplesubgroups" id="multiplesubgroups" value="<?php //echo $news['subgroupid']; ?>" />
                                            -->
                                            <!--
                                </td>
                                            -->

                                            <!--new @ 10-04-2017 -->   
                                        <tr><td style="height:10px;" colspan="4"></td></tr>
                                        <tr>
                                            <td colspan="4">
                                                <table border="1px solid" align="center" style="margin: 0 auto;" width="900px" id="table_grid">
                                                    <tr style="text-align:center; background-color:#008080; color:white;">
                                                        <th style="border-right:1px solid #333;">
                                                            <input type="checkbox" name="delete_checkbox" id="chkselectAll" value="1" onclick="return selectAll();"> Select All 

                                                        </th>
                                                        <th style="border-right:1px solid #333;">Discipline</th>
                                                        <th style="border-right:1px solid #333;">Group</th>
                                                        <th style="border-right:1px solid #333;">Subgroup</th>
                                                        <th>Action</th>
                                                    </tr>
<?php
$tbl_data_row_count = 1;

foreach ($row as $data) {


    echo '<tr id="rem' . $tbl_data_row_count . '">';
    echo '<td style="text-align: center;"> <input type="checkbox" name="delete_checkbox[]" value="' . $tbl_data_row_count . '" onclick="return selectChild();"></td>';

    echo '<td style="padding-left: 5px;">' . $data['discipline'] . '<input type="hidden" name="newdescipline[]" value="' . $data['desciplineID'] . '"/></td>';


    echo '<td style="padding-left: 5px;">' . $data['group_name'] . '<input type="hidden" name="newgroup[]" value="' . $data['groupID'] . '"/></td>';


    echo '<td style="padding-left: 5px;">' . $data['subgroup'] . '<input type="hidden" name="subgroupsList[]" id="newsubgroup" value="' . $data['groupID'] . '_' . $data['subgroupID'] . '"/></td>';

    echo '<td style="padding-left: 5px;">
										<a href="javascript:void(0)" rel="' . $tbl_data_row_count . '+' . $data['id'] . '+' . $data['desciplineID'] . '+' . $data['groupID'] . '+' . $data['groupID'] . '_' . $data['subgroupID'] . '-' . $data['subgroup'] . '" onclick="editGridRow(this); ">Edit</a> 
										<!--<a href="javascript:void(0)" onclick="removeGridRow(\'' . $tbl_data_row_count . '\');">Delete</a>-->
									</td></tr>';
    $tbl_data_row_count++;
}
?>
                                                </table>
                                            </td>
                                        </tr>
                                        <!-- new change end --> 

                                        </tr>
                                        <tr>
                                            <td width="22%" align="left" class="LabPaddingLeft">&nbsp;</td>
                                            <td width="32%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
                                                <script src="js/ui.datepicker.js"></script>
                                                <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
                                                <script src="js/ui.datepicker.js"></script>                      
                                            </td>
                                            <td width="21%" align="left"></td>
                                            <td width="25%" align="left">&nbsp;

                                            </td>
                                        </tr>

                                        <tr><td style="height:10px;" colspan="4"></td></tr>
                                        <tr>
                                            <td colspan="4" align="center">

                                        <center>
                                            <input type="button" value="Delete" style="float: left; margin-left: 3%;" onClick="return deleteMultiple();">
                                            <input type="submit" name="submit" value="Upload" onclick="javascript:return validateCertificateForm();">
                                            <input type="reset" name="reset" value="Reset">
<?php
echo anchor('c=certificate&m=index', 'back');
?>   </center>     
                                        </td>              
                                        </tr>
                                        <tr><td style="height:10px;" colspan="4"></td></tr>
                                    </table>
                            </td>
                        </tr>
                        <tr>
                            <td height="25px"></td></tr>
                    </table>
                </div>
                </form>
            </td>
        </tr>
        <tr>
            <td height="25px"></td></tr>
    </table>
</div>
<script language='JavaScript' type='text/javascript'>
    var global_field = null;
    var global_count = 0;
<?php
if ($tbl_data_row_count > 0) {
    ?>
        global_count = <?php echo $tbl_data_row_count; ?>;
    <?php
} else {
    ?>
        global_count = 0;
    <?php
}
?>
    var remove_pos_id = 0;

    function createTableRow(new_subgroup_text, new_subgroup_val) {
        global_count += 1;
//getting selected data 
        var new_discipline_text = $("#field_id option:selected").text();
        var new_discipline_val = $("#field_id option:selected").val();

        var new_group_text = $("#group_id option:selected").text();
        var new_group_val = $("#group_id option:selected").val();

//var new_subgroup_text = $("#subgroup_id option:selected").text();
//var new_subgroup_val = $("#subgroup_id option:selected").val();
        var facility_field = $("#facility_id option:selected").val();


        if (global_field == null || global_field == '') {
        } else {
//            console.log(facility_field);
            if (global_field != facility_field) {
                alert('Sorry! You can not select multiple field.');
                return;
            }
        }


        if (new_discipline_val == '-1' || new_discipline_val == '' ||
                new_group_val == '-1' || new_group_val == '' ||
                new_subgroup_val == '-1' || new_subgroup_val == ''
                ) {
            alert('Please select required field value.');
            return;
        }
//removing in case of edit
        if (remove_pos_id > 0) {
            $("#rem" + remove_pos_id).remove();
            remove_pos_id = 0;
            $("#add").val("Add");
        }
//creating row
        var row = '<tr id="rem' + global_count + '">';
        row += '<td style="padding-left: 5px;"> <input type="checkbox" name="delete_checkbox[]" value="' + global_count + '" onclick="return selectChild();"></td>'
        row += '<td style="padding-left: 5px;">' + new_discipline_text + '<input type="hidden" name="newdescipline[]" value="' + new_discipline_val + '"/></td>';
        row += '<td style="padding-left: 5px;">' + new_group_text + '<input type="hidden" name="newgroup[]" value="' + new_group_val + '"/></td>';
        row += '<td style="padding-left: 5px;">' + new_subgroup_text + '<input type="hidden" name="subgroupsList[]" id="newsubgroup" value="' + new_subgroup_val + '"/></td>';
        row += '<td style="padding-left: 5px;">';
        row += '<a href="javascript:void(0)" rel="' + global_count + '+' + facility_field + '+' + new_discipline_val + '+' + new_group_val + '+' + new_subgroup_val + '-' + new_subgroup_text + '" onclick="editGridRow(this);">Edit</a>';
        //row += '<a href="javascript:void(0)" onclick="removeGridRow(\''+global_count+'\');">Delete</a>';
        row += '</td></tr>';
//appending row in table	
        $("#table_grid").append(row);
        global_field = facility_field;
        row = '';
        sortTable();
    }
//removing grid
    function removeGridRow(row_id) {
        if (window.confirm('Do you want to remove?')) {
            $("#rem" + row_id).remove();
        }
    }
//editing grid
    function editGridRow(info) {
        if (window.confirm('Do you want to edit?')) {
            $("#add").val("Update");
            var all_data = info.rel.split("+");
            var row_id = all_data[0];
            var field_id = all_data[1];
            var disci_id = all_data[2];
            var grp_id = all_data[3];
            var sub_grp_id = all_data[4];
            $("#facility_id").val(field_id);
            loadDropDownOnEdit(field_id, disci_id, grp_id, sub_grp_id);
            remove_pos_id = row_id;
        } else {
            //
        }
    }
    function loadDropDownOnEdit(f_id, disc_id, gp_id, sgrp_id) {
        var query_str = '<?php echo base_url("helpers/bindDropDownOnEdit.php"); ?>?f_id=' + f_id + '&disc_id=' + disc_id + '&gp_id=' + gp_id;
        $.ajax({
            url: query_str,
            type: 'get',
            async: false,
            success: function (data) {
                var rec = JSON.parse(data);
                $('#field_id').html();
                $('#field_id').html(rec['Discipline']);
                $("#field_id").val(disc_id);

                $('#group_id').html('');
                $('#group_id').html(rec['Group']);
                $("#group_id").val(gp_id);

                $('#subgroup_id').html();
                $('#subgroup_id').html(rec['SubGroup']);
                $("#subgroup_id").val([sgrp_id]);
            },
            error: function (data) {
                console.log(data);
            }
        });
    }
    function sortTable() {
        var table, rows, switching, i, x, y, shouldSwitch;
        table = document.getElementById("table_grid");
        switching = true;
        /*Make a loop that will continue until
         no switching has been done:*/
        while (switching) {
            //start by saying: no switching is done:
            switching = false;
            rows = table.getElementsByTagName("TR");
            /*Loop through all table rows (except the
             first, which contains table headers):*/
            for (i = 1; i < (rows.length - 1); i++) {
                //start by saying there should be no switching:
                shouldSwitch = false;
                /*Get the two elements you want to compare,
                 one from current row and one from the next:*/
                x = rows[i].getElementsByTagName("TD")[0];
                y = rows[i + 1].getElementsByTagName("TD")[0];
                //check if the two rows should switch place:
                if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                    //if so, mark as a switch and break the loop:
                    shouldSwitch = true;
                    break;
                }
            }
            if (shouldSwitch) {
                /*If a switch has been marked, make the switch
                 and mark that a switch has been done:*/
                rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                switching = true;
            }
        }
    }

    var subGroupShowStr = "";
    var subGroupHideStr = "";

    function addsubgroups() {
        var allSub = [];
        var temp = 0;
        var s = document.getElementById("subgroup_id");
        for (var i = 0; i < s.options.length; i++) {
            temp = 0;
            if (s.options[i].selected == true) {
                var sid = s.options[i].value;
                allSub.push(sid);
                tempArr = sid.split("-");
                subGroupShowStr = tempArr[1];
                subGroupHideStr = tempArr[0];
                //var k = document.getElementById("newsubgroup");
                var k = document.getElementsByName('subgroupsList[]');
                if (k == null || k.length == 0) {
                    temp = 0;
                } else {
                    for (var j = 0; j < k.length; j++) {
                        if (k[j].value == subGroupHideStr) {
                            temp = 1;
                            alert('You can not add duplicate subgroup.');
                        } else {
                            //
                        }
                    }
                }
                if (temp != 1) {
                    allSub.push(sid);
                    tempArr = sid.split("-");
                    subGroupShowStr = tempArr[1];
                    subGroupHideStr = tempArr[0];
                    createTableRow(subGroupShowStr, subGroupHideStr);
                }
            }
        }
        var subgroups = document.getElementById('subgroup_id').value;
    }

    function clearSubgroup() {
        $("#subgroup_id option").remove();
        $('#subgroup_id').html('<option value="-1" selected>Please Select</option>');
    }

    function clearGroup() {
        $("#group_id option").remove();
        $('#group_id').html('<option value="-1" selected>Please Select</option>');
    }
    function selectAll() {

        if ($("#chkselectAll").is(":checked"))
            $("input[name='delete_checkbox[]']").attr("checked", true);
        else
            $("input[name='delete_checkbox[]']").attr("checked", false);
    }
    function selectChild() {
        var checked = "0";
        $("input[name='delete_checkbox[]']").each(function () {
            if (!($(this).is(":checked")))
                checked++;
        });
        if (checked)
            $("#chkselectAll").attr("checked", false);
        if (checked == "0")
            $("#chkselectAll").attr("checked", true);

    }
    function deleteMultiple() {
        var checked = "0";
        $("input[name='delete_checkbox[]']").each(function () {
            if ($(this).is(":checked"))
            {
                checked++;
            }

        });
        if (checked == "0")
        {
            return alert("Please select atleast 1 checkbox.");
        } else {
            if (window.confirm("Are you sure?")) {
                $("input[name='delete_checkbox[]']").each(function () {
                    if ($(this).is(":checked"))
                    {
                        var row_id = $(this).val();
                        $("#rem" + row_id).remove();
                        $("#chkselectAll").attr("checked", false);
                    }
                });
            }
        }

    }

</script>
<script type="text/javascript">
    $(document).ready(function () {
        global_field = $("#facility_id").val();

    });
</script>