<script src="js/ajax.js"></script>
<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){
                //For date of birth
                $('#issue_date').datepicker({ yearRange: '1930:2020' } );
                $('#expiry_date').datepicker({ yearRange: '1930:2020' } );
            });
</script>
<script language='JavaScript' type='text/javascript'>
function addsubgroups()
{
	var subgroups = document.getElementById('subgroup_id').value;
	tempArr = subgroups.split("-");
	subGroupShowStr = tempArr[1];
	subGroupHideStr = tempArr[0];	
	var opt = document.createElement('option');  
    document.getElementById('subgroupsList').options.add(opt);     
    opt.text = subGroupShowStr;
    opt.value = subGroupHideStr;
    opt.selected=true;
}

function deletesubgroups()
{
	var i;
	selectbox =  document.getElementById('subgroupsList');
	for(i=selectbox.options.length-1;i>=0;i--)
	{
		if(selectbox.options[i].selected)
		{
			selectbox.remove(i);
		}
	}
}
/*
function addsubgroups()
{
	var existsShowSubGroup = document.getElementById('show_multiple_subgroups').innerHTML;
	var existsHideSubGroup = document.getElementById('multiplesubgroups').value;
	
	var subgroups = document.getElementById('subgroup_id').value;
	tempArr1 = subgroups.split("-");	
	subGroupShowStr = existsShowSubGroup+'<br/>'+tempArr1[1];	
	subGroupHideStr = existsHideSubGroup+','+tempArr1[0];
	document.getElementById('show_multiple_subgroups').innerHTML = subGroupShowStr;
	document.getElementById('multiplesubgroups').value = subGroupHideStr;
	//alert(document.getElementById('multiplesubgroups').value);
}
*/
</script>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">

<tr>
<td align="center">
<?php echo validation_errors(); ?>
<?php echo form_open_multipart('c=certificate&m=editcertificate&id='.$_GET['id']) ?>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Edit Certificate</td>
</tr>
<tr>
<td style="height:15px;">
</td>
</tr>
<tr>
<td>
<div style="overflow:auto; width:930px;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
Edit Certificate
</td>
</tr>
<tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="22%" align="left" class="LabPaddingLeft">Laboratory *</td>
              <td width="75%" align="left" colspan="3">
              <select name="lab_id" id="lab_id" style="width:150px;">
              <option value="1" selected>Please Select</option>
              <?php                     	
              	for($i=0;$i<count($lab);$i++)
              	{ 
              		$selected = '';
              		if($lab[$i]['id']==$news['lab_id'])
              			$selected = 'selected';
              ?>
                	<option value="<?php echo $lab[$i]['id'] ?>" <?php echo $selected; ?> ><?php echo $lab[$i]['lab_registration_code']." : ".$lab[$i]['lab_name'] ;?></option>
              <?php
              	} 
              ?>
              </select></td>              
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="22%" align="left" class="LabPaddingLeft">Certificate File *</td>
              <td width="32%" align="left"> 
              <input name="certificatedoc" type="file" id="certificatedoc">
              <br/>
               <a href="././file_download.php?filename=<?php echo $news['certificate_file']; ?>" target="_blank">
					   <?php echo $news['certificate_no']; ?>
				</a>
              </td>
              <td width="21%" align="left">Certificate No * </td>
              <td width="25%" align="left"><input name="certificate_no" type="text" id="certificate_no" value="<?php echo $news['certificate_no']; ?>" /> 
                
                </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td align="left" class="LabPaddingLeft">Nature of Lab *</td>
              <td align="left"><select name="nature_of_lab" id="nature_of_lab">
                <option value="-1" selected>Please Select</option>
                <?php                     	
              	for($i=0;$i<count($nolab);$i++)
              	{ 
              		$selected = '';
              		if($nolab[$i]['id']==$news['nature_of_lab'])
              			$selected = 'selected';
              ?>
                <option value="<?php echo $nolab[$i]['id'] ?>" <?php echo $selected; ?> ><?php echo $nolab[$i]['nature_name']; ?></option>
                <?php
              	} 
              ?>
              </select></td>
              <td align="left">Facility * <br/>
                <span class="LabSubText"> <strong>(Press Ctrl for multiple selection)</strong></span></td>
              <td align="left"><?php                  	
              		echo $operat;            	
                ?></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="22%" align="left" class="LabPaddingLeft">Issue Date *</td>
              <td width="32%" align="left">
              <?php
              		$isseueDate = explode('-',$news['issue_date']); 
              		$isseueDate = array_reverse($isseueDate);
              		$isseueDate = implode('-',$isseueDate);
              		
              		$expiryDate = explode('-',$news['expiry_date']); 
              		$expiryDate = array_reverse($expiryDate);
              		$expiryDate = implode('-',$expiryDate);
              		
              		
              		
              ?>
               <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>  
              <input name="issue_date" type="text" id="issue_date" value="<?php echo $isseueDate; ?>" /> 
              </td>
              <td width="21%" align="left"><span class="LabPaddingLeft">Expiry Date * </span></td>
              <td width="25%" align="left">
               <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="expiry_date" type="text" id="expiry_date" value="<?php echo $expiryDate; ?>" /></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td align="left" class="LabPaddingLeft">Field * </td>
              <td align="left"><?php echo $facilitydropdown;?></td>
              <td align="left">&nbsp;</td>
              <td align="left">
              
              </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="22%" align="left" class="LabPaddingLeft">Discipline * </td>
              <td width="32%" align="left">
              <div id='field'>
               <?php echo $fielddropdown; ?>
              </div> 
              </td>
              <td width="21%" align="left">&nbsp;</td>
              <td width="25%" align="left"> 
                         
               </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td align="left" class="LabPaddingLeft">Group *</td>
              <td align="left">
              <div id="group">
              <?php echo $groupdropdown; ?>                            
              </div>
              </td>
              <td align="left"></td>
              <td align="left">&nbsp;</td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td align="left" class="LabPaddingLeft">Sub Group *</td>
              <td align="left">
              <div id="subgroup">
              <select name="subgroup[]" id="subgroup_id" style="width:150px;" size='15' multiple >
              <option value="0" selected>Please Select</option>
              </select>                          
              </div> 
              </td>
              <td align="center">
              <input type="button" name="add" id="add" value="Add" onclick="javascript:return addsubgroups()" />
              <br/>
              <br/>
              <input type="button" name="remove" id="remove" value="Remove" onclick="javascript:return deletesubgroups()" /> 
              
              </td>
              <td align="left" valign="top">              
              <?php  
              		$str = explode(",",$news['subGroupName']);              		
					echo "<select name='subgroupsList[]' size='10' id='subgroupsList' multiple>";
						for($a=0;$a<count($str);$a++)
						{
							$tempStr = explode('-',$str[$a]);							
							echo "<option value='$tempStr[1]' selected='selected'>$tempStr[0]</option>";							
						}
               		echo "</select>";	
			   
			   
                    
              ?>
              <!--
              		<input type="hidden" name="multiplesubgroups" id="multiplesubgroups" value="<?php //echo $news['subgroupid']; ?>" />
              -->
              </td>
            </tr>
            <tr>
              <td width="22%" align="left" class="LabPaddingLeft">&nbsp;</td>
              <td width="32%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
            <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>                      
              </td>
              <td width="21%" align="left"></td>
              <td width="25%" align="left">&nbsp;
             
              </td>
            </tr>
            
           <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td colspan="4" align="center">
              <center>
             <input type="submit" name="submit" value="Upload" onclick="javascript:return validateCertificateForm();">
                <input type="reset" name="reset" value="Reset">
                <?php
			  		echo anchor('c=certificate&m=index', 'back');
			    ?>   </center>     
                </td>              
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
          </table>
</form></td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>