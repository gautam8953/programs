<script type="text/javascript">
				function open_cer_win(certificateid)
				{
					//alert(certificateid);
					var cid = certificateid;
					
				/*window.open("index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid], _blank")
				window.open('index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid]', 'mywindow', 'location=1,status=1,scrollbars=1,width=100,height=100');
				*/
				//alert('index.php?c=search&m=searchlabcertificate&cno='+cid);
				testwindow  = window.open('index.php?c=certificate&m=view&cno='+cid , 'mywindow', 'scrollbars=no,menubar=no,height=400,width=700,resizable=yes,toolbar=no,location=no,status=no,scroll=yes');
				testwindow.moveTo(350, 300);
				}
				
				function open_lab_win(labid)
				{
					//alert(certificateid);
					var lid = labid;
					
				/*window.open("index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid], _blank")
				window.open('index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid]', 'mywindow', 'location=1,status=1,scrollbars=1,width=100,height=100');
				*/
				//alert('index.php?c=search&m=searchlabcertificate&cno='+cid);
				testwindow  = window.open('index.php?c=laboratory&m=view&lno='+lid , 'mywindow', 'scrollbars=no,menubar=no,height=300,width=800,resizable=yes,toolbar=no,location=no,status=no');
				testwindow.moveTo(350, 300);
				}
				
</script>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Manage Certificate</td>
</tr>
<tr>
<td align="center" valign="middle">
<br/>
<?php echo form_open('c=certificate&m=index') ?>

<table width="800" border="0" cellspacing="5" cellpadding="5" class="Border">
  <tr>
    <td class="LaboratoryGridHead LabPaddingLeft" valign="middle" colspan="4">Search Certificate</td>   
  </tr>
  <tr>
    <td width="200" align="left" valign="middle" class="LabPaddingLeft"><b>Lab Name</b></td>
    <td width="200" align="left" valign="middle" class="LabPaddingLeft"><b>Lab Registration Code</b></td>
    <td width="200" align="left" valign="middle" class="LabPaddingLeft"><b>Certificate No.</b></td>
    <td width="200" align="left" valign="middle" class="LabPaddingLeft">&nbsp;</td>
  </tr>
  <tr>
    <td align="left" valign="middle" class="LabPaddingLeft"><input type="text" name="labname" id="labname" /></td>
    <td align="left" valign="middle" class="LabPaddingLeft"><input type="text" name="labcode" id="labcode" /></td>
    <td align="left"  valign="middle" class="LabPaddingLeft"><input type="text" name="labcode2" id="labcode2" /></td>
    <td align="left"  valign="middle" class="LabPaddingLeft"><input type="submit" name="submit" id="submit" value="Search" /></td>
  </tr>
  <tr>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle">&nbsp;</td>
  </tr>
  </table>
</form>
</td>
</tr>


<tr>
<td class="LabAlighRight">
<a href="index.php?c=certificate&m=create">Add Certificate</a>
</td>
</tr>
<tr>
<td>
<?php

if(count($news)>0){
?>
<div style="overflow:auto; width:930px;">
<table align="center" border="1" cellpadding="0" cellspacing="0" width="100%">
<tr>
<th width="20%" class="LaboratoryGridHead LabPaddingLeft">Lab Name [Code]</th>
<th width="12%" class="LaboratoryGridHead LabPaddingLeft">Certificate No.</th>
<th width="11%" class="LaboratoryGridHead LabPaddingLeft">Field</th>
<th width="12%" class="LaboratoryGridHead LabPaddingLeft">Discipline</th>
<th width="10%" class="LaboratoryGridHead LabPaddingLeft">Issue Date</th>
<th width="10%" class="LaboratoryGridHead LabPaddingLeft">Expiry Date</th>
<th width="16%" class="LaboratoryGridHead LabPaddingLeft">Activate/Deactivate</th>
<th width="15%" class="LaboratoryGridHead LabPaddingLeft">Action</th>
<?php
$i=0;
foreach ($news as $news_item){ 
	 $id = $news_item['cid'];
	 $labid = $news_item['id'];
?>

<tr>
	<td class="LabPaddingLeft" valign="top"><?php echo "<a href='#' onClick=open_lab_win($labid)>".$news_item['lab_name']." [".$news_item['lab_registration_code']."]"."</a>"; ?></td>  
    <td class="LabPaddingLeft" valign="top"><?php echo "<a href='#' onClick=open_cer_win($id)>".$news_item['certificate_no']."</a>"; ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['facilityName']; ?></td>  
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['fieldName']; ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['issue_date'] ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['expiry_date'] ?></td>    
    <td class="LabPaddingLeft" valign="top">
    <?php 
    	if($news_item['status']==0)
    	{
    		echo "<a href='index.php?c=certificate&m=updateStatus&status=0&id=$id'>Activate</a>";
    	}
    	if($news_item['status']==1)
    	{
    		echo "<a href='index.php?c=certificate&m=updateStatus&status=1&id=$id'>Deactivate</a>";
    	} 
    ?>
    </td> 
    <td class="LabPaddingLeft" valign="top"><a href="index.php?c=certificate&m=editcertificate&id=<?php echo $news_item['cid'];?>">Edit</a>|
    <a href="index.php?c=certificate&m=deletecertificate&id=<?php echo $news_item['cid'];?>" onclick="Javascript: return confirm('Are you sure you want to delete it ?')"
    >Delete</a>
</td>
</tr>
<?php
}
?>

</table>
<?php
}else{
	echo "No Certificate Found ";
}

	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>