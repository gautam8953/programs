<script type="text/javascript">
				function open_cer_win(certificateid)
				{
					//alert(certificateid);
					var cid = certificateid;
					
				/*window.open("index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid], _blank")
				window.open('index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid]', 'mywindow', 'location=1,status=1,scrollbars=1,width=100,height=100');
				*/
				//alert('index.php?c=search&m=searchlabcertificate&cno='+cid);
				testwindow  = window.open('index.php?c=certificate&m=view&cno='+cid , 'mywindow', 'scrollbars=yes,menubar=no,height=500,width=700,resizable=yes,toolbar=no,location=no,status=no,scroll=yes');
				testwindow.moveTo(100, 100);
				}
				
				function open_lab_win(labid)
				{
					//alert(certificateid);
					var lid = labid;
					
				/*window.open("index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid], _blank")
				window.open('index.php?c=search&m=searchlabcertificate&cno=$labdata_items[certificateid]', 'mywindow', 'location=1,status=1,scrollbars=1,width=100,height=100');
				*/
				//alert('index.php?c=search&m=searchlabcertificate&cno='+cid);
				testwindow  = window.open('index.php?c=laboratory&m=view&lno='+lid , 'mywindow', 'scrollbars=yes,menubar=no,height=500,width=800,resizable=yes,toolbar=no,location=no,status=no');
				testwindow.moveTo(100, 100);
				}
				
</script>
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Manage Certificate</td>
</tr>
<tr>
<td align="center" valign="middle">
<br/>
<?php echo form_open('c=certificate&m=index') ?>

<table width="800" border="0" cellspacing="5" cellpadding="5" class="Border">
  <tr>
    <td class="LaboratoryGridHead LabPaddingLeft" valign="middle" colspan="4">Search Certificate</td>   
  </tr>
  <tr>
    <td width="200" align="left" valign="middle" class="LabPaddingLeft"><b>Lab Name</b></td>
    <td width="200" align="left" valign="middle" class="LabPaddingLeft"><b>Lab Registration Code</b></td>
    <td width="200" align="left" valign="middle" class="LabPaddingLeft"><b>Certificate No.</b></td>
    <td width="200" align="left" valign="middle" class="LabPaddingLeft">&nbsp;</td>
  </tr>
  <tr>
    <td align="left" valign="middle" class="LabPaddingLeft"><input type="text" name="labname" id="labname" /></td>
    <td align="left" valign="middle" class="LabPaddingLeft"><input type="text" name="labcode" id="labcode" /></td>
    <td align="left"  valign="middle" class="LabPaddingLeft"><input type="text" name="certificateno" id="certificateno" /></td>
    <td align="left"  valign="middle" class="LabPaddingLeft"><input type="submit" name="submit" id="submit" value="Search" /></td>
  </tr>
  <tr>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle">&nbsp;</td>
  </tr>
  </table>
</form>
</td>
</tr>


<tr>
<td class="LabAlighRight">
<a href="index.php?c=certificate&m=create">Add Certificate</a>
</td>
</tr>
<tr>
<td>
<?php

if(count($labdata)>0){
	if(isset($total_rows) && count($total_rows)>0)
	{
		echo "Total ".count($total_rows)." Records Found";
	}
?>
<div style="overflow:auto; width:940px;">
<table id="manage-certificate" align="center" border="1" cellpadding="0" cellspacing="0" width="940px">
<tr>
<th width="105px" class="LaboratoryGridHead">Lab Name[Code]</th>
<th width="125px" class="LaboratoryGridHead">Certificate No.</th>
<th width="120px" class="LaboratoryGridHead">Field</th>
<th width="135px" class="LaboratoryGridHead">Discipline</th>
<th width="75px" class="LaboratoryGridHead">Issue Date</th>
<th width="75px" class="LaboratoryGridHead">Expiry Date</th>
<th width="75px" class="LaboratoryGridHead">Extend Upto</th>
<th width="140px" class="LaboratoryGridHead">Activate/Deactivate</th>
<th width="90px" class="LaboratoryGridHead">Action</th>
</tr>
<?php
$i=0;
foreach ($labdata as $labdata_item){ 
	 //$id = $labdata_item['cid'];
	 $labid = $labdata_item['id'];
?>

<tr>
	<td width="100%" valign="top" colspan="9" bgcolor="#cccccc"><b>
	<?php echo "<a href='#' onClick=open_lab_win($labid)>".$labdata_item['lab_name']." [".$labdata_item['lab_registration_code']."]"."</a>"; ?></b>
	</td>
	</tr>	
	<?php
	if(count($cdata)>0)
	{
			//echo "Total Records - ".count($cdata);
			for($b=0;$b<count($cdata);$b++)
			{
				$certdata = $cdata[$b];
				for($c=0;$c<count($certdata);$c++)
				{				
					if($labid==$certdata[$c]['id'])
					{
						$certificateid = $certdata[$c]['cid']					
		 ?>
					 	<tr>
					 	<td width="130px" align="left" valign="top">&nbsp;</td>
						<td width="125px" valign="top"><?php echo "<a href='#' onClick=open_cer_win($certificateid)><b>".$certdata[$c]['certificate_no']."</b></a>"; ?></td>
					    <td width="120px" valign="top"><b><?php echo $certdata[$c]['facilityName']; ?></b></td>  
					    <td width="135px" valign="top"><b><?php echo $certdata[$c]['fieldName']; ?></b></td>
					    <td width="100px" valign="top">
                        <b>
					    <?php 					    		
					    		$issueDate = explode('-',$certdata[$c]['issue_date']); 
						        $issueDate = array_reverse($issueDate);
						        echo $issueDate = implode('/',$issueDate);
					    ?>
                        </b>
					    </td>
					    <td width="100px" valign="top">
                        <b>
					    <?php 					    		
					    		$expiryDate = explode('-',$certdata[$c]['expiry_date']); 
						        $expiryDate = array_reverse($expiryDate);
						        echo $expiryDate = implode('/',$expiryDate);
					    ?>
                        </b>
					    </td>  
						<!-- added by niraj.lal.rahi  -->
						 <td width="100px" valign="top">
                        <b>
					    <?php 					    		
					    		$extendDate = explode('-',$certdata[$c]['extend_date']); 
						        $extendDate = array_reverse($extendDate);
						        $extendDate = implode('/',$extendDate);
								echo (empty($extendDate) || $extendDate==='00/00/0000' ) ? '-' : $extendDate;
					    ?>
                        </b>
					    </td> 
						<!-- end here -->
					    <td width="140px" valign="top">
                        <b>
					    <?php 					    
					    	if($certdata[$c]['status']==0)
					    	{
					    		echo "<a href='index.php?c=certificate&m=updateStatus&status=0&id=$certificateid'>Activate</a>";
					    	}
					    	if($certdata[$c]['status']==1)
					    	{
					    		echo "<a href='index.php?c=certificate&m=updateStatus&status=1&id=$certificateid'>Deactivate</a>";
					    	} 					    	
					    ?>
                        </b>
					    </td> 
					    <td width="90px" valign="top"><a href="index.php?c=certificate&m=editcertificate&id=<?php echo $certificateid;?>"><b>Edit</b></a>|
					    <a href="index.php?c=certificate&m=deletecertificate&id=<?php echo $certificateid;?>" onclick="Javascript: return confirm('Are you sure you want to delete it ?')"
					    ><b>Delete</b></a>
					</td>
					
		<?php 
					}
					}
				}
			}
			?>	
</tr>
<?php
}
?>

</table>
<?php
}else{
	echo "No Record Found ";
}

	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>