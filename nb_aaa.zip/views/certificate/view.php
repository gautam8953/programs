<script src="js/ajax.js"></script>
<script src="js/jquery.js"></script>
<link href="../templates/mystore_plazza/css/custom.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/css.gzip.php?style=lite&amp;size=standard" type="text/css" />
<style type="text/css">
body{	
	margin:0 auto;
	background-color:#FFF;
}
.table-setting {
    margin-bottom: 15px;
    margin-left: 9px;
}	
</style>
<?php echo form_open_multipart('c=certificate&m=view') ?>
<table width="700px"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="middle">	      
	<table width="690px" border="0" cellspacing="0" cellpadding="0" class="Border" bgcolor="#FFF">	
    <tr>
    <td class="LaboratoryGridHead LabPaddingLeft">Certificate</td></tr>
	<tr>
	<td>
	<?php	
		//print_r($certificatedata);
		if(count($certificatedata)>0)
		{		
			$subgroustr = "";
			//$i=0;
			foreach($certificatedata as $cdata)
			{
				$fileName = $cdata['certificate_file'];
				//$subgroup = $cdata['sub_group_id'];	
				//$subgroustr = explode(",",$subgroup);
				//$sql = "se";
				
				$issueDate = explode('-',$cdata['issue_date']); 
		        $issueDate = array_reverse($issueDate);
		        $issueDate = implode('/',$issueDate);
		        		        
		        $expiryDate = explode('-',$cdata['expiry_date']);
		        $expiryDate = array_reverse($expiryDate);
		        $expiryDate = implode('/',$expiryDate);
				/* added by niraj.lal.rahi */
				$extendDate = explode('-',$cdata['extend_date']);
		        $extendDate = array_reverse($extendDate);
		        $extendDate = implode('/',$extendDate);
				$extendDate = (empty($extendDate) || $extendDate==='00/00/0000' ) ? '-' : $extendDate;
				/* end here*/
		        
				echo "<table width='600px' border='0' cellspacing='0' cellpadding='0'>
					  <tr>
					   <td  width='150px' class='LabTdLeft' valign='top'>Lab Name </td>   
					   <td  width='150px' class='LabTdRight' valign='top' colspan='3'>$cdata[lab_name]</td>
					  </tr>
					  <tr>
					    <td class='LabTdLeft' valign='top'>Field</td>
					   <td class='LabTdRight' valign='top'>$cdata[facilityName]</td>
					   <td align='left' valign='top'><font color='#666666'><b>Discipline</b></font></td>
					    <td class='LabTdRight' valign='top'>$cdata[discipline_name]</td> 
  </tr>
					  <tr>
					    <td class='LabTdLeft' valign='top'>Certificate No. </td>
					   <td class='LabTdRight' valign='top'>
					    <a href='././file_download.php?filename=$fileName' target='_blank'>
					   	$cdata[certificate_no]</a>
					    </td>
					   <td class='LabTdLeft' valign='top'>&nbsp;</td>
					    <td class='LabTdRight' valign='top'>&nbsp;</td>
  </tr>
					  <tr>
					    <td class='LabTdLeft' valign='top'>Issue Date</td>
					   <td class='LabTdRight' valign='top'>$issueDate</td>
					   <td align='left' valign='top'><font color='#666666'><b>Valid Upto</b></font></td>
					    <td class='LabTdRight' valign='top'>$expiryDate</td>
						<td class='LabTdLeft' valign='top'>Extend Upto</td>
					   <td class='LabTdRight' valign='top'>$extendDate</td> 
  </tr>							 
					</table>";					   	
			}			
			?>		
	<?php 
		}
		if(count($gnsdata)>0)
		{		
				$subGroup = array();
				echo "<table width='600px' border='1px' cellspacing='0' cellpadding='0' class='table-setting'>							 
						    <tr>
						   <td width='300px' class='LabTdLeft' valign='top'>Discipline </td>
						    <td width='300px' class='LabTdLeft' valign='top'>Group </td>
						    <td width='300px' class='LabTdLeft' valign='top'>Sub Group </td>						   
                                                   </tr>";	
				/*			
		        foreach($gnsdata as $data)
		        {
		        	$subGroup = explode(",",$data['subGroupName']);
					echo  "<tr>
						    <td class='LabTdLeft' valign='top'>$data[groupName]</td>
						    <td align='left' valign='top'>";					        					    
							for($x=0;$x<count($subGroup);$x++)
							 {
						    	 echo $subGroup[$x];	
							 }
					  echo "</td></tr>
							<tr>
						    <td width='300px' class='LabTdLeft' valign='top'>&nbsp;</td>
						    <td width='300px' align='left' valign='top'>&nbsp;</td>
						    </tr>";							         
		        }
				*/
				foreach($gnsdata as $rows) {
					echo  '<tr>';
						echo '<td width="300px" style="padding-left: 0.2cm;" align="left" valign="top">'.$rows['Discipline'].'</td>';
					    echo '<td width="300px" style="padding-left: 0.2cm;" align="left" valign="top">'.$rows['Groupname'].'</td>';
						echo '<td width="300px" style="padding-left: 0.2cm;" align="left" valign="top">'.$rows['Subgroup'].'</td>';
				    echo '</tr>';	
				}
		        echo "</table>";				   	
			
		}
	?>
	</td>
	</tr>	
	</table>
	</td>
  </tr>
</table>
</form>
