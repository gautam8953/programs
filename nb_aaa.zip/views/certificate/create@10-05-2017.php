<script src="js/ajax.js"></script>
<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){
                //For date of birth
                $('#issue_date').datepicker({ yearRange: '1930:2020' } );
                $('#expiry_date').datepicker({ yearRange: '1930:2020' } );
            });
</script>
<script language='JavaScript' type='text/javascript'>
var subGroupShowStr = "";
var subGroupHideStr = "";

/*
Commented on 9 July 2014 for multiselect add
function addsubgroups()
{
	var subgroups = document.getElementById('subgroup_id').value;
	tempArr = subgroups.split("-");
	subGroupShowStr = tempArr[1];
	subGroupHideStr = tempArr[0];	
	var opt = document.createElement('option');  
    document.getElementById('subgroupsList').options.add(opt);     
    opt.text = subGroupShowStr;
    opt.value = subGroupHideStr;
    opt.selected=true;
}
*/

function addsubgroups(){
	var allSub = [];
	var temp = 0;
	var s = document.getElementById("subgroup_id");
    for (var i = 0; i < s.options.length; i++) {
		temp = 0;
        if (s.options[i].selected == true) {
            var sid = s.options[i].value;
			allSub.push(sid);
			tempArr = sid.split("-");
			subGroupShowStr = tempArr[1];
			subGroupHideStr = tempArr[0];
			var k = document.getElementById("subgroupsList");
			for (var j = 0; j < k.options.length; j++) {
				if(k.options[j].value == subGroupHideStr){
					temp = 1;
					 
				} else {
					
				}
			} 
			
			if(temp != 1){
				allSub.push(sid);
				tempArr = sid.split("-");
				subGroupShowStr = tempArr[1];
				subGroupHideStr = tempArr[0];	
				var opt = document.createElement('option');  
				document.getElementById('subgroupsList').options.add(opt);     
				opt.text = subGroupShowStr;
				opt.value = subGroupHideStr;
				opt.selected=true;
			} 
			
        }
    }
	var subgroups = document.getElementById('subgroup_id').value;
	
}

function deletesubgroups()
{
	var i;
	selectbox =  document.getElementById('subgroupsList');
	for(i=selectbox.options.length-1;i>=0;i--)
	{
		if(selectbox.options[i].selected)
		{
			selectbox.remove(i);
		}
	}
}

/*
function addsubgroups()
{
	var subgroups = document.getElementById('subgroup_id').value;
	tempArr = subgroups.split("-");
	subGroupShowStr = subGroupShowStr+'<br/>'+tempArr[1];
	subGroupHideStr = subGroupHideStr+','+tempArr[0];
	document.getElementById('show_multiple_subgroups').innerHTML = subGroupShowStr;
	document.getElementById('multiplesubgroups').value = subGroupHideStr;
}
*/
</script>

<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">

<tr>
<td align="center">
<?php //echo validation_errors(); ?>
<?php echo form_open_multipart('c=certificate&m=create') ?>

<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add Certificate</td>
</tr>
<tr><td style="height:15px;"></td></tr>
<tr>
<td>
<div style="overflow:auto; width:930px;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
Add Certificate
</td>
</tr>
<tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Laboratory * </td>
              <td width="79%" align="left" colspan="3">  <select name="lab_id" id="lab_id" style="width:150px;">
              <option value="-1" selected>Please Select</option>
              <?php                     	
              	for($i=0;$i<count($lab);$i++)
              	{ 
              ?>
                	<option value="<?php echo $lab[$i]['id'] ?>"><?php echo $lab[$i]['lab_registration_code']." : ".$lab[$i]['lab_name'] ;?></option>
              <?php
              	} 
              ?>
              </select></td>            
            </tr>
           
             <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Certificate File *</td>
              <td width="30%" align="left" ><input name="certificatedoc" type="file" id="certificatedoc"></td>
              <td width="20%" align="left" >Certificate No *</td>
              <td width="30%" align="left"><input name="certificate_no" type="text" id="certificate_no" /></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Nature of Lab * </td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
                <select name="nature_of_lab" id="nature_of_lab" style="width:150px;">
                  <option value="-1" selected>Please Select</option>
                  <?php                     	
              	for($i=0;$i<count($nolab);$i++)
              	{ 
              ?>
                  <option value="<?php echo $nolab[$i]['id'] ?>"><?php echo $nolab[$i]['nature_name'] ;?></option>
                  <?php
              	} 
              ?>
                </select>
                <script src="js/ui.datepicker.js"></script></td>
              <td width="20%" align="left">Facility *<br/>
              <span class="LabSubText"> (Press Ctrl for multiple selection)</span> </td>
              <td width="30%" align="left">
              <?php                     	
              		echo $operat;            	
               ?>                
                        
              </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td align="left" class="LabPaddingLeft">Issue Date: *</td>
              <td align="left">
			  <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>    
              <input name="issue_date" type="text" id="issue_date" />
              </td>
              <td align="left" >Expiry Date *</td>
              <td align="left">
              <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="expiry_date" type="text" id="expiry_date" />
              </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Field * </td>
              <td width="30%" align="left">  
              <?php echo $facilitydropdown;?>             
              </td>
              <td width="20%" align="left">Discipline * </td>
              <td width="30%" align="left">              
              <div id='field'>
              <select name="field_id" id="field_id" style="width:150px;">
              <option value="-1">Please Select</option>
              </select>            
              </div>
              </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Group *</td>
              <td align="left" colspan="3">
			  <div id="group">
              <select name="group_id" id="group_id" style="width:150px;">
              <option value="-1">Please Select</option>
              </select>            
              </div>     
			  </td>            
            </tr>
            <tr><td height="23" colspan="4" style="height:10px;"></td></tr>
            <tr>              
              <td width="20%" class="LabPaddingLeft">Sub Group *</td>
              <td width="30%" align="left">              
              <div id="subgroup">
              <select name="subgroup[]" id="subgroup_id" style="width:150px;" size='15' multiple >
              <option value="-1" selected>Please Select</option>
              </select>             
              </div>
              </td>
              <td align="center">
                <input type="button" name="add" id="add" value="Add" onclick="javascript:return addsubgroups()" />                
                <br/>
                <br/>
                <input type="button" name="remove" id="remove" value="Remove" onclick="javascript:return deletesubgroups()" />               
                  <!--
                <input type="button" name="remove" id="remove" value="Remove" onclick="javascript:return deletesubgroups()" />
                -->
                </td>
              <td align="left">  
                <select name="subgroupsList[]" size="10" id="subgroupsList" multiple>                      
                </select>
               <!--
                <div id="show_multiple_subgroups" class="div-border">                        
                </div>
                <input type="hidden" name="multiplesubgroups" id="multiplesubgroups" value="" />     
              -->            
              </td>
            </tr>
            
          <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td colspan="4" align="center">
              <center>
                <input type="submit" name=submit value="Upload" onclick="javascript:return validateCertificateForm();">
                <input type="reset" name="reset" value="Reset">
                <?php
			  		echo anchor('c=certificate&m=index', 'back');
			    ?>    </center>     
                </td>              
            </tr>
           <tr><td style="height:10px;" colspan="4"></td></tr>
          </table>
</form></td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
