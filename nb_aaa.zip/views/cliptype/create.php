
<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Create a Clip Type</td>
</tr>
<tr>
<td class="LabAlighRight">

</td>
</tr>
<tr>
<td>
<?php echo validation_errors(); ?>
<?php echo form_open('c=cliptype&m=create') ?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="80%">
<tr>
<td class="LabPaddingLeft" style="height:30px;"><label for="title">Clip Type Name</label></td>
<td><input type="text" name=clip_name id="clip_name" /></td>
	</tr>
   
    <tr>
    <td></td>
    <td align="left" style="height:30px;">
	<input type="submit" name="submit" value="Create Clip Type" onclick="javascript:return validateClipTypeForm();" />
	<input type="reset" name="reset" value="Reset">
    <?php
			  	echo anchor('c=cliptype&m=index', 'Back');
	?>
</td>
</tr>
</table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
