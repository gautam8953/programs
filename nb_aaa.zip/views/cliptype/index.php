<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Clip Type</td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=cliptype&m=create">Create Clip Type</a>
</td>
</tr>
<tr>
<td>
<?php
if(count($cliptype)>0){
?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="Border">
<tr>
<td class="LaboratoryGridHead LabPaddingLeft">Si No</td>
<td class="LaboratoryGridHead">Clip Type Name</td>
<td class="LaboratoryGridHead">Action</td>
<?php
$i=0;
foreach ($cliptype as $cliptype_items){ ?>
<tr>
	<td class="LabPaddingLeft"><?php echo ++$i;?></td>
    <td><?php echo $cliptype_items['clip_name'] ?></td>   
    <td><a href="index.php?c=cliptype&m=edit_clip_type&id=<?php echo $cliptype_items['id'];?>">Edit</a>|
    <a href="index.php?c=cliptype&m=delete_clip_type&id=<?php echo $cliptype_items['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this ?')"
    >Delete</a>
</td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Clip Types Found ";
}
if(isset($pagination) && $pagination="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>