<!--sdfasdfasdf
</body>
</html>-->
</td>
</tr>

</table>
</div>
												
																		<div class="clrfix"></div>
					</div>
				</div>		
				<div class="clrfix"></div>
			</div> 
			
			<!--bottom-->

			
                          <!-- -->
			<!--footer-->
			<div class="tpcontainerbottom">
				<div class="tpcontainerbottom1">Copyright  2012. NABL. All Rights Reserved. &nbsp;&nbsp;Powered by <a href="http://www.rvsolutions.in/" class="linkbota" target="_blank">RV Solutions Pvt. Ltd.</a></div>
				 <div class="clrfix"></div>
             
		</div>
	</div>
	</div>
    </center>
</body>
</html>