<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <title>
  <?php 
  if(isset($title) && $title!="")
  {
  		echo $title;
  }
  else 
  {
  	 echo $title="Admin Dashboard";
  } 
  ?>
  </title>
  <link href="../templates/mystore_plazza/favicon.ico" rel="shortcut icon" type="image/x-icon" />
  <script type="text/javascript" src="../media/system/js/mootools.js"></script>
  <script type="text/javascript" src="../media/system/js/caption.js"></script>
  <script type="text/javascript" src="../modules/mod_tpmenu/tpmenu/dropdown/menu.js.php?animated=Fx.Transitions.Bounce.easeOut"></script>
  <link href="../templates/mystore_plazza/css/dropdowntpmenu.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="../templates/mystore_plazza/favicon.ico" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/css.gzip.php?style=lite&amp;size=standard" type="text/css" />
<link rel="stylesheet" href="../templates/mystore_plazza/css/custom.css" type="text/css" />
<script type="text/javascript" src="../templates/mystore_plazza/scripts/js/template.js"></script>
<script language="JavaScript" type="text/javascript" src="js/validation.js"></script>
</head>
<center>
<body id="tpbody" class="mainbody">
    <div class="top">
    <div id="tpcontainer" style="width:960px;">
		<div class="tpcontainer-inner">
			<!--header-->
			<div class="tpcontainerheader">
				<div class="tpinner">
					<div class="tpheader1"><span class="logo"><a href="../logo.php" title="" onclick="NewWindow(this.href,'Nabl-logo','290','330','no','center');return false" onfocus="this.blur()"></a></span></div>
                    <!--  <div class="clrfix">  -->                    
                    <div class="clrfix HindiLink">&nbsp;&nbsp;</div>                    
					<!-- </div>  -->
                    <div class="tpheader3"><div id="tp-mainnavwrap">
                                                     <div id="tp-mainnav" class="clearfix">
                                                      <ul class="clearfix"  id="tp-cssmenu">
<li class=""><a href="index.php?c=admin&m=index">Home</a></li>
<li class=""><a href="../administrator/index.php">Content Admin</a></li>
<!-- 
<li class="active parent">
<a class="haschild" href="#">Setting</a><ul>
<li class="active">
<a href="index.php?c=zone&m=index">Manage Zones</a></li>
<li class=""><a href="index.php?c=cliptype&m=index">Anshu Manage Clip Types</a></li>
<li class=""><a href="index.php?c=documenttype&m=index">Manage Document Types</a></li>
<li class=""><a href="index.php?c=eventtype&m=index">Manage Event Types</a></li>
<li class=""><a href="index.php?c=natureoflab&m=index">Manage Nature of Labs</a></li>
<li class=""><a href="index.php?c=operationat&m=index">Manage Operation At</a></li>
</ul></li>

<li class="parent">
<a class="#">Laboratory</a><ul>
<li class=""><a href="index.php?c=labs&m=index">Manage Categoriess</a></li>
<li class=""><a href="index.php?c=accredationDoc&m=index&docType=both">Manage NABL Documents</a></li>
<li class=""><a href="index.php?c=accredationDoc&m=index&docType=newsletter">Manage News Letter</a></li>
<li class=""><a href="index.php?c=jobs&m=index">Manage Job Postings</a></li>
<li class=""><a href="index.php?c=protestschedule&m=index">Manage Proficiency Testing</a></li>
<li class=""><a href="index.php?c=eventschedule&m=index">Manage Training & Awareness</a></li> -->
<!-- <li class=""><a href="index.php?c=eventschedule&m=index">Manage Awareness Schedules</a></li> -->
<!-- 
<li class=""><a href="index.php?c=laboratory&m=index">Manage Laboratories</a></li>
<li class=""><a href="index.php?c=news&m=index">Manage News</a></li>
<li class=""><a href="index.php?c=news&m=index">Manage Announcements</a></li>
<li class=""><a href="index.php?c=certificate&m=index">Manage Certificate</a></li>
</ul>
</li>

<li class="parent">
<a class="#">Misc</a><ul>
<li class=""><a href="index.php?c=auth&m=changePassword">Change Password</a></li>
</ul>
</li>
 -->


</ul>
</div>
<div id="tp-logoutcssmenu">
<ul>
<li>
<a href="index.php?c=auth&m=logout">Log Out</a>
</li>
</ul></div>
</div></div>	
			
</div>
</div>
			
			<!--top-->

			<!---->
						<!--content-->
			<div class="tpcontainercontent">
				<!--advert1-->
				<!---->
				
				<!--left-->
                              <!--right-->
								
				<!--maincontent-->
	<div class="tpcontainermain bb">
					<div class="tpinner">
<!--<div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">

<tr>
		<td class="contentheading" width="100%">
					Laboratory			</td>

</table>-->

<table class="contentpaneopen">


<tr>
<td valign="top" class="main_article">
