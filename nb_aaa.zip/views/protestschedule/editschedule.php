<script src="js/ajax.js"></script>
<script src="js/jquery.js"></script>
<script language='JavaScript' type='text/javascript'>
            $(document).ready(function(){                
                $('#last_date_of_registration').datepicker({ yearRange: '1930:2020' } );
                $('#programme_finish_date').datepicker({ yearRange: '1930:2020' } );
            });
</script>
<?php echo validation_errors(); ?>
<?php echo form_open('c=protestschedule&m=editschedule&id='.$_GET['id']) ?>

<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Edit  Proficiency Testing Schedule</td>
</tr>
<tr>
<td style="height:15px;">
</td>
</tr>
<tr>
<td>
<div style="overflow:auto; width:930px;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
            <tr>
<td class="LaboratoryGridHead LabPaddingLeft" colspan="4">
Edit Proficiency Testing Schedule
</td>
</tr>
<tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft"> Code No* </td>
              <td width="30%" align="left"> <input name="code" type="text" id="code" value="<?php echo $labs['code']; ?>" /></td>
              <td width="20%" align="left">Program Name * </td>
              <td width="30%" align="left"><input name="programe_name" type="text" id="programe_name" value="<?php echo $labs['programe_name']; ?>" /></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Description *</td>
              <td width="30%" align="left"><input name="programe_description" type="text" id="programe_description" value="<?php echo $labs['programe_description']; ?>"></td>
              <td width="20%" align="left">Contact Person *</td>
              <td width="30%" align="left"><input name="contact_person" type="text" id="contact_person" value="<?php echo $labs['contact_person']; ?>" />	
              </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td align="left" class="LabPaddingLeft">Field * </td>
              <td align="left"><?php echo $facility; ?></td>
              <td align="left">Nodal Lab Name*</td>
              <td align="left"><input name="nodal_lab_name" type="text" id="nodal_lab_name2" value="<?php echo $labs['nodal_lab_name']; ?>" /></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Discipline *</td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <div id='field'>
               <?php echo $fielddropdown; ?>
              </div>    
             </td>
              <td width="20%" align="left">Designation</td>
              <td width="30%" align="left"><input name="designation" type="text" id="designation2" value="<?php echo $labs['designation']; ?>" /> </td>
            </tr>            
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Contact Address</td>
              <td width="30%" align="left"><textarea name="contact_address" cols="30" rows="3" id="contact_address"><?php echo $labs['contact_address']; ?></textarea></td>
              <td width="20%" align="left">City * </td>
              <td width="30%" align="left"><select name="city" id="city" >
                <option value="1" selected>Please Select</option>
                <?php                     	
	              	for($i=0;$i<count($city);$i++)
	              	{ 
	              		$selected = '';
              			if($city[$i]['id']==$labs['city_id'])
              				$selected = 'selected';
	              ?>
                <option value="<?php echo $city[$i]['id'] ?>" <?php echo $selected; ?> ><?php echo $city[$i]['name'] ;?></option>
                <?php
	              	} 
	             ?>
              </select></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">State</td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <select name="state" id="state" >
                <option value="1" selected>Please Select</option>
                <?php                     	
	              	for($i=0;$i<count($state);$i++)
	              	{ 
	              		$selected = '';
              			if($state[$i]['id']==$labs['state_id'])
              				$selected = 'selected';
	              ?>
                <option value="<?php echo $state[$i]['id'] ?>" <?php echo $selected;?> ><?php echo $state[$i]['name'] ;?></option>
                <?php
	              	} 
	             ?>
              </select></td>
              <td width="20%" align="left">Country * </td>
              <td width="30%" align="left">
              <select name="country" id="country" style="width:150px;">
                <option value="0" selected>Please Select</option>
                <?php                     	
	              	for($i=0;$i<count($country);$i++)
	              	{ 
	              		$selected = '';
              			if($country[$i]['id']==$labs['county'])
              				$selected = 'selected';
	              ?>
                <option value="<?php echo $country[$i]['id'] ?>" <?php echo $selected; ?> ><?php echo $country[$i]['name'] ;?></option>
                <?php
	              	} 
	             ?>
              </select>
              </td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Pincode</td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
               <input name="pin" type="text" id="pin" value="<?php echo $labs['pin']; ?>" /></td>
              <td width="20%" align="left">Phone</td>
              <td width="30%" align="left"><input name="phone" type="text" id="phone" value="<?php echo $labs['phone']; ?>" /></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Fax</td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="fax" type="text" id="fax" value="<?php echo $labs['fax']; ?>" /></td>
              <td width="20%" align="left">Email ID</td>
              <td width="30%" align="left"> <input name="emailid" type="text" id="emailid" value="<?php echo $labs['emailid']; ?>" /></td>
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
            <tr>
              <td width="20%" align="left" class="LabPaddingLeft">Last Date of Registration * </td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
             <?php
              		$lastregiDate = explode('-',$labs['last_date_of_registration']); 
              		$lastregiDate = array_reverse($lastregiDate);
              		$lastregiDate = implode('-',$lastregiDate);

              		$pfDate = explode('-',$labs['programme_finish_date']); 
              		$pfDate = array_reverse($pfDate);
              		$pfDate = implode('-',$pfDate);
              ?>
              <link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="last_date_of_registration" type="text" id="last_date_of_registration" value="<?php echo $lastregiDate; ?>" /></td>
              <td width="20%" align="left">Program Finish Date *</td>
              <td width="30%" align="left"><link rel="stylesheet" href="css/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)">
              <script src="js/ui.datepicker.js"></script>
              <input name="programme_finish_date" type="text" id="programme_finish_date" value="<?php echo $pfDate; ?>" /></td>
            </tr>
            <tr><td style="height:5px;" colspan="4"></td></tr>
            <tr>
              <td colspan="4" align="center">
              <center>
             <input type="submit" name="submit" value="Submit" onclick="javascript:return validateProficiencyTestScheduleForm()">
                <input type="reset" name="reset" value="Reset">
                <?php
			  		echo anchor('c=protestschedule&m=index', 'Back');
			   ?>         </center>     
                </td>              
            </tr>
            <tr><td style="height:10px;" colspan="4"></td></tr>
          </table>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>
 </form> 
