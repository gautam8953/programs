<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Manage Proficiency Testing Schedule</td>
</tr>
<tr>
<td class="LabAlighRight">
<a href="index.php?c=protestschedule&m=create">Add Proficiency Testing Schedule</a>
</td>
</tr>
<tr>
<td>
<?php
if(count($news)>0){
?>
<table align="left" border="1" cellpadding="1" cellspacing="1" width="940px">
<tr>
<!-- <td width="50px"   class="LaboratoryGridHead LabPaddingLeft">Si No</td>  -->
<td width="60px"   class="LaboratoryGridHead LabPaddingLeft">Code No</td>
<td width="210px"  class="LaboratoryGridHead LabPaddingLeft">Program Name</td>
<td width="120px"  class="LaboratoryGridHead LabPaddingLeft">Contact Person</td>
<td width="150px"  class="LaboratoryGridHead LabPaddingLeft">Last Date of Regn.</td>
<td width="145px"  class="LaboratoryGridHead LabPaddingLeft">Program Finish Date</td>
<th width="145px"  class="LaboratoryGridHead LabPaddingLeft">Activate/Deactivate</th>
<td width="90px"   class="LaboratoryGridHead LabPaddingLeft">Action</td>
<?php
$i=0;
foreach ($news as $news_item){ 
 $id =	$news_item['id'];
?>
<tr>
<!-- <td class="LabPaddingLeft" valign="top"><?php //echo ++$i;?></td>  -->
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['code'] ?></td>
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['programe_name'] ?></td>        
    <td class="LabPaddingLeft" valign="top"><?php echo $news_item['contact_person'] ?></td>   
    <td class="LabPaddingLeft" valign="top">
    <?php 
   		//echo $news_item['last_date_of_registration'];
   		$lastregiDate = explode('-',$news_item['last_date_of_registration']); 
        $lastregiDate = array_reverse($lastregiDate);
        echo $lastregiDate = implode('/',$lastregiDate);

              		
    ?>
    </td>
    <td class="LabPaddingLeft" valign="top">
    <?php 
    	//echo $news_item['programme_finish_date'];
    	$pfDate = explode('-',$news_item['programme_finish_date']); 
        $pfDate = array_reverse($pfDate);
        echo $pfDate = implode('/',$pfDate);
    ?>
    </td>    
    <td class="LabPaddingLeft" valign="top">
    <?php 
    	if($news_item['status']==0)
    	{
    		echo "<a href='index.php?c=protestschedule&m=updateStatus&status=0&id=$id'>Activate</a>";
    	}
    	if($news_item['status']==1)
    	{
    		echo "<a href='index.php?c=protestschedule&m=updateStatus&status=1&id=$id'>Deactivate</a>";
    	} 
    ?>
    </td>
    <td class="LabPaddingLeft" valign="top"><a href="index.php?c=protestschedule&m=editschedule&id=<?php echo $news_item['id'];?>">Edit</a>|
    <a href="index.php?c=protestschedule&m=deleteschedule&id=<?php echo $news_item['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this category ?')"
    >Delete</a>

</td>
</tr>
<?php
}
?>
</table>
<?php
}else{
	echo "No Record Found ";
}
if(isset($pagination) && $pagination=="yes")
{ 
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>

</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>