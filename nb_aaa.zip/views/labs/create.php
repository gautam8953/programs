<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Add Lab Category</td>
</tr>
<tr>
<td class="LabAlighRight">&nbsp;
</td>
</tr>
<tr>
<td>
<?php //echo validation_errors(); ?>
<?php echo form_open('c=labs&m=create') ?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="60%">
      <tr>
        <td class="LabPaddingLeft" style="height:30px;">Category Name *</td>
        <td align="left"><input type="text" name="category_name" id="category_name" /></td>
      </tr>
      <tr>
        <td class="LabPaddingLeft">Category Description *</td>
        <td align="left">
        <textarea name="category_description" id="category_description" style="width:300px;"></textarea></td>
      </tr>
      <tr>
        <td width="250" align="left"><label for="title"></label></td>
        <td width="250" align="left" style="height:30px;">
        <input type="submit" name="submit" value="Submit" onclick="javascript:return  validateLabCategories();">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="reset" name="reset" value="Reset">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <?php
			  	echo anchor('c=labs&m=index', 'back');
		?>
        </td>
      </tr>
    </table>
	<label for="text"></label>
	<br/>
</form>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>