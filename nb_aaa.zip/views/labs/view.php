<?php
echo '<h2>'.$news_item['category_name'].'</h2>';
echo $news_item['category_description'];