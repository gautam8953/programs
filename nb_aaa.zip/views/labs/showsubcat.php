<div class="tpcontainermainc" style="width: 940px">
<table class="contentpaneopen detail">
<tr>
<td class="contentheading">Manage Lab Category</td>
</tr>
<tr>
<td class="LabAlighRight">

<?php 
if(!isset($_GET['catid']))
{ 	
	?>
	<a href="index.php?c=labs&m=create">Add New Category</a>
	<?php 
}
if(isset($_GET['catid']))
{	
	
	?>
	<a href="index.php?c=labs&m=addsubcat&catid=<?php echo $_GET['catid']; ?>">Add New Category</a>
	<?php	
}
?>
</td>
</tr>
<tr>
<td>
<?php
if(isset($navheader))
	{
		echo $navheader;
	}
if(count($news)>0){		
	echo "<br/><b>".count($total_rows)." Records Found</b>";
?>
<div style="overflow:auto; width:930px;" class="Border">
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td class="LaboratoryGridHead LabPaddingLeft">Si No</td>
<td class="LaboratoryGridHead">Category Name</td>
<td class="LaboratoryGridHead">Description</td>
<td class="LaboratoryGridHead">Change Status</td>
<td class="LaboratoryGridHead">Action</td>
<?php
$i=0;
foreach ($news as $news_item){ ?>

<tr>
	<td class="LabPaddingLeft"><?php echo ++$i;?></td>
    <td>
    <a href="index.php?c=labs&m=showsubcat&catid=<?php echo $news_item['id'];?>"><?php echo $news_item['category_name'] ?></a>     
    </td>
    <td><?php echo $news_item['category_description'] ?></td>
    <td>
    <?php 
    		if($news_item['isactive']=='1')
    		{
    			echo "<a href='index.php?c=labs&m=changestatus&id=$news_item[id]&status=0'>Deactivate</a>";
    		}
			if($news_item['isactive']=='0')
    		{
    			echo "<a href='index.php?c=labs&m=changestatus&id=$news_item[id]&status=1'>Activate</a>";
    		}    		
    ?>
    </td>  
    <td><a href="index.php?c=labs&m=editlab&id=<?php echo $news_item['id'];?>&catid=<?php echo $_GET['catid']; ?>">Edit</a> &nbsp;&nbsp;
    |
    <!-- 
    &nbsp;&nbsp;
    <a href="index.php?c=labs&m=deletelab&id=<?php echo $news_item['id'];?>&catid=<?php echo $_GET['catid']; ?>">Delete</a> &nbsp;&nbsp;
    | -->
    &nbsp;&nbsp;
    <a href="index.php?c=labs&m=addsubcat&catid=<?php echo $news_item['id'];?>">Add Sub Category</a>
	</td>
</tr>
<?php
}	
?>

</table>
<?php
}else{
	echo " <br/><b>No Record Found</b>";
}
if(isset($pagination) && $pagination="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
} 
?>
</td>
</tr>
<tr>
<td height="25px"></td></tr>
</table>
</div>