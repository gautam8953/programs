<div class="tpcontainermainc" style="width: 940px">
<table width="700px" align="center" cellspacing="0" cellpadding="4">
  <tr>
    <td align="center">
    <table width="100%" border="0" cellspacing="0" cellpadding="0"  >
  <tr>
    <td align="left" valign="top" ><!-- Manage Laboratory  --></td>
  </tr>
  <tr>
    <td align="left" valign="top">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="50%" align="left" valign="top"><table width="95%" border="0" cellspacing="0" cellpadding="5">
          <tr>
            <td class="LaboratoryGridHead LabPaddingLeft">Manage Laboratories</td>
          </tr>
          <tr>
            <td class="LabPaddingLeft"><?php
			  		echo anchor('c=labs&m=index', 'View Lab Categories');
	        ?></td>
          </tr>
          <!--
          <tr>
            <td class="LabPaddingLeft">
			<?php
			  		//echo anchor('c=laboratory&m=create', 'Add Laboratories');
		    ?></td>
          </tr>
          -->
          
          <tr>
            <td class="LabPaddingLeft"><?php
			  		echo anchor('c=laboratory&m=index', 'View Laboratories');
		    ?></td>
          </tr>
          <tr>
            <td><span class="LabPaddingLeft">
              <?php
			  		echo anchor('c=certificate&m=index', 'View Certificates');
			  ?>
            </span></td>
          </tr>
          <tr>
            <td><span class="LabPaddingLeft">
              <?php
			  		echo anchor('c=statusapplicantlaboratories&m=index', 'View Status of Applicant Laboraties');
	          ?>
            </span></td>
          </tr>
          <!-- 
          <tr>
            <td><span class="LabPaddingLeft">
              <?php
			  		//echo anchor('c=labAccreditationUnderAbeyance&m=index', 'View Lab. Accreditation Under Abeyance');
		      ?>
            </span></td>
          </tr>
           -->
          <tr>
            <td><span class="LabPaddingLeft">
              <?php
			  		echo anchor('c=suspendedaccreditation&m=index', 'View Suspended Accreditation');
		  ?>
            </span></td>
          </tr>
          <!--<tr>
            <td><span class="LabPaddingLeft">
              <?php
			  	//echo anchor('c=closedaccreditation&m=index', 'View Closed Accreditation');
		  ?>
            </span></td>
          </tr>-->
          <tr>
            <td><span class="LabPaddingLeft">
              <?php
		  		echo anchor('c=forcedwithdrawalaccreditation&m=index', 'View Forced Withdrawal Accreditation');			  	
		  ?>
            </span></td>
          </tr>
          <tr>
            <td><span class="LabPaddingLeft">
              <?php
			  	//echo anchor('c=forcedwithdrawalaccreditation&m=index', 'Manage Forced Withdrawal Accreditation');
			  	echo anchor('c=voluntarywithdrawalaccreditation&m=index', 'View Voluntary Withdrawal Accreditation');
		  ?>
              </span></td>
          </tr>
		  
		  <tr>
            <td><span class="LabPaddingLeft">
              <?php
			  	//echo anchor('c=forcedwithdrawalaccreditation&m=index', 'Manage Forced Withdrawal Accreditation');
			  	echo anchor('c=debardvoluntarywithdrawalaccreditation&m=index', 'View Debarred Accreditation');
		  ?>
              </span></td>
          </tr>
		  
		  
          <tr>
            <td align="left" valign="top">&nbsp;</td>
          </tr>
          </table>
          <table width="95%" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td class="LaboratoryGridHead LabPaddingLeft">Settings</td>
            </tr>
            <tr>
              <td class="LabPaddingLeft"><?php
			  	echo anchor('c=natureoflab&m=index', 'View Nature of Labs');
			?></td>
            </tr>
            <tr>
              <td><span class="LabPaddingLeft">
                <?php
			  	echo anchor('c=operationat&m=index', 'View Facility');
			?>
              </span></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
        <td width="50%" align="left" valign="top"><table width="95%" cellspacing="0" cellpadding="5" >
          <tr>
            <td class="LaboratoryGridHead LabPaddingLeft">Manage Documents</td>
          </tr>
          <tr>
            <td class="LabPaddingLeft"><?php
			  		//echo anchor('c=jobs&m=index', 'View Job Postings');
			  		echo anchor('c=accredationDoc&m=index', 'View NABL Documents');			  		
			 ?></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table>
          <table width="95%" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td class="LaboratoryGridHead LabPaddingLeft">Manage Proficiency Testing</td>
            </tr>
            <tr>
              <td class="LabPaddingLeft"><?php
			  		echo anchor('c=protestschedule&m=index', 'View Proficiency Testing');
			  ?></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
          <table width="95%" cellspacing="0" cellpadding="5" >
            <tr>
              <td class="LaboratoryGridHead LabPaddingLeft">Manage Training</td>
            </tr>
            <tr>
              <td class="LabPaddingLeft"><?php
			  		echo anchor('c=eventschedule&m=index', 'View Training & Awareness');
			  ?></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
          <table width="95%" cellspacing="0" cellpadding="5" >
            <tr>
              <td class="LaboratoryGridHead LabPaddingLeft">Manage Jobs Postings </td>
            </tr>
            <tr>
              <td class="LabPaddingLeft"><?php
			  		echo anchor('c=jobs&m=index', 'View Jobs Postings');	  		
		    ?></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
          <table width="95%" cellspacing="0" cellpadding="5" >
            <tr>
              <td class="LaboratoryGridHead LabPaddingLeft">Manage News Letter</td>
            </tr>
            <tr>
              <td class="LabPaddingLeft"><?php
			  		echo anchor('c=news&m=index&clipType=news', 'View News');
			  		echo "<br/>";
			  		echo anchor('c=news&m=index&clipType=announcement', 'View Announcement');
		    ?></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
          
          </td>
      </tr>
      
      <tr>
        <td align="left" valign="top"><table width="95%" border="0" cellspacing="0" cellpadding="5">
          <tr>
            <td class="LaboratoryGridHead LabPaddingLeft">Change Password</td>
          </tr>
          <tr>
            <td class="LabPaddingLeft"><?php
			  		echo anchor('c=auth&m=changePassword', 'Change Password');
		  ?></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table></td>
        <td align="left" valign="top">&nbsp;</td>
      </tr>
      </table></td>
  </tr>
  <tr>
    <td align="left" valign="top"><!-- Manage Settings  --></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp;</td>
  </tr>
</table>
    
    </td>
  </tr> 
</table>
</div>
