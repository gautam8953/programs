<h2>Edit a Lab Group</h2>

<?php echo validation_errors(); ?>

<?php echo form_open('c=group&m=editgroup&id='.$_GET['id']) ?>

	<label for="title">Group Name</label>
	<input type="text" name="group_name"  value="<?php echo $group['group_name']?>"/><br />
	
	<label for="title">Field Name</label>
	<?php echo $fielddropdown; ?><br/>

	<label for="text">Description</label>
	<textarea name="group_description"><?php echo $group['group_description']?></textarea><br />

	<input type="submit" name="submit" value="Update Group" />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="reset" name="reset" value="Reset">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php
			  	echo anchor('c=group&m=index', 'back');
	?>
</form>
