<h2>Create a Lab Group</h2>

<?php echo validation_errors(); ?>

<?php echo form_open('c=group&m=create') ?>

	<label for="title">Group Name</label>
	<input type="text" name="group_name" /><br /><br />
	
	<label for="title">Field Name</label>
	<?php echo $fielddropdown; ?><br/><br />
	<label for="text">Description</label>
	<textarea name="group_description"></textarea><br /><br />
	<input type="submit" name="submit" value="Create Group" />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="reset" name="reset" value="Reset">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php
			  	echo anchor('c=group&m=index', 'back');
	?>    
</form>
