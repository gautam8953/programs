<h2 align="center">Lab Group</h2>
<h3 align="center"><a href="index.php?c=group&m=create">Create New Group</a></h3>
<?php

if(count($news)>0){
?>
<table align="center" border="1">
<tr>
<th>Si No</th>
<th>Category Name</th>
<th>Description</th>
<th>Action</th>
<?php
$i=0;
foreach ($news as $news_item){ ?>

<tr>
	<td><?php echo ++$i;?></td>
    <td><?php echo $news_item['group_name'] ?></td>
    <td><?php echo $news_item['group_description'] ?></td>
    <td><a href="index.php?c=group&m=editgroup&id=<?php echo $news_item['id'];?>">Edit</a>|
    <a href="index.php?c=group&m=deletegroup&id=<?php echo $news_item['id'];?>" onclick="Javascript: return confirm('Are you sure you want to delete this group ?')"
    >Delete</a>

</td>
</tr>
<?php
}
?>

</table>
<?php
}else{
	echo "No Facilites ";
}
if(isset($pagination) && $pagination=="yes")
{
	echo "<table width='700' border='0' align='center'>
		  <tr><td align='center'>";
	echo $this->pagination->create_links();
	echo "</td></tr></table>";
}
?>