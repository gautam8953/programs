<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

  class dropdown {
      
  function zoneDropDwon($name, $id='', $javascript='', $css='', $selecteditem='') 
      {       
      	  //echo "Drop Down Function Called";   
          $CI =& get_instance();
          $zoneModel = $CI->load->model('zone_model');
          //$this->load->model('zone_model');
          //$zoneObj = new zone_model();
          $zoneData = $CI->zone_model->selectAllZone('', '');  
          //print_r($zoneData);
          $dropDown='';
          if(count($zoneData)>0)
          {   
              $dropDown = "<select name=\"$name\" id=\"$id\"  class=\"$css\"" ;                                    
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='0'> Please Select </option>" ;
          while($i<count($zoneData))
          {
              $dropDown .= "<option value=\"".$zoneData[$i]['id']."\"";
              if($selecteditem==$zoneData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$zoneData[$i]['zone_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";        
          
          return $dropDown;          
      }
      
      
      function natureoflabDropDwon($name, $id='', $javascript='', $css='', $selecteditem='') 
      {          
          //require './application/models/natureoflab_model.php';
          
           $CI =& get_instance(); 
          
          $nolabObj =   $CI->load->model('natureoflab_model');
          $nolData = $CI->natureoflab_model->selectAllNatureoflab('', '');  
          $dropDown='';
          if(count($nolData)>0)
          {   
              $dropDown = "<select name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='0'> Please Select </option>" ;
          while($i<count($nolData))
          {
              $dropDown .= "<option value=\"".$nolData[$i]['id']."\"";
              if($selecteditem==$nolData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$nolData[$i]['nature_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      function operationAtDropDwon($name, $id='', $javascript='', $css='', $selecteditem='') 
      {          
      		//echo "Cid - ".$selecteditem;
      		$editoperationatArray = array();    	
	       	if($selecteditem!='')
	       	{
	    		$operationatsql = "select operation_at from certificate_operation_at_tbl where certificate_id=$selecteditem";
	    		$operationatresult = mysql_query($operationatsql);     
	    		while($row=mysql_fetch_array($operationatresult))
	         		{           		            
	            	   $editoperationatArray[] = $row['operation_at'];                             
	         		}
	        } 	   
          //require './application/models/operationat_model.php';
          $CI =& get_instance();  
          $nolabObj =   $CI->load->model('operationat_model');
         // $nolabObj = new operationat_model();
          $opatData = $CI->operationat_model->selectAllOperationAt('', '');  
          $dropDown='';
          if(count($opatData)>0)
          {   
              $dropDown .= "<select name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= " size='3' multiple>";
          }
          $i=0;
          $dropDown .= "<option value='0'> Please Select </option>";
          while($i<count($opatData))
          {
              $dropDown .= "<option value=\"".$opatData[$i]['id']."\"";
               if(in_array($opatData[$i]['id'], $editoperationatArray))//if($selecteditem==$opatData[$i]['id']) {
               {  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$opatData[$i]['operation_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      
      function groupDropDwon($name, $id='', $javascript='', $css='', $selecteditem='') 
      {          
         // require './application/models/group_model.php';
         
          $CI =& get_instance(); 
          
          $groupObj =   $CI->load->model('group_model');
           //= new group_model();
          $groupData = $CI->group_model->selectAllGroup('', '');  
          $dropDown='';
          if(count($groupData)>0)
          {   
              $dropDown = "<select name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='0'> Please Select </option>" ;
          while($i<count($groupData))
          {
              $dropDown .= "<option value=\"".$groupData[$i]['id']."\"";
              if($selecteditem==$groupData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$groupData[$i]['group_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      function facilityDropDwon($name, $id='', $javascript='', $css='', $selecteditem='') 
      {          
          //require './application/models/facility_model.php';
          $CI =& get_instance();   
          $facilityObj = $CI->load->model('facility_model');
          $facilityData = $CI->facility_model->selectAllFacility('', '');
                    
          $dropDown='';
          if(count($facilityData)>0)
          {  
              $dropDown = "<select name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='0'> Please Select </option>" ;
          while($i<count($facilityData))
          {
              $dropDown .= "<option value=\"".$facilityData[$i]['id']."\"";
              if($selecteditem==$facilityData[$i]['id']) 
              {                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$facilityData[$i]['facility_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";          
          return $dropDown;
          
      }
      
      function fieldDropDownById($name, $id='', $javascript='', $css='', $selecteditem='') 
      {          
          //require './application/models/field_model.php';
          $CI =& get_instance();   
          $fieldObj = $CI->load->model('field_model');
          $fieldData = $CI->field_model->selectFieldById('', '');
          
          $dropDown='';
          if(count($fieldData)>0)
          {   
              $dropDown = "<select name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='0'> Please Select </option>" ;
          while($i<count($fieldData))
          {
              $dropDown .= "<option value=\"".$fieldData[$i]['id']."\"";
              if($selecteditem==$fieldData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$fieldData[$i]['field_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      function groupDropDownById($name, $id='', $javascript='', $css='', $selecteditem='') 
      {          
          //require './application/models/group_model.php';
          $CI =& get_instance();   
          $groupObj = $CI->load->model('group_model');
          $groupData = $CI->group_model->selectGroupById('','');
          $dropDown='';
          if(count($groupData)>0)
          {   
              $dropDown = "<select name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='0'> Please Select </option>" ;
          while($i<count($groupData))
          {
              $dropDown .= "<option value=\"".$groupData[$i]['id']."\"";
              if($selecteditem==$groupData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$groupData[$i]['group_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      function subgroupDropDownById($name, $id='', $javascript='', $css='', $group='',$certificateid='') 
      {          
           //require './application/models/subgroup_model.php';          
	      	$editsubgroupArray = array();    	
	       	if($group!='')
	       	{
	    		$sql = "select * from certificate_sub_group_tbl where certificate_id=$certificateid and group_id=$group";
	    		$subgroupresult = mysql_query($sql);     
	    		while($row=mysql_fetch_array($subgroupresult))
	         		{           		            
	            	   $editsubgroupArray[] = $row['sub_group_id'];                             
	         		}
	        } 	        
           $CI =& get_instance();
           $CI->load->model('subgroup_model');
         // $subgroupObj = new subgroup_model();
          $subgroupData = $CI->subgroup_model->selectSubgroupById('','');
          $dropDown='';
          if(count($subgroupData)>0)
          {   
              $dropDown = "<select name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= " size='3' multiple>";
          }
          $i=0;
          $dropDown .= "<option value='0'> Please Select </option>" ;
          while($i<count($subgroupData))
          {
              $dropDown .= "<option value=\"".$subgroupData[$i]['id']."\"";
              if(in_array($subgroupData[$i]['id'], $editsubgroupArray))//if($selecteditem==$subgroupData[$i]['id']) 
              {                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$subgroupData[$i]['sub_group_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      
      
      
  }
?>
