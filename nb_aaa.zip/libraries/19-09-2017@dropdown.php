<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

  class dropdown {
      
  function zoneDropDwon($name, $id='', $javascript='', $css='', $selecteditem='') 
      {       
      	  //echo "Drop Down Function Called"; 
      	  //echo "Zone Name In Drop Down - ".$id; 
          $CI =& get_instance();
          $zoneModel = $CI->load->model('zone_model');
          //$this->load->model('zone_model');
          //$zoneObj = new zone_model();
          $zoneData = $CI->zone_model->selectAllZone('', '');
          //print_r($zoneData);
          $dropDown='';
          if(count($zoneData)>0)
          {   
      $dropDown = "<select style=\"width:150px;\"  name=\"$name\" id=\"$id\"  class=\"$css\"" ;                                  
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          } else{
		  	$dropDown .= "<select style=\"width:150px;\"  name=\"$name\" id=\"$id\"  class=\"$css\">" ; 
		  }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($zoneData))
          {
              $dropDown .= "<option value=\"".$zoneData[$i]['id']."\"";
              if($selecteditem==$zoneData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$zoneData[$i]['zone_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";        
          
          return $dropDown;          
      }
      
      ////state dropdown////
	    function stateDropDwon($name, $id='', $javascript='', $css='', $selecteditem='') 
      {       
      	  //echo "Drop Down Function Called"; 
      	  //echo "Zone Name In Drop Down - ".$id; 
          $CI =& get_instance();
          $searchModel = $CI->load->model('search_model');
          $stateData = $CI->search_model->get_state($id = FALSE);
        //  print_r($stateData);
          $dropDown='';
          if(count($stateData)>0)
          {   
    $dropDown = "<select style=\"width:150px;\"  name=\"$name\" id=\"$id\"  class=\"$css\"" ;                                    
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($stateData))
          {
              $dropDown .= "<option value=\"".$stateData[$i]['id']."\"";
              if($selecteditem==$stateData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$stateData[$i]['name']."</option>";
              $i++;
          }
          $dropDown .="</select>";        
          
          return $dropDown;          
      }
    
      
	  
	      ////city dropdown////
	    function cityDropDwon($name, $id='', $javascript='', $css='', $selecteditem) 
      {    
      	  //echo "Drop Down Function Called"; 
      	  //echo "Zone Name In Drop Down - ".$id; 
          $CI =& get_instance();
          $citiesModel = $CI->load->model('search_model');
          //$this->load->model('zone_model');
          //$zoneObj = new zone_model();
         /* $cityData = $CI->search_model->get_city($id = FALSE); */
       // commented by Asmita to update dependency of sate and city\
            if($_SERVER['REQUEST_METHOD']=='POST'){
          	$cityData = $CI->search_model->get_city($id = $_POST['state']);
            }else{
          $cityData = $CI->search_model->get_city($id = FALSE);
	 }

         // print_r($stateData);
          $dropDown='';
          if(count($cityData)>0)
          {   
    $dropDown = "<select style=\"width:150px;\"  name=\"$name\" id=\"$id\"  class=\"$css\"" ;                                    
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          } else{
		  	$dropDown .= "<select style=\"width:150px;\"  name=\"$name\" id=\"$id\"  class=\"$css\">" ; 
	}
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($cityData))
          {
              $dropDown .= "<option value=\"".$cityData[$i]['id']."\"";
              if($selecteditem==$cityData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$cityData[$i]['name']."</option>";
              $i++;
          }
          $dropDown .="</select>";        
          
          return $dropDown;          
      }
    
	  
      function natureoflabDropDwon($name, $id='', $javascript='', $css='', $selecteditem='') 
      {          
          //require './application/models/natureoflab_model.php';
          //echo "";
           $CI =& get_instance(); 
          
          $nolabObj =   $CI->load->model('natureoflab_model');
          $nolData = $CI->natureoflab_model->selectAllNatureoflab('', '');  
          $dropDown='';
          if(count($nolData)>0)
          {   
              $dropDown = "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($nolData))
          {
              $dropDown .= "<option value=\"".$nolData[$i]['id']."\"";
              if($selecteditem==$nolData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$nolData[$i]['nature_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      function operationAtDropDwon($name, $id='', $javascript='', $css='', $selecteditem='') 
      { 	
      		$editoperationatArray = array();      		
	       	if($selecteditem!='')
	       	{	  
	       		$tmpArr = explode(",",$selecteditem);    		
      			for($e=0;$e<count($tmpArr);$e++)
      			{	      			   
		           $editoperationatArray[] = $tmpArr[$e];
	      		}	         	
	        }
          //require './application/models/operationat_model.php';
          $CI =& get_instance();
          $nolabObj =   $CI->load->model('operationat_model');
         // $nolabObj = new operationat_model();
          $opatData = $CI->operationat_model->selectAllOperationAt('', '');  
          $dropDown='';
          if(count($opatData)>0)
          {   
              $dropDown .= "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= " size='5' multiple>";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>";
          while($i<count($opatData))
          {
              $dropDown .= "<option value=\"".$opatData[$i]['id']."\"";
               if(in_array($opatData[$i]['id'], $editoperationatArray))//if($selecteditem==$opatData[$i]['id']) {
               {  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$opatData[$i]['operation_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      
      function groupDropDwon($name, $id='', $javascript='', $css='', $selecteditem='') 
      {          
         // require './application/models/group_model.php';
         
          $CI =& get_instance(); 
          
          $groupObj =   $CI->load->model('group_model');
           //= new group_model();
          $groupData = $CI->group_model->selectAllGroup('', '');  
          $dropDown='';
          if(count($groupData)>0)
          {   
              $dropDown = "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($groupData))
          {
              $dropDown .= "<option value=\"".$groupData[$i]['id']."\"";
              if($selecteditem==$groupData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$groupData[$i]['group_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      function facilityDropDwon($name, $id='', $javascript='', $css='', $selecteditem='') 
      {          
          //require './application/models/facility_model.php';
          $CI =& get_instance();   
          $facilityObj = $CI->load->model('facility_model');
          $facilityData = $CI->facility_model->selectAllFacility('', '');
                    
          $dropDown='';
          if(count($facilityData)>0)
          {  
              $dropDown = "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($facilityData))
          {
              $dropDown .= "<option value=\"".$facilityData[$i]['id']."\"";
              if($selecteditem==$facilityData[$i]['id']) 
              {                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$facilityData[$i]['facility_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";          
          return $dropDown;
          
      }
      
      function fieldDropDownById($name, $id='', $javascript='', $css='', $selecteditem,$facilityid) 
      {          
          //require './application/models/field_model.php';
          $CI =& get_instance();   
          $fieldObj = $CI->load->model('lab_model');
          $fieldData = $CI->lab_model->selectFieldById($facilityid,'', '');
          
          $dropDown='';
          if(count($fieldData)>0)
          {   
              $dropDown = "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onclick=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($fieldData))
          {
              $dropDown .= "<option value=\"".$fieldData[$i]['id']."\"";
              if($selecteditem==$fieldData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$fieldData[$i]['category_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      function groupDropDownById($name, $id='', $javascript='', $css='', $selecteditem,$fieldid) 
      {          
          //require './application/models/group_model.php';
          $CI =& get_instance();   
          $groupObj = $CI->load->model('lab_model');
          $groupData = $CI->lab_model->selectGroupById($fieldid,'','');
          $dropDown='';
          if(count($groupData)>0)
          {   
              $dropDown = "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onclick=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($groupData))
          {
              $dropDown .= "<option value=\"".$groupData[$i]['id']."\"";
              if($selecteditem==$groupData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$groupData[$i]['category_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      function subgroupDropDownById($name, $id='', $javascript='', $css='', $group='',$certificateid='') 
      {          
           //require './application/models/subgroup_model.php';         
	      	$editsubgroupArray = array();    	
	       	if($group!='')
	       	{
	    		$sql = "select * from certificate_sub_group_tbl where certificate_id=$certificateid and group_id=$group";
	    		$subgroupresult = mysql_query($sql);     
	    		while($row=mysql_fetch_array($subgroupresult))
	         		{           		            
	            	   $editsubgroupArray[] = $row['sub_group_id'];                             
	         		}
	        } 	        
           $CI =& get_instance();
           $CI->load->model('lab_model');
         // $subgroupObj = new subgroup_model();
          $subgroupData = $CI->lab_model->selectSubgroupById($group,'','');
          $dropDown='';
          if(count($subgroupData)>0)
          {   
              $dropDown = "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= " size='3' multiple>";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($subgroupData))
          {
              $dropDown .= "<option value=\"".$subgroupData[$i]['id']."\"";
              if(in_array($subgroupData[$i]['id'], $editsubgroupArray))//if($selecteditem==$subgroupData[$i]['id']) 
              {                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$subgroupData[$i]['category_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      public function facilityDropDown($name, $id='', $javascript='', $css='', $selecteditem='') 
      {      		          
          //require './application/models/facility_model.php';
          $CI =& get_instance();   
          $facilityObj = $CI->load->model('lab_model');
          $facilityData = $CI->lab_model->selectAllFacility_Lab('', '');
                    
          $dropDown='';
          if(count($facilityData)>0)
          {  
              $dropDown = "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($facilityData))
          {
              $dropDown .= "<option value=\"".$facilityData[$i]['id']."\"";
              if($selecteditem==$facilityData[$i]['id']) 
              {                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$facilityData[$i]['category_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";          
          return $dropDown;
          
      
      }
      
    public function labsdropdown($name, $id='', $javascript='', $css='', $selecteditem='')
    {    	       
      	  //echo "Drop Down Function Called";   
          $CI =& get_instance();
          $labModel = $CI->load->model('laboratory_model');
          //$this->load->model('zone_model');
          //$zoneObj = new zone_model();
          $labData = $CI->laboratory_model->get_all_laboratory();
          //print_r($zoneData);
          $dropDown='';
          if(count($labData)>0)
          {   
              $dropDown = "<select style=\"width:150px;\"  name=\"$name\" id=\"$id\"  class=\"$css\"" ;                                    
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($labData))
          {
              $dropDown .= "<option value=\"".$labData[$i]['id']."\"";
              if($selecteditem==$labData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$labData[$i]['lab_registration_code']." : ".$labData[$i]['lab_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";        
          
          return $dropDown;      
    }  
      
    
    public function certificatedropdown($name, $id='', $javascript='', $css='', $selecteditem='')
    {    	       
      	  //echo "Drop Down Function Called";   
          $CI =& get_instance();
          $certificateModel = $CI->load->model('Certificate_model');
          //$this->load->model('zone_model');
          //$zoneObj = new zone_model();
          $certificateData = $CI->Certificate_model->get_all_certificate_new();         
          //print_r($zoneData);
          $dropDown='';
          if(count($certificateData)>0)
          {   
              $dropDown = "<select style=\"width:150px;\"  name=\"$name\" id=\"$id\" onchange='showLaboratory(this.value)'   class=\"$css\""  ;                                    
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($certificateData))
          {
              $dropDown .= "<option value=\"".$certificateData[$i]['id']."|".$certificateData[$i]['certificate_no']."\"";
              if($selecteditem==$certificateData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$certificateData[$i]['certificate_no']."</option>";
              $i++;
          }
          $dropDown .="</select>";        
          
          return $dropDown;      
    }

  	function subgroupDropDownByIdForSearch($name, $id='', $javascript='', $css='', $selecteditem,$groupid) 
      {         	
      	  $subgroupArr = array();
      	  if($selecteditem!=""){
      	  	  $tmpArr = explode(",",$selecteditem);
	      	  for($x=0;$x<count($tmpArr);$x++)
	      	  {
		      	  $tempsubGroup1Arr = explode('-',$tmpArr[$x]);
		      	  $tempsubGroup2Arr = explode('_',$tempsubGroup1Arr[0]);
		      	  $subgroupArr[] = $tempsubGroup2Arr[1];
	      	  }
      	  }
      	  
          $CI =& get_instance();
          $subgroupObj = $CI->load->model('lab_model');
          $subgroupData = $CI->lab_model->selectSubgroupById($groupid,'','');
          $dropDown='';
          if(count($subgroupData)>0)
          {   
              $dropDown = "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onclick=\"return $javascript\"";
              }
              $dropDown .= " size='10' multiple>";
          }
          $i=0;
          $dropDown .= "" ;
          while($i<count($subgroupData))
          {
              $dropDown .= "<option value='".$groupid."_".$subgroupData[$i]['id']."-".$subgroupData[$i]['category_name']."' ";
              if(in_array($subgroupData[$i]['id'], $subgroupArr))
              {                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$subgroupData[$i]['category_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      
  	function operationAtDropDown($name, $id='', $javascript='', $css='', $selecteditem='') 
      { 	
      		$editoperationatArray = array();      		
	       	if(count($selecteditem)>0)
	       	{  		
      			for($e=0;$e<count($selecteditem);$e++)
      			{	      			   
		           $editoperationatArray[] = $selecteditem[$e];
	      		}	         	
	        }
          //require './application/models/operationat_model.php';
          $CI =& get_instance();
          $nolabObj =   $CI->load->model('operationat_model');
         // $nolabObj = new operationat_model();
          $opatData = $CI->operationat_model->selectAllOperationAt('', '');  
          $dropDown='';
          if(count($opatData)>0)
          {   
              $dropDown .= "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onchange=\"return $javascript\"";
              }
              $dropDown .= " size='5' multiple>";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>";
          while($i<count($opatData))
          {
              $dropDown .= "<option value=\"".$opatData[$i]['id']."\"";
               if(in_array($opatData[$i]['id'], $editoperationatArray))//if($selecteditem==$opatData[$i]['id']) {
               {  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$opatData[$i]['operation_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
      
      //change @ 10-04-2017
      function groupDropDownByIdPro($name, $id='', $javascript='', $css='', $selecteditem,$fieldid) 
      {
          $fieldid = $fieldid[count($fieldid)-1];
          //require './application/models/group_model.php';
          $CI =& get_instance();   
          $groupObj = $CI->load->model('lab_model');
          $groupData = $CI->lab_model->selectGroupById($fieldid,'','');
          $dropDown='';
          if(count($groupData)>0)
          {   
              $dropDown = "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onclick=\"return $javascript\"";
              }
              $dropDown .= ">";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($groupData))
          {
              $dropDown .= "<option value=\"".$groupData[$i]['id']."\"";
              if($selecteditem==$groupData[$i]['id']) {
                  
                  $dropDown .= " selected=\"selected\"";
              }              
              $dropDown .=">".$groupData[$i]['category_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
	  function fieldDropDownByIdPro($name, $id='', $javascript='', $css='', $selecteditem,$facilityid) 
      {  
         //echo '<pre>'; var_dump($selecteditem);  var_dump($facilityid); die;	  
          //require './application/models/field_model.php';
          $CI =& get_instance();   
          $fieldObj = $CI->load->model('lab_model');
          $fieldData = $CI->lab_model->selectFieldById($facilityid,'', '');
          $dropDown='';
          if(count($fieldData)>0)
          {   
              $dropDown = "<select style=\"width:150px;\" name=\"$name\" id=\"$id\"  class=\"$css\"" ;              
              if($javascript!='') 
              {
                  $dropDown .= " onclick=\"return $javascript\"";
              }
              $dropDown .= " multiple>";
          }
          $i=0;
          $dropDown .= "<option value='-1'> Please Select </option>" ;
          while($i<count($fieldData))
          {
              $dropDown .= "<option value=\"".$fieldData[$i]['id']."\"";
				  if(in_array($fieldData[$i]['id'], $selecteditem)) {
					 $dropDown .= " selected=\"selected\"";
                  }             
              $dropDown .=">".$fieldData[$i]['category_name']."</option>";
              $i++;
          }
          $dropDown .="</select>";
          //echo $dropDown;
          return $dropDown;          
      }
  }
?>
