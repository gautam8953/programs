<?php
class publicstatusapplicantlaboratories extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('status_applicant_laboratories_model');
	}
	
	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Miscellaneous";//"Status of Applicant Laboratories";
			/*
	        $this->load->library('session');
	        if(!$this->session->userdata('nabl_user'))
	        {             
	           redirect('c=auth&m=login');
	        }
	        */
        
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=publicstatusapplicantlaboratories&m=index';
	    $config['total_rows'] = $this->db->count_all('status_applicant_laboratories_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';
	    $this->pagination->initialize($config);
	    $this->load->model('status_applicant_laboratories_model');
	    $data['laccua'] = $this->status_applicant_laboratories_model->get_all_statusapplicantlaboratory($config['per_page']);
	    //$this->load->view('templates/header', $data);
		$this->load->view('publicstatusapplicantlaboratories/index', $data);
		//$this->load->view('templates/footer');
	}
	
}