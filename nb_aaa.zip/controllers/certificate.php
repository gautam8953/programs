<?php
/* error_reporting(E_ALL);
		ini_set('display_errors','1'); */
//include './application/libraries/dropdown.php';
class Certificate extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('certificate_model');
	}

	
	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Certificate";
		$this->load->library('session');    
        if(!$this->session->userdata('nabl_user'))
        {
           //$this->load->helper('url');
           redirect('c=auth&m=login');
        }      
		$this->load->helper('form');
				
		if(array_key_exists('submit',$_POST)) //($this->form_validation->run() === FALSE)
		{			
			$data['pagination']="yes";
			$this->load->library('pagination');			 
		    $config['base_url'] = base_url().'index.php?c=certificate&m=index';
		    
		    $this->db->select('l.id, l.lab_registration_code, l.lab_name, c.lab_id, c.certificate_no');
		    $this->db->from('lab_certificate_tbl as c');
		    $this->db->join('laboratory_tbl as l','c.lab_id=l.id','inner');
		    if($this->input->post('labcode')!="")		    
		    	$this->db->where('l.lab_registration_code',$this->input->post('labcode'));		  	    	    
		    if($this->input->post('labname')!="")
		    	$this->db->like('lab_name',$this->input->post('labname'));  	
		    if($this->input->post('certificateno')!="")
		    	$this->db->where('c.certificate_no',$this->input->post('certificateno'));  	
		    	
			    
	   		$config['total_rows'] = $this->db->count_all_results();
	   		//$data['total_rows'] = $this->db->count_all_results();
		    $config['per_page'] = '10';
		    $config['full_tag_open'] = '<p>';
		    $config['full_tag_close'] = '</p>';	
		    $this->pagination->initialize($config);
		    $this->load->model('certificate_model');
		    $data['labdata'] = $this->certificate_model->get_all_labs_contains_certificates($config['per_page']);
		    $data['total_rows'] = $this->certificate_model->count_all_labs_contains_certificates();
		    $certificateArr = array();
		    if(count($data['labdata'])>0)
		    {
		    	for($h=0;$h<count($data['labdata']);$h++)
		    	{
		    		$certificateArr[] = $this->certificate_model->get_certificates_by_labid($data['labdata'][$h]['id']);
		    	}
		    }	    
		    $data['cdata']=$certificateArr;		     
		    $this->load->view('templates/header', $data);
			$this->load->view('certificate/index', $data);
			$this->load->view('templates/footer');		
							
		}
		else 
		{				
			$data['pagination']="yes";
			$this->load->library('pagination');			 
		    $config['base_url'] = base_url().'index.php?c=certificate&m=index';
		    
		    $this->db->select('l.id, l.lab_registration_code, l.lab_name, c.lab_id, c.certificate_no');
		    $this->db->from('lab_certificate_tbl as c');
		    $this->db->join('laboratory_tbl as l','c.lab_id=l.id','inner');
		    if($this->input->post('labcode')!="")		    
		    	$this->db->where('l.lab_registration_code',$this->input->post('labcode'));		  	    	    
		    if($this->input->post('labname')!="")
		    	$this->db->like('lab_name',$this->input->post('labname'));  	
		    if($this->input->post('certificateno')!="")
		    	$this->db->where('c.certificate_no',$this->input->post('certificateno'));  	
		    	
			    
	   		$config['total_rows'] = $this->db->count_all_results();
	   		//$data['total_rows'] = $this->db->count_all_results();
		    $config['per_page'] = '10';
		    $config['full_tag_open'] = '<p>';
		    $config['full_tag_close'] = '</p>';	
		    $this->pagination->initialize($config);
		    $this->load->model('certificate_model');
		    $data['labdata'] = $this->certificate_model->get_all_labs_contains_certificates($config['per_page']);
		    $data['total_rows'] = $this->certificate_model->count_all_labs_contains_certificates();
		    $certificateArr = array();
		    if(count($data['labdata'])>0)
		    {
		    	for($a=0;$a<count($data['labdata']);$a++)
		    	{
		    		$certificateArr[] = $this->certificate_model->get_certificates_by_labid($data['labdata'][$a]['id']);
					
		    	}
		    }
			//
		    $data['cdata']=$certificateArr;		     
		    $this->load->view('templates/header', $data);
			$this->load->view('certificate/index', $data);
			$this->load->view('templates/footer');		
			
		}
		
	}

			
	public function view($slug='')
	{		
		$this->load->helper('url');
		$data['title'] = "Certificate";
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {           
           redirect('c=auth&m=login');
        }
        
		$this->load->helper('form');				
		$data['certificatedata'] = $this->certificate_model->viewCertificate();
		$data['gnsdata']=$this->certificate_model->viewGroupSubGroup();
		//echo"<pre>";print_R($data['certificatedata']);die;
		if(array_key_exists('submit',$_POST))
		{			
			
		}
		else
		{
			
			$this->load->view('certificate/view',$data);				
		}
		
	}
			
	public function create()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {           
           redirect('c=auth&m=login');
        }
		$this->load->library('dropdown');			
		$this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Add Certificate';		
		
		$data['lab'] = $this->certificate_model->get_lab();
		$data['nolab'] = $this->certificate_model->get_natureoflab();		
		$data['operat'] = $this->dropdown->operationAtDropDwon('operationat[]','operationat','','','');
		$data['facilitydropdown'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id',  'getFieldList(this.value)', '','');
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{			
			
			$cermsg = $this->certificate_model->set_certificate();			
			if(isset($cermsg) && count($cermsg)==1)
			{
				if(isset($cermsg['duplicate']) && $cermsg['duplicate']=="duplicate")
				{
					 //duplicate error
			?>
					<script>alert('Certificate Already Exists');
					location = "<?php echo $_SERVER['PHP_SELF'];?>?c=certificate&m=create";
					</script>
		<?php 
				}
				if(isset($cermsg['unsuccess']) && $cermsg['unsuccess']=="unsuccess")
				{
					//unable to insert error
			?>
					<script>alert('Unable To Add Certificate');
					location = "<?php echo $_SERVER['PHP_SELF'];?>?c=certificate&m=create";
					</script>
			<?php 
				}
			}
			if(isset($cermsg) && count($cermsg)==2)
			{
				if(isset($cermsg['success']) && $cermsg['success']=="success")
				{
					$certificateid = $cermsg['cid'];
					if($certificateid!="")
					{
						include './application/controllers/Upload.php';	
						$uploadObj = new Upload(); 				                     
			            $data['certInfo1'] = $uploadObj->do_upload("certificatedoc",$certificateid);
						$ext = $this->get_file_extension($_FILES['certificatedoc']['name']);
						$userDoc = "uploads/".$certificateid.".".$ext;
						$content = "";
						if($ext=="doc")
						{
							$content = $this->parseWord($userDoc);				
						}
						if( $ext=="docx")
						{
							$content = $this->readDocx($userDoc);				
						}
						if( $ext=="pdf")
						{
							
							include './application/controllers/class.pdf2txt.php';
							$a = new PDF2Text();
							$a->setFilename($userDoc);
							$a->decodePDF();
							$content= $a->output();
							

						}
			            $this->load->model('certificate_model');
			            $this->certificate_model->updateCertificateDocument($certificateid,$content);
					}
					$this->load->helper('url');
					?>
						<script>alert('Certificate Added');
						location = "<?php echo $_SERVER['PHP_SELF'];?>?c=certificate&m=index";
						</script>
					<?php 	
					
				}
			}				
			$this->load->helper('url')			
			?>
			<script>alert('Certificate Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=certificate&m=index";
			</script>
			<?php			
		}
		else
		{			
			$this->load->helper('url');		
			$this->load->view('templates/header', $data);
			$this->load->view('certificate/create');
			$this->load->view('templates/footer');
		}
	}
			
	public function editcertificate()
	{
		
				$this->load->helper('url');
			    $this->load->library('session');              
		        if(!$this->session->userdata('nabl_user'))
		        {
		           //$this->load->helper('url');
		           redirect('c=auth&m=login');
		        }				
				$this->load->library('dropdown');
				$this->load->helper('form');
				$this->load->library('form_validation');
		
				$data['title'] = 'Edit Certificate';
				$data['news'] = $this->certificate_model->get_certificate_details($_GET['id']);
				
				$data['row'] = $this->certificate_model->edit_certificate_details($_GET['id']);
				
				$opAtstr = $data['news']['operationat'];
				$opAt = explode(",",$opAtstr);				
				
				$data['lab'] = $this->certificate_model->get_lab();
				$data['nolab'] = $this->certificate_model->get_natureoflab();
				$data['operat'] = $this->dropdown->operationAtDropDown('operationat[]','operationat[]','','',$opAt);
				$data['facilitydropdown'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id',  'getFieldList(this.value)','',$data['news']['faclity_id']);
				$data['fielddropdown'] = $this->dropdown->fieldDropDownById('field_id', 'field_id', 'getgroupList(this.value)', '',$data['news']['filed_id'],$data['news']['faclity_id']);
				$data['groupdropdown'] = $this->dropdown->groupDropDownById('group_id', 'group_id', 'getsubgroupList(this.value)', '',$data['news']['group_id'],$data['news']['filed_id']);
				$data['subgroupdropdown'] = $this->dropdown->subgroupDropDownById('subgroup[]', 'subgroup_id', '', '', $data['news']['group_id'],$_GET['id']);
				
				
				if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
				{				
					$this->load->helper('url');
					$filecontent = "";
					$content = "";
					if($_FILES['certificatedoc']['name']!="")
					{
						include './application/controllers/Upload.php';
						$uploadObj = new Upload(); 				                     
			            $data['certInfo1'] = $uploadObj->do_upload("certificatedoc",$_GET['id']);
			            $ext = $this->get_file_extension($_FILES['certificatedoc']['name']);
			            $userDoc = "uploads/".$_GET['id'].".".$ext;
						$content = "";
									//if($ext=="doc") 
									//This is changed by Ashit on 05-09-2013 for updation of cirtificates.
				               if($ext=="doc")
						{
							$content = $this->parseWord($userDoc);				
						}
						if( $ext=="docx")
						{
							$content = $this->readDocx($userDoc);				
						}
						if( $ext=="pdf")
						{
							
							include './application/controllers/class.pdf2txt.php';
							$a = new PDF2Text();
							$a->setFilename($userDoc);
							$a->decodePDF();
							$content= $a->output();
							

						}						
					}
					$this->load->model('certificate_model');
					$this->certificate_model->update_certificate($_GET['id'],$content);
					$this->load->helper('url');
					?>
					<script>alert('Certificate Updated');
					location = "<?php echo $_SERVER['PHP_SELF'];?>?c=certificate&m=index";
					</script>
					<?php
				}
				else
				{
					$this->load->helper('url');
					$this->load->view('templates/header', $data);					
					$this->load->view('certificate/editcertificate');
					$this->load->view('templates/footer');	
				}
	}
			
	public function deletecertificate()
	{
				$this->load->helper('url');
				$this->load->library('session');              
		        if(!$this->session->userdata('nabl_user'))
		        {
		           //$this->load->helper('url');
		           redirect('c=auth&m=login');
		        }		        	
				$data['title'] = 'Delete Certificate';
				$this->load->helper('form');
				$this->load->library('form_validation');		
		
				$this->certificate_model->delete_certificate($_GET['id']);
				$this->load->helper('url');
				?>
					<script>alert('Certificate Deleted');
					location = "<?php echo $_SERVER['PHP_SELF'];?>?c=certificate&m=index";
					</script>
				<?php
		
		
	}
	
	function parseWord($userDoc) 
	{
	    $fileHandle = fopen($userDoc, "r");
	    $word_text = @fread($fileHandle, filesize($userDoc));
	    $line = "";
	    $tam = filesize($userDoc);
	    $nulos = 0;
	    $caracteres = 0;
	    for($i=1536; $i<$tam; $i++)
	    {
	        $line .= $word_text[$i];
	
	        if( $word_text[$i] == 0)
	        {
	            $nulos++;
	        }
	        else
	        {
	            $nulos=0;
	            $caracteres++;
	        }
	
	        if( $nulos>1996)
	        {   
	            break;  
	        }
	    }	
	    //echo $caracteres;	
	    $lines = explode(chr(0x0D),$line);
	    //$outtext = "<pre>";	
	    $outtext = "";
	    foreach($lines as $thisline)
	    {
	        $tam = strlen($thisline);
	        if( !$tam )
	        {
	            continue;
	        }
	
	        $new_line = ""; 
	        for($i=0; $i<$tam; $i++)
	        {
	            $onechar = $thisline[$i];
	            if( $onechar > chr(240) )
	            {
	                continue;
	            }
	
	            if( $onechar >= chr(0x20) )
	            {
	                $caracteres++;
	                $new_line .= $onechar;
	            }
	
	            if( $onechar == chr(0x14) )
	            {
	                $new_line .= "</a>";
	            }
	
	            if( $onechar == chr(0x07) )
	            {
	                $new_line .= "\t";
	                if( isset($thisline[$i+1]) )
	                {
	                    if( $thisline[$i+1] == chr(0x07) )
	                    {
	                        $new_line .= "\n";
	                    }
	                }
	            }
	        }
	        //troca por hiperlink
	        $new_line = str_replace("HYPERLINK" ,"<a href=",$new_line); 
	        $new_line = str_replace("\o" ,">",$new_line); 
	        $new_line .= "\n";
	
	        //link de imagens
	        $new_line = str_replace("INCLUDEPICTURE" ,"<br><img src=",$new_line); 
	        $new_line = str_replace("\*" ,"><br>",$new_line); 
	        $new_line = str_replace("MERGEFORMATINET" ,"",$new_line);
	        $outtext .= nl2br($new_line);
	    }	
	 return $outtext;
	} 
		/// for .docx only 
	function readDocx($filePath) 
{
	// Create new ZIP archive
	$zip = new ZipArchive;
	$dataFile = 'word/document.xml';
	// Open received archive file
	if (true === $zip->open($filePath)) {
	// If done, search for the data file in the archive
	if (($index = $zip->locateName($dataFile)) !== false) {
		// If found, read it to the string
		$data = $zip->getFromIndex($index);
		// Close archive file
		$zip->close();
		// Load XML from a string
		// Skip errors and warnings
		$xml = DOMDocument::loadXML($data, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
		// Return data without XML formatting tags
	
		$contents = explode('\n',strip_tags($xml->saveXML()));
		$text = '';
		foreach($contents as $i=>$content) {
			$text .= $contents[$i];
		}
		return $text;
	}
	$zip->close();
	}
	// In case of failure return empty string
	return "";
}

//////////
	function get_file_extension($file_name) 
	{
		return end(explode('.',$file_name));
	}
	
	public function updateStatus()
	{
		$this->load->helper('url');
		$this->load->library('session');
		if(!$this->session->userdata('nabl_user'))
		{
			redirect('c=auth&m=login');
		}
		$status = $_GET['status'];
		$id = $_GET['id'];		
		$this->load->model('certificate_model');
		if($this->certificate_model->update_status($status, $id))
		{
			?>
			<script language="javascript">
			alert('Status Updated Successfully');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=certificate";
			</script>
			<?php 
		}
		else
		{
			?>
			<script language="javascript">
			alert('Unable To Update Status');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=certificate";
			</script>
			<?php
		}		
	}
			

}