<?php
class Jobs extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('jobs_model');
	}

	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Jobs";
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }		
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=jobs&m=index';
	    $config['total_rows'] = $this->db->count_all('job_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('jobs_model');
	    $data['news'] = $this->jobs_model->get_all_jobsPostings($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('jobs/index', $data);
		$this->load->view('templates/footer');	
		
		
	}

	public function view($slug)
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $data['news_item'] = $this->jobs_model->get_jobs($slug);
		if (empty($data['news_item']))
		{
			show_404();
		}
		$data['title'] = $data['news_item']['title'];
		$this->load->view('templates/header', $data);
		$this->load->view('jobs/view', $data);
		$this->load->view('templates/footer');
	}

	public function create()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('form');
		$this->load->library('form_validation');
		
		$data['title'] = 'Add Job';
		
		if (array_key_exists('submit', $_POST))//($this->form_validation->run() === FALSE)
		{				
			//$this->jobs_model->set_job();
			include './application/controllers/Upload.php';
			$uploadObj = new Upload(); 				    
			if(isset($_FILES['jobdesc']['tmp_name']) && $_FILES['jobdesc']['tmp_name']!="")              
            	$data['jobdesc'] = $uploadObj->do_upload("jobdesc"); 
            if(isset($_FILES['applicationdoc']['tmp_name']) && $_FILES['applicationdoc']['tmp_name']!="")
            	$data['application'] = $uploadObj->do_upload("applicationdoc");
            
            //print_r($data['jobdesc']);
            //echo "<br/>";
            //print_r($data['application']);
            //die();
            $this->load->model('jobs_model');
            $this->jobs_model->set_job($data['jobdesc']['name'],$data['application']['name']);
			$this->load->helper('url');
			?>
			<script>alert('Jobs Added Successfully ');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=jobs";
			</script>
			<?php
		}
		else
		{	
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('jobs/create');
			$this->load->view('templates/footer');
		}
	}
	
	
	public function editjob()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Edit Job';
		//$data['options'] = $this->jobs_model->get_clip_dropdown();
		$data['news'] = $this->jobs_model->get_jobs($_GET['id']);

		if(array_key_exists('submit', $_POST))//($this->form_validation->run() === FALSE)
		{			        
			include './application/controllers/Upload.php';
			$uploadObj = new Upload(); 	
			$jobFileName = "";
			$appfileName = "";	
			if(isset($_FILES['jobdesc']['tmp_name']) && $_FILES['jobdesc']['tmp_name']!="") 
			{	                     
            	$data['jobdesc'] = $uploadObj->do_upload("jobdesc");
            	$jobFileName = $data['jobdesc']['name'];
			}
           if(isset($_FILES['applicationdoc']['tmp_name']) && $_FILES['applicationdoc']['tmp_name']!="")
            {       
            	$data['application'] = $uploadObj->do_upload("applicationdoc");
            	$appfileName = $data['application']['name'];
            }
            
            $this->load->model('jobs_model');
            $this->jobs_model->update_job($_GET['id'],$jobFileName,$appfileName);
			$this->load->helper('url');		
				
			?>
			<script>alert('Job Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=jobs";
			</script>
			<?php			
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('jobs/editjob');
			$this->load->view('templates/footer');
		}
	}
	
	public function deletejob()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }        
        $data['title'] = 'Delete Job';
		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->load->view('templates/header', $data);
		$this->load->view('jobs/index');
		$this->load->view('templates/footer');	
		
		$this->jobs_model->delete_job($_GET['id']);
		$this->load->helper('url');
		?>
		<script>alert('Job Deleted');
		location = "<?php echo $_SERVER['PHP_SELF'];?>?c=jobs";
		</script>
		<?php
	}

}