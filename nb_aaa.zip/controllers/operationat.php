<?php
class operationat extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('operationat_model');
	}

	public function index()
	{
		$data['title'] = "Facility";
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        		
		$this->load->helper('url');
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=operationat&m=index';
	    $config['total_rows'] = $this->db->count_all('lab_operations_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('operationat_model');
	    $data['operationat'] = $this->operationat_model->get_all_operationat($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('operationat/index', $data);
		$this->load->view('templates/footer');
		
	}

	public function view($slug)
	{
			
	}

	public function create()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        
        $this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Add - Facility';
		//$this->form_validation->set_rules('operation_name', 'Please Enter Operation Name', 'required');		

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->operationat_model->set_operationat();
			$this->load->helper('url');
			?>
			<script>alert('Facility Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=operationat";
			</script>
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('operationat/create');
			$this->load->view('templates/footer');
		}
	}

	public function edit_operationat()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        
        $this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Edit - Facility';
		$data['operationat'] = $this->operationat_model->get_operationat($_GET['id']);
		//$this->form_validation->set_rules('operation_name', 'Please Enter Operation Name', 'required');

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->operationat_model->update_operationat($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Facility Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=operationat";
			</script>
			<?php		
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('operationat/edit_operationat');
			$this->load->view('templates/footer');
		}
	}

	public function delete_operationat()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $data['title'] = 'Delete - Facility';
		$this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Delete - Facility ';
		$this->operationat_model->delete_operationat($_GET['id']);
		$this->load->helper('url');
		?>
			<script>alert('Facility Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=operationat";
			</script>
		<?php
	}
}