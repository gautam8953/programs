<?php
class Group extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('group_model');
    }

    public function index()
    {
    	$data['title'] = "Groups";
        $this->load->library('session'); 
        if(!$this->session->userdata('nabl_user'))
        {
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
       
        $this->load->helper('url');
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=group&m=index';
	    $config['total_rows'] = $this->db->count_all('group_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('group_model');
	    $data['news'] = $this->group_model->get_all_labs_groups($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('group/index', $data);
		$this->load->view('templates/footer');	
        
    }

    public function view($slug)
    {
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $data['news_item'] = $this->group_model->get_lab_group($slug);

        if (empty($data['news_item']))
        {
            show_404();
        }

        $data['title'] = $data['news_item']['group_name'];

        $this->load->view('templates/header', $data);
        $this->load->view('group/view', $data);
        $this->load->view('templates/footer');
    }

    public function create()
    {
        $this->load->library('session');  
        $this->load->library('dropdown'); 
                
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
       
        $this->load->helper('form');
        $this->load->library('form_validation');

        $data['title'] = 'Create a Lab group';
        
        $data['fielddropdown'] = $this->dropdown->fieldDropDownById('field_id', 'field_id',  '', '');

        $this->form_validation->set_rules('group_name', 'group Name', 'required');
        $this->form_validation->set_rules('group_description', 'Description', 'required');

        if ($this->form_validation->run() === FALSE)
        {
        	$this->load->helper('url');
            $this->load->view('templates/header', $data);
            $this->load->view('group/create');
            $this->load->view('templates/footer');

        }
        else
        {
            $this->group_model->set_group();
            $this->load->helper('url');
            ?>
            <script>alert('group Added');
            location = "<?php echo $_SERVER['PHP_SELF'];?>?c=group";
            </script>
            <?php

        }
    }

    public function editgroup()
    {
    	$this->load->library('dropdown'); 
        $this->load->library('session');
        if(!$this->session->userdata('nabl_user'))
        {
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }       
        $this->load->helper('form');
        $this->load->library('form_validation');

        $data['title'] = 'Edit - Lab group';
        $data['group'] = $this->group_model->get_lab_group($_GET['id']);
        //print_r($data['group']);
		$data['fielddropdown'] = $this->dropdown->fieldDropDownById('field_id', 'field_id',  '', '',$data['group']['field_id']);
		
        $this->form_validation->set_rules('group_name', 'group Name', 'required');
        $this->form_validation->set_rules('group_description', 'text', 'required');

        if ($this->form_validation->run() === FALSE)
        {
        	$this->load->helper('url');
            $this->load->view('templates/header', $data);
            $this->load->view('group/editgroup');
            $this->load->view('templates/footer');

        }
        else
        {
            $this->group_model->update_group($_GET['id']);
            $this->load->helper('url');
            ?>
            <script>alert('group Updated');
            location = "<?php echo $_SERVER['PHP_SELF'];?>?c=group";
            </script>
            <?php

        }
    }

    public function deletegroup()
    {
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        
		$this->load->helper('url');
        $data['title'] = 'Delete Lab group';
        $this->load->helper('form');
        $this->load->library('form_validation');

            $this->load->view('templates/header', $data);
            $this->load->view('group/index');
            $this->load->view('templates/footer');

        $data['title'] = 'Delete Lab Category';
        $data['group'] = $this->group_model->get_lab_group($_GET['id']);



            $this->group_model->delete_group($_GET['id']);
            $this->load->helper('url');
            ?>
            <script>alert('group Deleted');
            location = "<?php echo $_SERVER['PHP_SELF'];?>?c=group";
            </script>
            <?php


    }

}