<?php ini_set('memory_limit', '-1');error_reporting(E_ALL);
ini_set('display_errors', 1);
class forcedwithdrawalaccreditation extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('forced_withdrawal_accreditation_model');
	}
	
	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Forced Withdrawal Accreditation";
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){             
           redirect('c=auth&m=login');
        }
        
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=forcedwithdrawalaccreditation&m=index';
	    $config['total_rows'] = $this->db->count_all('forced_withdrawal_accreditation_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';
	    $this->pagination->initialize($config);
	    $this->load->model('forced_withdrawal_accreditation_model');
	    $data['laccua'] = $this->forced_withdrawal_accreditation_model->get_all_forcedWithdrawalAccreditation($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('forcedwithdrawalaccreditation/index', $data);
		$this->load->view('templates/footer');
	}
	
	public function create()
	{
		
		$this->load->helper('url');		
		$this->load->library('session');           
        if(!$this->session->userdata('nabl_user'))
        { 
           redirect('c=auth&m=login');
        }
		
		$this->load->helper('form');
		$this->load->library('dropdown');
			
		$data['title'] = "Add Forced Withdrawal Accreditation";		
		$data['lab_names'] = $this->dropdown->labsdropdown('lab_id','lab_id','','','');
		$data['certificate_no'] = $this->dropdown->certificatedropdown('cno','cno','','','');	//echo "asss";die();
		$data['facilitydropdown'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id',  'getFieldList(this.value)', '','');
		
		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->forced_withdrawal_accreditation_model->setforcedWithdrawalAccreditation();
			$this->load->helper('url');
			?>
			<script>alert('Record Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=forcedwithdrawalaccreditation";
			</script>
			<?php
		}
		else
		{
			//echo "Else Block";
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('forcedwithdrawalaccreditation/create');
			$this->load->view('templates/footer');
		}	
		
	}
	
	public function edit()
	{
				
		$this->load->helper('url');
		$this->load->library('session');
        if(!$this->session->userdata('nabl_user'))
        {
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('dropdown');
		$data['title'] = "Edit Forced Withdrawal Accreditation";
		$data['lacua'] = $this->forced_withdrawal_accreditation_model->get_forcedWithdrawalAccreditation($_GET['id']);
		$data['lab_names'] = $this->dropdown->labsdropdown('lab_id','lab_id','','',$data['lacua']['lab_id']);
		$data['certificate_no'] = $this->dropdown->certificatedropdown('cno','cno','','',$data['lacua']['certificate_id']);
		$data['facilitydropdown'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id',  'getFieldList(this.value)','',$data['lacua']['field']);
		$data['fielddropdown'] = $this->dropdown->fieldDropDownById('field_id', 'field_id', '', '',$data['lacua']['discipline'],$data['lacua']['field']);
		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->forced_withdrawal_accreditation_model->updateforcedWithdrawalAccreditation($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Record Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=forcedwithdrawalaccreditation";
			</script>
			<?php
		}
		else
		{
			//echo "Else Block";
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('forcedwithdrawalaccreditation/edit');
			$this->load->view('templates/footer');
		}
	
	}
	
	public function delete()
	{		
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {              
           redirect('c=auth&m=login');
        }		
		$this->load->helper('form');
		//$this->load->library('form_validation');
		$data['title'] = 'Delete - Forced Withdrawal Accreditation ';
		$this->forced_withdrawal_accreditation_model->deleteforcedWithdrawalAccreditation($_GET['id']);
		$this->load->helper('url');
		?>
			<script>alert('Record Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=forcedwithdrawalaccreditation";
			</script>
		<?php	
	}
}