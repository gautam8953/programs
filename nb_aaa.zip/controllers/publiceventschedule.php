<?php
class publiceventschedule extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Eventschedule_model');
	}

	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Course Details - ";
			/*
	        $this->load->library('session');              
	        if(!$this->session->userdata('nabl_user')){
	              //$this->load->helper('url');
	           redirect('c=auth&m=login');
	        }
	        */		
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $traingType = $_GET['trainingType'];
	    $config['base_url'] = base_url().'index.php?c=publiceventschedule&m=index&traingType='.$traingType;
	    $config['per_page'] = '20';	    
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('Eventschedule_model');
	    $config['total_rows'] = count($this->Eventschedule_model->count_eventScheduleByTraingType($traingType));
	    $data['evtscde'] = $this->Eventschedule_model->get_lab_all_eventScheduleByTraingType($config['per_page'],$traingType);
	    //$this->load->view('templates/header', $data);
		$this->load->view('publiceventschedule/index', $data);
		//$this->load->view('templates/footer');		
		
	}
	
	public function view()
	{
		$this->load->helper('url');
		$eventId = $_GET['eventid'];
		$this->load->model('Eventschedule_model');
		$data['courseDetails'] = $this->Eventschedule_model->get_event_test_schedule($eventId);		
		$this->load->view('publiceventschedule/view',$data);
	}

}




