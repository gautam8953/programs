<?php  
class publicaccredationdoc extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('AccredationDoc_model');
	}	
	public function index()
	{
		$data['title'] = 'Accredation Document';
		$docType = $this->input->get('docType');
		$this->load->helper('url');
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=publicaccredationdoc&m=index&docType='.$docType;
	    $config['total_rows'] = count($this->AccredationDoc_model->get_accre_doc_by_doctype($docType));
	    $config['per_page'] = '25';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('AccredationDoc_model');
	    $data['news'] = $this->AccredationDoc_model->get_lab_all_accredatationDocByType($config['per_page'],$docType);
	    //$this->load->view('templates/header', $data);
		$this->load->view('publicaccredationdoc/index', $data);
		//$this->load->view('templates/footer');		
	}	
	public function view($slug)
	{
		
	}
}





