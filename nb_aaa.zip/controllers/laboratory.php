<?php
class Laboratory extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('laboratory_model');
	}

	
	public function index()
	{
		$this->load->helper('url');
		$data['title'] = 'Laboratory';			
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {           
           redirect('c=auth&m=login');
        }
        $this->load->helper('form');		
		if(array_key_exists('submit',$_POST)) //($this->form_validation->run() === FALSE)
		{
					
			$data['pagination']="yes";
			$this->load->library('pagination');
		    $config['base_url'] = base_url().'index.php?c=laboratory&m=index';
		    if($this->input->post('labcode')!="")		    
		    	$this->db->where('lab_registration_code',$this->input->post('labcode'));		  	    	    
		    if($this->input->post('labname')!="")		   
		    	$this->db->where('lab_name',$this->input->post('labname'));	  
		    	
			$this->db->from('laboratory_tbl');    
	   		$config['total_rows'] = $this->db->count_all_results();	 
		    //$config['total_rows'] = $this->db->count_all('laboratory_tbl');
		    $config['per_page'] = '10';
		    $config['full_tag_open'] = '<p>';
		    $config['full_tag_close'] = '</p>';
		    $this->pagination->initialize($config);
		    $this->load->model('laboratory_model');
		    //$data['total_rows'] =  $this->lab_model->count_all_labs_category($catid);
		    $data['total_rows'] = $this->laboratory_model->count_all_labs();
		    $data['news'] = $this->laboratory_model->get_lab_all_laboratory($config['per_page']);
		    $this->load->view('templates/header', $data);
			$this->load->view('laboratory/index', $data);
			$this->load->view('templates/footer');
			
		}
		else
		{
			$data['pagination']="yes";
			$this->load->library('pagination');	    
		    $config['base_url'] = base_url().'index.php?c=laboratory&m=index';
		    if($this->input->post('labcode')!="")		    
		    	$this->db->where('lab_registration_code',$this->input->post('labcode'));		  	    	    
		    if($this->input->post('labname')!="")		   
		    	$this->db->where('lab_name',$this->input->post('labname'));	  
		    	
			$this->db->from('laboratory_tbl');    
	   		$config['total_rows'] = $this->db->count_all_results();	 
		    //$config['total_rows'] = $this->db->count_all('laboratory_tbl');
		    $config['per_page'] = '10';
		    $config['full_tag_open'] = '<p>';
		    $config['full_tag_close'] = '</p>';
		    $this->pagination->initialize($config);
		    $this->load->model('laboratory_model');
		    //$data['total_rows'] =  $this->lab_model->count_all_labs_category($catid);
		    $data['total_rows'] = $this->laboratory_model->count_all_labs();
		    $data['news'] = $this->laboratory_model->get_lab_all_laboratory($config['per_page']);
		    $this->load->view('templates/header', $data);
			$this->load->view('laboratory/index', $data);
			$this->load->view('templates/footer');
			
		}
	}

			
	public function view($slug='')
	{
		$this->load->helper('url');
		$data['title'] = "Laboratory";
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
           //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        
		$this->load->helper('form');
		//$this->load->helper('url');		
		$data['labdata'] = $this->laboratory_model->viewLaboratory();
		if(array_key_exists('submit',$_POST))
		{			
			
		}
		else
		{
			$this->load->view('laboratory/view',$data);
				
		}
	}
			
	public function create()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {           
           redirect('c=auth&m=login');
        }
        
        //print_r($this->session->userdata('nabl_user'));
        $this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Add Laboratory';
		
		$data['city'] = $this->laboratory_model->get_city();
		$data['state'] = $this->laboratory_model->get_states();
		$data['zone'] = $this->laboratory_model->get_zone();
		$data['country'] = $this->laboratory_model->get_country();
		//$this->form_validation->set_rules('labo_regis_code', 'Laboratory Registration Code', 'required');
		//$this->form_validation->set_rules('labo_name', 'Laboratory Name', 'required');
		if(array_key_exists('submit',$_POST)) //($this->form_validation->run() === FALSE)
		{
			$msg = array();
			$msg=$this->laboratory_model->set_laboratory();
			$this->load->helper('url');
			
			if(isset($msg['duplicate']) && $msg['duplicate']=="duplicate")
			{
				?>
					<script>alert('Laboratory Already Exists');	
					location = "<?php echo $_SERVER['PHP_SELF'];?>?c=laboratory&m=create";				
					</script>
				<?php	
			}
			
			if(isset($msg['success']) && $msg['success']=="success")
			{
				?>
					<script>alert('Laboratory Added');
					location = "<?php echo $_SERVER['PHP_SELF'];?>?c=laboratory&m=index";
					</script>
				<?php	
			}
			if(isset($msg['unsuccess']) && $msg['unsuccess']=="unsuccess")
			{
				?>
					<script>alert('Unable To Add Laboratory');
					location = "<?php echo $_SERVER['PHP_SELF'];?>?c=laboratory&m=create";
					</script>
				<?php
			}			
		}
		else
		{			
			$this->load->helper('url');		
			$this->load->view('templates/header', $data);			
			$this->load->view('laboratory/create');
			$this->load->view('templates/footer');
		}
	}
			
	public function editlaboratory()
	{	
		$this->load->helper('url');	
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
           //$this->load->helper('url');
           redirect('c=auth&m=login');
        }	
        $this->load->helper('form');
		$this->load->library('form_validation');
		
		$data['title'] = 'Edit Laboratory';
		$data['labs'] = $this->laboratory_model->get_laboratory_details($_GET['id']);
				
		$data['city'] = $this->laboratory_model->get_city();
		$data['state'] = $this->laboratory_model->get_states();
		$data['zone'] = $this->laboratory_model->get_zone();	
		$data['country'] = $this->laboratory_model->get_country();	
		//$this->form_validation->set_rules('labo_regis_code', 'Laboratory Registration Code', 'required');
		//$this->form_validation->set_rules('labo_name', 'Laboratory Name', 'required');		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->laboratory_model->update_laboratory($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Laboratory Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=laboratory&m=index";
			</script>
			<?php	
		}
		else
		{
			$this->load->helper('url');	
			$this->load->view('templates/header', $data);					
			$this->load->view('laboratory/editlaboratory');
			$this->load->view('templates/footer');		
		}
	}
			
	public function deletelaboratory()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
           //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        //$this->load->helper('url');
        $this->load->helper('url');
				$data['title'] = 'Delete Laboratory';
				$this->load->helper('form');
				$this->load->library('form_validation');
		
					$this->load->view('templates/header', $data);
					$this->load->view('laboratory/index');
					$this->load->view('templates/footer');
		
				$data['title'] = 'Delete Laboratory';
				$data['labs'] = $this->laboratory_model->get_laboratory_details($_GET['id']);		
		
		
					$this->laboratory_model->delete_laboratory($_GET['id']);
					$this->load->helper('url');
				?>
					<script>alert('Laboratory Deleted');
					location = "<?php echo $_SERVER['PHP_SELF'];?>?c=laboratory";
					</script>
				<?php	
		
	}
	
	public function updateLabStatus()
	{
		$this->load->helper('url');
		$this->load->library('session');
		if(!$this->session->userdata('nabl_user'))
		{
			redirect('c=auth&m=login');
		}
		$labstatus = $_GET['status'];
		$labid = $_GET['labid'];		
		$this->load->model('laboratory_model');	
		if($this->laboratory_model->update_status_laboratory($labstatus, $labid))
		{
			?>
			<script language="javascript">
			alert('Status Updated Successfully');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=laboratory";
			</script>
			<?php 
		}
		else
		{
			?>
			<script language="javascript">
			alert('Unable To Update Status');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=laboratory";
			</script>
			<?php
		}		
	}
	
	public function search()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {           
           redirect('c=auth&m=login');
        }    
        
        $this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Search Laboratory';
		
		if(array_key_exists('submit',$_POST)) //($this->form_validation->run() === FALSE)
		{
			$data['labdata'] = $this->laboratory_model->search_lab();
			$this->load->helper('url');		
			$this->load->view('templates/header', $data);			
			$this->load->view('laboratory/index');
			$this->load->view('templates/footer');
			
		}
		else
		{			
			$this->load->helper('url');		
			$this->load->view('templates/header', $data);			
			$this->load->view('laboratory/search');
			$this->load->view('templates/footer');
		}
	}

}