<?php
class cliptype extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('cliptype_model');
	}

	public function index()
	{
		
		$this->load->helper('url');
		$data['title'] = "Clip Type";
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
             // $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        //print_r($this->session->userdata('nabl_user'));		
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=cliptype&m=index';
	    $config['total_rows'] = $this->db->count_all('clip_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('cliptype_model');
	    $data['cliptype'] = $this->cliptype_model->get_all_clipTypes($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('cliptype/index', $data);
		$this->load->view('templates/footer');		
		
		
	}

	public function view($slug)
	{
			
	}

	public function create()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Add a Clip Type';
		$this->form_validation->set_rules('clip_name', 'Please Enter Clip Name', 'required');		

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->cliptype_model->set_cliptype();
			$this->load->helper('url');
			?>
			<script>alert('Clip Type Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=cliptype";
			</script>
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('cliptype/create');
			$this->load->view('templates/footer');
		}
	}

	public function edit_clip_type()
	{
        
		$this->load->helper('url');
        $this->load->library('session');          
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Edit - Zone';
		$data['cliptype'] = $this->cliptype_model->get_cliptype($_GET['id']);
		$this->form_validation->set_rules('clip_name', 'Please Enter Clip Name', 'required');

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->cliptype_model->update_cliptype($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Clip Type Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=cliptype";
			</script>
			<?php			
		}
		else
		{
            $this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('cliptype/edit_clip_type');
			$this->load->view('templates/footer');			
		}
	}

	public function delete_clip_type()
	{
        $this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$data['title'] = 'Delete Clip Type';
		$this->load->helper('form');
		$this->load->library('form_validation');		
		$data['title'] = 'Clip Type Deleted';		
		$this->cliptype_model->delete_cliptype($_GET['id']);
		//$this->load->helper('url');
		?>
			<script>alert('Clip Type Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=cliptype";
			</script>
		<?php
	}
}