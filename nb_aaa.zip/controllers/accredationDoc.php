<?php  
//error_reporting(1);
class accredationDoc extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('accredationdoc_model');
	}	
	public function index()
	{
		$this->load->helper('url');
		$data['title'] = 'Accredation Document';
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){              
           redirect('c=auth&m=login');
        }
        		
	    $this->load->library('pagination');
	    $data['pagination']="yes";    
	    $config['base_url'] = base_url().'index.php?c=accredationDoc&m=index';
	    $config['total_rows'] = count($this->accredationdoc_model->get_accre_doc_by_doctype());
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('accredationdoc_model');
	    $data['news'] = $this->accredationdoc_model->get_lab_all_accredatationDoc($config['per_page']);
	    
	    $this->load->view('templates/header', $data);
		$this->load->view('accredationDoc/index', $data);
		$this->load->view('templates/footer');		
		
	}
	

	public function view($slug)
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$data['news_item'] = $this->accredationdoc_model->get_accre_doc($slug);
		if (empty($data['news_item']))
		{
			show_404();
		}
		$data['title'] = $data['news_item']['title'];
		$this->load->view('templates/header', $data);		
		$this->load->view('accredationDoc/view', $data);
		$this->load->view('templates/footer');
	}

	public function create()
	{	
		$this->load->helper('url');	
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }       
		//$this->load->helper('form');
		$this->load->library('form_validation');		
		$data['docType'] = $this->accredationdoc_model->get_doc_type();				
		$data['title'] = 'Add Document';		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$docFileName = "";
			if(isset($_FILES['userfile']['tmp_name']) && $_FILES['userfile']['tmp_name']!="")
			{
	            include './application/controllers/Upload.php';	
				$uploadObj = new Upload(); 				                     
	            $data['docInfo'] = $uploadObj->do_upload("userfile"); 
	            $docFileName = $data['docInfo']['name'];
			}
            $this->load->model('accredationdoc_model'); 
            $this->accredationdoc_model->set_accre_doc($docFileName);
			$this->load->helper('url');
			?>
			<script>alert('Document Added Successfully ');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=accredationDoc";
			</script>
			<?php
		}
		else
		{          	
			$this->load->helper('url');
			$this->load->view('templates/header', $data);			
			$this->load->view('accredationDoc/create');
			$this->load->view('templates/footer');	
		}
	}	
	
	public function editaccrdoc()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Edit Document';
		
		$data['docType'] = $this->accredationdoc_model->get_doc_type();
		$data['news'] = $this->accredationdoc_model->get_accre_doc($_GET['id']);		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{    
			$docFileName = "";        	
			if(isset($_FILES['userfile']['tmp_name']) && $_FILES['userfile']['tmp_name']!="")
			{				
				include './application/controllers/Upload.php';
				$uploadObj = new Upload();                 
            	$data['docInfo1'] = $uploadObj->do_upload("userfile");
                 //var_dump($uploadObj->upload->display_errors());
            	$docFileName = $data['docInfo1']['name'];
			}
			$this->load->model('accredationdoc_model');
                       //var_dump($docFileName); die;
			$this->accredationdoc_model->update_accre_doc($_GET['id'],$docFileName);
			$this->load->helper('url');
			?>
			<script>alert('Document Updated Successfully');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=accredationDoc";
			</script>
			<?php
		}
		else
		{			
			$this->load->helper('url');
			$this->load->view('templates/header', $data);			
			$this->load->view('accredationDoc/editaccrdoc');
			$this->load->view('templates/footer');
		}
	}
	
	public function deleteaccrdoc()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$data['title'] = 'Delete Document';
		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->load->view('templates/header', $data);
		$this->load->view('accredationDoc/index');
		$this->load->view('templates/footer');	
		
		$this->accredationdoc_model->delete_accre_doc($_GET['id']);
		//$this->load->helper('url');
		?>
		<script>alert('Document Deleted Successfully');
		location = "<?php echo $_SERVER['PHP_SELF'];?>?c=accredationDoc";
		</script>
		<?php
	}
	
	public function updateStatus()
	{
		$this->load->helper('url');
		$this->load->library('session');
		if(!$this->session->userdata('nabl_user'))
		{
			redirect('c=auth&m=login');
		}
		$status = $_GET['status'];
		$id = $_GET['id'];		
		$this->load->model('accredationdoc_model');
		if($this->accredationdoc_model->update_status($status, $id))
		{
			?>
			<script language="javascript">
			alert('Status Updated Successfully');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=accredationDoc";
			</script>
			<?php 
		}
		else
		{
			?>
			<script language="javascript">
			alert('Unable To Update Status');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=accredationDoc";
			</script>
			<?php
		}		
	}	

}





