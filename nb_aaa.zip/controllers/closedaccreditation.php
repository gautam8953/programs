<?php ini_set('memory_limit', '-1');
class closedaccreditation extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('closed_accreditation_model');
	}
	
	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Closed Accreditation";
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){             
           redirect('c=auth&m=login');
        }
        
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=closedaccreditation&m=index';
	    $config['total_rows'] = $this->db->count_all('closed_accreditation_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('closed_accreditation_model');
	    $data['laccua'] = $this->closed_accreditation_model->get_all_closedAccreditation($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('closedaccreditation/index', $data);
		$this->load->view('templates/footer');
	}
	
	public function create()
	{		
		$this->load->helper('url');		
		$this->load->library('session');           
        if(!$this->session->userdata('nabl_user'))
        { 
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');		
		$this->load->library('dropdown');
		$data['title'] = "Add Closed Accreditation";		
		$data['lab_names'] = $this->dropdown->labsdropdown('lab_id','lab_id','','','');
		$data['certificate_no'] = $this->dropdown->certificatedropdown('cno','cno','','','');
		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->closed_accreditation_model->setclosedAccreditation();
			$this->load->helper('url');
			?>
			<script>alert('Record Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=closedaccreditation";
			</script>
			<?php
		}
		else
		{
			//echo "Else Block";
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('closedaccreditation/create');
			$this->load->view('templates/footer');
		}	
		
	}
	
	public function edit()
	{
				
		$this->load->helper('url');
		$this->load->library('session');
        if(!$this->session->userdata('nabl_user'))
        { 
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');		
		$this->load->library('dropdown');
		$data['title'] = "Edit Closed Accreditation";
		$data['lacua'] = $this->closed_accreditation_model->get_closedAccreditation($_GET['id']);
		$data['lab_names'] = $this->dropdown->labsdropdown('lab_id','lab_id','','',$data['lacua']['lab_id']);
		$data['certificate_no'] = $this->dropdown->certificatedropdown('cno','cno','','',$data['lacua']['certificate_id']);
		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->closed_accreditation_model->updateclosedAccreditation($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Record Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=closedaccreditation";
			</script>
			<?php
		}
		else
		{
			//echo "Else Block";
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('closedaccreditation/edit');
			$this->load->view('templates/footer');
		}	
	
	}
	
	public function delete()
	{
		
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {              
           redirect('c=auth&m=login');
        }		
		$this->load->helper('form');
		//$this->load->library('form_validation');
		$data['title'] = 'Delete - Closed Accreditation ';
		$this->closed_accreditation_model->deleteclosedAccreditation($_GET['id']);
		$this->load->helper('url');
		?>
			<script>alert('Record Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=closedaccreditation";
			</script>
		<?php	
	}
}