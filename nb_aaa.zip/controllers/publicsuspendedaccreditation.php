<?php
class publicsuspendedaccreditation extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('suspended_accreditation_model');
	}
	
	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Suspended Accreditation";
			/*
	        $this->load->library('session');              
	        if(!$this->session->userdata('nabl_user'))
	        {             
	           redirect('c=auth&m=login');
	        }
	        */
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=publicsuspendedaccreditation&m=index';
	    $config['total_rows'] = $this->db->count_all('suspended_accreditation_tbl');
	    $config['per_page'] = '20';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';
	    $this->pagination->initialize($config);
	    $this->load->model('suspended_accreditation_model');
	    $data['laccua'] = $this->suspended_accreditation_model->get_all_suspendedAccreditation($config['per_page']);
	    //$this->load->view('templates/header', $data);
		$this->load->view('publicsuspendedaccreditation/index', $data);
		//$this->load->view('templates/footer');
	}	
}