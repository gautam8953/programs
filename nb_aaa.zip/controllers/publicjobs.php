<?php
class publicjobs extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('jobs_model');
	}

	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Careers";		
			/*
			$this->load->library('session');              
	        if(!$this->session->userdata('nabl_user'))
	        {
	           //$this->load->helper('url');
	           redirect('c=auth&m=login');
	        }
	        */	
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=publicjobs&m=index';
	    $config['total_rows'] = $this->db->count_all('job_tbl');
	    $config['per_page'] = '20';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('jobs_model');
	    $config['total_rows'] = $this->jobs_model->count_all_records();
	    $data['jobs'] = $this->jobs_model->get_all_active_jobsPostings($config['per_page']);
	    //$this->load->view('templates/header', $data);
		$this->load->view('publicjobs/index', $data);
		//$this->load->view('templates/footer');		
	}
	
	public function view()
	{
		
		$this->load->helper('url');
		$jobId = $_GET['jobid'];
		$this->load->model('jobs_model');
		$data['news'] = $this->jobs_model->get_jobs($jobId);
		$this->load->view('publicjobs/view',$data);
	
	}
	public function viewJob()
	{
		
		$this->load->helper('url');
		$data['title'] = "Careers";		
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=publicjobs&m=index';
	    $config['total_rows'] = $this->db->count_all('job_tbl');
	    $config['per_page'] = '20';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    //$this->pagination->initialize($config);
	    //$this->load->model('jobs_model');
	    //$config['total_rows'] = $this->jobs_model->count_all_records();
	    //$data['jobs'] = $this->jobs_model->get_all_active_jobsPostings($config['per_page']);
	    //$this->load->view('templates/header', $data);
		$this->load->view('publicjobs/Job-View', $data);
		//$this->load->view('templates/footer');
	
	}
}