<?php
class Search extends CI_Controller 
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('search_model');
	}
	
	public function index()
	{	
		$this->load->helper('url');
        $this->load->library('dropdown');//$dropDownObj = new dropdown();
		$this->load->helper('form');		
		$data['title'] = 'Laboratory Search';	
		$data['state'] = $this->dropdown->stateDropDwon('state', 'state',  'getCityList(this.value)', '','');
	    $data['city'] = $this->dropdown->cityDropDwon('city', 'city',  '', '','');
		$data['zone'] = $this->dropdown->zoneDropDwon('zone', 'zone',  '', '','');
		$data['natureoflab'] = $this->dropdown->natureoflabDropDwon('natureoflab', 'natureoflab',  '', '','');
		$data['operationat'] = $this->dropdown->operationAtDropDwon('operationat[]', 'operationat',  '', '','');	
		$data['facilitydropdown'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id',  'getFieldListPro(this.value)', '','');	
        //$this->load->library('session');
		//$data['facilitydropdown'] = $this->dropdown->facilityDropDwon('facility_id', 'facility_id',  'getFieldList(this.value)', '');
		$this->load->model('search_model');
		if(array_key_exists('submit',$_POST) || isset($_GET['per_page']))//if ($this->form_validation->run() === FALSE)
		{	
			$data['pagination']="yes";
			$data['rows'] = $this->search_model->search();
			$this->load->helper('url');
		    $this->load->library('pagination');
		    $config['base_url'] = base_url().'index.php?c=search&m=index';
		    $config['total_rows'] = count($data['rows']);
		    $config['per_page'] = '10';
		    $config['full_tag_open'] = '<p>';	
		    $config['full_tag_close'] = '</p>';	
		    $this->pagination->initialize($config);
		    
		    $data['labdata'] = $this->search_model->search($config['per_page']);
		    $this->load->library('session');
			$data['searchFormData'] = $this->session->userdata;
			$postedData = $data['searchFormData'];	
			//print_r($postedData);
			$data['state'] = $this->dropdown->stateDropDwon('state', 'state',  'getCityList(this.value)', '',$postedData['state1']);
			$data['city'] = $this->dropdown->cityDropDwon('city', 'city',  '', '',$postedData['city1']);
			$data['zone'] = $this->dropdown->zoneDropDwon('zone', 'zone',  '', '',$postedData['zone1']);
			$data['natureoflab'] = $this->dropdown->natureoflabDropDwon('natureoflab', 'natureoflab',  '', '', $postedData['nature_of_lab1']);
			$data['operationat'] = $this->dropdown->operationAtDropDwon('operationat[]', 'operationat',  '', '',$postedData['operationAtstr1']);	
			$data['facilitydropdown'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id',  'getFieldListPro(this.value)', '',$postedData['facility_id1']);
			$data['fielddropdown'] = "";
			$data['groupdropdown'] = "";
			$data['subgroupdropdown'] = "";
			if($postedData['facility_id1']!='-1')
			{				
				$data['fielddropdown'] = $this->dropdown->fieldDropDownByIdPro('field_id[]', 'field_id', 'bindDiscipline()', '',$postedData['field_id1'],$postedData['facility_id1']);
			}
			if($postedData['field_id1']!='-1')
			{				
				$data['groupdropdown'] = $this->dropdown->groupDropDownByIdPro('group_id', 'group_id', 'getsubgroupList(this.value)', '',$postedData['group_id1'],$postedData['field_id1']);
			}
			
			if($postedData['group_id1']!='-1')
			{				
			$data['subgroupdropdown'] = $this->dropdown->subgroupDropDownByIdForSearch('subgroup[]', 'subgroup_id', '', '',$postedData['subgroup_id1'],$postedData['group_id1']);
			}
			
			//Labs data export using enter search keyword
			$data['allrows'] = $this->search_model->search($config['total_rows']);
			
			if(isset($_POST['export-excel']))
			{    
				ob_clean();
				$srno = 1;
				$export_file_name = "laboratory-search-report-".date("d-m-Y").".xls";		 
				header("Content-Type: application/vnd.ms-excel");
				header("Content-Disposition: attachment; filename=\"$export_file_name\"");
				$headers = array("Sr. No.","Lab Name","Address ","Tel No","Fax No","Email ","Contact Person");
				echo implode("\t", $headers) . "\n";
				foreach($data['allrows'] as $rec_obj)
				{
					if(strpos($rec_obj['lab_name'], '<br/>') !== false) {
						$lab_name = str_replace('<br/>','',$rec_obj['lab_name']);
						$lab_name = "\"" . eregi_replace("\"", "\"\"", $lab_name) . "\"";
					}else{
						$lab_name = $rec_obj['lab_name'];
						$lab_name = "\"" . eregi_replace("\"", "\"\"", $lab_name) . "\"";
					}
					if(!empty($rec_obj['cityName'])){
						$cityName = ','. $rec_obj['cityName'];
					}
					if(!empty($rec_obj['pincode'])){
						$pincode = '-'. $rec_obj['pincode'];
					}
					if(!empty($rec_obj['stateName'])){
						$stateName = ','. $rec_obj['stateName'];
					}
					if(!empty($rec_obj['countryName'])){
						$countryName = ','. $rec_obj['countryName'];
					}
					$lab_address = $rec_obj['lab_address'].$cityName.$pincode.$stateName.$countryName;
					if(strpos($lab_address, '<br/>') !== false) {
						$lab_address = $lab_address;
						$lab_address = str_replace('<BR/>','',$lab_address);
						$lab_address = str_replace('< BR/>','',$lab_address);
						$lab_address = str_replace('<Br/>','',$lab_address);
						$lab_address = str_replace('</Br>','',$lab_address);
						$lab_address = str_replace('</br>','',$lab_address);
						$lab_address = str_replace('<br/>','',$lab_address);
						$lab_address = "\"" . eregi_replace("\"", "\"\"", $lab_address) . "\"";
						$lab_address = html_entity_decode(htmlentities($lab_address, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$lab_address = str_replace('&rsquo;','`',$lab_address);
						$lab_address = str_replace('&ndash;','-',$lab_address);
					}else{
						$lab_address = $lab_address;
						$lab_address = str_replace('<BR/>','',$lab_address);
						$lab_address = str_replace('< BR/>','',$lab_address);
						$lab_address = str_replace('<Br/>','',$lab_address);
						$lab_address = str_replace('</Br>','',$lab_address);
						$lab_address = str_replace('</br>','',$lab_address);
						$lab_address = str_replace('<br/>','',$lab_address);
						$lab_address = "\"" . eregi_replace("\"", "\"\"", $lab_address) . "\"";
						$lab_address = html_entity_decode(htmlentities($lab_address, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$lab_address = str_replace('&rsquo;','`',$lab_address);
						$lab_address = str_replace('&ndash;','-',$lab_address);
					}
					
					if(strpos($rec_obj['phone'], ',') !== false) {
						$phone = str_replace('â€“','-',$rec_obj['phone']);
						$phone = "\"" . eregi_replace("\"", "\"\"",  $phone) . "\"";
						$phone = html_entity_decode(htmlentities($phone, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$phone = str_replace('&ndash;','-',$phone);
					}else{
						$phone = $rec_obj['phone'];
						$phone = "\"" . eregi_replace("\"", "\"\"",  $phone) . "\"";
						$phone = html_entity_decode(htmlentities($phone, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$phone = str_replace('&ndash;','-',$phone);
					}
					
					if(strpos($rec_obj['fax'], ',') !== false) {
						$fax = str_replace('â€“','-',$rec_obj['fax']);
						$fax = "\"" . eregi_replace("\"", "\"\"",  $fax) . "\"";
						$fax = html_entity_decode(htmlentities($fax, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$fax = str_replace('&ndash;','-',$fax);
					}else{
						$fax = $rec_obj['fax'];
						$fax = "\"" . eregi_replace("\"", "\"\"",  $fax) . "\"";
						$fax = html_entity_decode(htmlentities($fax, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$fax = str_replace('&ndash;','-',$fax);
					}
					
					if(strpos($rec_obj['emailid'], ',') !== false) {
						$emailid = str_replace(',',',',$rec_obj['emailid']);
						$emailid = "\"" . eregi_replace("\"", "\"\"",  $emailid) . "\"";
					}else{
						$emailid = $rec_obj['emailid'];
						$emailid = "\"" . eregi_replace("\"", "\"\"",  $emailid) . "\"";
					}
					
					if(strpos($rec_obj['contact_person'], '<BR/>') !== false) {
						$contact_person = str_replace('<BR/>','',$rec_obj['contact_person']);
						$contact_person = "\"" . eregi_replace("\"", "\"\"",  $contact_person) . "\"";
						$contact_person = html_entity_decode(htmlentities($contact_person, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$contact_person = str_replace('&ndash;','-',$contact_person);
					}else{
						$contact_person = $rec_obj['contact_person'];
						$contact_person = "\"" . eregi_replace("\"", "\"\"",  $contact_person) . "\"";
						$contact_person = html_entity_decode(htmlentities($contact_person, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$contact_person = str_replace('&ndash;','-',$contact_person);
					}
					
					echo implode("\t",array("$srno","$lab_name","$lab_address","$phone","$fax","$emailid","$contact_person"))."\n";
					$srno++;
				}
				exit;
			}
		
		   	$this->load->view('search/index', $data);
		}
		else
		{   
	        //All labs data export without enter any keyword
	        $data['allrows'] = $this->search_model->search();
			if(isset($_POST['export-excel']))
			{    
				ob_clean();
				$srno = 1;
				$export_file_name = "laboratory-search-report-".date("d-m-Y").".xls";		 
				header("Content-Type: application/vnd.ms-excel");
				header("Content-Disposition: attachment; filename=\"$export_file_name\"");
				$headers = array("Sr. No.","Lab Name","Address ","Tel No","Fax No","Email ","Contact Person");
				echo implode("\t", $headers) . "\n";
				foreach($data['allrows'] as $rec_obj)
				{
					if(strpos($rec_obj['lab_name'], '<br/>') !== false) {
						$lab_name = str_replace('<br/>','',$rec_obj['lab_name']);
						$lab_name = "\"" . eregi_replace("\"", "\"\"", $lab_name) . "\"";
					}else{
						$lab_name = $rec_obj['lab_name'];
						$lab_name = "\"" . eregi_replace("\"", "\"\"", $lab_name) . "\"";
					}
					if(!empty($rec_obj['cityName'])){
						$cityName = ','. $rec_obj['cityName'];
					}
					if(!empty($rec_obj['pincode'])){
						$pincode = '-'. $rec_obj['pincode'];
					}
					if(!empty($rec_obj['stateName'])){
						$stateName = ','. $rec_obj['stateName'];
					}
					if(!empty($rec_obj['countryName'])){
						$countryName = ','. $rec_obj['countryName'];
					}
					$lab_address = $rec_obj['lab_address'].$cityName.$pincode.$stateName.$countryName;
					if(strpos($lab_address, '<br/>') !== false) {
						$lab_address = $lab_address;
						$lab_address = str_replace('<BR/>','',$lab_address);
						$lab_address = str_replace('< BR/>','',$lab_address);
						$lab_address = str_replace('<Br/>','',$lab_address);
						$lab_address = str_replace('</Br>','',$lab_address);
						$lab_address = str_replace('</br>','',$lab_address);
						$lab_address = str_replace('<br/>','',$lab_address);
						$lab_address = "\"" . eregi_replace("\"", "\"\"", $lab_address) . "\"";
						$lab_address = html_entity_decode(htmlentities($lab_address, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$lab_address = str_replace('&rsquo;','`',$lab_address);
						$lab_address = str_replace('&ndash;','-',$lab_address);
					}else{
						$lab_address = $lab_address;
						$lab_address = str_replace('<BR/>','',$lab_address);
						$lab_address = str_replace('< BR/>','',$lab_address);
						$lab_address = str_replace('<Br/>','',$lab_address);
						$lab_address = str_replace('</Br>','',$lab_address);
						$lab_address = str_replace('</br>','',$lab_address);
						$lab_address = str_replace('<br/>','',$lab_address);
						$lab_address = "\"" . eregi_replace("\"", "\"\"", $lab_address) . "\"";
						$lab_address = html_entity_decode(htmlentities($lab_address, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$lab_address = str_replace('&rsquo;','`',$lab_address);
						$lab_address = str_replace('&ndash;','-',$lab_address);
					}
					
					if(strpos($rec_obj['phone'], ',') !== false) {
						$phone = str_replace('â€“','-',$rec_obj['phone']);
						$phone = "\"" . eregi_replace("\"", "\"\"",  $phone) . "\"";
						$phone = html_entity_decode(htmlentities($phone, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$phone = str_replace('&ndash;','-',$phone);
					}else{
						$phone = $rec_obj['phone'];
						$phone = "\"" . eregi_replace("\"", "\"\"",  $phone) . "\"";
						$phone = html_entity_decode(htmlentities($phone, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$phone = str_replace('&ndash;','-',$phone);
					}
					
					if(strpos($rec_obj['fax'], ',') !== false) {
						$fax = str_replace('â€“','-',$rec_obj['fax']);
						$fax = "\"" . eregi_replace("\"", "\"\"",  $fax) . "\"";
						$fax = html_entity_decode(htmlentities($fax, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$fax = str_replace('&ndash;','-',$fax);
					}else{
						$fax = $rec_obj['fax'];
						$fax = "\"" . eregi_replace("\"", "\"\"",  $fax) . "\"";
						$fax = html_entity_decode(htmlentities($fax, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$fax = str_replace('&ndash;','-',$fax);
					}
					
					if(strpos($rec_obj['emailid'], ',') !== false) {
						$emailid = str_replace(',',',',$rec_obj['emailid']);
						$emailid = "\"" . eregi_replace("\"", "\"\"",  $emailid) . "\"";
					}else{
						$emailid = $rec_obj['emailid'];
						$emailid = "\"" . eregi_replace("\"", "\"\"",  $emailid) . "\"";
					}
					
					if(strpos($rec_obj['contact_person'], '<BR/>') !== false) {
						$contact_person = str_replace('<BR/>','',$rec_obj['contact_person']);
						$contact_person = "\"" . eregi_replace("\"", "\"\"",  $contact_person) . "\"";
						$contact_person = html_entity_decode(htmlentities($contact_person, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$contact_person = str_replace('&ndash;','-',$contact_person);
					}else{
						$contact_person = $rec_obj['contact_person'];
						$contact_person = "\"" . eregi_replace("\"", "\"\"",  $contact_person) . "\"";
						$contact_person = html_entity_decode(htmlentities($contact_person, ENT_QUOTES, 'UTF-8'), ENT_QUOTES , 'ISO-8859-15');
						$contact_person = str_replace('&ndash;','-',$contact_person);
					}
					
					
					echo implode("\t",array("$srno","$lab_name","$lab_address","$phone","$fax","$emailid","$contact_person"))."\n";
					$srno++;
				}
				exit;
			}
			$this->load->view('search/index',$data);
		}	
	}			
	public function view($slug)
	{
		
	}
			
	public function searchlabcertificate()
	{
		//$this->load->helper('showgroupsubgroup');
		//$data['Search'] = $this;
		$this->load->helper('form');
		$this->load->helper('url');		
		$ggroupsubgroupsarr = array();
                 //comment by nishant on 28-05-2013
		//$data['certificatedata'] = $this->search_model->searchcertificate();
                //--end
                $data['certificatedata'] = $this->search_model->searchcertificateresult();

		if($data['certificatedata']>0)
		{
			for($x=0;$x<count($data['certificatedata']);$x++)
			{
				$ggroupsubgroupsarr[$x] = $this->search_model->viewGroupSubGroupPro($data['certificatedata'][$x]['certificate_id']);
			}				
			//print_r($data['gnsdata']);
			//die();
		}
		$data['gnsdata'] = $ggroupsubgroupsarr;
		//print_r($data['gnsdata']);
		//die();
				
		if(array_key_exists('submit',$_POST))//if ($this->form_validation->run() === FALSE)
		{			
			
		}
		else
		{
			$this->load->view('search/searchlabcertificate',$data);
			//$this->load->view('templates/footer');			
		}		
	}
	
	public function showGroupSubGroup()
	{
		/*
		$this->load->helper('test');
		$this->load->helper('form');
		$this->load->helper('url');
		$data['gnsdata']=$this->search_model->viewGroupSubGroup();
		$this->load->view('search/showGroupSubGroup',$data);
		*/
		
	}
}