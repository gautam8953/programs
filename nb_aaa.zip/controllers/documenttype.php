<?php
class documenttype extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('doctype_model');
	}

	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Document Type";
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=documenttype&m=index';
	    $config['total_rows'] = $this->db->count_all('document_type_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('doctype_model');
	    $data['doctype'] = $this->doctype_model->get_all_documentType($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('documenttype/index', $data);
		$this->load->view('templates/footer');		
	}

	public function view($slug)
	{
			
	}

	public function create()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Create a Document Type';
		$this->form_validation->set_rules('document_type_name', 'Please Enter Document Name', 'required');		

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->doctype_model->set_doctype();
			$this->load->helper('url');
			?>
			<script>alert('Document Type Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=documenttype";
			</script>
			<?php			
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('documenttype/create');
			$this->load->view('templates/footer');
		}
	}

	public function edit_document_type()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Edit - Zone';
		$data['doctype'] = $this->doctype_model->get_doctype($_GET['id']);

		//$this->form_validation->set_rules('document_type_name', 'Please Enter Document Name', 'required');

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->load->library('session');              
            if(!$this->session->userdata('nabl_user')){
                  $this->load->helper('url');
               redirect('c=auth&m=login');
            }
			$this->doctype_model->update_doctype($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Document Type Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=documenttype";
			</script>
			<?php
		}
		else
		{
            $this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('documenttype/edit_document_type');
			$this->load->view('templates/footer');
		}
	}

	public function delete_document_type()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        
		$data['title'] = 'Delete Document Type';
		$this->load->helper('form');
		$this->load->library('form_validation');		
		$data['title'] = 'Document Type Deleted';		
		$this->doctype_model->delete_doctype($_GET['id']);
		$this->load->helper('url');
		?>
			<script>alert('Document Type Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=documenttype";
			</script>
		<?php
	}
}