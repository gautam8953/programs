<?php
include './application/libraries/dropdown.php';
class Subgroup extends CI_Controller {

    public function __construct()  {        
        
        parent::__construct();
        $this->load->model('subgroup_model');
       // $this->load->library('session'); 
    }

    public function index()
    {
    	$data['title'] = "Sub Groups";
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        
        $this->load->helper('url');
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=subgroup&m=index';
	    $config['total_rows'] = $this->db->count_all('sub_group_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('subgroup_model');
	    $data['news'] = $this->subgroup_model->get_all_subgroups($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('subgroup/index', $data);
		$this->load->view('templates/footer');
        
    }

    public function view($slug)
    {
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $data['news_item'] = $this->subgroup_model->get_lab_subgroup($slug);

        if (empty($data['news_item']))
        {
            show_404();
        }

        $data['title'] = $data['news_item']['subgroup_name'];

        $this->load->view('templates/header', $data);
        $this->load->view('subgroup/view', $data);
        $this->load->view('templates/footer');
    }

    public function create()
    {
       
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $dropDownObj = new dropdown();
        $this->load->helper('form');
        $this->load->library('form_validation');

        $data['title'] = 'Create a Lab subgroup';
        $data['groupdropdown'] = $dropDownObj->groupDropDwon('group_id', 'group_id',  '', '');        

        $this->form_validation->set_rules('group_id', 'subgroup Name', 'required');
        $this->form_validation->set_rules('subgroup_name', 'subgroup Name', 'required');
        $this->form_validation->set_rules('subgroup_description', 'Description', 'required');

        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('templates/header', $data);
            $this->load->view('subgroup/create');
            $this->load->view('templates/footer');

        }
        else
        {
            $this->subgroup_model->set_subgroup();
            $this->load->helper('url');
            ?>
            <script>alert('Subgroup Added');
            location = "<?php echo $_SERVER['PHP_SELF'];?>?c=subgroup";
            </script>
            <?php

        }
    }

    public function editsubgroup()
    {
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $this->load->library('dropdown');
        
        //$dropDownObj = new dropdown();
        $this->load->helper('form');
        $this->load->library('form_validation');

        $data['title'] = 'Edit - Lab subgroup';
        $data['subgroup'] = $this->subgroup_model->get_lab_subgroup($_GET['id']);
        //echo  $data['subgroup']['id'];
        
        $data['groupdropdown'] = $this->dropdown->groupDropDwon('group_id', 'group_id',  '', '', $data['subgroup']['group_id']);
        
        $this->form_validation->set_rules('subgroup_name', 'subgroup Name', 'required');
        $this->form_validation->set_rules('subgroup_description', 'text', 'required');

        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('templates/header', $data);
            $this->load->view('subgroup/editsubgroup');
            $this->load->view('templates/footer');

        }
        else
        {
            $this->subgroup_model->update_subgroup($_GET['id']);
            $this->load->helper('url');
            ?>
            <script>alert('subgroup Updated');
            location = "<?php echo $_SERVER['PHP_SELF'];?>?c=subgroup";
            </script>
            <?php

        }
    }

    public function deletesubgroup()
    {
        
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        
		$this->load->helper('url');
        $data['title'] = 'Delete Lab subgroup';
        $this->load->helper('form');
        $this->load->library('form_validation');

            $this->load->view('templates/header', $data);
            $this->load->view('subgroup/index');
            $this->load->view('templates/footer');

        $data['title'] = 'Delete Lab Category';
        $data['subgroup'] = $this->subgroup_model->get_lab_subgroup($_GET['id']);



            $this->subgroup_model->delete_subgroup($_GET['id']);
            $this->load->helper('url');
            ?>
            <script>alert('subgroup Deleted');
            location = "<?php echo $_SERVER['PHP_SELF'];?>?c=subgroup";
            </script>
            <?php


    }

}