<?php
class News extends CI_Controller {

	public function __construct()
	{
		parent::__construct();		
		$this->load->model('news_model');
	}

	public function index()
	{
		$data['title'] = "News/Announcements";
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }        
		$this->load->helper('url');
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    
	    if(isset($_GET['clipType']) && $_GET['clipType']!="")
	    {
	    	$clipType = $_GET['clipType'];
	    }
	    else 
	    {
	    	$clipType = "both";
	    }
	    	    
	    $config['base_url'] = base_url().'index.php?c=news&m=index&clipType='.$clipType;
	    $config['total_rows'] = $this->db->count_all('jos_clip_details_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('news_model');
	    $data['news'] = $this->news_model->get_lab_all_news_announcement($config['per_page'], $clipType);
	    $this->load->view('templates/header', $data);
		$this->load->view('news/index', $data);
		$this->load->view('templates/footer');	
		
	}

	public function view($slug)
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $data['news_item'] = $this->news_model->get_news($slug);
		if (empty($data['news_item']))
		{
			show_404();
		}
		$data['title'] = $data['news_item']['title'];
		$this->load->view('templates/header', $data);
		$this->load->view('news/view', $data);
		$this->load->view('templates/footer');
	}

	public function create()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('form');
		$this->load->library('form_validation');		
		//$data['options'] = $this->news_model->get_clip_dropdown();
				
		$data['title'] = 'Add News / Announcement';
		//$this->form_validation->set_rules('clip_type', 'Please Select Clip Type', 'required');
		//$this->form_validation->set_rules('headline', 'Please Enter Headline', 'required');
		//$this->form_validation->set_rules('clip_detail', 'Enter Clip Details', 'required');
		//$this->form_validation->set_rules('date_of_clip', 'Please Enter Clipping Date', 'required');
		if(array_key_exists('submit',$_POST)) //($this->form_validation->run() === FALSE)
		{
			$this->news_model->set_news();
			$this->load->helper('url');
			?>
			<script>alert('News Added Successfully ');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=news";
			</script>
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('news/create');
			$this->load->view('templates/footer');			
		}
	}
	
	public function editnews()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Edit a News / Announcement';
		$data['options'] = $this->news_model->get_clip_dropdown();
		$data['news'] = $this->news_model->get_news($_GET['id']);
		//$this->form_validation->set_rules('clip_type', 'Please Select Clip Type', 'required');
		//$this->form_validation->set_rules('headline', 'Please Enter Headline', 'required');
		//$this->form_validation->set_rules('clip_detail', 'Enter Clip Details', 'required');
		//$this->form_validation->set_rules('date_of_clip', 'Please Enter Clipping Date', 'required');
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{			
			$this->news_model->update_news($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('News Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=news";
			</script>
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('news/editnews');
			$this->load->view('templates/footer');
		}
	}
	
	public function deletenews()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $data['title'] = 'Delete News / Announcement';
		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->load->view('templates/header', $data);
		$this->load->view('news/index');
		$this->load->view('templates/footer');	
		
		$this->news_model->delete_news($_GET['id']);
		$this->load->helper('url');
		?>
		<script>alert('News Deleted');
		location = "<?php echo $_SERVER['PHP_SELF'];?>?c=news";
		</script>
		<?php
	}
	
	public function updateStatus()
	{
		$this->load->helper('url');
		$this->load->library('session');
		if(!$this->session->userdata('nabl_user'))
		{
			redirect('c=auth&m=login');
		}
		$status = $_GET['status'];
		$id = $_GET['id'];		
		$this->load->model('news_model');
		if($this->news_model->update_status($status, $id))
		{
			?>
			<script language="javascript">
			alert('Status Updated Successfully');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=news";
			</script>
			<?php 
		}
		else
		{
			?>
			<script language="javascript">
			alert('Unable To Update Status');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=news";
			</script>
			<?php
		}		
	}

}