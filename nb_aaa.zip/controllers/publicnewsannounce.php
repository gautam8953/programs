<?php

class publicnewsannounce extends CI_Controller {



	public function __construct()

	{

		parent::__construct();		

		$this->load->model('news_model');

	}



	public function index()

	{

		$data['title'] = "News/Announcements";

		$this->load->helper('url');

	    $this->load->library('pagination');

	    $data['pagination']="yes";	    

	    if(isset($_GET['clipType']) && $_GET['clipType']!="")

	    {

	    	$clipType = $_GET['clipType'];

	    }

	    else 

	    {

	    	$clipType = "both";

	    }	    

	    $config['base_url'] = base_url().'index.php?c=publicnewsannounce&m=index&clipType='.$clipType;

	    $config['total_rows'] = $this->db->count_all('jos_clip_details_tbl');

	    $config['per_page'] = '10';

	    $config['full_tag_open'] = '<p>';

	    $config['full_tag_close'] = '</p>';	

	    $this->pagination->initialize($config);

	    $this->load->model('news_model');

	    $data['news'] = $this->news_model->get_lab_active_news_announcementOrderById($config['per_page'], $clipType);

	    $this->load->view('publicnewsannounce/index', $data);		

	}

}