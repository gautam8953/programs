<?php
class publicexpiredaccreditation extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Certificate_model');
	}
	
	public function index()
	{
		$this->load->helper('url');
		$keyword = ($this->input->post('search')) ? $this->input->post('search') : $this->input->get('keyword');
		///$this->session->set_userdata('keyword',$keyword);
		$data['title'] = "Expired Accreditation";
		$this->load->library('pagination');
		$data['pagination']="yes";
		$config['per_page'] = '20';
		$config['full_tag_open'] = '<p>';
		$config['full_tag_close'] = '</p>';	
		if(empty($keyword))
		{
			$data['keyword'] = '';
			$config['base_url'] = base_url().'index.php?c=publicexpiredaccreditation&m=index';
			$config['total_rows'] = count($this->Certificate_model->count_ExpiredAccreditation(0));
			$this->pagination->initialize($config);
			$data['laccua'] = $this->Certificate_model->get_ExpiredAccreditation($config['per_page']);
			
		}else{
			if($this->input->get('per_page')){
				$page = $this->input->get('per_page');
			}else{
				$page = 20 ;
			}
			
			$config['base_url'] = base_url().'index.php?c=publicexpiredaccreditation&m=index&keyword='.$keyword;
			$start=$page;
			$data['keyword'] = $keyword;
			$config['total_rows'] = $this->Certificate_model->search($keyword,$count=true,$config['per_page'],$start);
			$this->pagination->initialize($config);
			$data['laccua'] = $this->Certificate_model->search($keyword,$count=false,$config['per_page'],$start);
			
		}
		$this->load->view('publicexpiredaccreditation/index', $data);
	}
	
	
}