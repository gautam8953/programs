<?php
class Eventschedule extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Eventschedule_model');
	}

	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Training & Awareness";
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }		
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=eventschedule&m=index';
	    $config['total_rows'] = $this->db->count_all('event_schedule_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('Eventschedule_model');
	    $data['news'] = $this->Eventschedule_model->get_lab_all_eventSchedule($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('eventschedule/index', $data);
		$this->load->view('templates/footer');		
		
	}

	public function view($slug)
	{
        $this->load->library('session');
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$data['news_item'] = $this->Eventschedule_model->get_event_test_schedule($slug);
		if (empty($data['news_item']))
		{
			show_404();
		}
		$data['title'] = $data['news_item']['category_name'];
		$this->load->view('templates/header', $data);
		$this->load->view('eventschedule/view', $data);
		$this->load->view('templates/footer');
	}

	public function create()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Add Event Schedule';

		$data['city'] = $this->Eventschedule_model->get_city();
		$data['state'] = $this->Eventschedule_model->get_states();	
		$data['country'] = $this->Eventschedule_model->get_country();	
		$data['eventType'] = $this->Eventschedule_model->get_eventType();
			/*
			$this->form_validation->set_rules('event_type_id', 'Please Select Event Type', 'required');
			$this->form_validation->set_rules('program_name', 'Please Enter Program Name', 'required');
			$this->form_validation->set_rules('course_detail', 'Please Enter Course Details', 'required');
			$this->form_validation->set_rules('venue', 'Please Enter venue', 'required');
			$this->form_validation->set_rules('contact_address', 'Please Enter Contact Address', 'required');
			$this->form_validation->set_rules('city', 'Please Enter City Name', 'required');		
			$this->form_validation->set_rules('country', 'Please Enter Country Name', 'required');
			$this->form_validation->set_rules('phone', 'Please Enter Phone Number', 'required');
			$this->form_validation->set_rules('program_fees', 'Please Enter Program Fees', 'required');	
			*/
		if(array_key_exists('submit',$_POST)) //($this->form_validation->run() === FALSE)
		{
			$this->Eventschedule_model->set_event_sch();
			$this->load->helper('url');
			?>
			<script>alert('Schedule Added Sucessfullly');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=eventschedule";
			</script>
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('eventschedule/create');
			$this->load->view('templates/footer');
		}
	}

	public function editschedule()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Edit Event Schedule';
		
		$data['labs'] = $this->Eventschedule_model->get_event_test_schedule($_GET['id']);
		
		$data['city'] = $this->Eventschedule_model->get_city();
		$data['state'] = $this->Eventschedule_model->get_states();
		$data['country'] = $this->Eventschedule_model->get_country();
		$data['eventType'] = $this->Eventschedule_model->get_eventType();
		/*
		$this->form_validation->set_rules('event_type_id', 'Please Select Event Type', 'required');
		$this->form_validation->set_rules('program_name', 'Please Enter Program Name', 'required');
		$this->form_validation->set_rules('course_detail', 'Please Enter Course Details', 'required');
		$this->form_validation->set_rules('venue', 'Please Enter venue', 'required');
		$this->form_validation->set_rules('contact_address', 'Please Enter Contact Address', 'required');
		$this->form_validation->set_rules('city', 'Please Enter City Name', 'required');		
		$this->form_validation->set_rules('country', 'Please Enter Country Name', 'required');
		$this->form_validation->set_rules('phone', 'Please Enter Phone Number', 'required');
		$this->form_validation->set_rules('program_fees', 'Please Enter Program Fees', 'required');
		*/

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->Eventschedule_model->update_event_sch($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Schedule Updated Sucessfullly');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=eventschedule";
			</script>
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('eventschedule/editschedule');
			$this->load->view('templates/footer');
		}
	}

	public function deleteschedule()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }        
		$data['title'] = 'Delete Event Schedule';
		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->load->view('templates/header', $data);
		$this->load->view('eventschedule/index');
		$this->load->view('templates/footer');
		
		$data['labs'] = $this->Eventschedule_model->get_event_test_schedule($_GET['id']);
		
		$this->Eventschedule_model->delete_event_sch($_GET['id']);		
		?>
		<script>alert('Schedule Deleted Sucessfullly');
		location = "<?php echo $_SERVER['PHP_SELF'];?>?c=eventschedule";
		</script>
		<?php
	}
	
	public function updateStatus()
	{
		$this->load->helper('url');
		$this->load->library('session');
		if(!$this->session->userdata('nabl_user'))
		{
			redirect('c=auth&m=login');
		}
		$status = $_GET['status'];
		$id = $_GET['id'];		
		$this->load->model('Eventschedule_model');
		if($this->Eventschedule_model->update_status($status, $id))
		{
			?>
			<script language="javascript">
			alert('Status Updated Successfully');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=eventschedule";
			</script>
			<?php 
		}
		else
		{
			?>
			<script language="javascript">
			alert('Unable To Update Status');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=eventschedule";
			</script>
			<?php
		}		
	}

}




