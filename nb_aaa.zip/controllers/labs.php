<?php
class labs extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('lab_model');
	}

	public function index()
	{
		$this->load->helper('url');
		$data['title'] = 'Lab Categories';
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
           //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=labs&m=index';
	    $this->db->where('cat_id',0);		
		$this->db->from('lab_category_tbl');	    
	    $config['total_rows'] = $this->db->count_all_results(); 	    	    	   
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('lab_model');
	    $data['total_rows'] =  $this->lab_model->count_all_labs_category();
	    $data['news'] = $this->lab_model->get_all_labs_category($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('labs/index', $data);
		$this->load->view('templates/footer');
		
	}

	public function view($slug)
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $data['news_item'] = $this->lab_model->get_lab_category($slug);

		if (empty($data['news_item']))
		{
			show_404();
		}

		$data['title'] = $data['news_item']['category_name'];

		$this->load->view('templates/header', $data);
		$this->load->view('news/view', $data);
		$this->load->view('templates/footer');
	}

	public function create()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {            
           redirect('c=auth&m=login');
        }
        $this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Create a Lab Category';
		//$this->form_validation->set_rules('category_name', 'Category Name', 'required');
		//$this->form_validation->set_rules('category_description', 'text', 'required');		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->lab_model->set_labs();
			$this->load->helper('url');
			?>
			<script>alert('Category Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=labs&m=index";
			</script>
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('labs/create');
			$this->load->view('templates/footer');
		}
	}

	public function editlab()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Edit a Lab Category';
		$data['labs'] = $this->lab_model->get_lab_category($_GET['id']);
		//$this->form_validation->set_rules('category_name', 'Category Name', 'required');
		//$this->form_validation->set_rules('category_description', 'text', 'required');
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			
			$this->lab_model->update_labs($_GET['id']);
			$this->load->helper('url');
			if(isset($_POST['catid']))
			{
				
				?>
				<script>alert('Category Updated');
				location = "<?php echo $_SERVER['PHP_SELF'];?>?c=labs&m=showsubcat&catid=<?php echo $_POST['catid']; ?>";
				</script>
				<?php 
			}
			else 
			{
				?>
				<script>alert('Category Updated');
				location = "<?php echo $_SERVER['PHP_SELF'];?>?c=labs&m=index";
				</script>
				<?php 
			}
			?>
			
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('labs/editlab');
			$this->load->view('templates/footer');
		}
	}

	public function deletelab()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
           //$this->load->helper('url');
           redirect('c=auth&m=login');
        }        
        $this->load->helper('url');
        $data['title'] = 'Delete Lab Category';
		$this->load->helper('form');		
		$data['title'] = 'Delete Lab Category';			
		$this->lab_model->delete_lab_cat($_GET['id']);
		$this->load->helper('url');
		if(isset($_GET['catid']) && $_GET['catid']!=0)
		{
			$catid = $_GET['catid'];
			//die();
			?>
				<script>alert('Category Deleted');
				location = "<?php echo $_SERVER['PHP_SELF'];?>?c=labs&m=showsubcat&catid=<?php echo $catid; ?>";
				</script>
			<?php
		}
		else 
		{
		  	?>
				<script>alert('Category Deleted');
				location = "<?php echo $_SERVER['PHP_SELF'];?>?c=labs&m=index";
				</script>
			<?php
		}
	}
	
	public function changestatus()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){             
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $data['title'] = 'Lab Category';        
        $this->lab_model->change_lab_status($_GET['id']);
        ?>
		<script>alert('Category Status Has been Changed');
		location = "<?php echo $_SERVER['PHP_SELF'];?>?c=labs";
		</script>
		<?php        
	}

	public function addsubcat()
	{
		$this->load->helper('url');
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {            
           redirect('c=auth&m=login');
        }
        $this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Create a Lab Sub Category';
		//$this->form_validation->set_rules('category_name', 'Category Name', 'required');
		//$this->form_validation->set_rules('category_description', 'text', 'required');		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$catid = $_POST['catid'];
			if($this->lab_model->set_sub_cat())
			{
				$this->load->helper('url');
				?>
				<script>alert('Sub Category Added');
				location = "<?php echo $_SERVER['PHP_SELF'];?>?c=labs&m=showsubcat&catid=<?php echo $catid; ?>";
				</script>
				<?php	
			}
			else 
			{
				$this->load->helper('url');
				?>
				<script>alert('Unable To Create Sub Category');
				location = "<?php echo $_SERVER['PHP_SELF'];?>?c=labs&m=showsubcat&catid=<?php echo $catid; ?>";
				</script>
				<?php
			}
					
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('labs/addsubcat');
			$this->load->view('templates/footer');
		}
	}
	
	public function showsubcat()
	{	
		$this->load->helper('url');	
		$data['title'] = 'Lab Categories';
		$this->load->library('session'); 		             
        if(!$this->session->userdata('nabl_user'))
        {
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        if(isset($_GET['catid']) && $_GET['catid']!=0)
        {
        	$catid = $_GET['catid'];
        	$config['base_url'] = base_url().'index.php?c=labs&m=showsubcat&catid='.$catid;
        }
        else 
        {
        	$catid = $_GET['catid'];
        	$config['base_url'] = base_url().'index.php?c=labs&m=showsubcat&catid='.$catid;
        }
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    //$config['base_url'] = base_url().'index.php?c=labs&m=index';
	    //$catid = $_GET['catid'];
	    $this->db->where('cat_id',$catid);
		$this->db->from('lab_category_tbl');	    
	    $config['total_rows'] = $this->db->count_all_results();	    
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('lab_model');
	    $data['navheader'] = $this->lab_model->showCategoryNavigater($catid);
	    //die();
	    $data['total_rows'] =  $this->lab_model->count_all_labs_category($catid);
	    $data['news'] = $this->lab_model->get_all_labs_category($config['per_page'],$catid);
	    //print_r($data['news']);
	    //die();
	    $this->load->view('templates/header', $data);
		$this->load->view('labs/showsubcat', $data);
		$this->load->view('templates/footer');	
	}
	
	

}