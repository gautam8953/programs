<?php
include './application/libraries/dropdown.php';
class Field extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('field_model');
    }

    public function index()
    {
    	$data['title'] = "Field";
        $this->load->library('session');        
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }        
        $this->load->helper('url');
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=field&m=index';
	    $config['total_rows'] = $this->db->count_all('facility_fields_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('field_model');
	    $data['fields'] = $this->field_model->get_all_fields($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('field/index', $data);
		$this->load->view('templates/footer');	
        
    }

    public function view($slug)
    {
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $data['news_item'] = $this->field_model->get_lab_field($slug);
        if (empty($data['news_item']))
        {
            show_404();
        }

        $data['title'] = $data['news_item']['field_name'];
        $this->load->view('templates/header', $data);
        $this->load->view('field/view', $data);
        $this->load->view('templates/footer');
    }

    public function create()
    {
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $dropDownObj = new dropdown();
        $this->load->helper('form');
        $this->load->library('form_validation');

        $data['title'] = 'Create a Field';
        $data['facilitydropdown'] = $dropDownObj->facilityDropDwon('facility_id', 'facility_id',  '', '');        

        $this->form_validation->set_rules('facility_id', 'Facility Name', 'required');
        $this->form_validation->set_rules('field_name', 'Field Name', 'required');        

        if ($this->form_validation->run() === FALSE)
        {
        	$this->load->helper('url');
            $this->load->view('templates/header', $data);
            $this->load->view('field/create');
            $this->load->view('templates/footer');

        }
        else
        {
            $this->field_model->set_field();
            $this->load->helper('url');
            ?>
            <script>alert('Field Added');
            location = "<?php echo $_SERVER['PHP_SELF'];?>?c=field";
            </script>
            <?php

        }
    }

    public function editfield()
    {
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->library('dropdown'); 
        $this->load->helper('form');
        $this->load->library('form_validation');
        $data['title'] = 'Edit - Field';
        $data['field'] = $this->field_model->get_lab_field($_GET['id']);        
        
        $data['facilitydropdown'] = $this->dropdown->facilityDropDwon('facility_id', 'facility_id',  '', '', $data['field']['facility_id']);
        
        $this->form_validation->set_rules('facility_id', 'Facility Name', 'required');
        $this->form_validation->set_rules('field_name', 'Field Name', 'required');

        if ($this->form_validation->run() === FALSE)
        {
        	$this->load->helper('url');
            $this->load->view('templates/header', $data);
            $this->load->view('field/editfield');
            $this->load->view('templates/footer');

        }
        else
        {
            $this->field_model->update_field($_GET['id']);
            $this->load->helper('url');
            ?>
            <script>alert('Field Updated');
            location = "<?php echo $_SERVER['PHP_SELF'];?>?c=field";
            </script>
            <?php

        }
    }

    public function deletefield()
    {
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $data['title'] = 'Delete Field';
        $this->load->helper('form');
        $this->load->library('form_validation');

        $this->load->view('templates/header', $data);
        $this->load->view('field/index');
        $this->load->view('templates/footer');

        $data['title'] = 'Delete Field';
        $data['subgroup'] = $this->field_model->get_lab_field($_GET['id']);

        $this->field_model->delete_field($_GET['id']);
        $this->load->helper('url');
        ?>
            <script>alert('Field Deleted');
            location = "<?php echo $_SERVER['PHP_SELF'];?>?c=field";
            </script>
        <?php


    }

}