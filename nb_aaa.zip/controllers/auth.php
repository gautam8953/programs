<?php
class Auth extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('auth_model');
	}

	public function index()
	{
		
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
           //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        
		$this->load->helper('form');
		$this->load->library('form_validation');
		
		
		//$this->form_validation->set_rules('username', 'User Name Cann\'t be Blank', 'required');
		//$this->form_validation->set_rules('password', 'Password Cann\'t be Blank', 'required');		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$data['title'] = 'Login';	
			$this->load->helper('url');
			if($this->auth_model->login())
			{				
				$data['title'] = 'Admin Dashboard';
				$this->load->view('templates/header');
				$this->load->view('admin/index',$data);
				$this->load->view('templates/footer');
			}
			else 
			{
				$data['msg'] = 'Invalid User Please Try Again';				
				$this->load->view('auth/login',$data);				
			}
		}
		else
		{			
			$data['title'] = 'Login';
			$this->load->helper('url');			
			$this->load->view('auth/login',$data);	
		}
		
	}
	
	
	public function login()
	{
		
		$this->load->helper('form');
		$this->load->library('form_validation');
		
		$data['title'] = 'Login';
		$this->load->helper('url');
		//$this->form_validation->set_rules('username', 'User Name Cann\'t be Blank', 'required');
		//$this->form_validation->set_rules('password', 'Password Cann\'t be Blank', 'required');
		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{	
			$data['title'] = 'Login';		
			$this->load->helper('url');
			if($this->auth_model->login())
			{
				$data['title'] = 'Admin Dashboard';
				$this->load->view('templates/header',$data);
				$this->load->view('admin/index',$data);
				$this->load->view('templates/footer',$data);
			}
			else 
			{
				$data['msg'] = 'Invalid User Please Try Again';				
				$this->load->view('auth/login',$data);				
			}	
		}
		else
		{	
			$this->load->view('auth/login',$data);			
		}
		
	}
	public function view($slug)
	{
		
	}
	
	public function changePassword()
	{
		$this->load->helper('url');
		$this->load->library('session');
		if(!$this->session->userdata('nabl_user'))
		{
           $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        
        $username = $this->session->userdata('nabl_user');
		$this->load->helper('form');
		$this->load->library('form_validation');		
		$data['title'] = 'Change Password';
		$this->form_validation->set_rules('oldpassword', 'Old Password Cann\'t be Blank', 'required');
		$this->form_validation->set_rules('newpassword', 'New Password Cann\'t be Blank', 'required');
		if ($this->form_validation->run() === FALSE)//if(array_key_exists('submit',$_POST))
		{	
			$this->load->helper('url');
			$this->load->view('templates/header',$data);
			$this->load->view('auth/changePassword',$data);
			$this->load->view('templates/footer',$data);
		}
		else
		{		
			if($this->auth_model->change_pass($username))
			{
				$this->load->helper('url');
				$data['msg'] = 'Password Change Successfully';
				//$this->load->view('templates/header',$data);
				$this->load->view('auth/login',$data);
				//$this->load->view('templates/footer',$data);
			}
			else 
			{
				$this->load->helper('url');
				$data['msg'] = 'Unable To Change Password';
				$this->load->view('templates/header',$data);
				$this->load->view('auth/changePassword',$data);
				$this->load->view('templates/footer',$data);
			}
		}
		
	
	}
	
	public function logout() 
	{
         	 $this->load->helper('url');
             $this->load->library('session');        
             //$this->session->unset_userdata('nabl_user');     
             //$this->session->sess_destroy(); 
             $this->session->sess_destroy(); 
             redirect('c=auth&m=login');
     }
	
}