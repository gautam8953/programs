<?php ini_set('memory_limit', '-1');
class statusapplicantlaboratories extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('status_applicant_laboratories_model');
	}
	
	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Status of Applicant Laboratories";
        $this->load->library('session');
        if(!$this->session->userdata('nabl_user')){             
           redirect('c=auth&m=login');
        }
        
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=statusapplicantlaboratories&m=index';
	    $config['total_rows'] = $this->db->count_all('status_applicant_laboratories_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';
	    $this->pagination->initialize($config);
	    $this->load->model('status_applicant_laboratories_model');
	    $data['laccua'] = $this->status_applicant_laboratories_model->get_all_statusapplicantlaboratory($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('statusapplicantlaboratories/index', $data);
		$this->load->view('templates/footer');
	}
	
	public function create()
	{		
		$this->load->helper('url');		
		$this->load->library('session');           
        if(!$this->session->userdata('nabl_user'))
        { 
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');		
		$this->load->library('dropdown');
		$data['title'] = "Add Status of Applicant Laboratories";
		$data['lab_names'] = $this->dropdown->labsdropdown('lab_id','lab_id','','','');
		$data['certificate_no'] = $this->dropdown->certificatedropdown('cno','cno','','','');
		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->status_applicant_laboratories_model->setstatusapplicantlaboratory();
			$this->load->helper('url');
			?>
			<script>alert('Record Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=statusapplicantlaboratories";
			</script>
			<?php
		}
		else
		{
			//echo "Else Block";
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('statusapplicantlaboratories/create');
			$this->load->view('templates/footer');
		}	
		
	}
	
	public function edit()
	{
				
		$this->load->helper('url');
		$this->load->library('session');
        if(!$this->session->userdata('nabl_user'))
        {
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('dropdown');
		$data['title'] = "Edit Status of Applicant Laboratories";
		$data['lacua'] = $this->status_applicant_laboratories_model->get_statusapplicantlaboratory($_GET['id']);
		$data['lab_names'] = $this->dropdown->labsdropdown('lab_id','lab_id','','',$data['lacua']['lab_id']);
		//$data['certificate_no'] = $this->dropdown->certificatedropdown('cno','cno','','',$data['lacua']['certificate_id']);
		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->status_applicant_laboratories_model->updatestatusapplicantlaboratory($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Record Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=statusapplicantlaboratories";
			</script>
			<?php
		}
		else
		{
			//echo "Else Block";
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('statusapplicantlaboratories/edit');
			$this->load->view('templates/footer');
		}
	
	}
	
	public function delete()
	{		
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {              
           redirect('c=auth&m=login');
        }		
		$this->load->helper('form');
		//$this->load->library('form_validation');
		$data['title'] = 'Delete - Status of Applicant Laboratories';
		$this->status_applicant_laboratories_model->deletestatusapplicantlaboratory($_GET['id']);
		$this->load->helper('url');
		?>
			<script>alert('Record Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=statusapplicantlaboratories";
			</script>
		<?php	
	}
}