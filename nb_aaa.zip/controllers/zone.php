<?php
class zone extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('zone_model');
	}

	public function index()
	{
		$data['title'] = "Zone";
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }        
		$this->load->helper('url');
	    $this->load->library('pagination');
	    $config['base_url'] = base_url().'index.php?c=zone&m=index';
	    $config['total_rows'] = $this->db->count_all('zone_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('zone_model');
	    $data['zone'] = $this->zone_model->get_all_labs_zones($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('zone/index', $data);
		$this->load->view('templates/footer');	
		
	}

	public function view($slug)
	{
			/*
			$data['news_item'] = $this->facility_model->get_lab_facility($slug);
			if (empty($data['news_item']))
			{
				show_404();
			}	
			$data['title'] = $data['news_item']['facility_name'];	
			$this->load->view('templates/header', $data);
			$this->load->view('facility/view', $data);
			$this->load->view('templates/footer');
			*/
	}

	public function create()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Create a Zone';
		//$this->form_validation->set_rules('zone_name', 'Zone Name', 'required');
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->zone_model->set_zone();
			$this->load->helper('url');
			?>
			<script>alert('Zne Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=zone";
			</script>
			<?php
		}
		else
		{
			$this->load->view('templates/header', $data);
			$this->load->view('zone/create');
			$this->load->view('templates/footer');
		}
	}

	public function editzone()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Edit - Zone';
		$data['zone'] = $this->zone_model->get_zone($_GET['id']);

		//$this->form_validation->set_rules('zone_name', 'Zone Name', 'required');
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->zone_model->update_zone($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Zone Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=zone";
			</script>
			<?php			
		}
		else
		{
			$this->load->view('templates/header', $data);
			$this->load->view('zone/editzone');
			$this->load->view('templates/footer');
		}
	}

	public function deletezone()
	{

		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $data['title'] = 'Delete Zone';
		$this->load->helper('form');
		$this->load->library('form_validation');
			//$this->load->view('templates/header', $data);
			//$this->load->view('facility/index');
			//$this->load->view('templates/footer');
		$data['title'] = 'Delete Zone';
		//$data['facility'] = $this->zone_model->get_zone($_GET['id']);		
		$this->zone_model->delete_zone($_GET['id']);
		$this->load->helper('url');
		?>
			<script>alert('Zone Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=zone";
			</script>
		<?php
	}

}