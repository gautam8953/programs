<?php
class assessor extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('assessor_model');
	}

	public function index()
	{		
		$this->load->helper('url');
		$data['title'] = "Assessor";
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
             // $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        //print_r($this->session->userdata('nabl_user'));
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=assessor&m=index';
	    $config['total_rows'] = $this->db->count_all('assessor_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('assessor_model');
	    $data['assessor'] = $this->assessor_model->get_all_assessor($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('assessor/index', $data);
		$this->load->view('templates/footer');
	}

	public function view($slug)
	{
			
	}

	public function create()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Add Assessor';
		//$this->form_validation->set_rules('clip_name', 'Please Enter Clip Name', 'required');		

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->assessor_model->set_assessor();
			$this->load->helper('url');
			?>
			<script>alert('Assessor Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=assessor";
			</script>
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('assessor/create');
			$this->load->view('templates/footer');
		}
	}
	

	public function edit()
	{
        
		$this->load->helper('url');
        $this->load->library('session');          
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Edit - Assessor';
		$data['assessor'] = $this->assessor_model->get_assessor($_GET['id']);
		//$this->form_validation->set_rules('clip_name', 'Please Enter Clip Name', 'required');

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->assessor_model->update_assessor($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Assessor Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=assessor";
			</script>
			<?php			
		}
		else
		{
            $this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('assessor/edit');
			$this->load->view('templates/footer');			
		}
	}

	public function delete()
	{
        $this->load->helper('url');
		$this->load->library('session');   
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$data['title'] = 'Delete Assessor';
		$this->load->helper('form');
		$this->load->library('form_validation');		
		$data['title'] = 'Delete Assessor';		
		$this->assessor_model->delete_assessor($_GET['id']);
		//$this->load->helper('url');
		?>
			<script>alert('Assessor Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=assessor";
			</script>
		<?php
	}
	
	public function loginassessors()
	{
		
		//session_start();
		$this->load->helper('form');
		$this->load->library('form_validation');
		
		$data['title'] = 'Assessor Login';
		$this->load->helper('url');		
		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{	
			$data['title'] = 'Assessor Login';		
			$this->load->helper('url');
			if($this->assessor_model->login())
			{				
				$data['title'] = 'Assessor Login';				
				$data['msg'] = 'Login Successfully';
				$this->load->view('assessor/loginassessors',$data);				
			}
			else 
			{
				$data['msg'] = 'Invalid User Name. Please Try Again';				
				$this->load->view('assessor/loginassessors',$data);				
			}	
		}
		else
		{	
			$this->load->view('assessor/loginassessors',$data);			
		}
		
	
	}
}