<?php
class eventtype extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('eventtype_model');
	}

	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Event Type";
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        		
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=eventtype&m=index';
	    $config['total_rows'] = $this->db->count_all('event_type_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('eventtype_model');
	    $data['eventtype'] = $this->eventtype_model->get_all_labs_eventTypes($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('eventtype/index', $data);
		$this->load->view('templates/footer');
	}

	public function view($slug)
	{
			
	}

	public function create()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
             // $this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Add - Event Type';
		$this->form_validation->set_rules('event_type_name', 'Please Enter Event Type Name', 'required');		

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->eventtype_model->set_eventtype();
			$this->load->helper('url');
			?>
			<script>alert('Event Type Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=eventtype";
			</script>
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('eventtype/create');
			$this->load->view('templates/footer');
		}
	}

	public function edit_type_type()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Edit - Event Type';
		$data['eventtype'] = $this->eventtype_model->get_eventtype($_GET['id']);
		$this->form_validation->set_rules('event_type_name', 'Please Enter Event Type Name', 'required');

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->eventtype_model->update_eventtype($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Event Type Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=eventtype";
			</script>
			<?php			
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('eventtype/edit_type_type');
			$this->load->view('templates/footer');
		}
	}

	public function delete_event_type()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }        
		$data['title'] = 'Delete Event Type';
		$this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Delete - Event Type ';
		$this->eventtype_model->delete_eventtype($_GET['id']);
		$this->load->helper('url');
		?>
			<script>alert('Event Type Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=eventtype";
			</script>
		<?php
	}
}