<?php

class Ngsearch extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('ngsearch_model');
        $this->load->model('laboratory_model');
    }

public function test(){
if(isset($_GET['filename']))
{
	$fileName = $_GET['filename'];
	$path = FCPATH."/uploads/".$fileName;




	if($fileName!="")
	{
		$fileExt = strtolower(end(explode('.',$fileName)));
	}
	switch($fileExt)
	{
		case "pdf": $ctype="application/pdf"; break;
		case "doc": $ctype="application/msword"; break;
		case "docx": $ctype="application/vnd.openxmlformats-officedocument.wordprocessingml.document"; break;
		case "xls": $ctype="application/vnd.ms-excel"; break;	
		case "xlsx": $ctype="application/vnd.ms-excel"; break;
		default: $ctype="application/force-download";
	}		
	
	header("Content-type: $ctype");	
	header("Content-Disposition: attachment; filename=$fileName");
	readfile($path);	
}

}
    public function index() {
        ini_set('max_execution_time', 72000); //60 minutes
        
        $this->load->helper('url');
        $this->load->library('dropdown'); //$dropDownObj = new dropdown();
        $this->load->helper('form');
        $data['title'] = 'Laboratory Search';
        $data['state'] = $this->dropdown->stateDropDwon('state', 'state', 'getCityList(this.value)', '', '');
        $data['city'] = $this->dropdown->cityDropDwon('city', 'city', '', '', '');
        $data['zone'] = $this->dropdown->zoneDropDwon('zone', 'zone', '', '', '');
        $data['natureoflab'] = $this->dropdown->natureoflabDropDwon('natureoflab', 'natureoflab', '', '', '');
        $data['operationat'] = $this->dropdown->operationAtDropDwon('operationat[]', 'operationat', '', '', '');
        $data['country'] = $this->laboratory_model->get_country();
        $data['facilitydropdown'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id', 'getFieldListPro(this.value)', '', '');
        $data['selectedCountry'] = '';
        //$this->load->library('session');
        //$data['facilitydropdown'] = $this->dropdown->facilityDropDwon('facility_id', 'facility_id',  'getFieldList(this.value)', '');
        $this->load->model('ngsearch_model');
          if ($this->input->server('REQUEST_METHOD') === 'POST') {//if ($this->form_validation->run() === FALSE)
            $data['pagination'] = "yes";
            $data['rows'] = $this->ngsearch_model->search_page();
            
//            echo "<pre>";
//            print_r($data['rows'][0]['total_rows']); die;
            
            $this->load->helper('url');
            $this->load->library('pagination');
            $config['base_url'] = base_url() . 'index.php?c=ngsearch&m=index';
            $config['total_rows'] = $data['rows'][0]['total_rows'];
            $config['per_page'] = '10';
            $config['full_tag_open'] = '<p>';
            $config['full_tag_close'] = '</p>';
            $this->pagination->initialize($config);

            $data['labdata'] = $this->ngsearch_model->search($config['per_page']);
            $this->load->library('session');
            $data['searchFormData'] = $this->session->userdata;
            $postedData = $data['searchFormData'];
            $data['selectedCountry'] = $postedData['country1'];
            $data['state'] = $this->dropdown->stateDropDwon('state', 'state', 'getCityList(this.value)', '', $postedData['state1']);
            $data['city'] = $this->dropdown->cityDropDwon('city', 'city', '', '', $postedData['city1']);
            $data['zone'] = $this->dropdown->zoneDropDwon('zone', 'zone', '', '', $postedData['zone1']);
            $data['natureoflab'] = $this->dropdown->natureoflabDropDwon('natureoflab', 'natureoflab', '', '', $postedData['nature_of_lab1']);
            $data['operationat'] = $this->dropdown->operationAtDropDwon('operationat[]', 'operationat', '', '', $postedData['operationAtstr1']);
            $data['facilitydropdown'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id', 'getFieldListPro(this.value)', '', $postedData['facility_id1']);
            $data['fielddropdown'] = "";
            $data['groupdropdown'] = "";
            $data['subgroupdropdown'] = "";
            if ($postedData['facility_id1'] != '-1') {
                $data['fielddropdown'] = $this->dropdown->fieldDropDownByIdPro('field_id[]', 'field_id', 'bindDiscipline()', '', $postedData['field_id1'], $postedData['facility_id1']);
            }
            if ($postedData['field_id1'] != '-1') {
                $data['groupdropdown'] = $this->dropdown->groupDropDownByIdPro('group_id', 'group_id', 'getsubgroupList(this.value)', '', $postedData['group_id1'], $postedData['field_id1']);
            }

            if ($postedData['group_id1'] != '-1') {
                $data['subgroupdropdown'] = $this->dropdown->subgroupDropDownByIdForSearch('subgroup[]', 'subgroup_id', '', '', $postedData['subgroup_id1'], $postedData['group_id1']);
            }

            //Labs data export using enter search keyword
//            $data['allrows'] = $this->ngsearch_model->search($config['total_rows']);

            if (isset($_POST['export-excel'])) {
                ob_clean();
                $srno = 1;
                $export_file_name = "laboratory-search-report-" . date("d-m-Y") . ".xls";
                header("Content-Type: application/vnd.ms-excel");
                header("Content-Disposition: attachment; filename=\"$export_file_name\"");
                $headers = array("Sr. No.", "Lab Name", "Address ", "Tel No", "Fax No", "Email ", "Contact Person");
                echo implode("\t", $headers) . "\n";
                foreach ($data['allrows'] as $rec_obj) {
                    if (strpos($rec_obj['lab_name'], '<br/>') !== false) {
                        $lab_name = str_replace('<br/>', '', $rec_obj['lab_name']);
                        $lab_name = "\"" . eregi_replace("\"", "\"\"", $lab_name) . "\"";
                    } else {
                        $lab_name = $rec_obj['lab_name'];
                        $lab_name = "\"" . eregi_replace("\"", "\"\"", $lab_name) . "\"";
                    }
                    if (!empty($rec_obj['cityName'])) {
                        $cityName = ',' . $rec_obj['cityName'];
                    }
                    if (!empty($rec_obj['pincode'])) {
                        $pincode = '-' . $rec_obj['pincode'];
                    }
                    if (!empty($rec_obj['stateName'])) {
                        $stateName = ',' . $rec_obj['stateName'];
                    }
                    if (!empty($rec_obj['countryName'])) {
                        $countryName = ',' . $rec_obj['countryName'];
                    }
                    $lab_address = $rec_obj['lab_address'] . $cityName . $pincode . $stateName . $countryName;
                    if (strpos($lab_address, '<br/>') !== false) {
                        $lab_address = $lab_address;
                        $lab_address = str_replace('<BR/>', '', $lab_address);
                        $lab_address = str_replace('< BR/>', '', $lab_address);
                        $lab_address = str_replace('<Br/>', '', $lab_address);
                        $lab_address = str_replace('</Br>', '', $lab_address);
                        $lab_address = str_replace('</br>', '', $lab_address);
                        $lab_address = str_replace('<br/>', '', $lab_address);
                        $lab_address = "\"" . eregi_replace("\"", "\"\"", $lab_address) . "\"";
                        $lab_address = html_entity_decode(htmlentities($lab_address, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'ISO-8859-15');
                        $lab_address = str_replace('&rsquo;', '`', $lab_address);
                        $lab_address = str_replace('&ndash;', '-', $lab_address);
                    } else {
                        $lab_address = $lab_address;
                        $lab_address = str_replace('<BR/>', '', $lab_address);
                        $lab_address = str_replace('< BR/>', '', $lab_address);
                        $lab_address = str_replace('<Br/>', '', $lab_address);
                        $lab_address = str_replace('</Br>', '', $lab_address);
                        $lab_address = str_replace('</br>', '', $lab_address);
                        $lab_address = str_replace('<br/>', '', $lab_address);
                        $lab_address = "\"" . eregi_replace("\"", "\"\"", $lab_address) . "\"";
                        $lab_address = html_entity_decode(htmlentities($lab_address, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'ISO-8859-15');
                        $lab_address = str_replace('&rsquo;', '`', $lab_address);
                        $lab_address = str_replace('&ndash;', '-', $lab_address);
                    }

                    if (strpos($rec_obj['phone'], ',') !== false) {
                        $phone = str_replace('â€“', '-', $rec_obj['phone']);
                        $phone = "\"" . eregi_replace("\"", "\"\"", $phone) . "\"";
                        $phone = html_entity_decode(htmlentities($phone, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'ISO-8859-15');
                        $phone = str_replace('&ndash;', '-', $phone);
                    } else {
                        $phone = $rec_obj['phone'];
                        $phone = "\"" . eregi_replace("\"", "\"\"", $phone) . "\"";
                        $phone = html_entity_decode(htmlentities($phone, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'ISO-8859-15');
                        $phone = str_replace('&ndash;', '-', $phone);
                    }

                    if (strpos($rec_obj['fax'], ',') !== false) {
                        $fax = str_replace('â€“', '-', $rec_obj['fax']);
                        $fax = "\"" . eregi_replace("\"", "\"\"", $fax) . "\"";
                        $fax = html_entity_decode(htmlentities($fax, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'ISO-8859-15');
                        $fax = str_replace('&ndash;', '-', $fax);
                    } else {
                        $fax = $rec_obj['fax'];
                        $fax = "\"" . eregi_replace("\"", "\"\"", $fax) . "\"";
                        $fax = html_entity_decode(htmlentities($fax, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'ISO-8859-15');
                        $fax = str_replace('&ndash;', '-', $fax);
                    }

                    if (strpos($rec_obj['emailid'], ',') !== false) {
                        $emailid = str_replace(',', ',', $rec_obj['emailid']);
                        $emailid = "\"" . eregi_replace("\"", "\"\"", $emailid) . "\"";
                    } else {
                        $emailid = $rec_obj['emailid'];
                        $emailid = "\"" . eregi_replace("\"", "\"\"", $emailid) . "\"";
                    }

                    if (strpos($rec_obj['contact_person'], '<BR/>') !== false) {
                        $contact_person = str_replace('<BR/>', '', $rec_obj['contact_person']);
                        $contact_person = "\"" . eregi_replace("\"", "\"\"", $contact_person) . "\"";
                        $contact_person = html_entity_decode(htmlentities($contact_person, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'ISO-8859-15');
                        $contact_person = str_replace('&ndash;', '-', $contact_person);
                    } else {
                        $contact_person = $rec_obj['contact_person'];
                        $contact_person = "\"" . eregi_replace("\"", "\"\"", $contact_person) . "\"";
                        $contact_person = html_entity_decode(htmlentities($contact_person, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'ISO-8859-15');
                        $contact_person = str_replace('&ndash;', '-', $contact_person);
                    }

                    echo implode("\t", array("$srno", "$lab_name", "$lab_address", "$phone", "$fax", "$emailid", "$contact_person")) . "\n";
                    $srno++;
                }
                exit;
            }

            $this->load->view('ngsearch/index', $data);
        } else {
            //All labs data export without enter any keyword
            $data['allrows'] = $this->ngsearch_model->search();
            if (isset($_POST['export-excel'])) {


                $this->load->library('excel'); //load library
                $this->excel->setActiveSheetIndex(0); //set active index
                //heading of excel sheet
                $header_array = array('Sr. No.', 'Lab Name', 'Address', 'Tel No.', 'Fax No.', 'Email', 'Contact Person');
                $col = 0;
                //setting title of excel sheet
                $this->excel->getActiveSheet()->setCellValue('A1', 'Laboratory Search Report ' . date('d-m-Y'));
                $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
                $this->excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(14);
                $this->excel->getActiveSheet()->mergeCells('A1:G1');
                $cell_head = 'A';
                //insert headings and styling them in excel
                foreach ($header_array as $heading) {
                    $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, 2, $heading);
                    $this->excel->getActiveSheet()->getStyle($cell_head . '2')->getFont()->setBold(true);
                    $this->excel->getActiveSheet()->getStyle($cell_head . '2')->getFont()->setSize(12);
                    $this->excel->getActiveSheet()->getStyle($cell_head . '2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                    $this->excel->getActiveSheet()->getColumnDimension($cell_head . '2')->setAutoSize(true);
                    $cell_head++;
                    $col++;
                }
                //end here
                $cell_head --;
                //styling and adjusting the excel sheet
                for ($col = ord('A'); $col <= ord($cell_head); $col++) {
                    //set column dimension 
                    $this->excel->getActiveSheet()->getColumnDimension(chr($col))->setAutoSize(true);
                    //change the font size
                    $this->excel->getActiveSheet()->getStyle(chr($col))->getFont()->setSize(11);
                    $this->excel->getActiveSheet()->getStyle(chr($col))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
                }
                //end here
                $excel_data = array();
                $sr_no = 1;
                // arrange data regarding heading
                foreach ($data['allrows'] as $record) {
                    //address formatting
                    $lab_address = $record['lab_address'];
                    $lab_address = str_replace('<BR/>', '', $lab_address);
                    $lab_address = str_replace('< BR/>', '', $lab_address);
                    $lab_address = str_replace('<Br/>', '', $lab_address);
                    $lab_address = str_replace('</Br>', '', $lab_address);
                    $lab_address = str_replace('</br>', '', $lab_address);
                    $lab_address = str_replace('<br/>', '', $lab_address);
                    $lab_address = str_replace('<br>', '', $lab_address);
                    if (!empty($record['cityName']))
                        $lab_address .= $record['cityName'];
                    if (!empty($record['cityName']) && !empty($record['pincode']))
                        $lab_address .= '-' . $record['pincode'];
                    if (!empty($record['stateName']))
                        $lab_address .= ',' . $record['stateName'];
                    if (!empty($record['countryName']))
                        $lab_address .= ',' . $record['countryName'];

                    $excel_data[] = array($sr_no, $record['lab_name'], $lab_address, $record['phone'], $record['fax'], $record['emailid'], $record['contact_person']);
                    $sr_no++;
                }
                //insert data in excel sheet
                $this->excel->getActiveSheet()->fromArray($excel_data, null, 'A3');
                $filename = 'Laboratory-Search-Report-report' . date('d/m/Y') . '.xls';
                header('Content-Type: application/vnd.ms-excel');
                header('Content-type: application/force-download');
                header('Content-Transfer-Encoding: binary');
                header('Content-Disposition: attachment;filename="' . $filename . '"');
                header('Cache-Control: max-age=0');
                $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
                $objWriter->save('php://output');
                exit;
            }
            $this->load->view('ngsearch/index', $data);
        }
    }

    public function view($slug) {
        
    }

    public function searchlabcertificate() {
        //$this->load->helper('showgroupsubgroup');
        //$data['Search'] = $this;
        $this->load->helper('form');
        $this->load->helper('url');
        $ggroupsubgroupsarr = array();
        //comment by nishant on 28-05-2013
        //$data['certificatedata'] = $this->ngsearch_model->searchcertificate();
        //--end
        $data['certificatedata'] = $this->ngsearch_model->searchcertificateresult();

        if ($data['certificatedata'] > 0) {
            for ($x = 0; $x < count($data['certificatedata']); $x++) {
                $ggroupsubgroupsarr[$x] = $this->ngsearch_model->viewGroupSubGroupPro($data['certificatedata'][$x]['certificate_id']);
            }
            //print_r($data['gnsdata']);
            //die();
        }
        $data['gnsdata'] = $ggroupsubgroupsarr;
        //print_r($data['gnsdata']);
        //die();

        if (array_key_exists('submit', $_POST)) {//if ($this->form_validation->run() === FALSE)
            
        } else {   //print_r($data); die;
            $this->load->view('search/searchlabcertificate', $data);
            //$this->load->view('templates/footer');			
        }
    }

    public function showGroupSubGroup() {
        /*
          $this->load->helper('test');
          $this->load->helper('form');
          $this->load->helper('url');
          $data['gnsdata']=$this->ngsearch_model->viewGroupSubGroup();
          $this->load->view('search/showGroupSubGroup',$data);
         */
    }

}
