<?php

class Upload extends CI_Controller {

	/*function __construct()
	{
		parent::__construct();
	}	*/

	/*function index()
	{
		$this->load->view('upload_form', array('error' => ' ' ));
	} */

	function get_file_extension($file_name)
	{		
		return end(explode('.',$file_name));		
	}
	
	function do_upload($fieldsName,$docid='')
	{		
		$this->load->library('session');
        if(!$this->session->userdata('nabl_user'))
        {
           $this->load->helper('url');
           redirect('c=auth&m=login');
        }        
        $this->load->helper('url');
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|jpg|png|pdf|JPG|jpeg|JPEG|doc|docx|xls|xlsx';
				
		if($fieldsName=='userfile')
		{
			if($_FILES[$fieldsName]['name']!='')
			{
				$cdate = date("Ymdhi");
				$dno = $_POST['document_no'];
				$ext = $this->get_file_extension($_FILES[$fieldsName]['name']);				
				$dno = str_replace(" ","-",$dno);							
		        $newFileName =   $cdate."-".$dno."-doc.".$ext;
		        $config['file_name'] = $newFileName; 
		        
		        $this->load->library('upload', $config);
		        $this->upload->initialize($config);
				return $data = array('upload_data' => $this->upload->do_upload($fieldsName), 'name'=>$newFileName);
			}
		} 
		
		if($fieldsName=='jobdesc')
		{
			if($_FILES[$fieldsName]['name']!='')
			{
				$cdate = date("Ymdhis");
				$ext = $this->get_file_extension($_FILES[$fieldsName]['name']); 	
				//$file = $_FILES[$fieldsName]['name'];			
				//$file_namewithoutExt =  basename($file,'.'.$ext);	
				//$file_namewithoutExt = str_replace(" ","-",$file_namewithoutExt);		
		        $newFileName =   $cdate."-jobdoc.".$ext;   
		        $config['file_name'] = $newFileName; 
		        
				$this->load->library('upload', $config);
		        $this->upload->initialize($config);
				return $data = array('upload_data' => $this->upload->do_upload($fieldsName), 'name'=>$newFileName);
			}	        
		} 
		
		if($fieldsName=='applicationdoc')
		{
			if($_FILES[$fieldsName]['name']!='')
			{
				$cdate = date("Ymdhis");
				$ext = $this->get_file_extension($_FILES[$fieldsName]['name']); 	
				//$file = $_FILES[$fieldsName]['name'];			
				//$file_namewithoutExt =  basename($file,'.'.$ext);
				//$file_namewithoutExt = str_replace(" ","-",$file_namewithoutExt);
		        $newFileName =   $cdate."-appdoc.".$ext;       
		        $config['file_name'] = $newFileName;
		        $this->load->library('upload', $config);
		        $this->upload->initialize($config);
				return $data = array('upload_data' => $this->upload->do_upload($fieldsName), 'name'=>$newFileName);
			}
		} 
		
		if($fieldsName=='certificatedoc')
		{
			if($_FILES[$fieldsName]['name']!='')
			{
				$ext = $this->get_file_extension($_FILES[$fieldsName]['name']); 				
				//$this->input->post('certificate_no').".".$ext;		
		        $newFileName =   $docid.".".$ext;
		        $path = "uploads/".$newFileName;
		        if(file_exists($path))
		        {      	
		        	unlink($path);	        	
		        }	       
		     	$config['file_name'] = $newFileName; 	       
		        $this->load->library('upload', $config);
		        $this->upload->initialize($config);
				return $data = array('upload_data' => $this->upload->do_upload($fieldsName), 'name'=>$newFileName);
			}
		} 
				
		//die();	
	}
	
}
?>