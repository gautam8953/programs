<?php
class publicprotestschedule extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Protestschedule_model');
	}

	public function index()
	{
		$data['title'] = "Program Schedule";
		/*  
			$this->load->library('session');			           
	        if(!$this->session->userdata('nabl_user'))
	        {
	              $this->load->helper('url');
	           	  redirect('c=auth&m=login');
	        } 
	        */
		$this->load->helper('url');
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=publicprotestschedule&m=index';
	    $config['total_rows'] = $this->db->count_all('proficiency_testing_schedule_tbl');
	    $config['per_page'] = '20';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('Protestschedule_model');
	    $data['protestsch'] = $this->Protestschedule_model->get_active_profTestSchedule($config['per_page']);
	    //$this->load->view('templates/header', $data);
		$this->load->view('publicprotestschedule/index', $data);
		//$this->load->view('templates/footer');
	}

	public function view()
	{		
        $this->load->helper('url');
        $prtestid = $_GET['protestid'];
        $data['labs'] = $this->Protestschedule_model->get_pro_test_schedule($prtestid);			
		$this->load->view('publicprotestschedule/view', $data);
		
	}	
}