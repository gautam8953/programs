<?php
class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('auth_model');
	}

	public function index()
	{
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {             
           	 redirect('c=auth&m=login');
        }        		
		$data['title'] = 'Admin Dashboard';
		$this->load->view('templates/header');
		$this->load->view('admin/index',$data);
		$this->load->view('templates/footer');
	}	
	
	public function view($slug)
	{
		
	}
	
	
	
}