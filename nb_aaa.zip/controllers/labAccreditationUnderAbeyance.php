<?php
class labAccreditationUnderAbeyance extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('lab_accreditation_under_abeyance_model');
	}
	
	public function index()
	{
		$this->load->helper('url');
		$data['title'] = "Laboratory Accreditation under Abeyance";
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){     
           redirect('c=auth&m=login');
        }
        
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=labAccreditationUnderAbeyance&m=index';
	    $config['total_rows'] = $this->db->count_all('lab_accreditation_under_abeyance_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('lab_accreditation_under_abeyance_model');
	    $data['laccua'] = $this->lab_accreditation_under_abeyance_model->get_all_LabAccUnderAbeyance($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('labAccreditationUnderAbeyance/index', $data);
		$this->load->view('templates/footer');
	}
	
	public function create()
	{		
		$this->load->helper('url');		
		$this->load->library('session');           
        if(!$this->session->userdata('nabl_user'))
        { 
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');		
		$this->load->library('dropdown');
		$data['title'] = "Laboratory Accreditation under Abeyance";
		$data['lab_names'] = $this->dropdown->labsdropdown('lab_id','lab_id','','','');
		$data['certificate_no'] = $this->dropdown->certificatedropdown('cno','cno','','','');
		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->lab_accreditation_under_abeyance_model->setLabAccUnderAbeyance();
			$this->load->helper('url');
			?>
			<script>alert('Record Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=labAccreditationUnderAbeyance";
			</script>
			<?php
		}
		else
		{
			//echo "Else Block";
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('labAccreditationUnderAbeyance/create');
			$this->load->view('templates/footer');
		}	
		
	}
	
	public function edit()
	{
				
		$this->load->helper('url');		
		$this->load->library('session');           
        if(!$this->session->userdata('nabl_user'))
        { 
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');		
		$this->load->library('dropdown');
		$data['title'] = "Edit Laboratory Accreditation under Abeyance";
		$data['lacua'] = $this->lab_accreditation_under_abeyance_model->get_LabAccUnderAbeyance($_GET['id']);
		$data['lab_names'] = $this->dropdown->labsdropdown('lab_id','lab_id','','',$data['lacua']['lab_id']);
		$data['certificate_no'] = $this->dropdown->certificatedropdown('cno','cno','','',$data['lacua']['certificate_id']);
		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->lab_accreditation_under_abeyance_model->updateLabAccUnderAbeyance($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Record Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=labAccreditationUnderAbeyance";
			</script>
			<?php
		}
		else
		{
			//echo "Else Block";
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('labAccreditationUnderAbeyance/edit');
			$this->load->view('templates/footer');
		}	
	
	}
	
	public function delete()
	{
		
		$this->load->helper('url');
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {              
           redirect('c=auth&m=login');
        }		
		$this->load->helper('form');
		//$this->load->library('form_validation');
		$data['title'] = 'Delete - Laboratory Accreditation Under Abeyance ';
		$this->lab_accreditation_under_abeyance_model->deleteLabAccUnderAbeyance($_GET['id']);
		$this->load->helper('url');
		?>
			<script>alert('Record Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=labAccreditationUnderAbeyance";
			</script>
		<?php	
	}
}