<?php
class Protestschedule extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Protestschedule_model');
	}

	public function index()
	{
		$data['title'] = "Proficiency Testing";
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        } 
		$this->load->helper('url');
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=protestschedule&m=index';
	    $config['total_rows'] = $this->db->count_all('proficiency_testing_schedule_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('Protestschedule_model');
	    $data['news'] = $this->Protestschedule_model->get_all_profTestSchedule($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('protestschedule/index', $data);
		$this->load->view('templates/footer');
	}

	public function view($slug)
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $data['news_item'] = $this->Protestschedule_model->get_pro_test_schedule($slug);
		if (empty($data['news_item']))
		{
			show_404();
		}
		$data['title'] = $data['news_item']['category_name'];
		$this->load->view('templates/header', $data);
		$this->load->view('protestschedule/view', $data);
		$this->load->view('templates/footer');
	}

	public function create()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->library('dropdown');	
        
        $this->load->helper('url');
        $this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Add Proficiency Testing Schedule';
		$data['facility'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id',  'getFieldList(this.value)', '','');
		//$data['facility'] = $this->Protestschedule_model->get_facility();
		//$data['field'] = $this->Protestschedule_model->get_field();
		$data['city'] = $this->Protestschedule_model->get_city();
		$data['state'] = $this->Protestschedule_model->get_states();	
		$data['country'] = $this->Protestschedule_model->get_country();

			/*
			$this->form_validation->set_rules('code', 'Please Enter Code Number', 'required');
			$this->form_validation->set_rules('programe_name', 'Please Enter Program Name', 'required');
			$this->form_validation->set_rules('programe_description', 'Program Description Description', 'required');
			$this->form_validation->set_rules('facility_id', 'Please Enter Facility Name', 'required');
			$this->form_validation->set_rules('field_id', 'Please Enter Field Name Name', 'required');		
			$this->form_validation->set_rules('nodal_lab_name', 'Please Enter Nodal Lab Name', 'required');
			$this->form_validation->set_rules('contact_person', 'Please Enter Contact Person Name', 'required');
			$this->form_validation->set_rules('city', 'Please Enter City', 'required');
			$this->form_validation->set_rules('country', 'Please Enter Country Name', 'required');
			$this->form_validation->set_rules('last_date_of_registration', 'Please Enter Last Date of Registration', 'required');
			$this->form_validation->set_rules('programme_finish_date', 'Please Enter Program Finish Date', 'required');		
			*/
		if(array_key_exists('submit',$_POST)) //($this->form_validation->run() === FALSE)
		{
			$this->Protestschedule_model->set_pro_test_sch();
			$this->load->helper('url');
			?>
			<script>alert('Schedule Added Sucessfullly');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=protestschedule";
			</script>
			<?php
		}
		else
		{
			$this->load->view('templates/header', $data);
			$this->load->view('protestschedule/create');
			$this->load->view('templates/footer');
		}
	}

	public function editschedule()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->library('dropdown');	
        $this->load->helper('url');
        $this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Edit Proficiency Testing Schedule';
		
		$data['labs'] = $this->Protestschedule_model->get_pro_test_schedule($_GET['id']);
		//print_r($data['labs']['facility']);
		//$data['facility'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id',  'getFieldList(this.value)', '',$data['labs']['facility']);
		$data['facility'] = $this->dropdown->facilityDropDown('facility_id', 'facility_id',  'getFieldList(this.value)','',$data['labs']['facility']);
		$data['fielddropdown'] = $this->dropdown->fieldDropDownById('field_id', 'field_id', '', '',$data['labs']['field_id'],$data['labs']['facility']);
		
		
		$data['city'] = $this->Protestschedule_model->get_city();
		$data['state'] = $this->Protestschedule_model->get_states();
		$data['country'] = $this->Protestschedule_model->get_country();
		
			/*
			$this->form_validation->set_rules('code', 'Please Enter Code No', 'required');
			$this->form_validation->set_rules('programe_name', 'Please Enter Program Name', 'required');
			$this->form_validation->set_rules('programe_description', 'Program Description Description', 'required');
			$this->form_validation->set_rules('facility_id', 'Please Enter Facility Name', 'required');
			$this->form_validation->set_rules('field_id', 'Please Enter Field Name Name', 'required');
			$this->form_validation->set_rules('nodal_lab_name', 'Please Enter Nodal Lab Name', 'required');
			$this->form_validation->set_rules('contact_person', 'Please Enter Contact Person Name', 'required');
			$this->form_validation->set_rules('city', 'Please Enter City', 'required');
			$this->form_validation->set_rules('country', 'Please Enter Country Name', 'required');
			$this->form_validation->set_rules('last_date_of_registration', 'Please Enter Last Date of Registration', 'required');
			$this->form_validation->set_rules('programme_finish_date', 'Please Enter Program Finish Date', 'required');
			*/		
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->Protestschedule_model->update_pro_test_sch($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Schedule Updated Sucessfullly');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=protestschedule";
			</script>
			<?php
		}
		else
		{
			$this->load->view('templates/header', $data);
			$this->load->view('protestschedule/editschedule');
			$this->load->view('templates/footer');
		}
	}

	public function deleteschedule()
	{     
		$this->load->library('session');    
		if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        
        $this->load->helper('url');
		$data['title'] = 'Delete Proficiency Testing Schedule';
		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->load->view('templates/header', $data);
		$this->load->view('protestschedule/index');
		$this->load->view('templates/footer');
		
		$data['labs'] = $this->Protestschedule_model->get_pro_test_schedule($_GET['id']);
		
		$this->Protestschedule_model->delete_pro_test_sch($_GET['id']);
		$this->load->helper('url');
		?>
		<script>alert('Schedule Deleted Sucessfullly');
		location = "<?php echo $_SERVER['PHP_SELF'];?>?c=protestschedule";
		</script>
		<?php
	}
	
	public function updateStatus()
	{
		$this->load->helper('url');
		$this->load->library('session');
		if(!$this->session->userdata('nabl_user'))
		{
			redirect('c=auth&m=login');
		}
		$status = $_GET['status'];
		$id = $_GET['id'];		
		$this->load->model('Protestschedule_model');
		if($this->Protestschedule_model->update_status($status, $id))
		{
			?>
			<script language="javascript">
			alert('Status Updated Successfully');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=protestschedule";
			</script>
			<?php 
		}
		else
		{
			?>
			<script language="javascript">
			alert('Unable To Update Status');
			location = "<?php echo $_SERVER['PHP_SELF']; ?>?c=protestschedule";
			</script>
			<?php
		}		
	}
	

}