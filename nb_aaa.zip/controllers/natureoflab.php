<?php
class natureoflab extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('natureoflab_model');
	}

	public function index()
	{
		$data['title'] = "Nature of Lab";
		$this->load->library('session');           
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        
		$this->load->helper('url');
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=natureoflab&m=index';
	    $config['total_rows'] = $this->db->count_all('lab_nature_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('natureoflab_model');
	    $data['natureoflab'] = $this->natureoflab_model->get_all_natureoflabs($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('natureoflab/index', $data);
		$this->load->view('templates/footer');
		
	}

	public function view($slug)
	{
			
	}

	public function create()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Add - Nature of Lab';
		//$this->form_validation->set_rules('nature_name', 'Please Nature of Lab Name', 'required');
		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->natureoflab_model->set_natureoflab();
			$this->load->helper('url');
			?>
			<script>alert('Nature of Lab Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=natureoflab";
			</script>
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('natureoflab/create');
			$this->load->view('templates/footer');
		}
	}

	public function edit_natureoflab()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Edit - Nature of Lab';
		$data['natureoflab'] = $this->natureoflab_model->get_natureoflab($_GET['id']);
		//$this->form_validation->set_rules('nature_name', 'Please Nature of Lab Name', 'required');

		if(array_key_exists('submit',$_POST))//($this->form_validation->run() === FALSE)
		{
			$this->natureoflab_model->update_natureoflab($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Nature of Lab Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=natureoflab";
			</script>
			<?php
		}
		else
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('natureoflab/edit_natureoflab');
			$this->load->view('templates/footer');
		}
	}

	public function delete_natureoflab()
	{
		$this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              $this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
        $data['title'] = 'Delete - Nature of Lab';
		$this->load->helper('form');
		$this->load->library('form_validation');
		$data['title'] = 'Delete - Nature of Lab ';
		$this->natureoflab_model->delete_natureoflab($_GET['id']);
		$this->load->helper('url');
		?>
			<script>alert('Nature of Lab Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=natureoflab";
			</script>
		<?php
	}
}