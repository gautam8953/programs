<?php
class Facility extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('facility_model');
	}

	public function index()
	{
		$data['title'] = "Facility";
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
	    $this->load->helper('url');
	    $this->load->library('pagination');
	    $data['pagination']="yes";
	    $config['base_url'] = base_url().'index.php?c=facility&m=index';
	    $config['total_rows'] = $this->db->count_all('facility_tbl');
	    $config['per_page'] = '10';
	    $config['full_tag_open'] = '<p>';
	    $config['full_tag_close'] = '</p>';	
	    $this->pagination->initialize($config);
	    $this->load->model('facility_model');
	    $data['results'] = $this->facility_model->get_lab_all_facility($config['per_page']);
	    $this->load->view('templates/header', $data);
		$this->load->view('facility/index', $data);
		$this->load->view('templates/footer');		
	}

	public function view($slug)
	{
		/*
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        */
        $this->load->helper('url');
		$data['news_item'] = $this->facility_model->get_lab_facility($slug);
		if (empty($data['news_item']))
		{
			show_404();
		}

		$data['title'] = $data['news_item']['facility_name'];

		$this->load->view('templates/header', $data);
		$this->load->view('facility/view', $data);
		$this->load->view('templates/footer');
	}

	public function create()
	{
        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Create a Lab Facility';

		$this->form_validation->set_rules('facility_name', 'Facility Name', 'required');
		$this->form_validation->set_rules('facility_description', 'Description', 'required');

		if ($this->form_validation->run() === FALSE)
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('facility/create');
			$this->load->view('templates/footer');

		}
		else
		{
			$this->facility_model->set_facility();
			$this->load->helper('url');
			?>
			<script>alert('Facility Added');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=facility&m=index";
			</script>
			<?php

		}
	}

	public function editfacility()
	{

        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user'))
        {
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Edit - Lab Facility';
		$data['facility'] = $this->facility_model->get_lab_facility($_GET['id']);

		$this->form_validation->set_rules('facility_name', 'Facility Name', 'required');
		$this->form_validation->set_rules('facility_description', 'text', 'required');

		if ($this->form_validation->run() === FALSE)
		{
			$this->load->helper('url');
			$this->load->view('templates/header', $data);
			$this->load->view('facility/editfacility');
			$this->load->view('templates/footer');

		}
		else
		{
			$this->facility_model->update_facility($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Facility Updated');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=facility";
			</script>
			<?php

		}
	}

	public function deletefacility()
	{

        $this->load->library('session');              
        if(!$this->session->userdata('nabl_user')){
              //$this->load->helper('url');
           redirect('c=auth&m=login');
        }
        $this->load->helper('url');
		$data['title'] = 'Delete Lab Facility';
		$this->load->helper('form');
		$this->load->library('form_validation');

			$this->load->view('templates/header', $data);
			$this->load->view('facility/index');
			$this->load->view('templates/footer');

		$data['title'] = 'Delete Lab Category';
		$data['facility'] = $this->facility_model->get_lab_facility($_GET['id']);



			$this->facility_model->delete_facility($_GET['id']);
			$this->load->helper('url');
			?>
			<script>alert('Facility Deleted');
			location = "<?php echo $_SERVER['PHP_SELF'];?>?c=facility";
			</script>
			<?php


	}

}