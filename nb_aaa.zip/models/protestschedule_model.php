<?php
class Protestschedule_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_all_profTestSchedule($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('proficiency_testing_schedule_tbl', $num, $offset);
		return $query->result_array();
	}
	
	public function get_active_profTestSchedule($num)
	{
		$offset = $this->input->get('per_page');		
		$query = $this->db->select("*");
		$query = $this->db->from("proficiency_testing_schedule_tbl");
		$query = $this->db->where('status',1);
		$query = $this->db->get('', $num, $offset);
		return $query->result_array();
	}
	
	public function get_pro_test_schedule($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('proficiency_testing_schedule_tbl');
			return $query->result_array();
		}
		$query = $this->db->select("pts.*,fac.category_name as facilityName, fd.category_name as fieldName, c.name as cityName, s.name as stateName, ctry.name as countryName ");
		$query = $this->db->from('proficiency_testing_schedule_tbl as pts');
		$query = $this->db->join('lab_category_tbl as fac','pts.facility=fac.id');
		$query = $this->db->join('lab_category_tbl as fd','pts.field_id=fd.id');
		$query = $this->db->join('cities as c','pts.city_id=c.id');
		$query = $this->db->join('states as s','pts.state_id=s.id');
		$query = $this->db->join('country as ctry','pts.county=ctry.id');
		$query = $this->db->get_where('proficiency_testing_schedule_tbl', array('pts.id' => $id));
		return $query->row_array();
	}
	
	public function get_facility($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('facility_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('facility_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function get_field($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('facility_fields_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('facility_fields_tbl', array('facility_id' => $id));		
		return $query->row_array();
	}
	
	
	public function get_states($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('states');
			return $query->result_array();
		}
		$query = $this->db->get_where('states', array('id' => $id));	
		return $query->row_array();
	}
	
	public function get_city($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('cities');
			return $query->result_array();
		}
		$query = $this->db->get_where('cities', array('id' => $id));		
		return $query->row_array();
	}
	
	public function get_country($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('country');
			return $query->result_array();
		}

		$query = $this->db->get_where('country', array('id' => $id));		
		return $query->row_array();
	}
	
	
	public function set_pro_test_sch()
	{		
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		$ldregnDate = "0000-00-00";
		$pfDate = "0000-00-00";
		if($this->input->post('last_date_of_registration')!="")
		{
			$ldregnDate = explode('-',$this->input->post('last_date_of_registration'));
			$ldregnDate = array_reverse($ldregnDate);	
			$ldregnDate = implode('-',$ldregnDate);
		}
		if($this->input->post('programme_finish_date')!="")
		{
			$pfDate = explode('-',$this->input->post('programme_finish_date'));
			$pfDate = array_reverse($pfDate);	
			$pfDate = implode('-',$pfDate);	
		}		
		$data = array(
						'code' => $this->input->post('code'),
						'programe_name' => $this->input->post('programe_name'),
						'programe_description' => $this->input->post('programe_description'),
						'facility' => $this->input->post('facility_id'),
						'field_id' => $this->input->post('field_id'),		
						'nodal_lab_name' => $this->input->post('nodal_lab_name'),
						'contact_person' => $this->input->post('contact_person'),
						'designation' => $this->input->post('designation'),
						'contact_address' => $this->input->post('contact_address'),
						'city_id' => $this->input->post('city'),
						'state_id' => $this->input->post('state'),
						'county' => $this->input->post('country'),	
						'pin' => $this->input->post('pin'),	
						'phone' => $this->input->post('phone'),	
						'fax' => $this->input->post('fax'),	
						'emailid' => $this->input->post('emailid'),
						'last_date_of_registration' => $ldregnDate,
						'programme_finish_date' => $pfDate,
						'status'=>1,
						'createdby' => '1'
		);
		return $this->db->insert('proficiency_testing_schedule_tbl', $data);
	}

	public function update_pro_test_sch($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);	
		$ldregnDate = explode('-',$this->input->post('last_date_of_registration'));
		$ldregnDate = array_reverse($ldregnDate);	
		$ldregnDate = implode('-',$ldregnDate);		
		
		$pfDate = explode('-',$this->input->post('programme_finish_date'));
		$pfDate = array_reverse($pfDate);
		$pfDate = implode('-',$pfDate);
			
		$data = array(
						'code' => $this->input->post('code'),
						'programe_name' => $this->input->post('programe_name'),
						'programe_description' => $this->input->post('programe_description'),
						'facility' => $this->input->post('facility_id'),
						'field_id' => $this->input->post('field_id'),		
						'nodal_lab_name' => $this->input->post('nodal_lab_name'),
						'contact_person' => $this->input->post('contact_person'),
						'designation' => $this->input->post('designation'),
						'contact_address' => $this->input->post('contact_address'),
						'city_id' => $this->input->post('city'),
						'state_id' => $this->input->post('state'),
						'county' => $this->input->post('country'),	
						'pin' => $this->input->post('pin'),	
						'phone' => $this->input->post('phone'),	
						'fax' => $this->input->post('fax'),	
						'emailid' => $this->input->post('emailid'),
						'last_date_of_registration' => $ldregnDate,
						'programme_finish_date' => $pfDate,
						'createdby' => '1'
		);
		return $this->db->update('proficiency_testing_schedule_tbl', $data, array('id'=>$id));
	}

	public function delete_pro_test_sch($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		return $this->db->delete('proficiency_testing_schedule_tbl',  array('id'=>$id));
	}
	
	public function update_status($status, $id)
	{		
		//$this->load->helper('url');
		if($status==1)
		{
			if($this->db->update('proficiency_testing_schedule_tbl', array('status'=>0), array('id'=>$id)))
					return true;
			else 
					return false;	
		}
		if($status==0)
		{
			if($this->db->update('proficiency_testing_schedule_tbl', array('status'=>1), array('id'=>$id)))
					return true;
			else 
					return false;
		}		
	}
}