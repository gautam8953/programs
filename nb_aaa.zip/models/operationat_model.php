<?php
class operationat_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_all_operationat($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('lab_operations_tbl', $num, $offset);	
		return $query->result_array();
	}

	public function get_operationat($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('lab_operations_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('lab_operations_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function set_operationat()
	{
		$this->load->helper('url');		
		$data = array(
			'operation_name' => $this->input->post('operation_name'),
			'createdby' => '1'			
		);
		return $this->db->insert('lab_operations_tbl', $data);
	}

	public function update_operationat($id)
	{
		$this->load->helper('url');
		$data = array(
			'operation_name' => $this->input->post('operation_name'),
			'modifiedby' => '1',
			'modifiedon' => date('Y-m-d h:i:s')
		);
		return $this->db->update('lab_operations_tbl', $data, array('id'=>$id));
	}

	public function delete_operationat($id)
	{
		$this->load->helper('url');		
		return $this->db->delete('lab_operations_tbl',  array('id'=>$id));
	}
	
	public function selectAllOperationAt($order='', $sort='')
    {        
    	 //$query = $this->db->get_where('group_tbl', array('id' => $id));
         $query = $this->db->get('lab_operations_tbl');
         if($sort=='')
         {
            $sort = 'ASC';
         }         
         if($order!='')
         {
            $this->db->order_by($order, $sort);  
         }        
         return $query->result_array(); 
        
    }
}