<?php
class search_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_lab($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('laboratory_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('laboratory_tbl', array('id' => $id));	
		return $query->row_array();
	}
	
	public function get_zone($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('zone_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('zone_tbl', array('id' => $id));	
		return $query->row_array();
	}
	
	public function get_natureoflab($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('lab_nature_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('lab_nature_tbl', array('id' => $id));	
		return $query->row_array();
	}
	
	public function get_operationAt($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('lab_operations_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('lab_operations_tbl', array('id' => $id));	
		return $query->row_array();
	}
	
	public function get_facility($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('facility_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('facility_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function search($limit='')
	{		
		$curdate = date("Y-m-d");
		$offset = $this->input->get('per_page');
		$likearray = array();
		$anlikearray=array();
		$array = array();
		$columnNames = '';
		$this->load->helper('url');
		$this->load->library('session');
		
		if(array_key_exists('submit',$_POST))
		{		
			
			$labName = $this->input->post('labname');
			$location = $this->input->post('location');
			$zone = $this->input->post('zone');
			$searchword = $this->input->post('searchword');
			$nature_of_lab = $this->input->post('natureoflab');
			$operationAt = $this->input->post('operationat');
			$operationAtstr = '';
			if(count($operationAt)>0 && $operationAt!="")
			{
				foreach($operationAt as $key=>$value)
				$operationAtstr .= $value.",";
			}
			$facility_id = $this->input->post('facility_id');	
			$field_id = $this->input->post('field_id');
			$group_id = $this->input->post('group_id');
			$subgroup = $this->input->post('subgroup');
			$subgroup_id = '';			
			if(count($subgroup)>0 && $subgroup!="")
			{
				foreach($subgroup as $key=>$value)
				{
					$subgroup_id .= $value.",";
				}
			}			
			$params = array('labName1'=>$labName,
	        					    'location1'       => $location,
								    'zone1'           => $zone,
									'searchword'     => $searchword,
								    'nature_of_lab1'  => $nature_of_lab,	
								    'operationAtstr1' => $operationAtstr,
								    'facility_id1'    => $facility_id,
									'field_id1'       => $field_id,
									'group_id1'       => $group_id,
									'subgroup_id1'    => $subgroup_id,
					
							);
	        $this->session->set_userdata($params);
	   }
	   else
	   {
	   		//Set all values to session				        
	        $labName = $this->session->userdata('labName1');
			$location = $this->session->userdata('location1');
			$searchword = $this->session->userdata('searchword1');
			$zone = $this->session->userdata('zone1');	
			$nature_of_lab = $this->session->userdata('nature_of_lab1');
			$operationAtstr = $this->session->userdata('operationAtstr1');
			$facility_id = $this->session->userdata('facility_id1');
			$field_id = $this->session->userdata('field_id1');
			$group_id = $this->session->userdata('group_id1');
			$subgroup_id = $this->session->userdata('subgroup_id1');	        
	   }
	   $tmpsubGroupArr = explode(",",$subgroup_id);	  
	   $subGroupVal = ",";
	   for($d=0;$d<count($tmpsubGroupArr);$d++)
	   {
	   		$tmpsArr = explode("-",$tmpsubGroupArr[$d]);
	   		$subGroupVal .= $tmpsArr[0];
	   }	  
        //echo "Lab Name Input Data - ".$this->session->userdata('labName');
		if($labName!="")
		{
			$likearray['l.lab_name'] = $labName;
			//$anlikearray['c.file_content'] = $labName;
		}	
		/*		
		if($location!="")
			$likearray['l.lab_address']= $location;	
		*/
		if($zone!="-1")
			$array['l.zone']= $zone;
		if($searchword!="")
			$likearray['LOWER(c.file_content)'] = 	strtolower($searchword);
		if($nature_of_lab!="-1")
			$array['c.nature_of_lab']= $nature_of_lab;	
		if($operationAtstr!="")		
			$array['c.operationat']= $operationAtstr;
		if($subgroup_id!="")
		{	
			$array['c.sub_group_id']= $subGroupVal;	
		}	
		if($group_id!="-1" && $subgroup_id=="")	
			$array['c.group_id']= $group_id;
		if($field_id!="-1" && $group_id=="-1" && $subgroup_id=="")	
			$array['c.filed_id']= $field_id;		
		if($facility_id!="-1" && $field_id=="-1" && $group_id=="-1" && $subgroup_id=="")		
			$array['c.faclity_id']= $facility_id;
			
		$array['c.status']=1;
		$array['l.status']=1;
		
		//$this->db->select('l.id, l.lab_name, l.lab_registration_code, l.lab_address, l.pincode, l.contact_person, l.designation, l.phone, l.emailid, l.fax, getOperationName(c.id) as opertaionAtName, c.expiry_date, c.status, city.name as cityName, s.name as stateName, ctry.name as countryName, ln.nature_name, z.zone_name');//'c.lab_id, c.certificate_no, c.certificate_file, c.issue_date, c.expiry_date, l.lab_name, l.lab_address, l.zone,f.facility_name'
		$this->db->select('l.id, l.lab_name, l.lab_registration_code, l.lab_address, l.pincode, l.contact_person, l.designation, l.phone, l.emailid, l.fax, city.name as cityName, s.name as stateName, ctry.name as countryName, z.zone_name');
		$this->db->distinct('l.lab_registration_code');
		$this->db->from('laboratory_tbl As l');
		$this->db->join('lab_certificate_tbl As c', 'c.lab_id=l.id');//		
		$this->db->join('cities As city', 'l.city=city.id', 'left');//
		$this->db->join('states As s', 'l.state=s.id', 'left');//
		$this->db->join('country As ctry', 'l.country=ctry.id', 'left');//		
		$this->db->join('zone_tbl As z', 'l.zone=z.id', 'left');//
		
		//$this->db->join('lab_nature_tbl As ln', 'c.nature_of_lab=ln.id', 'left');//
		//$this->db->join('lab_operations_tbl As oa', 'c.operationat=oa.id', 'left');//
		
		if($subgroup_id!="")
		{	}
		
		if($group_id!="-1" && $subgroup_id=="")
		{	}
		
		if($field_id!="-1" && $group_id=="-1" && $subgroup_id=="")
		{   }
		
		if($facility_id!="-1" && $field_id=="-1" && $group_id=="-1" && $subgroup_id=="")
		{	}	
		
			
		$this->db->where($array);			
	    $this->db->where('c.expiry_date >=',$curdate);
		//$this->db->or_where('c.expiry_date IS NULL',NULL);
		$this->db->like($likearray);
		if($location!="")
			{
				 $this->db->like('l.lab_address',$location);
				 $this->db->or_like('s.name',$location);
				 $this->db->or_like('city.name',$location);				 
			}
						
		$this->db->order_by('l.lab_registration_code','l.lab_name');
						
		if($limit!="")
		{
			$query = $this->db->get('',$limit,$offset);
		}	
		else 
		{
			$query = $this->db->get();
		}  		
	    return $query->result_array();  
	}
	public function searchcertificateresult()
	{		
				
		$labid = $this->input->get('cno');
		//die();
		$this->db->select("*, c.id as cid, f.id, f.category_name as facilityName, fd.id, fd.category_name as fieldName");	
		//$this->db->select("getSubGroupName(c.id,c.group_id) As subGroupName",false);		
		$this->db->from('certificate_operation_and_subgroup_tbl As labcer');
		$this->db->join('lab_certificate_tbl As c', 'labcer.certificate_id=c.id');//
		$this->db->join('laboratory_tbl As l', 'c.lab_id=l.id');					
		//$this->db->join('lab_category_tbl As g', 'c.group_id=g.id');	
		$this->db->join('lab_category_tbl As fd', 'c.filed_id=fd.id');
		$this->db->join('lab_category_tbl As f', 'c.faclity_id=f.id');
		$this->db->join('zone_tbl As z', 'l.zone=z.id');//
		$this->db->join('lab_nature_tbl As ln', 'c.nature_of_lab=ln.id');//
		$this->db->join('lab_operations_tbl As oa', 'c.operationat=oa.id');//
		
		$this->db->where('c.lab_id',$labid);
                $this->db->where('c.status',"1");
		$query = $this->db->get();
		return $query->result_array();		
	
		
	}
	public function searchcertificate()
	{		
				
		$labid = $this->input->get('cno');
		//die();
		$this->db->select("*, c.id as cid, f.id, f.category_name as facilityName, fd.id, fd.category_name as fieldName");	
		//$this->db->select("getSubGroupName(c.id,c.group_id) As subGroupName",false);		
		$this->db->from('certificate_operation_and_subgroup_tbl As labcer');
		$this->db->join('lab_certificate_tbl As c', 'labcer.certificate_id=c.id');//
		$this->db->join('laboratory_tbl As l', 'c.lab_id=l.id');					
		//$this->db->join('lab_category_tbl As g', 'c.group_id=g.id');	
		$this->db->join('lab_category_tbl As fd', 'c.filed_id=fd.id');
		$this->db->join('lab_category_tbl As f', 'c.faclity_id=f.id');
		$this->db->join('zone_tbl As z', 'l.zone=z.id');//
		$this->db->join('lab_nature_tbl As ln', 'c.nature_of_lab=ln.id');//
		$this->db->join('lab_operations_tbl As oa', 'c.operationat=oa.id');//
		
		$this->db->where('c.lab_id',$labid);
		$query = $this->db->get();
		return $query->result_array();		
	
		
	}
	
	public function viewGroupSubGroup($certificateid='')
	{
		//$certificateid = $this->input->get('cno');
		$this->db->select("csgt.certificate_id , csgt.group_id, gt.category_name as groupName");
		$this->db->select(",getGroupSubGroupName(csgt.certificate_id, csgt.group_id) As subGroupName",false);
		$this->db->distinct('csgt.group_id');
		$this->db->from('certificate_sub_group_tbl AS csgt');
		$this->db->join('lab_category_tbl AS gt','csgt.group_id=gt.id');
		$this->db->where('csgt.certificate_id',$certificateid);
		$this->db->group_by('csgt.group_id','csgt.certificate_id');
		$this->db->order_by('csgt.group_id','csgt.certificate_id');
		$query = $this->db->get();
		return $query->result_array();
	}
	
}