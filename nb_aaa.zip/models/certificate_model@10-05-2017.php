<?php
class Certificate_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_all_labs_contains_certificates($num)
	{
		$offset = $this->input->get('per_page');
		$query = $this->db->select('l.id, l.lab_registration_code, l.lab_name');
		$query = $this->db->distinct('l.id');
		$query = $this->db->from('lab_certificate_tbl as c');
		$query = $this->db->join('laboratory_tbl as l','c.lab_id=l.id','inner');
		if($this->input->post('labcode')!="")		    
		    	$query = $this->db->where('l.lab_registration_code',$this->input->post('labcode'));		  	    	    
		if($this->input->post('labname')!="")		   
		    	$query = $this->db->like('l.lab_name',$this->input->post('labname'));		
		if($this->input->post('certificateno')!="")
		    	$query = $this->db->where('c.certificate_no',$this->input->post('certificateno'));
		
		$query = $this->db->order_by('l.lab_registration_code');
		$query = $this->db->get('', $num, $offset);
		return $query->result_array();
	}
	
	public function count_all_labs_contains_certificates()
	{		
		//$offset = $this->input->get('per_page');
		$query = $this->db->select('l.id, l.lab_registration_code, l.lab_name');
		//$query = $this->db->distinct('l.id');
		$query = $this->db->from('lab_certificate_tbl as c');
		$query = $this->db->join('laboratory_tbl as l','c.lab_id=l.id','inner');
		if($this->input->post('labcode')!="")		    
		    	$query = $this->db->where('l.lab_registration_code',$this->input->post('labcode'));		  	    	    
		if($this->input->post('labname')!="")		   
		    	$query = $this->db->like('l.lab_name',$this->input->post('labname'));
		if($this->input->post('certificateno')!="")
		    	$query = $this->db->where('c.certificate_no',$this->input->post('certificateno'));
		$query = $this->db->order_by('l.lab_registration_code');
		$query = $this->db->get('');
		return $query->result_array();
	}
	
	public function get_certificates_by_labid($labid)
	{		
		$query = $this->db->select('l.id, l.lab_name, l.lab_registration_code, c.id as cid, c.lab_id,  c.certificate_no, c.faclity_id, c.filed_id, c.issue_date, c.expiry_date, c.status ,fac.category_name as facilityName, fd.category_name as fieldName');
		$query = $this->db->from('lab_certificate_tbl as c');
		$query = $this->db->join('laboratory_tbl as l','c.lab_id=l.id' ,'inner');
		$query = $this->db->join('lab_category_tbl as fac','c.faclity_id=fac.id','left');
		$query = $this->db->join('lab_category_tbl as fd','c.filed_id=fd.id' ,'left');
		
		if($this->input->post('labcode')!="")		    
		    	$query = $this->db->where('l.lab_registration_code',$this->input->post('labcode'));		  	    	    
		if($this->input->post('labname')!="")		   
		    	$query = $this->db->like('l.lab_name',$this->input->post('labname'));
		if($this->input->post('certificateno')!="")
		    	$query = $this->db->where('c.certificate_no',$this->input->post('certificateno'));
		    	
		$query = $this->db->where('c.lab_id',$labid);	
		$query = $this->db->order_by('c.certificate_no');
		$query = $this->db->get('');	
		return $query->result_array();
	}
	
	public function get_ExpiredAccreditation($num)
	{
		date_default_timezone_set ('Asia/Kolkata');
		$currDate = date('Y-m-d');
		$offset = $this->input->get('per_page');
		$whereCond = array('expiry_date <'=>$currDate);
		$this->db->select('c.certificate_no,c.expiry_date , d.category_name as discipline ,l.lab_name, l.lab_registration_code, l.lab_address');
		$this->db->from('lab_certificate_tbl as c');
		$this->db->join('laboratory_tbl as l','c.lab_id=l.id' ,'left');
		$this->db->join('lab_category_tbl as d','c.filed_id=d.id' ,'left');
		$this->db->where($whereCond);
		$this->db->order_by('l.lab_registration_code');
		$query = $this->db->get('',$num,$offset);
		return $query->result_array();
	}
	
	public function count_ExpiredAccreditation()
	{
		date_default_timezone_set ('Asia/Kolkata');
		$currDate = date('Y-m-d');		
		$whereCond = array('expiry_date <'=>$currDate);
		$this->db->select('c.certificate_no, l.lab_name, l.lab_registration_code, l.lab_address');
		$this->db->from('lab_certificate_tbl as c');
		$this->db->join('laboratory_tbl as l','c.lab_id=l.id' ,'left');
		$this->db->where($whereCond);
		$query = $this->db->get();
		return $query->result_array();
	}
	
	
	
	public function get_certificate_details($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->select('*');
			$query = $this->db->from('lab_certificate_tbl');
			$query = $this->db->where('status',1);
			$query = $this->db->order_by('certificate_no');
			$query = $this->db->get('');
			return $query->result_array();
		}

		$query = $this->db->select('c.*, csgt.certificate_id, c.sub_group_id as subgroupid');
		$query = $this->db->select("getSubGroupName(c.id) As subGroupName",false);
		$query = $this->db->from('lab_certificate_tbl as c');		
		$query = $this->db->join('certificate_sub_group_tbl as csgt','c.id=csgt.certificate_id' ,'left');
		$query = $this->db->where('c.id',$id);
		$query = $this->db->get();
		//print_r($query->row_array());
		//die();
		return $query->row_array();
	}
	
 	public function get_lab_field($id = FALSE)
    {
        if ($id === FALSE)
        {
                          
            $query = $this->db->select('t1.*, t2.facility_name')
                          ->from('facility_fields_tbl AS t1, facility_tbl AS t2')
                          ->where('t1.facility_id = t2.id');                        
            $query = $this->db->get();
            return $query->result_array();
        }
        
        $query = $this->db->select('t1.*, t2.facility_name')
                          ->from('facility_fields_tbl AS t1, facility_tbl AS t2')
                          ->where('t1.facility_id = t2.id')                    
                          ->where('t1.id',$id);
        $query = $this->db->get();
        return $query->row_array();
    }
	
	
	public function get_lab($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->select('*');
			$query = $this->db->from('laboratory_tbl');			
			$query = $this->db->where('status',1);
			$query = $this->db->order_by('lab_registration_code','lab_name');
			$query = $this->db->get('');
			return $query->result_array();
		}

		$query = $this->db->get_where('laboratory_tbl', array('id' => $id));	
		return $query->row_array();
	}
	
	public function get_natureoflab($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('lab_nature_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('lab_nature_tbl', array('id' => $id));	
		return $query->row_array();
	}
	
	public function get_operationAt($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('lab_operations_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('lab_operations_tbl', array('id' => $id));	
		return $query->row_array();
	}
	
	public function get_facility($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('facility_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('facility_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function set_certificate()
	{
		$this->load->helper('url');
		$arrmsg = array();
	    if($this->checkUniqueCertificate($this->input->post('certificate_no')))
		{
			$arrmsg['duplicate'] = "duplicate";
			return $arrmsg;
		}
		else 
		{
				//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);		
				$issuedate = explode('-',$this->input->post('issue_date'));
				$issuedate = array_reverse($issuedate);	
				$issuedate = implode('-',$issuedate);
				
				$expiryDate = explode('-',$this->input->post('expiry_date'));
				$expiryDate = array_reverse($expiryDate);
				$expiryDate = implode('-',$expiryDate);
				
				$ext1 = $this->get_file_extension($_FILES['certificatedoc']['name']);
				//$file_namewithoutExt1 =  basename($_FILES['certificatedoc']['name'],'.'.$ext1);			
			    //$newcertificateFileName =   $this->input->post('certificate_no').".".$ext1;
				//print_r($this->input->post('operationat'));
				
				$operationAt = $this->input->post('operationat');
				$operationAtstr[] = array();
				$operationAts = "";
				if(count($operationAt)>0)
				{
					foreach($operationAt as $key=>$value)
					{
						$operationAtstr[$key] = $value;
						$operationAts .= $value.",";				
					}			
				}
				$temparr = array();
				//$subgroup = $this->input->post('multiplesubgroups');
				$subgroupList =array();				
				$subgroup = "";				
				$subgroupList = $this->input->post('subgroupsList');				
				for($p=0;$p<count($subgroupList);$p++)
				{
					$subgroup .= ",".$subgroupList[$p];
				}		

				
				$subgroupstr = array();		
				$tempsubgrouparr = explode(",",$subgroup);
				if(count($tempsubgrouparr)>0)
				{
					for($i=1;$i<count($tempsubgrouparr);$i++)
					{				
						$subgroupstr[]= $tempsubgrouparr[$i];	
					}
				}
				$data = array(
								'lab_id' => $this->input->post('lab_id'),
								'certificate_no' => $this->input->post('certificate_no'),
								//'certificate_file' => $newcertificateFileName,
								'issue_date' => $issuedate,
								'expiry_date' => $expiryDate,
								'operationat'=>$operationAts,
								'sub_group_id'=>$subgroup,
								'nature_of_lab' => $this->input->post('nature_of_lab'),						
								'faclity_id' => $this->input->post('facility_id'),
								'filed_id' => $this->input->post('field_id'),
								'group_id' => $this->input->post('group_id'),
								'status'=>1,																
								'createdby' => '1'
				);	

				
				//$this->db->insert('lab_certificate_tbl', $data);
				//$certificateid = $this->db->insert_id();
				if($this->db->insert('lab_certificate_tbl', $data))
				{
					$arrmsg['success']="success";
					$arrmsg['cid']=$this->db->insert_id();	
					$certificateid = $this->db->insert_id();
					for($l=0;$l<count($operationAtstr);$l++)
					{
						$operationatdata = array(
											'certificate_id'=>$certificateid,'operation_at'=>$operationAtstr[$l]);

						$this->db->insert('certificate_operation_at_tbl', $operationatdata);					
					}
					
					for($k=0;$k<count($subgroupstr);$k++)
					{
						$arr = explode('_',$subgroupstr[$k]);
						$subgroupdata = array(
											'certificate_id'=>$certificateid,
											'group_id'=>$arr[0],
											'sub_group_id'=>$arr[1]
											);
						$this->db->insert('certificate_sub_group_tbl', $subgroupdata);				
					}
					
					$data1 = array(
									'certificate_id' => $certificateid,	
									'type'=> $ext1,												
									'createby' => '1'
					);				
					$this->db->insert('certificate_operation_and_subgroup_tbl', $data1);								
					return $arrmsg;
				}
				else 
				{
					$arrmsg['unsuccess'] = "unsuccess";
					return $arrmsg;
				}				
		}
		
	}

	public function update_certificate($id,$filecontent='')
	{			
		$ext1 = $this->get_file_extension($_FILES['certificatedoc']['name']);
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);		
		$issuedate = explode('-',$this->input->post('issue_date'));
		$issuedate = array_reverse($issuedate);	
		$issuedate = implode('-',$issuedate);
		
		$expiryDate = explode('-',$this->input->post('expiry_date'));
		$expiryDate = array_reverse($expiryDate);
		$expiryDate = implode('-',$expiryDate);
		
			
		$operationAt = $this->input->post('operationat');
		$operationAtstr[] = array();
		$operationAts = "";
		if(count($operationAt)>0)
		{
			foreach($operationAt as $key=>$value)
			{
				$operationAtstr[$key] = $value;
				$operationAts .=$value.",";
			}
		}
			
		$temparr = array();
		//$subgroup = $this->input->post('multiplesubgroups');
		$subgroupList =array();				
		$subgroup = "";				
		$subgroupList = $this->input->post('subgroupsList');	
		//print_r($subgroupList);			
		for($p=0;$p<count($subgroupList);$p++)
		{
			$subgroup .= ",".$subgroupList[$p];
		}		
		$subgroup = str_replace('<br/>','',$subgroup);
		//echo "Sub Group - ".$subgroup;
		//die();
		$subgroupstr = array();		
		$tempsubgrouparr = explode(",",$subgroup);
		if(count($tempsubgrouparr)>0)
		{
			for($i=1;$i<count($tempsubgrouparr);$i++)
			{				
				$subgroupstr[]= $tempsubgrouparr[$i];	
			}
		}

		if($filecontent!="")
		{
			$data = array(
						'lab_id' => $this->input->post('lab_id'),
						'certificate_no' => $this->input->post('certificate_no'),
						'certificate_file' => $id.".".$ext1,
						'file_content' => $filecontent,
						'issue_date' => $issuedate,
						'expiry_date' => $expiryDate,
						'operationat'=>$operationAts,
						'sub_group_id'=>$subgroup,	
						'nature_of_lab' => $this->input->post('nature_of_lab'),						
						'faclity_id' => $this->input->post('facility_id'),
						'filed_id' => $this->input->post('field_id'),
						'group_id' => $this->input->post('group_id'),										
						'modifiedby' => '1',
						'modifiedon' => date('Y-m-d h:i:s')
						);
		}
		else 
		{
			$data = array(
						'lab_id' => $this->input->post('lab_id'),
						'certificate_no' => $this->input->post('certificate_no'),						
						'issue_date' => $issuedate,
						'expiry_date' => $expiryDate,
						'nature_of_lab' => $this->input->post('nature_of_lab'),		
						'operationat'=>$operationAts,
						'sub_group_id'=>$subgroup,				
						'faclity_id' => $this->input->post('facility_id'),
						'filed_id' => $this->input->post('field_id'),
						'group_id' => $this->input->post('group_id'),											
						'modifiedby' => '1',
						'modifiedon' => date('Y-m-d h:i:s')
						);
		}
		
		if($this->db->delete('certificate_operation_at_tbl',  array('certificate_id'=>$id)))
		{print_r($operationAtstr);
			for($l=0;$l<count($operationAtstr);$l++)
			{
				$operationatdata = array(
								'certificate_id'=>$id,								
								'operation_at'=>$operationAtstr[$l]
								); //die();
				$this->db->insert('certificate_operation_at_tbl', $operationatdata);					
			}
		}
				
		if($this->db->delete('certificate_sub_group_tbl',  array('certificate_id'=>$id)))
		{
			for($k=0;$k<count($subgroupstr);$k++)
			{
				$arr = explode('_',$subgroupstr[$k]);
				$subgroupdata = array(
									'certificate_id'=>$id,
									'group_id' => $arr[0],
									'sub_group_id'=>$arr[1]
									);
				$this->db->insert('certificate_sub_group_tbl', $subgroupdata);					
			}
		}
		
		if($this->db->delete('certificate_operation_and_subgroup_tbl',  array('certificate_id'=>$id)))
		{
				$data1 = array(
									'certificate_id' => $id,	
									'type'=> $ext1,												
									'createby' => '1'
					          );				
			    $this->db->insert('certificate_operation_and_subgroup_tbl', $data1);
		}
		else 
		{
			    $data1 = array(
									'certificate_id' => $id,	
									'type'=> $ext1,												
									'createby' => '1'
					          );				
			    $this->db->insert('certificate_operation_and_subgroup_tbl', $data1);
		}

		
		return $this->db->update('lab_certificate_tbl', $data, array('id'=>$id));
	}

	public function delete_certificate($id)
	{
		$this->load->helper('url');
		$result = $this->db->delete('certificate_operation_and_subgroup_tbl',  array('certificate_id'=>$id));
		if($result)
		{
			return $this->db->delete('lab_certificate_tbl',  array('id'=>$id));
		}
	}
	
	function get_file_extension($file_name) 
	{
		return end(explode('.',$file_name));
	}
	
	function updateCertificateDocument($certificateid,$text)
	{		
		$ext = $this->get_file_extension($_FILES['certificatedoc']['name']);		
		$data2 = array(						
						'certificate_file' => $certificateid.".".$ext,
						'file_content'=> $text
		);
		return $this->db->update('lab_certificate_tbl', $data2, array('id'=>$certificateid));
	}
	
	public function update_status($status, $id)
	{		
		//$this->load->helper('url');
		if($status==1)
		{
			if($this->db->update('lab_certificate_tbl', array('status'=>0), array('id'=>$id)))
					return true;
			else 
					return false;	
		}
		if($status==0)
		{
			if($this->db->update('lab_certificate_tbl', array('status'=>1), array('id'=>$id)))
					return true;
			else 
					return false;
		}		
	}
	
	public function viewCertificate()
	{		
		$certificateid = $this->input->get('cno');
		//die();
		$this->db->select("*, f.id, f.category_name as facilityName, fd.id, fd.category_name as fieldName");	
		//$this->db->select("getSubGroupName(c.id,c.group_id) As subGroupName",false);		
		$this->db->from('certificate_operation_and_subgroup_tbl As labcer');
		$this->db->join('lab_certificate_tbl As c', 'labcer.certificate_id=c.id');//
		$this->db->join('laboratory_tbl As l', 'c.lab_id=l.id');					
		//$this->db->join('lab_category_tbl As g', 'c.group_id=g.id');	
		$this->db->join('lab_category_tbl As fd', 'c.filed_id=fd.id');
		$this->db->join('lab_category_tbl As f', 'c.faclity_id=f.id');
		$this->db->join('zone_tbl As z', 'l.zone=z.id');//
		$this->db->join('lab_nature_tbl As ln', 'c.nature_of_lab=ln.id');//
		$this->db->join('lab_operations_tbl As oa', 'c.operationat=oa.id');//
		
		$this->db->where('c.id',$certificateid);
		$query = $this->db->get();
		return $query->result_array();		
	}
	
	public function viewGroupSubGroup()
	{
		$certificateid = $this->input->get('cno');
		$this->db->select("csgt.group_id, gt.category_name as groupName");
		$this->db->select(",getGroupSubGroupName(csgt.certificate_id, csgt.group_id) As subGroupName",false);
		$this->db->from('certificate_sub_group_tbl AS csgt');
		$this->db->join('lab_category_tbl AS gt','csgt.group_id=gt.id');
		$this->db->where('csgt.certificate_id',$certificateid);
		$this->db->group_by('csgt.group_id','csgt.certificate_id');
		$this->db->order_by('csgt.group_id','csgt.certificate_id');
		$query = $this->db->get();
		return $query->result_array();
	}
	public function checkUniqueCertificate($cno)
	{
		$query01 = $this->db->get_where('lab_certificate_tbl', array('certificate_no'=>$cno));
		return $query01->row_array();
	}
	
	public function get_all_certificate()
	{	
		$query = $this->db->select('*');
		$query = $this->db->from('lab_certificate_tbl');
		$query = $this->db->order_by('certificate_no');
		$query = $this->db->get('');
		return $query->result_array();
	}
}