<?php
class lab_accreditation_under_abeyance_model extends CI_Model
{
	public function __construct()
	{
		$this->load->database();
	}
	
	
	public function get_all_LabAccUnderAbeyance($limit)
	{
		$offset = $this->input->get('per_page');
		
		$this->db->select('laua.id, laua.remark, l.lab_name, l.lab_registration_code, c.certificate_no');
		$this->db->from('lab_accreditation_under_abeyance_tbl As laua');
		$this->db->join('laboratory_tbl As l', 'laua.lab_id=l.id', 'left');
		$this->db->join('lab_certificate_tbl As c', 'laua.certificate_id=c.id', 'left');		
	    $this->db->order_by('l.lab_registration_code');
		if($limit!="")
		{
			$query = $this->db->get('',$limit,$offset);
		}	
		else 
		{
			$query = $this->db->get();
		}	  
		
		return $query->result_array();  
		
	}

	public function get_LabAccUnderAbeyance($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('lab_accreditation_under_abeyance_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('lab_accreditation_under_abeyance_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	
	public function setLabAccUnderAbeyance()
	{
		$this->load->helper('url');		
		$str = explode("|", $this->input->post('cno'));
		$cid = $str[0];
		$data = array(
            'lab_id' => $this->input->post('lab_id'),
            'certificate_id' => $cid,
        	'remark' => $this->input->post('remark'),        
            'createdby' => '1'    
        );
        return $this->db->insert('lab_accreditation_under_abeyance_tbl', $data);
	}
	
	
	public function updateLabAccUnderAbeyance($id)
	{
		$this->load->helper('url');
		$str = explode("|", $this->input->post('cno'));
		$cid = $str[0];
        $data = array(
            'lab_id' => $this->input->post('lab_id'),
            'certificate_id' => $cid,
        	'remark' => $this->input->post('remark'),        
            'createdby' => '1'           
        );
        return $this->db->update('lab_accreditation_under_abeyance_tbl', $data, array('id'=>$id));
	}
	
	public function deleteLabAccUnderAbeyance($id)
	{
		$this->load->helper('url');
		return $this->db->delete('lab_accreditation_under_abeyance_tbl',  array('id'=>$id));
	}
	
	
}