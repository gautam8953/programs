<?php

class News_model extends CI_Model {



	public function __construct()

	{		

		$this->load->database();

	}



	public function get_lab_all_news($num)

	{		

		$offset = $this->input->get('per_page');		

		$query = $this->db->get('jos_clip_details_tbl', $num, $offset);	

		return $query->result_array();

	}

	

	public function get_lab_all_news_announcement($num, $newstype)

	{		

		

		$offset = $this->input->get('per_page');

		$query = $this->db->select('*');

		$query = $this->db->from('jos_clip_details_tbl');

		if($newstype=="both")

		{

			

		}

		else 

		{

			$query = $this->db->where('clip_type',$newstype);

		}		

		$query = $this->db->get('', $num, $offset);		

		return $query->result_array();

	}

	
		public function get_lab_active_news_announcementOrderById($num, $newstype)
	{		
		
		$offset = $this->input->get('per_page');
		$query = $this->db->select('*');
		$query = $this->db->from('jos_clip_details_tbl');
		if($newstype=="both")
		{
			
		}
		else 
		{
			$query = $this->db->where('clip_type',$newstype);
		}		
		$query = $this->db->where('status',1);
		$query = $this->db->order_by('id', 'desc');
		$query = $this->db->get('', $num, $offset);		
		return $query->result_array();
	}
	public function get_lab_active_news_announcementByType($num, $newstype)

	{		

		

		$offset = $this->input->get('per_page');

		$query = $this->db->select('*');

		$query = $this->db->from('jos_clip_details_tbl');

		if($newstype=="both")

		{

			

		}

		else 

		{

			$query = $this->db->where('clip_type',$newstype);

		}	

			

		//$query = $this->db->where('id',$id);

		$query = $this->db->where('status',1);

		$query = $this->db->get('', $num, $offset);		

		return $query->result_array();

	}

	

	

	

	public function get_news($id = FALSE)

	{

		if ($id === FALSE)

		{

			$query = $this->db->get('jos_clip_details_tbl');			

			return $query->result_array();

		}

		$query = $this->db->get_where('jos_clip_details_tbl', array('id' => $id));		

		return $query->row_array();

	}

	

	public function get_clip_dropdown($id = FALSE)

	{

		if ($id === FALSE)

		{

			$query = $this->db->get('clip_tbl');			

			return $query->result_array();

		}

		$query = $this->db->get_where('clip_tbl', array('id' => $id));		

		return $query->result_array();

	}

	



	public function set_news()

	{

		$this->load->helper('url');

		$clipingendDate = NULL;

		//$slug = url_title($this->input->post('title'), 'dash', TRUE);

		

		$clipDate = explode('-',$this->input->post('date_of_clip'));

		$clipDate = array_reverse($clipDate);	

		$clipDate = implode('-',$clipDate);		

		

		if($this->input->post('end_date')!="")

		{

			$clipingendDate = explode('-',$this->input->post('end_date'));

			$clipingendDate = array_reverse($clipingendDate);

			$clipingendDate = implode('-',$clipingendDate);

		}		

		

		$data = array(

			'clip_type' => $this->input->post('clip_type'),

			'headline' => $this->input->post('headline'),

			'clip_detail' => $this->input->post('clip_detail'),

			'date_of_clip' => $clipDate,

		    'end_date' => $clipingendDate,

			'createby' => '1'

		);

		return $this->db->insert('jos_clip_details_tbl', $data);

	}

	

	public function update_news($id)

	{

		$this->load->helper('url');

		$clipingendDate = NULL;

		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);	

		

		$clipDate = explode('-',$this->input->post('date_of_clip'));

		$clipDate = array_reverse($clipDate);	

		$clipDate = implode('-',$clipDate);



		if($this->input->post('end_date')!="")

		{

			$clipingendDate = explode('-',$this->input->post('end_date'));

			$clipingendDate = array_reverse($clipingendDate);

			$clipingendDate = implode('-',$clipingendDate);

		}	

		

		$data = array(

			'clip_type' => $this->input->post('clip_type'),

			'headline' => $this->input->post('headline'),

			'clip_detail' => $this->input->post('clip_detail'),

			'date_of_clip' => $clipDate,

			'end_date' => $clipingendDate,

			'createby' => '1'

		);		

		return $this->db->update('jos_clip_details_tbl', $data, array('id'=>$id));

	}	

	

	public function delete_news($id)

	{

		$this->load->helper('url');

		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);

		return $this->db->delete('jos_clip_details_tbl',  array('id'=>$id));

	}

	

	public function update_status($status, $id)

	{		

		//$this->load->helper('url');

		if($status==1)

		{

			if($this->db->update('jos_clip_details_tbl', array('status'=>0), array('id'=>$id)))

					return true;

			else 

					return false;	

		}

		if($status==0)

		{

			if($this->db->update('jos_clip_details_tbl', array('status'=>1), array('id'=>$id)))

					return true;

			else 

					return false;

		}		

	}

}