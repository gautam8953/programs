<?php
class closed_accreditation_model extends CI_Model
{
	public function __construct()
	{
		$this->load->database();
	}
	
	
	public function get_all_closedAccreditation($limit)
	{
		$offset = $this->input->get('per_page');
		
		$this->db->select('laua.id, laua.remark, l.lab_name, l.lab_registration_code, c.certificate_no');
		$this->db->from('closed_accreditation_tbl As laua');
		$this->db->join('laboratory_tbl As l', 'laua.lab_id=l.id', 'left');
		$this->db->join('lab_certificate_tbl As c', 'laua.certificate_id=c.id', 'left');
		$this->db->order_by('l.lab_registration_code');
		
		if($limit!="")
		{
			$query = $this->db->get('',$limit,$offset);
		}	
		else 
		{
			$query = $this->db->get();
		}	  
		
		return $query->result_array();  
		
	}

	public function get_closedAccreditation($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('closed_accreditation_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('closed_accreditation_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	
	public function setclosedAccreditation()
	{
		$this->load->helper('url');
		$str = explode("|", $this->input->post('cno'));
		$cid = $str[0];
        $data = array(
            'lab_id' => $this->input->post('lab_id'),
            'certificate_id' => $cid,
        	'remark' => $this->input->post('remark'),        
            'createdby' => '1'    
        );
        return $this->db->insert('closed_accreditation_tbl', $data);
	}
	
	
	public function updateclosedAccreditation($id)
	{
		$this->load->helper('url');
		$str = explode("|", $this->input->post('cno'));
		$cid = $str[0];
        $data = array(
            'lab_id' => $this->input->post('lab_id'),
            'certificate_id' => $cid,
        	'remark' => $this->input->post('remark'),        
            'createdby' => '1'           
        );
        return $this->db->update('closed_accreditation_tbl', $data, array('id'=>$id));
	}
	
	public function deleteclosedAccreditation($id)
	{
		$this->load->helper('url');
		return $this->db->delete('closed_accreditation_tbl',  array('id'=>$id));
	}
	
	
}