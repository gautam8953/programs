<?php
class subgroup_model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }
    
	public function get_all_subgroups($num)
	{		
		$offset = $this->input->get('per_page');
		$query =     $this->db->select('t1.*, t2.group_name')
                        ->from('sub_group_tbl AS t1, group_tbl AS t2')
                        ->where('t1.group_id = t2.id');                        
        $query = $this->db->get('',$num,$offset);
        return $query->result_array();
	}
    

    public function get_lab_subgroup($id = FALSE)
    {
        if ($id === FALSE)
        {
                          
            $query =     $this->db->select('t1.*, t2.group_name')
                        ->from('sub_group_tbl AS t1, group_tbl AS t2')
                        ->where('t1.group_id = t2.id');                        
            $query = $this->db->get();
            return $query->result_array();
        }
        
        $query =     $this->db->select('t1.*, t2.group_name')
                        ->from('sub_group_tbl AS t1, group_tbl AS t2')
                        ->where('t1.group_id = t2.id')                    
                        ->where('t1.id',$id);
            $query = $this->db->get();
        
        //$query = $this->db->get_where('sub_group_tbl', array('id' => $id));
        //print_r($query->row_array());
        return $query->row_array();
    }
    public function set_subgroup()
    {
        $this->load->helper('url');

        //$slug = url_title($this->input->post('category_name'), 'dash', TRUE);

        $data = array(
            'sub_group_name' => $this->input->post('subgroup_name'),
            'group_id' => $this->input->post('group_id'),
            'createdby' => '1',
            'sub_group_description' => $this->input->post('subgroup_description')
        );

        return $this->db->insert('sub_group_tbl', $data);
    }

    public function update_subgroup($id)
    {
        $this->load->helper('url');

        //$slug = url_title($this->input->post('category_name'), 'dash', TRUE);

       $editdata = array(
            'sub_group_name' => $this->input->post('subgroup_name'),
            'group_id' => $this->input->post('group_id'),
            'createdby' => '1',
            'sub_group_description' => $this->input->post('subgroup_description')
        );
       

        return $this->db->update('sub_group_tbl', $editdata, array('id'=>$id), NULL);
    }

    public function delete_subgroup($id)
    {
        $this->load->helper('url');
        //$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
        return $this->db->delete('sub_group_tbl',  array('id'=>$id));
    }
    
    public function selectSubgroupById($order='', $sort='')
    {        
    	 //$query = $this->db->get_where('sub_group_tbl', array('group_id' => $this->input->post('group_id')));
         $query = $this->db->get('sub_group_tbl');         
         if($sort=='')
         {
             $sort = 'ASC';
         }         
         if($order!='')
         {
            $this->db->orderby($order, $sort);  
         }        
         return $query->result_array(); 
        
    }
}