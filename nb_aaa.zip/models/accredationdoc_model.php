<?php
class accredationdoc_model extends CI_Model
{
	public function __construct()
	{
		$this->load->database();
	}

	public function get_lab_all_accredatationDoc($num)
	{
		$offset = $this->input->get('per_page');
		$query = $this->db->select('*');
		$query = $this->db->from('accredation_documents_tbl');
		$query = $this->db->order_by('document_no');		
		$query = $this->db->get('',$num,$offset);
		return $query->result_array();			
	}
	
	public function get_lab_all_accredatationDocByType($num,$doctype)
	{
		$offset = $this->input->get('per_page');	
		$query = $this->db->select('*');
		$query = $this->db->from('accredation_documents_tbl');
		if($doctype=="both")
		{
			$query = $this->db->where('document_type',"free");
			$query = $this->db->or_where('document_type',"paid");
		}
		else 
		{
			$query = $this->db->where('document_type',$doctype);			
		}
		
		$query = $this->db->where('status',1);
		$query = $this->db->order_by('document_no');
		$query = $this->db->get('',$num,$offset);
		return $query->result_array();	
			
	}
	
	
	
	public function get_accre_doc($id = FALSE,$doctype='')
	{
		if($id === FALSE && $doctype=="")
		{
			$query = $this->db->get('accredation_documents_tbl');			
			return $query->result_array();
		}
		
		if($id!="" && $doctype=="")
		{
			$query = $this->db->get_where('accredation_documents_tbl', array('id' => $id));		
			return $query->row_array();
		}
		
		if($id=="" && $doctype!="")
		{
			$this->db->select('acdoc.*,dt.*');
			$this->db->from('accredation_documents_tbl as acdoc');
			$this->db->join('document_type_tbl as dt', 'acdoc.document_type=dt.id');
			$this->db->where('dt.document_type_name',$doctype);				
			$query = $this->db->get();
			return $query->result_array();
		}
		
	}
	
	public function get_accre_doc_by_doctype($doctype='')
	{		    		   
			$this->db->select('acdoc.*');
			$this->db->from('accredation_documents_tbl as acdoc');			
			if($doctype!='')
			{
				if($doctype=="both")
			    {
			    	$this->db->where('acdoc.document_type',"free");
					$this->db->or_where('acdoc.document_type',"paid");
			    }
			    else 
			    {
			    	$this->db->where('acdoc.document_type',$doctype);
			    }				
			}		
			$query = $this->db->get();
			return $query->result_array();
	}
	
	public function get_doc_type($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('document_type_tbl');			
			return $query->result_array();
		}
		$query = $this->db->get_where('document_type_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function set_accre_doc($docFileName)
	{
		$this->load->helper('url');		
		$issueDate = explode('-',$this->input->post('issue_date'));
		$issueDate = array_reverse($issueDate);	
		$issueDate = implode('-',$issueDate);		
		
		if($this->input->post('last_amendment_date')!="")
		{
			$lastamedDate = explode('-',$this->input->post('last_amendment_date'));
			$lastamedDate = array_reverse($lastamedDate);	
			$lastamedDate = implode('-',$lastamedDate);		
		}
		else 
		{
			$lastamedDate = "0000-00-00";
		}
		
		$data = array(
			'document_no' => $this->input->post('document_no'),
			'document_title' => $this->input->post('document_title'),
			'document_type' => $this->input->post('document_type'),
			'issue_no' => $this->input->post('issue_no'),
			'issue_date' => $issueDate,
		    'last_amendment_no' => $this->input->post('last_amendment_no'),
		    'last_amendment_date' => $lastamedDate,
		    'cost' => $this->input->post('cost'),
		    'document_file_name' => $docFileName,  
			'status'=>1,
			'createdby' => '1'
		);		
		return $this->db->insert('accredation_documents_tbl', $data);
	}
	public function update_accre_doc($id,$docFileName)
	{
		$this->load->helper('url');		
		$issueDate = explode('-',$this->input->post('issue_date'));
		$issueDate = array_reverse($issueDate);	
		$issueDate = implode('-',$issueDate);		
		
		if($this->input->post('last_amendment_date')=="")
		{
			$lastamedDate = "0000-00-00";
		}
		else 
		{
			
			$lastamedDate = explode('-',$this->input->post('last_amendment_date'));
			$lastamedDate = array_reverse($lastamedDate);
			$lastamedDate = implode('-',$lastamedDate);
		}
		
		$data = array(
			'document_no' => $this->input->post('document_no'),
			'document_title' => $this->input->post('document_title'),
			'document_type' => $this->input->post('document_type'),
			'issue_no' => $this->input->post('issue_no'),
			'issue_date' => $issueDate,
		    'last_amendment_no' => $this->input->post('last_amendment_no'),
		    'last_amendment_date' => $lastamedDate,
		    'cost' => $this->input->post('cost'),
		    //'document_file_name' => $newFileName,		   
			'createdby' => '1'
		);		
		if($docFileName!='')
		{
			$data = array('document_file_name' => $docFileName);
		}
		return $this->db->update('accredation_documents_tbl', $data, array('id'=>$id));
	}	
	
	public function delete_accre_doc($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		return $this->db->delete('accredation_documents_tbl',  array('id'=>$id));
	}
	
	public function get_file_extension($file_name) 
	{
		return end(explode('.',$file_name));
	}
	
	public function get_new_fileName($dno,$ext)
	{	
		$cdate = date("Ymdhi");
		return $newFileName =   $cdate."-".$dno."-doc.".$ext;		
	}
	
	
	public function update_status($status, $id)
	{		
		//$this->load->helper('url');
		if($status==1)
		{
			if($this->db->update('accredation_documents_tbl', array('status'=>0), array('id'=>$id)))
					return true;
			else 
					return false;	
		}
		if($status==0)
		{
			if($this->db->update('accredation_documents_tbl', array('status'=>1), array('id'=>$id)))
					return true;
			else 
					return false;
		}		
		
	}
}