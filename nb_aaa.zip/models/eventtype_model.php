<?php
class eventtype_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}

	public function get_all_labs_eventTypes($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('event_type_tbl', $num, $offset);	
		return $query->result_array();
	}
	
	public function get_lab_all_eventScheduleByTraingType($num,$eventType)
	{		
		$offset = $this->input->get('per_page');	
			
		$query = $this->db->get('event_type_tbl', $num, $offset);	
		return $query->result_array();
	}
	
	public function get_eventtype($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('event_type_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('event_type_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function set_eventtype()
	{
		$this->load->helper('url');		
		$data = array(
			'event_type_name' => $this->input->post('event_type_name'),
			'createdby' => '1'			
		);
		return $this->db->insert('event_type_tbl', $data);
	}

	public function update_eventtype($id)
	{
		$this->load->helper('url');
		$data = array(
			'event_type_name' => $this->input->post('event_type_name'),
			'modifiedby' => '1',
			'modifiedon' => date('Y-m-d h:i:s')
		);
		return $this->db->update('event_type_tbl', $data, array('id'=>$id));
	}

	public function delete_eventtype($id)
	{
		$this->load->helper('url');		
		return $this->db->delete('event_type_tbl',  array('id'=>$id));
	}
}