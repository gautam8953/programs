<?php
class natureoflab_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_all_natureoflabs($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('lab_nature_tbl', $num, $offset);	
		return $query->result_array();
	}

	public function get_natureoflab($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('lab_nature_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('lab_nature_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function set_natureoflab()
	{
		$this->load->helper('url');		
		$data = array(
			'nature_name' => $this->input->post('nature_name'),
			'createdby' => '1'			
		);
		return $this->db->insert('lab_nature_tbl', $data);
	}

	public function update_natureoflab($id)
	{
		$this->load->helper('url');
		$data = array(
			'nature_name' => $this->input->post('nature_name'),
			'modifiedby' => '1',
			'modifiedon' => date('Y-m-d h:i:s')
		);
		return $this->db->update('lab_nature_tbl', $data, array('id'=>$id));
	}

	public function delete_natureoflab($id)
	{
		$this->load->helper('url');		
		return $this->db->delete('lab_nature_tbl',  array('id'=>$id));
	}
	
	public function selectAllNatureoflab($order='', $sort='')
    {        
    	 //$query = $this->db->get_where('group_tbl', array('id' => $id));
         $query = $this->db->select('*');
	 $query = $this->db->from('lab_nature_tbl');
         $this->db->order_by('nature_name');
         $query = $this->db->get('');
         
         /*
         if($sort=='')
         {
            $sort = 'ASC';
         }         
         if($order!='')
         {
            $this->db->order_by($order, $sort);  
         } 
         */       
         return $query->result_array(); 
        
    }
}