<?php
class lab_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_all_labs_category($num,$catid='')
	{		
		if($catid=='0')
			$catid = 0;		
		else
			$catid = $catid;			
		$offset = $this->input->get('per_page');
		$query = $this->db->where('cat_id',$catid);
		$this->db->limit($num,$offset);
		$query = $this->db->get('lab_category_tbl');
		return $query->result_array();
	}

	public function count_all_labs_category($catid='')
	{
		if($catid=='0')
			$catid = 0;		
		else
			$catid = $catid;	
		$query = $this->db->get_where('lab_category_tbl', array('cat_id' => $catid));		
		return $query->result_array();
	}
	
	public function get_lab_category($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('lab_category_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('lab_category_tbl', array('id' => $id));		
		return $query->row_array();
	}
	public function set_labs()
	{
		$this->load->helper('url');		
		$data = array(
			'category_name' => $this->input->post('category_name'),
			'isactive' =>'1',
			'createdby' => '1',
			'category_description' => $this->input->post('category_description')
		);

		return $this->db->insert('lab_category_tbl', $data);
	}

	public function update_labs($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		$data = array(
			'category_name' => $this->input->post('category_name'),
			'modifiedby' => '1',
			'modifiedon' => date('Y-m-d h:i:s'),
			'category_description' => $this->input->post('category_description')
		);
		return $this->db->update('lab_category_tbl', $data, array('id'=>$id));
	}

	public function delete_lab($id)
	{			
		return $this->db->delete('lab_category_tbl',  array('id'=>$id));
	}
	
	public function delete_lab_cat($id)
	{
		$this->load->helper('url');
		$query = $this->db->get_where('lab_category_tbl', array('cat_id' => $id));	
		$res = $query->result_array();
		if(count($res)>0)
		{
			foreach($res as $rs)
			{
				$this->delete_lab_cat($rs['id']);
			}
		}
		return $this->db->delete('lab_category_tbl',  array('id'=>$id));		
		/*
	    $result=mysql_query("SELECT * FROM yourTable WHERE parentid='$id'");
	    if (mysql_num_rows($result)>0) {
	         while($current=mysql_fetch_array($result)) {
	              recursiveDelete($current['id']);
	         }
	    }
    	mysql_query("DELETE FROM yourTable WHERE id='$id'");
    	*/
}
	

	
	
	
	public function change_lab_status($id)
	{
		$data = array(
			'isactive' => $this->input->get('status'),
			'modifiedby' => '1',
			'modifiedon' => date('Y-m-d h:i:s')			
		);
		return $this->db->update('lab_category_tbl', $data, array('id'=>$id));
	}
	
	public function set_sub_cat()
	{			
		$this->load->helper('url');
		$catid = $this->input->post('catid');
		if($this->checkParentItem($catid))
		{		
			$data = array(
							'cat_id' => $catid,
							'category_name' => $this->input->post('category_name'),
							'isactive' =>'1',
							'createdby' => '1',
							'category_description' => $this->input->post('category_description')
						  );
			return $this->db->insert('lab_category_tbl', $data);
		}
		else 
		{
			//echo "Catid - ".$this->checkParentItem($catid);
			//die();
			return false;
			
		}	
	}
	
	public function selectAllFacility_Lab($order='category_name', $sort='')
    {

         $query =$this->db->select('*');
	 $query =$this->db->from('lab_category_tbl');
         $query = $this->db->where(array('cat_id'=>'0','isactive'=>'1'));
         $query = $this->db->order_by('category_name');
	 $query = $this->db->get('');       
         
         //$query = $this->db->get_where('lab_category_tbl',array('cat_id'=>'0','isactive'=>'1'));
         /*
         if($sort=='')
         {
             $sort = 'ASC';
         }         
         if($order!='')
         {
            $query = $this->db->order_by($order, $sort);  
         }  
         */      
         return $query->result_array();        
    }
    
	public function selectFieldById($facilityid,$order='', $sort='')
    { 
    	 $query = $this->db->get_where('lab_category_tbl', array('cat_id' => $facilityid, 'isactive'=>'1'));
         //$query = $this->db->get('facility_fields_tbl');
         if($sort=='')
         {
             $sort = 'ASC';
         }         
         if($order!='')
         {
           	$this->db->orderby($order, $sort);  
         }
        
         return $query->result_array(); 
        
    }
    
	public function selectGroupById($fieldid,$order='', $sort='')
    {
    	 $query = $this->db->get_where('lab_category_tbl', array('cat_id' => $fieldid));             
         if($sort=='')
         {
            $sort = 'ASC';
         }         
         if($order!='')
         {
            $this->db->order_by($order, $sort);  
         }        
         return $query->result_array(); 
        
    }
    
 	public function selectSubgroupById($groupid, $order='', $sort='')
    {        
    	 $query = $this->db->get_where('lab_category_tbl', array('cat_id' => $groupid));
         //$query = $this->db->get('sub_group_tbl');         
         if($sort=='')
         {
             $sort = 'ASC';
         }         
         if($order!='')
         {
            $this->db->orderby($order, $sort);  
         }        
         return $query->result_array(); 
        
    }
    
    public function checkParentItem($prntid)
    {
    	$qry1 = $this->db->get_where('lab_category_tbl', array('id' => $prntid));
    	$res1 = $qry1->row_array();
    	$IstParent = $res1['id'];
    	$catid1 = $res1['cat_id'];
    	
    	if($catid1!=0)
    	{
    		$qry2 = $this->db->get_where('lab_category_tbl', array('id' => $catid1));
	    	$res2 = $qry2->row_array();    	
	    	$IIndParent = $res2['id'];
	    	$catid2 = $res2['cat_id'];	
	    		    	
	    	if($catid2!=0)
	    	{
	    		$qry3 = $this->db->get_where('lab_category_tbl', array('id' => $catid2));
		    	$res3 = $qry3->row_array();    	
		    	$IIIrdParent = $res3['id'];
		    	$catid3 = $res3['cat_id'];
		    			    	
		    	if($catid3!=0)
		    	{
		    		return false;		    		
		    	}
		    	else 
		    	{
		    		return true;
		    	}
	    	}
	    	else 
	    	{
	    		return true;
	    	}
    	}
    	else 
    	{
    		return true;
    	}	
    	
    }
    
	public function showCategoryNavigater($prntid='')
	{
		//echo "Cat id".$prntid;
		//die();
		$navstr = "";
		$qry1 = $this->db->get_where('lab_category_tbl', array('id' => $prntid));
    	$res1 = $qry1->row_array();
    	$IstParent = $res1['id'];
    	$catid1 = $res1['cat_id'];    
    	$ParentName1 = $res1['category_name'];
    	if($catid1==0)
    	{
    		return $navstr .= "<a href='index.php?c=labs&m=index'>Home</a> -> "."<a href='index.php?c=labs&m=showsubcat&catid=$prntid'>".$ParentName1."</a>";
    	}
    	else 
    	{
    		$qry2 = $this->db->get_where('lab_category_tbl', array('id' => $catid1));
	    	$res2 = $qry2->row_array();    	
	    	$IIndParent = $res2['id'];
	    	$catid2 = $res2['cat_id'];
	    	$ParentName2 = $res2['category_name'];
	    	if($catid2==0)
	    	{
	    		return $navstr = "<a href='index.php?c=labs&m=index'>Home</a> -> "."<a href='index.php?c=labs&m=showsubcat&catid=$catid1'>".$ParentName2."</a> -> <a href='index.php?c=labs&m=showsubcat&catid=$prntid'>".$ParentName1."</a>";
	    	}
	    	else 
	    	{
	    		$qry3 = $this->db->get_where('lab_category_tbl', array('id' => $catid2));
		    	$res3 = $qry3->row_array();    	
		    	$IIIrdParent = $res3['id'];
		    	$catid3 = $res3['cat_id'];
		    	$ParentName3 = $res3['category_name'];
		    	if($catid3==0)
		    	{
		    		return $navstr .= " <a href='index.php?c=labs&m=index'>Home</a> -> <a href='index.php?c=labs&m=showsubcat&catid=$catid2'>".$ParentName3."</a> -> <a href='index.php?c=labs&m=showsubcat&catid=$catid1'>".$ParentName2."</a> -> <a href='index.php?c=labs&m=showsubcat&catid=$prntid'>".$ParentName1."</a>";
		    	}		    	
	    	}
    	}	
	}
}