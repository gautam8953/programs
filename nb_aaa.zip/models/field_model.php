<?php
class field_model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }
    
    public function get_all_fields($num)
	{		
		$offset = $this->input->get('per_page');	
		$query = $this->db->select('t1.*, t2.facility_name')
                          ->from('facility_fields_tbl AS t1, facility_tbl AS t2')
                          ->where('t1.facility_id = t2.id');  	
		$query = $this->db->get('',$num,$offset);
		return $query->result_array();
	}
    

    public function get_lab_field($id = FALSE)
    {
        if ($id === FALSE)
        {                          
            $query = $this->db->select('t1.*, t2.facility_name')
                          ->from('facility_fields_tbl AS t1, facility_tbl AS t2')
                          ->where('t1.facility_id = t2.id');                        
            $query = $this->db->get();
            return $query->result_array();
        }
        
        $query = $this->db->select('t1.*, t2.facility_name')
                          ->from('facility_fields_tbl AS t1, facility_tbl AS t2')
                          ->where('t1.facility_id = t2.id')                    
                          ->where('t1.id',$id);
        $query = $this->db->get();
        return $query->row_array();
    }
    public function set_field()
    {
        $this->load->helper('url');
        //$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
        $data = array(
            'field_name' => $this->input->post('field_name'),
            'facility_id' => $this->input->post('facility_id'),
            'createdby' => '1'           
        );

        return $this->db->insert('facility_fields_tbl', $data);
    }

    public function update_field($id)
    {
       $this->load->helper('url');
       //$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
       $editdata = array(
            'field_name' => $this->input->post('field_name'),
            'facility_id' => $this->input->post('facility_id'),
            'modifiedby' => '1',
          	'modifiedon' => date('Y-m-d h:i:s')
        );      

        return $this->db->update('facility_fields_tbl', $editdata, array('id'=>$id), NULL);
    }

    public function delete_field($id)
    {
        $this->load->helper('url');
        //$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
        return $this->db->delete('facility_fields_tbl',  array('id'=>$id));
    }
    
    public function selectFieldById($order='', $sort='')
    { 
    	 //$query = $this->db->get_where('facility_fields_tbl', array('facility_id' => $facilityid));
         $query = $this->db->get('facility_fields_tbl');
         if($sort=='')
         {
             $sort = 'ASC';
         }         
         if($order!='')
         {
           	$this->db->orderby($order, $sort);  
         }
        
         return $query->result_array(); 
        
    }
}