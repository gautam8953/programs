<?php
class zone_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}

	public function get_all_labs_zones($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('zone_tbl', $num, $offset);	
		return $query->result_array();
	}
	
	
	public function get_zone($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('zone_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('zone_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function set_zone()
	{
		$this->load->helper('url');		
		$data = array(
			'zone_name' => $this->input->post('zone_name'),
			'createdby' => '1',
			'createdon' => date('Y-m-d h:i:s')
		);
		return $this->db->insert('zone_tbl', $data);
	}

	public function update_zone($id)
	{
		$this->load->helper('url');
		$data = array(
			'zone_name' => $this->input->post('zone_name'),
			'modifiedby' => '1',
			'modifiedon' => date('Y-m-d h:i:s')
		);
		return $this->db->update('zone_tbl', $data, array('id'=>$id));
	}

	public function delete_zone($id)
	{
		$this->load->helper('url');		
		return $this->db->delete('zone_tbl',  array('id'=>$id));
	}
	
	public function selectAllZone($order='zone_name', $sort='')
        {        
    	 //$query = $this->db->get_where('group_tbl', array('id' => $id));
         $query = $this->db->select('*');
	 $query = $this->db->from('zone_tbl');
         $query = $this->db->order_by('zone_name');
         $query = $this->db->get('');         
         /*
         if($sort=='')
         {
            $sort = 'ASC';
         }         
         if($order!='')
         {
           // $this->db->order_by($order, $sort);  
         } 
         */       
         return $query->result_array(); 
        
    }
}