<?php
class Auth_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}

	public function login()
	{		
		$username = $this->input->post('username');
		$password = MD5($this->input->post('password'));		
		$query = $this->db->get_where('user_tbl', array('username' => $username, 'password' => $password, 'status' =>1));		
		$res = $query->row_array();
		if(count($res)>0)
		{
            $username = $res['username'];            
            $this->load->library('session');
            $this->session->set_userdata('nabl_user', $username);
			return true;
		}
		else 
		{
			return false;
		}		
	}
	
	public function change_pass($username)
	{
		$newpassword = MD5($this->input->post('newpassword'));	
		$oldpassword = MD5($this->input->post('oldpassword'));
				
		$query = $this->db->get_where('user_tbl', array('username' => $username, 'password' => $oldpassword));
		$rows =  $query->result_array();
		if(count($rows)>0)
		{
			$data = array(
				'password' => $newpassword,
				'modifiedby' => '1',
				'modifiedon' => date('Y-m-d h:i:s')					
			);
			return $query =  $this->db->update('user_tbl', $data, array('username'=>$username, 'password'=>$oldpassword));
		}
		else
		{
			return false;
		}
		
	}
}