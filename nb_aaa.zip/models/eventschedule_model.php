<?php
class Eventschedule_model extends CI_Model {
	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_lab_all_eventSchedule($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('event_schedule_tbl', $num, $offset);
		return $query->result_array();
	}
	
	public function get_lab_all_eventScheduleByTraingType($num,$traingType)
	{		
		$offset = $this->input->get('per_page');
		$query = $this->db->select('es.id as eventId, es.program_name, es.venue, es.start_date, es.end_date, es.event_type_id, e.event_type_name');
		$query = $this->db->from('event_schedule_tbl as es');
		$query = $this->db->join('event_type_tbl as e','es.event_type_id=e.id');
		$query = $this->db->where('es.event_type_id',$traingType);
		$query = $this->db->where('es.status',1);
		$query = $this->db->get('', $num, $offset);
		return $query->result_array();
	}
	
	public function count_eventScheduleByTraingType($traingType)
	{		
		//$offset = $this->input->get('per_page');
		$query = $this->db->select('es.program_name');
		$query = $this->db->from('event_schedule_tbl as es');
		$query = $this->db->join('event_type_tbl as e','es.event_type_id=e.id');		
		$query = $this->db->where('es.event_type_id',$traingType);
		$query = $this->db->get('');
		return $query->result_array();
	}
	
	public function get_event_test_schedule($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('event_schedule_tbl');
			return $query->result_array();
		}
		$query = $this->db->select('es.*, e.event_type_name, c.name as cityname, s.name as statename,ctry.name as countryname');
		$query = $this->db->from('event_schedule_tbl as es');
		$query = $this->db->join('event_type_tbl as e','es.event_type_id=e.id');
		$query = $this->db->join('cities as c','es.city_id=c.id');
		$query = $this->db->join('states as s','es.state=s.id');
		$query = $this->db->join('country as ctry','es.country=ctry.id');
		//$query = $this->db->where('es.event_type_id',$traingType);
		$query = $this->db->get_where('event_schedule_tbl', array('es.id' => $id));		
		return $query->row_array();
	}
	
	public function get_states($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('states');
			return $query->result_array();
		}
		$query = $this->db->get_where('states', array('id' => $id));	
		return $query->row_array();
	}
	
	public function get_city($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('cities');
			return $query->result_array();
		}
		$query = $this->db->get_where('cities', array('id' => $id));		
		return $query->row_array();
	}
	
	public function get_country($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('country');
			return $query->result_array();
		}

		$query = $this->db->get_where('country', array('id' => $id));		
		return $query->row_array();
	}
	
	public function get_eventType($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('event_type_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('event_type_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function set_event_sch()
	{		
		$this->load->helper('url');
		
		$startDate = "0000-00-00";
		$endDate = "0000-00-00";
		if($this->input->post('start_date')!="")
		{
			$startDate = explode('-',$this->input->post('start_date'));
			$startDate = array_reverse($startDate);	
			$startDate = implode('-',$startDate);	
		}
		if($this->input->post('end_date')!="")
		{
			$endDate = explode('-',$this->input->post('end_date'));
			$endDate = array_reverse($endDate);	
			$endDate = implode('-',$endDate);	
		}
		
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		$data = array(
						'event_type_id' => $this->input->post('event_type_id'),
						'program_name' => $this->input->post('program_name'),
						'course_detail' => $this->input->post('course_detail'),
						'venue' => $this->input->post('venue'),
						'contact_person' => $this->input->post('contact_person'),		
						'designation' => $this->input->post('designation'),
						'contact_address' => $this->input->post('contact_address'),						
						'city_id' => $this->input->post('city'),
						'state' => $this->input->post('state'),
						'country' => $this->input->post('country'),	
						'pin' => $this->input->post('pin'),	
						'phone' => $this->input->post('phone'),	
						'fax' => $this->input->post('fax'),	
						'emailid' => $this->input->post('emailid'),
						'program_fees' => $this->input->post('program_fees'),
						'start_date' => $startDate,
						'end_date' => $endDate,
						'remark' => $this->input->post('remark'),
						'status'=>1,
						'createdby' => '1'
		);
		return $this->db->insert('event_schedule_tbl', $data);
	}

	public function update_event_sch($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);	

		$startDate = explode('-',$this->input->post('start_date'));
		$startDate = array_reverse($startDate);	
		$startDate = implode('-',$startDate);	
		
		$endDate = explode('-',$this->input->post('end_date'));
		$endDate = array_reverse($endDate);	
		$endDate = implode('-',$endDate);	
		
		$data = array(
						'event_type_id' => $this->input->post('event_type_id'),
						'program_name' => $this->input->post('program_name'),
						'course_detail' => $this->input->post('course_detail'),
						'venue' => $this->input->post('venue'),
						'contact_person' => $this->input->post('contact_person'),		
						'designation' => $this->input->post('designation'),
						'contact_address' => $this->input->post('contact_address'),						
						'city_id' => $this->input->post('city'),
						'state' => $this->input->post('state'),
						'country' => $this->input->post('country'),	
						'pin' => $this->input->post('pin'),	
						'phone' => $this->input->post('phone'),	
						'fax' => $this->input->post('fax'),	
						'emailid' => $this->input->post('emailid'),
						'program_fees' => $this->input->post('program_fees'),
						'start_date' => $startDate,
						'end_date' => $endDate,
						'remark' => $this->input->post('remark'),
						'createdby' => '1'
		);
		return $this->db->update('event_schedule_tbl', $data, array('id'=>$id));
	}

	public function delete_event_sch($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		return $this->db->delete('event_schedule_tbl',  array('id'=>$id));
	}
	
	public function update_status($status, $id)
	{		
		//$this->load->helper('url');
		if($status==1)
		{
			if($this->db->update('event_schedule_tbl', array('status'=>0), array('id'=>$id)))
					return true;
			else 
					return false;	
		}
		if($status==0)
		{
			if($this->db->update('event_schedule_tbl', array('status'=>1), array('id'=>$id)))
					return true;
			else 
					return false;
		}		
	}
}