<?php
class cliptype_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_all_clipTypes($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('clip_tbl', $num, $offset);	
		return $query->result_array();
	}

	public function get_cliptype($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('clip_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('clip_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function set_cliptype()
	{
		$this->load->helper('url');		
		$data = array(
			'clip_name' => $this->input->post('clip_name'),
			'createdby' => '1'			
		);
		return $this->db->insert('clip_tbl', $data);
	}

	public function update_cliptype($id)
	{
		$this->load->helper('url');
		$data = array(
			'clip_name' => $this->input->post('clip_name'),
			'modifiedby' => '1',
			'modifiedon' => date('Y-m-d h:i:s')
		);
		return $this->db->update('clip_tbl', $data, array('id'=>$id));
	}

	public function delete_cliptype($id)
	{
		$this->load->helper('url');		
		return $this->db->delete('clip_tbl',  array('id'=>$id));
	}
}