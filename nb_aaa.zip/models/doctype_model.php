<?php
class doctype_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}

	public function get_all_documentType($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('document_type_tbl', $num, $offset);	
		return $query->result_array();
	}
	
	public function get_doctype($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('document_type_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('document_type_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function set_doctype()
	{
		$this->load->helper('url');		
		$data = array(
			'document_type_name' => $this->input->post('document_type_name'),
			'createdby' => '1'			
		);
		return $this->db->insert('document_type_tbl', $data);
	}

	public function update_doctype($id)
	{
		$this->load->helper('url');
		$data = array(
			'document_type_name' => $this->input->post('document_type_name'),
			'modifiedby' => '1',
			'modifiedon' => date('Y-m-d h:i:s')
		);
		return $this->db->update('document_type_tbl', $data, array('id'=>$id));
	}

	public function delete_doctype($id)
	{
		$this->load->helper('url');		
		return $this->db->delete('document_type_tbl',  array('id'=>$id));
	}
}