<?php
class assessor_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_all_assessor($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('assessor_tbl', $num, $offset);	
		return $query->result_array();
	}

	public function get_assessor($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('assessor_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('assessor_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	public function set_assessor()
	{
		date_default_timezone_set('Asia/Kolkata');	
		$this->load->helper('url');
				
		$regnDate = explode('-',$this->input->post('account_expiry_date'));
		$regnDate = array_reverse($regnDate);	
		$regnDate = implode('-',$regnDate);		
		
		$data = array(
			'username' => $this->input->post('username'),
			'assessor_code' => $this->input->post('assessor_code'),
			'registration_code' => $this->input->post('registration_code'),
			'account_expiry_date' => $regnDate,
			'createdby' => '1'			
		);
		return $this->db->insert('assessor_tbl', $data);
	}

	public function update_assessor($id)
	{
		date_default_timezone_set('Asia/Kolkata');
		$this->load->helper('url');
		
		$regnDate = explode('-',$this->input->post('account_expiry_date'));
		$regnDate = array_reverse($regnDate);	
		$regnDate = implode('-',$regnDate);
		
		$data = array(
			'username' => $this->input->post('username'),
			'assessor_code' => $this->input->post('assessor_code'),
			'registration_code' => $this->input->post('registration_code'),
			'account_expiry_date' => $regnDate,
			'modifiedby' => '1',
			'modifiedon' => date('Y-m-d h:i:s'),
		);
		return $this->db->update('assessor_tbl', $data, array('id'=>$id));
	}

	public function delete_assessor($id)
	{
		$this->load->helper('url');
		return $this->db->delete('assessor_tbl',  array('id'=>$id));
	}
	
	public function login()
	{		
		$username = $this->input->post('username');
		$password = $this->input->post('assessor_code');	
		$query = $this->db->get_where('assessor_tbl', array('username' => $username, 'assessor_code' => $password));		
		$res = $query->row_array();
		if(count($res)>0)
		{
            $username = $res['username']; 
            //$_SESSION['assessname'] = $username;
            //$this->load->library('session');
            //$this->session->set_userdata('nabl_assessor', $username);
			return true;
		}
		else 
		{
			return false;
		}		
	}
}