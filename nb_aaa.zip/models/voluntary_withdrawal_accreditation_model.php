<?php
class voluntary_withdrawal_accreditation_model extends CI_Model
{
	public function __construct()
	{
		$this->load->database();
                ini_set('memory_limit', '-1');
	}
	
	
	public function get_all_voluntaryWithdrawalAccreditation($limit)
	{
		$offset = $this->input->get('per_page');
		
		$this->db->select('laua.id, laua.remark, l.lab_name, l.lab_registration_code, c.certificate_no, lct.category_name as discipline');
		$this->db->from('voluntary_withdrawal_accreditation_tbl As laua');
		$this->db->join('laboratory_tbl As l', 'laua.lab_id=l.id', 'left');
		$this->db->join('lab_certificate_tbl As c', 'laua.certificate_id=c.id', 'left');
		$this->db->join('lab_category_tbl As lct', 'laua.discipline=lct.id', 'left');
		$this->db->order_by('l.lab_registration_code');
		
		if($limit!="")
		{
			$query = $this->db->get('',$limit,$offset);
		}	
		else 
		{
			$query = $this->db->get();
		}	  
		
		return $query->result_array();  
		
	}

	public function get_voluntaryWithdrawalAccreditation($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('voluntary_withdrawal_accreditation_tbl');
			return $query->result_array();
		}
		$query = $this->db->get_where('voluntary_withdrawal_accreditation_tbl', array('id' => $id));		
		return $query->row_array();
	}
	
	
	public function setvoluntaryWithdrawalAccreditation()
	{
		$this->load->helper('url');
		$str = explode("|", $this->input->post('cno'));
		$cid = $str[0];
        $data = array(
            'lab_id' => $this->input->post('lab_id'),
            'certificate_id' => $cid,
	        'field' => $this->input->post('facility_id'),
	        'discipline' => $this->input->post('field_id'),
        	'remark' => $this->input->post('remark'),        
            'createdby' => '1'    
        );
        return $this->db->insert('voluntary_withdrawal_accreditation_tbl', $data);
	}
	
	
	public function updatevoluntaryWithdrawalAccreditation($id)
	{
		$this->load->helper('url');
		$str = explode("|", $this->input->post('cno'));
		$cid = $str[0];
        $data = array(
            'lab_id' => $this->input->post('lab_id'),
            'certificate_id' => $cid,
        	'field' => $this->input->post('facility_id'),
	        'discipline' => $this->input->post('field_id'),
        	'remark' => $this->input->post('remark'),        
            'createdby' => '1'           
        );
        return $this->db->update('voluntary_withdrawal_accreditation_tbl', $data, array('id'=>$id));
	}
	
	public function deletevoluntaryWithdrawalAccreditation($id)
	{
		$this->load->helper('url');
		return $this->db->delete('voluntary_withdrawal_accreditation_tbl',  array('id'=>$id));
	}
	
	
}