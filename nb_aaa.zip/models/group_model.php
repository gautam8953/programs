<?php
class group_model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }

    public function get_all_labs_groups($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('group_tbl', $num, $offset);	
		return $query->result_array();
	}
    
    
    public function get_lab_group($id = FALSE)
    {
        if ($id === FALSE)
        {
            $query = $this->db->get('group_tbl');
            return $query->result_array();
        }

        $query = $this->db->get_where('group_tbl', array('id' => $id));
        //print_r($query->row_array());
        return $query->row_array();
    }
    public function set_group()
    {
        $this->load->helper('url');

        //$slug = url_title($this->input->post('category_name'), 'dash', TRUE);

        $data = array(
            'group_name' => $this->input->post('group_name'),
        	'field_id' => $this->input->post('field_id'),
            'createdby' => '1',
            'group_description' => $this->input->post('group_description')
        );

        return $this->db->insert('group_tbl', $data);
    }

    public function update_group($id)
    {
        $this->load->helper('url');

        //$slug = url_title($this->input->post('category_name'), 'dash', TRUE);

        $data = array(
            'group_name' => $this->input->post('group_name'),
        	'field_id' => $this->input->post('field_id'),
            'modifiedby' => '1',
            'modifiedon' => date('Y-m-d h:i:s'),
            'group_description' => $this->input->post('group_description')
        );

        return $this->db->update('group_tbl', $data, array('id'=>$id));
    }

    public function delete_group($id)
    {
        $this->load->helper('url');

        //$slug = url_title($this->input->post('category_name'), 'dash', TRUE);



        return $this->db->delete('group_tbl',  array('id'=>$id));
    }
    
    public function selectAllGroup($order='', $sort='')
    {        
    	 //$query = $this->db->get_where('group_tbl', array('id' => $id));
         $query = $this->db->get('group_tbl');         
         if($sort=='')
         {
            $sort = 'ASC';
         }         
         if($order!='')
         {
            $this->db->order_by($order, $sort);  
         }        
         return $query->result_array(); 
        
    }
    
	public function selectGroupById($order='', $sort='')
    {
    	 //$query = $this->db->get_where('group_tbl', array('field_id' => $this->input->post('field_id')));
         $query = $this->db->get('group_tbl');         
         if($sort=='')
         {
            $sort = 'ASC';
         }         
         if($order!='')
         {
            $this->db->order_by($order, $sort);  
         }        
         return $query->result_array(); 
        
    }
}