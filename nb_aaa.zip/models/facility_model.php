<?php
class facility_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}

	public function get_lab_all_facility($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('facility_tbl', $num, $offset);	
		return $query->result_array();
	}
	
	public function get_lab_facility($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('facility_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('facility_tbl', array('id' => $id));
		//print_r($query->row_array());
		return $query->row_array();
	}
	public function set_facility()
	{
		$this->load->helper('url');

		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);

		$data = array(
			'facility_name' => $this->input->post('facility_name'),
			'createdby' => '1',
			'facility_description' => $this->input->post('facility_description')
		);

		return $this->db->insert('facility_tbl', $data);
	}

	public function update_facility($id)
	{
		$this->load->helper('url');

		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);

		$data = array(
			'facility_name' => $this->input->post('facility_name'),
			'modifiedby' => '1',
			'modifiedon' => date('Y-m-d h:i:s'),
			'facility_description' => $this->input->post('facility_description')
		);

		return $this->db->update('facility_tbl', $data, array('id'=>$id));
	}

	public function delete_facility($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		return $this->db->delete('facility_tbl',  array('id'=>$id));
	}
	
	public function selectAllFacility($order='', $sort='')
    {        
         $query = $this->db->get('facility_tbl');
         if($sort=='')
         {
             $sort = 'ASC';
         }         
         if($order!='')
         {
            $this->db->order_by($order, $sort);  
         }        
         return $query->result_array(); 
        
    }
}