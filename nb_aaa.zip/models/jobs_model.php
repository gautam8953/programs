<?php
class Jobs_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}

	public function get_all_jobsPostings($num)
	{		
		$offset = $this->input->get('per_page');		
		$query = $this->db->get('job_tbl', $num, $offset);
		return $query->result_array();
	}
	
	public function count_all_records()
	{				
		$query = $this->db->get_where('job_tbl',array('status'=>1));
		return $query->result_array();
	}
	
	public function get_all_active_jobsPostings($num)
	{
		$offset = $this->input->get('per_page');
		$query = $this->db->select('*');
		$query = $this->db->from('job_tbl');
		$query = $this->db->where('status',1);				
		$query = $this->db->get('', $num, $offset);
		return $query->result_array();
	}
	
	public function get_jobs($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('job_tbl');			
			return $query->result_array();
		}
		$query = $this->db->get_where('job_tbl', array('id' => $id));		
		return $query->row_array();
	}

	
	
	public function set_job($jobFileName,$appFileName)
	{		
		$this->load->helper('url');		
		if($this->input->post('postingdate')!="")
		{
			$postingdate = explode('-',$this->input->post('postingdate'));
			$postingdate = array_reverse($postingdate);
			$postingdate = implode('-',$postingdate);	
		}
		else
		{
			$postingdate = "0000-00-00";
		}
		
		$lastdateofapply = explode('-',$this->input->post('lastdateofapply'));
		$lastdateofapply = array_reverse($lastdateofapply);	
		$lastdateofapply = implode('-',$lastdateofapply);		
	    
		$data = array(
			'job_titile' => $this->input->post('job_titile'),		
			'contact_person' => $this->input->post('contact_person'),
			'job_description_file_name' =>$jobFileName,
			'designation' => $this->input->post('designation'),
			'emailid' => $this->input->post('emailid'),
			'postingdate' => $postingdate,
			'lastdateofapply' => $lastdateofapply,	
			'uploaded_application_name'	=> $appFileName,
			'status'=>1,
			'createdby' => '1'
		);
		return $this->db->insert('job_tbl', $data);
	}
	
	public function update_job($id,$jobFileName,$appFileName)
	{		
		$this->load->helper('url');			
		if($this->input->post('postingdate')!="")
		{
			$postingdate = explode('-',$this->input->post('postingdate'));
			$postingdate = array_reverse($postingdate);	
			$postingdate = implode('-',$postingdate);	
		}
		else
		{
			$postingdate = "0000-00-00";
		}
		
		$lastdateofapply = explode('-',$this->input->post('lastdateofapply'));
		$lastdateofapply = array_reverse($lastdateofapply);	
		$lastdateofapply = implode('-',$lastdateofapply);
		
	   if($jobFileName!="" && $appFileName=="")
		{
			$data = array(
			'job_titile' => $this->input->post('job_titile'),		
			'contact_person' => $this->input->post('contact_person'),
			'job_description_file_name' =>$jobFileName,
			'designation' => $this->input->post('designation'),
			'emailid' => $this->input->post('emailid'),
			'postingdate' => $postingdate,
			'lastdateofapply' => $lastdateofapply,						
			'createdby' => '1'
			);
		}
		else if($appFileName!="" && $jobFileName=="")
		{
			$data = array(
			'job_titile' => $this->input->post('job_titile'),		
			'contact_person' => $this->input->post('contact_person'),
			'designation' => $this->input->post('designation'),
			'emailid' => $this->input->post('emailid'),
			'postingdate' => $postingdate,
			'lastdateofapply' => $lastdateofapply,	
			'uploaded_application_name'	=> $appFileName,		
			'createdby' => '1'
			);
		}	
		else if($jobFileName!="" && $appFileName!="")
		{
			$data = array(
			'job_titile' => $this->input->post('job_titile'),		
			'contact_person' => $this->input->post('contact_person'),
			'job_description_file_name' =>$jobFileName,
			'designation' => $this->input->post('designation'),
			'emailid' => $this->input->post('emailid'),
			'postingdate' => $postingdate,
			'lastdateofapply' => $lastdateofapply,	
			'uploaded_application_name'	=> $appFileName,		
			'createdby' => '1'
			);
		}	
		else 
		{
			$data = array(
			'job_titile' => $this->input->post('job_titile'),		
			'contact_person' => $this->input->post('contact_person'),	
			'designation' => $this->input->post('designation'),
			'emailid' => $this->input->post('emailid'),
			'postingdate' => $postingdate,
			'lastdateofapply' => $lastdateofapply,			
			'createdby' => '1'
			);
		}		
		
		return $this->db->update('job_tbl', $data, array('id'=>$id));
	}	
	
	public function delete_job($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		return $this->db->delete('job_tbl',  array('id'=>$id));
	}
	
	function get_file_extension($file_name) 
	{
		return end(explode('.',$file_name));
	}	
}