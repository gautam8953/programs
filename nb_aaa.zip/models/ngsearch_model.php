<?php

class ngsearch_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function get_lab($id = FALSE) {
        if ($id === FALSE) {
            $query = $this->db->get('laboratory_tbl');
            return $query->result_array();
        }

        $query = $this->db->get_where('laboratory_tbl', array('id' => $id));
        return $query->row_array();
    }

    public function get_zone($id = FALSE) {
        if ($id === FALSE) {
            $query = $this->db->get('zone_tbl');
            return $query->result_array();
        }

        $query = $this->db->get_where('zone_tbl', array('id' => $id));
        return $query->row_array();
    }

    // add by asmita
    public function get_state($id = FALSE) {
        if ($id === FALSE) {
            $query = $this->db->select('id,name');
            $query = $this->db->from('states');
            $query = $this->db->where(array('country_id' => '105'));
            $this->db->order_by("name", "asc");
            $query = $this->db->get('');
            return $query->result_array();
        }
        $query = $this->db->select('id,name');
        $query = $this->db->from('states');
        $query = $this->db->where(array('id' => $id));
        $query = $this->db->get('');
        $this->db->order_by("name", "asc");
        return $query->row_array();
    }

    public function get_city($id = FALSE) { //echo $id;
        if ($id === FALSE) {
            $query = $this->db->select('id,name');
            $query = $this->db->from('cities');
            $query = $this->db->where(array('id' => '0'));
            $query = $this->db->get('');

            return $query->result_array();
        }
        $query = $this->db->select('id,name');
        $query = $this->db->from('cities');
        $query = $this->db->where(array('stateid' => $id));
        $query = $this->db->get('');
        return $query->result_array();
    }

    ///city //////////////
    public function get_natureoflab($id = FALSE) {
        if ($id === FALSE) {
            $query = $this->db->get('lab_nature_tbl');
            return $query->result_array();
        }

        $query = $this->db->get_where('lab_nature_tbl', array('id' => $id));
        return $query->row_array();
    }

    public function get_operationAt($id = FALSE) {
        if ($id === FALSE) {
            $query = $this->db->get('lab_operations_tbl');
            return $query->result_array();
        }

        $query = $this->db->get_where('lab_operations_tbl', array('id' => $id));
        return $query->row_array();
    }

    public function get_facility($id = FALSE) {
        if ($id === FALSE) {
            $query = $this->db->get('facility_tbl');
            return $query->result_array();
        }

        $query = $this->db->get_where('facility_tbl', array('id' => $id));
        return $query->row_array();
    }
 public function search_page($limit) {

        $curdate = date("Y-m-d");
        $offset = $this->input->get('per_page');
        $likearray = array();
        $anlikearray = array();
        $array = array();
        $columnNames = '';
        $this->load->helper('url');
        $this->load->library('session');

        if (array_key_exists('submit', $_POST)) {

            $labName = $this->input->post('labname');
            $country = $this->input->post('country');
            if ($country === '1') {
                $state = $this->input->post('state');
                $city = $this->input->post('city');
            } else {
                $state = $city = '';
            }
            $zone = $this->input->post('zone');
            $searchword = $this->input->post('searchword');
            $nature_of_lab = $this->input->post('natureoflab');
            $operationAt = $this->input->post('operationat');
            $operationAtstr = '';
            if (count($operationAt) > 0 && $operationAt != "") {
                foreach ($operationAt as $key => $value)
                    $operationAtstr .= $value . ",";
            }
            $facility_id = $this->input->post('facility_id');
            $field_id = $this->input->post('field_id');
            $group_id = $this->input->post('group_id');
            $subgroup = $this->input->post('subgroup');
            $subgroup_id = '';
            $subgroupval_id = '';
            if (count($subgroup) > 0 && $subgroup != "") {
                foreach ($subgroup as $key => $value) {
                    $subgroup_id .= $value . ",";
                    $value = explode('-', $value);
                    if (isset($value[0])) {
                        $subgroupval_id .= $value[0] . ",";
                    }
                }
            }
            $subgroupval_id = str_replace(",,", ',', rtrim($subgroupval_id, ","));
            if ($country === '1') {
                $params = array('labName1' => $labName,
                    'country1' => $country,
                    'state1' => $state,
                    'city1' => $city,
                    'zone1' => $zone,
                    'searchword' => $searchword,
                    'nature_of_lab1' => $nature_of_lab,
                    'operationAtstr1' => $operationAtstr,
                    'facility_id1' => $facility_id,
                    'field_id1' => $field_id,
                    'group_id1' => $group_id,
                    'subgroup_id1' => $subgroup_id,
                );
            } else {
                $params = array('labName1' => $labName,
                    'country1' => $country,
                    'zone1' => $zone,
                    'searchword' => $searchword,
                    'nature_of_lab1' => $nature_of_lab,
                    'operationAtstr1' => $operationAtstr,
                    'facility_id1' => $facility_id,
                    'field_id1' => $field_id,
                    'group_id1' => $group_id,
                    'subgroup_id1' => $subgroup_id,
                );
            }

            $this->session->set_userdata($params);

            //echo "<pre>";print_r( $this->session->userdata);exit;
        } else {

            //Set all values to session		
            $country = $this->session->userdata('country1');
            $labName = $this->session->userdata('labName1');
            $state = $this->session->userdata('state1');
            $city = $this->session->userdata('city1');
            $searchword = $this->session->userdata('searchword');
            $zone = $this->session->userdata('zone1');
            $nature_of_lab = $this->session->userdata('nature_of_lab1');
            $operationAtstr = $this->session->userdata('operationAtstr1');
            $facility_id = $this->session->userdata('facility_id1');
            $field_id = $this->session->userdata('field_id1');
            $group_id = $this->session->userdata('group_id1');
            $subgroup_id = $this->session->userdata('subgroup_id1');
            if (trim($subgroup_id) != '') {
                $subgroup = explode(",", $subgroup_id);
                if (count($subgroup) > 0 && $subgroup != "") {

                    foreach ($subgroup as $key => $value) {
                        $subgroup_id .= $value . ",";
                        $value = explode('-', $value);
                        if (isset($value[0])) {
                            $subgroupval_id .= $value[0] . ",";
                        }
                    }
                }

                $subgroupval_id = str_replace(",,", ',', rtrim($subgroupval_id, ","));
            }
        }

        $tmpsubGroupArr = explode(",", $subgroup_id);
        $subGroupVal = ",";
        for ($d = 0; $d < count($tmpsubGroupArr); $d++) {

            $tmpsArr = explode("-", $tmpsubGroupArr[$d]);
            $subGroupVal .= $tmpsArr[0];
        }

        //echo "Lab Name Input Data - ".$this->session->userdata('labName');
        if ($labName != "") {
            $likearray['l.lab_name'] = $labName;
            //$anlikearray['c.file_content'] = $labName;
        }

        /* if($location!="")
          $likearray['l.lab_address']= $location;
         */
        if ($zone != "-1")
            $array['l.zone'] = $zone;
        if ($country === '1') {
            if ($state != "-1")
                $array['s.id'] = $state;
            if ($city != "-1")
                $array['city.id'] = $city;
        }else {
            $array['ctry.id'] = $country;
        }

        /*
          commeted By Ashit 20-09-2013 For serching the keywords.
          if($searchword!="")
          $likearray['LOWER(c.file_content)'] = 	$searchword; */
        //Ashit code starts
        if ($searchword != "") {
            $this->db->where("(c.file_content like '%" . strtoupper($searchword) . "%' OR c.file_content like '%" . strtolower($searchword) . "%' OR c.file_content like '%" . ucwords($searchword) . "%' OR c.file_content like '%" . $searchword . "%')");
        }
        // Ashit code ends
        /* //Asmita code starts
          if($searchword!="")
          {
          $this->db->where("LOWER(c.file_content) like '%".strtolower($searchword)."%'");

          }
          // Ashit code ends */


        if ($nature_of_lab != "-1")
            $array['c.nature_of_lab'] = $nature_of_lab;
        if ($operationAtstr != "")
            $array['c.operationat'] = $operationAtstr;
        /*
          commented by Ashit 19-09-2013 for searching the group
          if($subgroup_id!="")
          {
          $array['c.sub_group_id']= $subGroupVal;
          } */
        //Ashit code starts
        if ($subgroupval_id != "") {
            $subgroupvalArr = explode(",", $subgroupval_id);
            $subgroupwhere = '';
            foreach ($subgroupvalArr as $subgroupval_id) {
                $subgroupwhere .= ' FIND_IN_SET("' . $subgroupval_id . '",c.sub_group_id) OR';

                // $this->db->where('FIND_IN_SET(c.sub_group_id,'.$subgroupval_id.')',$subgroupval_id);
            }

            $subgroupwhere = rtrim($subgroupwhere, 'OR');
            $this->db->where('(' . $subgroupwhere . ')');


            // $this->db->where('FIND_IN_SET(c.sub_group_id,'.$subgroupval_id.')',$subgroupval_id);
            //$array['c.sub_group_id']= $subGroupVal;	
        }
        //Ashit code ends
        /*
          Commented by Ashit date 19-09-2013 for searching on the besis of subgroups.
          if($group_id!="-1" && $subgroup_id=="")	{
          $array['c.group_id']= $group_id;
          } */
        /*
          if($group_id!="-1" )	{
          $array['c.group_id']= $group_id;
          //$this->db->where("c.sub_group_id like '%".$group_id."%'"); Commented by Shubham on 20 March 2015

          }
         */
        //22-03-2017
        //if($field_id!="-1" && $group_id=="-1" && $subgroup_id=="")	
        //$array['c.filed_id']= $field_id;
        //if($field_id!="-1" && !empty($field_id))
        //$array['c.filed_id']= $field_id;
        //22/03/2017 end
        //echo 'val-'.$facility_id.",".$field_id.",".$group_id.",".$subgroup_id;

        if ($facility_id != "-1" && ($field_id == "-1" || empty($field_id))) //&& $group_id=="-1" && $subgroup_id=="")		
            $array['c.faclity_id'] = $facility_id;

        $array['c.status'] = 1;
        $array['l.status'] = 1;

        //$this->db->select('l.id, l.lab_name, l.lab_registration_code, l.lab_address, l.pincode, l.contact_person, l.designation, l.phone, l.emailid, l.fax, getOperationName(c.id) as opertaionAtName, c.expiry_date, c.status, city.name as cityName, s.name as stateName, ctry.name as countryName, ln.nature_name, z.zone_name');//'c.lab_id, c.certificate_no, c.certificate_file, c.issue_date, c.expiry_date, l.lab_name, l.lab_address, l.zone,f.facility_name'
        $this->db->select('count(DISTINCT(l.lab_registration_code)) as total_rows');
//        $this->db->distinct('l.lab_registration_code');
        $this->db->from('laboratory_tbl As l');
        $this->db->join('lab_certificate_tbl As c', 'c.lab_id=l.id'); //		
        $this->db->join('cities As city', 'l.city=city.id', 'left'); //
        $this->db->join('states As s', 'l.state=s.id', 'left'); //
        $this->db->join('country As ctry', 'l.country=ctry.id', 'left'); //		
        $this->db->join('zone_tbl As z', 'l.zone=z.id', 'left'); //
        //$this->db->join('lab_nature_tbl As ln', 'c.nature_of_lab=ln.id', 'left');//
        //$this->db->join('lab_operations_tbl As oa', 'c.operationat=oa.id', 'left');//

        if ($subgroup_id != "") {
            
        }

        if ($group_id != "-1" && $subgroup_id == "") {
            
        }

        if ($field_id != "-1" && $group_id == "-1" && $subgroup_id == "") {
            
        }

        if ($facility_id != "-1" && $field_id == "-1" && $group_id == "-1" && $subgroup_id == "") {
            
        }

        $this->db->where($array);
        $this->db->where('c.expiry_date >=', $curdate);
        //$this->db->or_where('c.expiry_date IS NULL',NULL);
        //@10-04-2017
        $str = '';
        if ($labName != "") {
            $str .= "l.lab_name LIKE '%$labName%' ";
        }

        if (count($field_id) > 0 && !empty($field_id) && $field_id[0] != '-1') {
            $andor = '';
            //$dicpline_id = implode(',', $field_id);
            if (!empty($str)) {
                $andor = ' AND (';
                foreach ($field_id as $dicpline_id) {
                    if ($dicpline_id != '-1') {
                        $str .= "$andor FIND_IN_SET($dicpline_id, `c`.`filed_id`)";
                    }
                    $andor = ' OR ';
                }
                $str .= ')';
            } else {
                $andor = '';
                $str .= '(';
                foreach ($field_id as $dicpline_id) {
                    if ($dicpline_id != '-1') {
                        $str .= $andor . "FIND_IN_SET($dicpline_id, `c`.`filed_id`)";
                    }
                    $andor = ' OR ';
                }
                $str .= ')';
            }
        }
        if (!empty($str))
            $this->db->where($str);


        if (!empty($group_id) && $group_id != "-1" && empty($subgroupval_id) && $subgroupval_id != "-1") {
            $query = $this->db->get();
        } else {
            $query = $this->db->get('', $limit, $offset);
        }
        echo $this->db->last_query(); //die('end');
        return $query->result_array();
        
       
    }
    public function search($limit) {

        $curdate = date("Y-m-d");
        $offset = $this->input->get('per_page');
        $likearray = array();
        $anlikearray = array();
        $array = array();
        $columnNames = '';
        $this->load->helper('url');
        $this->load->library('session');

        if (array_key_exists('submit', $_POST)) {

            $labName = $this->input->post('labname');
            $country = $this->input->post('country');
            if ($country === '1') {
                $state = $this->input->post('state');
                $city = $this->input->post('city');
            } else {
                $state = $city = '';
            }
            $zone = $this->input->post('zone');
            $searchword = $this->input->post('searchword');
            $nature_of_lab = $this->input->post('natureoflab');
            $operationAt = $this->input->post('operationat');
            $operationAtstr = '';
            if (count($operationAt) > 0 && $operationAt != "") {
                foreach ($operationAt as $key => $value)
                    $operationAtstr .= $value . ",";
            }
            $facility_id = $this->input->post('facility_id');
            $field_id = $this->input->post('field_id');
            $group_id = $this->input->post('group_id');
            $subgroup = $this->input->post('subgroup');
            $subgroup_id = '';
            $subgroupval_id = '';
            if (count($subgroup) > 0 && $subgroup != "") {
                foreach ($subgroup as $key => $value) {
                    $subgroup_id .= $value . ",";
                    $value = explode('-', $value);
                    if (isset($value[0])) {
                        $subgroupval_id .= $value[0] . ",";
                    }
                }
            }
            $subgroupval_id = str_replace(",,", ',', rtrim($subgroupval_id, ","));
            if ($country === '1') {
                $params = array('labName1' => $labName,
                    'country1' => $country,
                    'state1' => $state,
                    'city1' => $city,
                    'zone1' => $zone,
                    'searchword' => $searchword,
                    'nature_of_lab1' => $nature_of_lab,
                    'operationAtstr1' => $operationAtstr,
                    'facility_id1' => $facility_id,
                    'field_id1' => $field_id,
                    'group_id1' => $group_id,
                    'subgroup_id1' => $subgroup_id,
                );
            } else {
                $params = array('labName1' => $labName,
                    'country1' => $country,
                    'zone1' => $zone,
                    'searchword' => $searchword,
                    'nature_of_lab1' => $nature_of_lab,
                    'operationAtstr1' => $operationAtstr,
                    'facility_id1' => $facility_id,
                    'field_id1' => $field_id,
                    'group_id1' => $group_id,
                    'subgroup_id1' => $subgroup_id,
                );
            }

            $this->session->set_userdata($params);

            //echo "<pre>";print_r( $this->session->userdata);exit;
        } else {

            //Set all values to session		
            $country = $this->session->userdata('country1');
            $labName = $this->session->userdata('labName1');
            $state = $this->session->userdata('state1');
            $city = $this->session->userdata('city1');
            $searchword = $this->session->userdata('searchword');
            $zone = $this->session->userdata('zone1');
            $nature_of_lab = $this->session->userdata('nature_of_lab1');
            $operationAtstr = $this->session->userdata('operationAtstr1');
            $facility_id = $this->session->userdata('facility_id1');
            $field_id = $this->session->userdata('field_id1');
            $group_id = $this->session->userdata('group_id1');
            $subgroup_id = $this->session->userdata('subgroup_id1');
            if (trim($subgroup_id) != '') {
                $subgroup = explode(",", $subgroup_id);
                if (count($subgroup) > 0 && $subgroup != "") {

                    foreach ($subgroup as $key => $value) {
                        $subgroup_id .= $value . ",";
                        $value = explode('-', $value);
                        if (isset($value[0])) {
                            $subgroupval_id .= $value[0] . ",";
                        }
                    }
                }

                $subgroupval_id = str_replace(",,", ',', rtrim($subgroupval_id, ","));
            }
        }

        $tmpsubGroupArr = explode(",", $subgroup_id);
        $subGroupVal = ",";
        for ($d = 0; $d < count($tmpsubGroupArr); $d++) {

            $tmpsArr = explode("-", $tmpsubGroupArr[$d]);
            $subGroupVal .= $tmpsArr[0];
        }

        //echo "Lab Name Input Data - ".$this->session->userdata('labName');
        if ($labName != "") {
            $likearray['l.lab_name'] = $labName;
            //$anlikearray['c.file_content'] = $labName;
        }

        /* if($location!="")
          $likearray['l.lab_address']= $location;
         */
        if ($zone != "-1")
            $array['l.zone'] = $zone;
        if ($country === '1') {
            if ($state != "-1")
                $array['s.id'] = $state;
            if ($city != "-1")
                $array['city.id'] = $city;
        }else {
            $array['ctry.id'] = $country;
        }

        /*
          commeted By Ashit 20-09-2013 For serching the keywords.
          if($searchword!="")
          $likearray['LOWER(c.file_content)'] = 	$searchword; */
        //Ashit code starts
        if ($searchword != "") {
            $this->db->where("(c.file_content like '%" . strtoupper($searchword) . "%' OR c.file_content like '%" . strtolower($searchword) . "%' OR c.file_content like '%" . ucwords($searchword) . "%' OR c.file_content like '%" . $searchword . "%')");
        }
        // Ashit code ends
        /* //Asmita code starts
          if($searchword!="")
          {
          $this->db->where("LOWER(c.file_content) like '%".strtolower($searchword)."%'");

          }
          // Ashit code ends */


        if ($nature_of_lab != "-1")
            $array['c.nature_of_lab'] = $nature_of_lab;
        if ($operationAtstr != "")
            $array['c.operationat'] = $operationAtstr;
        /*
          commented by Ashit 19-09-2013 for searching the group
          if($subgroup_id!="")
          {
          $array['c.sub_group_id']= $subGroupVal;
          } */
        //Ashit code starts
        if ($subgroupval_id != "") {
            $subgroupvalArr = explode(",", $subgroupval_id);
            $subgroupwhere = '';
            foreach ($subgroupvalArr as $subgroupval_id) {
                $subgroupwhere .= ' FIND_IN_SET("' . $subgroupval_id . '",c.sub_group_id) OR';

                // $this->db->where('FIND_IN_SET(c.sub_group_id,'.$subgroupval_id.')',$subgroupval_id);
            }

            $subgroupwhere = rtrim($subgroupwhere, 'OR');
            $this->db->where('(' . $subgroupwhere . ')');


            // $this->db->where('FIND_IN_SET(c.sub_group_id,'.$subgroupval_id.')',$subgroupval_id);
            //$array['c.sub_group_id']= $subGroupVal;	
        }
        //Ashit code ends
        /*
          Commented by Ashit date 19-09-2013 for searching on the besis of subgroups.
          if($group_id!="-1" && $subgroup_id=="")	{
          $array['c.group_id']= $group_id;
          } */
        /*
          if($group_id!="-1" )	{
          $array['c.group_id']= $group_id;
          //$this->db->where("c.sub_group_id like '%".$group_id."%'"); Commented by Shubham on 20 March 2015

          }
         */
        //22-03-2017
        //if($field_id!="-1" && $group_id=="-1" && $subgroup_id=="")	
        //$array['c.filed_id']= $field_id;
        //if($field_id!="-1" && !empty($field_id))
        //$array['c.filed_id']= $field_id;
        //22/03/2017 end
        //echo 'val-'.$facility_id.",".$field_id.",".$group_id.",".$subgroup_id;

        if ($facility_id != "-1" && ($field_id == "-1" || empty($field_id))) //&& $group_id=="-1" && $subgroup_id=="")		
            $array['c.faclity_id'] = $facility_id;

        $array['c.status'] = 1;
        $array['l.status'] = 1;

        //$this->db->select('l.id, l.lab_name, l.lab_registration_code, l.lab_address, l.pincode, l.contact_person, l.designation, l.phone, l.emailid, l.fax, getOperationName(c.id) as opertaionAtName, c.expiry_date, c.status, city.name as cityName, s.name as stateName, ctry.name as countryName, ln.nature_name, z.zone_name');//'c.lab_id, c.certificate_no, c.certificate_file, c.issue_date, c.expiry_date, l.lab_name, l.lab_address, l.zone,f.facility_name'
        $this->db->select('c.sub_group_id,l.id, l.lab_name,l.lab_registration_code, l.lab_address, l.pincode, l.contact_person, l.designation, l.phone, l.emailid, l.fax, city.name as cityName, s.name as stateName, ctry.name as countryName, z.zone_name');
        $this->db->distinct('l.lab_registration_code');
        $this->db->from('laboratory_tbl As l');
        $this->db->join('lab_certificate_tbl As c', 'c.lab_id=l.id'); //		
        $this->db->join('cities As city', 'l.city=city.id', 'left'); //
        $this->db->join('states As s', 'l.state=s.id', 'left'); //
        $this->db->join('country As ctry', 'l.country=ctry.id', 'left'); //		
        $this->db->join('zone_tbl As z', 'l.zone=z.id', 'left'); //
        //$this->db->join('lab_nature_tbl As ln', 'c.nature_of_lab=ln.id', 'left');//
        //$this->db->join('lab_operations_tbl As oa', 'c.operationat=oa.id', 'left');//

        if ($subgroup_id != "") {
            
        }

        if ($group_id != "-1" && $subgroup_id == "") {
            
        }

        if ($field_id != "-1" && $group_id == "-1" && $subgroup_id == "") {
            
        }

        if ($facility_id != "-1" && $field_id == "-1" && $group_id == "-1" && $subgroup_id == "") {
            
        }

        $this->db->where($array);
        $this->db->where('c.expiry_date >=', $curdate);
        //$this->db->or_where('c.expiry_date IS NULL',NULL);
        //@10-04-2017
        $str = '';
        if ($labName != "") {
            $str .= "l.lab_name LIKE '%$labName%' ";
        }

        if (count($field_id) > 0 && !empty($field_id) && $field_id[0] != '-1') {
            $andor = '';
            //$dicpline_id = implode(',', $field_id);
            if (!empty($str)) {
                $andor = ' AND (';
                foreach ($field_id as $dicpline_id) {
                    if ($dicpline_id != '-1') {
                        $str .= "$andor FIND_IN_SET($dicpline_id, `c`.`filed_id`)";
                    }
                    $andor = ' OR ';
                }
                $str .= ')';
            } else {
                $andor = '';
                $str .= '(';
                foreach ($field_id as $dicpline_id) {
                    if ($dicpline_id != '-1') {
                        $str .= $andor . "FIND_IN_SET($dicpline_id, `c`.`filed_id`)";
                    }
                    $andor = ' OR ';
                }
                $str .= ')';
            }
        }
        if (!empty($str))
            $this->db->where($str);

        //$this->db->like($likearray);

        /* if($location!="")
          {
          $this->db->like('s.name',$location);
          $this->db->or_like('l.lab_address',$location);
          $this->db->or_like('city.name',$location);
          } */
        $this->db->group_by('c.lab_id');
        $this->db->order_by('l.lab_registration_code', 'l.lab_name');


        if (!empty($group_id) && $group_id != "-1" && empty($subgroupval_id) && $subgroupval_id != "-1") {
            $query = $this->db->get();
        } else {
            $query = $this->db->get('', $limit, $offset);
        }
        echo $this->db->last_query(); //die('end');
        if (!empty($group_id) && $group_id != "-1" && empty($subgroupval_id) && $subgroupval_id != "-1") {
            $final_result = array();
            $all_data = $query->result_array();
            foreach ($all_data as $rec) {
                if (strpos($rec['sub_group_id'], $group_id)) {
                    $final_result[] = $rec;
                }
            }
            if ($limit != "") {
                if (count($final_result) > 10) {
                    $_SESSION['SEARCH_BY_GROUP_DATA'] = $final_result;
                    $new_final_result = array();
                    $tmp = 0;

                    if (empty($offset))
                        $offset = 0;

                    for ($cnt = $offset; $cnt < count($_SESSION['SEARCH_BY_GROUP_DATA']); $cnt++) {
                        $new_final_result[] = $_SESSION['SEARCH_BY_GROUP_DATA'][$cnt];
                        $tmp++;
                        if ($tmp >= 10)
                            break;
                    }
                    unset($_SESSION['SEARCH_BY_GROUP_DATA']);
                    return $new_final_result;
                }
                else {
                    return $final_result;
                }
            } else {
                return $final_result;
            }
        } else {
            return $query->result_array();
        }
    }

    public function searchcertificateresult() {

        $curdate = date("Y-m-d");
        $fieldid = '';
        $labid = $this->input->get('cno');
        $fieldid = $this->input->get('fid');
//die();
        $this->db->select("*, `c`.`id` as cid, `f`.`id`, `f`.`category_name` as facilityName,
 `fd`.`id`, `fd`.`category_name` as fieldName, `cities`.`name` as City, `states`.`name` as State, 
 `country`.`name` as Country, 
 (SELECT GROUP_CONCAT(category_name) FROM lab_category_tbl WHERE FIND_IN_SET(id, `c`.`filed_id` ) ) as discipline_name");
//$this->db->select("getSubGroupName(c.id,c.group_id) As subGroupName",false);		
        $this->db->from('certificate_operation_and_subgroup_tbl as labcer');
        $this->db->join('lab_certificate_tbl As c', 'labcer.certificate_id=c.id'); //
        $this->db->join('laboratory_tbl As l', 'c.lab_id=l.id');
        //$this->db->join('lab_category_tbl As g', 'c.group_id=g.id');	
        $this->db->join('lab_category_tbl As fd', 'c.filed_id=fd.id');
        $this->db->join('lab_category_tbl As f', 'c.faclity_id=f.id', 'left');
        $this->db->join('zone_tbl As z', 'l.zone=z.id'); //
        $this->db->join('lab_nature_tbl As ln', 'c.nature_of_lab=ln.id'); //
        $this->db->join('lab_operations_tbl As oa', 'c.operationat=oa.id'); //

        $this->db->join('cities', 'l.city=cities.id', 'left');
        $this->db->join('states', 'l.state=states.id', 'left');
        $this->db->join('country', 'l.country=country.id', 'left');

        $this->db->where('c.lab_id', $labid);
        $this->db->where('c.expiry_date >=', $curdate);
        if ($fieldid != '' && $fieldid != '-1') {
            $this->db->where('c.filed_id', $fieldid);
        }
        $this->db->where('c.status', "1");
        $query = $this->db->get();

        //echo '<pre>';
        //print_r($this->db);die();
        //print_r($query->result_array()); die('end');
        //echo $this->db->last_query(); die('end');
        return $query->result_array();
    }

    public function searchcertificate() {

        $labid = $this->input->get('cno');
        //die();
        $this->db->select("*, c.id as cid, f.id, f.category_name as facilityName, fd.id, fd.category_name as fieldName");
        //$this->db->select("getSubGroupName(c.id,c.group_id) As subGroupName",false);		
        $this->db->from('certificate_operation_and_subgroup_tbl As labcer');
        $this->db->join('lab_certificate_tbl As c', 'labcer.certificate_id=c.id'); //
        $this->db->join('laboratory_tbl As l', 'c.lab_id=l.id');
        //$this->db->join('lab_category_tbl As g', 'c.group_id=g.id');	
        $this->db->join('lab_category_tbl As fd', 'c.filed_id=fd.id');
        $this->db->join('lab_category_tbl As f', 'c.faclity_id=f.id');
        $this->db->join('zone_tbl As z', 'l.zone=z.id'); //
        $this->db->join('lab_nature_tbl As ln', 'c.nature_of_lab=ln.id'); //
        $this->db->join('lab_operations_tbl As oa', 'c.operationat=oa.id'); //
        $this->db->where('c.lab_id', $labid);

        $query = $this->db->get();
        return $query->result_array();
    }

    public function viewGroupSubGroup($certificateid = '') {
        //$certificateid = $this->input->get('cno');
        $this->db->select("csgt.certificate_id , csgt.group_id, gt.category_name as groupName");
        $this->db->select(",getGroupSubGroupName(csgt.certificate_id, csgt.group_id) As subGroupName", false);
        $this->db->distinct('csgt.group_id');
        $this->db->from('certificate_sub_group_tbl AS csgt');
        $this->db->join('lab_category_tbl AS gt', 'csgt.group_id=gt.id');
        $this->db->where('csgt.certificate_id', $certificateid);
        $this->db->group_by('csgt.group_id', 'csgt.certificate_id');
        $this->db->order_by('csgt.group_id', 'csgt.certificate_id');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function viewGroupSubGroupPro($certificateid = '') {
        $query = "SELECT
						c1.category_name AS Discipline,
						c2.category_name AS Groupname,
						c3.category_name AS Subgroup
				  FROM lab_category_tbl c1
				  INNER JOIN lab_category_tbl c2 on c1.id=c2.cat_id
				  INNER JOIN lab_category_tbl c3 on c2.id=c3.cat_id 
				  INNER JOIN 
				  (SELECT sub_group_id FROM certificate_sub_group_tbl WHERE certificate_id=$certificateid) T 
				  ON T.sub_group_id=c3.id";
        $result = $this->db->query($query);
        return $result->result_array();
    }

}
