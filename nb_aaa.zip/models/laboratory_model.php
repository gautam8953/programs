<?php
class laboratory_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_lab_all_laboratory($num)
	{		
		$this->load->helper('url');	
		$offset = $this->input->get('per_page');	
		$labcode = "";
		$labname = "";		
	    $labcode = $this->input->post('labcode');
	    $labname = $this->input->post('labname');
		$query = $this->db->select('*');
		$query = $this->db->from('laboratory_tbl');
		if($labcode!="")
		{
			$query = $this->db->where('lab_registration_code',$labcode);
		}
		if($labname!="")
		{
			$query = $this->db->like('lab_name',$labname);
		}
		$query = $this->db->order_by('lab_registration_code','lab_name');
		$query = $this->db->get('', $num, $offset);
		return $query->result_array();		
	}

	public function count_all_labs()
	{		
		//$offset = $this->input->get('per_page');	
		$labcode1 = "";
		$labname1 = "";		
	    $labcode1 = $this->input->post('labcode');
	    $labname1 = $this->input->post('labname');
		$query1 = $this->db->select('*');
		$query1 = $this->db->from('laboratory_tbl');
		if($labcode1!="")
		{
			$query1 = $this->db->where('lab_registration_code',$labcode1);
		}
		if($labname1!="")
		{
			$query1 = $this->db->like('lab_name',$labname1);
		}
		$query1 = $this->db->order_by('lab_registration_code','lab_name');
		$query1 = $this->db->get('');
		return $query1->result_array();
	}
	
	public function get_InactiveLaboratories($num)
	{
		$offset = $this->input->get('per_page');
		$whereCond = array('status'=>0);		
		$this->db->select('l.id, l.lab_name, l.lab_registration_code, l.lab_address');
		$this->db->from('laboratory_tbl as l');
		$this->db->where($whereCond);
		$this->db->order_by('l.lab_registration_code');
		$query = $this->db->get('',$num,$offset);
		return $query->result_array();
	}
	
	public function count_InactiveLaboratories()
	{		
		$query = $this->db->get_where('laboratory_tbl', array('status'=>0));
		return $query->result_array();
	}
	
	
	public function get_laboratory_details($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->select('*');
			$query = $this->db->from('laboratory_tbl');
			$query = $this->db->where('status',1);
			$query = $this->db->order_by('lab_registration_code','lab_name');
			$query = $this->db->get('');
			return $query->result_array();
		}

		$query = $this->db->get_where('laboratory_tbl', array('id' => $id));
		//print_r($query->row_array());
		return $query->row_array();
	}
	
	public function get_states($id = FALSE)
	{       $this->db->order_by("name", "asc");
		if ($id === FALSE)
		{
			$query = $this->db->get('states');
			return $query->result_array();
		}

		$query = $this->db->get_where('states', array('id' => $id));	
		return $query->row_array();
	}
	
	public function get_city($id = FALSE)
	{       $this->db->order_by("name", "asc");
		if ($id === FALSE)
		{
			$query = $this->db->get('cities');
			return $query->result_array();
		}

		$query = $this->db->get_where('cities', array('id' => $id));		
		return $query->row_array();
	}
	
	public function get_country($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('country');
			return $query->result_array();
		}

		$query = $this->db->get_where('country', array('id' => $id));		
		return $query->row_array();
	}
	
	
	
	public function get_zone($id = FALSE)
	{
		if ($id === FALSE)
		{
			$query = $this->db->get('zone_tbl');
			return $query->result_array();
		}

		$query = $this->db->get_where('zone_tbl', array('id' => $id));	
		return $query->row_array();
	}
	
	public function viewLaboratory()
	{
		$labid = $this->input->get('lno');
		//die();
		$this->db->select("l.*, city.name as cityName, s.name as stateName, c.name as countryName, z.zone_name as zoneName");	
		$this->db->from('laboratory_tbl As l');
		$this->db->join('cities As city', 'l.city=city.id','left');					
		$this->db->join('states As s', 'l.state=s.id','left');
		$this->db->join('country As c', 'l.country=c.id','left');
		$this->db->join('zone_tbl As z', 'l.zone=z.id','left');
		$this->db->where('l.id',$labid);
		$query = $this->db->get();
		return $query->result_array();
	}
	
	public function set_laboratory()
	{		
		$this->load->helper('url');		
		
		$arrmsg = array();
		
		if($this->input->post('registration_date')!="")
		{
		$regisDate = explode('-',$this->input->post('registration_date'));
		$regisDate = array_reverse($regisDate);	
		$newRegistrationDate = implode('-',$regisDate);		
		}
		else 
		{
			$newRegistrationDate = "0000-00-00";
		}
		
		if($this->checkUniqueLabRegistrationCode($this->input->post('labo_regis_code')))
		{
			$arrmsg['duplicate'] = "duplicate";
			return $arrmsg;
		}
		else
		{		
			//echo "Anshu - ";	
			$data = array(
							'lab_name' => $this->input->post('labo_name'),
							'lab_registration_code' => $this->input->post('labo_regis_code'),
							'lab_address' => $this->input->post('address'),
							'city' => $this->input->post('city'),
							'state' => $this->input->post('state'),
							'country' => $this->input->post('country'),
							'zone' => $this->input->post('zone'),
							'otherzone' => $this->input->post('otherzone'),
							'pincode' => $this->input->post('pincode'),
							'contact_person' => $this->input->post('contactperson'),
							'designation' => $this->input->post('designation'),
							'phone' => $this->input->post('phone'),	
							'emailid' => $this->input->post('emailid'),	
							'fax' => $this->input->post('fax'),	
							'registration_date' => $newRegistrationDate,	
							'status'=>1,
							'createdby' => '1'
			);
			if($this->db->insert('laboratory_tbl', $data))
			{
				//echo "IF - ";
					//$this->db->insert('laboratory_tbl', $data);
					$arrmsg['success']="success";
					return $arrmsg;
					
			}
			else 
			{
				//echo "ELSE - ";
				$arrmsg['unsuccess'] = "unsuccess";
				return $arrmsg;
			}
			
			
			
		}
		
	}

	public function update_laboratory($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		if($this->input->post('registration_date')!="")
		{
			$regisDate = explode('-',$this->input->post('registration_date'));
			$regisDate = array_reverse($regisDate);	
			$newRegistrationDate = implode('-',$regisDate);		
		}
		else 
		{
			$newRegistrationDate = "0000-00-00";
		}				
		$data = array(
						'lab_name' => $this->input->post('labo_name'),
						'lab_registration_code' => $this->input->post('labo_regis_code'),
						'lab_address' => $this->input->post('address'),
						'city' => $this->input->post('city'),
						'state' => $this->input->post('state'),
						'country' => $this->input->post('country'),
						'zone' => $this->input->post('zone'),
						'otherzone' => $this->input->post('otherzone'),
						'pincode' => $this->input->post('pincode'),
						'contact_person' => $this->input->post('contactperson'),
						'designation' => $this->input->post('designation'),
						'phone' => $this->input->post('phone'),	
						'emailid' => $this->input->post('emailid'),	
						'fax' => $this->input->post('fax'),	
						'registration_date' => $newRegistrationDate,
						'modifiedby' => '1',
						'modifiedon' => date('Y-m-d h:i:s')
		);
		return $this->db->update('laboratory_tbl', $data, array('id'=>$id));
	}

	public function delete_laboratory($id)
	{
		$this->load->helper('url');
		//$slug = url_title($this->input->post('category_name'), 'dash', TRUE);
		return $this->db->delete('laboratory_tbl',  array('id'=>$id));
	}
	
	public function update_status_laboratory($status, $id)
	{		
		//$this->load->helper('url');
		if($status==1)
		{
			if($this->db->update('laboratory_tbl', array('status'=>0), array('id'=>$id)))
					return true;
			else 
					return false;	
		}
		if($status==0)
		{
			if($this->db->update('laboratory_tbl', array('status'=>1), array('id'=>$id)))
					return true;
			else 
					return false;
		}	
		
	}
	
	public function checkUniqueLabRegistrationCode($labcode)
	{
		$query = $this->db->get_where('laboratory_tbl', array('lab_registration_code'=>$labcode));
		return $query->row_array();
	}
	
	public function search_lab($num)
	{
		$this->load->helper('url');	
		$offset = $this->input->get('per_page');		
	    $labcode = $this->input->post('labcode');
	    $labname = $this->input->post('labname');
		$query = $this->db->select('*');
		$query = $this->db->from('laboratory_tbl');
		if($labcode!="")
		{
			$query = $this->db->where('lab_registration_code',$labcode);
		}
		if($labname!="")
		{
			$query = $this->db->like('lab_name',$labname);
		}
		$query = $this->db->order_by('lab_registration_code','lab_name');
		$query = $this->db->get('', $num, $offset);
		return $query->result_array();		
	}
	
	public function get_all_laboratory()
	{		
		$query = $this->db->select('*');
		$query = $this->db->from('laboratory_tbl');	
		$query = $this->db->order_by('lab_registration_code','lab_name');
		$query = $this->db->get('');
		return $query->result_array();		
	}
}