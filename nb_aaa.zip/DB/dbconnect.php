<?php
$con = mysql_connect('localhost','rvsolutions_nabl','Aknu84*8');
mysql_select_db('rvsolutions_nabl',$con);
?>
