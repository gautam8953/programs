import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services/login.service';
import { LoginData } from '../../Models/Login';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginData:LoginData;
  constructor( private loginService: LoginService) {
    // this.loginData={
    // }
  }

  ngOnInit() {
  }
  
  login(username,password){
    if(!username || !password){
      alert('Please enter username and password');
    } else {
      this.loginData={
        'username': username,
        'password': password
      }
      //this.loginService.loginUser(this.loginData).subscribe(res=>{
      this.loginService.loginUser({username,password} as LoginData).subscribe(res=>{
        console.log(res.code);
        //this.newPost.emit(post);
      });
    }
  }
}

