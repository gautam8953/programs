$(document).ready(function () {

    $('#osceForm').submit(function() {
        $(this).ajaxSubmit({
          beforeSubmit:  showRequest,
          success: showResponse,
          type: 'POST',
          dataType: 'json',
          data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false; 
    });

});

function showResponse(responseText, statusText, xhr, $form)  {
    $("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
    if(parseInt(responseText.code)==0){
        swal(responseText.msg).then((value) => {
            window.location.replace(pageMainUrl+"reports/osce");
        });
    } else {
      swal(responseText.msg);
      $('#osceRpt').prop('disabled',false);
    }
    /*if(parseInt(responseText.code)==0){
      $("#msgDiv").removeClass('alert-danger');
      $("#msgDiv").addClass('alert-success').show();
    } else {
      $("#msgDiv").removeClass('alert-success');
      $("#msgDiv").addClass('alert-danger').show();
      $('#osceRpt').prop('disabled',false);
    }    
    $("#LoginMsg").text(responseText.msg);
    setTimeout(function() { 
    if(parseInt(responseText.code)==0){
      window.location.replace(pageMainUrl+"reports/osce");
    }
    }, 3000);*/
}
function showRequest(formData, jqForm, options) { 
    var check='0';
    $('#osceRpt').prop('disabled',true);
    var inputCheck=$('#osceForm input[type="text"]').filter(function(){
      return $(this).val()=='';
    });
    if(parseInt(inputCheck.length)>0){
      inputCheck.closest('.form-group').addClass('has-error');
    }
    if($('input[name="dakshata"]').is('checked')){
      $('input[name="dakshata"]').removeClass('has-error');
    } else {
      $('input[name="dakshata"]').addClass('has-error');      
    }
    if($('input[name="daksh"]').is('checked')){
      $('input[name="daksh"]').removeClass('has-error');
    } else {
      $('input[name="daksh"]').addClass('has-error');      
    }
    if($('input[name="others"]').is('checked')){
      $('input[name="others"]').removeClass('has-error');
    } else {
      $('input[name="others"]').addClass('has-error');      
    }
    if($('input[name="trained"]').is('checked')){
      $('input[name="trained"]').removeClass('has-error');
    } else {
      $('input[name="trained"]').addClass('has-error');      
    }

    if($('#participant').val()=='' || $('#participant').val()=='undefined'){
      $('#participant').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#participant').closest('.form-group').removeClass('has-error');
    }
    if($('#remarks').val()=='' || $('#remarks').val()=='undefined'){
      $('#remarks').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#remarks').closest('.form-group').removeClass('has-error');
    }

    if(check!='0'){
      $('#osceRpt').prop('disabled',false);
      return false;
    }
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    return true; 
}

function changeTrained(){
    var check=0;
    if($('input[name="dakshata"]:checked').val()=='1'){
        check=1;
    }
    if($('input[name="daksh"]:checked').val()=='1'){
        check=1;
    }
    if(check==1){
        $('#trained_0').prop('checked',false);
        $('#trained_1').prop('checked',true);
    } else {
        $('#trained_1').prop('checked',false);
        $('#trained_0').prop('checked',true);
    }
}
function calculateScore(){
    var score1=parseInt($('#score1').val())||0;
    var score2=parseInt($('#score2').val())||0;
    var score3=parseInt($('#score3').val())||0;
    var score4=parseInt($('#score4').val())||0;
    var scoreTot=parseInt(score1+score2+score3+score4)||0;
    var scorePer=parseInt((scoreTot*100)/80);
    if(parseInt(score1)>=16 && parseInt(score2)>=16 && parseInt(score3)>=16 && parseInt(score4)>=16){
        scoreRes='1';
    } else {
        scoreRes='0';
    }
    $('#scoreTot').val(scoreTot);
    $('#scoreRes').val(scoreRes);
    $('#scorePer').val(scorePer);

}