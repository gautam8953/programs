$(document).ready(function () {
    $('input[name="BaselineNQASChecklistLR"]').click(function(e){
        e.preventDefault();
    });
    $('input[name="BaselineNQASChecklistOT"]').click(function(e){
        e.preventDefault();
    });
    // Step show event
    $("#smartwizard").on("showStep", function (e, anchorObject, stepNumber, stepDirection, stepPosition) {
        if (stepPosition === 'first') {
            $(".saveBtn").hide();
            $(".saveBtn").addClass('disabled');
            $('.draftBtn').prop('disabled', false);
            $("#prev-btn").addClass('disabled');
        } else if (stepPosition === 'final') {
            $(".saveBtn").show();
            $(".saveBtn").removeClass('disabled');
            $('.saveBtn').prop('disabled', false);
            $('.draftBtn').prop('disabled', false);
            $("#next-btn").addClass('disabled');
        } else {
            $(".saveBtn").hide();
            $(".saveBtn").addClass('disabled');
            $("#prev-btn").removeClass('disabled');
            $("#next-btn").removeClass('disabled');
        }
    });

    // Toolbar extra buttons
    var btnSave = $('<button></button>').text('Submit')
            .addClass('btn btn-success saveBtn')
            .on('click', function (e) {
                e.preventDefault();
                save_data('save');
            });

    var btnDraft = $('<button></button>').text('Save as Draft')
            .addClass('btn btn-info draftBtn')
            .on('click', function () {
                save_data('draft');
            });

    // Smart Wizard
    $('#smartwizard').smartWizard({
        selected: 0,
        theme: 'default',
        transitionEffect: 'fade',
        labelFinish: 'Finish',
        showStepURLhash: false,
        toolbarSettings: {toolbarPosition: 'both',
            toolbarButtonPosition: 'end',
            toolbarExtraButtons: [btnDraft, btnSave]
        },
        anchorSettings: {
            anchorClickable: true, // Enable/Disable anchor navigation
            enableAllAnchors: true, // Activates all anchors clickable all times
            markDoneStep: true, // add done css
            enableAnchorOnDoneStep: true // Enable/Disable the done steps navigation
        },
    });

    if ($('#search_state').length) {
        if ($('#search_state option').length == '2') {
            $('#search_state').val($('#search_state option:eq(1)').val());
            change_state();
            $('#search_state').closest('div').hide();
        }
    }
    if ($('#search_district').length) {
        if ($('#search_district option').length == '2') {
            $('#search_district').val($('#search_district option:eq(1)').val());
            change_district();
            $('#search_district').closest('div').hide();
        }
    }
    $('#btn_search').click(function () {
        if ($('#reportMonths').val() == '') {
            swal('Please select Month');
            return false;
        }
        if ($('#reportYears').val() == '') {
            swal('Please select Year');
            return false;
        }
        if ($('#search_facility').length) {
            if ($('#search_facility').val() == '') {
                swal('Please select Facility');
                return false;
            }
        }
        var reportMonths = $('#reportMonths').val();
        var reportYears = $('#reportYears').val();
        var now = new Date;
        var currentMonth=parseInt(now.getMonth())+1;

        if (parseInt(reportYears)>now.getFullYear()) {
                swal('Selected Year can not be a future date');
                return false;
        } else if ((parseInt(reportMonths)>parseInt(currentMonth) && parseInt(reportYears)==now.getFullYear())){
            swal('Selected Month can not be a future date');
            return false;        
        }
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchType'] = 'monthReportCheck';
        params['reportMonths'] = reportMonths;
        params['reportYears'] = reportYears;
        //params['facility']=$('#search_facility').val();
        $("#bodyLoad").addClass('loader');
        $("#loader_overlay").show();
        $.ajax({
            url: pageMainUrl + 'ApiMonthly/monthReportCheck',
            data: params,
            type: 'POST',
            dataType: 'json',
            success: function (result) {
                $("#loader_overlay").hide();
                $("#bodyLoad").removeClass('loader');
                $('#resultDiv').html(result.data);
                if (result.page == 'Add') {
                    getPage(document.getElementById('redirectBtn'));
                    getMonthly();
                    getOneTime();
                    lastAssesment();
                    resetval1();
                    $('#formDiv').show();
                    $('#searchDiv').hide();
                } else {
                    if (result.page == 'View') {
                        swal('Monthly report already submitted. Click OK to view or cancle', {
                            buttons: {
                                cancel: "Cancle",
                                defeat: 'Ok',
                            },
                        })
                                .then((value) => {
                                    switch (value) {
                                        case "defeat":
                                            getPage(document.getElementById('redirectBtn'));
                                            break;
                                        default:
                                    }
                                });
                    } else {
                        swal('Monthly report already saved. Click OK to edit or cancle', {
                            buttons: {
                                cancel: "Cancle",
                                defeat: 'Ok',
                            },
                        })
                                .then((value) => {
                                    switch (value) {
                                        case "defeat":
                                            getPage(document.getElementById('redirectBtn'));
                                            getMonthly();
                                            getOneTime();
                                            lastAssesment();
                                            $('#formDiv').show();
                                            $('#searchDiv').hide();
                                            break;
                                        default:
                                    }
                                });
                    }

                }
            }
        });
    });
    if ($('#MonthlyID').val() != '') {
        setMonthlyData();
        getMonthly();
        getOneTime();
        lastAssesment();
    }

});


function save_data(saveType) {
    if (saveType == 'save') {
        $('.saveBtn').prop('disabled', true);
        $('.draftBtn').prop('disabled', true);
    } else {

        $('.draftBtn').prop('disabled', true);
    }

    var params = {};
    if (saveType == 'save') {
        var radioCheck = '0';
        $('[id^=step-]').each(function () {
            var cat = $(this).attr('id');
            var catCheeck = '0';
            var inputs = $("#" + cat + " input").filter(function () {
                return $(this).attr('name') !== undefined;
            });
            if (cat != 'step-2') {
                $.each(inputs, function (index, elem) {
                    if ($(elem).attr('type') == 'radio') {
                        if ($("#" + cat + " input[name='" + $(elem).attr('name') + "']").is(':checked')) {
                            $(elem).closest('.form-group').removeClass('has-error');
                        } else {
                            $(elem).closest('.form-group').addClass('has-error');
                            radioCheck = '1';
                        }
                    } else {
                        if ($(elem).val() == '') {
                            radioCheck = '1';
                            catCheeck = '1';
                            $(elem).closest('.form-group').addClass('has-error');
                        } else {
                            $(elem).closest('.form-group').removeClass('has-error');
                        }
                    }
                });
            } else {
                if ($("#step-3 input[name='BaselineNQASChecklistLR']:checked").val() == '1') {
                    if ($("#" + cat + " input[name='AssessmentMonthLR']").val() == '') {
                        radioCheck = '1';
                        catCheeck = '1';
                        $("#" + cat + " input[name='AssessmentMonthLR']").closest('.form-group').addClass('has-error');
                    } else {
                        $("#" + cat + " input[name='AssessmentMonthLR']").closest('.form-group').removeClass('has-error');
                    }
                    if ($("#" + cat + " input[name='BaselineScoreLR']").val() == '') {
                        radioCheck = '1';
                        catCheeck = '1';
                        $("#" + cat + " input[name='BaselineScoreLR']").closest('.form-group').addClass('has-error');
                    } else {
                        $("#" + cat + " input[name='BaselineScoreLR']").closest('.form-group').removeClass('has-error');
                    }
                } else {
                    $("#" + cat + " input[name='BaselineScoreLR']").closest('.form-group').removeClass('has-error');
                    $("#" + cat + " input[name='AssessmentMonthLR']").closest('.form-group').removeClass('has-error');
                }
                if ($("#step-3 input[name='BaselineNQASChecklistOT']:checked").val() == '1') {
                    if ($("#" + cat + " input[name='AssessmentMonthOT']").val() == '') {
                        radioCheck = '1';
                        catCheeck = '1';
                        $("#" + cat + " input[name='AssessmentMonthOT']").closest('.form-group').addClass('has-error');
                    } else {
                        $("#" + cat + " input[name='AssessmentMonthOT']").closest('.form-group').removeClass('has-error');
                    }
                    if ($("#" + cat + " input[name='BaselineScoreOT']").val() == '') {
                        radioCheck = '1';
                        catCheeck = '1';
                        $("#" + cat + " input[name='BaselineScoreOT']").closest('.form-group').addClass('has-error');
                    } else {
                        $("#" + cat + " input[name='BaselineScoreOT']").closest('.form-group').removeClass('has-error');
                    }
                } else {
                    $("#" + cat + " input[name='AssessmentMonthOT']").closest('.form-group').removeClass('has-error');
                    $("#" + cat + " input[name='BaselineScoreOT']").closest('.form-group').removeClass('has-error');
                }
                if ($("#step-3 input[name='BaselineStaffCompetenceOSCE']:checked").val() == '1') {
                    if ($("#" + cat + " input[name='AssessmentMonthOSCE']").val() == '') {
                        radioCheck = '1';
                        catCheeck = '1';
                        $("#" + cat + " input[name='AssessmentMonthOSCE']").closest('.form-group').addClass('has-error');
                    } else {
                        $("#" + cat + " input[name='AssessmentMonthOSCE']").closest('.form-group').removeClass('has-error');
                    }
                    if ($("#" + cat + " input[name='BaselineAvgOSCEScore']").val() == '') {
                        radioCheck = '1';
                        catCheeck = '1';
                        $("#" + cat + " input[name='BaselineAvgOSCEScore']").closest('.form-group').addClass('has-error');
                    } else {
                        $("#" + cat + " input[name='BaselineAvgOSCEScore']").closest('.form-group').removeClass('has-error');
                    }
                } else {
                    $("#" + cat + " input[name='AssessmentMonthOSCE']").closest('.form-group').removeClass('has-error');
                    $("#" + cat + " input[name='BaselineAvgOSCEScore']").closest('.form-group').removeClass('has-error');
                }
            }
            if (catCheeck != '0') {
                $('#smartwizard a[href="#' + cat + '"]').attr('style', 'color: #ffb3b3 !important');
            } else {
                $('#smartwizard a[href="#' + cat + '"]').attr('style', 'color: #ffffff !important');
            }
        });

        if (radioCheck != '0') {
            swal('Please fill all questions');
            $('.draftBtn').prop('disabled', false);
            $('.saveBtn').prop('disabled', false);
            return false;
        } else {
            params['status'] = 'save';
            swal({
                title: "Really want to submit the report ?",
                text: "Please have a re-look,before submission. Once submission is done, information can't be edited.",
                //icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    params['status'] = 'save';
                    save_continue(params);
                } else {
                    //params['status'] = 'draft';
                    //save_continue(params);
                    $('.saveBtn').prop('disabled', false);
                }
            });
        }
    } else {
        params['status'] = 'draft';
        save_continue(params);
    }

}

function save_continue(params) {
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    params['data'] = $('#monthlyForm').serializeArray();
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl + 'ApiMonthly/save',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $("#bodyLoad").removeClass('loader');
            $("#loader_overlay").hide();
            if (parseInt(result.code) == 0) {
                swal(result.msg).then((value) => {
                    if (result.status == '1') {
                        window.location.replace(pageMainUrl + 'monthly/index');
                    } else {
                        $('.draftBtn').prop('disabled', false);
                    }
                });
            } else {
                //swal('Error saving data');
                swal(result.msg);
                $('.draftBtn').prop('disabled', false);
            }
        }
    });
}

function calulateTotalDel() {
    var TotalCSections = parseInt($('#TotalCSections').val()) || 0;
    var TotalAssistedVaginalDeliveries = parseInt($('#TotalAssistedVaginalDeliveries').val()) || 0;
    var TotalNormalVaginalDeliveries = parseInt($('#TotalNormalVaginalDeliveries').val()) || 0;
    var tot = parseInt(TotalCSections + TotalAssistedVaginalDeliveries + TotalNormalVaginalDeliveries) || 0;
    $('#TotalDeliveries').val(tot);
}

function calulateStillBirth() {
    var TotalFreshStillBirths = parseInt($('#TotalFreshStillBirths').val()) || 0;
    var TotalMaceratedStillBirths = parseInt($('#TotalMaceratedStillBirths').val()) || 0;
    var tot = parseInt(TotalFreshStillBirths + TotalMaceratedStillBirths) || 0;
    $('#TotalStillBirths').val(tot);
}
function calulateNeonatalDeaths() {
    var NeonatalPrematurity = parseInt($('#NeonatalPrematurity').val()) || 0;
    var NeonatalSepsis = parseInt($('#NeonatalSepsis').val()) || 0;
    var NeonatalAsphyxia = parseInt($('#NeonatalAsphyxia').val()) || 0;
    var NeonatalOthers = parseInt($('#NeonatalOthers').val()) || 0;
    var tot = parseInt(NeonatalPrematurity + NeonatalSepsis + NeonatalAsphyxia + NeonatalOthers) || 0;
    $('#NumberNeonatalDeaths').val(tot);
}
function calulateTotalMaternalDeaths() {
    var MaternalAPH = parseInt($('#MaternalAPH').val()) || 0;
    var MaternalPPH = parseInt($('#MaternalPPH').val()) || 0;
    var MaternalSepsis = parseInt($('#MaternalSepsis').val()) || 0;
    var MaternalObstructedLabour = parseInt($('#MaternalObstructedLabour').val()) || 0;
    var MaternalPIHEclampsia = parseInt($('#MaternalPIHEclampsia').val()) || 0;
    var MaternalOthers = parseInt($('#MaternalOthers').val()) || 0;
    var tot = parseInt(MaternalAPH + MaternalPPH + MaternalSepsis + MaternalObstructedLabour + MaternalPIHEclampsia + MaternalOthers) || 0;
    $('#TotalMaternalDeaths').val(tot);
}

function getMonthly() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl + 'ApiMonthly/getMonthly',
        data: params,
        type: 'POST',
        dataType: 'json',
        async: false,
        success: function (result) {
            if (result.MonthlyStatus == '1') {
                window.location.replace(pageMainUrl+'monthly/index');
            }
            if (parseInt(result.code) == 0) {
                $.each(result.data[0], function (index, val) {
                    if ($('[name="' + index + '"]').attr('type') == 'radio') {
                        $('#' + index + '_' + val).prop('checked', true);
                    } else {
                        $('[name="' + index + '"]').val(val);
                    }
                });
            } else {
                $('#ReportMonth').val(result.rptDate);
            }
            $('#FacilityState').html('<option value="' + result.FacilityDetails.StateID + '" selected="selected">' + result.FacilityDetails.StateName + '</option>');
            $('#FacilityDistrict').html('<option value="' + result.FacilityDetails.DistrictID + '" selected="selected">' + result.FacilityDetails.DistrictName + '</option>');
            $('#FacilityType').html('<option value="' + result.FacilityDetails.TypeDetailID + '" selected="selected">' + result.FacilityDetails.TypeDetailCode + '</option>');
            $('#FacilityName').html('<option value="' + result.FacilityDetails.UserID + '" selected="selected">' + result.FacilityDetails.FacilityName + '</option>');
            $('.selectpicker').selectpicker('refresh');
        }
    });
}

function getOneTime() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl + 'ApiMonthly/getOneTime',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result1) {
            if (parseInt(result1.code) == 0) {
                $.each(result1.data[0], function (index, val) {
                    if ($('[name="' + index + '"]').attr('type') == 'radio') {
                        $('#' + index + '_' + val).prop('checked', true);
                        if (result1.onetimeStatus == '1') {
                            $('[name="' + index + '"]').prop('disabled', true);
                        }
                    } else {
                        $('[name="' + index + '"]').val(val);
                        if (result1.onetimeStatus == '1') {
                            $('[name="' + index + '"]').prop('disabled', true);
                        }
                    }
                });
                $('.selectpicker').selectpicker('refresh');
            }
        }
    });
}
function change_district() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'facility';
    params['searchData'] = $('#search_district').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_facility').html('<option value="">Select Facility</option>');
            if (result.data) {
                if (parseInt(result.data.length) > 0) {
                    $.each(result.data, function (key, val) {
                        $('#search_facility').append($("<option></option>").attr("value", val.UserID).text(val.FacilityName));
                    });
                    /*if($('#search_facility').length){
                     if(parseInt($('#search_facility option').length)==2){
                     $('#search_facility').val($('#search_facility option:eq(1)').val());
                     $('#btn_search').trigger('click');
                     }
                     }*/
                }
            }
        }
    });
}

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="">Select District</option>');
            if (parseInt(result.data.length) > 0) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
            /*if(parseInt($('#search_district option').length)>=2){
             $('#search_district').val($('#search_district option:eq(1)').val());
             change_district();
             }*/
            $('#search_facility').html('<option value="">Select Facility</option>');
        }
    });
}
function setFacility(ths) {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['facilitySetId'] = $(ths).val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/setFacility',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {

        }
    });
}
function getPage(ths) {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['setData'] = $(ths).attr('data-months');
    params['setDataMonth'] = $(ths).attr('data-reqMonth');
    $.ajax({
        url: pageMainUrl + 'ApiMonthly/setViewPage',
        data: params,
        type: 'POST',
        dataType: 'json',
        async: false,
        success: function (result) {
            if ($(ths).attr('data-page') == 'View') {
                window.location.href = $(ths).attr('data-href');
            }
        }
    });
}
function lastAssesment() {
    var params = {};
    params['facility'] = $('#FacilityName').val();
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl + 'ApiFacility/lastAssesment',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (parseInt(result.code) == 0) {
                $('#CurrentLabourRoomQualityScore').val(result.data.lrscore);
                $('#CurrentMaternityOTQualityScore').val(result.data.otscore);
            } else {
                $('#CurrentLabourRoomQualityScore').val('0');
                $('#CurrentMaternityOTQualityScore').val('0');
            }
        }
    });
}

function resetval(field){
    if(field=='BaselineNQASChecklistLR'){
        if($('[name="BaselineNQASChecklistLR"]:checked').val()=='1'){
            $('#AssessmentMonthLR').removeAttr('readonly');
            $('#BaselineScoreLR').removeAttr('readonly');
            var params = {};
            params['facility'] = $('#FacilityName').val();
            params['device'] = 'web';
            params['csrf_token']=$.cookie("csrf_cookie");
            params['sequence'] = '1';
            params['assesmentType'] = 'LR';
            $.ajax({
                url: pageMainUrl + 'ApiFacility/lastAssesment',
                data: params,
                type: 'POST',
                dataType: 'json',
                success: function (result) {
                    if (parseInt(result.code) == 0) {
                        $('#AssessmentMonthLR').val(result.data.AssessmentDateLR);
                        $('#BaselineScoreLR').val(result.data.lrscore);
                    } else {
                        $('#AssessmentMonthLR').val('');
                        $('#BaselineScoreLR').val('');
                    }
                }
            });
        } else {
            $('#AssessmentMonthLR').attr('readonly', true);
            $('#AssessmentMonthLR').val('');
            $('#BaselineScoreLR').attr('readonly', true);
            $('#BaselineScoreLR').val('');
        }
    }
    if(field=='BaselineNQASChecklistOT'){
        if($('[name="BaselineNQASChecklistOT"]:checked').val()=='1'){
            $('#AssessmentMonthOT').removeAttr('readonly');
            $('#BaselineScoreOT').removeAttr('readonly');
            var params = {};
            params['facility'] = $('#FacilityName').val();
            params['device'] = 'web';
            params['csrf_token']=$.cookie("csrf_cookie");
            params['sequence'] = '1';
            params['assesmentType'] = 'OT';
            $.ajax({
                url: pageMainUrl + 'ApiFacility/lastAssesment',
                data: params,
                type: 'POST',
                dataType: 'json',
                success: function (result) {
                    if (parseInt(result.code) == 0) {
                        $('#AssessmentMonthOT').val(result.data.AssessmentDateOT);
                        $('#BaselineScoreOT').val(result.data.otscore);
                    } else {
                        $('#AssessmentMonthOT').val('');
                        $('#BaselineScoreOT').val('');
                    }
                }
            });
        } else {
            $('#AssessmentMonthOT').attr('readonly', true);
            $('#AssessmentMonthOT').val('');
            $('#BaselineScoreOT').attr('readonly', true);
            $('#BaselineScoreOT').val('');
        }        
    }
}
function resetval1(){
    var params = {};
    params['facility'] = $('#FacilityName').val();
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['sequence'] = '1';
    params['assesmentType'] = 'LR';
    $.ajax({
        url: pageMainUrl + 'ApiFacility/lastAssesment',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (parseInt(result.code) == 0) {
                if(result.data.AssessmentDateLR==''){
                    $('#BaselineNQASChecklistLR_0').attr('checked',true);
                    $('#AssessmentMonthLR').val('');
                    $('#BaselineScoreLR').val('');
                } else {
                    $('#BaselineNQASChecklistLR_1').attr('checked',true);
                    $('#AssessmentMonthLR').val(result.data.AssessmentDateLR);
                    $('#BaselineScoreLR').val(result.data.lrscore);
                }
            } else {
                $('#BaselineNQASChecklistLR_0').attr('checked',true);
                $('#AssessmentMonthLR').val('');
                $('#BaselineScoreLR').val('');
            }
        }
    });
    var params = {};
    params['facility'] = $('#FacilityName').val();
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['sequence'] = '1';
    params['assesmentType'] = 'OT';
    $.ajax({
        url: pageMainUrl + 'ApiFacility/lastAssesment',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (parseInt(result.code) == 0) {
                if(result.data.AssessmentDateOT==''){
                    $('#BaselineNQASChecklistOT_0').attr('checked',true);
                    $('#AssessmentMonthOT').val('');
                    $('#BaselineScoreOT').val('');
                } else {
                    $('#BaselineNQASChecklistOT_1').attr('checked',true);
                    $('#AssessmentMonthOT').val(result.data.AssessmentDateOT);
                    $('#BaselineScoreOT').val(result.data.otscore);
                }
            } else {
                $('#BaselineNQASChecklistOT_0').attr('checked',true);
                $('#AssessmentMonthOT').val('');
                $('#BaselineScoreOT').val('');
            }
        }
    });
}
function setMonthlyData(){
    var params = {};
    params['MonthlyID'] = $('#MonthlyID').val();
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl + 'ApiMonthly/setMonthlyData',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            
        }
    });    
}