import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';
import { TokenService } from 'src/app/services/token.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public loggedIn:boolean;
  constructor(
    private Auth:AuthService,
    private router:Router,
    private Token:TokenService
  ) { }

  ngOnInit() {
    this.Auth.authStatus.subscribe(value=>this.loggedIn=value);
  }

  logout(event:MouseEvent){
    event.preventDefault();
    this.Auth.changeAuthStatus(true);
    this.Token.remove();
    localStorage.removeItem('userID');
    localStorage.removeItem('entityID');
    this.router.navigateByUrl('/login');
  }

}
