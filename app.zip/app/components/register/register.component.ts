import { Component, OnInit } from '@angular/core';
import { JarwisService } from 'src/app/services/jarwis.service';
import { TokenService } from 'src/app/services/token.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  public form = {
    companyName:null,
    iecCode:null,
    email:null,
    mobile:null,
    password:null,
    password_confirmation:null
  };
  public error=[];

  constructor(
    private Jarwis:JarwisService,
    private Token:TokenService,
    private router: Router
    ) { }

  ngOnInit() {
    this.getstates();
  }

  onSubmit(){
    this.Jarwis.register(this.form).subscribe(
      data=>this.handleResponse(data),
      error=>this.handleErrors(error)
    );
  }
  handleResponse(data){

    //this.Token.handle(data.access_token);
    //this.router.navigateByUrl('/company');
  }
  handleErrors(error){
    this.error=error.error;
  }

  getstates(){
    this.Jarwis.getstates().subscribe(
      data=>console.log(data),
      error=>console.log(error)
    );
  }

}
