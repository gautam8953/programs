<?php

class FacilityModel extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	/*function getQuestions($SurveyType,$category){
		$response=array();
	  	$this->db->select('survey.SurveyName,survey.SurveyDesc,c.CategoryName,s.SubCategoryCode,s.SubCategoryName,q.*');
	    $this->db->from('question q');
	    $this->db->join('subcategory s', 'q.SubcategoryID = s.SubcategoryID', 'inner'); 
	    $this->db->join('category c', 's.CategoryID = c.CategoryID', 'inner'); 
	    $this->db->join('survey', 'c.SurveyID = survey.SurveyID', 'inner'); 
	    $this->db->where('survey.SurveyID',$SurveyType);
	    $this->db->where('c.CategoryID',$category);
	    $query = $this->db->get();
		
		if($query -> num_rows()>=1){
			$response['code']=0;
			$response['msg']=$query -> num_rows().' rows get';
			$response['data'] = $query->result();
		} else {
			$response['code']=1;
			$response['msg']='0 rows get';
			$response['data'] = array();
		}
		return $response;

	}*/
	function getQuestionsAll($SurveyType,$format='A'){
		$response=array();
	  	$sql="select survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
WHERE survey.SurveyID='".$SurveyType."' and q.format='".$format."' 
ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC";
	    $result = $this->db->query($sql, NULL);
	    $data['survey']=array();
	    foreach ($result->result() as $key => $value) {
	    	//if(empty($value->Statement) && $value->Checkpoint){ continue; }
	    	if(!array_key_exists($value->SurveyID, $data['survey'])){
	    		$data['survey'][$value->SurveyID]=array(
			    	'SurveyName'=>$value->SurveyName,
			    	'SurveyDesc'=>$value->SurveyDesc,
			    	'category'=>array(),
	    		);
	    	}
	    	if(!array_key_exists($value->CategoryID, $data['survey'][$SurveyType]['category'])){
	    		$data['survey'][$SurveyType]['category'][$value->CategoryID]=array(
	    			'CategoryName'=>$value->CategoryName,
	    			'CategoryCode'=>$value->CategoryCode,
	    			'subcategory'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->SubcategoryID, $data['survey'][$SurveyType]['category'][$value->CategoryID]['subcategory'])){
	    		$data['survey'][$SurveyType]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]=array(
	    			'SubcategoryID'=>$value->SubcategoryID,
	    			'SubCategoryCode'=>$value->SubCategoryCode,
	    			'SubCategoryName'=>$value->SubCategoryName,
	    			'questions'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->QuestionID, $data['survey'][$SurveyType]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'])){
	    		$data['survey'][$SurveyType]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'][$value->QuestionID]=array(
	    			'Reference'=>$value->Reference,
	    			'Statement'=>$value->Statement,
	    			'Checkpoint'=>$value->Checkpoint,
	    			'Assesment'=>$value->Assesment,
	    			'Verification'=>$value->Verification,
	    			'Remarks'=>$value->Remarks,
	    		);
	    	}	    	
	    }
		return $data;

	}
	function saveSurveyAns($dataAns,$ansID){
		$response=array();
		$savedQues='0';
		$deactive='0';
		$unchanged='0';
		$cleared='0';
		$response['questions_get']=count($dataAns['answer']);
		$response['ans_clear_get']=count($dataAns['answerCleared']);
		if(!empty($ansID)){		
		  	$this->db->select('AnswerID');
		    $this->db->from('answer');
		    $this->db->where('AnswerID',$ansID);
		    //$this->db->where('SurveyID',$dataAns['survey']);
		    $this->db->order_by('AnswerID', 'DESC');
		    $query = $this->db->get();
			if($query -> num_rows()>=1){
				$result_Ans = $query->result();
				$ansId=$result_Ans[0]->AnswerID;
				$updateAns=array(
					'device'=>$dataAns['device'],
					'ModifiedOn'=>date('Y-m-d H:i:s'),
					'SurveyStatus'=>$dataAns['status']=='save'?'1':'0',
					'ModifiedBy'=>$this->session->userdata('UserID'),
				);
			    if($dataAns['status']=='save'){
			    	$updateAns['end_date']=date('Y-m-d');
			    }
				$this->db->where('AnswerID', $ansId);
				$this->db->update('answer', $updateAns);
			} else {
				$ansMain=array(
					'UserID'=>$this->session->userdata('facilityUser'),
					'SurveyID'=>$dataAns['survey'],
					'Sequence'=>'1',
					'start_date'=>date('Y-m-d H:i:s'),
					'device'=>$dataAns['device'],
					'SurveyStatus'=>$dataAns['status']=='save'?'1':'0',
					'CreatedOn'=>date('Y-m-d H:i:s'),
					'CreatedBy'=>$this->session->userdata('UserID'),
				);
				if($this->session->userdata('facilityUser')!=$this->session->userdata('UserID')){
					$ansMain['ParentUserID']=$this->session->userdata('UserID');
				}
			    if($dataAns['status']=='save'){
			    	$ansMain['end_date']=date('Y-m-d');
			    }
				if($this->db->insert('answer', $ansMain)){
					$ansId=$this->db->insert_id();
				} else {
					$this->db->insert('answer', $ansMain);
					$ansId=$this->db->insert_id();
				}
			}
			if($ansId>0){
				$response['answer']=$ansId;
				if(!empty($dataAns['answer'])){
					$QuestionIDs=implode(',',array_keys($dataAns['answer']));
					$quesDetCond=" AND ad.QuestionID in(".$QuestionIDs.") ";
				  	
				  	$sql="SELECT ad.AnswerDetailID,ad.QuestionID,ad.Answer
	FROM answerdetail ad 
	INNER join answer a on(a.AnswerID=ad.AnswerID)
	where 1 
	".$quesDetCond."
	and a.AnswerID='".$ansId."' 
	and ad.IsActive='1' 
	and a.UserID='".$this->session->userdata('facilityUser')."'";
				    $result_ansDetaa = $this->db->query($sql, NULL);
				    if($result_ansDetaa ->num_rows()>=1){
				    	foreach ($result_ansDetaa->result() as $key_ansDet => $value_ansDet) {
				    		if($value_ansDet->Answer!=$dataAns['answer'][$value_ansDet->QuestionID]){
								$updateAnsDet=array(
									'ModifiedOn'=>date('Y-m-d H:i:s'),
									'IsActive'=>'0',
									'ModifiedBy'=>$this->session->userdata('UserID'),
								);
								$this->db->where('AnswerDetailID', $value_ansDet->AnswerDetailID);
								$this->db->update('answerdetail', $updateAnsDet);
								$deactive++;
				    		} else {
				    			unset($dataAns['answer'][$value_ansDet->QuestionID]);
				    			$unchanged++;
				    		}
				    	}
				    } else {
				    	// no survey data filled before insert all
				    }
				} else {
					// no answer posted
				}

		    	foreach ($dataAns['answer'] as $key => $value) {
		    		$InsertAns[]=array(
		    			'AnswerID'=>$ansId,
		    			'QuestionID'=>$key,
		    			'Answer'=>$value,
		    			'IsActive'=>'1',
		    			'CreatedOn'=>date('Y-m-d H:i:s'),
		    			'CreatedBy'=>$this->session->userdata('UserID'),
		    		);
		    	}
		    	foreach ($dataAns['answerCleared'] as $key => $value) {
			    	$sql="SELECT ad.AnswerDetailID FROM answerdetail ad 
INNER join answer a on(a.AnswerID=ad.AnswerID)
where ad.QuestionID='".$value."'
and a.AnswerID='".$ansId."' 
and ad.IsActive='1' 
and a.UserID='".$this->session->userdata('facilityUser')."'";
				    $result_ansDel = $this->db->query($sql, NULL);
				    if($result_ansDel ->num_rows()>=1){
				    	foreach ($result_ansDel->result() as $key_ansDel => $value_ansDel) {
							$updateAnsDet=array(
								'ModifiedOn'=>date('Y-m-d H:i:s'),
								'IsActive'=>'0',
								'ModifiedBy'=>$this->session->userdata('UserID'),
							);
							$this->db->where('AnswerDetailID', $value_ansDel->AnswerDetailID);
							$this->db->update('answerdetail', $updateAnsDet);
							$cleared++;
				    	}				    	
				    }
			    }

		    	$ansId1=array();
				if(!empty($InsertAns)){
					if($this->db->insert_batch('answerdetail', $InsertAns)){
						$ansId1[]=$this->db->insert_id();
					} else {
						$this->db->insert_batch('answerdetail', $InsertAns);
						$ansId1[]=$this->db->insert_id();
					}
					$savedQues+=count($InsertAns);
				}
	    $sqlTot="select count(q.QuestionID) ques,(case when (ad.AnswerDetailID IS NULL) 
 THEN
      'not' 
 ELSE
      'yes' 
 END)
 as checkdata
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
LEFT join answer a on(survey.SurveyID=a.SurveyID AND a.format=c.format)
LEFT join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1')
WHERE a.AnswerID='".$ansId."'
GROUP by ad.AnswerID
";
	    $resultTot = $this->db->query($sqlTot, NULL);
	    $resultTotData=$resultTot->result_array();
	    $data['tot']=array('yes'=>0,'not'=>'0');
	    $totquestions=0;
	    foreach ($resultTotData as $key => $value) {
	    	$data['tot'][$value['checkdata']]=$value['ques'];
	    	$totquestions+=$value['ques'];
	    }
	    $data['tot']['allques']=$totquestions;
	    $response['questions']=$data;

				$response['code']=0;
				$response['msg']='Data saved successfully';
			} else {
				$response['code']=12;
				$response['msg']='Data Proper not saved ans';
			}
		} else {
			$response['code']=2;
			$response['msg']='No Data Posted';
		}
		
		$response['questions_saved']=$savedQues;
		$response['answer_deactive']=$deactive;
		$response['answer_unchanged']=$unchanged;
		$response['answer_cleared']=$cleared;
		return $response;
	}
 	/*function getQuestionsAnsAll($SurveyType){
		$response=array();
	  	$sql="select ad.Answer, survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
INNER join answer a on(survey.SurveyID=a.SurveyID and a.Sequence='1')
INNER join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1')
WHERE survey.SurveyID='".$SurveyType."'
ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.Serial ASC";
	    $result = $this->db->query($sql, NULL);
	    $data['survey']=array();
	    foreach ($result->result() as $key => $value) {
	    	if(!array_key_exists($value->SurveyID, $data['survey'])){
	    		$data['survey'][$value->SurveyID]=array(
			    	'SurveyName'=>$value->SurveyName,
			    	'SurveyDesc'=>$value->SurveyDesc,
			    	'category'=>array(),
	    		);
	    	}
	    	if(!array_key_exists($value->CategoryID, $data['survey'][$SurveyType]['category'])){
	    		$data['survey'][$SurveyType]['category'][$value->CategoryID]=array(
	    			'CategoryName'=>$value->CategoryName,
	    			'CategoryCode'=>$value->CategoryCode,
	    			'subcategory'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->SubcategoryID, $data['survey'][$SurveyType]['category'][$value->CategoryID]['subcategory'])){
	    		$data['survey'][$SurveyType]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]=array(
	    			'SubCategoryCode'=>$value->SubCategoryCode,
	    			'SubCategoryName'=>$value->SubCategoryName,
	    			'questions'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->QuestionID, $data['survey'][$SurveyType]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'])){
	    		$data['survey'][$SurveyType]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'][$value->QuestionID]=array(
	    			'Answer'=>$value->Answer,
	    		);
	    	}	    	
	    }
	    $response['code']=$result ->num_rows();
	    $response['msg']=$result ->num_rows().' data get';
	    $response['data']=$data;
		return $response;

	}*/
 	function getQuestionsAnsCatAll($SurveyType,$ansId){
		$response=array();
	  	$sql="select a.SurveyStatus,ad.Answer, survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
INNER join answer a on(survey.SurveyID=a.SurveyID AND a.format=q.format)
INNER join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1')
WHERE survey.SurveyID='".$SurveyType."' 
AND a.AnswerID='".$ansId."'
ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.Serial ASC";
	    $result = $this->db->query($sql, NULL);
	    $data['category']=array();
	    $data['surveyStatus']=0;
	    foreach ($result->result() as $key => $value) {
	    	if(!array_key_exists($value->CategoryID, $data['category'])){
	    		$data['category'][$value->CategoryID]=array(
	    			'CategoryName'=>$value->CategoryName,
	    			'CategoryCode'=>$value->CategoryCode,
	    			'questions'=>array(),
	    			'standered'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->QuestionID, $data['category'][$value->CategoryID]['questions'])){
	    		$data['category'][$value->CategoryID]['questions'][$value->QuestionID]=$value->Answer;
	    	}
	    	// for standered
	    	if(array_key_exists($value->SubcategoryID, $data['category'][$value->CategoryID]['standered'])){
	    		$data['category'][$value->CategoryID]['standered'][$value->SubcategoryID]['answer']+=$value->Answer;
	    		$data['category'][$value->CategoryID]['standered'][$value->SubcategoryID]['questionTot']+=1;
	    	}
	    	if(!array_key_exists($value->SubcategoryID, $data['category'][$value->CategoryID]['standered'])){
	    		$data['category'][$value->CategoryID]['standered'][$value->SubcategoryID]=array(
	    			'answer'=>$value->Answer,
	    			'questionTot'=>1,
	    			'subCategoryCode'=>$value->SubCategoryCode
	    		);
	    	}

	    }
	    if(isset($value->SurveyStatus)){
	    	$data['surveyStatus']=$value->SurveyStatus;
	    } else {
	    	$data['surveyStatus']=0;
	    }
	    $response['code']=$result ->num_rows();
	    $response['msg']=$result ->num_rows().' data get';
	    $response['data']=$data;
		return $response;

	}
	function surveyFormatDownload($arr){		
		$response=array();
	  	$sql="select a.SurveyStatus,ad.Answer, survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*,a.UserID,a.start_date,a.end_date,a.AssessmentDate,a.AssessorsName1,a.AssessorsName2,a.AssesseesName1,a.AssesseesName2,a.AssessmentType,a.AnswerID
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
LEFT join answer a on(survey.SurveyID=a.SurveyID AND a.format=q.format)
LEFT join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1')
WHERE a.AnswerID='".$arr['ansId']."' 
ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC ";
	    $result = $this->db->query($sql, NULL);
	    $data['survey']=array();
	    foreach ($result->result() as $key => $value) {
	    	if(!array_key_exists($value->SurveyID, $data['survey'])){
	    		$data['survey'][$value->SurveyID]=array(
			    	'SurveyName'=>$value->SurveyName,
			    	'SurveyDesc'=>$value->SurveyDesc,
			    	'category'=>array(),
	    		);
	    	}
	    	if(!array_key_exists($value->CategoryID, $data['survey'][$value->SurveyID]['category'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]=array(
	    			'CategoryName'=>$value->CategoryName,
	    			'CategoryCode'=>$value->CategoryCode,
	    			'subcategory'=>array()
	    		);
	    	}
	    	// for standered
	    	if(array_key_exists($value->SubcategoryID, $data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questionTot']+=1;
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['answerTot']+=$value->Answer;
	    	}
	    	if(!array_key_exists($value->SubcategoryID, $data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]=array(
	    			'SubCategoryCode'=>$value->SubCategoryCode,
	    			'SubCategoryName'=>$value->SubCategoryName,
	    			'questionTot'=>1,
	    			'answerTot'=>$value->Answer,
	    			'questions'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->QuestionID, $data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'][$value->QuestionID]=array(
	    			'Reference'=>$value->Reference,
	    			'Statement'=>$value->Statement,
	    			'Checkpoint'=>$value->Checkpoint,
	    			'Assesment'=>$value->Assesment,
	    			'Verification'=>$value->Verification,
	    			'Remarks'=>$value->Remarks,
	    			'Answer'=>$value->Answer,
	    		);
	    	}	    	
	    }
	    $this->db->select('users.UserID,facilities.FacilityName');
	    $this->db->from('users');
	    $this->db->join('usermapping', 'users.UserID=usermapping.UserID AND usermapping.FacilityID>0', 'inner');
	    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
	    $this->db->where('users.UserID',$value->UserID);
	    $this->db->order_by('facilities.FacilityName','ASC');
	    $query = $this->db->get();
		$Facilitydata=$query->row();
		if(!empty($Facilitydata)){
			$FacilityName=$Facilitydata->FacilityName;
		} else {
			$FacilityName='';
		}
	    // $facilityDetails
	    $data['answersMain']=array(
	    	'FacilityName'=>$FacilityName,
	    	'start_date'=>$value->start_date,
	    	'end_date'=>$value->end_date,
	    	'AssessmentDate'=>$value->AssessmentDate,
	    	'AssessorsName1'=>$value->AssessorsName1,
	    	'AssessorsName2'=>$value->AssessorsName2,
	    	'AssesseesName1'=>$value->AssesseesName1,
	    	'AssesseesName2'=>$value->AssesseesName2,
	    	'AssessmentType'=>$value->AssessmentType,
	    );
	    $this->db->select('answerremarks.*');
	    $this->db->from('answerremarks');
	    $this->db->where('answerremarks.AnswerID',$value->AnswerID);
	    $this->db->order_by('answerremarks.AnswerID', 'ASC');	   
	    $result = $this->db->get();
		foreach ($result->result_array() as $key => $value1) {
			$data['remarks']['q'.$value1['remarksType']][]=$value1;
		}

	  	$sql="select survey.SurveyDesc,survey.SurveyName,c.CategoryCode,c.CategoryName,count(q.QuestionID) as quesTot,sum(ad.Answer) as answer,ROUND(((sum(ad.Answer)/(count(q.QuestionID)*2) )*100)) as score from question q INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) INNER join category c on (s.CategoryID=c.CategoryID) INNER JOIN survey on(c.SurveyID=survey.SurveyID) INNER join answer a on(survey.SurveyID=a.SurveyID AND a.format=q.format) INNER join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1') WHERE a.AnswerID='".$value->AnswerID."' GROUP BY c.CategoryCode ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.Serial ASC";
	    $result = $this->db->query($sql, NULL);
	    foreach ($result->result_array() as $key => $value) {
	    	$data['score'][]=$value;
	    }
		return $data;

	}

	function getSearchData($searchData){
		$data=array('draw'=>0,'totalData'=>0,'totalFilter'=>0,'data'=>array());
		$col=array();
		if(!empty($this->session->userdata('showState'))){
			$col[]='s.StateName';
		}
		if(!empty($this->session->userdata('showDistrict'))){
			$col[]='d.DistrictName';
		}
		if(!empty($this->session->userdata('showFacilities'))){
			$col[]='f.facilityName';
		}
		$col[]='answer.Sequence';
		$col[]='survey.SurveyName';
		$col[]='answer.AssessmentDate';
		$col[]='answer.device';
		$col[]='answer.SurveyStatus';

	  	$this->db->select('answer.AnswerID');
	    $this->db->from('answer');
	    $this->db->join('survey', 'answer.SurveyID = survey.SurveyID', 'inner');
		$this->db->join('usermapping um','answer.UserID=um.UserID AND um.IsActive=1','inner');
		$this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
		$this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
		$this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
		if(!empty($searchData['cond'])){
			$this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
			/*$where_rr=array();
			foreach ($searchData['cond'] as $key => $value) {
				$where_rr[]= $value['mappedField'].'="'.$value['mappedData'].'" ';
				$this->db->or_where_in($value['mappedField'],$value['mappedData']);
			}*/
			/*if(!empty($where_rr)){
				echo $whereCond=implode(' OR ', $where_rr);
				$whereCond='('.$whereCond.')';
				$this->db->where_in($whereCond);
			}*/
		}
	    $this->db->where('answer.IsActive','1');
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            if(strtolower($searchString)=='base line' || strtolower($searchString)=='base' || strtolower($searchString)=='baseline'){ 
                $this->db->where("(answer.Sequence='1')", NULL, FALSE);
            } else if(strtolower($searchString)=='others' || strtolower($searchString)=='other'){ 
                $this->db->where("(answer.Sequence='2')", NULL, FALSE);
            } else if(strtolower($searchString)=='end line' || strtolower($searchString)=='end' || strtolower($searchString)=='endline'){ 
                $this->db->where("(answer.Sequence='3')", NULL, FALSE);
            } else if(strtolower($searchString)=='completed' || strtolower($searchString)=='complete'){ 
                $this->db->where("(answer.SurveyStatus='1')", NULL, FALSE);
            } else if(strtolower($searchString)=='incomplete'){
                $this->db->where("(answer.SurveyStatus='0')", NULL, FALSE);
            } else if(DateTime::createFromFormat('d-m-Y', $searchString) !== FALSE){
                $this->db->where("(answer.AssessmentDate='".date('Y-m-d',strtotime($searchString))."')", NULL, FALSE);
            } else {
                $this->db->where("(survey.SurveyName like '%".$searchString."%'  OR f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%' OR answer.device like '%".$searchString."%')", NULL, FALSE);
            }
        }
        if(!empty($searchData['search_state'])){
        	$this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
        	$this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
        	$this->db->where('answer.UserID',$searchData['search_facility']);
        }
	    $queryTot = $this->db->get();

	    $this->db->select('f.facilityName,s.StateName,d.DistrictName,answer.format,answer.AnswerID,answer.clientScore,answer.Sequence,answer.SurveyID,answer.AssessmentDate,answer.SurveyStatus,survey.SurveyName,survey.SurveyID,answer.device');
	    $this->db->from('answer');
	    $this->db->join('survey', 'answer.SurveyID = survey.SurveyID', 'inner');

		$this->db->join('usermapping um','answer.UserID=um.UserID AND um.IsActive=1','inner');
		$this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
		$this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
		$this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
		if(!empty($searchData['cond'])){
			/*foreach ($searchData['cond'] as $key => $value) {
				$this->db->where_in($value['mappedField'],$value['mappedData']);
			}*/
			$this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
		}
	    $this->db->where('answer.IsActive','1');
        if(!empty($searchData['search']['value'])){
            $searchString=trim($searchData['search']['value']);
            if(strtolower($searchString)=='base line' || strtolower($searchString)=='base' || strtolower($searchString)=='baseline'){ 
                $this->db->where("(answer.Sequence='1')", NULL, FALSE);
            } else if(strtolower($searchString)=='others' || strtolower($searchString)=='other'){ 
                $this->db->where("(answer.Sequence='2')", NULL, FALSE);
            } else if(strtolower($searchString)=='end line' || strtolower($searchString)=='end' || strtolower($searchString)=='endline'){ 
                $this->db->where("(answer.Sequence='3')", NULL, FALSE);
            } else if(strtolower($searchString)=='completed' || strtolower($searchString)=='complete'){ 
                $this->db->where("(answer.SurveyStatus='1')", NULL, FALSE);
            } else if(strtolower($searchString)=='incomplete'){
                $this->db->where("(answer.SurveyStatus='0')", NULL, FALSE);
            } else if(DateTime::createFromFormat('d-m-Y', $searchString) !== FALSE){
                $this->db->where("(answer.AssessmentDate='".date('Y-m-d',strtotime($searchString))."')", NULL, FALSE);
            } else {
                $this->db->where("(survey.SurveyName like '%".$searchString."%' OR f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%' OR answer.device like '%".$searchString."%')", NULL, FALSE);
            }
        }
        if(!empty($searchData['search_state'])){
        	$this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
        	$this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
        	$this->db->where('answer.UserID',$searchData['search_facility']);
        }
        if($searchData['order'][0]['column']>0){
        	$colNo=$searchData['order'][0]['column']-1;
        } else {
        	$colNo=$searchData['order'][0]['column'];
        }
	    $this->db->order_by($col[$colNo], $searchData['order'][0]['dir']);
	    if($searchData['length']>0){
	    	$this->db->limit($this->input->post('length'),$this->input->post('start'));
		}
	    $query = $this->db->get();

		$data['draw']=$this->input->post('draw');
		$data['totalData']=$queryTot -> num_rows();
		$data['totalFilter']=$queryTot -> num_rows();
		$surveyFormLevel=$this->config->item('assesmentSequence');
		$dataget=array();
		$cnt=$searchData['start'];
		//$access_add=$this->CommonModel->checkPageActionWeb('facility/index','access_add',$this->session->userdata('RoleName'));
		$access_edit=$this->CommonModel->checkPageActionWeb('facility/index','access_edit',$this->session->userdata('RoleName'));
		//$access_delete=$this->CommonModel->checkPageActionWeb('facility/index','access_delete',$this->session->userdata('RoleName'));
		$access_view=$this->CommonModel->checkPageActionWeb('facility/index','access_view',$this->session->userdata('RoleName'));
		foreach ($query->result() as $key => $value) {
		    $subdata=array();
		    $subdata[]=++$cnt;
		    if($this->session->userdata('showState')){
		    	$subdata[]=$value->StateName;		    	
		    }
		    if($this->session->userdata('showDistrict')){
		    	$subdata[]=$value->DistrictName;		    	
		    }
		    if($this->session->userdata('showFacilities')){
		    	$subdata[]=$value->facilityName;		    	
		    }
		    $subdata[]=$surveyFormLevel[$value->Sequence];
		    $subdata[]=$value->SurveyName;
		    $subdata[]=convert_date_show($value->AssessmentDate);
		    $subdata[]=$value->device;
		    $subdata[]=$value->SurveyStatus?'<span class="complete-status">Completed</span>':'<span class="incomplete-status">Incomplete</span>';
		    if($value->SurveyStatus){
			    if($value->SurveyID=='2'){
			    	$facilityType='operationChecklist';
			    } else {
			    	$facilityType='labourChecklist';
			    }
			    $actionLink='';
			    if($access_view){
			    	$actionLink.='<button data-href="'.base_url().'facility/checklistview/'.encryptor($value->SurveyID).'/'.encryptor($value->AnswerID).'/'.encryptor($value->format).'"  onclick="pageRedirect(this)" class="btn btn-primary btn-xs getAssesment getAssesment1 view" ><i class="fa fa-eye"></i> View</button><button onclick="pageRedirect(this)" data-href="'.base_url().'facility/viewscore/'.encryptor($value->AnswerID).'/'.encryptor($value->format).'" class="btn btn-primary btn-xs getScore getScore1" ><i class="fa fa-bar-chart"></i> Score</button><a href="'.base_url().'facility/surveyFormatDownload/'.encryptor($value->AnswerID).'/'.encryptor($value->format).'" target="_blank" title="Download Labour Room Facility Form" class="btn btn-primary btn-xs download-btn1"> <i class="fa fa-download" aria-hidden="true"></i> Download</a><button data-href="'.base_url().'facility/gapanalysis/'.encryptor($value->AnswerID).'/'.encryptor($value->format).'"  onclick="pageRedirect(this)" class="btn btn-primary btn-xs getAssesment getAssesment1 view" ><i class="fa fa-eye"></i> Gap Analysis</button>';
			    }
			    if($access_edit){
			    	$actionLink.='<button data-assessment="'.encryptor($value->AnswerID).'" data-clientScore="'.$value->clientScore.'" class="btn btn-primary btn-xs client-stati-s1" data-toggle="modal" data-target="#clientScoreModal" onclick="clientScore(this)" title="Beneficiary Satisfaction Score"><i class="fa fa-heart"></i> Beneficiary Satisfaction</button>';
			    }			    
		    	$subdata[]=$actionLink;
		    } else {
			    if($value->SurveyID=='2'){
			    	$facilityType='operationFacility';
			    } else {
			    	$facilityType='labourFacility';
			    }
			    $actionLink='';
			    if($access_edit){
			    	$actionLink.='<button data-href="'.base_url().'facility/checklist/'.encryptor($value->SurveyID).'/'.encryptor($value->AnswerID).'/'.encryptor($value->format).'" onclick="pageRedirect(this)" data-ans="'.$value->AnswerID.'" class="btn btn-primary btn-xs getAssesment getAssesment1" ><i class="fa fa-floppy-o"></i> Draft</button>';
			    }
		    	$subdata[]=$actionLink;
		    }
		    $dataget[]=$subdata;
		}
		$data['data']=$dataget;

		return $data;

	}
	function getSearchOptions(){
		$data=array();
		switch ($this->session->userdata('RoleName')) {
			case 'Facility':
				/*$data['Facility']=array(
					$this->session->userdata('UserID')=>$this->session->userdata('UserName')
				);*/
				break;
			case 'District':
			    $this->db->select('usermapping.DistrictID,district.DistrictName');
			    $this->db->from('users');
			    $this->db->join('usermapping', 'users.UserID=usermapping.UserID', 'inner');
			    $this->db->join('district', 'usermapping.DistrictID=district.DistrictID', 'inner');
			    $this->db->where('users.UserID',$this->session->userdata('UserID'));
			    $this->db->order_by('district.DistrictName','ASC');
			    $query = $this->db->get();
				$DistrictAssigned=$query->result_array();
				$data['District']=$DistrictAssigned;
				$data['Facility']=array();
				break;
			case 'State':
			    $this->db->select('usermapping.StateID,states.StateName');
			    $this->db->from('users');
			    $this->db->join('usermapping', 'users.UserID=usermapping.UserID', 'inner');
			    $this->db->join('states', 'usermapping.StateID=states.StateID', 'inner');
			    $this->db->where('users.UserID',$this->session->userdata('UserID'));
			    $this->db->order_by('states.StateName','ASC');
			    $query = $this->db->get();
				$StatesAssigned=$query->result_array();
				$data['State']=$StatesAssigned;
				$data['District']=array();
				$data['Facility']=array();
				break;
			case 'Ministry':
			    $this->db->select('states.StateID,states.StateName');
			    $this->db->from('states');
			    $this->db->where('states.IsActive','1');
			    $this->db->order_by('states.StateName','ASC');
			    $query = $this->db->get();
				$MinistryState=$query->result_array();
				$data['State']=$MinistryState;
				$data['District']=array();
				$data['Facility']=array();
				break;
			case 'NHSRC':
			    $this->db->select('states.StateID,states.StateName');
			    $this->db->from('states');
			    $this->db->where('states.IsActive','1');
			    $this->db->order_by('states.StateName','ASC');
			    $query = $this->db->get();
				$MinistryState=$query->result_array();
				$data['State']=$MinistryState;
				$data['District']=array();
				$data['Facility']=array();
				break;
			case 'Assessors':
			    $this->db->select('states.StateID,states.StateName');
			    $this->db->from('states');
			    $this->db->where('states.IsActive','1');
			    $this->db->order_by('states.StateName','ASC');
			    $query = $this->db->get();
				$MinistryState=$query->result_array();
				$data['State']=$MinistryState;
				$data['District']=array();
				$data['Facility']=array();
				break;
			default:
			    $this->db->select('states.StateID,states.StateName');
			    $this->db->from('states');
			    $this->db->where('states.IsActive','1');
			    $this->db->order_by('states.StateName','ASC');
			    $query = $this->db->get();
				$MinistryState=$query->result_array();
				$data['State']=$MinistryState;
				$data['District']=array();
				$data['Facility']=array();
				break;
		}
		return $data;

	}
	function getSearchOptions_new(){
		$data=array();
		switch ($this->session->userdata('RoleName')) {
			case 'Facility':
			    $this->db->select('facilities.FacilityName,facilities.services,facilities.FacilityNumber,facilities.Address,facilities.PinCode,facilities.landLine,usermapping.UserID,typedetail.TypeDetailCode');
			    $this->db->from('usermapping');
			    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID AND usermapping.FacilityID>0', 'inner');
			    $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');
			    $this->db->where('usermapping.UserID',$this->session->userdata('UserID'));
			    $this->db->limit('1');
			    $query = $this->db->get();
				if($query->num_rows()>0){
					$data['Facility_show']=$query->row_array();
				}

			    /*$this->db->select('facilities.FacilityName,users.UserID');
			    $this->db->from('users');
			    $this->db->join('userrole', 'users.UserID=userrole.UserID', 'inner');
			    $this->db->join('role', 'userrole.RoleID=role.RoleID', 'inner');
			    $this->db->join('usermapping', 'userrole.UserID=usermapping.UserID AND usermapping.FacilityID>0', 'inner');
			    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
			    $this->db->where('usermapping.UserID',$this->session->userdata('UserID'));
			    $this->db->where('role.RoleName','Facility');
			    $this->db->order_by('facilities.FacilityName');
			    $query = $this->db->get();
				$Facility=$query->result_array();
				$data['Facility_show']=$Facility;*/

				break;
			case 'District':
			    $this->db->select('facilities.FacilityName,users.UserID');
			    $this->db->from('users');
			    $this->db->join('userrole', 'users.UserID=userrole.UserID', 'inner');
			    $this->db->join('role', 'userrole.RoleID=role.RoleID', 'inner');
			    $this->db->join('usermapping', 'userrole.UserID=usermapping.UserID AND usermapping.FacilityID>0', 'inner');
			    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
			    $this->db->where_in('facilities.DistrictID',explode(',',$this->session->userdata('MappedDistrict')));
			    $this->db->where('role.RoleName','Facility');
			    $this->db->order_by('facilities.FacilityName');
			    $query = $this->db->get();
				$DistrictFacility=$query->result_array();

				$data['Facility']=$DistrictFacility;
				break;
			case 'State':
			    $this->db->select('district.DistrictID,district.DistrictName');
			    $this->db->from('district');
			    $this->db->join('states', 'states.StateID=district.StateID', 'inner');
			    $this->db->where('district.IsActive','1');
			    $this->db->where_in('states.StateID',explode(',',$this->session->userdata('MappedState')));
			    $this->db->order_by('district.DistrictName','ASC');
			    $query = $this->db->get();
				$StateDistrict=$query->result_array();

				$data['District']=$StateDistrict;
				$data['Facility']=array();
				break;
			case 'Ministry':
			case 'NHSRC':
			    $this->db->select('states.StateID,states.StateName');
			    $this->db->from('states');
			    $this->db->where('states.IsActive','1');
			    $this->db->order_by('states.StateName','ASC');
			    $query = $this->db->get();
				$MinistryState=$query->result_array();
				$data['State']=$MinistryState;
				$data['District']=array();
				$data['Facility']=array();
				break;
			case 'Assessors':
			    $this->db->select('states.StateID,states.StateName');
			    $this->db->from('states');
			    $this->db->where('states.IsActive','1');
			    $this->db->where_in('states.StateID',explode(',',$this->session->userdata('MappedState')));
			    $this->db->order_by('states.StateName','ASC');
			    $query = $this->db->get();
				$MinistryState=$query->result_array();
				$data['State']=$MinistryState;
				$data['District']=array();
				$data['Facility']=array();
				break;
			default:
				
				break;
		}
		return $data;

	}
	function searchOptions(){
		$data=array();
		switch ($this->session->userdata('RoleName')) {
			case 'Facility':
			    $this->db->select('facilities.FacilityName,facilities.services,facilities.FacilityNumber,facilities.Address,facilities.PinCode,facilities.landLine,usermapping.UserID,typedetail.TypeDetailCode');
			    $this->db->from('usermapping');
			    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID AND usermapping.FacilityID>0', 'inner');
			    $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');
			    $this->db->where('usermapping.UserID',$this->session->userdata('UserID'));
			    $this->db->limit('1');
			    $query = $this->db->get();
				if($query->num_rows()>0){
					$data['Facility']=$query->row_array();
				}
				break;
			case 'District':
			    $this->db->select('facilities.FacilityName,users.UserID');
			    $this->db->from('users');
			    $this->db->join('userrole', 'users.UserID=userrole.UserID', 'inner');
			    $this->db->join('role', 'userrole.RoleID=role.RoleID', 'inner');
			    $this->db->join('usermapping', 'userrole.UserID=usermapping.UserID AND usermapping.FacilityID>0', 'inner');
			    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
			    $this->db->where_in('facilities.DistrictID',explode(',',$this->session->userdata('MappedDistrict')));
			    $this->db->where('role.RoleName','Facility');
			    $this->db->order_by('facilities.FacilityName');
			    $query = $this->db->get();
				$DistrictFacility=$query->result_array();
				$data['Facility']=$DistrictFacility;
				break;
			case 'State':
			    $this->db->select('district.DistrictID,district.DistrictName');
			    $this->db->from('district');
			    $this->db->join('states', 'states.StateID=district.StateID', 'inner');
			    $this->db->where('district.IsActive','1');
			    $this->db->where_in('states.StateID',explode(',',$this->session->userdata('MappedState')));
			    $this->db->order_by('district.DistrictName','ASC');
			    $query = $this->db->get();
				$StateDistrict=$query->result_array();
				$data['District']=$StateDistrict;
				$data['Facility']=array();
				break;
			default:
			    $this->db->select('states.StateID,states.StateName');
			    $this->db->from('states');
			    $this->db->where('states.IsActive','1');
			    if(!empty($this->session->userdata('MappedState'))){
			    	$this->db->where_in('states.StateID',explode(',',$this->session->userdata('MappedState')));
			    }
			    $this->db->order_by('states.StateName','ASC');
			    $query = $this->db->get();
				$MinistryState=$query->result_array();
				$data['State']=$MinistryState;
				$data['District']=array();
				$data['Facility']=array();				
				break;
		}
		return $data;
	}		
	function getFacilityFromDistrict($district){
	    $this->db->select('facilities.FacilityName,users.UserID');
	    $this->db->from('users');
	    $this->db->join('userrole', 'users.UserID=userrole.UserID', 'inner');
	    $this->db->join('role', 'userrole.RoleID=role.RoleID', 'inner');
	    $this->db->join('usermapping', 'userrole.UserID=usermapping.UserID AND usermapping.FacilityID>0', 'inner');
	    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
	    $this->db->where('facilities.DistrictID',$district);
	    $this->db->where('role.RoleName','Facility');
	    $this->db->order_by('facilities.FacilityName');
	    $query = $this->db->get();
		$DistrictFacility=$query->result_array();
		$data=$DistrictFacility;
		return $data;
	}
	function getDistrictDataFromState($state){
	    $this->db->select('district.DistrictName,district.DistrictID');
	    $this->db->from('district');
	    $this->db->where('district.StateID',$state);
	    $this->db->order_by('district.DistrictName');
	    $query = $this->db->get();
		$StateDistrict=$query->result_array();
		$data=$StateDistrict;
		return $data;
	}
	function getSurveyOption(){
	    $this->db->select('survey.SurveyID,answer.SurveyStatus');
	    $this->db->from('answer');
	    $this->db->join('survey', 'answer.SurveyID=survey.SurveyID', 'inner');
	    $this->db->where('answer.UserID',$this->session->userdata('facilityUser'));
	    $this->db->where('answer.Sequence','1');
	    $this->db->group_by(array("answer.Sequence", "answer.SurveyID"));
	    $query = $this->db->get();
		$QuerySurveyResult=$query->result();
		$data=array('labour'=>0,'ot'=>0);
		foreach ($QuerySurveyResult as $key => $value) {
			if($value->SurveyID=='1' && $value->SurveyStatus==1){
				$data['labour']=1;
			}
			if($value->SurveyID=='2' && $value->SurveyStatus==1){
				$data['ot']=1;
			}
		}
		return $data;
	}
	function getAssesmentData($facilityUser){
	    $this->db->select('facilities.FacilityName,answer.AssessmentDate,answer.AssessorsName1,answer.AssessorsName2,answer.AssesseesName1,answer.AssesseesName2,answer.AssessmentType,answer.start_date,answer.FacilityAvailable');
	    $this->db->from('usermapping');
	    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
	    $this->db->join('answer', 'usermapping.UserID=answer.UserID', 'left');
	    $this->db->where('usermapping.UserID',$facilityUser);
	    $this->db->where('usermapping.FacilityID >','0');
	    $this->db->order_by('answer.AnswerID', 'DESC');
	    $this->db->limit('1');
	    $result = $this->db->get();
		$data=$result->row_array();
	    $response['code']=$result ->num_rows();
	    $response['msg']=$result ->num_rows().' data get';
	    $response['data']=$data;
		return $response;
	}
	function saveAssesmentData($saveData){
		if($saveData['AnswerID']>0){
			$this->db->where('answer.AnswerID', $saveData['AnswerID']);
			$this->db->update('answer', $saveData);
			$ansId=$saveData['AnswerID'];
		} else {
		    if($this->db->insert('answer', $saveData)){
				$ansId=$this->db->insert_id();
			} else {
				$ansId=0;
			}			
		}
		return $ansId;
	}
	function checkSurveyAns($answer,$survey){
	  	$sql="select a.AnswerID,a.SurveyStatus 
	  	from question 
	  	q INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) 
	  	INNER join category c on (s.CategoryID=c.CategoryID) 
	  	INNER JOIN survey on(c.SurveyID=survey.SurveyID) 
	  	INNER join answer a on(survey.SurveyID=a.SurveyID and a.Sequence='1') 
	  	LEFT join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1') 
	  	WHERE survey.SurveyID='".$survey."' AND a.AnswerID='".$answer."' AND ad.AnswerDetailID is null 
	  	ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.Serial ASC";
	  	
	    $result = $this->db->query($sql, NULL);
	    $data=$result->result_array();
	    if(count($data)>0){
		    foreach ($data as $key => $value) {
				$updateAns=array(
					'SurveyStatus'=>'0'
				);
				$this->db->where('AnswerID', $answer);
				$this->db->update('answer', $updateAns);
				$response='draft';
		    }	    	
	    } else {
			$updateAns=array(
				'SurveyStatus'=>'1',
				'end_date'=>date('Y-m-d H:i:s'),
			);
			$this->db->where('AnswerID', $answer);
			$this->db->update('answer', $updateAns);
	    	$response='save';
	    	$this->session->set_userdata('surveyScore', $answer);
	    }
		return $response;		
	}

	function getFacilityScore($ansId){
	  	$sql="select survey.SurveyDesc,survey.SurveyName,c.CategoryCode,c.CategoryName,count(q.QuestionID) as quesTot,sum(ad.Answer) as answer,ROUND(((sum(ad.Answer)/(count(q.QuestionID)*2) )*100)) as score from question q INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) INNER join category c on (s.CategoryID=c.CategoryID) INNER JOIN survey on(c.SurveyID=survey.SurveyID) INNER join answer a on(survey.SurveyID=a.SurveyID ) INNER join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1') WHERE a.AnswerID='".$ansId."' GROUP BY c.CategoryCode ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.Serial ASC";
	    $result = $this->db->query($sql, NULL);
	    $data=array();
	    foreach ($result->result_array() as $key => $value) {
	    	$data['score'][]=$value;
	    }
	  	$sql="select a.AnswerID,a.format,a.clientScore,a.Sequence,DATE_FORMAT(a.AssessmentDate,'%d-%m-%Y') as AssessmentDate,a.AssessorsName1,a.AssessorsName2,a.AssesseesName1,a.AssesseesName2,f.FacilityName 
from answer a 
INNER JOIN usermapping um ON(a.UserID=um.UserID AND um.FacilityID>0)
INNER JOIN facilities f on(um.FacilityID=f.FacilityID)
WHERE a.AnswerID='".$ansId."'";
	    $result = $this->db->query($sql, NULL);
	    $data['facility']=$result->row_array();
	    $data['facility']['Sequence']=$this->config->item('assesmentSequence')[$data['facility']['Sequence']];

	  	$sql="select c.CategoryID,c.CategoryCode,c.CategoryName,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,count(q.QuestionID) as quesTot,sum(ad.Answer) as answer,ROUND(((sum(ad.Answer)/(count(q.QuestionID)*2) )*100)) as score 
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) 
INNER join category c on (s.CategoryID=c.CategoryID) 
INNER JOIN survey on(c.SurveyID=survey.SurveyID) 
INNER join answer a on(survey.SurveyID=a.SurveyID ) 
INNER join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1') 
WHERE a.AnswerID='".$ansId."' 
GROUP BY s.SubcategoryID 
ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.Serial ASC";
	    $result = $this->db->query($sql, NULL);
	    $data['standered_data']=array();
	    foreach ($result->result() as $key => $value) {
	    	if(!array_key_exists($value->CategoryCode, $data['standered_data'])){
	    		$data['standered_data'][$value->CategoryCode]=array(
	    			'CategoryID'=>$value->CategoryCode,
	    			'CategoryCode'=>$value->CategoryCode,
	    			'CategoryName'=>$value->CategoryName,
	    			'standered'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->SubcategoryID, $data['standered_data'][$value->CategoryCode]['standered'])){
	    		$data['standered_data'][$value->CategoryCode]['standered'][$value->SubcategoryID]=array(
	    			'SubCategoryCode'=>$value->SubCategoryCode,
	    			'SubCategoryName'=>$value->SubCategoryName,
	    			'quesTot'=>$value->quesTot,
	    			'answer'=>$value->answer,
	    			'score'=>$value->score
	    		);
	    	}
	    }


	    return $data;

		
	}

	function savescore($ansId,$data){
		if(isset($data['q1']) && !empty($data['q1'])){
			foreach ($data['q1'] as $key => $value) {
				if(!empty($value)){
					$saveData=array(
						'AnswerID'=>$ansId,
						'remarksType'=>'1',
						'remarks'=>$value,
						'CreatedOn'=>date('Y-m-d H:i:s'),
						'CreatedBy'=>$this->session->userdata('UserID')
					);
					if($this->db->insert('answerremarks', $saveData)){
						$LoginHisID=$this->db->insert_id();
					} else {
						$this->db->insert('answerremarks', $saveData);
						$LoginHisID=$this->db->insert_id();
					}
				}
			}			
		}
		if(isset($data['q2']) && !empty($data['q2'])){
			foreach ($data['q2'] as $key => $value) {
				if(!empty($value)){
					$saveData=array(
						'AnswerID'=>$ansId,
						'remarksType'=>'2',
						'remarks'=>$value,
						'CreatedOn'=>date('Y-m-d H:i:s'),
						'CreatedBy'=>$this->session->userdata('UserID')
					);
					if($this->db->insert('answerremarks', $saveData)){
						$LoginHisID=$this->db->insert_id();
					} else {
						$this->db->insert('answerremarks', $saveData);
						$LoginHisID=$this->db->insert_id();
					}					
				}				
			}			
		}
		if(isset($data['q3']) && !empty($data['q3'])){
			foreach ($data['q3'] as $key => $value) {
				if(!empty($value)){
					$saveData=array(
						'AnswerID'=>$ansId,
						'remarksType'=>'3',
						'remarks'=>$value,
						'CreatedOn'=>date('Y-m-d H:i:s'),
						'CreatedBy'=>$this->session->userdata('UserID')
					);
					if($this->db->insert('answerremarks', $saveData)){
						$LoginHisID=$this->db->insert_id();
					} else {
						$this->db->insert('answerremarks', $saveData);
						$LoginHisID=$this->db->insert_id();
					}					
				}				
			}			
		}
		if(isset($data['clientScore']) && !empty($data['clientScore'])){
			$clientScore=$data['clientScore'];
		} else {
			$clientScore='0';
		}
		$updateAns=array(
			//'device'=>$dataAns['device'],
			'clientScore'=>$clientScore,
			'ModifiedOn'=>date('Y-m-d H:i:s'),
			'SurveyStatus'=>'1',
			'ModifiedBy'=>$this->session->userdata('UserID'),
		);
		$this->db->where('AnswerID', $ansId);
		$this->db->update('answer', $updateAns);
	}
	function getscore($ansId){
	    $this->db->select('answerremarks.*');
	    $this->db->from('answerremarks');
	    $this->db->where('answerremarks.AnswerID',$ansId);
	    $this->db->order_by('answerremarks.AnswerID', 'ASC');
	   
	    $result = $this->db->get();
	    $data=array();
		foreach ($result->result_array() as $key => $value) {
			$remarksType=$this->config->item('RemarksTypes')[$value['remarksType']];
			$data[$remarksType][]=$value;
		}
	    /*$response['code']=$result ->num_rows();
	    $response['msg']=$result ->num_rows().' data get';
	    $response['data']=$data;*/
		return $data;		
	}
	function checkFacilityAdd($facilityUser){
	    if($facilityUser){
		    $this->db->select('answer.AnswerID');
		    $this->db->from('answer');
		    $this->db->where('answer.UserID',$facilityUser);
		    $this->db->where('answer.Sequence','1');
		    $result = $this->db->get();
		    if($result ->num_rows()>=2){
			    $response['code']=$result ->num_rows();
			    $response['msg']=$result ->num_rows().' data get';
		    } else {
			    $response['code']='0';
			    $response['msg']=$result ->num_rows().' data get';
		    }
	    } else {
		    $response['code']='14';
		    $response['msg']='No Proper Data Submitted';
	    }
		return $response;	    
	}
	function checkQuestionExist($survey,$ques,$subcat,$checklist_format='A'){
		$questionId=0;
		$ques=preg_replace('/[^A-Za-z0-9]/', '', trim($ques));
	    if(!empty($ques) && !empty($survey)){
		    $this->db->select('q.QuestionID');
		    $this->db->from('question q');
		    $this->db->join('subcategory s', 'q.SubcategoryID = s.SubcategoryID', 'inner'); 
		    $this->db->join('category c', 's.CategoryID = c.CategoryID', 'inner'); 
		    $this->db->join('survey', 'c.SurveyID = survey.SurveyID', 'inner'); 
		    $this->db->where('survey.SurveyID',$survey);
		    //$this->db->like('q.checkpoint_code',trim($ques));
		    $this->db->where('q.checkpoint_code',trim($ques));
		    $this->db->where('q.IsActive','1');
		    $this->db->where('q.format',$checklist_format);
		    $this->db->where('q.SubcategoryID',$subcat);
		    $result = $this->db->get();
		    if($result ->num_rows()>=1){
		    	$resQry=$result->result_array();
		    	$questionId=$resQry[0]['QuestionID'];
		    } else {
		    	//echo $this->db->last_query(); echo PHP_EOL;
		    	$questionId=0;
		    }
	    } else {
		    $questionId=0;
	    }
		return $questionId;
	}
	function checkSubCatExist($survey,$subCat,$checklist_format='A'){
		$SubcategoryID=0;
	    if(!empty($subCat) && !empty($survey)){
		    $this->db->select('s.SubcategoryID');
		    $this->db->from('subcategory s');
		    $this->db->join('category c', 's.CategoryID = c.CategoryID', 'inner'); 
		    $this->db->join('survey', 'c.SurveyID = survey.SurveyID', 'inner'); 
		    $this->db->where('survey.SurveyID',$survey);
		    $this->db->where('s.IsActive','1');
		    $this->db->where('s.format',$checklist_format);
		    $this->db->like('s.SubCategoryCode',$subCat);
		    $result = $this->db->get();
		    if($result ->num_rows()>=1){
		    	$resQry=$result->result_array();
		    	$SubcategoryID=$resQry[0]['SubcategoryID'];
		    } else {
		    	$SubcategoryID=0;
		    }
	    } else {
		    $SubcategoryID=0;
	    }
		return $SubcategoryID;
	}
	function checkFacilityExist($facilityname){
		$FacilityID=0;
		$facilityname=preg_replace('/[^A-Za-z0-9\- .]/', '', trim($facilityname));
	    if(!empty($facilityname)){
		    $this->db->select('facilities.FacilityID');
		    $this->db->from('facilities');
		    $this->db->where('facilities.FacilityName',trim($facilityname));
		    $this->db->where('facilities.IsActive','1');
		    $result = $this->db->get();
		    if($result ->num_rows()>=1){
		    	$resQry=$result->result_array();
		    	$FacilityID=$resQry[0]['FacilityID'];
		    } else {
		    	$FacilityID=0;
		    }
	    } else {
		    $FacilityID=0;
	    }
		return $FacilityID;
	}
	function surveyFormatApp_old($SurveyType,$catgory){
		if(!empty($SurveyType)){
			$survyCond=" AND survey.SurveyID='".$SurveyType."' ";
		} else {
			$survyCond='';
		}
		if(!empty($catgory)){
			$CatCond=" AND c.CategoryID='".$catgory."' ";
		} else {
			$CatCond='';
		}
		$response=array();
	  	$sql="select survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,c.Icon,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
WHERE 1 ".$survyCond.$CatCond."
ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC";
	    $result = $this->db->query($sql, NULL);
	    $data['survey']=array();
	    foreach ($result->result() as $key => $value) {
	    	if(!array_key_exists($value->SurveyID, $data['survey'])){
	    		$data['survey'][$value->SurveyID]=array(
			    	'SurveyID'=>$value->SurveyID,
			    	'SurveyName'=>$value->SurveyName,
			    	'SurveyDesc'=>$value->SurveyDesc,
			    	'category'=>array(),
	    		);
	    	}
	    	if(!array_key_exists($value->CategoryID, $data['survey'][$value->SurveyID]['category'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]=array(
	    			'CategoryID'=>$value->CategoryID,
	    			'CategoryName'=>$value->CategoryName,
	    			'CategoryCode'=>$value->CategoryCode,
	    			'Icon'=>$value->Icon,
	    			'subcategory'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->SubcategoryID, $data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]=array(
	    			'SubcategoryID'=>$value->SubcategoryID,
	    			'SubCategoryCode'=>$value->SubCategoryCode,
	    			'SubCategoryName'=>$value->SubCategoryName,
	    			'questions'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->QuestionID, $data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'])){
	    		if(!empty($value->Reference)){
                    $Reference=$value->Reference;
                }
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'][$value->QuestionID]=array(
	    			'QuestionID'=>$value->QuestionID,
	    			'Reference'=>$Reference,
	    			'Statement'=>$value->Statement,
	    			'Checkpoint'=>$value->Checkpoint,
	    			'Assesment'=>$value->Assesment,
	    			'Verification'=>$value->Verification,
	    			'Remarks'=>$value->Remarks,
	    		);
	    	}	    	
	    }
		return $data;

	}
	function surveyFormatApp($SurveyType,$catgory,$subcategory,$question,$format='A'){
		$response=array();
		if(!empty($SurveyType)){
			$categoryData=array();
			$survyCond=" AND survey.SurveyID='".$SurveyType."' ";
		  	$sqlSurvey="select survey.SurveyID,survey.SurveyName,survey.SurveyDesc
	from survey 
	WHERE 1 ".$survyCond."
	ORDER by survey.SurveyName ASC";
		    $resultSurvey = $this->db->query($sqlSurvey, NULL);
		    foreach ($resultSurvey->result() as $key => $value) {
		    	$surveyData=array(
		    		'SurveyID'=>$value->SurveyID,
		    		'SurveyName'=>$value->SurveyName,
		    		'SurveyDesc'=>$value->SurveyDesc
		    	);
				if(!empty($catgory)){
					$CatCond=" AND c.CategoryID='".$catgory."' ";
				} else {
					$CatCond=" AND survey.SurveyID='".$value->SurveyID."' ";
				}
/*			  	$sqlCat="select c.CategoryID,c.CategoryName,c.CategoryCode,c.Icon
		from category c
		INNER JOIN survey on(c.SurveyID=survey.SurveyID)
		WHERE 1 AND c.format='".$format."' ".$survyCond.$CatCond." 
		ORDER by survey.SurveyName,c.CategoryCode ASC";*/
			  	$sqlCat="select c.CategoryID,c.CategoryName,c.CategoryCode,c.Icon
		from category c
		INNER JOIN survey on(c.SurveyID=survey.SurveyID)
		WHERE 1 ".$survyCond.$CatCond." 
		ORDER by survey.SurveyName,c.CategoryCode ASC";
			    $resultCat = $this->db->query($sqlCat, NULL);
			    foreach ($resultCat->result() as $keyCat => $valueCat) {
			    	$SubcategoryData=array();
			    	$categoryDataIn=array(
		    			'CategoryID'=>$valueCat->CategoryID,
		    			'CategoryName'=>$valueCat->CategoryName,
		    			'CategoryCode'=>$valueCat->CategoryCode,
		    			'Icon'=>$valueCat->Icon,		    		
			    	);
					if(!empty($subcategory)){
						$SubCatCond=" AND s.SubcategoryID='".$subcategory."' ";
					} else {
						$SubCatCond=" AND c.CategoryID='".$valueCat->CategoryID."' ";
					}
/*				  	$sqlSubCat="select s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName
						from subcategory s
						INNER join category c on (s.CategoryID=c.CategoryID)
						INNER JOIN survey on(c.SurveyID=survey.SurveyID)
						WHERE 1 AND c.format='".$format."' AND s.format='".$format."' ".$survyCond.$CatCond.$SubCatCond." 
						ORDER by survey.SurveyName,c.CategoryCode,s.SubcategoryID ASC";*/
				  	$sqlSubCat="select s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName
						from subcategory s
						INNER join category c on (s.CategoryID=c.CategoryID)
						INNER JOIN survey on(c.SurveyID=survey.SurveyID)
						WHERE 1  ".$survyCond.$CatCond.$SubCatCond." 
						ORDER by survey.SurveyName,c.CategoryCode,s.SubcategoryID ASC";
				    $resultSubCat = $this->db->query($sqlSubCat, NULL);
				    foreach ($resultSubCat->result() as $keySubCat => $valueSubCat) {
				    	$questionData=array();
				    	$subCategoryDataIn=array(
			    			'SubcategoryID'=>$valueSubCat->SubcategoryID,
			    			'SubCategoryCode'=>$valueSubCat->SubCategoryCode,
			    			'SubCategoryName'=>$valueSubCat->SubCategoryName		    		
				    	);
						if(!empty($question)){
							$QuesCond=" AND q.QuestionID='".$question."' ";
						} else {
							$QuesCond=" AND s.SubcategoryID='".$valueSubCat->SubcategoryID."' ";
						}
					  	$sqlQues="select survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,c.Icon,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*
							from question q 
							INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
							INNER join category c on (s.CategoryID=c.CategoryID)
							INNER JOIN survey on(c.SurveyID=survey.SurveyID)
							WHERE 1 ".$survyCond.$CatCond.$SubCatCond.$QuesCond."
							ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC";
					    $resultQues = $this->db->query($sqlQues, NULL);
					    foreach ($resultQues->result() as $keyQues => $valueQues) {
				    		if(!empty($valueQues->Reference)){
			                    $Reference=$valueQues->Reference;
			                    $parentID=$valueQues->QuestionID;
			                }
					    	$quesDataIn=array(
				    			'QuestionID'=>$valueQues->QuestionID,
				    			'parentID'=>$parentID,
				    			'Reference'=>$Reference,
				    			'Statement'=>$valueQues->Statement,
				    			'Checkpoint'=>$valueQues->Checkpoint,
				    			'Assesment'=>$valueQues->Assesment,
				    			'Verification'=>$valueQues->Verification,
				    			'Remarks'=>$valueQues->Remarks
					    	);
					    	$questionData[]=$quesDataIn;
					    }
					    $subCategoryDataIn['question']=$questionData;
				    	$SubcategoryData[]=$subCategoryDataIn;				    	
				    }
				    $categoryDataIn['Subcategory']=$SubcategoryData;
			    	$categoryData[]=$categoryDataIn;
			    }
			    $surveyData['catgory']=$categoryData;
		    	$response=$surveyData;
		    }			
		} else {
			$response=array();
		}
		return $response;

	}
	function surveyFormatApp1($SurveyType,$catgory){
		if(!empty($SurveyType)){
			$survyCond=" AND survey.SurveyID='".$SurveyType."' ";
		} else {
			$survyCond='';
		}
		if(!empty($catgory)){
			$CatCond=" AND c.CategoryID='".$catgory."' ";
		} else {
			$CatCond='';
		}
		$response=array();
	  	$sql="select survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,c.Icon,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
WHERE 1 ".$survyCond.$CatCond."
ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC";
	    $result = $this->db->query($sql, NULL);
	    $data['survey']=array();
	    foreach ($result->result() as $key => $value) {
	    	if(!array_key_exists($value->SurveyID, $data['survey'])){
	    		$data['survey'][$value->SurveyID]=array(
			    	'SurveyID'=>$value->SurveyID,
			    	'SurveyName'=>$value->SurveyName,
			    	'SurveyDesc'=>$value->SurveyDesc,
			    	'category'=>array(),
	    		);
	    	}
	    	if(!array_key_exists($value->CategoryID, $data['survey'][$value->SurveyID]['category'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]=array(
	    			'CategoryID'=>$value->CategoryID,
	    			'CategoryName'=>$value->CategoryName,
	    			'CategoryCode'=>$value->CategoryCode,
	    			'Icon'=>$value->Icon,
	    			'subcategory'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->SubcategoryID, $data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]=array(
	    			'SubcategoryID'=>$value->SubcategoryID,
	    			'SubCategoryCode'=>$value->SubCategoryCode,
	    			'SubCategoryName'=>$value->SubCategoryName,
	    			'questions'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->QuestionID, $data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'])){
	    		if(!empty($value->Reference)){
                    $Reference=$value->Reference;
                }
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'][$value->QuestionID]=array(
	    			'QuestionID'=>$value->QuestionID,
	    			'Reference'=>$Reference,
	    			'Statement'=>$value->Statement,
	    			'Checkpoint'=>$value->Checkpoint,
	    			'Assesment'=>$value->Assesment,
	    			'Verification'=>$value->Verification,
	    			'Remarks'=>$value->Remarks,
	    		);
	    	}	    	
	    }
		return $data;

	}
	function assesmentDataView($assesmentID){
	    $this->db->select('facilities.FacilityName,DATE_FORMAT(answer.AssessmentDate,"%d-%m-%Y") as AssessmentDate,answer.AssessorsName1,answer.AssessorsName2,answer.AssesseesName1,answer.AssesseesName2,answer.AssessmentType,DATE_FORMAT(answer.start_date,"%d-%m-%Y") as start_date,answer.Sequence,answer.SurveyID');
	    $this->db->from('answer');
	    $this->db->join('usermapping', 'answer.UserID=usermapping.UserID AND usermapping.FacilityID >0', 'left');
	    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'left');
	    $this->db->where('answer.AnswerID',$assesmentID);
	    $this->db->order_by('answer.AnswerID', 'DESC');
	    $this->db->limit('1');
	    $result = $this->db->get();
		$data=$result->row_array();
		$data['Sequence']=$this->config->item('assesmentSequence')[$data['Sequence']];
	    $response['survey']=$data['SurveyID']=='1'?'labourChecklist':'operationChecklist';
	    if(empty($data['AssessmentDate']) || $data['AssessmentDate']=='0000-00-00' || $data['AssessmentDate']=='1970-01-01'){
	    	$data['AssessmentDate']='';
	    }
	    if(empty($data['AssessorsName1'])){
	    	$data['AssessorsName1']='';
	    }
	    if(empty($data['AssessorsName2'])){
	    	$data['AssessorsName2']='';
	    }
	    if(empty($data['AssesseesName1'])){
	    	$data['AssesseesName1']='';
	    }
	    if(empty($data['AssesseesName2'])){
	    	$data['AssesseesName2']='';
	    }
	    if(empty($data['start_date']) || $data['start_date']=='0000-00-00' || $data['start_date']=='1970-01-01'){
	    	$data['start_date']='';
	    }
	    $response['code']=$result ->num_rows();
	    $response['msg']=$result ->num_rows().' data get';
	    $response['data']=$data;
		return $response;
	}
	function checkEntry($surveyType,$survey,$userId){
	    $this->db->select('answer.AnswerID');
	    $this->db->from('answer');
	    $this->db->where('answer.UserID',$userId);
	    $this->db->where('answer.SurveyID',$survey);
	    $this->db->where('answer.Sequence',$surveyType);
	    $this->db->where('answer.IsActive','1');
	    $this->db->order_by('answer.AnswerID', 'DESC');
	    $result = $this->db->get();
		if($result ->num_rows()==0){
			return true;
		} else {
			return false;
		}
	}
	function lastAssesment($facility,$assesmentType,$sequence){
		if($assesmentType=='LR' || $assesmentType=='both'){
		    $this->db->select('answer.AnswerID,answer.AssessmentDate');
		    $this->db->from('answer');
		    $this->db->where('answer.UserID',$facility);
		    $this->db->where('answer.SurveyID','1');
		    $this->db->where('answer.SurveyStatus','1');
		    if(!empty($sequence)){
		    	$this->db->where('answer.Sequence',$sequence);
		    }
		    $this->db->order_by('answer.AnswerID', 'DESC');
		    $this->db->limit('1');
		    $result = $this->db->get();
			if($result ->num_rows()==0){
				$lrScore=0;
				$AssessmentDateLR='';
			} else {
				$data=$result->result_array();
			  	$sql="select survey.SurveyDesc,survey.SurveyName,c.CategoryCode,c.CategoryName,count(q.QuestionID) as quesTot,sum(ad.Answer) as answer,ROUND(((sum(ad.Answer)/(count(q.QuestionID)*2) )*100)) as score from question q INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) INNER join category c on (s.CategoryID=c.CategoryID) INNER JOIN survey on(c.SurveyID=survey.SurveyID) INNER join answer a on(survey.SurveyID=a.SurveyID ) INNER join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1') WHERE a.AnswerID='".$data[0]['AnswerID']."' GROUP BY c.CategoryCode ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.Serial ASC";
			    $result1 = $this->db->query($sql, NULL);
			    $quesTot=0;
			    $ansTot=0;
			    foreach ($result1->result_array() as $key => $value) {
				    $quesTot+=$value['quesTot']*2;
				    $ansTot+=$value['answer'];
			    }						
				$lrScore=(int)(((int)$ansTot/(int)$quesTot)*100);
				$AssessmentDateLR=$data[0]['AssessmentDate'];
			}			
		} else {
			$lrScore='';
			$AssessmentDateLR='';
		}

		if($assesmentType=='OT' || $assesmentType=='both'){
		    $this->db->select('answer.AnswerID,answer.AssessmentDate');
		    $this->db->from('answer');
		    $this->db->where('answer.UserID',$facility);
		    $this->db->where('answer.SurveyID','2');
		    $this->db->where('answer.SurveyStatus','1');
		    if(!empty($sequence)){
		    	$this->db->where('answer.Sequence',$sequence);
		    }
		    $this->db->order_by('answer.AnswerID', 'DESC');
		    $this->db->limit('1');
		    $result = $this->db->get();
			if($result ->num_rows()==0){
				$otScore=0;
				$AssessmentDateOT='';
			} else {
				$data=$result->result_array();
			  	$sql="select survey.SurveyDesc,survey.SurveyName,c.CategoryCode,c.CategoryName,count(q.QuestionID) as quesTot,sum(ad.Answer) as answer,ROUND(((sum(ad.Answer)/(count(q.QuestionID)*2) )*100)) as score from question q INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID) INNER join category c on (s.CategoryID=c.CategoryID) INNER JOIN survey on(c.SurveyID=survey.SurveyID) INNER join answer a on(survey.SurveyID=a.SurveyID ) INNER join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1') WHERE a.AnswerID='".$data[0]['AnswerID']."' GROUP BY c.CategoryCode ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.Serial ASC";
			    $result1 = $this->db->query($sql, NULL);
			    $quesTot=0;
			    $ansTot=0;
			    foreach ($result1->result_array() as $key => $value) {
				    $quesTot+=$value['quesTot']*2;
				    $ansTot+=$value['answer'];
			    }						
				$otScore=(int)(((int)$ansTot/(int)$quesTot)*100);
				$AssessmentDateOT=$data[0]['AssessmentDate'];
			}
		} else {
			$otScore='';
			$AssessmentDateOT='';
		}
		return array('lrscore'=>$lrScore,'AssessmentDateLR'=>$AssessmentDateLR,'otscore'=>$otScore,'AssessmentDateOT'=>$AssessmentDateOT);
	}
	function checkBaselineEntry($SurveyID,$facilityUser){
	    $this->db->select('answer.AnswerID');
	    $this->db->from('answer');
	    $this->db->where('answer.UserID',$facilityUser);
	    $this->db->where('answer.SurveyID',$SurveyID);
	    $this->db->where('answer.Sequence','1');
	    $this->db->where('answer.SurveyStatus','1');
	    $this->db->order_by('answer.AnswerID', 'DESC');
	    $result = $this->db->get();
		if($result ->num_rows()==0){
			return 0;
		} else {
			return 3;
		}
	}
	function checkEntryLast($SurveyID,$facilityUser){
		if($SurveyID=='2'){
		    $this->db->select('facilities.services');
		    $this->db->from('usermapping');
		    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID AND usermapping.FacilityID>0', 'inner');	    
		    $this->db->where('usermapping.UserID',$facilityUser);
		    $queryServices = $this->db->get();
			$dataServices=$queryServices->row_array();
			if($dataServices['services']=='lr'){
				$respone=array('code'=>'2','type'=>'LR','href'=>'facility/checklist/'.encryptor('1'),'msg'=>'Facility do not have OT services so please update servies provided in profile first.');
				return $respone;			
			}
		}
	    $this->db->select('answer.SurveyID,answer.SurveyStatus,answer.AnswerID,answerremarks.AnswerremarksID');
	    $this->db->from('answer');
	    $this->db->join('answerremarks', 'answer.AnswerID=answerremarks.AnswerID', 'left');
	    $this->db->where('answer.UserID',$facilityUser);
	    $this->db->where('answer.IsActive','1');
	    $this->db->order_by('answer.SurveyStatus', 'ASC');
	    $this->db->limit('1');
	    $result = $this->db->get();
		if($result ->num_rows()==0){
			if($SurveyID=='2'){
				$respone=array('code'=>'2','type'=>'LR','href'=>'facility/checklist/'.encryptor('1'),'msg'=>'OT Assessment can only be done after LR Assessment. Please do the LR Assessment first');
				return $respone;				
			} else {
				return array('code'=>'0');
			}
		} else {
			$data=$result->result_array();
			if($SurveyID=='1'){
				if($data[0]['SurveyID']=='1' && $data[0]['SurveyStatus']!='1' ){
					// redirect to questions
					$respone=array('code'=>'2','type'=>'LR','ansID'=>$data[0]['AnswerID'],'href'=>'facility/checklist/'.encryptor('1').'/'.encryptor($data[0]['AnswerID']),'msg'=>'Your previous LR Assessment is already saved in draft. You will be redirected to continue with draft assessment');
					return $respone;
				} else if($data[0]['SurveyID']=='2' && ($data[0]['SurveyStatus']!='1' ) ){
					// OT not complete
					$respone=array('code'=>'2','type'=>'OT','ansID'=>$data[0]['AnswerID'],'href'=>'facility/checklist/'.encryptor('2').'/'.encryptor($data[0]['AnswerID']),'msg'=>'Your previous OT Assessment is already saved in draft. You will be redirected to continue with draft assessment');
					return $respone;
				} else {
					$respone=array('code'=>'0');
					return $respone;					
				}
			} else {
				if($data[0]['SurveyID']=='2' && $data[0]['SurveyStatus']=='1'  ){
					// ot already filled, fill lr
					$respone=array('code'=>'2','type'=>'LR','ansID'=>0,'href'=>'facility/checklist/'.encryptor('2'),'msg'=>'Your previous OT Assessment is completed. You will be redirected to continue with LR assessment');
					return $respone;
				} else if($data[0]['SurveyID']=='1' && ($data[0]['SurveyStatus']!='1') ){
					// lr not complete
					$respone=array('code'=>'2','type'=>'LR','ansID'=>$data[0]['AnswerID'],'href'=>'facility/checklist/'.encryptor('1').'/'.encryptor($data[0]['AnswerID']),'msg'=>'Your previous LR Assessment is already saved in draft. You will be redirected to continue with draft assessment');
					return $respone;
				} else if($data[0]['SurveyID']=='2' && ($data[0]['SurveyStatus']!='1' ) ){
					// redirect to question ot
					$respone=array('code'=>'2','type'=>'OT','ansID'=>$data[0]['AnswerID'],'href'=>'facility/checklist/'.encryptor('2').'/'.encryptor($data[0]['AnswerID']),'msg'=>'Your previous OT Assessment is already saved in draft. You will be redirected to continue with draft assessment');
					return $respone;
				}
			}
		}
	}
	function answerview_old($ansId,$catgory,$subcatgory,$QuestionID){
		$response=array(); $data=array();
		if(!empty($catgory)){
			$CatCond=" AND c.CategoryID='".$catgory."' ";
		} else {
			$CatCond='';
		}
		if(!empty($subcatgory)){
			$subcatgoryCond=" AND s.SubcategoryID='".$subcatgory."' ";
		} else {
			$subcatgoryCond='';
		}
		if(!empty($QuestionID)){
			$QuestionIDCond=" AND q.QuestionID='".$QuestionID."' ";
		} else {
			$QuestionIDCond='';
		}
	  	$sql="select a.SurveyStatus,ad.Answer, survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
LEFT join answer a on(survey.SurveyID=a.SurveyID)
LEFT join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1')
WHERE a.AnswerID='".$ansId."'".$CatCond.$subcatgoryCond.$QuestionIDCond." 
ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC ";
	    $result = $this->db->query($sql, NULL);
	    $data['category']=array();
	    foreach ($result->result() as $key => $value) {
	    	/*if(!array_key_exists($value->SurveyID, $data['survey'])){
	    		$data['survey'][$value->SurveyID]=array(
	    			'SurveyID'=>$value->SurveyID,
			    	'SurveyName'=>$value->SurveyName,
			    	'SurveyDesc'=>$value->SurveyDesc,
			    	'category'=>array(),
	    		);
	    	}*/
	    	if(!array_key_exists('category'.$value->CategoryID, $data['category'])){
	    		$data['category']['category'.$value->CategoryID]=array(
	    			'CategoryID'=>$value->CategoryID,
	    			'CategoryName'=>$value->CategoryName,
	    			'CategoryCode'=>$value->CategoryCode,
	    			'subcategory'=>array()
	    		);
	    	}
	    	if(!array_key_exists('subcategory'.$value->SubcategoryID, $data['category']['category'.$value->CategoryID]['subcategory'])){
	    		$data['category']['category'.$value->CategoryID]['subcategory']['subcategory'.$value->SubcategoryID]=array(
	    			'SubcategoryID'=>$value->SubcategoryID,
	    			'SubCategoryCode'=>$value->SubCategoryCode,
	    			'SubCategoryName'=>$value->SubCategoryName,
	    			'questions'=>array()
	    		);
	    	}
	    	if(!array_key_exists('questions'.$value->QuestionID, $data['category']['category'.$value->CategoryID]['subcategory']['subcategory'.$value->SubcategoryID]['questions'])){
                if(!empty($value->Reference)){
                    $Reference=$value->Reference;
                    $parentID=$value->QuestionID;
                }
                $data['category']['category'.$value->CategoryID]['subcategory']['subcategory'.$value->SubcategoryID]['questions']['questions'.$value->QuestionID]=array(
                    'QuestionID'=>$value->QuestionID,
                    'parentID'=>$parentID,
	    			'Reference'=>$value->Reference,
	    			'Statement'=>$value->Statement,
	    			'Checkpoint'=>$value->Checkpoint,
	    			'Assesment'=>$value->Assesment,
	    			'Verification'=>$value->Verification,
	    			'Remarks'=>$value->Remarks,
	    			'Answer'=>$value->Answer,
                );
            }
	    	/*if(!array_key_exists('questions'.$value->QuestionID, $data['category']['category'.$value->CategoryID]['subcategory']['subcategory'.$value->SubcategoryID]['questions'])){
	    		$data['category']['category'.$value->CategoryID]['subcategory']['subcategory'.$value->SubcategoryID]['questions']['questions'.$value->QuestionID]=array(
	    			'QuestionID'=>$value->QuestionID,
	    			'Reference'=>$value->Reference,
	    			'Statement'=>$value->Statement,
	    			'Checkpoint'=>$value->Checkpoint,
	    			'Assesment'=>$value->Assesment,
	    			'Verification'=>$value->Verification,
	    			'Remarks'=>$value->Remarks,
	    			'Answer'=>$value->Answer,
	    		);
	    	}*/	    	


	    }
	    $sqlTot="select count(q.QuestionID) ques,(case when (ad.AnswerDetailID IS NULL) 
 THEN
      'not' 
 ELSE
      'yes' 
 END)
 as checkdata
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
LEFT join answer a on(survey.SurveyID=a.SurveyID)
LEFT join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1')
WHERE a.AnswerID='".$ansId."'
GROUP by ad.AnswerID
";
	    $resultTot = $this->db->query($sqlTot, NULL);
	    $resultTotData=$resultTot->result_array();
	    $data['tot']=array('yes'=>0,'not'=>'0');
	    $totquestions=0;
	    foreach ($resultTotData as $key => $value) {
	    	$data['tot'][$value['checkdata']]=$value['ques'];
	    	$totquestions+=$value['ques'];
	    }
	    $data['tot']['allques']=$totquestions;
	    $response['code']='10';
	    $response['msg']=$this->config->item('errCodes')[10];
	    $response['data']=$data;
		return $response;
		
	/*
		$response=array(); $data=array();
		if(!empty($catgory)){
			$CatCond=" AND c.CategoryID='".$catgory."' ";
		} else {
			$CatCond='';
		}
		if(!empty($subcatgory)){
			$subcatgoryCond=" AND s.SubcategoryID='".$subcatgory."' ";
		} else {
			$subcatgoryCond='';
		}
		if(!empty($QuestionID)){
			$QuestionIDCond=" AND q.QuestionID='".$QuestionID."' ";
		} else {
			$QuestionIDCond='';
		}
	  	$sql="select a.SurveyStatus,ad.Answer, survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
LEFT join answer a on(survey.SurveyID=a.SurveyID)
LEFT join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1')
WHERE a.AnswerID='".$ansId."'".$CatCond.$subcatgoryCond.$QuestionIDCond." 
ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC ";
	    $result = $this->db->query($sql, NULL);
	    $data['survey']=array();
	    foreach ($result->result() as $key => $value) {
	    	if(!array_key_exists($value->SurveyID, $data['survey'])){
	    		$data['survey'][$value->SurveyID]=array(
	    			'SurveyID'=>$value->SurveyID,
			    	'SurveyName'=>$value->SurveyName,
			    	'SurveyDesc'=>$value->SurveyDesc,
			    	'category'=>array(),
	    		);
	    	}
	    	if(!array_key_exists($value->CategoryID, $data['survey'][$value->SurveyID]['category'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]=array(
	    			'CategoryID'=>$value->CategoryID,
	    			'CategoryName'=>$value->CategoryName,
	    			'CategoryCode'=>$value->CategoryCode,
	    			'subcategory'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->SubcategoryID, $data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]=array(
	    			'SubcategoryID'=>$value->SubcategoryID,
	    			'SubCategoryCode'=>$value->SubCategoryCode,
	    			'SubCategoryName'=>$value->SubCategoryName,
	    			'questions'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->QuestionID, $data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'][$value->QuestionID]=array(
	    			'QuestionID'=>$value->QuestionID,
	    			'Reference'=>$value->Reference,
	    			'Statement'=>$value->Statement,
	    			'Checkpoint'=>$value->Checkpoint,
	    			'Assesment'=>$value->Assesment,
	    			'Verification'=>$value->Verification,
	    			'Remarks'=>$value->Remarks,
	    			'Answer'=>$value->Answer,
	    		);
	    	}	    	
	    }
	    $sqlTot="select count(q.QuestionID) ques,(case when (ad.AnswerDetailID IS NULL) 
 THEN
      'not' 
 ELSE
      'yes' 
 END)
 as checkdata
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
LEFT join answer a on(survey.SurveyID=a.SurveyID)
LEFT join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1')
WHERE a.AnswerID='".$ansId."'
GROUP by ad.AnswerID
";
	    $resultTot = $this->db->query($sqlTot, NULL);
	    $resultTotData=$resultTot->result_array();
	    $data['tot']=array('yes'=>0,'not'=>'0');
	    $totquestions=0;
	    foreach ($resultTotData as $key => $value) {
	    	$data['tot'][$value['checkdata']]=$value['ques'];
	    	$totquestions+=$value['ques'];
	    }
	    $data['tot']['allques']=$totquestions;
	    $response['code']='10';
	    $response['msg']=$this->config->item('errCodes')[10];
	    $response['data']=$data;
		return $response;
		
	*/}
	function answerview($ansId,$catgory,$subcategory,$question){
		$response=array(); 		
		if(!empty($ansId)){
			$categoryData=array();$data=array();
			$survyCond=" AND a.AnswerID='".$ansId."' ";
		  	$sqlSurvey="select survey.SurveyID,survey.SurveyName,survey.SurveyDesc
	from survey 
	INNER join answer a on(survey.SurveyID=a.SurveyID)
	WHERE 1 ".$survyCond."
	ORDER by survey.SurveyName ASC";
		    $resultSurvey = $this->db->query($sqlSurvey, NULL);
		    foreach ($resultSurvey->result() as $key => $value) {
		    	$surveyData=array(
		    		'SurveyID'=>$value->SurveyID,
		    		'SurveyName'=>$value->SurveyName,
		    		'SurveyDesc'=>$value->SurveyDesc
		    	);
				if(!empty($catgory)){
					$CatCond=" AND c.CategoryID='".$catgory."' ";
				} else {
					$CatCond=" AND survey.SurveyID='".$value->SurveyID."' ";
				}
			  	$sqlCat="select c.CategoryID,c.CategoryName,c.CategoryCode,c.Icon
		from category c
		INNER JOIN survey on(c.SurveyID=survey.SurveyID)
		INNER join answer a on(survey.SurveyID=a.SurveyID AND c.format=a.format)
		WHERE 1  ".$survyCond.$CatCond." 
		ORDER by survey.SurveyName,c.CategoryCode ASC";
			    $resultCat = $this->db->query($sqlCat, NULL);
			    foreach ($resultCat->result() as $keyCat => $valueCat) {
			    	$SubcategoryData=array();
			    	$categoryDataIn=array(
		    			'CategoryID'=>$valueCat->CategoryID,
		    			'CategoryName'=>$valueCat->CategoryName,
		    			'CategoryCode'=>$valueCat->CategoryCode,
		    			'Icon'=>$valueCat->Icon,		    		
			    	);
					if(!empty($subcategory)){
						$SubCatCond=" AND s.SubcategoryID='".$subcategory."' ";
					} else {
						$SubCatCond=" AND c.CategoryID='".$valueCat->CategoryID."' ";
					}
				  	$sqlSubCat="select s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName
						from subcategory s
						INNER join category c on (s.CategoryID=c.CategoryID)
						INNER JOIN survey on(c.SurveyID=survey.SurveyID)
						INNER join answer a on(survey.SurveyID=a.SurveyID AND c.format=a.format)
						WHERE 1 ".$survyCond.$CatCond.$SubCatCond." 
						ORDER by survey.SurveyName,c.CategoryCode,s.SubcategoryID ASC";
				    $resultSubCat = $this->db->query($sqlSubCat, NULL);
				    foreach ($resultSubCat->result() as $keySubCat => $valueSubCat) {
				    	$questionData=array();
				    	$subCategoryDataIn=array(
			    			'SubcategoryID'=>$valueSubCat->SubcategoryID,
			    			'SubCategoryCode'=>$valueSubCat->SubCategoryCode,
			    			'SubCategoryName'=>$valueSubCat->SubCategoryName		    		
				    	);
						if(!empty($question)){
							$QuesCond=" AND q.QuestionID='".$question."' ";
						} else {
							$QuesCond=" AND s.SubcategoryID='".$valueSubCat->SubcategoryID."' ";
						}
					  	$sqlQues="select a.SurveyStatus,ad.Answer,survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,c.Icon,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*
							from question q 
							INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
							INNER join category c on (s.CategoryID=c.CategoryID)
							INNER JOIN survey on(c.SurveyID=survey.SurveyID)
							INNER join answer a on(survey.SurveyID=a.SurveyID AND c.format=a.format)
							LEFT join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1')
							WHERE 1 ".$survyCond.$CatCond.$SubCatCond.$QuesCond."
							ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC";
					    $resultQues = $this->db->query($sqlQues, NULL);
					    foreach ($resultQues->result() as $keyQues => $valueQues) {
				    		if(!empty($valueQues->Reference)){
			                    $Reference=$valueQues->Reference;
			                    $parentID=$valueQues->QuestionID;
			                }
					    	$quesDataIn=array(
				    			'QuestionID'=>$valueQues->QuestionID,
				    			'parentID'=>$parentID,
				    			'Reference'=>$Reference,
				    			'Statement'=>$valueQues->Statement,
				    			'Checkpoint'=>$valueQues->Checkpoint,
				    			'Assesment'=>$valueQues->Assesment,
				    			'Verification'=>$valueQues->Verification,
				    			'Remarks'=>$valueQues->Remarks,
	    						'Answer'=>$valueQues->Answer,
					    	);
					    	$questionData[]=$quesDataIn;
					    }
					    $subCategoryDataIn['question']=$questionData;
				    	$SubcategoryData[]=$subCategoryDataIn;				    	
				    }
				    $categoryDataIn['Subcategory']=$SubcategoryData;
			    	$categoryData[]=$categoryDataIn;
			    }
			    $surveyData['catgory']=$categoryData;
		    	$data=$surveyData;
		    }			
		} else {
			$data=array();
		}







	    $sqlTot="select count(q.QuestionID) ques,(case when (ad.AnswerDetailID IS NULL) 
 THEN
      'not' 
 ELSE
      'yes' 
 END)
 as checkdata
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
LEFT join answer a on(survey.SurveyID=a.SurveyID AND a.format=c.format)
LEFT join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1')
WHERE a.AnswerID='".$ansId."' 
GROUP by ad.AnswerID
";
	    $resultTot = $this->db->query($sqlTot, NULL);
	    $resultTotData=$resultTot->result_array();
	    $data['tot']=array('yes'=>0,'not'=>'0');
	    $totquestions=0;
	    foreach ($resultTotData as $key => $value) {
	    	$data['tot'][$value['checkdata']]=$value['ques'];
	    	$totquestions+=$value['ques'];
	    }
	    $data['tot']['allques']=$totquestions;
	    $response['code']='10';
	    $response['msg']=$this->config->item('errCodes')[10];
	    $response['data']=$data;
		return $response;
		
	}
	function surveySampleDownload($SurveyType){
		$response=array();
	  	$sql="select survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
WHERE survey.SurveyID='".$SurveyType."' AND q.IsActive='1'
ORDER by c.CategoryID ASC,s.SubcategoryID ASC,q.QuestionID,q.ParentID ASC,q.Serial ASC ";
	    $result = $this->db->query($sql, NULL);
	    $data['survey']=array();
	    foreach ($result->result() as $key => $value) {
	    	if(!array_key_exists($value->SurveyID, $data['survey'])){
	    		$data['survey'][$value->SurveyID]=array(
			    	'SurveyName'=>$value->SurveyName,
			    	'SurveyDesc'=>$value->SurveyDesc,
			    	'category'=>array(),
	    		);
	    	}
	    	if(!array_key_exists($value->CategoryID, $data['survey'][$value->SurveyID]['category'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]=array(
	    			'CategoryName'=>$value->CategoryName,
	    			'CategoryCode'=>$value->CategoryCode,
	    			'subcategory'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->SubcategoryID, $data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]=array(
	    			'SubCategoryCode'=>$value->SubCategoryCode,
	    			'SubCategoryName'=>$value->SubCategoryName,
	    			'questions'=>array()
	    		);
	    	}
	    	if(!array_key_exists($value->QuestionID, $data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'])){
	    		$data['survey'][$value->SurveyID]['category'][$value->CategoryID]['subcategory'][$value->SubcategoryID]['questions'][$value->QuestionID]=array(
	    			'Reference'=>$value->Reference,
	    			'Statement'=>$value->Statement,
	    			'Checkpoint'=>$value->Checkpoint,
	    			'Assesment'=>$value->Assesment,
	    			'Verification'=>$value->Verification,
	    			'Remarks'=>$value->Remarks,
	    		);
	    	}	    	
	    }
		return $data;

	}
	function quesTot($survey,$checklist_format='A'){
	    $this->db->select('q.QuestionID');
	    $this->db->from('question q');
	    $this->db->join('subcategory s', 'q.SubcategoryID = s.SubcategoryID', 'inner'); 
	    $this->db->join('category c', 's.CategoryID = c.CategoryID', 'inner'); 
	    $this->db->join('survey', 'c.SurveyID = survey.SurveyID', 'inner'); 
	    $this->db->where('survey.SurveyID',$survey);
	    $this->db->where('q.IsActive','1');
	    $this->db->where('q.format',$checklist_format);
	    $result = $this->db->get();
	    //echo $this->db->last_query();
	    return $result ->num_rows();
	}
	function checklistsave($ansID,$type,$ques,$ans){
		try {
		    $this->db->select('ad.AnswerDetailID');
		    $this->db->from('answer');
		    $this->db->join('answerdetail ad', 'answer.AnswerID = ad.AnswerID AND ad.IsActive="1"', 'inner');
		    $this->db->where('answer.AnswerID',$ansID);
		    $this->db->where('ad.QuestionID',$ques);
		    $result = $this->db->get();
			if($result ->num_rows()>0){
				foreach ($result->result() as $key => $value) {
					$updateAns=array(
						'IsActive'=>'0',
						'ModifiedOn'=>date('Y-m-d H:i:s'),
						'ModifiedBy'=>$this->session->userdata('UserID'),
					);
					$this->db->where('AnswerDetailID', $value->AnswerDetailID);
					$this->db->update('answerdetail', $updateAns);				
				}
			}
			if($type=='save'){
	    		$InsertAns=array(
	    			'AnswerID'=>$ansID,
	    			'QuestionID'=>$ques,
	    			'Answer'=>$ans,
	    			'IsActive'=>'1',
	    			'CreatedOn'=>date('Y-m-d H:i:s'),
	    			'CreatedBy'=>$this->session->userdata('UserID'),
	    		);			
				$this->db->insert('answerdetail', $InsertAns);
			}
            $response['code'] = '0';
            $response['msg'] = $this->config->item('errCodes')[0];
		} catch (Exception $e) {
            $response['code'] = '10';
            $response['msg'] = $e;
		}
	    $sqlTot="select count(q.QuestionID) ques,(case when (ad.AnswerDetailID IS NULL) 
 THEN
      'not' 
 ELSE
      'yes' 
 END)
 as checkdata
from question q 
INNER join subcategory s on(q.SubcategoryID=s.SubcategoryID)
INNER join category c on (s.CategoryID=c.CategoryID)
INNER JOIN survey on(c.SurveyID=survey.SurveyID)
LEFT join answer a on(survey.SurveyID=a.SurveyID)
LEFT join answerdetail ad on(a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive='1')
WHERE a.AnswerID='".$ansID."'
GROUP by ad.AnswerID
";
	    $resultTot = $this->db->query($sqlTot, NULL);
	    $resultTotData=$resultTot->result_array();
	    $data['tot']=array('yes'=>0,'not'=>'0');
	    $totquestions=0;
	    foreach ($resultTotData as $key => $value) {
	    	$data['tot'][$value['checkdata']]=$value['ques'];
	    	$totquestions+=$value['ques'];
	    }
	    $data['tot']['allques']=$totquestions;
	    $response['questions']=$data;
		return $response;

	}
	function checkEndlineEntry($facilityUser){
	    $this->db->select('facilities.AssesmentCheck,users.UserID');
	    $this->db->from('users');
	    $this->db->join('userrole', 'users.UserID=userrole.UserID', 'inner');
	    $this->db->join('role', 'userrole.RoleID=role.RoleID', 'inner');
	    $this->db->join('usermapping', 'userrole.UserID=usermapping.UserID AND usermapping.FacilityID>0', 'inner');
	    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
	    $this->db->where('role.RoleName','Facility');
	    $this->db->where('users.UserID',$facilityUser);
	    $query = $this->db->get(); 
		if($query ->num_rows()==0){
			return 0;
		} else {
			$data=$query->row();
			return $data->AssesmentCheck;
		}
	}
	function asessmentDataApp($facility){
	    $this->db->select('answer.AnswerID,answer.Sequence,answer.SurveyID,answer.AssessmentDate,answer.SurveyStatus,survey.SurveyName,survey.SurveyID');
	    $this->db->from('answer');
	    $this->db->join('survey', 'answer.SurveyID = survey.SurveyID', 'inner');
	    $this->db->where('answer.UserID',$facility);		
	    $this->db->order_by('answer.AnswerID', 'DESC');
	    $query = $this->db->get();

		$surveyFormLevel=$this->config->item('assesmentSequence');
		$dataget=array();
		foreach ($query->result() as $key => $value) {
		    $subdata=array();
		    $subdata['AnswerID'] = $value->AnswerID;
		    $subdata['Sequence'] = $value->Sequence;
		    $subdata['SurveyName'] = $value->SurveyName;
		    $subdata['AssessmentDate'] = empty($value->AssessmentDate)?'':date('d-m-Y',strtotime($value->AssessmentDate));
		    $subdata['SurveyStatus'] = $value->SurveyStatus?'Completed':'Incomplete';
		    $dataget[]=$subdata;
		}
		$respone=array();
		$respone['totalData']=$query -> num_rows();
		$respone['data']=$dataget;
		$respone['code']='10';
		$respone['msg']='data get';
		return $respone;
	}
	function monthlyDataApp($facility,$data=array()){
        $this->db->select('monthly.MonthlyID,monthly.ReportMonth,monthly.CollectionDate,monthly.MonthlyStatus,monthly.CreatedOn');
        $this->db->from('monthly');
        $this->db->where('monthly.UserID', $facility);
        if(!empty($data['year']) && empty($data['month'])){ $this->db->where('YEAR(monthly.ReportMonth)', $data['year']); }
        if(empty($data['year']) && !empty($data['month'])){ $this->db->where('MONTH(monthly.ReportMonth)', $data['month']); }
        if(!empty($data['year']) && !empty($data['month'])){ $this->db->where('monthly.ReportMonth', $data['year'].'-'.$data['month'].'-01'); }
        $this->db->order_by('MonthlyID', 'DESC');
        $query = $this->db->get();


        $dataget = array();
        foreach ($query->result() as $key => $value) {
            $subdata = array();
            $subdata['MonthlyID'] = $value->MonthlyID;
            $subdata['ReportMonth'] = date('F Y', strtotime($value->ReportMonth));
            $subdata['CollectionDate'] = convert_date_show($value->CollectionDate);
            $subdata['MonthlyStatus'] = $value->MonthlyStatus ? 'Completed' : 'Incomplete';
            $subdata['CreatedOn'] = convert_date_show($value->CreatedOn);
            $dataget[] = $subdata;
        }
		$respone=array();
		$respone['totalData']=$query -> num_rows();
		$respone['data']=$dataget;
		$respone['code']='10';
		$respone['msg']='data get';
		return $respone;
	}
	function assesmentDataEdit($assesmentID){
	    $this->db->select('facilities.StateID,states.StateName,facilities.DistrictID,district.DistrictName,facilities.FacilityName,DATE_FORMAT(answer.AssessmentDate,"%d-%m-%Y") as AssessmentDate,answer.AssessorsName1,answer.AssessorsName2,answer.AssesseesName1,answer.AssesseesName2,answer.AssessmentType,DATE_FORMAT(answer.start_date,"%d-%m-%Y") as start_date,answer.Sequence,answer.SurveyID,answer.UserID');
	    $this->db->from('answer');
	    $this->db->join('usermapping', 'answer.UserID=usermapping.UserID AND usermapping.FacilityID >0', 'left');
	    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'left');
	    $this->db->join('states', 'facilities.StateID=states.StateID', 'left');
	    $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'left');
	    $this->db->where('answer.AnswerID',$assesmentID);
	    $this->db->order_by('answer.AnswerID', 'DESC');
	    $this->db->limit('1');
	    $result = $this->db->get();
		$data=$result->row_array();
	    $response['code']=$result ->num_rows();
	    $response['msg']=$result ->num_rows().' data get';
	    $response['data']=$data;
		return $response;
	}
	function saveOsce($userID,$osce,$osceID){
		try {
			if($osceID>0){
				$this->db->where('OsceID', $osceID);
				if ($this->db->update('osce', $osce)=== FALSE){
				    $response['code']='11';
				    $response['msg']=$this->config->item('errCodes')[11];
				    $response['data']=$osceID;
				} else {
				    $response['code']='0';
				    $response['msg']=$this->config->item('errCodes')[0];
				    $response['data']=$osceID;					
				}
			} else {
				if($this->db->insert('osce', $osce)){
				    $response['code']='0';
				    $response['msg']=$this->config->item('errCodes')[0];
				    $response['data']=$this->db->insert_id();
				} else {
				    $response['code']='11';
				    $response['msg']=$this->config->item('errCodes')[11];
				    $response['data']='0';
				}				
			}

		} catch(Exception $e) {
		    $response['code']='14';
		    $response['msg']=$this->config->item('errCodes')[14];
		    $response['data']='0';
		}
		return $response;
	}
	function oscedata($userID){
        $this->db->select('osce.OsceID,osce.participant,osce.designation,osce.dakshata,osce.daksh,osce.others,osce.remarks,osce.score1,osce.score2,osce.score3,,osce.score4');
        $this->db->from('osce');
        $this->db->where('osce.UserID', $userID);
        $this->db->where('osce.IsActive', '1');
        $this->db->order_by('OsceID', 'DESC');
        $query = $this->db->get();

        $dataget = array();
        foreach ($query->result() as $key => $value) {
            $subdata = array();
            $subdata['OsceID'] = $value->OsceID;
            $subdata['participant'] = $value->participant;
            $subdata['designation'] = $this->config->item('osceDesig')[$value->designation];
            $subdata['dakshata'] = $value->dakshata=='1'?'Yes':'No';
            $subdata['daksh'] = $value->daksh=='1'?'Yes':'No';
            $subdata['others'] = $value->others=='1'?'Yes':'No';
            $subdata['trained'] = ($value->dakshata=='1' || $value->daksh=='1')?'Yes':'No';
            $subdata['remarks'] = $value->remarks;
            $subdata['score1'] = $value->score1;
            $subdata['score2'] = $value->score2;
            $subdata['score3'] = $value->score3;
            $subdata['score4'] = $value->score4;
            $subdata['scoreTot'] = $value->score1+$value->score2+$value->score3+$value->score4;
            $subdata['scoreRes'] = ($value->score1>=16 && $value->score2>=16 && $value->score3>=16 && $value->score4>=16)?'1':'0';
            $subdata['scorePer'] = (int)((($value->score1+$value->score2+$value->score3+$value->score4)*100)/80);
            $dataget[] = $subdata;
        }
		/*$respone=array();
		$respone['totalData']=$query -> num_rows();
		$respone['data']=$dataget;
		$respone['code']='10';
		$respone['msg']='data get';*/
		return $dataget;
	}
	function oscedataForm($OsceID){
        $this->db->select('osce.OsceID,osce.participant,osce.designation,osce.dakshata,osce.daksh,osce.others,osce.remarks,osce.score1,osce.score2,osce.score3,,osce.score4');
        $this->db->from('osce');
        $this->db->where('osce.OsceID', $OsceID);
        $this->db->where('osce.userID', $this->session->userdata('UserID'));
        $this->db->limit('1');
        $query = $this->db->get();
        $value=$query->row();

        $subdata = array();
        $subdata['OsceID'] = $value->OsceID;
        $subdata['participant'] = $value->participant;
        $subdata['designation'] = $value->designation;
        $subdata['dakshata'] = $value->dakshata=='1'?'Yes':'No';
        $subdata['daksh'] = $value->daksh=='1'?'Yes':'No';
        $subdata['others'] = $value->others=='1'?'Yes':'No';
        $subdata['trained'] = ($value->dakshata=='1' || $value->daksh=='1')?'Yes':'No';
        $subdata['remarks'] = $value->remarks;
        $subdata['score1'] = $value->score1;
        $subdata['score2'] = $value->score2;
        $subdata['score3'] = $value->score3;
        $subdata['score4'] = $value->score4;
        $subdata['scoreTot'] = $value->score1+$value->score2+$value->score3+$value->score4;
        $subdata['scoreRes'] = ($value->score1>=16 && $value->score2>=16 && $value->score3>=16 && $value->score4>=16)?'1':'0';
        $subdata['scorePer'] = (int)((($value->score1+$value->score2+$value->score3+$value->score4)*100)/80);

		return $subdata;		
	}
	function saveClientScore($data,$ansID){
		$this->db->where('AnswerID', $ansID);
		if ($this->db->update('answer', $data) === FALSE){
		    $response['code']='11';
		    $response['msg']=$this->config->item('errCodes')[11];
		} else {
		    $response['code']='0';
		    $response['msg']=$this->config->item('errCodes')[0];
		}
		return $response;
	}
	function getCategory($surveyID=''){
        $this->db->select('c.CategoryCode,concat(c.CategoryName," ",if(SurveyID=1, "LR", "OT") ) as CategoryName');
        $this->db->from('category c');
        $this->db->where('c.IsActive', 1);
        $this->db->where('c.format', 'A');
        if(!empty($surveyID)){
        	$this->db->where_in('c.SurveyID', $surveyID);
        }
        $this->db->order_by('c.CategoryCode', 'ASC');
        $query = $this->db->get();
        $data = array();
        $data['code']=$query->num_rows();
        $data['msg']=$query->num_rows().' retrieved';
        $data['cat']=$query->result_array();
        return $data;
	}
	function getGapOptions($ansID,$format){
        $this->db->select('c.CategoryCode,c.CategoryName');
        $this->db->from('category c');
        $this->db->join('survey s', 's.SurveyID=c.SurveyID', 'inner');
        $this->db->join('answer a', 'a.SurveyID=s.SurveyID', 'inner');
        $this->db->where('c.IsActive', 1);
        $this->db->where('c.format', $format);
        $this->db->where('a.AnswerID', $ansID);
        $this->db->order_by('c.CategoryCode', 'ASC');
        $query = $this->db->get();

        $data = array();
        $data['cat']=$query->result_array();
        return $data;
	}
	function assessment_summary($ansID,$format){
        $this->db->select('c.CategoryCode,c.CategoryName,ad.Answer,SUM(ad.IsActive) as cnt');
        $this->db->from('answer a');
        $this->db->join('answerdetail ad', 'a.AnswerID=ad.AnswerID AND ad.IsActive=1', 'inner');
        $this->db->join('question q', 'ad.QuestionID=q.QuestionID', 'inner');
        $this->db->join('subcategory sb', 'sb.SubcategoryID=q.SubcategoryID', 'inner');
        $this->db->join('category c', 'c.CategoryID=sb.CategoryID', 'inner');
        $this->db->where('a.AnswerID', $ansID);
        $this->db->group_by(array("c.CategoryID", "ad.Answer"));
        $this->db->order_by('c.CategoryCode', 'ASC');
        $query = $this->db->get();

        $dataget = array();
        foreach ($query->result_array() as $key => $value) {
        	if(!isset($dataget['cat'][$value['CategoryCode']]) ){
        		$dataget['cat'][$value['CategoryCode']]=array(
        			'categoryName'=>$value['CategoryName'],
        			'data'=>array(
        				'0'=>0,
        				'1'=>0,
        				'2'=>0
        			)
        		);
        	}
        	$dataget['cat'][$value['CategoryCode']]['data'][$value['Answer']]=$value['cnt'];
        }
        return $dataget;
	}
	function getgapdata_old($dataget){
		$data=array('draw'=>0,'totalData'=>0,'totalFilter'=>0,'data'=>array());
		$col =array(
		    0   =>  'CategoryCode',
		    1   =>  'SubCategoryCode',
		    2   =>  'Reference',
		    4   =>  'Checkpoint',
		    5   =>  'Answer',
		);

	  	$this->db->select('a.AnswerID');
	    $this->db->from('answer a');
	    $this->db->join('answerdetail ad', 'a.AnswerID=ad.AnswerID AND ad.IsActive=1', 'inner');
		$this->db->join('question q','q.QuestionID=ad.QuestionID');
		$this->db->join('subcategory sb', 'sb.SubcategoryID=q.SubcategoryID', 'inner');
		$this->db->join('category c','c.CategoryID=sb.CategoryID', 'inner');
	    $this->db->where('a.AnswerID',encryptor($dataget['search_answer'],'decrypt'));
	    $this->db->where('a.format',encryptor($dataget['search_format'],'decrypt'));
		if(!empty($dataget['search_cat'])){			
			$where = '(';
			$where1=array();
			foreach ($dataget['search_cat'] as $key => $value) {
				if($value!=''){
					$where1[]=' c.CategoryCode="'.$value.'" ';
				}				
			}
			if(!empty($where1)){
				$cond=implode(' or', $where1);
				$where.=$cond;
				$where.=')';
	       		$this->db->where($where);
			}
		}
		if(!empty($dataget['search_score'])){
			$where = '(';
			$where1=array();
			foreach ($dataget['search_score'] as $key => $value) {
				if($value!=''){
					$where1[]=' ad.Answer="'.$value.'" ';
				}				
			}
			if(!empty($where1)){
				$cond=implode(' or', $where1);
				$where.=$cond;
				$where.=')';
	       		$this->db->where($where);
			}
			
		}
        if(!empty($dataget['search']['value'])){
            $searchString=trim($dataget['search']['value']);
            $this->db->where("(ad.Answer like '%".$searchString."%' OR q.Reference like '%".$searchString."%' OR q.Checkpoint like '%".$searchString."%' OR c.CategoryName like '%".$searchString."%' OR sb.SubCategoryCode like '%".$searchString."%' )", NULL, FALSE);
        }
	    $queryTot = $this->db->get();

	  	$this->db->select('ad.Answer,q.Reference,q.Checkpoint,c.CategoryName,sb.SubCategoryCode');
	    $this->db->from('answer a');
	    $this->db->join('answerdetail ad', 'a.AnswerID=ad.AnswerID AND ad.IsActive=1', 'inner');
		$this->db->join('question q','q.QuestionID=ad.QuestionID');
		$this->db->join('subcategory sb', 'sb.SubcategoryID=q.SubcategoryID', 'inner');
		$this->db->join('category c','c.CategoryID=sb.CategoryID', 'inner');
	    $this->db->where('a.AnswerID',encryptor($dataget['search_answer'],'decrypt'));
	    $this->db->where('a.format',encryptor($dataget['search_format'],'decrypt'));
		if(!empty($dataget['search_cat'])){			
			$where = '(';
			$where1=array();
			foreach ($dataget['search_cat'] as $key => $value) {
				if($value!=''){
					$where1[]=' c.CategoryCode="'.$value.'" ';
				}				
			}
			if(!empty($where1)){
				$cond=implode(' or', $where1);
				$where.=$cond;
				$where.=')';
	       		$this->db->where($where);
			}
		}
		if(!empty($dataget['search_score'])){
			$where = '(';
			$where1=array();
			foreach ($dataget['search_score'] as $key => $value) {
				if($value!=''){
					$where1[]=' ad.Answer="'.$value.'" ';
				}				
			}
			if(!empty($where1)){
				$cond=implode(' or', $where1);
				$where.=$cond;
				$where.=')';
	       		$this->db->where($where);
			}
			
		}
        if(!empty($dataget['search']['value'])){
            $searchString=trim($dataget['search']['value']);
            $this->db->where("(ad.Answer like '%".$searchString."%' OR q.Reference like '%".$searchString."%' OR q.Checkpoint like '%".$searchString."%' OR c.CategoryName like '%".$searchString."%' OR sb.SubCategoryCode like '%".$searchString."%' )", NULL, FALSE);
        }
	    $this->db->order_by($col[$dataget['order'][0]['column']], $dataget['order'][0]['dir']);
	    $this->db->limit($this->input->post('length'),$this->input->post('start'));
	    $query = $this->db->get();


		$data['draw']=$this->input->post('draw');
		$data['totalData']=$queryTot -> num_rows();
		$data['totalFilter']=$queryTot -> num_rows();
		$surveyFormLevel=$this->config->item('assesmentSequence');
		$dataget=array();
		foreach ($query->result() as $key => $value) {
		    $subdata=array();
		    $subdata[]=$value->CategoryName;
		    $subdata[]=$value->SubCategoryCode;
		    $subdata[]=$value->Reference;
		    $subdata[]=$value->Checkpoint;
		    $subdata[]=$value->Answer;
		    $dataget[]=$subdata;
		}
		$data['data']=$dataget;

		return $data;

	}
	function getgapdata($dataget){
		$data=array('draw'=>0,'totalData'=>0,'totalFilter'=>0,'data'=>array());
		$col =array(
		    0   =>  'CategoryCode',
		    1   =>  'SubCategoryCode',
		    2   =>  'Reference',
		    4   =>  'Checkpoint',
		    5   =>  'Answer',
		);

	  	$this->db->select('a.AnswerID');
	    $this->db->from('question q');
	    $this->db->join('subcategory s', 'q.SubcategoryID=s.SubcategoryID', 'inner');
		$this->db->join('category c','s.CategoryID=c.CategoryID','inner');
		$this->db->join('survey', 'c.SurveyID=survey.SurveyID', 'inner');
		$this->db->join('answer a','survey.SurveyID=a.SurveyID AND c.format=a.format', 'inner');
		$this->db->join('answerdetail ad','a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive=1', 'inner');
	    $this->db->where('a.AnswerID',encryptor($dataget['search_answer'],'decrypt'));
	    $this->db->where('a.format',encryptor($dataget['search_format'],'decrypt'));
		if(!empty($dataget['search_cat'])){			
			$where = '(';
			$where1=array();
			foreach ($dataget['search_cat'] as $key => $value) {
				if($value!=''){
					$where1[]=' c.CategoryCode="'.$value.'" ';
				}				
			}
			if(!empty($where1)){
				$cond=implode(' or', $where1);
				$where.=$cond;
				$where.=')';
	       		$this->db->where($where);
			}
		}
		if(!empty($dataget['search_score'])){
			$where = '(';
			$where1=array();
			foreach ($dataget['search_score'] as $key => $value) {
				if($value!=''){
					$where1[]=' ad.Answer="'.$value.'" ';
				}				
			}
			if(!empty($where1)){
				$cond=implode(' or', $where1);
				$where.=$cond;
				$where.=')';
	       		$this->db->where($where);
			}
			
		}
        if(!empty($dataget['search']['value'])){
            $searchString=trim($dataget['search']['value']);
            $this->db->where("(ad.Answer like '%".$searchString."%' OR q.Reference like '%".$searchString."%' OR q.Checkpoint like '%".$searchString."%' OR c.CategoryName like '%".$searchString."%' OR s.SubCategoryCode like '%".$searchString."%' )", NULL, FALSE);
        }
	    $queryTot = $this->db->get();
//echo $this->db->last_query();

	  	$this->db->select('a.SurveyStatus,ad.Answer,survey.SurveyID,survey.SurveyName,survey.SurveyDesc,c.CategoryID,c.CategoryName,c.CategoryCode,c.Icon,s.SubcategoryID,s.SubCategoryCode,s.SubCategoryName,q.*');
	    $this->db->from('question q');
	    $this->db->join('subcategory s', 'q.SubcategoryID=s.SubcategoryID', 'inner');
		$this->db->join('category c','s.CategoryID=c.CategoryID','inner');
		$this->db->join('survey', 'c.SurveyID=survey.SurveyID', 'inner');
		$this->db->join('answer a','survey.SurveyID=a.SurveyID AND c.format=a.format', 'inner');
		$this->db->join('answerdetail ad','a.AnswerID=ad.AnswerID AND ad.QuestionID=q.QuestionID AND ad.IsActive=1', 'inner');
	    $this->db->where('a.AnswerID',encryptor($dataget['search_answer'],'decrypt'));
	    $this->db->where('a.format',encryptor($dataget['search_format'],'decrypt'));
		if(!empty($dataget['search_cat'])){			
			$where = '(';
			$where1=array();
			foreach ($dataget['search_cat'] as $key => $value) {
				if($value!=''){
					$where1[]=' c.CategoryCode="'.$value.'" ';
				}				
			}
			if(!empty($where1)){
				$cond=implode(' or', $where1);
				$where.=$cond;
				$where.=')';
	       		$this->db->where($where);
			}
		}
		if(!empty($dataget['search_score'])){
			$where = '(';
			$where1=array();
			foreach ($dataget['search_score'] as $key => $value) {
				if($value!=''){
					$where1[]=' ad.Answer="'.$value.'" ';
				}				
			}
			if(!empty($where1)){
				$cond=implode(' or', $where1);
				$where.=$cond;
				$where.=')';
	       		$this->db->where($where);
			}
			
		}
        if(!empty($dataget['search']['value'])){
            $searchString=trim($dataget['search']['value']);
            $this->db->where("(ad.Answer like '%".$searchString."%' OR q.Reference like '%".$searchString."%' OR q.Checkpoint like '%".$searchString."%' OR c.CategoryName like '%".$searchString."%' OR s.SubCategoryCode like '%".$searchString."%' )", NULL, FALSE);
        }
	    $this->db->order_by($col[$dataget['order'][0]['column']], $dataget['order'][0]['dir']);
	    if($dataget['length']>0){
	    	$this->db->limit($this->input->post('length'),$this->input->post('start'));	    	
	    }
	    $query = $this->db->get();


		$data['draw']=$this->input->post('draw');
		$data['totalData']=$queryTot -> num_rows();
		$data['totalFilter']=$queryTot -> num_rows();
		$surveyFormLevel=$this->config->item('assesmentSequence');
		$dataget=array();
		foreach ($query->result() as $key => $value) {
    		if(!empty($value->Reference)){
                $Reference=$value->Reference;
                $parentID=$value->QuestionID;
            }
		    $subdata=array();
		    $subdata[]=$value->CategoryName;
		    $subdata[]=$value->SubCategoryCode;
		    $subdata[]=@$Reference;
		    $subdata[]=$value->Checkpoint;
		    $subdata[]=$value->Answer;
		    $dataget[]=$subdata;
		}
		$data['data']=$dataget;

		return $data;

	}
	

}