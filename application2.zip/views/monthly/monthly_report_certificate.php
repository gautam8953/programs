<style>

    table thead tr th {background: #337ab7;
                        border: 1px solid #024f92 !important;
                        color: #ffffff;}

</style>

<div class="page-title">
    <div class="title_left">
        <h3>Report</h3>
    </div>
 
</div>


<div class="main-content"> 
    <div class="container">

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel" >
                    <div class="x_title">
                        <h2>Monthly Report</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
 
                        <table id="datatable" class="table table-striped table-bordered my-table-width" width="100%">
                            <thead>
                                <tr>
                                    <th style="min-width: 80px;" data-toggle="tooltip" title="Month">Month</th>
                                    
                                    <th title="Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores">Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores</th>

                                    <th title="Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots">Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots</th>
                                    
                                    <th title="Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI">Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI</th>
                                    
                                    <th title="Percentage of deliveries are attended by a birth companion">Percentage of deliveries are attended by a birth companion</th>
                                    
                                    <th title="Percentage deliveries are conducted using safe birth checklist in Labour Room">Percentage deliveries are conducted using safe birth checklist in Labour Room </th>
                                    
                                    <th title="Percentage of deliveries are conducted using  Safe Surgery checklist in Maternity OT">Percentage of deliveries are conducted using  Safe Surgery checklist in Maternity OT</th>
                                    
                                    <th title="Percentage of deliveries for which Partograph is generated using real-time information in at least">Percentage of deliveries for which Partograph is generated using real-time information in at least </th>
                                    
                                    <th title="Percentage breastfeeding within 1 hour">Percentage breastfeeding within 1 hour </th>
                                    
                                    <th title="Neonatal asphyxia rate in Inborn Babies"> Neonatal asphyxia rate in Inborn Babies </th>
                                    
                                    <th title="Neonatal sepsis rate in-born babies"> Neonatal sepsis rate in-born babies </th>
                                    
                                    <th title="Surgical Site infection Rate in Maternity OT"> Surgical Site infection Rate in Maternity OT </th>
                                    
                                    <th title="Antenatal corticosteroid administration rate in case in preterm labour">Antenatal corticosteroid administration rate in case in preterm labour</th>
                                    
                                    <th title="Pre-eclampsia, eclampsia & PIH related mortality">Pre-eclampsia, eclampsia & PIH related mortality</th>
                                    
                                    <th title="APH/PPH related mortality"> APH/PPH related mortality </th>
                                    
                                    <th title="Facility Labour Room is reorganized as labour room standardization guidelines">Facility Labour Room is reorganized as labour room standardization guidelines</th>
                                    
                                    <th title="Facility Labour room has staffing as per defined norms">Facility Labour room has staffing as per defined norms </th>
                                    
                                    <th title="Percentage of Women, administered Oxytocin, immediately after birth.">Percentage of Women, administered Oxytocin, immediately after birth.</th>
                                    
                                    <th style="min-width: 100px;" title="OSCE Score">OSCE Score </th>
                                    
                                    <th title="Facility conducts referral audit on Monthly basis">Facility conducts referral audit on Monthly basis</th>
                                    
                                    <th title="Facility conducts Maternal death, Neonatal death and near-miss on monthly basis">Facility conducts Maternal death, Neonatal death and near-miss on monthly basis</th>
                                    
                                    <th title="Facility report zero stock outs in Labour Room & Maternity OT">Facility report zero stock outs in Labour Room & Maternity OT</th>
                                    
                                    <th style="min-width: 120px;" title="Still Birth Rate">Still Birth Rate </th>
                                    
                                    <th title="Percentage of beneficiaries  who were either satisfied or highly satisfied">Percentage of beneficiaries  who were either satisfied or highly satisfied</th>
                                    
                                    <th title="functional Obs ICU/Hybrid ICU/HDU?">functional Obs ICU/Hybrid ICU/HDU?</th>
                                    
                                    <th title="Microbiological Surveillance in OT & LR">Microbiological Surveillance in OT & LR </th>
                                    
                                    <th title="Labour Room Quality Score Improvement from Baseline">Labour Room Quality Score Improvement from Baseline </th>
                                    
                                    <th title="Maternity OT Quality Score Improvement from Baseline">Maternity OT Quality Score Improvement from Baseline </th>
                                    <!--<th width="70px">Action</th>-->
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                            <input type="hidden" name="CertificationID" id="CertificationID" value="<?php echo empty($CertificationID)?'':encryptor($CertificationID); ?>" >
                            <input type="hidden" name="monthCount" id="monthCount" value="<?php echo empty($monthCount)?'':encryptor($monthCount); ?>" >
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>

    </div>
</div>



<style>
    .dataTables_wrapper{display:grid;}
    
    table tr th{vertical-align: top !important;}

    table.my-table-width tr th{min-width: 210px;}
</style>