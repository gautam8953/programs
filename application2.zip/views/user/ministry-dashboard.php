<?php //ob_start(); // die ?>
<div class="page-title">
  <div class="title_left">
    <h3>Dashboard</h3>
  </div>
</div>

<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">	  
    <div class="row">
	
			<div class="col-md-12 dash-h2-font">
				<div class="col-md-4 col-xs-12">
					<a href="#">
						<div class="dash_box1">
							<h2><?php echo isset($data['totalBaseLaQshya'])?$data['totalBaseLaQshya']:'0'; ?></h2>
							<p>LaQshya baseline assessment completed</p>
						</div>
					</a>
				</div>
				<div class="col-md-4 col-xs-12">
					<a href="#">
						<div class="dash_box2">
							<h2>0</h2>
							<p>LaQshya State orientation completed</p>
						</div>
					</a>
				</div>
				<div class="col-md-4 col-xs-12">
					<a href="#">
						<div class="dash_box3">
							<h2><?php echo isset($data['totalQfLaQshya'])?$data['totalQfLaQshya']:'0'; ?></h2>
							<p>LaQshya Certified Facilities:  LR & OT</p>
						</div>
					</a>
				</div>
				<div class="col-md-4 col-xs-12">
					<a href="#">
						<div class="dash_box4">
							<h2><?php echo isset($data['totalBaseLaQshyaDh'])?$data['totalBaseLaQshyaDh']:'0'; ?></h2>
							<p>DH in Aspirational Districts completed baseline assessment</p>
						</div>
					</a>
				</div>
				<div class="col-md-4 col-xs-12">
					<a href="#">
						<div class="dash_box5">
							<h2>0</h2>
							<p>State Certification of LR of Dist. Hospital in Aspirational District</p>
						</div>
					</a>
				</div>
				<div class="col-md-4 col-xs-12">
					<a href="#">
						<div class="dash_box1">
							<h2>0</h2>
							<p>State Certification of OT of Dist. Hospital in Aspirational District</p>
						</div>
					</a>
				</div>








			</div>
			<!-- pie chart started  -->
			<?php if(array_sum($data['deliveryQualityPie'])>0){ ?>
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Laqshya Qualified LR & OT</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">	   
			        <div class="col-md-12">
			        	<div class="row mar-bottom30">
			        		<div id="piechart_3d" style="width: 100%; height: 500px;"></div>
		            	</div>
		            	<hr>            	
		        	</div>
			    </div>
			  </div>
			</div>
			<?php } ?>
			<!-- pie chart ended  -->

		</div>        
    </div>
</div>


<span id="jstip"></span>



   <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
<?php if(array_sum($data['deliveryQualityPie'])>0){ ?>
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Indicator', 'Number'],
          <?php foreach ($data['deliveryQualityPie'] as $key => $value) { 
          	echo "['".$key."',     ".$value."],";
          } ?>
        ]);

        var options = {
          title: 'Delivery Quality Indicators',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
<?php } ?>
    </script>
<?php 
/*$out2 = ob_get_contents();
ob_end_clean();
echo $out2;*/
?>




