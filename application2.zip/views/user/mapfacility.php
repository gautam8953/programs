<div class="page-title">
  <div class="title_left">
    <h3>Users</h3>
  </div>
</div>
<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">

		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2><?php if(isset($facility)){ echo 'Add/Update Facility'; } else { echo 'Map Facility'; } ?> </h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">
			    	<?php if(isset($facility)){ ?>
					<?php if(isset($facility['FacilityID']) && $facility['FacilityID']>0){ ?>
			        <div class="alert alert-danger" id="" >
			          <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
			          <strong id="">Facility already added</strong>
			        </div>						
					<?php } ?>
		            <form enctype="multipart/form-data" name="facilityForm" id="facilityForm" role="form" action="<?php echo base_url(). "ApiUser/addfacility"; ?>" method="post">             
		              
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label>Name</label>
		                  <input maxlength="99" class="form-control" placeholder="Name" id="FacilityName" name="FacilityName" type="text" value="<?php if(isset($facility)){ echo $facility['FacilityName']; };  ?>" readonly="readonly" >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> NIN ID </label>
		                  <input maxlength="25" class="form-control" placeholder="NIN ID" id="FacilityNumber" name="FacilityNumber" type="text" value="<?php if(isset($facility)){ echo $facility['FacilityNumber']; };  ?>" readonly="readonly"  >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> Type of Facility </label>
		                  <input maxlength="50" class="form-control" placeholder="Type of Facility" id="TypeDetailCode" name="TypeDetailCode" type="text" value="<?php if(isset($facility)){ echo $facility['TypeDetailCode']; };  ?>" readonly="readonly"   >
		                  <input maxlength="50" class="form-control" placeholder="State" id="FacilityTypeDetailID" name="FacilityTypeDetailID" type="hidden" value="<?php if(isset($facility)){ echo $facility['FacilityTypeDetailID']; };  ?>" readonly="readonly"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label>Address </label>
		                  <input maxlength="255" class="form-control" placeholder="Address" id="Address" name="Address" type="text" value="<?php if(isset($facility)){ echo $facility['Address']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> State </label>
		                  <input maxlength="50" class="form-control" placeholder="State" id="StateName" name="StateName" type="text" value="<?php if(isset($facility)){ echo $facility['StateName']; };  ?>" readonly="readonly"   >
		                  <input maxlength="50" class="form-control" placeholder="State" id="StateID" name="StateID" type="hidden" value="<?php if(isset($facility)){ echo $facility['StateID']; };  ?>" readonly="readonly"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> District </label>
		                  <input maxlength="50" class="form-control" placeholder="District" id="DistrictName" name="DistrictName" type="text" value="<?php if(isset($facility)){ echo $facility['DistrictName']; };  ?>" readonly="readonly"   >
		                  <input maxlength="50" class="form-control" placeholder="State" id="DistrictID" name="DistrictID" type="hidden" value="<?php if(isset($facility)){ echo $facility['DistrictID']; };  ?>" readonly="readonly"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label>Pin Code </label>
		                  <input maxlength="6" class="form-control nums" placeholder="Pin Code" id="PinCode" name="PinCode" type="text" value="<?php if(isset($facility)){ echo $facility['PinCode']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> Landline No. </label>
		                  <input class="form-control" placeholder="Landline No" id="landLine" name="landLine" type="text" value="<?php if(isset($facility)){ echo $facility['landLine']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> Latitude </label>
		                  <input maxlength="50" class="form-control" placeholder="Latitude" id="Latitude" name="Latitude" type="text" value="<?php if(isset($facility)){ echo $facility['Latitude']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> Longitude </label>
		                  <input maxlength="50" class="form-control" placeholder="Longitude" id="Longitude" name="Longitude" type="text" value="<?php if(isset($facility)){ echo $facility['Longitude']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> Altitude </label>
		                  <input maxlength="50" class="form-control" placeholder="Altitude" id="Altitude" name="Altitude" type="text" value="<?php if(isset($facility)){ echo $facility['Altitude']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                  <div class="form-group">
		                      <label>Services </label>
		                          <br>
		                      <label class="radio inline">
		                          <input id="services_lr" name="services" type="radio" onchange="checkFacilityAssessment(this)" value="lr" >
		                          <span>LR </span>
		                      </label>

		                      <label class="radio inline">
		                          <input id="services_both" name="services" type="radio" onchange="checkFacilityAssessment(this)" value="both" >
		                          <span>LR & OT Both </span>
		                      </label>

		                  </div>
		              </div>
		              <div class="col-md-12">
		                <div class="form-group">
		                  <div class='input-group pull-right'>
		                  	<input maxlength="50" class="form-control" placeholder="FacilityID" id="FacilityID" name="FacilityID" type="hidden" value="<?php if(isset($facility['FacilityID'])){ echo $facility['FacilityID']; };  ?>" readonly="readonly"   >
		                    <input style="margin-top: 15px; margin-right: 20px;" type='submit' id="profileBtn" name="profileBtn" value="Save" class="btn btn-info" />
		                    <input type="button" style="margin-top: 15px; margin-right: 0px;" data-href="<?php echo base_url().'user/mapfacility'; ?>" class="btn btn-danger" onclick="pageRedirect(this)" value="Cancel" >
		                  </div>
		                </div>
		              </div>                    
		            </form>

			    	<?php } else { ?>
				    <div class="row">
				        <div class="col-md-12">
				        	<div class="well">
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                	<select id="search_state" name="search_state" onchange="change_state()" class="form-control">
									<option value="0">Select State</option>
								</select>                    
			                </div>
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                	<select id="search_district" name="search_district" onchange="" class="form-control">
									<option value="0">Select District</option>
								</select>                    
			                </div>
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                	<select id="opt" name="opt" onchange="change_type(this)" class="form-control">
									<option value="1">Laqshya Facility</option>
									<option value="0">InActive Facility</option>
								</select>                    
			                </div>
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" />
			                    <a href="javascript:void(0)" id="reset_btn" class="btn btn-primary">Reset</a>
			                </div>
			                <?php if($this->CommonModel->checkPageActionWeb('user/mapfacility','access_edit',$this->session->userdata('RoleName'))){ ?>
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                    <input id="btn_facility_map" name="btn_facility_map" type="button" class="btn btn-primary" value="Map Facility to Laqshya" onclick="map_user('1')" disabled="disabled" />
			                </div>
			                <?php } ?>
			                <?php if($this->CommonModel->checkPageActionWeb('user/mapfacility','access_edit',$this->session->userdata('RoleName'))){ ?>
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                    <input id="btn_facility_remove" name="btn_facility_remove" type="button" class="btn btn-primary" value="Remove Facility From Laqshya" onclick="map_user('0')" />
			                </div>
			            	<?php } ?>
			                <?php if($this->CommonModel->checkPageActionWeb('user/mapfacility','access_edit',$this->session->userdata('RoleName'))){ ?>
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                    <input id="btn_facility_add" name="btn_facility_add" type="button" class="btn btn-primary" value="Add Facility" data-toggle="modal" data-target="#addFacilityModal" />
			                </div>
			            	<?php } ?>
			                <?php if($this->CommonModel->checkPageActionWeb('user/mapfacility','access_edit',$this->session->userdata('RoleName'))){ ?>
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                    <input id="btn_facility_type_add" name="btn_facility_type_add" type="button" class="btn btn-primary" value="Add Facility Type" data-toggle="modal" data-target="#addFacilityTypeModal" />
			                </div>
			            	<?php } ?>
			            </div>
			            </div>
				    </div>
				      <table id="datatable" class="table table-striped table-bordered">
				        	<thead>
				            <tr>
				                <th>SN.</th>
				                <th>State</th>
				                <th>District</th>
				                <th>Facility</th>
				                <th>Nin Number</th>
				                <th>Is Laqshya</th>
				            </tr>
				        	</thead>
				            <tbody>
				            	<tr>
				            		<td></td>
				            		<td></td>
				                	<td></td>
				                	<td></td>
				                	<td></td>
				                	<td></td>
				            	</tr>
				            </tbody>
				      </table>
				    <?php } ?>
			    </div>
			  </div>
			</div>
			<form name="failitiesAdd" id="failitiesAdd" class="login-form" action="<?php echo base_url() . "ApiUser/AddFacility" ?>" method="post" style="display: none;">
				
			</form>
		</div>        
    </div>
</div>

<!-- facility add modal start -->
  <div class="modal fade" id="addFacilityModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add/Update Facility Deatils</h4>
        </div>
        <div class="modal-body">
		    <div class="row">
		        <div class="col-md-12">
		        	<div class="well">
		                <div class="col-md-6 col-xs-12 mar-top-20">
		                	<input type="text" name="" maxlength="99" class="form-control" placeholder="NIN Number" id="FacilityNumberSearch" name="FacilityNumberSearch">
		                </div>
		                <div class="col-md-6 col-xs-12 mar-top-20">
		                    <input id="btn_search_nin" name="btn_search_nin" type="button" class="btn btn-danger" value="Search" />
		                </div>
	            	</div>
	            </div>
		    </div>

        </div>
        <div class="modal-footer">
        	<input disabled="true" type='submit' id="saveFacilityBtn" name="saveFacilityBtn" value="Save" class="btn btn-info" />
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!-- facility add modal end -->
<!-- facility Type add modal start -->
  <div class="modal fade" id="addFacilityTypeModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Facility Type</h4>
        </div>
        <div class="modal-body">
		    <div class="row">
		        <div class="col-md-12">
		        	<div class="well">
		                <div class="col-md-6 col-xs-12 mar-top-20">
		                	<input type="text" name="" maxlength="99" class="form-control" placeholder="Facility Type" id="FacilityTypeSearch" name="FacilityTypeSearch">
		                </div>
		                <div class="col-md-6 col-xs-12 mar-top-20">
		                    <input id="btn_search_type" name="btn_search_type" type="button" class="btn btn-danger" value="Save" />
		                </div>
	            	</div>
	            </div>
		    </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!-- facility Type add modal end -->