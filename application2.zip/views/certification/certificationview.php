<style>
		.col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}
		
</style>


<div class="page-title">
	<div class="title_left full-width">
		<h3><!-- <?php echo $this->config->item('certificationLevel')[$data['main']['level']]; ?> <?php echo $this->config->item('survey')[$data['main']['certification_type']]; ?>-->Certification Apply</h3>
	</div>
</div>
<div class="clearfix"></div>


<div class="main-content main-content-form-gr-h carti-c">
		<div class="container">
				<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="x_panel">
										<div class="x_title">
												<h2><?php echo $this->config->item('certificationLevel')[$data['main']['level']]; ?> <?php echo $this->config->item('survey')[$data['main']['certification_type']]; ?> </h2>
												<ul class="nav navbar-right panel_toolbox">
														<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
												</ul>
												<div class="clearfix"></div>
										</div>
										<div class="x_content">
												<!-- <form id="assesmentForm" name="assesmentForm" role="form" action="<?php //echo base_url()."ApiFacility/assesment"?>" method="post"> -->
												<div id="smartwizard">
													<ul>
														<li><a href="#step-0"><span><em> A </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>General Information<br /></a></li>
														<li><a href="#step-1"><span><em> B </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>Documents<br /></a></li>
														<li><a href="#step-2"><span><em> C </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>Events/History<br /></a></li>
													</ul>
													<div>
														<!-- Step Start -->														
														<div id="step-0">

<div class="col-md-6 col-xs-12">
		<div class="form-group"><span class="f-anme1">Facility Name: </span>
		<span class="name-details-f"><?php echo empty($data['show']['FacilityName'])?'':$data['show']['FacilityName']; ?> </span>
		</div>
</div>
<div class="col-md-6 col-xs-12">
		<div class="form-group"><span class="f-anme1">Application Number: </span>
		<?php echo empty($data['main']['certification_no'])?'':$data['main']['certification_no']; ?>
		</div>
</div>
<div class="col-md-6 col-xs-12">
		<div class="form-group"><span class="f-anme1">Certificate Type: </span>
		 <span class="name-details-f"><?php echo $this->config->item('survey')[$data['main']['certification_type']]; ?> <?php echo $this->config->item('certificationLevel')[$data['main']['level']]; ?></span>
		</div>
</div>

<div class="col-md-6 col-xs-12">
		<div class="form-group">
			<span class="f-anme1">Certificate Status: </span>
			<?php echo $this->config->item('certificationStatus')[$data['main']['status']]; ?>
		</div>
</div>
<div class="col-md-6 col-xs-12">
		<div class="form-group">
			<span class="f-anme1">Certificate Remarks:</span>
		<?php echo empty($data['main']['remarks'])?'':$data['main']['remarks']; ?>
		</div>
</div>
<div class="col-md-6 col-xs-12">
		<div class="form-group">
			<span class="f-anme1">Applied Date:</span>
		<?php echo convert_date_show($data['main']['applied_date']); ?>
		</div>
</div>
<div class="col-md-6 col-xs-12">
		<div class="form-group">
			<span class="f-anme1">Certification Date:</span>
		<?php echo convert_date_show($data['main']['certification_date']); ?>
		</div>
</div>






															<div class="clear"></div>
														</div>
														<div id="step-1" style="">
<div class="col-md-6 col-xs-12">
		<div class="form-group">
			<span class="f-anme1">Application Form: </span>
		<?php if(!empty($data['main']['appForm'])){ $appFormUrl=is_file($data['main']['appForm'])?base_url().$data['main']['appForm']:''; } else { $appFormUrl=''; }; if(!empty($appFormUrl)){ ?>
		<a target="_blank" href="<?php echo $appFormUrl; ?>"  class="viewdetailpage">View</a>
		<?php } ?>
		</div>
</div>
<div class="col-md-6 col-xs-12">
		<div class="form-group">
			<span class="f-anme1">hospital Data Sheet: </span>
		<a target="_blank" href="<?php echo base_url().'certification/hospitaldata/'.encryptor($CertificationID); ?>"  class="viewdetailpage">View</a>
		</div>
</div>
 
	<?php if($data['main']['certification_type']=='lr' ){ ?>
	<div class="col-md-6 col-xs-12">
		<div class="form-group">
		<span class="f-anme1">	lr sop: </span>
        <?php if(!empty($data['main']['lrsop'])){ $lrsopUrl=is_file($data['main']['lrsop'])?base_url().$data['main']['lrsop']:''; } else { $lrsopUrl=''; }; if(!empty($lrsopUrl)){ ?>
        <a target="_blank" href="<?php echo $lrsopUrl; ?>"  class="viewdetailpage">View</a>
        <?php } ?>
		</div>
	</div>
	<?php } ?>
	<?php if($data['main']['certification_type']=='ot' ){ ?>
	<div class="col-md-6 col-xs-12">
		<div class="form-group">
		<span class="f-anme1"> OT SOP: </span>
        <?php if(!empty($data['main']['otsop'])){ $otsopUrl=is_file($data['main']['otsop'])?base_url().$data['main']['otsop']:''; } else { $otsopUrl=''; }; if(!empty($otsopUrl)){ ?>
        <a target="_blank" href="<?php echo $otsopUrl; ?>"  class="viewdetailpage">View</a>
        <?php } ?>
		</div>
	</div>
	<?php } ?>
	<?php if($data['main']['certification_type']=='lr' ){ ?>
	<div class="col-md-6 col-xs-12">
		<div class="form-group">
	<span class="f-anme1">	LR Assessment: </span>
        <?php if(!empty($data['main']['facilityPeerAssmentLR'])){ 
        	$lrAssessmentUrl=base_url().'facility/checklistview/'.encryptor('1').'/'.encryptor($data['main']['facilityPeerAssmentLR']).'/'.encryptor('A');
        	$lrAssessmentUrlDownlaod=base_url().'facility/surveyFormatDownload/'.encryptor($data['main']['facilityPeerAssmentLR']).'/'.encryptor('A');

        	?>
        <a target="_blank" href="<?php echo $lrAssessmentUrl; ?>" class="viewdetailpage">View</a>
        <!-- <a target="_blank" href="<?php //echo $lrAssessmentUrlDownlaod; ?>" class="viewdetailpage1">Download</a> -->
        <?php } ?>
		</div>
	</div>
	<?php } ?> 	
	<?php if($data['main']['certification_type']=='ot' ){ ?>
	<div class="col-md-6 col-xs-12">
		<div class="form-group">
	<span class="f-anme1">	OT Assessment: </span>
        <?php if(!empty($data['main']['facilityPeerAssmentOT'])){ 
        	$otAssessmentUrl=base_url().'facility/checklistview/'.encryptor('2').'/'.encryptor($data['main']['facilityPeerAssmentOT']).'/'.encryptor('A'); 
        	$otAssessmentUrlDownlaod=base_url().'facility/surveyFormatDownload/'.encryptor($data['main']['facilityPeerAssmentOT']).'/'.encryptor('A');
        	?>
        <a target="_blank" href="<?php echo $otAssessmentUrl; ?>" class="viewdetailpage">View</a>
        <!-- <a target="_blank" href="<?php //echo $otAssessmentUrlDownlaod; ?>" class="viewdetailpage1">Download</a> -->
        <?php } ?>
		</div>
	</div>
	<?php } ?>
 

<?php if(!empty($data['anexturedoc'])){ foreach($data['anexturedoc'] as $key => $value) { ?>	
    <div class="col-md-6 col-xs-12">
    <div class="col-md-12 col-xs-12">
        <div class="form-group">
            <label><span class="f-anme1"> Submission Date: </span>
            <span><?php echo empty($value['submitdate'])?'':convert_date_show($value['submitdate']); ?></span>
            <?php if(!empty($value['submitfile'])){ $docUrl=is_file($value['submitfile'])?base_url().$value['submitfile']:''; } else { $docUrl=''; }; if(!empty($docUrl)){ ?>
        <a target="_blank" href="<?php echo $docUrl; ?>" class="viewdetailpage">View</a>
        <a target="_blank" href="<?php echo $docUrl; ?>" class="viewdetailpage1" download="" >Download</a>
        <?php } ?> </label>
        </div>        
    </div>
    </div>
<?php } }  ?>

<?php if(!empty($data['othername'])){ foreach($data['othername'] as $key => $value) { ?>
<div class="">	
    <div class="col-md-6 col-xs-12">
        <div class="form-group">
            <label><span class="f-anme1"> Document Name:  <?php echo empty($value['name'])?'':$value['name']; ?> </span></label>
            <?php if(!empty($value['doc'])){ $docUrl=is_file($value['doc'])?base_url().$value['doc']:''; } else { $docUrl=''; }; if(!empty($docUrl)){ ?>
        <a target="_blank" href="<?php echo $docUrl; ?>"  class="viewdetailpage">View</a>
        <?php } ?>
        </div>        
    </div>	
    <div class="col-md-6 col-xs-12">
        
    </div>    
</div>

<?php } }  ?>
<div class="col-md-6 col-xs-12">
		<div class="form-group">
		<span class="f-anme1">	Laqshya Indicator Report 1: </span>
		 	<a target="_blank" href="<?php echo base_url(); ?>monthly/report_certificate/<?php echo empty($CertificationID)?'':encryptor($CertificationID); ?>" class="viewdetailpage">View</a>
		</div>
</div>
<div class="col-md-6 col-xs-12">
		<div class="form-group">
		<span class="f-anme1">	Laqshya Indicator Report 2: </span>
			<a target="_blank" href="<?php echo base_url(); ?>monthly/report_certificate/<?php echo empty($CertificationID)?'':encryptor($CertificationID); ?>" class="viewdetailpage">View</a>
		</div>
</div>
<div class="col-md-6 col-xs-12">
		<div class="form-group">
		<span class="f-anme1">	Laqshya Indicator Report 3: </span>
		 	<a target="_blank" href="<?php echo base_url(); ?>monthly/report_certificate/<?php echo empty($CertificationID)?'':encryptor($CertificationID); ?>" class="viewdetailpage">View</a>
		</div>
</div>




															<div class="clear"></div>
														</div>
														<div id="step-2"  style="">


															<table class="new-tabl-event-histry">
																<tr>
																	<th>Remarks</th>
																	<th>Status History</th>
																	<th>Event Date</th>
																	<th>Updated By</th>
																</tr>
 
<?php if(!empty($data['certification_status'])){ foreach($data['certification_status'] as $key => $value) {  ?>
																<tr>
																	
																	<td><?php echo $value['remarks']; ?></td>
																	<td><?php echo $this->config->item('certificationStatus')[$value['new_status']]; ?></td>
																	<td> <?php echo convert_date_show($value['CreatedOn']); ?></td>
																	<td> <?php echo $value['UserName']; ?></td>
																	 
																</tr>
																<?php } }  ?>

															</table>


											 

															<div class="clear"></div>
														</div>




														<input type="hidden" name="CertificationID" id="CertificationID" value="<?php echo empty($CertificationID)?'':encryptor($CertificationID); ?>" >

														<!-- Step End -->

													</div>
												</div>
												<!-- </form> -->


										</div>
								</div>



						</div>




				




				</div>
		</div>
</div>
<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>