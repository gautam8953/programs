<div class="page-title">
  <div class="title_left">
    <h3>Assessment Form</h3>
  </div>

  <!--<div class="title_right">
    <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
      <div class="input-group" style="float: right;">
        <a href="<?php echo base_url(). "facility/assesment"; ?>" id="addBtn" class="btn btn-success disabled pull-right">Add</a>
      </div>
    </div>
  </div>-->
</div>

<div class="clearfix"></div>






<div class="main-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Assessment Data</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <form id="assesmentForm" name="assesmentForm" role="form" action="<?php echo base_url()."ApiFacility/assesment"?>" method="post">
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label> Name of the Hospital <span class=""> : </span> <span class="normal_font" id="facilityName"></span></label>
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label> Assessment Type <span class=""> : </span> <span class="normal_font" id="sequence"></span></label>
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label> Date of Assessment <span class=""> : </span> <span class="normal_font" id="assessmentDate"></span></label>
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label> Name of Assessor 1<span class=""> : </span> <span class="normal_font" id="assessorsName1"></span></label>
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label> Name of Assessee 1<span class=""> : </span> <span class="normal_font" id="assesseesName1"></span></label>
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label> Name of Assessor 2<span class=""> : </span> <span class="normal_font" id="assessorsName2"></span></label>
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label> Name of Assessee 2<span class=""> : </span> <span class="normal_font" id="assesseesName1"></span></label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label> Category of Assessment <span class=""> : </span> <span class="normal_font" id="assessmentType"></span></label>
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label> Action plan Submission Date <span class=""> : </span> <span class="normal_font" id="submissionDate"></span></label>
                            
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class='input-group pull-right'>
                                <input type='hidden' name="ansId" id="ansId" value="<?php echo $this->uri->segment('3'); ?>" class="" />
                                <input style="margin-top: 15px; margin-right: 0px;" type='button' id="assesment" name="assesment" value="Next" class="btn btn-info" />
                            </div>
                        </div>
                    </div>
                    
                </form>
            </div>
        </div>
            </div>
        </div>
    </div>
</div>