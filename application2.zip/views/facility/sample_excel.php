<?php
 $file = 'format-'.date("Y-M-D")."-".time().'.xls';
 ob_start(); ?>
<table border="1">
  <?php foreach ($data['survey'] as $keySurvey => $valueSurvey) { ?>
    <tr>
      <th colspan="7">Any changes in excel except Compliance may lead to cancled format</th>
    </tr>
    <tr>
      <th colspan="7">National Quality Assurance Standards 2016</th>
    </tr>
    <tr>
      <th colspan="7"><?php echo $valueSurvey['SurveyDesc']; ?></th>
    </tr>
    <tr>
      <th colspan="7">Assessment Summary</th>
    </tr>
    <tr>
      <th colspan="2">Name of the Hospital</th>
      <th colspan="3"></th>
      <th colspan="1">Date of Assessment</th>
      <th colspan="1"></th>
    </tr>
    <tr>
      <th colspan="2">Names of Assessors</th>
      <th colspan="3"></th>
      <th colspan="1">Names of Assessees</th>
      <th colspan="1"></th>
    </tr>
    <tr>
      <th colspan="2">Type of Assessment (Internal/Peer/External)</th>
      <th colspan="3"></th>
      <th colspan="1">Action plan Submission Date</th>
      <th colspan="1"></th>
    </tr>
    <tr>
      <th></th>
      <th colspan="6">Major Gaps Observed</th>
    </tr>
    <tr>
      <th>1</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>2</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>3</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>4</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>5</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th></th>
      <th colspan="6">Strengths / Good Practices</th>
    </tr>
    <tr>
      <th>1</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>2</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>3</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>4</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>5</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th></th>
      <th colspan="6">Recommendations/ Opportunities for Improvement</th>
    </tr>
    <tr>
      <th>1</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>2</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>3</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>4</th>
      <th colspan="6"></th>
    </tr>
    <tr>
      <th>5</th>
      <th colspan="6"></th>
    </tr>
    <?php foreach ($valueSurvey['category'] as $keyCat => $valueCat) { ?>
      <tr>
        <th>Reference No</th>
        <th>Measurable Element</th>
        <th>Checkpoint</th>
        <th>Compliance</th>
        <th>Assessment Methods</th>
        <th>Means Of Verification</th>
        <th>Remarks</th>
      </tr>
      <tr>
        <th colspan="7"><?php echo $valueCat['CategoryCode'].':'.$valueCat['CategoryName']; ?></th>
      </tr>
        <?php foreach ($valueCat['subcategory'] as $keySubCat => $valueSubCat) {  ?>
        <tr>
          <th colspan=""><?php echo $valueSubCat['SubCategoryCode']; ?></th>
          <th colspan="6"><?php echo $valueSubCat['SubCategoryName']; ?></th>
        </tr>
          <?php foreach ($valueSubCat['questions'] as $keyQues => $valueQues) {  ?>
            <tr>
              <td><?php echo $valueQues['Reference']; ?></td>
              <td><?php echo $valueQues['Statement']; ?></td>
              <td><?php echo $valueQues['Checkpoint']; ?></td>
              <td>2</td>
              <td><?php echo $valueQues['Assesment']; ?></td>
              <td><?php echo $valueQues['Verification']; ?></td>
              <td><?php echo $valueQues['Remarks']; ?></td>
            </tr>
          <?php  } ?>
        <?php } ?>      
    <?php } ?>    
  <?php } ?>
 </table>
<?php 
 $content = ob_get_contents();
 ob_end_clean();
  header("Expires: 0");
 header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
 header("Cache-Control: no-store, no-cache, must-revalidate");
 header("Cache-Control: post-check=0, pre-check=0", false);
 header("Pragma: no-cache");  header("Content-type: application/vnd.ms-excel;charset:UTF-8");
 header('Content-length: '.strlen($content));
 header('Content-disposition: attachment; filename='.basename($file));
 echo $content;
 exit;
?>