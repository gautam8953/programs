<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('UserModel');
        $this->load->model('FacilityModel');
        $this->load->helper('captcha');        
    }
    public function index() {
        $userID = $this->session->userdata('UserID');
        if (empty($userID)) {
            redirect('user/login');
        }
        $data=array();
        $this->load->view('header');
        if($this->session->userdata('RoleName')=='Facility'){
          $search['userID']=$this->session->userdata('UserID');
          $data['data']=$this->CommonModel->dashboard_facility_data($search);
          $this->load->view('user/facility-dashboard',$data);
        } else if($this->session->userdata('RoleName')=='State'){
          $search=array();
          $search['UserID']=$this->session->userdata('UserID');
          $search['RoleName']=$this->session->userdata('RoleName');
          $search['mapped']='';
          if($this->session->userdata('RoleName')=='State'){
            $search['mapped']=$this->session->userdata('MappedState');
          }
          $data['data']=$this->CommonModel->state_dashboard_new($search);
          $this->load->view('user/state_dashboard_new',$data);
        } else if($this->session->userdata('RoleName')=='District'){
          $search=array();
          $search['UserID']=$this->session->userdata('UserID');
          $search['RoleName']=$this->session->userdata('RoleName');
          $search['mapped']='';
          if($this->session->userdata('RoleName')=='District'){
            $search['mapped']=$this->session->userdata('MappedDistrict');
          }
          $data['data']=$this->CommonModel->district_dashboard_new($search);
          $this->load->view('user/district_dashboard_new',$data);
          //echo "<pre>"; print_r($data); echo "</pre>";
        } else {
          $search=array();
          $search['UserID']=$this->session->userdata('UserID');
          $search['RoleName']=$this->session->userdata('RoleName');
          $search['mapped']='';
          if($this->session->userdata('RoleName')=='State'){
            $search['mapped']=$this->session->userdata('MappedState');
          }
          if($this->session->userdata('RoleName')=='District'){
            $search['mapped']=$this->session->userdata('MappedDistrict');  
          }
          $data['data']=$this->CommonModel->ministry_dashboard_new($search);
          $this->load->view('user/ministry_dashboard_new',$data);
        }
          //echo "<pre>"; print_r($data); echo "</pre>";
        $this->load->view('footer');
    }
    public function index_three() {
        $userID = $this->session->userdata('UserID');
        if (empty($userID)) {
            redirect('user/login');
        }
        $data=array();
        $this->load->view('header');
        if($this->session->userdata('RoleName')=='Facility'){
          $search['userID']=$this->session->userdata('UserID');
          $data['data']=$this->CommonModel->dashboard_facility_data($search);
          $this->load->view('user/facility-dashboard',$data);
        } else if($this->session->userdata('RoleName')=='State'){
          $search=array();
          $search['UserID']=$this->session->userdata('UserID');
          $search['RoleName']=$this->session->userdata('RoleName');
          $search['mapped']='';
          if($this->session->userdata('RoleName')=='State'){
            $search['mapped']=$this->session->userdata('MappedState');
          }
          $data['data']=$this->CommonModel->state_dashboard_new($search);
          $this->load->view('user/state_dashboard_new',$data);
        } else if($this->session->userdata('RoleName')=='District'){
          $search=array();
          $search['UserID']=$this->session->userdata('UserID');
          $search['RoleName']=$this->session->userdata('RoleName');
          $search['mapped']='';
          if($this->session->userdata('RoleName')=='District'){
            $search['mapped']=$this->session->userdata('MappedDistrict');
          }
          $data['data']=$this->CommonModel->district_dashboard_new($search);
          $this->load->view('user/district_dashboard_new',$data);
        } else {
          $search=array();
          $search['UserID']=$this->session->userdata('UserID');
          $search['RoleName']=$this->session->userdata('RoleName');
          $search['mapped']='';
          if($this->session->userdata('RoleName')=='State'){
            $search['mapped']=$this->session->userdata('MappedState');
          }
          if($this->session->userdata('RoleName')=='District'){
            $search['mapped']=$this->session->userdata('MappedDistrict');  
          }
          $data['data']=$this->CommonModel->ministry_dashboard_new($search);
          $this->load->view('user/ministry_dashboard_new_three',$data);
        }
          //echo "<pre>"; print_r($data); echo "</pre>";
        $this->load->view('footer');
    }
    public function index_two() {
        $userID = $this->session->userdata('UserID');
        if (empty($userID)) {
            redirect('user/login');
        }
        $data=array();
        $this->load->view('header');
        if($this->session->userdata('RoleName')=='Facility'){
          //echo "<pre>";
          $search['userID']=$this->session->userdata('UserID');
          $data['data']=$this->CommonModel->dashboard_facility_data($search);
          //print_r($data); die;
          $this->load->view('user/facility-dashboard',$data);
        } else if($this->session->userdata('RoleName')=='Ministry'){
          $search=array();
          $search['UserID']=$this->session->userdata('UserID');
          $search['RoleName']=$this->session->userdata('RoleName');
          $data['data']=$this->CommonModel->dashboard_ministry_data($search);
          //echo array_sum($data['data']['deliveryQualityPie']);
          //echo "<pre>"; print_r($data); die;
          $this->load->view('user/ministry-dashboard',$data);
        } else {
          $search=array();
          $search['UserID']=$this->session->userdata('UserID');
          $search['RoleName']=$this->session->userdata('RoleName');
          $search['mapped']='';
          if($this->session->userdata('RoleName')=='State'){
            $search['mapped']=$this->session->userdata('MappedState');
          }
          if($this->session->userdata('RoleName')=='District'){
            $search['mapped']=$this->session->userdata('MappedDistrict');  
          }
          //echo "<pre>";
          $data['data']=$this->CommonModel->dashboard_data($search);
          //print_r($data); 
          //die;
          $this->load->view('user/dashboard',$data);
        }
        $this->load->view('footer');
    }
    public function index_one() {
        $userID = $this->session->userdata('UserID');
        if (empty($userID)) {
            redirect('user/login');
        }
        $data=array();
        $this->load->view('header');
        if($this->session->userdata('RoleName')=='Facility'){
          //echo "<pre>";
          $search['userID']=$this->session->userdata('UserID');
          $data['data']=$this->CommonModel->dashboard_facility_data($search);
          //print_r($data); die;
          $this->load->view('user/facility-dashboard',$data);
        } else {
          $search=array();
          $search['UserID']=$this->session->userdata('UserID');
          $search['RoleName']=$this->session->userdata('RoleName');
          $search['mapped']='';
          if($this->session->userdata('RoleName')=='State'){
            $search['mapped']=$this->session->userdata('MappedState');
          }
          if($this->session->userdata('RoleName')=='District'){
            $search['mapped']=$this->session->userdata('MappedDistrict');  
          }
          //echo "<pre>";
          $data['data']=$this->CommonModel->dashboard_data($search);
          //print_r($data); 
          //die;
          $this->load->view('user/dashboard',$data);
        }
        $this->load->view('footer');
    }
    public function deleteFiles($path){
        chmod($path, 0777); 
        $files = glob($path.'*'); // get all file names
        foreach($files as $file){ // iterate files
          if(is_file($file)){
            unlink($file); // delete file
          }
        }   
    }
    public function refresh() {        
         $config = array(
          'img_url' => base_url() . 'assets/captcha_img/',
          'img_path' => 'assets/captcha_img/',
          'img_height' => 45,
          'word_length' => 5,
          'img_width' => '225',
          'expiration' => 1,
          'font_size' => 18,
          'font_path' => '/fonts/VeraBd.ttf',
            'colors'        => array(
                'background' => array(128, 128, 128),
                'border' => array(255, 255, 255),
                'text' => array(255, 255, 255),
                'grid' => array(255, 40, 40)
                )
          );
          $captcha = create_captcha($config); 
        $this->session->unset_userdata('valuecaptchaCode');
        $this->session->set_userdata('valuecaptchaCode', $captcha['word']);
        echo $captcha['image'];
    }

    public function login() {
         $config = array(
          'img_url' => base_url() . 'assets/captcha_img/',
          'img_path' => 'assets/captcha_img/',
          'img_height' => 45,
          'word_length' => 5,
          'img_width' => '225',
          'expiration' => 1,
          'font_size' => 18,
          'font_path' => '/fonts/verdanab.ttf',
                'colors'        => array(
                'background' => array(128, 128, 128),
                'border' => array(255, 255, 255),
                'text' => array(255, 255, 255),
                'grid' => array(255, 40, 40)
              )
          );
          $captcha = create_captcha($config); 

        $this->session->set_userdata('valuecaptchaCode', $captcha['word']);
        $data['captchaImg'] = $captcha['image'];
        $userID = $this->session->userdata('UserID');
        if (!empty($userID)) {
            redirect('/');
        }
        $this->load->view('user/login', $data);
    }

    public function changepassword() {
        $userID = $this->session->userdata('UserID');
        if (empty($userID)) {
            redirect('user/login');
        }
        $this->load->view('header');
        $this->load->view('user/changepassword');
        $this->load->view('footer');
    }

    function mapfacility($ninnumber=''){
        $this->CommonModel->checkPageAccessWeb('user/mapfacility',$this->session->userdata('RoleName'));
          $data=array();
          if(!empty($ninnumber)){
            $data['facility']=$this->CommonModel->getfacilitydata($ninnumber);
          }
          $this->load->view('header');
          $this->load->view('user/mapfacility',$data);
          $this->load->view('footer');
    }
    function facilityassessment(){
        $this->CommonModel->checkPageAccessWeb('user/facilityassessment',$this->session->userdata('RoleName'));
          $data=array();
          $this->load->view('header');
          $this->load->view('user/facilityassessment',$data);
          $this->load->view('footer');
    }
    function laqshyafacility($param1=''){
        $userID = $this->session->userdata('UserID');
        $RoleName=$this->session->userdata('RoleName');
        if (!empty($userID) && ($RoleName!='Facility')) {
          $data=array();
          $data['param1']=$param1;
          $data['search_options']=$this->FacilityModel->getSearchOptions();
          $this->load->view('header');
          $this->load->view('user/laqshyafacility',$data);
          $this->load->view('footer');
        } else {
          redirect('/');
        }
    }
    function laqshyabaselr($aspirational=''){
        $userID = $this->session->userdata('UserID');
        $RoleName=$this->session->userdata('RoleName');
        if (!empty($userID) && ($RoleName!='Facility')) {
          $data=array();
          $data['search_options']=$this->FacilityModel->getSearchOptions();
          $data['aspirational']=$aspirational;
          $this->load->view('header');
          $this->load->view('user/laqshyabaselr',$data);
          $this->load->view('footer');
        } else {
          redirect('/');
        }
    }
    function laqshyabaseot($aspirational=''){
        $userID = $this->session->userdata('UserID');
        $RoleName=$this->session->userdata('RoleName');
        if (!empty($userID) && ($RoleName!='Facility')) {
          $data=array();
          $data['search_options']=$this->FacilityModel->getSearchOptions();
          $data['aspirational']=$aspirational;
          $this->load->view('header');
          $this->load->view('user/laqshyabaseot',$data);
          $this->load->view('footer');
        } else {
          redirect('/');
        }
    }
    function laqshyalr(){
        $userID = $this->session->userdata('UserID');
        $RoleName=$this->session->userdata('RoleName');
        if (!empty($userID) && ($RoleName!='Facility')) {
          $data=array();
          $data['search_options']=$this->FacilityModel->getSearchOptions();
          $this->load->view('header');
          $this->load->view('user/laqshyalr',$data);
          $this->load->view('footer');
        } else {
          redirect('/');
        }
    }
    function laqshyaot(){
        $userID = $this->session->userdata('UserID');
        $RoleName=$this->session->userdata('RoleName');
        if (!empty($userID) && ($RoleName!='Facility')) {
          $data=array();
          $data['search_options']=$this->FacilityModel->getSearchOptions();
          $this->load->view('header');
          $this->load->view('user/laqshyaot',$data);
          $this->load->view('footer');
        } else {
          redirect('/');
        }
    }
    function profile(){
        $userID = $this->session->userdata('UserID');
        if (empty($userID)) {
            redirect('user/login');
        }
        $data=array();
        $data['mainProfile']='';
        if($this->session->userdata('RoleName')=='Facility'){
          $data['facility']=$this->UserModel->getFacilityDetails($userID);
        }
        $data['main']=$this->UserModel->getProfileDetails($userID,'main');
        if($this->session->userdata('RoleName')!='Facility' ){
          $data['nodal']=$this->UserModel->getProfileDetails($userID,'nodal');          
        }
        
        if($this->session->userdata('RoleName')=='State'){ $data['mainProfile']='State'; }
        if($this->session->userdata('RoleName')=='District'){ $data['mainProfile']='CMO'; }
//echo "<pre>"; print_r($data); echo "</pre>"; die;
        $this->load->view('header');
        $this->load->view('user/profile',$data);
        $this->load->view('footer');

        
    }
    function termsandconditions(){
      $this->load->view('termsandconditions');
    }

    function privacypolicy(){
      $this->load->view('privacy-policy');
    }

    function help(){
      $this->load->view('help');
    }
    function facilitydata(){
        $userID = $this->session->userdata('UserID');
        $RoleName=$this->session->userdata('RoleName');
        if (!empty($userID) && ($RoleName!='Facility')) {
          $data=array();
          if(!empty($this->input->get('aspirational', TRUE))){
            $data['aspirational']=$this->input->get('aspirational', TRUE);
          }
          if(!empty($this->input->get('types', TRUE))){
            $data['types']=$this->input->get('types', TRUE);
          }
          if(!empty($this->input->get('level', TRUE))){
            $data['level']=$this->input->get('level', TRUE);
          }
          if(!empty($this->input->get('stage', TRUE))){
            $data['stage']=$this->input->get('stage', TRUE);
          }
                    
          $data['search_options']=$this->FacilityModel->getSearchOptions();
          $this->load->view('header');
          $this->load->view('user/facilitydata',$data);
          $this->load->view('footer');
        } else {
          redirect('/');
        }
    }
    function notification(){
      //$data=$this->CommonModel->getNotification();
      $data=array();
      $this->load->view('header');
      $this->load->view('user/notification',$data);
      $this->load->view('footer');
    }

    function role_management(){
      $this->CommonModel->checkPageAccessWeb('user/role_management',$this->session->userdata('RoleName'));
      $data=array();
      $data['rolesData']=$this->CommonModel->getRoles();
      if(!empty($this->input->post('btn_search'))){
        $role=$this->input->post('search_role');
      } else {
        $role=$data['rolesData'][0]['RoleID'];
      }
      if(!empty($this->input->post('save'))){
        foreach ($this->input->post('access') as $key => $value) {
          foreach ($value as $keyForm => $valueForm) {
            $dataSave=array(
              'user'=>$this->session->userdata('UserID'),
              'RoleID'=>$key,
              'frmID'=>$keyForm,
            );
            $this->CommonModel->updateRoles($dataSave,$valueForm);            
          }          
        }
      }
      $data['selectedRole']=$role;
      $data['roles']=$this->CommonModel->getRoles($role);
      $data['urls']=$this->CommonModel->getURLs();
      $data['getUserAccess']=$this->CommonModel->getUserAccess($role);
      $this->load->view('header');
      $this->load->view('user/role_management',$data);
      $this->load->view('footer');
    }
    function usermapping(){
      $this->CommonModel->checkPageAccessWeb('user/usermapping',$this->session->userdata('RoleName'));
      $data=array();
      $data['rolesData']=$this->UserModel->rolesdataUser();
      $this->load->view('header');
      $this->load->view('user/usermapping',$data);
      $this->load->view('footer');      
    }
    public function roles(){
      $this->CommonModel->checkPageAccessWeb('user/roles',$this->session->userdata('RoleName'));
      $this->load->model('FacilityModel');
      $data=array();
      $data['roles']=$this->UserModel->rolesdata();
      $this->load->view('header');
      $this->load->view('user/roles',$data);
      $this->load->view('footer');
    }
    public function rolesadd(){
      $this->load->model('FacilityModel');
      $data=array('RoleID'=>0);
      $uriParam=$this->uri->segment('3');
      if(!empty($uriParam)){
        if(!$this->CommonModel->checkPageActionWeb('user/roles','access_edit',$this->session->userdata('RoleName'))){
            redirect('/');
        }
        $data['RoleID']=encryptor($uriParam,'decrypt');
        if(empty($data['RoleID'])){
          redirect('user/roles');
        } else {
          $data['roleForm']=$this->UserModel->roledataForm($data['RoleID']);
          $data['getUserAccess']=$this->CommonModel->getUserAccess($data['RoleID']);
        }
      } else {
        if(!$this->CommonModel->checkPageActionWeb('user/roles','access_add',$this->session->userdata('RoleName'))){
            redirect('/');
        }
      }
      $data['roles']=$this->UserModel->rolesdata();
      $data['urls']=$this->CommonModel->getURLs();
      $this->load->view('header');
      $this->load->view('user/rolesadd',$data);
      $this->load->view('footer');
    }
    function userlist(){
      $this->CommonModel->checkPageAccessWeb('user/userlist',$this->session->userdata('RoleName'));
      $data=array();
      $data['roles']=$this->UserModel->rolesdataUser();
      $this->load->view('header');
      $this->load->view('user/userlist',$data);
      $this->load->view('footer');      
    }
  public function add($id=''){
    $data=array();
    $data['id']=$id;
    $data['roles']=$this->UserModel->rolesdataUser();

    if(!empty($id)){
      $ids=encryptor($id,'decrypt');
      if(empty($ids)){
        redirect('/');
      } else {
        $data['userdata']=$this->UserModel->getUserData($ids);
      }
      // edit link
      if(!$this->CommonModel->checkPageActionWeb('user/userlist','access_edit',$this->session->userdata('RoleName'))){
          redirect('/');
      }
    } else {
      // add link
      if(!$this->CommonModel->checkPageActionWeb('user/add','access_add',$this->session->userdata('RoleName'))){
        redirect('/');
      }
    }
    $this->load->view('header');
    $this->load->view('user/add',$data);
    $this->load->view('footer');
  }
  function mappeduserdata(){
    $this->CommonModel->checkPageAccessWeb('user/mappeduserdata',$this->session->userdata('RoleName'));
    $data=array();
    $data['rolesData']=$this->UserModel->rolesdataUser();
    $this->load->view('header');
    $this->load->view('user/mappeduserdata',$data);
    $this->load->view('footer');      
  }

    function pdf(){
      $this->load->library('Pdf');
      $msg='';
      $msg = $this->load->view('welcome_message', '', true);

      $pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
      $pdf->SetTitle('My Title');
      $pdf->SetHeaderMargin(30);
      $pdf->SetTopMargin(20);
      $pdf->setFooterMargin(20);
      $pdf->SetAutoPageBreak(true);
      $pdf->SetAuthor('Author');
      $pdf->SetDisplayMode('real', 'default');
      $pdf->AddPage();      
      //$pdf->Write(5, $msg);
      $pdf->writeHTML($msg, true, false, true, false, '');
      $pdf->Output(__DIR__ . '../../../assets/pdf/Delivery_Note.pdf', 'F');
    }
    function testphp(){
      //phpinfo();
              $ci = get_instance();
              $ci->load->library('email');
              $config['protocol'] = $this->config->item('email_protocol');
              $config['smtp_host'] = $this->config->item('email_smtp_host');
              $config['smtp_port'] = $this->config->item('email_smtp_port');
              $config['smtp_user'] = $this->config->item('email_smtp_user');
              $config['smtp_pass'] = $this->config->item('email_smtp_pass');
              $config['charset'] = $this->config->item('email_charset');
              $config['mailtype'] = $this->config->item('email_mailtype');
              $config['newline'] = $this->config->item('email_newline');
              $config['smtp_crypto'] = 'SSL';

              $ci->email->initialize($config);
              $ci->email->from($this->config->item('email_from_main'), $this->config->item('email_name_main'));
              $ci->email->to('gautam.kumar02@rvsolutions.in');
              $ci->email->subject('test');
              $ci->email->message('test mail');           
            if($ci->email->send()){
              $response=array('code'=>16,'msg'=>'new password has generated. Please check your email for new password');
            } else {
              $response=array('code'=>18,'msg'=>$this->config->item('errCodes')[18]);
            }
            echo "<pre>"; print_r($response); echo "</pre>";
    }

}
