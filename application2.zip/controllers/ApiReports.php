<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class ApiReports extends CI_Controller {
	public function __construct()
	{
		parent :: __construct();
		$this->load->model('FacilityModel');
		$this->load->model('ReportModel');
	}
	
	public function index(){
	}
	function checklistData(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$userId=$data1['userID'];
					$search=array();
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					$userId=$this->session->userdata('UserID');
					$search=$this->input->post();
					$roleName=$this->session->userdata('RoleName');
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		if($userId>0 && !empty($roleName) ){
			if($search['search_type']=='State'){
				$facilityData=$this->ReportModel->checklistData($userId,$roleName,$search);
			} else{
				$facilityData=$this->ReportModel->checklistDataNational($userId,$roleName,$search);	
			}
			
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}
		$response=array(
		    "draw"              =>  $search['draw'],
		    "recordsTotal"      =>  $facilityData['totalData'],
		    "recordsFiltered"   =>  $facilityData['totalFilter'],
		    "data"              =>  $facilityData['data']
		);
		echo json_encode($response);
		exit;
	}
	
	function checklistDataApp(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$search=array();
					if(isset($data1['search_state'])){ if(!empty($data1['search_state'])){ $search['search_state']=$data1['search_state']; } }
					if(isset($data1['search_district'])){ if(!empty($data1['search_district'])){ $search['search_district']=$data1['search_district']; } }
					if(isset($data1['search_facility'])){ if(!empty($data1['search_facility'])){ $search['search_facility']=$data1['search_facility']; } }

					if(isset($data1['MappedState'])){ if(!empty($data1['MappedState'])){ $search['MappedState']=$data1['MappedState']; } }
					if(isset($data1['MappedDistrict'])){ if(!empty($data1['MappedDistrict'])){ $search['MappedDistrict']=$data1['MappedDistrict']; } }
					//$search=  //search_state search_district search_facility
					$userId=$this->session->userdata('UserID');
					$roleName=$data1['RoleName'];
					//$userId=$data1['userID'];
					//$search=array();
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					redirect('/');
					/*$userId=$this->session->userdata('UserID');
					$search=$this->input->post();
					$roleName=$this->session->userdata('RoleName');*/
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		if($userId>0 && !empty($roleName) ){
			$facilityData=$this->ReportModel->checklistDataApp($userId,$roleName,$search);
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}
		echo json_encode($facilityData);
		exit;
	}
    public function getanalysis() {
        if ($this->CommonModel->checkAPIWebUser()) {
            $searchData = $this->input->post();
            if($this->session->userdata('RoleName')=='State'){
                $searchData['cond']=array('mappedField'=>'f.StateID','mappedData'=>$this->session->userdata('MappedState'));
            }
            if($this->session->userdata('RoleName')=='District'){
                $searchData['cond']=array('mappedField'=>'f.DistrictID','mappedData'=>$this->session->userdata('MappedDistrict'));
            }
            if($this->session->userdata('RoleName')=='Facility'){
                $searchData['cond']=array('mappedField'=>'um.UserID','mappedData'=>$this->session->userdata('UserID'));
            }
            $searchData['search_months'] = $this->input->post('search_months');
            $searchData['search_years'] = $this->input->post('search_years');
            $data = $this->ReportModel->getanalysis($searchData);

            $json_data = array(
                "draw" => intval($data['draw']),
                "recordsTotal" => intval($data['totalData']),
                "recordsFiltered" => intval($data['totalFilter']),
                "data" => $data['data']
            );
            echo json_encode($json_data);
        } else {
            $json_data = array(
                "draw" => 0,
                "recordsTotal" => 0,
                "recordsFiltered" => 0,
                "data" => array()
            );
            echo json_encode($json_data);            
        }
    }	











}