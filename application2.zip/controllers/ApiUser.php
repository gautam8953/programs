<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ApiUser extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //check_user();
        $this->load->model('UserModel');
    }

    public function index() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey']=$this->session->userdata('APIKey'); 
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey']=$this->session->userdata('APIKey'); 
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    //$data = $this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(isset($dataHeader['device']) && $dataHeader['device']=='app'){
            $response['APIKey']=$this->session->userdata('APIKey');            
        }
        echo json_encode($response);
        exit;
    }

    public function login() {
        $this->session->sess_regenerate(false);
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    $response['code'] = '7';
                    $response['msg'] = $this->config->item('errCodes')[7];
                } else {
                    $data = $this->CommonModel->getApiData();
                    $username = trim($data['username']);
                    $password = trim($data['password']);
                    $ip = $this->input->ip_address();
                    $device='App';
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    redirect('/');
                } else {
                    $data = $this->input->post();
                    $username = trim($data['username']);
                    $password = trim($data['password']);
                    $ip = $this->input->ip_address();
                    $device='Web';
                    if ($this->session->userdata('valuecaptchaCode') == trim($data['captcha'])) {
                        
                    } else {
                        $response['code'] = '12';
                        $response['msg'] = $this->config->item('errCodes')[12];
                        echo json_encode($response);
                        exit;
                    }
                }
            } else {
                redirect('/');
            }
        }
        if (!empty($username) && !empty($password)) {
            $response = $this->UserModel->loginCheck($username, md5($password), $ip,$device);
        } else {
            $response['code'] = '2';
            $response['msg'] = $this->config->item('errCodes')[2];
        }
        echo json_encode($response);
        exit;
    }

    public function logout() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    $response = $this->UserModel->logout($dataHeader['token']);
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            $this->session->sess_destroy();
            session_destroy();
            $this->session->sess_regenerate(true);
            redirect('/');
        }
        echo json_encode($response);
        exit;
    }

    function roleData(){
        $response=array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        $data=array();
        $this->load->model('UserModel');
        if(isset($dataHeader['device']) || isset($dataHeader['token'])){
            if($this->input->method(true) == 'POST'){
                if($this->CommonModel->checkAppRequest($dataHeader)){
                    // get data and process api requrest
                    $data1=$this->CommonModel->getApiData();
                    $userID=$data1['UserID'];
                } else {
                    $response['code']='5';
                    $response['msg']=$this->config->item('errCodes')[5];
                    echo json_encode($response);
                    exit;
                }               
            } else {
                $response['code']='8';
                $response['msg']=$this->config->item('errCodes')[8];
                echo json_encode($response);
                exit;
            }
        } else {
            if($this->input->method(true) == 'POST'){
                if($this->CommonModel->checkAPIWebUser()){
                    // get data and process web requrest
                    $userID=$this->session->userdata('UserID');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($userID)){
            $response=$this->UserModel->roleData($userID);
        } else {
            $response['code']='9';
            $response['msg']=$this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit; 
    }
    function getSearchFacilityNoUser(){
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $search_district=$this->input->post('search_district');
                    $draw=$this->input->post('draw');
                    $searchData=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $json_data=array(
            "draw"              =>  $draw,
            "recordsTotal"      =>  '0',
            "recordsFiltered"   =>  '0',
            "data"              =>  array()
        );
        if(!empty($search_district)){
            $data=$this->UserModel->getFacilityData($search_district,$searchData);
            $json_data=array(
                "draw"              =>  intval($draw),
                "recordsTotal"      =>  intval($data['totalData']),
                "recordsFiltered"   =>  intval($data['totalFilter']),
                "data"              =>  $data['data']
            );
        }
        echo json_encode($json_data);
        exit;        
    }
    function getSearchFacility(){
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $search_state=$this->input->post('search_state');
                    $search_district=$this->input->post('search_district');
                    $draw=$this->input->post('draw');
                    $searchData=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $json_data=array(
            "draw"              =>  $draw,
            "recordsTotal"      =>  '0',
            "recordsFiltered"   =>  '0',
            "data"              =>  array()
        );
        $RoleName=$this->session->userdata('RoleName');
        if($RoleName=='Ministry' || $RoleName=='State' || $RoleName=='District'){
            $data=$this->UserModel->getFacilityData($search_district,$searchData,$search_state);
            $json_data=array(
                "draw"              =>  intval($draw),
                "recordsTotal"      =>  intval($data['totalData']),
                "recordsFiltered"   =>  intval($data['totalFilter']),
                "data"              =>  $data['data']
            );
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];            
        }
        echo json_encode($json_data);
        exit;        
    }
    function map_facility(){
        $response = array();
        $dataHeader = apache_request_headers();
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $mapType='';
                    $facilities = $this->input->post('facilities');
                    if($this->input->post('mapType')!=''){
                        $mapType=$this->input->post('mapType');
                    }                    
                    if(!empty($facilities)){
                        foreach ($facilities as $key => $value) {
                            $data['facilities'][]=encryptor($value['value'],'decrypt');
                        }
                    }
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $RoleName=$this->session->userdata('RoleName');
        if(!empty($data['facilities']) && $mapType!='' && ($RoleName=='Ministry' || $RoleName=='State' || $RoleName=='District') ){
            $response=$this->UserModel->mapFacility($data['facilities'],$this->session->userdata('UserID'),$mapType);
        } else {
            $response['code'] = '8';
            $response['msg'] = $this->config->item('errCodes')[8];
        }
        echo json_encode($response);
        exit;
    }
    function getSearchFacilityAssessment(){
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $search_district=$this->input->post('search_district');
                    $draw=$this->input->post('draw');
                    $searchData=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $json_data=array(
            "draw"              =>  $draw,
            "recordsTotal"      =>  '0',
            "recordsFiltered"   =>  '0',
            "data"              =>  array()
        );
        $RoleName=$this->session->userdata('RoleName');
        if(!empty($search_district) && ($RoleName=='Ministry' || $RoleName=='State' || $RoleName=='District')){
            $data=$this->UserModel->getFacilityAssessmentData($search_district,$searchData);
            $json_data=array(
                "draw"              =>  intval($draw),
                "recordsTotal"      =>  intval($data['totalData']),
                "recordsFiltered"   =>  intval($data['totalFilter']),
                "data"              =>  $data['data']
            );
        } else {
            $response['code'] = '8';
            $response['msg'] = $this->config->item('errCodes')[8];            
        }
        echo json_encode($json_data);
        exit;        
    }
    function failitiesAssessment(){
        $response = array();
        $dataHeader = apache_request_headers();
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $mapType='';
                    $facilities = $this->input->post('facilities');
                    if($this->input->post('mapType')!=''){
                        $mapType=$this->input->post('mapType');
                    }                    
                    if(!empty($facilities)){
                        foreach ($facilities as $key => $value) {
                            $data['facilities'][]=encryptor($value['value'],'decrypt');
                        }
                    }
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $RoleName=$this->session->userdata('RoleName');
        if(!empty($data['facilities']) && $mapType!='' && ($RoleName=='Ministry' || $RoleName=='State' || $RoleName=='District') ){
            $response=$this->UserModel->failitiesAssessment($data['facilities'],$this->session->userdata('UserID'),$mapType);
        } else {
            $response['code'] = '8';
            $response['msg'] = $this->config->item('errCodes')[8];
        }
        echo json_encode($response);
        exit;
    }
    function forgetpassword(){
        $response = array();
        $dataHeader = apache_request_headers();
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $userId=$data['username'];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                $userId = $this->input->post('username');
            } else {
                redirect('/');
            }
        }        
        if(!empty($userId) ){
            $response=$this->UserModel->forgetpassword($userId);
        } else {
            $response['code'] = '8';
            $response['msg'] = $this->config->item('errCodes')[8];
        }
        echo json_encode($response);
        exit;        
    }
    function changepassword(){
        $response = array();
        $dataHeader = apache_request_headers();
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $userId=$data['username'];
                    $oldPassword=$data['oldPassword'];
                    $newpassword=$data['newpassword'];
                    $confirmPassword=$data['confirmPassword'];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                $userId = $this->session->userdata('UserName');
                $oldPassword=$this->input->post('oldPassword');
                $newpassword=$this->input->post('newPassword');
                $confirmPassword=$this->input->post('confirmPassword');
            } else {
                redirect('/');
            }
        }
        if(!empty($userId) && !empty($oldPassword) && !empty($newpassword) && !empty($confirmPassword) ){
            if($newpassword==$confirmPassword){
                $checkPswrd=$this->CommonModel->checkPassword($confirmPassword);
                if(empty($checkPswrd)){
                    if($oldPassword!=$confirmPassword){
                        $response=$this->UserModel->changepassword($userId,$oldPassword,$confirmPassword);
                    } else {
                        $response['code'] = '16';
                        $response['msg'] = 'old and new passwords must be different';                        
                    }
                } else {
                    $response['code'] = '16';
                    $response['msg'] = $checkPswrd;
                }                
            } else {
                $response['code'] = '16';
                $response['msg'] = 'new and confirm password must be same';
            }            
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit;        
    }
    function getlaqshyaFacilityData(){
        $response = array();
        $dataHeader = apache_request_headers();
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $data=array();
                    $search=array();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                    $search=array();
                    $search['UserID']=$this->session->userdata('UserID');
                    $search['RoleName']=$this->session->userdata('RoleName');
                    $search['mapped']='';
                    if($this->session->userdata('RoleName')=='State'){
                        $search['mapped']=$this->session->userdata('MappedState');
                    }
                    if($this->session->userdata('RoleName')=='District'){
                        $search['mapped']=$this->session->userdata('MappedDistrict');  
                    }
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($data) ){
            $response=$this->CommonModel->getlaqshyaFacilityData($data,$search);
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit;        
    }
    function getlaqshyabaselrData(){
        $response = array();
        $dataHeader = apache_request_headers();
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $data=array();
                    $search=array();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                    $search=array();
                    $search['UserID']=$this->session->userdata('UserID');
                    $search['RoleName']=$this->session->userdata('RoleName');
                    $search['mapped']='';
                    if($this->session->userdata('RoleName')=='State'){
                        $search['mapped']=$this->session->userdata('MappedState');
                    }
                    if($this->session->userdata('RoleName')=='District'){
                        $search['mapped']=$this->session->userdata('MappedDistrict');  
                    }
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($data) ){
            $response=$this->CommonModel->getlaqshyabaselrData($data,$search);
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit;        
    }
    function getlaqshyabaseotData(){
        $response = array();
        $dataHeader = apache_request_headers();
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $data=array();
                    $search=array();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                    $search=array();
                    $search['UserID']=$this->session->userdata('UserID');
                    $search['RoleName']=$this->session->userdata('RoleName');
                    $search['mapped']='';
                    if($this->session->userdata('RoleName')=='State'){
                        $search['mapped']=$this->session->userdata('MappedState');
                    }
                    if($this->session->userdata('RoleName')=='District'){
                        $search['mapped']=$this->session->userdata('MappedDistrict');  
                    }
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($data) ){
            $response=$this->CommonModel->getlaqshyabaseotData($data,$search);
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit;        
    }
    function getlaqshyalrData(){
        $response = array();
        $dataHeader = apache_request_headers();
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $data=array();
                    $search=array();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                    $search=array();
                    $search['UserID']=$this->session->userdata('UserID');
                    $search['RoleName']=$this->session->userdata('RoleName');
                    $search['mapped']='';
                    if($this->session->userdata('RoleName')=='State'){
                        $search['mapped']=$this->session->userdata('MappedState');
                    }
                    if($this->session->userdata('RoleName')=='District'){
                        $search['mapped']=$this->session->userdata('MappedDistrict');  
                    }
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($data) ){
            $response=$this->CommonModel->getlaqshyalrData($data,$search);
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit;        
    }
    function getlaqshyaotData(){
        $response = array();
        $dataHeader = apache_request_headers();
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $data=array();
                    $search=array();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                    $search=array();
                    $search['UserID']=$this->session->userdata('UserID');
                    $search['RoleName']=$this->session->userdata('RoleName');
                    $search['mapped']='';
                    if($this->session->userdata('RoleName')=='State'){
                        $search['mapped']=$this->session->userdata('MappedState');
                    }
                    if($this->session->userdata('RoleName')=='District'){
                        $search['mapped']=$this->session->userdata('MappedDistrict');  
                    }
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($data) ){
            $response=$this->CommonModel->getlaqshyaotData($data,$search);
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit;        
    }
    function profile(){
        $response = array();
        $response['postedData']['request']=$_REQUEST;
        $response['postedData']['files']=$_FILES;

        $dataHeader = apache_request_headers();
        $data=array();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest                    
                    $data1 = $this->CommonModel->getApiData();
                    $data=array();
                    if(!empty($data1['FacilityName'])){
                        //$data['facility']['FacilityName']=$this->input->post('FacilityName');
                        $data['facility']['FacilityNumber']=$data1['FacilityNumber'];
                        $data['facility']['Address']=$data1['Address'];
                        $data['facility']['PinCode']=$data1['PinCode'];
                        $data['facility']['landLine']=$data1['landLine'];
                        $data['facility']['Latitude']=$data1['Latitude'];
                        $data['facility']['Longitude']=$data1['Longitude'];
                        $data['facility']['Altitude']=$data1['Altitude'];
                        $data['facility']['services']=$data1['services'];
                    }

                    if(!empty($data1['FirstName_main'])){
                        $data['main']['FirstName']=$data1['FirstName_main'];
                        $data['main']['LastName']=$data1['LastName_main'];
                        $data['main']['Designation']=$data1['Designation_main'];
                        $data['main']['Mobile']=$data1['Mobile_main'];
                        $data['main']['Email']=$data1['Email_main'];
                        if(!empty($data1['Pic_main']) && !empty($data1['Pic_main_name'])){
                            $nameArr=explode('.', $data1['Pic_main_name']);
                            if(in_array(strtolower(end($nameArr)),$this->config->item('ImageTypes')) ) {
                                $Pic_main_name=date('Y-m-d-H-i-s').preg_replace('/[^A-Za-z0-9\-]/', '', $data1['Pic_main_name']);
                                $Pic_main_string = $data1['Pic_main'];
                                $ImageMain = 'assets/uploads/profile/'.$Pic_main_name;
                                if(!empty($Pic_main_string) || $Pic_main_string != NULL)
                                {
                                  file_put_contents($ImageMain, base64_decode($Pic_main_string));
                                }
                                $data['main']['Pic'] = 'assets/uploads/profile/'.$Pic_main_name;
                            } else {
                                $response['code'] = '16';
                                $response['msg'] = 'Please upload only jpg,png,jpeg,bmp files';
                                exit;
                            }

                        }
                    }
                    if(!empty($data1['FirstName_nodal'])){
                        $data['nodal']['FirstName']=$data1['FirstName_nodal'];
                        $data['nodal']['LastName']=$data1['LastName_nodal'];
                        $data['nodal']['Designation']=$data1['Designation_nodal'];
                        $data['nodal']['Mobile']=$data1['Mobile_nodal'];
                        $data['nodal']['Email']=$data1['Email_nodal'];
                        if(!empty($data1['Pic_nodal']) && !empty($data1['Pic_nodal_name'])){
                            $nameArr=explode('.', $data1['Pic_nodal_name']);
                            if(in_array(strtolower(end($nameArr)),$this->config->item('ImageTypes')) ) {
                                $Pic_nodal_name=date('Y-m-d-H-i-s').preg_replace('/[^A-Za-z0-9\-]/', '', $data1['Pic_nodal_name']);
                                $Pic_nodal_string = $data1['Pic_nodal'];
                                $ImageMain = 'assets/uploads/profile/'.$Pic_nodal_name;
                                if(!empty($Pic_nodal_string) || $Pic_nodal_string != NULL)
                                {
                                  file_put_contents($ImageMain, base64_decode($Pic_nodal_string));
                                }
                                $data['nodal']['Pic'] = 'assets/uploads/profile/'.$Pic_nodal_name;
                            } else {
                                $response['code'] = '16';
                                $response['msg'] = 'Please upload only jpg,png,jpeg,bmp files';
                                exit;
                            }
                        }
                    }
                    $userID=$this->session->userdata('UserID');
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=array();
                    if($this->input->post('FacilityName')!=''){
                        //$data['facility']['FacilityName']=$this->input->post('FacilityName');
                        $data['facility']['FacilityNumber']=$this->input->post('FacilityNumber');
                        $data['facility']['Address']=$this->input->post('Address');
                        $data['facility']['PinCode']=$this->input->post('PinCode');
                        $data['facility']['landLine']=$this->input->post('landLine');
                        $data['facility']['Latitude']=$this->input->post('Latitude');
                        $data['facility']['Longitude']=$this->input->post('Longitude');
                        $data['facility']['Altitude']=$this->input->post('Altitude');
                        $data['facility']['services']=$this->input->post('services');
                    }
                    if($this->input->post('FirstName_main')!=''){
                        $data['main']['FirstName']=$this->input->post('FirstName_main');
                        $data['main']['LastName']=$this->input->post('LastName_main');
                        $data['main']['Designation']=$this->input->post('Designation_main');
                        $data['main']['Mobile']=$this->input->post('Mobile_main');
                        $data['main']['Email']=$this->input->post('Email_main');
                        if(isset($_FILES['Pic_main'])){
                            if($_FILES['Pic_main']['size']>0 && $_FILES['Pic_main']['error']=='' && $_FILES['Pic_main']['name']!='' ){
                                if($_FILES['Pic_main']['size']<500000){
                                    $ext = pathinfo($_FILES['Pic_main']['name'], PATHINFO_EXTENSION);
                                    $ext=strtolower($ext);
                                    if(in_array($ext,$this->config->item('ImageTypes')) ) {
                                      $ImageMain=date('Y-m-d-H-i').preg_replace('/[^A-Za-z0-9\-]/', '', $_FILES['Pic_main']['name']).'.'.$ext;
                                      if(!is_file('assets/uploads/profile/'.$ImageMain)){
                                        if(move_uploaded_file($_FILES['Pic_main']['tmp_name'],"assets/uploads/profile/".$ImageMain)){
                                            $data['main']['Pic'] = 'assets/uploads/profile/'.$ImageMain;
                                        } else {
                                            $response['code'] = '4';
                                            $response['msg'] = $this->config->item('errCodes')[4];
                                            exit;
                                        }
                                        } else {
                                            $response['code'] = '16';
                                            $response['msg'] = 'Please change image name';
                                            exit;
                                        }
                                    } else {
                                        $response['code'] = '16';
                                        $response['msg'] = 'Please uplaod only excel files';
                                        exit;                                        
                                    }

                                } else {
                                    $response['code'] = '16';
                                    $response['msg'] = 'image file size should less than 500000 KB';
                                    exit;
                                }
                            }
                        }
                    }
                    if($this->input->post('FirstName_nodal')!=''){
                        $data['nodal']['FirstName']=$this->input->post('FirstName_nodal');
                        $data['nodal']['LastName']=$this->input->post('LastName_nodal');
                        $data['nodal']['Designation']=$this->input->post('Designation_nodal');
                        $data['nodal']['Mobile']=$this->input->post('Mobile_nodal');
                        $data['nodal']['Email']=$this->input->post('Email_nodal');
                        if(isset($_FILES['Pic_nodal'])){
                            if($_FILES['Pic_nodal']['size']>0 && $_FILES['Pic_nodal']['error']=='' && $_FILES['Pic_nodal']['name']!='' ){
                                if($_FILES['Pic_nodal']['size']<500000){
                                    $ext = pathinfo($_FILES['Pic_nodal']['name'], PATHINFO_EXTENSION);
                                    $ext=strtolower($ext);
                                    if(in_array($ext,$this->config->item('ImageTypes')) ) {
                                      $ImageNodal=date('Y-m-d-H-i').preg_replace('/[^A-Za-z0-9\-]/', '', $_FILES['Pic_nodal']['name']).'.'.$ext;
                                      if(!is_file('assets/uploads/profile/'.$ImageNodal)){
                                        if(move_uploaded_file($_FILES['Pic_nodal']['tmp_name'],"assets/uploads/profile/".$ImageNodal)){
                                            $data['nodal']['Pic']= 'assets/uploads/profile/'.$ImageNodal;
                                        } else {
                                            $response['code'] = '4';
                                            $response['msg'] = $this->config->item('errCodes')[4];
                                            exit;
                                        }
                                        } else {
                                            $response['code'] = '16';
                                            $response['msg'] = 'Please change image name';
                                            exit;
                                        }
                                    } else {
                                        $response['code'] = '16';
                                        $response['msg'] = 'Please uplaod only excel files';
                                        exit;                                        
                                    }
                                } else {
                                    $response['code'] = '9';
                                    $response['msg'] = 'image file size should less than 500000 KB';
                                    exit;
                                }
                            }
                        }
                    }
                    $userID=$this->session->userdata('UserID');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($data) && !empty($userID) ){
            $response=$this->UserModel->profileUpdate($data,$userID);
            
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit;        
    }
    function checkFacilityAssessment(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $searchType=$data1['searchType'];
                    $UserID=$this->session->userdata('UserID');
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $searchType=$this->input->post('searchType');
                    $UserID=$this->session->userdata('UserID');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(isset($searchType) && !empty($searchType) && isset($UserID) && !empty($UserID) ){
            $response=$this->CommonModel->checkFacilityAssessment($searchType,$UserID);
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit;
    }
    function getAllStates(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $response=$this->CommonModel->getAllStates();
        echo json_encode($response);
        exit;
    }

    function getProfile(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $RoleName=$data1['RoleName'];
                    $UserID=$this->session->userdata('UserID');
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($RoleName) && !empty($UserID)){
            if($RoleName=='Facility'){
              $response['facility']=$this->UserModel->getFacilityDetails($UserID);
            }
            $response['main']=$this->UserModel->getProfileDetails($UserID,'main');
            if($RoleName!='Facility' ){
              $response['nodal']=$this->UserModel->getProfileDetails($UserID,'nodal');          
            }            
        }
        $response['code']=0;
        $response['UserID']=$UserID;
        $response['RoleName']=$RoleName;
        echo json_encode($response);
        exit;
    }

    function getStateData(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $data['state']=$data1['state'];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data['state']=$this->input->post('state');
                    $data['mappedData']= $this->session->userdata('MappedState');
                    $data['mappedField']='f.StateID';
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $response['code']=0;
        $response['data']=$this->CommonModel->getDashboardData($data);
        echo json_encode($response);
        exit;
    }
    function getMinistryDashboardData(){
        $response = array();
        $dataHeader = apache_request_headers();
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $data=array();
                    $search=array();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                    $search=array();
                    $search['UserID']=$this->session->userdata('UserID');
                    $search['RoleName']=$this->session->userdata('RoleName');
                    $search['mapped']='';
                    if($this->session->userdata('RoleName')=='State'){
                        $search['mapped']=$this->session->userdata('MappedState');
                    }
                    if($this->session->userdata('RoleName')=='District'){
                        $search['mapped']=$this->session->userdata('MappedDistrict');  
                    }
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($data) ){
            $response=$this->CommonModel->getMinistryDashboardData($data,$search);
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit;        
    }
    function getMinistryChart(){
        $response=array();
        $data=array();
        $searchData=$this->input->post('searchType');
        $searchDate=$this->input->post('searchDate');
        $state=$this->input->post('state');
        $district=$this->input->post('district');
        $facility=$this->input->post('facility');
        if($this->session->userdata('RoleName')=='State'){
            $data['cond']=array('mappedField'=>'f.StateID','mappedData'=>$this->session->userdata('MappedState'));
        }
        if($this->session->userdata('RoleName')=='District'){
            $data['cond']=array('mappedField'=>'f.DistrictID','mappedData'=>$this->session->userdata('MappedDistrict'));
        }
        if($this->session->userdata('RoleName')=='Facility'){
            $data['cond']=array('mappedField'=>'um.UserID','mappedData'=>$this->session->userdata('UserID'));
        }

        switch ($searchData) {
            case 'piechart_MatDeath':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->piechart_MatDeath($data);
                break;
            case 'piechart_NeonDeath':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->piechart_NeonDeath($data);
                break;
            case 'piechart_StillBirth':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->piechart_StillBirth($data);
                break;
            case 'piechart_Deliveries':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->piechart_Deliveries($data);
                break;
            case 'chart_aph':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->chart_aph($data);
                break;
            case 'chart_pih':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->chart_pih($data);
                break;
            case 'chart_sepsis':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->chart_sepsis($data);
                break;
            case 'chart_asphyxia':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->chart_asphyxia($data);
                break;
            case 'chart_partograph':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->chart_partograph($data);
                break;
            case 'chart_birth':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->chart_birth($data);
                break;
            case 'chart_safebirth':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->chart_safebirth($data);
                break;
            case 'chart_safebirthot':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->chart_safebirthot($data);
                break;
            case 'monthly_indicator':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                $response=$this->CommonModel->monthly_indicator($data);
                break;
            case 'faclity_monthly_indicator':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }
                if(!empty($facility)){
                    $data['search'][]=array('field'=>'um.UserID','value'=>$facility);                    
                }
                $response=$this->CommonModel->faclity_monthly_indicator($data);
                break;
            case 'monthly_indicator_state':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                if(!empty($district)){
                    $data['search'][]=array('field'=>'f.DistrictID','value'=>$district);                    
                }
                $response=$this->CommonModel->monthly_indicator($data);
                break;
            case 'monthly_indicator_ministry':
                if(empty($searchDate)){
                    $data['searchDate']=date('Y').'-'.date('m',strtotime("-1 month")).'-01';
                } else {
                    $data['searchDate']=$searchDate.'-01';
                }                
                if(!empty($district)){
                    $data['search'][]=array('field'=>'f.DistrictID','value'=>$district);                    
                }
                if(!empty($state)){
                    $data['search'][]=array('field'=>'f.StateID','value'=>$state);                    
                }
                $response=$this->CommonModel->monthly_indicator($data);
                break;
        }
        echo json_encode($response);
    }

    function getNotification(){
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $draw=$this->input->post('draw');
                    $searchData=$this->input->post();
                    $searchData['RoleName']=$this->session->userdata('RoleName');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }        
        $data=$this->CommonModel->getNotification($searchData);
        $json_data=array(
            "draw"              =>  intval($draw),
            "recordsTotal"      =>  intval($data['totalData']),
            "recordsFiltered"   =>  intval($data['totalFilter']),
            "data"              =>  $data['data']
        );
        echo json_encode($json_data);
        exit;        
    }
    function getuser(){
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($data['search_role'])){
            $response=$this->CommonModel->getuser($data);            
        } else {
            $response=array(
                'code'=>'9',
                'msg'=>$this->config->item('errCodes')[9]
            );
        }
        echo json_encode($response);
        exit;        
    }
    function getstates(){
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $response=$this->CommonModel->getstates($data);
        echo json_encode($response);
        exit;        
    }
    function getdistricts(){
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $response=$this->CommonModel->getdistricts($data);
        echo json_encode($response);
        exit;        
    }
    function getfacilities(){
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $response=$this->CommonModel->getfacilities($data);
        echo json_encode($response);
        exit;        
    }
    public function roles() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $userID=$this->session->userdata('UserID');
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey']=$this->session->userdata('APIKey'); 
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey']=$this->session->userdata('APIKey'); 
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data = $this->input->post();
                    $userID=$this->session->userdata('UserID');                    
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(empty($data['RoleName'])){
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        } else {
            $roles=array(
                'RoleName'=>$data['RoleName'],
                'IsActive'=>(int)$data['IsActive']
            );
            if(isset($data['RoleID']) && encryptor($data['RoleID'],'decrypt')>0){
                $RoleID=encryptor($data['RoleID'],'decrypt');
            } else{
                $RoleID='0';
            }
            $response=$this->UserModel->saveRoles($userID,$roles,$RoleID);
        }
        if(isset($dataHeader['device']) && $dataHeader['device']=='app'){
            $response['APIKey']=$this->session->userdata('APIKey');            
        }
        echo json_encode($response);
        exit;
    }
    public function getUserlist(){
        if ($this->CommonModel->checkAPIWebUser()) {
            $searchData=$this->input->post();
            $data=$this->UserModel->getUserlist($searchData);
            $json_data=array(
                "draw"              =>  intval($searchData['draw']),
                "recordsTotal"      =>  intval($data['totalData']),
                "recordsFiltered"   =>  intval($data['totalFilter']),
                "data"              =>  $data['data']
            );
            echo json_encode($json_data);
        } else {
            $json_data=array(
                "draw"              =>  0,
                "recordsTotal"      =>  0,
                "recordsFiltered"   =>  0,
                "data"              =>  array()
            );
            echo json_encode($json_data);       
        }
    }
    public function add(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }

        if(empty($data['FirstName']) ){
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];            
        } else {
            $dataSave=array();
            $dataSave['UserID']=encryptor($data['UserID'],'decrypt');
            $dataSave['date']=date('Y-m-d H:i:s');
            $dataSave['userID']=$this->session->userdata('UserID');
            $dataSave['user']['usertype']=(int)$data['usertype'];
            $dataSave['user']['FirstName']=$data['FirstName'];
            $dataSave['user']['Password']=$data['Password'];
            $dataSave['user']['IsActive']=(int)$data['IsActive'];
            $dataSave['role']['RoleID']=$data['RoleID'];
            $dataSave['mapping']['search_state']=isset($data['search_state'])?$data['search_state']:'99999';
            $dataSave['mapping']['search_district']=isset($data['search_district'])?$data['search_district']:'99999';
            $dataSave['mapping']['FacilityID']=isset($data['FacilityName'])?$data['FacilityName']:'99999';
            $dataSave['incharge']['Email']=$data['Email'];
            $dataSave['incharge']['Mobile']=$data['Mobile'];
            $dataSave['incharge']['FirstName']=$data['FirstName'];
            if(!empty($data['Password'])){
                $dataSave['user']['hintpswrd']=$data['Password'];
                $dataSave['user']['Password']=md5($data['Password']);
            }
            if(empty($data['UserID'])){
                $dataSave['user']['UserName']=$data['UserName'];
                $dataSave['user']['CreatedOn']=$dataSave['date'];
                $dataSave['user']['CreatedBy']=$dataSave['userID'];
            } else {
                $dataSave['user']['ModifiedOn']=$dataSave['date'];
                $dataSave['user']['ModifiedBy']=$dataSave['userID'];
            }
            $response=$this->UserModel->add($dataSave);
        }
        echo json_encode($response);
        exit;
    }
    public function checkusername(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(empty($data['UserName']) ){
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];            
        } else {
            $response=$this->UserModel->checkusername($data['UserName']);
        }
        echo json_encode($response);
        exit;
    }
    function getUserMapping(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(empty($data['search_user']) ){
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];            
        } else {
            $response=$this->UserModel->getUserMapping($data['search_user']);
        }
        echo json_encode($response);
        exit;
    }
    public function getMappeduserdata(){
        if ($this->CommonModel->checkAPIWebUser()) {
            $searchData=$this->input->post();
            $data=$this->UserModel->getMappeduserdata($searchData);
            $json_data=array(
                "draw"              =>  intval($searchData['draw']),
                "recordsTotal"      =>  intval($data['totalData']),
                "recordsFiltered"   =>  intval($data['totalFilter']),
                "data"              =>  $data['data']
            );
            echo json_encode($json_data);
        } else {
            $json_data=array(
                "draw"              =>  0,
                "recordsTotal"      =>  0,
                "recordsFiltered"   =>  0,
                "data"              =>  array()
            );
            echo json_encode($json_data);       
        }
    }
    public function rolesadd() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $userID=$this->session->userdata('UserID');
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey']=$this->session->userdata('APIKey'); 
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey']=$this->session->userdata('APIKey'); 
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data = $this->input->post();
                    $userID=$this->session->userdata('UserID');                    
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(empty($data['RoleName'])){
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        } else {
            $roles=array(
                'RoleName'=>$data['RoleName'],
                'IsActive'=>(int)$data['IsActive']
            );
            if(isset($data['RoleID']) && encryptor($data['RoleID'],'decrypt')>0){
                $RoleID=encryptor($data['RoleID'],'decrypt');
            } else{
                $RoleID='0';
            }
            $response=$this->UserModel->saveRoles($userID,$roles,$RoleID);
            $RoleID=$response['data'];
            if(!empty($this->input->post('access'))){
                foreach ($this->input->post('access') as $key => $value) {
                  foreach ($value as $keyForm => $valueForm) {
                    $dataSave=array(
                      'user'=>$this->session->userdata('UserID'),
                      'RoleID'=>$RoleID,
                      'frmID'=>$keyForm,
                    );
                    $this->CommonModel->updateRoles($dataSave,$valueForm);            
                  }          
                }
            }
        }
        if(isset($dataHeader['device']) && $dataHeader['device']=='app'){
            $response['APIKey']=$this->session->userdata('APIKey');            
        }
        echo json_encode($response);
        exit;
    }
    function addfacility(){
        $response=array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if(isset($dataHeader['device']) || isset($dataHeader['token'])){
            if($this->input->method(true) == 'POST'){
                if($this->CommonModel->checkAppRequest($dataHeader)){
                    // get data and process api requrest
                    $data1=$this->CommonModel->getApiData();
                } else {
                    $response['code']='5';
                    $response['msg']=$this->config->item('errCodes')[5];
                }               
            } else {
                $response['code']='8';
                $response['msg']=$this->config->item('errCodes')[8];
            }
        } else {
            if($this->input->method(true) == 'POST'){
                if($this->CommonModel->checkAPIWebUser()){
                    // get data and process web requrest
                    $data = $this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($data['FacilityNumber'])){
            $response=$this->CommonModel->addupdatefacilitydetails($data);
        } else {
            $response['code']='9';
            $response['msg']=$this->config->item('errCodes')[9];
        }       
        echo json_encode($response);
        exit;
    }
    public function facilitytype($facilityType=''){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    //$data = $this->CommonModel->getApiData();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    //$data=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(empty($facilityType) ){
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];            
        } else {
            $response=$this->CommonModel->facilitytype($facilityType);
        }
        echo json_encode($response);
        exit;
    }

    
}
