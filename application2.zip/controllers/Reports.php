<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $userID = $this->session->userdata('UserID');
        if (empty($userID)) {
            redirect('user/login');
        }
        $this->load->model('FacilityModel');
    }

	public function index(){
		redirect('/');
	}
	public function checklist(){
		$this->CommonModel->checkPageAccessWeb('reports/checklist',$this->session->userdata('RoleName'));
      	$data=array();
      	$this->load->view('header');
      	$this->load->view('reports/checklist',$data);
		$this->load->view('footer');
	}

	public function osce(){
		$this->CommonModel->checkPageAccessWeb('reports/osce',$this->session->userdata('RoleName'));
      	
		$data=array('OsceID'=>0);
		$uriParam=$this->uri->segment('3');
		if(!empty($uriParam)){
			$data['OsceID']=encryptor($uriParam,'decrypt');
			if(empty($data['OsceID'])){
				redirect('reports/osce');
			} else {
				$data['osceForm']=$this->FacilityModel->oscedataForm($data['OsceID']);
			}
		}
      	$data['osce']=$this->FacilityModel->oscedata($this->session->userdata('UserID'));
      	$this->load->view('header');
      	$this->load->view('reports/osce',$data);
		$this->load->view('footer');
	}
    public function analysis() {
        //$this->CommonModel->checkPageAccessWeb('monthly/index',$this->session->userdata('RoleName'));
        $data = array();
        $data['search_options'] = $this->FacilityModel->getSearchOptions_new();
        $this->load->view('header');
        $this->load->view('reports/analysis', $data);
        $this->load->view('footer');
        //echo "<pre>"; print_r($data); echo "</pre>";

    }


}