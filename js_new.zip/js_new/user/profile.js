$(document).ready(function () {

    $('#profileForm').submit(function() {
        $(this).ajaxSubmit({
          beforeSubmit:  showRequest,
          success: showResponse,
          type: 'POST',
          dataType: 'json',
          data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false; 
    });

});

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="0">Select District</option>');
            if (result.hasOwnProperty('data')) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
        }
    });
}

function checkFile(fileobj) {
    var validExts = new Array(".jpg", ".jpeg", ".png",".bmp",".JPG", ".JPEG", ".PNG",".BMP");
    var fileExt = fileobj.value;
    fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
    if (validExts.indexOf(fileExt) < 0) {
        swal('Please choose only Image file');
        var ids=$(fileobj).attr('id');
        $('#'+ids).val('');
        $("label[for='"+ids+"']").children('span').text('');
        return false;
    }
}

function showResponse(responseText, statusText, xhr, $form)  {
    if(parseInt(responseText.code)==0){
      swal(responseText.msg).then((value) => {
        window.location.replace(window.location.href);
      });
      /*setTimeout(function() { 
        window.location.replace(window.location.href);
      }, 6000);*/
      
      //$("#msgDiv").removeClass('alert-danger');
      //$("#msgDiv").addClass('alert-success').show();
    } else {
      swal(responseText.msg);
      //$("#msgDiv").removeClass('alert-success');
      //$("#msgDiv").addClass('alert-danger').show();
    }    

    
}
function showRequest(formData, jqForm, options) { 
    var check='0';
    // main profile check 
    if($('#FirstName_main').length){
      var main_check='0';
      if($.trim($('#FirstName_main').val())==''){
        check='1';
        $('#FirstName_main').closest('.form-group').addClass('has-error');
      } else {
        $('#FirstName_main').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#Mobile_main').val())==''){
        check='1';
        $('#Mobile_main').closest('.form-group').addClass('has-error');
      } else {
        $('#Mobile_main').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#Email_main').val())==''){
        check='1';
        $('#Email_main').closest('.form-group').addClass('has-error');
      } else {
        $('#Email_main').closest('.form-group').removeClass('has-error');
      }

    }

    if($('#FirstName_nodal').length){
      var main_check='0';
      if($.trim($('#FirstName_nodal').val())==''){
        check='1';
        $('#FirstName_nodal').closest('.form-group').addClass('has-error');
      } else {
        $('#FirstName_nodal').closest('.form-group').removeClass('has-error');
      }
    }
    if($('#FacilityName').length){
      var main_check='0';
      if($.trim($('#FacilityNumber').val())==''){
        check='1';
        $('#FacilityNumber').closest('.form-group').addClass('has-error');
      } else {
        $('#FacilityNumber').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#Latitude').val())==''){
        check='1';
        $('#Latitude').closest('.form-group').addClass('has-error');
      } else {
        $('#Latitude').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#Longitude').val())==''){
        check='1';
        $('#Longitude').closest('.form-group').addClass('has-error');
      } else {
        $('#Longitude').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#Address').val())==''){
        check='1';
        $('#Address').closest('.form-group').addClass('has-error');
      } else {
        $('#Address').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#PinCode').val())==''){
        check='1';
        $('#PinCode').closest('.form-group').addClass('has-error');
      } else {
        $('#PinCode').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('#FacilityTypeDetailID').val())=='' || $('#FacilityTypeDetailID').val()==undefined){
        check='1';
        $('#FacilityTypeDetailID').closest('.form-group').addClass('has-error');
      } else {
        $('#FacilityTypeDetailID').closest('.form-group').removeClass('has-error');
      }
      if($.trim($('[name="services"]').val())==''){
        check='1';
        $('[name="services"]').closest('.form-group').addClass('has-error');
      } else {
        $('[name="services"]').closest('.form-group').removeClass('has-error');
      }

    }


    if(check!='0'){
      return false;
    } else {
        return true;
    }
    return true;
}
function checkFacilityAssessment(ths){
  var params = {};
  var searchType=$(ths).val();
  console.log(searchType);
  params['device'] = 'web';
  params['csrf_token']=$.cookie("csrf_cookie");
  params['searchType'] = searchType;
  $.ajax({
      url: pageMainUrl + 'ApiUser/checkFacilityAssessment',
      data: params,
      type: 'POST',
      dataType: 'json',
      success: function (result) {
          if(result.code=='16'){
            swal(result.msg);
            $('#services_'+result.type).prop('checked',true);
          } else {
            if(searchType=='both'){
              $('[name="ot_services"]').parent().show();
            } else {
              $('[name="ot_services"]').parent().hide();
              $('[name="ot_services"]').attr('checked',false);
            }
          }

      }
  });
     
}
function check_facility(ths){
  if($('#FacilityTypeDetailID option:selected').text()=='Others'){
    $('#facilitytype_other').parent().show();
  } else {
    $('#facilitytype_other').val('').parent().hide();
  }
}