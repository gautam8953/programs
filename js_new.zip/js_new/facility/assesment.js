$(document).ready(function(){

    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl+'ApiFacility/assesmentData', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            if(result.data.facilityName){
              $('#facilityName').html('<option value="'+result.data.facilityUser+'">'+result.data.FacilityName+'</option>');
            }
            /*$('#assessmentDate').val(result.data[0].AssessmentDate);
            $('#assessorsName1').val(result.data[0].AssessorsName1);
            $('#assessorsName2').val(result.data[0].AssessorsName2);
            $('#assesseesName1').val(result.data[0].AssesseesName1);
            $('#assesseesName2').val(result.data[0].AssesseesName2);
            $('#assessmentType').val(result.data[0].AssessmentType);
            $('#submissionDate').val(result.data[0].SubmissionDate);
            $('#facilityAvailable_'+result.data[0].FacilityAvailable).prop('checked',true);*/
        }
    });

    $('#assesmentForm').submit(function() {
        $(this).ajaxSubmit({
          beforeSubmit:  showRequest,
          success: showResponse,
          type: 'POST',
          dataType: 'json',
          data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false; 
    }); 
    assementdataCheck();
    $('.selectpicker').selectpicker('refresh');
});

function showResponse(responseText, statusText, xhr, $form)  {
    $("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
    if(parseInt(responseText.code)==0){
      $("#msgDiv").removeClass('alert-danger');
      $("#msgDiv").addClass('alert-success').show();
    } else {
      $('#assesment').prop('disabled',false);
      $("#msgDiv").removeClass('alert-success');
      $("#msgDiv").addClass('alert-danger').show();
    }
    
    $("#LoginMsg").text(responseText.msg);
    setTimeout(function() { 
    if(parseInt(responseText.code)==0){
      window.location.href = pageMainUrl+"facility/labourFacility/"+responseText.ansId;
    }
    }, 3000);

}
function showRequest(formData, jqForm, options) { 
    var check='0';
    $('#assesment').prop('disabled',true);
    if($('#facilityName').val()=='' || $('#facilityName').val()=='undefined'){
      $('#facilityName').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#facilityName').closest('.form-group').removeClass('has-error');
    }
    if($('#assessmentDate').val()=='' || $('#assessmentDate').val()=='undefined'){
      $('#assessmentDate').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#assessmentDate').closest('.form-group').removeClass('has-error');
    }
    if($('#assessorsName1').val()=='' || $('#assessorsName1').val()=='undefined'){
      $('#assessorsName1').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#assessorsName1').closest('.form-group').removeClass('has-error');
    }
    /*if($('#assessorsName2').val()=='' || $('#assessorsName2').val()=='undefined'){
      $('#assessorsName2').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#assessorsName2').closest('.form-group').removeClass('has-error');
    }*/
    if($('#assesseesName1').val()=='' || $('#assesseesName1').val()=='undefined'){
      $('#assesseesName1').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#assesseesName1').closest('.form-group').removeClass('has-error');
    }
    /*if($('#assesseesName2').val()=='' || $('#assesseesName2').val()=='undefined'){
      $('#assesseesName2').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#assesseesName2').closest('.form-group').removeClass('has-error');
    }*/
    if($('#assessmentType').val()=='' || $('#assessmentType').val()=='undefined'){
      $('#assessmentType').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#assessmentType').closest('.form-group').removeClass('has-error');
    }
    if($('#submissionDate').val()=='' || $('#submissionDate').val()=='undefined'){
      $('#submissionDate').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#submissionDate').closest('.form-group').removeClass('has-error');
    }
    if(check!='0'){
      $('#assesment').prop('disabled',false);
      return false;
    }
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    return true; 
}

function changeFacility(ths){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['facilitySetId']=$(ths).val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/setFacility', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
          assementdataCheck();
        }
    });  
}

function change_district(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType']='facility';
    params['searchData']=$('#search_district').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/getSearchOptions', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#facilityName').html('<option value="">Select Facility</option>');
            if(result.data){
                if(parseInt(result.data.length)>0){
                    $.each(result.data,function(key,val){
                        //$('#facilityName').append($("<option></option>").attr("value",val.UserID).text(val.FacilityName));
                        $('#facilityName').append('<option val="'+val.UserID+'">'+val.FacilityName+'</option>');
                    });
                    $('#facilityName').selectpicker('refresh');
                /*if($('#facilityName').length){
                    if(parseInt($('#facilityName option').length)==2){
                        $('#facilityName').val($('#facilityName option:eq(1)').val());
                        $('#facilityName').trigger('change');
                    }
                }*/
                }                
            }
        }
    });
}

function change_state(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType']='district';
    params['searchData']=$('#search_state').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/getSearchOptions', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#search_district').html('<option value="">Select District</option>');
            if(parseInt(result.data.length)>0){
                $.each(result.data,function(key,val){
                    $('#search_district').append($("<option></option>").attr("value",val.DistrictID).text(val.DistrictName));
                });
            }
            /*if(parseInt($('#search_district option').length)>=2){
                $('#search_district').val($('#search_district option:eq(1)').val());
                change_district();
            }*/
            $('#facilityName').html('<option value="">Select Facility</option>');
        }
    });    
}

function assementdataCheck(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['SurveyID']=$('#SurveyID').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/assementdataCheck', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            if(result.code=='1'){
              console.log('lr incomplete redirect its href got ');
              swal(result.msg)
              .then((value) => {
                window.location.replace(pageMainUrl+result.href);
              });
            }
            if(result.code=='2'){
              swal(result.msg)
              .then((value) => {
                window.location.replace(pageMainUrl+result.href);
              });
              //console.log('no lr and its ot so redirect to fill lr first')
            }
            if(result.basecheck=='3'){
              //console.log('as per page baseline is alreday filled so make baseline disable');
              $('#sequence option:eq(0)').prop('disabled',true);
              $('#sequence').val('2');
            }
            if(result.endcheck=='3'){
              //console.log('end line open so make all disable');
              $('#sequence option:eq(0)').prop('disabled',true);
              $('#sequence option:eq(1)').prop('disabled',true);
              $('#sequence option:eq(2)').prop('disabled',false);
              $('#sequence').val('3');
            }
            $('#sequence').selectpicker('refresh');
        }
    });  
}