$(document).ready(function () {

    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 20,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "order": [[ 0, "desc" ]],
        "ajax": {
            url: pageMainUrl + "ApiFacility/getgapdata",
            type: "post",
            data: function (d) {
                $("#bodyLoad").removeClass('loader');
                $("#loader_overlay").hide();
                d.search_score = $('#search_score').val();
                d.search_cat = $('#search_cat').val();
                d.search_answer = $('#search_answer').val();
                d.search_format = $('#search_format').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        drawCallback: function () {
        },
        "dom":"Blfrtip",
        buttons: [
                   {
                    extend: 'excel',
                    text: 'Export to Excel',
                    extension: '.xlsx',
                    exportOptions: {
                        columns: "thead th:not(.noExport)"
                       
                    },
                   
                  }
            ]



    });


    $('#btn_search').click(function () {
        datatableData.ajax.reload();
    });
     $("#reset_btn").click(function () {
        $('select').prop('selectedIndex', 0);
        $('.selectpicker').selectpicker('refresh');
        datatableData.ajax.reload();
    });

});

function getData(){
    $('#btn_search').trigger('click');
}
