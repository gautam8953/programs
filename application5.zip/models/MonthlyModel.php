<?php

class MonthlyModel extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function saveMonthly($dataSave) {
        $response = array('code' => 15, 'msg' => 'Data saved successfully');
        $monthlyId = 0;
        if (!empty($dataSave)) {
            $this->db->select('MonthlyID,MonthlyStatus');
            $this->db->from('monthly');
            $this->db->where('UserID', $this->session->userdata('facilityUser'));
            //$this->db->where('ReportMonth',date('Y-m-01'));
            $this->db->where('ReportMonth', $dataSave['monthly']['ReportMonth']);
            //$this->db->where('MonthlyStatus <>','1');
            $this->db->order_by('MonthlyID', 'DESC');
            $query = $this->db->get();
            if ($this->session->userdata('facilityUser') != $this->session->userdata('UserID')) {
                $dataSave['monthly']['ParentUserID'] = $this->session->userdata('UserID');
            }
            if ($query->num_rows() >= 1) {
                $dataSave['monthly']['ModifiedOn'] = date('Y-m-01');
                $dataSave['monthly']['ModifiedBy'] = $this->session->userdata('UserID');
                $result_Ans = $query->result();
                $monthlyId = $result_Ans[0]->MonthlyID;
                if ($result_Ans[0]->MonthlyStatus <> 1) {
                    $this->db->where('MonthlyID', $monthlyId);
                    $this->db->update('monthly', $dataSave['monthly']);
                    $response['code'] = 0;
                    $response['status'] = $dataSave['monthly']['MonthlyStatus'];
                    $response['msg'] = 'Data saved successfully';
                } else {
                    $response['code'] = 14;
                    $response['status'] = $dataSave['monthly']['MonthlyStatus'];
                    $response['msg'] = 'Report already submitted';
                }
            } else {
                //$dataSave['monthly']['ReportMonth']=date('Y-m-01');
                $dataSave['monthly']['CreatedOn'] = date('Y-m-d');
                $dataSave['monthly']['CreatedBy'] = $this->session->userdata('UserID');
                if ($this->db->insert('monthly', $dataSave['monthly'])) {
                    $monthlyId = $this->db->insert_id();
                    $response['code'] = 0;
                    $response['monthlyId'] = $monthlyId;
                    $response['status'] = $dataSave['monthly']['MonthlyStatus'];
                    $response['msg'] = 'Data saved successfully';
                } else {
                    $this->db->insert('monthly', $dataSave['monthly']);
                    $monthlyId = $this->db->insert_id();
                    $response['code'] = 0;
                    $response['monthlyId'] = $monthlyId;
                    $response['status'] = $dataSave['monthly']['MonthlyStatus'];
                    $response['msg'] = 'Data saved successfully';
                }
            }

            $this->db->select('onetimeID,onetimeStatus');
            $this->db->from('onetime');
            $this->db->where('UserID', $this->session->userdata('facilityUser'));
            $this->db->order_by('onetimeID', 'DESC');
            $query = $this->db->get();
            if ($dataSave['monthly']['MonthlyStatus'] == '1') {
                $dataSave['oneTime']['onetimeStatus'] = '1';
            } else {
                $dataSave['oneTime']['onetimeStatus'] = '0';
            }
            if ($query->num_rows() >= 1) {
                $result_oneTime = $query->result();
                $onetimeID = $result_oneTime[0]->onetimeID;
                if ($result_oneTime[0]->onetimeStatus != '1') {
                    $this->db->where('onetimeID', $onetimeID);
                    $this->db->update('onetime', $dataSave['oneTime']);
                    $response['oneTime']['code'] = 0;
                    $response['oneTime']['monthlyId'] = $onetimeID;
                    $response['oneTime']['oneTimeStatus'] = $dataSave['oneTime']['onetimeStatus'];
                    $response['oneTime']['msg'] = 'Data updated successfully';
                }
            } else {
                if ($this->session->userdata('facilityUser') != $this->session->userdata('UserID')) {
                    $dataSave['oneTime']['ParentUserID'] = $this->session->userdata('UserID');
                }
                if ($this->db->insert('onetime', $dataSave['oneTime'])) {
                    $onetimeID = $this->db->insert_id();
                    $response['oneTime']['code'] = 0;
                    $response['oneTime']['onetimeID'] = $onetimeID;
                    $response['oneTime']['oneTimeStatus'] = $dataSave['oneTime']['onetimeStatus'];
                    $response['oneTime']['msg'] = 'Data saved successfully';
                } else {
                    $this->db->insert('onetime', $dataSave['oneTime']);
                    $onetimeID = $this->db->insert_id();
                    $response['oneTime']['code'] = 0;
                    $response['oneTime']['onetimeID'] = $onetimeID;
                    $response['oneTime']['oneTimeStatus'] = $dataSave['oneTime']['onetimeStatus'];
                    $response['oneTime']['msg'] = 'Data saved successfully';
                }
            }
        }
        return $response;
    }

    function getMonthly($facilityUser, $rptDate) {
        $response = array();
        $this->db->select('monthly.ReportMonth,monthly.CollectionDate,monthly.TotalDeliveries,monthly.TotalNormalVaginalDeliveries,monthly.TotalAssistedVaginalDeliveries,monthly.TotalCSections,monthly.TotalMaternalDeaths,monthly.MaternalAPH,monthly.MaternalPPH,monthly.MaternalSepsis,monthly.MaternalObstructedLabour,monthly.MaternalPIHEclampsia,monthly.MaternalOthers,monthly.TotalLiveBirths,monthly.TotalStillBirths,monthly.TotalFreshStillBirths,monthly.TotalMaceratedStillBirths,monthly.NumberNeonatalDeaths,monthly.NeonatalPrematurity,monthly.NeonatalSepsis,monthly.NeonatalAsphyxia,monthly.NeonatalOthers,monthly.TotalLowBirthWeightBabies,monthly.TotalPretermDeliveries,monthly.BirthCompanionNos,monthly.SafeBirthChecklist,monthly.CSectionOTSafeChecklist,monthly.RealTimePartograph,monthly.BreastfedNewborns,monthly.MCBSamplingLR,monthly.MCBSamplingOT,monthly.CSectionsInfection,monthly.PretermANCSInFacilitiesSNCU,monthly.NewbornsSNCUAsphyxia,monthly.NewbornsSNCUSepsis,monthly.InbornLBWKMC,monthly.SatisfiedDelivered,monthly.ReorganizedLR,monthly.AdequateStaffLR,monthly.OxytocinCount,monthly.MaternalDeathsReviewed,monthly.NeonatalDeaths,monthly.MaternalMissCases,monthly.ReferralCases,monthly.StockOutsInLR,monthly.StockOutsInOT,monthly.NQASCertification,monthly.MCHDHFunctional,monthly.LaQshyaMentoringVisitsConducted,monthly.QITeamMeetings,monthly.TrainingSessionConducted,monthly.CurrentLabourRoomQualityScore,monthly.CurrentMaternityOTQualityScore,monthly.CurrentOSCEScore,monthly.MonthlyStatus');
        $this->db->from('monthly');
        $this->db->where('monthly.UserID', $facilityUser);
        $this->db->where('monthly.ReportMonth', $rptDate);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            $data = $query->result_array();
            $response['code'] = 0;
            $response['msg'] = $query->num_rows() . ' rows get';
            $response['data'] = $data;
            $response['MonthlyStatus'] = $data[0]['MonthlyStatus'];
            $response['rptDate'] = convert_date_show($rptDate);
        } else {
            $response['code'] = 1;
            $response['msg'] = '0 rows get';
            $response['rptDate'] = convert_date_show($rptDate);
            $response['data'] = array();
        }
        $this->db->select('usermapping.UserID,facilities.FacilityName,states.StateName,states.StateID,district.DistrictID,district.DistrictName,typedetail.TypeDetailID,typedetail.TypeDetailCode');
        $this->db->from('usermapping');
        $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
        $this->db->join('states', 'facilities.StateID=states.StateID', 'left');
        $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'left');
        $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');
        $this->db->where('usermapping.UserID', $facilityUser);
        $this->db->where('usermapping.FacilityID >', '0');
        $this->db->limit('1');
        $result = $this->db->get();
        $dataFacility = $result->result_array();
        $response['FacilityDetails'] = $dataFacility[0];
        return $response;
    }

    function getMonthlyView($page) {
        $response = array();
        $this->db->select('DATE_FORMAT(monthly.ReportMonth,"%M %Y") as ReportMonth,DATE_FORMAT(monthly.CollectionDate,"%d-%m-%Y") as CollectionDate,monthly.TotalDeliveries,monthly.TotalNormalVaginalDeliveries,monthly.TotalAssistedVaginalDeliveries,monthly.TotalCSections,monthly.TotalMaternalDeaths,monthly.MaternalAPH,monthly.MaternalPPH,monthly.MaternalSepsis,monthly.MaternalObstructedLabour,monthly.MaternalPIHEclampsia,monthly.MaternalOthers,monthly.TotalLiveBirths,monthly.TotalStillBirths,monthly.TotalFreshStillBirths,monthly.TotalMaceratedStillBirths,monthly.NumberNeonatalDeaths,monthly.NeonatalPrematurity,monthly.NeonatalSepsis,monthly.NeonatalAsphyxia,monthly.NeonatalOthers,monthly.TotalLowBirthWeightBabies,monthly.TotalPretermDeliveries,monthly.BirthCompanionNos,monthly.SafeBirthChecklist,monthly.CSectionOTSafeChecklist,monthly.RealTimePartograph,monthly.BreastfedNewborns,monthly.MCBSamplingLR,monthly.MCBSamplingOT,monthly.CSectionsInfection,monthly.PretermANCSInFacilitiesSNCU,monthly.NewbornsSNCUAsphyxia,monthly.NewbornsSNCUSepsis,monthly.InbornLBWKMC,monthly.SatisfiedDelivered,monthly.ReorganizedLR,monthly.AdequateStaffLR,monthly.OxytocinCount,monthly.MaternalDeathsReviewed,monthly.NeonatalDeaths,monthly.MaternalMissCases,monthly.ReferralCases,monthly.StockOutsInLR,monthly.StockOutsInOT,monthly.NQASCertification,monthly.MCHDHFunctional,monthly.LaQshyaMentoringVisitsConducted,monthly.QITeamMeetings,monthly.TrainingSessionConducted,monthly.CurrentLabourRoomQualityScore,monthly.CurrentMaternityOTQualityScore,monthly.CurrentOSCEScore,monthly.MonthlyStatus,monthly.UserID');
        $this->db->from('monthly');
        //$this->db->where('monthly.UserID', $facilityUser);
        $this->db->where('monthly.MonthlyID', $page);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            $data = $query->result_array();

            $this->db->select('usermapping.UserID,facilities.FacilityName,states.StateName,states.StateID,district.DistrictID,district.DistrictName,typedetail.TypeDetailID,typedetail.TypeDetailCode');
            $this->db->from('usermapping');
            $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
            $this->db->join('states', 'facilities.StateID=states.StateID', 'left');
            $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'left');
            $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');
            $this->db->where('usermapping.UserID', $data[0]['UserID']);
            $this->db->where('usermapping.FacilityID >', '0');
            $this->db->limit('1');
            $result = $this->db->get();
            $dataFacility = $result->result_array();
            $response['FacilityDetails'] = $dataFacility[0];

            $response['code'] = 0;
            $response['msg'] = $query->num_rows() . ' rows get';
            $response['data'] = $data;
            $response['MonthlyStatus'] = $data[0]['MonthlyStatus'];
        } else {
            $response['code'] = 1;
            $response['msg'] = '0 rows get';
            $response['data'] = array();
        }
        return $response;
    }

    function getOneTime_web($page) {
        $response = array();
        $this->db->select('onetime.BaselineNQASChecklistLR,DATE_FORMAT(onetime.AssessmentMonthLR,"%d-%m-%Y") as AssessmentMonthLR,onetime.BaselineScoreLR,onetime.BaselineNQASChecklistOT,DATE_FORMAT(onetime.AssessmentMonthOT,"%d-%m-%Y") as AssessmentMonthOT,onetime.BaselineScoreOT,onetime.BaselineStaffCompetenceOSCE,onetime.AssessmentMonthOSCE,onetime.BaselineAvgOSCEScore,onetime.QualityTeamFacility,onetime.QualityCircleLR,onetime.QualityCircleOT,onetime.OrientationAttended,onetimeStatus');
        $this->db->from('onetime');
        $this->db->join('monthly', 'monthly.UserID=onetime.UserID', 'inner');
        $this->db->where('monthly.MonthlyID', $page);
        $this->db->group_by(array("onetime.UserID"));
        //$this->db->where('onetime.UserID', $facilityUser);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            $data = $query->result_array();
            if (empty($data[0]['AssessmentMonthLR']) || $data[0]['AssessmentMonthLR'] == '1970-01-01') {
                $data[0]['AssessmentMonthLR'] = '';
            }
            if ($data[0]['BaselineScoreLR'] == null) {
                $data[0]['BaselineScoreLR'] = '';
            }
            if (empty($data[0]['AssessmentMonthOT']) || $data[0]['AssessmentMonthOT'] == '1970-01-01') {
                $data[0]['AssessmentMonthOT'] = '';
            }
            if ($data[0]['BaselineScoreOT'] == null) {
                $data[0]['BaselineScoreOT'] = '';
            }
            $response['code'] = 0;
            $response['onetimeStatus'] = $data[0]['onetimeStatus'];
            $response['msg'] = $query->num_rows() . ' rows get';
            $response['data'] = $data;
        } else {
            $response['code'] = 1;
            $response['msg'] = '0 rows get';
            $response['data'] = array();
        }
        return $response;
    }

    function getSearchData($searchData) {
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
        $col = array(
            0 => 'ReportMonth',
            1 => 'CollectionDate',
            2 => 'MonthlyStatus',
            3 => 'CreatedOn',
        );
        $response = array();
        $this->db->select('monthly.MonthlyID');
        $this->db->from('monthly');

        $this->db->join('usermapping um','monthly.UserID=um.UserID');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');

        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
        //$this->db->where('monthly.UserID', $userID);
        if(!empty($searchData['search_state'])){
            $this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
            $this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
            $this->db->where('monthly.UserID',$searchData['search_facility']);
        }
        if (!empty($searchData['search_months']) && empty($searchData['search_years'])) {
            $this->db->where('MONTH(monthly.ReportMonth)', $searchData['search_months']);
        }
        if (empty($searchData['search_months']) && !empty($searchData['search_years'])) {
            $this->db->where('YEAR(monthly.ReportMonth)', $searchData['search_years']);
        }
        if (!empty($searchData['search_months']) && !empty($searchData['search_years'])) {
            $search_date = $searchData['search_years'] . '-' . $searchData['search_months'] . '-01';
            $this->db->where('monthly.ReportMonth', $search_date);
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);
            if ($searchString == 'Completed') {
                $this->db->where("(monthly.MonthlyStatus='1')", NULL, FALSE);
            } else if ($searchString == 'Incomplete') {
                $this->db->where("(monthly.MonthlyStatus='0')", NULL, FALSE);
            } else {
                $this->db->where("(monthly.CollectionDate='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.CreatedOn='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.ReportMonth='" . date('Y-m-01', strtotime($searchString)) . "' OR f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        $queryTot = $this->db->get();

        $this->db->select('f.facilityName,s.StateName,d.DistrictName,monthly.MonthlyID,monthly.ReportMonth,monthly.CollectionDate,monthly.MonthlyStatus,monthly.CreatedOn');
        $this->db->from('monthly');

        $this->db->join('usermapping um','monthly.UserID=um.UserID');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');

        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
        //$this->db->where('monthly.UserID', $userID);
        if(!empty($searchData['search_state'])){
            $this->db->where('s.StateID',$searchData['search_state']);
        }
        if(!empty($searchData['search_district'])){
            $this->db->where('d.DistrictID',$searchData['search_district']);
        }
        if(!empty($searchData['search_facility'])){
            $this->db->where('monthly.UserID',$searchData['search_facility']);
        }
        if (!empty($searchData['search_months']) && empty($searchData['search_years'])) {
            $this->db->where('MONTH(monthly.ReportMonth)', $searchData['search_months']);
        }
        if (empty($searchData['search_months']) && !empty($searchData['search_years'])) {
            $this->db->where('YEAR(monthly.ReportMonth)', $searchData['search_years']);
        }
        if (!empty($searchData['search_months']) && !empty($searchData['search_years'])) {
            $search_date = $searchData['search_years'] . '-' . $searchData['search_months'] . '-01';
            $this->db->where('monthly.ReportMonth', $search_date);
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);
            if ($searchString == 'Completed') {
                $this->db->where("(monthly.MonthlyStatus='1')", NULL, FALSE);
            } else if ($searchString == 'Incomplete') {
                $this->db->where("(monthly.MonthlyStatus='0')", NULL, FALSE);
            } else {
                $this->db->where("(monthly.CollectionDate='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.CreatedOn='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.ReportMonth='" . date('Y-m-01', strtotime($searchString)) . "' OR f.facilityName like '%".$searchString."%' OR d.DistrictName like '%".$searchString."%' OR s.StateName like '%".$searchString."%')", NULL, FALSE);
            }
        }
        $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
        $this->db->limit($this->input->post('length'), $this->input->post('start'));
        $query = $this->db->get();

        $data['draw'] = $this->input->post('draw');
        $data['totalData'] = $queryTot->num_rows();
        $data['totalFilter'] = $queryTot->num_rows();
        $surveyFormLevel = array('1' => 'Base Line', '2' => 'Mid Line', '3' => 'Top Line');
        $dataget = array();
        $cnt=$searchData['start'];
        //$access_add=$this->CommonModel->checkPageActionWeb('facility/index','access_add',$this->session->userdata('RoleName'));
        $access_edit=$this->CommonModel->checkPageActionWeb('monthly/index','access_edit',$this->session->userdata('RoleName'));
        //$access_delete=$this->CommonModel->checkPageActionWeb('facility/index','access_delete',$this->session->userdata('RoleName'));
        $access_view=$this->CommonModel->checkPageActionWeb('monthly/index','access_view',$this->session->userdata('RoleName'));
        foreach ($query->result() as $key => $value) {
            $subdata = array();
            $subdata[]=++$cnt;
            $subdata[] = $value->StateName;
            $subdata[] = $value->DistrictName;
            $subdata[] = $value->facilityName;
            $subdata[] = date('F Y', strtotime($value->ReportMonth));
            $subdata[] = convert_date_show($value->CollectionDate);
            //$subdata[] = $value->MonthlyStatus ? 'Completed' : 'Incomplete';
            $subdata[]=$value->MonthlyStatus?'<span class="complete-status">Completed</span>':'<span class="incomplete-status">Incomplete</span>';
            $subdata[] = convert_date_show($value->CreatedOn);
            if (!$value->MonthlyStatus) {
                $actionLink='';
                if($access_edit){
                    $actionLink.='<button data-page="Edit" data-reqMonth="' . $value->ReportMonth . '" data-months="' . $value->MonthlyID . '" data-href="' . base_url() . 'monthly/add/' . encryptor($value->MonthlyID) . '" onclick="getPage(this)"  class="btn btn-primary btn-xs getScore view_edit_width" ><i class="glyphicon glyphicon-check"></i>Edit</button>';
                }                
                $subdata[] = $actionLink;
                $fromType = 'add';
            } else {
                $actionLink='';
                if($access_view){
                    $actionLink.='<button data-page="View" data-reqMonth="' . $value->ReportMonth . '" data-months="' . $value->MonthlyID . '" data-href="' . base_url() . 'monthly/view/' . encryptor($value->MonthlyID) . '" onclick="getPage(this)"  class="btn btn-primary btn-xs getScore view_edit_width" ><i class="glyphicon glyphicon-check"></i>View</button>';
                }                
                $subdata[] = $actionLink;
                $fromType = 'view';
            }

            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;

        return $data;
    }

    function checkMonthlyFacilityAdd($facilityUser) {
        if ($facilityUser) {
            $this->db->select('monthly.MonthlyID');
            $this->db->from('monthly');
            $this->db->where('monthly.UserID', $facilityUser);
            $this->db->where('monthly.ReportMonth', date('Y-m-01'));
            $result = $this->db->get();
            if ($result->num_rows() >= 1) {
                $response['code'] = $result->num_rows();
                $response['msg'] = $result->num_rows() . ' data get';
            } else {
                $response['code'] = '0';
                $response['msg'] = $result->num_rows() . ' data get';
            }
        } else {
            $response['code'] = '14';
            $response['msg'] = 'No Proper Data Submitted';
        }
        return $response;
    }

    function monthReportCheck($dateRpt, $facilityUser) {
        if ($facilityUser) {
            $this->db->select('monthly.MonthlyID,monthly.MonthlyStatus');
            $this->db->from('monthly');
            $this->db->where('monthly.UserID', $facilityUser);
            $this->db->where('monthly.ReportMonth', $dateRpt);
            $result = $this->db->get();
            $monthId = 0;
            if ($result->num_rows() >= 1) {
                $data = $result->result_array();
                if (isset($data[0]['MonthlyID'])) {
                    $monthId = $data[0]['MonthlyID'];
                } else {
                    $monthId = 0;
                }
                if ($data[0]['MonthlyStatus']) {
                    $response['code'] = '0';
                    $response['data'] = '<button data-page="View" id="redirectBtn" data-href="' . base_url() . 'monthly/view/' . encryptor($monthId) . '" onclick="getPage(this)" data-reqMonth="' . $dateRpt . '" data-months="' . $monthId . '" class="btn btn-primary getScore pull-right" >View</button>';
                    $response['monthId'] = $monthId;
                    $response['page'] = 'View';
                    $response['msg'] = ' View Page';
                } else {
                    $response['code'] = '0';
                    $response['data'] = '<button id="redirectBtn" data-page="Edit" data-href="' . base_url() . 'monthly/add/' . encryptor($monthId) . '" onclick="getPage(this)" data-reqMonth="' . $dateRpt . '" data-months="' . $monthId . '" class="btn btn-primary getScore pull-right" >Edit</button>';
                    $response['monthId'] = $monthId;
                    $response['page'] = 'Edit';
                    $response['msg'] = ' Edit Page';
                }
            } else {
                $response['code'] = '0';
                $response['data'] = '<button id="redirectBtn" data-page="Add" data-href="' . base_url() . 'monthly/add/' . encryptor($monthId) . '" onclick="getPage(this)" data-reqMonth="' . $dateRpt . '" data-months="0" class="btn btn-primary getScore" >Add</button>';
                $response['monthId'] = '0';
                $response['page'] = 'Add';
                $response['msg'] = ' Add Page';
            }
        } else {
            $response['code'] = '14';
            $response['msg'] = 'No Proper Data Submitted';
        }
        return $response;
    }

    function getSearchMonthlyReportQuery($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility) {
//        echo "AD";
        $this->db->select('s.StateName,d.DistrictName,f.FacilityName,f.FacilityNumber,f.stateID,f.districtId,um.UserID,m.*,ot.BaselineNQASChecklistLR,ot.BaselineNQASChecklistOT,ot.QualityTeamFacility,ot.QualityCircleLR,ot.QualityCircleOT,ot.OrientationAttended,ot.BaselineScoreOT,ot.BaselineScoreLR');
        $this->db->from('monthly as m');
        $this->db->join('onetime as ot', 'ot.UserID= m.UserID', 'inner');
        $this->db->join('usermapping as um', 'um.UserID= m.UserID', 'inner');
        $this->db->join('facilities as f', 'f.FacilityID= um.FacilityID', 'inner');
        $this->db->join('states as s', 's.StateID=f.StateID', 'inner');
        $this->db->join('district as d', 'd.DistrictID=f.DistrictID', 'inner');
        if ($this->session->userdata('RoleName') == 'State') {
            $MappedState = $this->session->userdata('MappedState');
            if ($MappedState != '') {
                $MappedStateArray = explode(",", $MappedState);
                $this->db->where_in('f.StateID', $MappedStateArray);
            }
        } else if ($this->session->userdata('RoleName') == 'District') {
            $MappedDistrict = $this->session->userdata('MappedDistrict');
            if ($MappedDistrict != '') {
                $MappedDistrictArray = explode(",", $MappedDistrict);
                $this->db->where_in('f.DistrictID', $MappedDistrictArray);
            }
        } 
        else if ($this->session->userdata('RoleName') == 'Facility') {
            $userID = $this->session->userdata('UserID');
            $this->db->where('um.UserID', $userID);
        }

//        $this->db->where('monthly.UserID', $userID);
        if (!empty($search_months) && empty($search_years)) {
//            print_r($search_years); die;
            $this->db->where('MONTH(m.ReportMonth)', $search_months);
        }
        if (empty($search_months) && !empty($search_years)) {
            $this->db->where('YEAR(m.ReportMonth)', $search_years);
        }
        if (!empty($search_months) && !empty($search_years)) {
            $search_date = $search_years . '-' . $search_months . '-01';
            $this->db->where('m.ReportMonth', $search_date);
        }
        //
        if (!empty($search_state)) {
//            print_r($search_years); die;
            $this->db->where('f.StateID', $search_state);
        }
        if (!empty($search_district)) {
//            print_r($search_years); die;
            $this->db->where('f.DistrictID', $search_district);
        }
        if (!empty($search_facility)) {
//            print_r($search_years); die;
            $this->db->where('um.UserID', $search_facility);
        }
         $this->db->order_by('m.ReportMonth', 'DESC');
        //

        /*if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);
            if ($searchString == 'Completed') {
                $this->db->where("(monthly.MonthlyStatus='1')", NULL, FALSE);
            } else if ($searchString == 'Incomplete') {
                $this->db->where("(monthly.MonthlyStatus='0')", NULL, FALSE);
            } else {
                $this->db->where("(monthly.CollectionDate='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.CreatedOn='" . date('Y-m-d', strtotime($searchString)) . "' OR monthly.ReportMonth='" . date('Y-m-01', strtotime($searchString)) . "')", NULL, FALSE);
            }
        }*/
    }
    function count_filtered_getSearchMonthlyReportData($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility) {
        $this->getSearchMonthlyReportQuery($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility);
        $query = $this->db->get();
        return $query->num_rows();
    }
    function getSearchMonthlyReportData($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility) {
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
        $col = array(0 => 's.StateName', 1 => 'd.DistrictName', 2 => 'f.FacilityName', 3 => 'f.FacilityName',);
        $response = array();
        $this->getSearchMonthlyReportQuery($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility);
        //$this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
        $this->db->order_by('f.FacilityName', 'ASC');
        $this->db->limit($this->input->post('length'), $this->input->post('start'));
        $query = $this->db->get();
//print_r($this->db->last_query());
        $data['draw'] = $this->input->post('draw');
        $data['totalData'] = $this->count_filtered_getSearchMonthlyReportData($search_months, $search_years, $searchData, $search_options, $search_state, $search_district, $search_facility);
        $data['totalFilter'] = $data['totalData'];

        $dataget = array();
        //echo "<pre>";
//print_r($subdata);
        $cnt=$this->input->post('start');
        foreach ($query->result() as $key => $value) {
            $subdata = array();
            $subdata[]=++$cnt;
            if (isset($search_options['State'])) {
                $subdata[] = $value->StateName;
            }
            if (isset($search_options['District'])) {
                $subdata[] = $value->DistrictName;
            }
            if (isset($search_options['Facility'])) {
                $subdata[] = $value->FacilityName;
            }
            $subdata[] = date('F Y', strtotime($value->ReportMonth));
            $subdata[] = ($value->BaselineNQASChecklistLR==1 && $value->BaselineNQASChecklistOT==1)?'YES':'No' ;
            $subdata[] = ($value->QualityTeamFacility==1 && $value->QualityCircleLR==1 && $value->QualityCircleOT==1)?'YES':'NO';
            $subdata[] = ($value->OrientationAttended==1)?'YES':'NO';
            $subdata[] = ($value->BirthCompanionNos==0)?0:formatValue(($value->BirthCompanionNos * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c38*100/c11+c12
            $subdata[] = ($value->SafeBirthChecklist==0)?0:formatValue(($value->SafeBirthChecklist * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c39*100/c11+c12
            $subdata[] = ($value->CSectionOTSafeChecklist==0)?0:formatValue(($value->CSectionOTSafeChecklist * 100) / $value->TotalCSections); // c40*100/c13
            $subdata[] = ($value->RealTimePartograph==0)?0:formatValue(($value->RealTimePartograph * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c41*100/c11+c12
            $subdata[] = ($value->BreastfedNewborns==0)?0:formatValue(($value->BreastfedNewborns * 100) / ($value->TotalAssistedVaginalDeliveries + $value->TotalNormalVaginalDeliveries + $value->TotalCSections)); // c42*100/(c13+c12+c11)
            $subdata[] = ($value->NewbornsSNCUAsphyxia==0)?0:formatValue(($value->NewbornsSNCUAsphyxia * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //c47*100/(c11+c12+13)
            $subdata[] = ($value->NewbornsSNCUSepsis==0)?0:formatValue(($value->NewbornsSNCUSepsis * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //c48*100/(c11+c12+13)
            $subdata[] = ($value->CSectionsInfection==0)?0:formatValue(($value->CSectionsInfection * 100) / ($value->TotalCSections)); // c45*100/c13
            $subdata[] = ($value->PretermANCSInFacilitiesSNCU>0 && $value->TotalPretermDeliveries>0)?formatValue(($value->PretermANCSInFacilitiesSNCU * 100) / ($value->TotalPretermDeliveries)):0; //c46*100/c35
            $subdata[] = ($value->MaternalPIHEclampsia==0)?0:formatValue(($value->MaternalPIHEclampsia * 100) / ($value->TotalMaternalDeaths)); // c20*100/c14
            $subdata[] = ($value->MaternalAPH + $value->MaternalPPH==0)?0:formatValue((($value->MaternalAPH + $value->MaternalPPH) * 100) / ($value->TotalMaternalDeaths)); // (c16+c17)*100/c14
            $subdata[] = ($value->ReorganizedLR==1)?'YES':'NO'; // c52
            $subdata[] = ($value->AdequateStaffLR==1)?'YES':'NO'; //c53
            $subdata[] = ($value->OxytocinCount==0)?0:formatValue(($value->OxytocinCount * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c54*100/(c11+c12)
            $subdata[] = ''; //current osce score (remove) from form
            $subdata[] = $value->ReferralCases; //c58
            $subdata[] = $value->MaternalDeathsReviewed + $value->NeonatalDeaths + $value->MaternalMissCases; //c55+c56+c57
            $subdata[] = ($value->StockOutsInOT==1)?'YES':'NO'; //c60
            $subdata[] = ($value->TotalFreshStillBirths + $value->TotalMaceratedStillBirths==0)?0:formatValue((($value->TotalFreshStillBirths + $value->TotalMaceratedStillBirths) * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //(c25+c26)*100/(c11+c12+c13)
            $subdata[] = ($value->SatisfiedDelivered>0)?formatValue(($value->SatisfiedDelivered * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)):0; //(c51)*100/(c11+c12+c13);
            $subdata[] = ($value->MCHDHFunctional==1)?'YES':'NO'; //c62
            $subdata[] = ($value->MCBSamplingLR==1 && $value->MCBSamplingOT==1)?'YES':'NO'; //c43+c44;
            $subdata[] =   (($value->CurrentLabourRoomQualityScore-$value->BaselineScoreLR*100)>0 && $value->BaselineScoreLR>0)?formatValue(($value->CurrentLabourRoomQualityScore-$value->BaselineScoreLR*100)/$value->BaselineScoreLR):0; //(c66-c72)*100/c72;
            $subdata[] = (($value->CurrentMaternityOTQualityScore-$value->BaselineScoreOT*100)>0 && $value->BaselineScoreOT>0)?formatValue(($value->CurrentMaternityOTQualityScore-$value->BaselineScoreOT*100)/$value->BaselineScoreOT):0;  //c67-c75*100/c75;




            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;
//echo "<pre>";
//print_r($subdata);
        return $data;
    }

    function reportData_certificate($searchData){
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
        $col = array(0 => 's.StateName', 1 => 'd.DistrictName', 2 => 'f.FacilityName', 3 => 'f.FacilityName',);

        $this->db->select('applied_date,status,userID');
        $this->db->from('certification');
        $this->db->where('CertificationID',encryptor($searchData['CertificationID'],'decrypt'));
        $query = $this->db->get();
        $certificateData=$query->row_array();

        $dateArray=array(
            Date("Y-m-01", strtotime($certificateData['applied_date']." -1 Month")),
            Date("Y-m-01", strtotime($certificateData['applied_date']." -2 Month")),
            Date("Y-m-01", strtotime($certificateData['applied_date']." -3 Month"))
        );

        $this->db->select('s.StateName,d.DistrictName,f.FacilityName,f.FacilityNumber,f.stateID,f.districtId,um.UserID,m.*,ot.BaselineNQASChecklistLR,ot.BaselineNQASChecklistOT,ot.QualityTeamFacility,ot.QualityCircleLR,ot.QualityCircleOT,ot.OrientationAttended,ot.BaselineScoreOT,ot.BaselineScoreLR');
        $this->db->from('monthly as m');
        $this->db->join('onetime as ot', 'ot.UserID= m.UserID', 'inner');
        $this->db->join('usermapping as um', 'um.UserID= m.UserID', 'inner');
        $this->db->join('facilities as f', 'f.FacilityID= um.FacilityID', 'inner');
        $this->db->join('states as s', 's.StateID=f.StateID', 'inner');
        $this->db->join('district as d', 'd.DistrictID=f.DistrictID', 'inner');
        if (!empty($certificateData['userID'])) {
            $this->db->where('um.UserID', $certificateData['userID']);
        }
        if(!empty($searchData['monthCount'])){
            $this->db->where('m.ReportMonth', Date("Y-m-01", strtotime($certificateData['applied_date']." -".encryptor($searchData['monthCount'],'decrypt')." Month")));
        } else {
            $this->db->where_in('m.ReportMonth', $dateArray);
        }

        $this->db->order_by('m.ReportMonth', 'DESC');
        $query = $this->db->get();
        
        $data['draw'] = $this->input->post('draw');
        $data['totalFilter'] = $query->num_rows();
        $data['totalData'] = $query->num_rows();

        $dataget = array();
        foreach ($query->result() as $key => $value) {
            $subdata = array();
            if (isset($search_options['State'])) {
                $subdata[] = $value->StateName;
            }
            if (isset($search_options['District'])) {
                $subdata[] = $value->DistrictName;
            }
            if (isset($search_options['Facility'])) {
                $subdata[] = $value->FacilityName;
            }
            $subdata[] = date('F Y', strtotime($value->ReportMonth));
            $subdata[] = ($value->BaselineNQASChecklistLR==1 && $value->BaselineNQASChecklistOT==1)?'YES':'No' ;
            $subdata[] = ($value->QualityTeamFacility==1 && $value->QualityCircleLR==1 && $value->QualityCircleOT==1)?'YES':'NO';
            $subdata[] = ($value->OrientationAttended==1)?'YES':'NO';
            $subdata[] = ($value->BirthCompanionNos==0)?0:formatValue(($value->BirthCompanionNos * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c38*100/c11+c12
            $subdata[] = ($value->SafeBirthChecklist==0)?0:formatValue(($value->SafeBirthChecklist * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c39*100/c11+c12
            $subdata[] = ($value->CSectionOTSafeChecklist==0)?0:formatValue(($value->CSectionOTSafeChecklist * 100) / $value->TotalCSections); // c40*100/c13
            $subdata[] = ($value->RealTimePartograph==0)?0:formatValue(($value->RealTimePartograph * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c41*100/c11+c12
            $subdata[] = ($value->BreastfedNewborns==0)?0:formatValue(($value->BreastfedNewborns * 100) / ($value->TotalAssistedVaginalDeliveries + $value->TotalNormalVaginalDeliveries + $value->TotalCSections)); // c42*100/(c13+c12+c11)
            $subdata[] = ($value->NewbornsSNCUAsphyxia==0)?0:formatValue(($value->NewbornsSNCUAsphyxia * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //c47*100/(c11+c12+13)
            $subdata[] = ($value->NewbornsSNCUSepsis==0)?0:formatValue(($value->NewbornsSNCUSepsis * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //c48*100/(c11+c12+13)
            $subdata[] = ($value->CSectionsInfection==0)?0:formatValue(($value->CSectionsInfection * 100) / ($value->TotalCSections)); // c45*100/c13
            $subdata[] = ($value->PretermANCSInFacilitiesSNCU==0)?0:formatValue(($value->PretermANCSInFacilitiesSNCU * 100) / ($value->TotalPretermDeliveries)); //c46*100/c35
            $subdata[] = ($value->MaternalPIHEclampsia==0)?0:formatValue(($value->MaternalPIHEclampsia * 100) / ($value->TotalMaternalDeaths)); // c20*100/c14
            $subdata[] = ($value->MaternalAPH + $value->MaternalPPH==0)?0:formatValue((($value->MaternalAPH + $value->MaternalPPH) * 100) / ($value->TotalMaternalDeaths)); // (c16+c17)*100/c14
            $subdata[] = ($value->ReorganizedLR==1)?'YES':'NO'; // c52
            $subdata[] = ($value->AdequateStaffLR==1)?'YES':'NO'; //c53
            $subdata[] = ($value->OxytocinCount==0)?0:formatValue(($value->OxytocinCount * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries)); //c54*100/(c11+c12)
            $subdata[] = ''; //current osce score (remove) from form
            $subdata[] = $value->ReferralCases; //c58
            $subdata[] = $value->MaternalDeathsReviewed + $value->NeonatalDeaths + $value->MaternalMissCases; //c55+c56+c57
            $subdata[] = ($value->StockOutsInOT==1)?'YES':'NO'; //c60
            $subdata[] = ($value->TotalFreshStillBirths + $value->TotalMaceratedStillBirths==0)?0:formatValue((($value->TotalFreshStillBirths + $value->TotalMaceratedStillBirths) * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //(c25+c26)*100/(c11+c12+c13)
            $subdata[] = ($value->SatisfiedDelivered==0)?0:formatValue(($value->SatisfiedDelivered * 100) / ($value->TotalNormalVaginalDeliveries + $value->TotalAssistedVaginalDeliveries + $value->TotalCSections)); //(c51)*100/(c11+c12+c13);
            $subdata[] = ($value->MCHDHFunctional==1)?'YES':'NO'; //c62
            $subdata[] = ($value->MCBSamplingLR==1 && $value->MCBSamplingOT==1)?'YES':'NO'; //c43+c44;
            $subdata[] =   (($value->CurrentLabourRoomQualityScore-$value->BaselineScoreLR*100)>0)?formatValue(($value->CurrentLabourRoomQualityScore-$value->BaselineScoreLR*100)/$value->BaselineScoreLR):0; //(c66-c72)*100/c72;
            $subdata[] = (($value->CurrentMaternityOTQualityScore-$value->BaselineScoreOT*100)>0)?formatValue(($value->CurrentMaternityOTQualityScore-$value->BaselineScoreOT*100)/$value->BaselineScoreOT):0;  //c67-c75*100/c75;




            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;
        if(!empty($searchData['monthCount'])){
            $data['monthdate'] = Date("F Y", strtotime($certificateData['applied_date']." -".encryptor($searchData['monthCount'],'decrypt')." Month"));
        } else {
            $data['monthdate'] = 'Last three months';
        }
        return $data;

    }
    function setMonthlyData($MonthlyID){
        $this->db->select('m.UserID,m.ReportMonth');
        $this->db->from('monthly as m');
        $this->db->where('m.MonthlyID', encryptor($MonthlyID,'decrypt'));
        $query = $this->db->get();
        $data=$query->row_array();
        $this->session->set_userdata('facilityUser', $data['UserID']);
        $this->session->set_userdata('setDataMonth', $data['ReportMonth']);
    }

}
