<?php

class EmailModel extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	function update_password($data){
		ob_start();
		?>
<p>Hi <?php echo $data['name']; ?>,</p>
<p>Your LaQshya account password has changed successfully. Your new password is <?php echo $data['pswrd']; ?>.</p>
<p>if you have not changed the password please contact Administrator.</p>
		<?php
		$content = ob_get_contents();
		ob_end_clean();
		return $content;		
	}
	function certification_insert($data){
		ob_start();
		?>
<p>Hi <?php echo $data['name']; ?>,</p>
<p>Your LaQshya Certification has applied.</p>
		<?php
		$content = ob_get_contents();
		ob_end_clean();
		return $content;		
	}
	
}