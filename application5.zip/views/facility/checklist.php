<style>
  #loader_mine {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}



@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>

<script>
  $(document).ready(function() {
           $('#loader_mine').hide();
           $('.main-content').show();
});
</script>
<div id="loader_mine"></div>  
<div class="page-title">
  <div class="title_left">
    <h3><?php echo isset($survey['survey'][$surveyId]['SurveyDesc'])?$survey['survey'][$surveyId]['SurveyDesc']:''; ?></h3>
  </div>
  <span class="downlo-btn-form">
            <a class="btn btn-info" href="#" data-toggle="modal" data-target="#abbreviationModal">Abbreviation <i class="fa fa-question-circle" aria-hidden="true"></i></a>
          </span>

  
</div>


<div class="main-content" style="display: none;">  
  <div class="tab-head1">
    <div class="container">
      <div class="row">
        <div class="form-main-labour">
          <h4 class="title"><h4>
            <!-- SmartWizard html -->
            <div id="smartwizard">          
              <?php if(isset($survey['survey'][$surveyId]['category']) && count($survey['survey'][$surveyId]['category'])>0){ ?>
              <ul>
                <li tabindex="0"><a href="#step-0"><span><em>  </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>Assessment<br /></a></li>
                <?php foreach ($survey['survey'][$surveyId]['category'] as $keyCat => $valueCat) { ?>            
                <li tabindex="0"><a href="#step-<?php echo $keyCat; ?>"><span><em> <?php echo isset($valueCat['CategoryCode'])?$valueCat['CategoryCode']:''; ?> </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span><?php echo isset($valueCat['CategoryName'])?$valueCat['CategoryName']:''; ?><br /></a></li>
                <?php } ?>
              </ul>
              <?php } ?>
              <div> 
                <!-- assesment start -->
                <div id="step-0">      
                  <div class="col-md-12 col-sm-12 col-xs-12">
                
                <?php if(isset($search_options['State']) ){ ?>
                <div class="col-md-4 col-sm-5 col-xs-12">
                     <div class="form-group">
                    <label> State Name<span class="required"> * </span> </label>
                    <select id="search_state" name="search_state" onchange="change_state()" class="form-control">
                        <option value="">Select State</option>
                        <?php foreach ($search_options['State'] as $key => $value) {  ?>
                        <option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
                        <?php } ?>
                    </select>  
                    </div>                  
                </div>
                <?php } ?>
                <?php if(isset($search_options['District']) ){ ?>
                <div class="col-md-4 col-sm-5 col-xs-12">
                     <div class="form-group">
                      <label> District Name <span class="required"> * </span> </label>
                    <select id="search_district"  name="search_district" onchange="change_district()" class="form-control">
                        <option value="">Select District</option>
                        <?php foreach ($search_options['District'] as $key => $value) { ?>
                        <option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
                        <?php } ?>
                    </select>  
                    </div>                  
                </div>
                <?php } ?>
                <?php if(isset($search_options['Facility']) || $this->session->userdata('RoleName')=='Facility' ){ ?>
                <div class="col-md-4 col-sm-5 col-xs-12">
                    <div class="form-group">
                        <label> Name of the Hospital <span class="required"> * </span> </label>
                        <select id="facilityName" name="facilityName" class="form-control"   onchange="changeFacility(this)">
                            <option value="">Select Facility</option>
                        </select>
                    </div>
                </div>
                <?php } ?>
                <div class="col-md-4 col-sm-5 col-xs-12">
                    <div class="form-group">
                        <label> Assessment Type <span class="required"> * </span> </label>
                        <select name="sequence" id="sequence" class="selectpicker" data-live-search="true" data-width="100%">
                            <?php foreach ($this->config->item('assesmentSequence') as $key => $value) { ?>
                            <option value="<?php echo $key ?>"><?php echo $value; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>            
               
        
                    <!-- <div class="col-md-4 col-sm-5 col-xs-12">
                        <div class="form-group">
                            <label> Name of the Hospital <span class="required"> * </span> </label>
                            <input type="text" class="form-control" id="facilityName" name="facilityName" placeholder="Hospital name">
                        </div>
                    </div> -->
                    <div class="col-md-4 col-sm-5 col-xs-12">
                        <div class="form-group">
                            <label> Date of Assessment <span class="required"> * </span> </label>
                            
                                <input minlength="10" maxlength="10" type='text' id="assessmentDate" name="assessmentDate"  placeholder="DD-MM-YYYY" class="form-control datepicker" />
                                <!--<span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>-->
                            
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-5 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessor 1<span class="required"> * </span> </label>
                            <input minlength="1" maxlength="100" type="text" id="assessorsName1" name="assessorsName1"  class="form-control" placeholder="Name of Assessor">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-5 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessee 1<span class="required"> * </span> </label>
                            <input minlength="1" maxlength="100" type="text" id="assesseesName1" name="assesseesName1" class="form-control" placeholder="Name of assessee">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-5 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessor 2</label>
                            <input maxlength="100" type="text" id="assessorsName2" name="assessorsName2"  class="form-control" placeholder="Name of assessor">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-5 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessee 2</label>
                            <input maxlength="100" type="text" id="assesseesName2" name="assesseesName2" class="form-control" placeholder="Name of assessee">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-5 col-xs-12">
                        <div class="form-group">
                            <label> Category of Assessment <span class="required"> * </span> </label>
                            <select name="assessment" id="assessment" class="selectpicker  " data-live-search="true" data-width="100%">
                            <?php foreach ($this->config->item('assessmentCat') as $key => $value) { ?>
                            <option value="<?php echo $key ?>"><?php echo $value; ?></option>
                            <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-5 col-xs-12">
                        <div class="form-group">
                            <label> Action plan Submission Date </label>
                            
                                <input minlength="10" maxlength="10" type='text' id="submissionDate" name="submissionDate" placeholder="DD-MM-YYYY" class="form-control datepicker" />
                                <!--<span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>-->
                            
                        </div>
                    </div> 
                                  
                  </div>
                </div>
        
                <!-- assessment end -->
                <!-- Catgory Start -->
                <?php if(isset($survey['survey'][$surveyId]['category']) && count($survey['survey'][$surveyId]['category'])>0){ ?>
                <?php foreach ($survey['survey'][$surveyId]['category'] as $keyCat => $valueCat) { ?>
                <div id="step-<?php echo $keyCat; ?>">			
                  <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="quote-top-bar">
                      <div class="col-md-1 col-md-offset-7 text-right">
                          <p>Compliance</p>
                      </div>
                      <div class="col-md-4 col-sm-5 col-xs-12  text-center to-compliance">
                        <div class="col-md-3 text-right">
                          <p>  0-49%</p>
                        </div>
                        <div class="col-md-3 text-center">
                          <p>  49-99%</p>
                        </div>
                        <div class="col-md-3 text-center">
                          <p>  100%</p>
                        </div>
                      </div>  
                    </div>  
                  </div>
                  <div class="clear"></div>

                  <!-- Subcatgory Start -->
                  <?php if(isset($valueCat['subcategory']) && count($valueCat['subcategory'])>0){ ?>
                  <?php foreach ($valueCat['subcategory'] as $keySubCat => $valueSubCat) { ?>
                  <div class="question-list">
                    <h5 class="form-title"><?php echo isset($valueSubCat['SubCategoryCode'])?$valueSubCat['SubCategoryCode'].': ':''; echo isset($valueSubCat['SubCategoryName'])?$valueSubCat['SubCategoryName']:'';  ?><span class="pull-right" id="SubTot_<?php echo $valueSubCat['SubcategoryID']; ?>"></span><span class="pull-right" id="SubScore_<?php echo $valueSubCat['SubcategoryID']; ?>"></span></h5>
                    <div class="question-list1">
                      <div class="quest1">

                        <!-- questation Start -->
                        <?php if(isset($valueSubCat['questions']) && count($valueSubCat['questions'])>0){ ?>
                        <?php foreach ($valueSubCat['questions'] as $keyQues => $valueQues) { 
                          if(!empty($valueQues['Reference']) && !empty($valueQues['Statement'])){
                          ?>
                        <div class="col-md-12 col-sm-12 col-xs-12 bg_dark_gr">
                         <div class="quote1-full">
                           
                            <div class="quote-1-list">
                              <?php if(isset($valueQues['Reference']) && !empty($valueQues['Reference'])){ ?><div class="num-list"><?php echo $valueQues['Reference']; ?></div><?php } ?>
                              <div class="quotation-content"> 
                                <?php if(isset($valueQues['Statement']) && !empty($valueQues['Statement'])){ ?><h4><?php echo $valueQues['Statement']; ?></h4><?php } ?>
                              </div>
                           </div>
                         </div>
                        </div>
                        <?php  } ?>
                        <div class="col-md-12 col-sm-12 col-xs-12 bg_light_gr">
                         <div class="quote1-full  quote1-full2">                          
                           
                          <div class="col-md-8 col-sm-7 col-xs-12">  
                            <div class="quote-1-list">
                              <div class="num-list"></div>
                              <div class="quotation-content quotation_content_mine_mar" tabindex="0"> 
                                <?php if(isset($valueQues['Checkpoint']) && !empty($valueQues['Checkpoint'])){ ?><h5><?php echo $valueQues['Checkpoint']; ?></h5><?php } ?>
                              </div>
                              <?php if(!empty($valueQues['Assesment']) || !empty($valueQues['Verification'])){ ?>
                              <div class="clearfix"></div>
                              <div class="" >
                               <p class="new-point-method">
                                <?php if(!empty($valueQues['Assesment'])){ ?>
                                <strong>Assessment method: </strong><?php echo $valueQues['Assesment']; ?> 
                                <a  href="#" data-toggle="modal" data-target="#abbreviationModal"><i class="fa fa-question-circle" aria-hidden="true"></i></a></br>
                                <?php } ?>
                                <?php if(!empty($valueQues['Verification'])){ ?>
                                <strong>Verification: </strong><?php echo $valueQues['Verification']; ?>
                                <?php } ?>
                                </p>
                             </div>
                             <?php } ?>
                           </div>
                          </div>










                         <div class="col-md-4 col-sm-5 col-xs-12 text-center">  
                          <div class="quote-1-option quote-1-option_mine_mar">
                            <div class="maxl">
                             <div class="col-md-3">  
                               <div class="custom-control custom-radio custom-control-inline">
                                  <input type="radio" id="answer_<?php echo $keyQues; ?>_0" name="answer[<?php echo $keyQues; ?>]" value="0" class="custom-control-input" required tabindex="0" >
                                  <label class="custom-control-label" for="answer_<?php echo $keyQues; ?>_0">0</label>
                                </div>
                            </div>
                            <div class="col-md-3">  
                             <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="answer_<?php echo $keyQues; ?>_1" name="answer[<?php echo $keyQues; ?>]" value="1" class="custom-control-input" required tabindex="0" >
                                <label class="custom-control-label" for="answer_<?php echo $keyQues; ?>_1">1</label>
                              </div>
                          </div>
                          <div class="col-md-3">  
                            <div class="custom-control custom-radio custom-control-inline">
                              <input checked="checked" type="radio" id="answer_<?php echo $keyQues; ?>_2"   name="answer[<?php echo $keyQues; ?>]" value="2" class="custom-control-input" required tabindex="0" >
                              <label class="custom-control-label" for="answer_<?php echo $keyQues; ?>_2">2</label>
                            </div>
                          </div>

                          <div class="col-md-3">  
                            <div class="selec-uncheck-btn" title="Uncheck Your Answer"  >
                                <a href="javascript:void(0);" class="uncheckRadio" id="uncheckRadio_<?php echo $keyQues; ?>" style="display: none;" tabindex="0" > <i class="fa fa-trash" aria-hidden="true"></i></a>
                            </div>
                          </div>


                        </div>
                      </div>
                    </div>

                  </div>
                </div>  
                <!-- questation Ended -->
                <?php } ?>
                <?php } ?>
              </div>
            </div>                  
          </div>
          <?php } ?>
          <?php } ?>
          <!-- Subcatgory End -->

        </div>
        <?php } ?>			  
        <?php } ?>  
        <!-- Catgory End -->
        <input type='hidden' name="user" id="user" value="<?php echo $this->session->userdata('RoleName'); ?>" class="" />
        <input type='hidden' name="SurveyID" id="SurveyID" value="<?php echo $this->uri->segment('3'); ?>" class="" />
        <input type='hidden' name="ansId" id="ansId" value="<?php echo $this->uri->segment('4'); ?>" class="" />
      </div>
    </div>   
    
  </div>
</div>
</div>
</div>  
</div><!--main-content --> 

<!-- abbrevation modal start -->
  <div class="modal fade" id="abbreviationModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Assessment Methods </h4>
        </div>
        <div class="modal-body">
          <p>
          <span >Assessment Method – </span> Assessment Methods are given in adjacent column to checkpoint and provides aid to the assessors that how the information required for a specific checkpoint can be gathered. There are four assessment methods:</br></br>
          <span style="font-weight: bold;" >Observations (OB) – </span> Where information can be gathered though
          direct observation. e.g. Level of Cleanliness, Display of Protocols,
          Landscaping, Signage etc.</br></br>
          <span style="font-weight: bold;" >Staff Interview (SI) – </span> Information should be gathered by interacting the concerned staff to understand the current practices, competency, etc. such as steps in hand washing, method to clean
          floor, wearing gloves.</br></br>
          <span style="font-weight: bold;" >Record Review (RR) – </span> Where information can be extracted from the records available at the facility. Few examples are availability of filled-in Housekeeping checklist, culture report for microbial surveillance, minutes of meeting of infection control committee.</br></br>
          <span style="font-weight: bold;" >Patient Interview (PI) – </span> Some information may be gathered by interacting the patients or their attendants e.g. counselling of patients on hygiene.</br></br>
          </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!-- abbrevation modal end -->

<!-- previewModal modal start -->
  <div class="modal fade" id="previewModal" role="dialog">
    <div class="modal-dialog modal-dialog-preview">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">LR Assessment Preview </h4>
        </div>
        <div class="modal-body">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!-- previewModal modal end -->

<!-- wizaard -->
<script src="<?php echo base_url();?>assets/js/notify.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>
<script src="<?php echo base_url();?>assets/js/form-custom.js"></script>
