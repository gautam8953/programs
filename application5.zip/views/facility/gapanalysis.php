<div class="page-title">
  <div class="title_left">
    <h3>Gap Analysis</h3>
  </div>

  
</div>

<div class="clearfix"></div>

<div class="main-content GapAnalysis"> 
    <div class="container">	  
    <div class="row">
    		<div class="col-md-12 col-sm-12 col-xs-12">
	        	<div class="x_panel">
	                <div class="x_title">
	                        <h2>Assessment Summary</h2>
	                        <ul class="nav navbar-right panel_toolbox">
	                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
	                        </ul>
	                        <div class="clearfix"></div>
	                </div>
	                <div class="x_content">
	                	<div class="col-md-12 col-sm-12 col-xs-12">
	                		<div class="top-list-new-1">
	                			<!--one-->
	                			<div class="new0car-n1">
	                				
	                				<div class="card">
									    <div class="card-header card-header-primary">
									        <h4 class="card-title">A-Service Provision</h4>
									        
									    </div>
									    <div class="card-body table-responsive">
									        <table class="table table-hover">
									             
									            <tbody>

									            	<tr class="car-head-number1">
									                    <td>Score</td>
									                    <td>Count</td>
									                    
									                </tr>


									                <tr>
									                    <td>Score-0</td>
									                    <td>0</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-1</td>
									                    <td>0</td>
									                   
									                </tr>
									                <tr>
									                    <td>Score-2</td>
									                    <td>11</td>
									                    
									                </tr>
									                 
									            </tbody>
									        </table>
									    </div>
									</div>


									<div class="card">
									    <div class="card-header card-header-primary">
									        <h4 class="card-title">B-Patient Rights</h4>
									        
									    </div>
									    <div class="card-body table-responsive">
									        <table class="table table-hover">
									             
									            <tbody>
									            	<tr class="car-head-number1">
									                    <td>Score</td>
									                    <td>Count</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-0</td>
									                    <td>0</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-1	</td>
									                    <td>0</td>
									                   
									                </tr>
									                <tr>
									                    <td>Score-2</td>
									                    <td>11</td>
									                    
									                </tr>
									                 
									            </tbody>
									        </table>
									    </div>
									</div>



									<div class="card">
									    <div class="card-header card-header-primary">
									        <h4 class="card-title">C-Inputs</h4>
									        
									    </div>
									    <div class="card-body table-responsive">
									        <table class="table table-hover">
									             
									            <tbody>
									            	<tr class="car-head-number1">
									                    <td>Score</td>
									                    <td>Count</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-0	</td>
									                    <td>0</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-1	</td>
									                    <td>0</td>
									                   
									                </tr>
									                <tr>
									                    <td>Score-2</td>
									                    <td>11</td>
									                    
									                </tr>
									                 
									            </tbody>
									        </table>
									    </div>
									</div>


									<div class="card">
									    <div class="card-header card-header-primary">
									        <h4 class="card-title">D-Support Services</h4>
									        
									    </div>
									    <div class="card-body table-responsive">
									        <table class="table table-hover">
									             
									            <tbody>
									            	<tr class="car-head-number1">
									                    <td>Score</td>
									                    <td>Count</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-0	</td>
									                    <td>0</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-1	</td>
									                    <td>0</td>
									                   
									                </tr>
									                <tr>
									                    <td>Score-2</td>
									                    <td>11</td>
									                    
									                </tr>
									                 
									            </tbody>
									        </table>
									    </div>
									</div>

									<div class="card">
									    <div class="card-header card-header-primary">
									        <h4 class="card-title">E-Clinical Services</h4>
									        
									    </div>
									    <div class="card-body table-responsive">
									        <table class="table table-hover">
									             
									            <tbody>
									            	<tr class="car-head-number1">
									                    <td>Score</td>
									                    <td>Count</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-0	</td>
									                    <td>0</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-1	</td>
									                    <td>0</td>
									                   
									                </tr>
									                <tr>
									                    <td>Score-2</td>
									                    <td>11</td>
									                    
									                </tr>
									                 
									            </tbody>
									        </table>
									    </div>
									</div>

									<div class="card">
									    <div class="card-header card-header-primary">
									        <h4 class="card-title">F-Infection Control</h4>
									        
									    </div>
									    <div class="card-body table-responsive">
									        <table class="table table-hover">
									             
									            <tbody>
									            	<tr class="car-head-number1">
									                    <td>Score</td>
									                    <td>Count</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-0	</td>
									                    <td>0</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-1	</td>
									                    <td>0</td>
									                   
									                </tr>
									                <tr>
									                    <td>Score-2</td>
									                    <td>11</td>
									                    
									                </tr>
									                 
									            </tbody>
									        </table>
									    </div>
									</div>

									<div class="card">
									    <div class="card-header card-header-primary">
									        <h4 class="card-title">G-Quality Management</h4>
									        
									    </div>
									    <div class="card-body table-responsive">
									        <table class="table table-hover">
									             
									            <tbody>
									            	<tr class="car-head-number1">
									                    <td>Score</td>
									                    <td>Count</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-0	</td>
									                    <td>0</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-1	</td>
									                    <td>0</td>
									                   
									                </tr>
									                <tr>
									                    <td>Score-2</td>
									                    <td>11</td>
									                    
									                </tr>
									                 
									            </tbody>
									        </table>
									    </div>
									</div>

									<div class="card">
									    <div class="card-header card-header-primary">
									        <h4 class="card-title">H-Outcome</h4>
									        
									    </div>
									    <div class="card-body table-responsive">
									        <table class="table table-hover">
									             
									            <tbody>
									            	<tr class="car-head-number1">
									                    <td>Score</td>
									                    <td>Count</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-0	</td>
									                    <td>0</td>
									                    
									                </tr>
									                <tr>
									                    <td>Score-1	</td>
									                    <td>0</td>
									                   
									                </tr>
									                <tr>
									                    <td>Score-2</td>
									                    <td>11</td>
									                    
									                </tr>
									                 
									            </tbody>
									        </table>
									    </div>
									</div>




	                			</div>
	                			<!--one ended00-->	


	                		</div>











	                		<!--------------- ol data  -------------------->
	                	<!--<table width="100%">
	                		<thead>
	                			<tr>
	                			<?php foreach ($data['cat'] as $key => $value) { ?>
	                			<th><?php echo $key.'-'.$value['categoryName']; ?></th>
	                			<?php } ?>
	                			</tr>
	                		</thead>
	                		<tbody>
	                			<tr>
	                			<?php foreach ($data['cat'] as $key => $value) { ?> 
	                				<th>
	                				<table>
	                				<?php foreach ($value['data'] as $key1 => $value1) { ?>
	                					<tr>
	                						<td><?php echo 'Score-'.$key1; ?></td>
	                						<td><?php echo $value1; ?></td>
	                					</tr>
	                				<?php } ?>	                					
	                				</table>
	                				</th>
	                			<?php } ?>
	                			</tr>	                			
	                		</tbody>
	                	</table> -->
	                    </div>
	                    <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px;">
	                    	<div class="col-md-3 col-sm-4 col-xs-6" >
	                    		<strong>Score-0 :</strong>
	                    		<?php 
								$sum = 0;
								foreach ($data['cat'] as $item) {
								    $sum += $item['data'][0];
								} echo $sum; ?>
	                    	</div>
	                    	<div class="col-md-3 col-sm-4 col-xs-6" >
	                    		<strong>Score-1 :</strong>
	                    		<?php 
								$sum = 0;
								foreach ($data['cat'] as $item) {
								    $sum += $item['data'][1];
								} echo $sum; ?>
	                    	</div>
	                    	<div class="col-md-3 col-sm-4 col-xs-6" >
	                    		<strong>Score-2 :</strong>
	                    		<?php 
								$sum = 0;
								foreach ($data['cat'] as $item) {
								    $sum += $item['data'][2];
								} echo $sum; ?>
	                    	</div>
	                    </div> 
	                </div>
	        	</div>
    		</div>
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Gap Analysis</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">

 
 
        
	    	<?php if(!empty($search_options)){ ?>	   
	        <div class="col-md-12">
	        	<div class="row mar-bottom30">
	        	<?php if(!empty($search_options['cat'])){ ?>
                <div class="col-md-4 col-xs-12 mar-top-20">
                	<select id="search_cat" name="search_cat" onchange="getData()" class="form-control search_cat selectpicker" multiple title="Pick your condiments" data-live-search="true">
						<option value="">Select Category</option>
						<?php foreach ($search_options['cat'] as $key => $value) { ?>
						<option value="<?php echo $value['CategoryCode']; ?>" ><?php echo $value['CategoryCode'].' - '.$value['CategoryName']; ?></option>
						<?php } ?>
					</select>                    
                </div>
            	<?php } ?>
                <div class="col-md-4 col-xs-12 mar-top-20">
                	<select id="search_score" name="search_score" onchange="getData()" class="form-control search_cat selectpicker" multiple title="Pick your condiments" data-live-search="true" >
						<option value="">Select Score</option>
						<option value="0" >Score-0</option>
						<option value="1" >Score-1</option>
						<option value="2" >Score-2</option>
					</select>                    
                </div>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<input type="hidden" name="search_format" id="search_format" value="<?php echo empty($search_format)?'':encryptor($search_format); ?>" >
                	<input type="hidden" name="search_answer" id="search_answer" value="<?php echo empty($search_answer)?'':encryptor($search_answer); ?>" >
                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" style="display: none;" />
                    <a href="javascript:void(0)" id="reset_btn" class="btn btn-primary">Reset</a>
                </div>
            </div>
            <hr>            	
	        </div>
	    	<?php } ?>
		
			      
			      <table id="datatable" class="table table-striped table-bordered">
			        <thead>
			            <tr>
			                <th>Area of Concern</th>
			                <th>Standard</th>
			                <th>ME Statement</th>
			                <th>CheckPoint</th>
			                <th>Score</th>
			            </tr>
			            </thead>
			            <tbody>
			            	<tr>
			            		<td></td>
			            		<td></td>
			            		<td></td>
			            		<td></td>
			                	<td></td>
			            	</tr>
			            </tbody>
			      </table>
			    </div>
			  </div>
			</div>
		</div>        
    </div>
</div>

<!-- modal window start  -->
<div id="clientScoreModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">

    <!-- Modal content-->
    <div class="modal-content">
    	<button type="button" class="close pull-right" data-dismiss="modal">&times;</button>
              <div class="panel-body">
                <div class="text-center">
                  <h3><i class="fa fa-heart fa-4x"></i></h3>
                  <h2 class="text-center">Client Satisfaction Score?</h2>
                  <p>You can add Client Satisfaction Score</p>
                  <div class="panel-body">
    
                    
    
                      <div class="form-group">
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-heart color-blue"></i></span>
                          <input maxlength="3" type="text" id="clientScore" name="clientScore" class="form-control nums" placeholder="Client Satisfaction Score">
                    <input type="hidden" id="assessmentID" name="assessmentID" class="form-control" readonly="readonly">

                        </div>
                      </div>
                      <div class="form-group">
                        <input id="clientScoreBtn" name="clientScoreBtn" type="button" class="btn btn-lg btn-primary btn-block" value="Submit Score" onclick="saveClientScore()" />
                        
                      </div>
                      
                     
                     
                  </div>
                </div>
              </div>

 
 
    </div>

  </div>
</div>

<!-- modal window end  -->
