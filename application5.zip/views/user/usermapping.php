<div class="page-title">
  <div class="title_left">
    <h3>Users</h3>
  </div>
</div>
<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>User Mapping</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">
			    <div class="row mar-top-20">
	                <div class="col-md-3 col-xs-12">
	                	<label>Role<span class="required">*</span></label>
	                	<div class="form-group">
		                	<select data-live-search="true" id="search_role" name="search_role" class="selectpicker" onchange="getuser(this)">
								<option value="0" >Select Role</option>
								<?php foreach ($rolesData as $key => $value) {
								if(strtolower($value['RoleName'])=='facility'){ continue; }
								?>
								<option value="<?php echo $value['RoleID']; ?>" ><?php echo $value['RoleName']; ?></option>
								<?php } ?>
							</select>
						</div>
	                </div>
	                <div class="col-md-3 col-xs-12">
	                	<label>User<span class="required">*</span></label>
	                	<div class="form-group">
		                	<select data-show-subtext="true" data-live-search="true" id="search_user" name="search_user" class="selectpicker" onchange="change_user();">
								<option value="0" data-subtext="" >Select User</option>
							</select>
						</div>
	                </div>
			    </div>
			    <hr>
			    <div class="row mar-top-20">
	                <div class="col-md-3 col-xs-12">
	                	<label>State<span class="required">*</span></label>
	                	<div class="form-group">
		                	<select data-live-search="true" id="search_state" name="search_state" class="selectpicker" onchange="change_state();">
							</select>
						</div>
	                </div>
	                <div class="col-md-3 col-xs-12">
	                	<label>District<span class="required">*</span></label>
	                	<div class="form-group">
		                	<select data-live-search="true" id="search_district" name="search_district" class="selectpicker" onchange="change_district();">
							</select>
						</div>
	                </div>
	                <div class="col-md-3 col-xs-12">
	                	<label>Facility<span class="required">*</span></label>
	                	<div class="form-group">
		                	<select data-live-search="true" id="facilityName" name="facilityName" class="selectpicker" onchange="">
							</select>
						</div>
	                </div>
	                <div class="col-md-3 col-xs-12">
	                	<input class="btn btn-primary" type="button" name="add" id="add" value="Add" onclick="add_row();" >
	                </div>
			    </div>

			    </div>
			  </div>
			</div>			
		</div>
	    <div class="row">
	      <div class="col-md-12 col-sm-12 col-xs-12">
	        <div class="x_panel">
	          <div class="x_title">
	            <h2>Mapped Facility</h2>
	            <ul class="nav navbar-right panel_toolbox">
	              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
	            </ul>
	            <div class="clearfix"></div>
	          </div>
	          <div class="x_content">

                <div class="col-md-12 col-sm-12 col-xs-12" style="overflow-y: auto;">
                <table class="table table-striped" id="mappedFacility">
                  <thead>
                    <tr>
                      <th>SN.</th>
                      <th>State</th>
                      <th>District</th>
                      <th>Facility</th>
                      <th>Assigned To</th>
                      <th>Role Type</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
              </div>
			    <div class="row mar-top-20">
	                <div class="col-md-3 col-xs-12 pull-right">
	                	<input class="btn btn-primary pull-right" type="button" name="save" id="save" value="Save">
	                </div>
			    </div>
	          </div>
	        </div>
	      </div>
	    </div>

    </div>
</div>