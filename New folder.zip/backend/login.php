<?php
header("Access-Control-Allow-Origin: *");
header("'Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,PATCH,OPTIONS'");
header("Access-Control-Allow-Headers: Origin, X-Requested-With,X-API-KEY, Content-Type, Accept, Authorization, Access-Control-Request-Method");
header("Access-Control-Allow-Credentials", "true"); 
header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Max-Age:3600");
require 'database.php';
  



// Get the posted data.
$postdata = file_get_contents("php://input");

if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);
	
// print_r($request);die;
  // Validate.
  if( trim($request->email)=== ''|| trim($request->password) === ''  )
  {
    return http_response_code(400);
  }
	
  // Sanitize.
  
  $email = mysqli_real_escape_string($con, trim($request->email));
  
  $password = mysqli_real_escape_string($con, trim($request->password));
    

  // Store.
  $sql = "SELECT * FROM `user` WHERE `email` = '{$email}'  AND `password` = '{$password}'";
 
  $data = mysqli_query($con,$sql);
  if($data){
    if(mysqli_num_rows($data)==1){
     $row = mysqli_fetch_assoc($data);
     // print_r($row);
     $user['firstName'] =$row['firstName'];
     $user['lastName'] =$row['lastName'];
     $user['email'] =$row['email'];
     $user['phone'] =$row['phone'];
      $user['password'] =$row['password'];

      echo json_encode($user);
   // echo 'get data';
    }
    // else{
    //     echo json_encode('No data found');
    // }
    // echo ' not get data';

  }
  // if(mysqli_query($con,$sql))
  // {


  //   http_response_code(201);
  //   $user = [
  //     'firstName' => $fname,
  //     'lastName' => $lname,
  //     'email' => $email,
  //     'phone' => $phone,
  //     'password'=>$password,
  //     'id'    => mysqli_insert_id($con)
  //   ];
  //   echo json_encode($user);
  // }
  else
  {
    echo 'noo';
    http_response_code(422);
  }
}