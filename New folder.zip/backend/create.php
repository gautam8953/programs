<?php
require 'database.php';
header("Access-Control-Allow-Origin: *");
header("'Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,PATCH,OPTIONS'");
header("Access-Control-Allow-Headers: Origin, X-Requested-With,X-API-KEY, Content-Type, Accept, Authorization, Access-Control-Request-Method");
header("Access-Control-Allow-Credentials", "true"); 
header("Access-Control-Allow-Origin: http://localhost:4200");

header("Access-Control-Max-Age:3600");   



// Get the posted data.
$postdata = file_get_contents("php://input");

if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);
	

  // Validate.
  if(trim($request->firstName) === '' || trim($request->lastName) === '' || trim($request->email)===''|| trim($request->phone) === '' || trim($request->password) === ''  )
  {
    return http_response_code(400);
  }
	
  // Sanitize.
  $fname = mysqli_real_escape_string($con, trim($request->firstName));
  $lname = mysqli_real_escape_string($con, trim($request->lastName));
  $email = mysqli_real_escape_string($con, trim($request->email));
  $phone = mysqli_real_escape_string($con, trim($request->phone));
  $password = mysqli_real_escape_string($con, trim($request->password));
    

  // Store.
  $sql = "INSERT INTO `user`(`id`,`firstName`,`lastName`,`email`,`phone`,`password`) VALUES (null,'{$fname}','{$lname}','{$email}','{$phone}','{$password}')";

  if(mysqli_query($con,$sql))
  {
    http_response_code(201);
    $user = [
      'firstName' => $fname,
      'lastName' => $lname,
      'email' => $email,
      'phone' => $phone,
      'password'=>$password,
      'id'    => mysqli_insert_id($con)
    ];
    echo json_encode($user);
  }
  else
  {
    http_response_code(422);
  }
}