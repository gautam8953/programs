import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../_models/user';

@Injectable({ providedIn: 'root' })
export class UserService {

  // PHP_API_SERVER = "http://127.0.0.1";

  constructor(private http: HttpClient) { }

  register(user: User): Observable<User>{
      return this.http.post<User>(`backend/user/create.php`, user);
  }

  
  getAll() {
    return this.http.get<User[]>(`/users`);
}



delete(id: number) {
    return this.http.delete(`/users/${id}`);
}

}