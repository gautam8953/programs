<style>
.alert1 {
    color: rgb(192, 80, 77);
}

.fsSectionHeader {
    background-color: #3f92ea;
    margin: 10px 0;
    padding: 5px 15px;
    color: #fff;
    font-family: "Source Sans Pro", sans-serif;
}

.fsSectionHeader {}

.new-tabl-miss-report .tab .nav-tabs {
    padding-left: 15px;
    border-bottom: 4px solid #344c98;
}

.new-tabl-miss-report .tab .nav-tabs li a {
    color: #fff;
    padding: 10px 20px;
    margin-right: 10px;
    background: #344c98;
    text-shadow: 1px 1px 2px #000;
    border: none;
    border-radius: 0;
    opacity: 0.5;
    position: relative;
    transition: all 0.3s ease 0s;
}

.backbtn {
    float: left;
    padding: 5px 20px !important;
    color: #fff;
    border-radius: 30px !important;
    /* padding: 2px 15px 2px 15px; */
    padding: 5px 20px;
    background: #119075 !important;
    border: 1px solid #119075 !important;
    padding: 5px 20px !important;
}

.forwart-dtnbtn {
    float: right;
    padding: 5px 20px !important;
    color: #fff;
    border-radius: 30px !important;
    /* padding: 2px 15px 2px 15px; */
    padding: 5px 20px;
    background: #4395c5 !important;
    border: 1px solid #4395c5 !important;
    padding: 5px 20px !important;
    margin-left: 4px;
}

.new-tabl-miss-report .tab .tab-pane {
    padding: 0;
    font-family: "Source Sans Pro", sans-serif;
}

.new-tabl-miss-report .tab .nav-tabs li a:hover {
    background: #344c98;
    opacity: 0.8;
}

.new-tabl-miss-report .tab .nav-tabs li.active a {
    opacity: 1;
}

.new-tabl-miss-report .tab .nav-tabs li.active a,
.new-tabl-miss-report.tab .nav-tabs li.active a:hover,
.new-tabl-miss-report.tab .nav-tabs li.active a:focus {
    color: #fff;
    background: #344c98;
    border: none;
    border-radius: 0;
}

.new-tabl-miss-report .tab .nav-tabs li a:before,
.new-tabl-miss-report .tab .nav-tabs li a:after {
    content: "";
    border-top: 42px solid transparent;
    position: absolute;
    top: -2px;
}

.new-tabl-miss-report .tab .nav-tabs li a:before {
    border-right: 15px solid #344c98;
    left: -15px;
}

.new-tabl-miss-report .tab .nav-tabs li a:after {
    border-left: 15px solid #344c98;
    right: -15px;
}

.new-tabl-miss-report .tab .nav-tabs li a i,
.new-tabl-miss-report.tab .nav-tabs li.active a i {
    display: inline-block;
    padding-right: 5px;
    font-size: 15px;
    text-shadow: none;
}

.new-tabl-miss-report .tab .nav-tabs li a span {
    display: inline-block;
    font-size: 14px;
    letter-spacing: -9px;
    opacity: 0;
    transition: all 0.3s ease 0s;
}

.new-tabl-miss-report .tab .nav-tabs li a:hover span,
.new-tabl-miss-report .tab .nav-tabs li.active a span {
    letter-spacing: 1px;
    opacity: 1;
    transition: all 0.3s ease 0s;
}

.new-tabl-miss-report .tab .tab-content {
    padding: 10px;
    background: #fff;
    font-size: 16px;
    color: #6c6c6c;
    line-height: 25px;
    border: 1px solid #344c98;
    float: left;
    width: 100%;
}

.new-tabl-miss-report .tab .tab-content h3 {
    font-size: 24px;
    margin-top: 0;
}

.form-note {
    margin: 15px 0;
    background-color: #E7E7E7 !important;
    color: #8C98A0 !important;
    -moz-border-radius: 6px;
    -webkit-border-radius: 6px;
    border-radius: 6px;
    padding: 12px 18px;
    text-align: center;
}

.form-note p {
    margin: 0 !important;
    vertical-align: middle !important;
    font-size: 14px !important;
}

.form-new-fild1{    min-height: 250px;}
.form-new-fild1 label{    font-weight: normal !important;
    font-size: 15px !important;
    position: relative;
    color: rgb(51, 51, 51);}
    
    @media only screen and (max-width: 479px) {
        .new-tabl-miss-report .tab .nav-tabs li {
            width: 100%;
            margin-bottom: 5px;
            text-align: center;
        }
        .new-tabl-miss-report .tab .nav-tabs li a span {
            letter-spacing: 1px;
            opacity: 1;
        }
    }
</style>

<div class="page-title">
    <div class="title_left full-width">
        <h3>Facility Based Maternal Near Miss Review Form</h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="main-content main-content-form-gr-h ApplyFor_center newap-cneter carti-c">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">

                    <div class="">
                        <div class="new-tabl-miss-report">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="tab" role="tabpanel">
                                            <!-- Nav tabs -->
                                            <ul class="nav nav-tabs" role="tablist">
                                                <li role="presentation" class="active"><a href="#Section1" aria-controls="home" role="tab" data-toggle="tab"><i class="fa fa-home"></i><span>Overview</span></a></li>
                                                <li role="presentation"><a href="#Section2" aria-controls="profile" role="tab" data-toggle="tab"><i class="fa fa-globe"></i><span>SECTION-2</span></a></li>
                                                <li role="presentation"><a href="#Section3" aria-controls="messages" role="tab" data-toggle="tab"><i class="fa fa-briefcase"></i><span>SECTION-3</span></a></li>
                                            </ul>
                                            <!-- Tab panes -->
                                            <div class="tab-content tabs">
                                                <div role="tabpanel" class="tab-pane fade in active" id="Section1">
                                                    <div class="table-report-form">
                                                        <div class="fsSectionHeader">
                                                            <h2 class="fsSectionHeading">MNM-R form</h2></div>

                                                            <div class="col-md-12">

                                                                <div class="form-note">
                                                                    <p>
                                                                        <b>Note:</b>&nbsp;Your privacy is very important to us. To better serve you, the form information you enter is recorded in real time.
                                                                    </p>
                                                                </div>
                                                            </div>

                                                            <div class="col-md-12">
                                                                <p>The information below will be used for Facility Based Maternal Near Miss Review </p>
                                                                <p>Once you are done with all the important, an email will be sent to the email address below with instructions and status.<br> <br></p>
                                                                <div class="form-new-fild1">
                                                                    <div class="col-md-12">
                                                                        <div class="row">
                                                                            <div class="col-md-12">

                                                                                <div class="form-group">
                                                                                    <label for="venue_name">Name & Address of Medical College/FRU <em>*</em></label>&nbsp;

                                                                                    <input type="text" class="form-control"  placeholder="Name & Address of Medical College/FRU">
                                                                                </div>

                                                                            </div>

                                                                        </div>
                                                                    </div>



                                                                    <div class="col-md-12">
                                                                        <div class="row">
                                                                            <div class="col-md-6">

                                                                                <div class="form-group">
                                                                                    <label for="venue_name">Name of Nodal Person  <em>*</em></label>&nbsp;
                                                                                    <input type="text" class="form-control" placeholder="Name of Nodal Person">
                                                                                </div>

                                                                            </div>

                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <label for="venue_phone">Contact No<em>*</em></label>
                                                                                    <input type="text" class="form-control" placeholder="Phone Number">
                                                                                </div>

                                                                                <!------- check box ---------->

                                                                            </div>
                                                                        </div>
                                                                    </div>



                                                                    <div class="col-md-12">
                                                                        <div class="row">
                                                                         <div class="annoumt1">
                                                                             <ul>
                                                                                <li><i class="fa fa-circle-o" aria-hidden="true"></i>This form must be filled for all cases of Maternal Near Miss as per Definition and criteria ( as per Annexure 1)</li>
                                                                                <li><i class="fa fa-circle-o" aria-hidden="true"></i>FB MNM-R number must be put serially e.g 001-dt-mth-yr. </li>
                                                                                <li><i class="fa fa-circle-o" aria-hidden="true"></i>Mark with "check" wherever applicable</li>
                                                                                <li><i class="fa fa-circle-o" aria-hidden="true"></i>For Date use Day/Month/Year format. For time use 24hours clock format.</li>
                                                                                <li><i class="fa fa-circle-o" aria-hidden="true"></i>Complete form at the time of discharge of woman with Maternal Near Miss, keep photocopy & send original to Nodal Officer MNM - R Committee</li>
                                                                                <li><i class="fa fa-circle-o" aria-hidden="true"></i>New series starts with new year</li>
                                                                                <li><i class="fa fa-circle-o" aria-hidden="true"></i>Attach copy of discharge summary with this form</li> 
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>



                                                            </div><!-------- form-new-fild1 ended--------->
                                                        </div>

                                                        <!-- ----------------------- button ---------------------->
                                                        <div class="col-md-12">

                                                            <div id="button" class="fsSubmit">
                                                                <div class="col-md-12">

                                                                    <center>
                                                                        <span class="Process1"> Process </span>
                                                                        <div class="progress prog">

                                                                            <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0%;">0%</div>
                                                                        </div>
                                                                    </center>
                                                                    <button type="button" id="prev" class="fsPreviousButton back-btn back backbtn" value="Previous Page"><span class="fsFull ">← Previous </span></button>

                                                                    <button type="button" id="next" onclick="incr()" class="fsNextButton next-btn next  forwart-dtnbtn" value="Next Page"><span class="fsFull">Next →</span></button>

                                                                    <div class="submit-bn text-right">

                                                                        <input id="submit" class="fsSubmitButton fsSubmitMultipage submit forwart-dtnbtn" name="submit" type="submit" value=" Submit for review">

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>

                                                </div>
                                                <div role="tabpanel" class="tab-pane fade" id="Section2">
                                                 <div class="table-report-form">
                                                    <div class="fsSectionHeader">
                                                        <h2 class="fsSectionHeading">Genral Information</h2></div>

                                                        
                                                        <div class="col-md-12">
                                                            <div class="sub-heading1">
                                                                Genral Information
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">

                                                            <div class="form-new-fild1">


                                                                <div class="col-md-12">
                                                                    <div class="row">
                                                                        <div class="col-md-6">

                                                                            <div class="form-group">
                                                                                <label for="venue_name"> Full Name  <em>*</em></label>&nbsp;
                                                                                <input type="text" class="form-control" placeholder="Full Name ">
                                                                            </div>

                                                                        </div>

                                                                        <div class="col-md-6">
                                                                            <div class="row">
                                                                             <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <label for="venue_phone">Age<em>*</em></label>
                                                                                    <input type="text" class="form-control" placeholder="Age">
                                                                                </div>

                                                                                <!------- check box ---------->

                                                                            </div>

                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <label for="venue_phone">Inpatient No<em>*</em></label>
                                                                                    <input type="text" class="form-control" placeholder="Inpatient No.">
                                                                                </div>

                                                                                <!------- check box ---------->

                                                                            </div>
                                                                        </div>


                                                                        <!------- check box ---------->

                                                                    </div>
                                                                </div>
                                                            </div>


                                                            <div class="col-md-12">
                                                                <div class="row">
                                                                    <div class="col-md-6">

                                                                        <div class="form-group">
                                                                            <label for="venue_name"> Contact No</label>&nbsp;
                                                                            <input type="text" class="form-control" placeholder="Contact No">
                                                                        </div>

                                                                    </div>

                                                                    <div class="col-md-6">

                                                                        <div class="form-group">
                                                                            <label for="venue_name"> Complete address</label>&nbsp;
                                                                            <textarea type="text" class="form-control" placeholder="Complete address"></textarea>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>


                                                            <div class="col-md-12">
                                                                <div class="row">


                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label for="venue_phone">Education <em>*</em></label><br>
                                                                            <label class="checkbox-inline">
                                                                              <input type="checkbox" value="">Illiterate
                                                                          </label>
                                                                          <label class="checkbox-inline">
                                                                              <input type="checkbox" value="">literate Upto 5th class
                                                                          </label>
                                                                          <label class="checkbox-inline">
                                                                              <input type="checkbox" value="">6th to 12th class 
                                                                          </label>
                                                                          <label class="checkbox-inline">
                                                                              <input type="checkbox" value="">Beyond 12th class  
                                                                          </label>
                                                                      </div>

                                                                      <!------- check box ---------->

                                                                  </div>

                                                                  <div class="col-md-6">

                                                                    <div class="form-group">
                                                                        <label for="venue_name"> Below Poverty Line status</label>&nbsp;
                                                                        <br>
                                                                        <label class="checkbox-inline">
                                                                          <input type="checkbox" value="">BPL Certificate / Self certified 
                                                                      </label>
                                                                      <label class="checkbox-inline">
                                                                          <input type="checkbox" value="">Not BPL
                                                                      </label>

                                                                  </div>

                                                              </div>


                                                          </div>
                                                      </div>

                                                      <div class="col-md-12">
                                                        <div class="row">

                                                            <div class="col-md-6">
                                                                <div class="row">

                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label for="venue_phone">Date of admission <em>*</em></label>
                                                                            <input type="text" class="form-control datetimepicker" placeholder="Date of admission">
                                                                        </div>
                                                                    </div>


                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label for="venue_phone">Date of discharge <em>*</em></label>
                                                                            <input type="text" class="form-control datetimepicker" placeholder="Date of discharge">
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>


                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="venue_phone">Date and time when became near miss <em>*</em></label>
                                                                    <input type="text" class="form-control datetimepicker" placeholder="Date and time when became near miss">
                                                                </div>
                                                            </div>



                                                        </div>
                                                    </div>


                                                    

                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="venue_phone">Type of Discharge <em>*</em></label><br>
                                                            <label class="checkbox-inline">
                                                              <input type="checkbox" value="">By Hospital 
                                                          </label>
                                                          <label class="checkbox-inline">
                                                              <input type="checkbox" value="">On Request
                                                          </label>
                                                          <label class="checkbox-inline">
                                                              <input type="checkbox" value="">Left Against Medical advice 
                                                          </label>
                                                          <label class="checkbox-inline">
                                                              <input type="checkbox" value="">Referred to Other Centre 
                                                          </label>
                                                          <label class="checkbox-inline">
                                                              <input type="checkbox" value="">Absconded
                                                          </label>

                                                      </div> 

                                                  </div>


                                                  <div class="col-md-12">
                                                    <div class="row">
                                                        <div class="col-md-6">

                                                            <div class="form-group">
                                                                <label for="venue_name"> Provisional Diagnosis At Admission </label>&nbsp;
                                                                <input type="text" class="form-control" placeholder="Provisional Diagnosis At Admission">
                                                            </div>

                                                        </div>

                                                        <div class="col-md-6">

                                                            <div class="form-group">
                                                                <label for="venue_name"> Final Diagnosis At Discharge</label>&nbsp;
                                                                <textarea type="text" class="form-control" placeholder="Final Diagnosis At Discharge"></textarea>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="row">

                                                        <div class="col-md-6">
                                                            <div class="row">
                                                                <div class="form-group">
                                                                    <div class="col-md-12">
                                                                        <label for="venue_name"> Duration of Hospital stay </label>&nbsp;
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <input type="text" class="form-control" placeholder="Days">
                                                                    </div>


                                                                    <div class="col-md-6"> 
                                                                        <input type="text" class="form-control" placeholder="Hours">
                                                                    </div>


                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <div class="row">
                                                                <div class="form-group">
                                                                    <div class="col-md-12">
                                                                        <label for="venue_name"> Duration of ICU stay </label>&nbsp;
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <input type="text" class="form-control" placeholder="Days">
                                                                    </div>


                                                                    <div class="col-md-6"> 
                                                                        <input type="text" class="form-control" placeholder="Hours">
                                                                    </div>


                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>




                                                <div class="col-md-12">
                                                    <div class="sub-heading1">
                                                        Condition at Time of Admission
                                                    </div>
                                                </div>


                                                 <div class="col-md-12">
                                                   
                                                        <div class="col-md-6">

                                                            <div class="form-group">
                                                                <label for="venue_name"> Condition at Time of Admission </label>&nbsp;
                                                                
                                                                <div class="checkbox">
                                                                  <label><input type="checkbox" value="">Option 1</label>
                                                                </div>

                                                            </div>

                                                       

                                                        
                                                    </div>
                                                </div>

















                                            </div><!-------- form-new-fild1 ended--------->
                                        </div>

                                        <!-- ----------------------- button ---------------------->
                                        <div class="col-md-12">

                                            <div id="button" class="fsSubmit">
                                                <div class="col-md-12">

                                                    <center>
                                                        <span class="Process1"> Process </span>
                                                        <div class="progress prog">

                                                            <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 15%;">15%</div>
                                                        </div>
                                                    </center>
                                                    <button type="button" id="prev" class="fsPreviousButton back-btn back backbtn" value="Previous Page"><span class="fsFull ">← Previous </span></button>

                                                    <button type="button" id="next" onclick="incr()" class="fsNextButton next-btn next  forwart-dtnbtn" value="Next Page"><span class="fsFull">Next →</span></button>

                                                    <div class="submit-bn text-right">

                                                        <input id="submit" class="fsSubmitButton fsSubmitMultipage submit forwart-dtnbtn" name="submit" type="submit" value=" Submitfor review">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="Section3">
                                    <h3>Section 3</h3>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nec urna aliquam, ornare eros vel, malesuada lorem. Nullam faucibus lorem at eros consectetur lobortis. Maecenas nec nibh congue, placerat sem id, rutrum velit. Phasellus porta enim at facilisis condimentum. Maecenas pharetra dolor vel elit tempor pellentesque sed sed eros. Aenean vitae mauris tincidunt, imperdiet orci semper, rhoncus ligula. Vivamus scelerisque.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
</div>
</div>
</div>


<script type="text/javascript">

    // forward click 
    $(".fsSubmit .forwart-dtnbtn").click(function(){
        $(this).parents(".tab").find(".nav-tabs").find(".active").next().find("a").trigger("click");
    });

    // backward click 
    $(".fsSubmit .backbtn").click(function(){
        $(this).parents(".tab").find(".nav-tabs").find(".active").prev().find("a").trigger("click");
    });


</script>