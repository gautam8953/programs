<style>
.col-md-4 .bootstrap-select button,
input {
    margin-bottom: 7px !important;
}
</style>

<div class="page-title">
    <div class="title_left full-width">
        <h3>Audit</h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="main-content main-content-form-gr-h ApplyFor_center newap-cneter carti-c">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>C-section Audit</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div id="smartwizard">
                            <ul>
                                <li><a href="#step-0"><span><em> A </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>General Information<br /></a></li>
                                <li><a href="#step-1"><span><em> B </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>Audit Form<br /></a></li>
                            </ul>
                            <div>
                                <!-- Step Start -->
                                <div id="step-0">
                                    <!--- static code ------>
                                    <div class="list-report-monthly">

                                        <h5 class="tab-title">Section 1: General Information </h5>

                                        <?php if(isset($search_options['State']) ){ ?>
                                            <div class="col-md-3 col-xs-12 mar-top-20">
                                                <select id="search_state" name="search_state" onchange="change_state()" class="selectpicker" data-live-search="true" data-width="100%">
                                                    <option value="">Select State</option>
                                                    <?php foreach ($search_options['State'] as $key => $value) {  ?>
                                                        <option value="<?php echo $value['StateID']; ?>">
                                                            <?php echo $value['StateName']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        <?php } ?>
                                        <?php if(isset($search_options['District']) ){ ?>
                                            <div class="col-md-3 col-xs-12 mar-top-20">
                                                <select id="search_district" name="search_district" onchange="change_district()" class="selectpicker" data-live-search="true" data-width="100%">
                                                    <option value="">Select District</option>
                                                    <?php foreach ($search_options['District'] as $key => $value) { ?>
                                                        <option value="<?php echo $value['DistrictID']; ?>">
                                                            <?php echo $value['DistrictName']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        <?php } ?>
                                        <?php if(isset($search_options['Facility']) ){ //for minisry,state,district user ?>
                                            <div class="col-md-3 col-xs-12 mar-top-20">
                                                <select id="search_facility" name="search_facility" class="selectpicker" data-live-search="true" data-width="100%" onchange="change_facility()">
                                                    <option value="">Select Facility</option>
                                                    <?php  foreach ($search_options['Facility'] as $key => $value) {  ?>
                                                        <option value="<?php echo $value['UserID']; ?>">
                                                            <?php echo $value['FacilityName']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        <?php } ?>
                                        <?php if(isset($search_options['Facility_show']) ){ // for facility user only?>

                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <div class="form-group">
                                                    <label> Name of the Facility <span class="required"> * </span> </label>
                                                    <input type="text" id="search_facility" name="search_facility" class="form-control" placeholder="Name of the Facility" value="<?php echo empty($search_options['Facility_show']['FacilityName'])?'':$search_options['Facility_show']['FacilityName']; ?>" readonly="readonly">

                                                </div>
                                            </div>

                                        <?php } ?>

                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-group">
                                                <label> Station <span class="required"> * </span> </label>
                                                <input minlength="1" maxlength="100" type="text" id="station" name="station" class="form-control " placeholder="Station" value="<?php echo empty($csection['station'])?'':$csection['station']; ?>">

                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-group">
                                                <label> Type of Facility <span class="required"> * </span> </label>
                                                <select id="facility_type" name="facility_type" class="selectpicker" data-live-search="true" data-width="100%">
                                                    <?php foreach ($options['facility_type'] as $key => $value) { ?>
                                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection[ 'facility_type']){ echo ' selected="selected" '; } ?> >
                                                            <?php echo $value; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-group">
                                                <label> Designation <span class="required"> * </span> </label>
                                                <input minlength="1" maxlength="100" type="text" id="designation" name="designation" class="form-control " placeholder="Designation" value="<?php echo empty($csection['designation'])?'':$csection['designation']; ?>">

                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-group">
                                                <label> Date Of Submission <span class="required"> * </span> </label>
                                                <input minlength="1" maxlength="100" type="text" id="dos" name="dos" class="form-control datepicker" placeholder="Date Of Submission" value="<?php echo empty($csection['dos'])?'':$csection['dos']; ?>">

                                            </div>
                                        </div>

                                    </div>
                                    <!----------- static code ----------->

                                    <div class="clear"></div>
                                </div>
                                <div id="step-1" style="">
                                    <div class="csstion-form">

                                    	<!-- new code --------->

                                    	<div class="list-report-monthly">

                                          <h5 class="tab-title">Section 2: Audit Details </h5>

                                          <div class="col-md-6 col-sm-6 col-xs-12">
                                              <div class="form-group">
                                                  <label> Name of the Mother, Age(Yrs) <span class="required"> * </span> </label>
                                                  <input type="text" id="mother_age" name="mother_age"  class="form-control " placeholder="Name of the Mother, Age(Yrs)" value="<?php echo empty($csection['mother_age'])?'':$csection['mother_age']; ?>">

                                              </div>
                                          </div>


                                          <div class="col-md-6 col-sm-6 col-xs-12">
                                              <div class="form-group">
                                                  <label> Hospital No. <span class="required"> * </span> </label>
                                                  <input type="text"  id="hospital_num" name="hospital_num"  class="form-control " placeholder="Hospital No." value="<?php echo empty($csection['hospital_num'])?'':$csection['hospital_num']; ?>">

                                              </div>
                                          </div>


                                          <div class="col-md-6 col-sm-6 col-xs-12">
                                              <div class="form-group">
                                                  <label> G/P/L/A <span class="required"> * </span> </label>
                                                  <input type="text"  id="gpla" name="gpla" class="form-control" placeholder="G/P/L/A" value="<?php echo empty($csection['gpla'])?'':$csection['gpla']; ?>">

                                              </div>
                                          </div>


                                          <div class="col-md-6 col-sm-6 col-xs-12">
                                              <div class="form-group">
                                                  <label> Date of Admission<span class="required"> * </span> </label>
                                                  <input type="text" type="text" id="doa" name="doa" class="form-control datepicker" placeholder="Date of Admission" value="<?php echo empty($csection['doa'])?'':$csection['doa']; ?>">

                                              </div>
                                          </div>


                                          <div class="col-md-6 col-sm-6 col-xs-12">
                                              <div class="form-group">
                                                  <label> Date of delivery by CS<span class="required"> * </span> </label>
                                                  <input minlength="1" maxlength="15" type="text" id="docs" name="docs" class="form-control datepicker" placeholder="Date of delivery by CS" value="<?php echo empty($csection['docs'])?'':$csection['docs']; ?>">

                                              </div>
                                          </div>


                                          <div class="col-md-6 col-sm-6 col-xs-12">
                                              <div class="form-group">
                                                  <label> Date of CS audit<span class="required"> * </span> </label>
                                                  <input minlength="1" maxlength="15" type="text" id="docs_audit" name="docs_audit" class="form-control datepicker" placeholder="Date of CS audit" value="<?php echo empty($csection['docs_audit'])?'':$csection['docs_audit']; ?>">

                                              </div>
                                          </div>


                                          <div class="col-md-6 col-sm-6 col-xs-12">
                                              <div class="form-group">
                                                  <label> Maternal height (in cms) and weight (in kgs)<span class="required"> * </span> </label>
                                                  <input minlength="1" maxlength="30" type="text" id="height_weight" name="height_weight" class="form-control" placeholder="Maternal height (in cms) and weight (in kgs)" value="<?php echo empty($csection['height_weight'])?'':$csection['height_weight']; ?>">

                                              </div>
                                          </div>



                                          <div class="col-md-6 col-sm-6 col-xs-12">
                                              <div class="form-group">
                                                  <label> Booking status<span class="required"> * </span> </label>
                                                  <select id="book_status" name="book_status" class="selectpicker" data-live-search="true" data-width="100%">
                                                    <?php foreach ($options['book_status'] as $key => $value) { ?>
                                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection[ 'book_status']){ echo ' selected="selected" '; } ?> >
                                                            <?php echo $value; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>

                                            </div>
                                        </div>


                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                          <div class="form-group">
                                              <label> Estimated gestation, in completed weeks<span class="required"> * </span> </label>
                                              <input minlength="1" maxlength="100" type="text" id="gestation" name="gestation" class="form-control" placeholder="Estimated gestation, in completed weeks " value="<?php echo empty($csection['gestation'])?'':$csection['gestation']; ?>">

                                          </div>
                                      </div>

                                      <div class="col-md-6 col-sm-6 col-xs-12">
                                          <div class="form-group">
                                              <label> Based on:<span class="required"> * </span> </label>
                                              <select id="based" name="based" class="selectpicker" data-live-search="true" data-width="100%">
                                                <?php foreach ($options['based'] as $key => $value) { ?>
                                                    <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection[ 'based']){ echo ' selected="selected" '; } ?> >
                                                        <?php echo $value; ?>
                                                    </option>
                                                <?php } ?>
                                            </select>

                                        </div>
                                    </div> 
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                      <div class="form-group">
                                          <label> Number of previous stillbirths >24 weeks, if any<span class="required"> * </span> </label>
                                          <input minlength="1" maxlength="100" type="text" id="prev_stillbirths" name="prev_stillbirths" class="form-control" placeholder="Number of previous stillbirths >24 weeks, if any" value="<?php echo empty($csection['prev_stillbirths'])?'':$csection['prev_stillbirths']; ?>">

                                      </div>
                                  </div>

                                  <div class="col-md-6 col-sm-6 col-xs-12">
                                      <div class="form-group">
                                          <label>Was the mother transferred to this hospital with baby in utero?<span class="required"> * </span> </label>
                                          <select id="baby_in_utero" name="baby_in_utero" class="selectpicker" data-live-search="true" data-width="100%" onchange="baby_in_utero(this)">
                                            <?php foreach ($options['baby_in_utero'] as $key => $value) { ?>
                                                <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection[ 'baby_in_utero']){ echo ' selected="selected" '; } ?> >
                                                    <?php echo $value; ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>



                                <div class="col-md-6 col-sm-6 col-xs-12" style="display:<?php if(isset($csection) && $csection['baby_in_utero']=='1'){ echo 'block'; } else { echo 'none'; } ?> ">
                                  <div class="form-group">
                                      <label>If Yes, </label>
                                      <input minlength="1" maxlength="100" type="text" id="transferred_facility" name="transferred_facility" class="form-control" placeholder="If yes, name of the transferring facility" value="<?php echo empty($csection['transferred_facility'])?'':$csection['transferred_facility']; ?>">
                                  </div>
                              </div>


                              <div class="col-md-6 col-sm-6 col-xs-12" style="display:<?php if(isset($csection) && $csection['baby_in_utero']=='1'){ echo 'block'; } else { echo 'none'; } ?> ">
                                  <div class="form-group">
                                      <label>If yes: GA </label>
                                      <select id="ga" name="ga" class="selectpicker" data-live-search="true" data-width="100%">
                                        <?php foreach ($options['ga'] as $key => $value) { ?>
                                            <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection[ 'ga']){ echo ' selected="selected" '; } ?> >
                                                <?php echo $value; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>


                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <div class="form-group">
                                  <label>If preterm was AN conticosteroids given prior to transfer</label>
                                  <select id="conticosteroids" name="conticosteroids" class="selectpicker" data-live-search="true" data-width="100%">
                                    <?php foreach ($options['conticosteroids'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection[ 'conticosteroids']){ echo ' selected="selected" '; } ?> >
                                            <?php echo $value; ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <div class="form-group">
                              <label> Who was the most senior obstetrician involved in the decision to perform the caesarean section? <span class="required"> * </span> </label>
                              <select id="senior_obstetrician" name="senior_obstetrician" class="selectpicker" data-live-search="true" data-width="100%">
                                <?php foreach ($options['senior_obstetrician'] as $key => $value) { ?>
                                    <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection[ 'senior_obstetrician']){ echo ' selected="selected" '; } ?> >
                                        <?php echo $value; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> <br>Which of the following best describes the indication for CS? <span class="required"> * </span><br></label>


                            <select id="indication" name="indication" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                <?php foreach ($options['indication'] as $key => $value) { ?>
                                    <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['indication']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Was labour onset spontaneous?  <span class="required"> * </span></label>
                            <input type="text" minlength="1" maxlength="100" type="text" id="onset_spontaneous" name="onset_spontaneous" class="form-control" placeholder="Was labour onset spontaneous?" value="<?php echo empty($csection['onset_spontaneous'])?'':$csection['onset_spontaneous']; ?>">

                        </div>
                    </div>



                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Was pre-labour prostaglandin used? <span class="required"> * </span> </label>
                            <input minlength="1" maxlength="100" type="text" id="pre_labour_prostaglandin" name="pre_labour_prostaglandin" class="form-control" placeholder="Was pre-labour prostaglandin used?" value="<?php echo empty($csection['pre_labour_prostaglandin'])?'':$csection['pre_labour_prostaglandin']; ?>"  >

                        </div>
                    </div>



                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Was oxytocin used for induction/acceleration before delivery? <span class="required"> * </span> </label>
                            <input minlength="1" maxlength="100" type="text" id="oxytocin_used" name="oxytocin_used" class="form-control" placeholder="Was oxytocin used for induction/acceleration before delivery?" value="<?php echo empty($csection['oxytocin_used'])?'':$csection['oxytocin_used']; ?>"  >

                        </div>
                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Was partograph used prior to decision for CS? <span class="required"> * </span> </label>
                            <input minlength="1" maxlength="100" type="text" id="partograph_used" name="partograph_used" class="form-control" placeholder="Was partograph used prior to decision for CS" value="<?php echo empty($csection['partograph_used'])?'':$csection['partograph_used']; ?>"  >

                        </div>
                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Were the membranes ruptured (ROM) prior to the caesarean section? <span class="required"> * </span> </label>
                            <select id="ROM" name="ROM" class="form-control selectpicker" data-live-search="true" data-width="100%">
                                <?php foreach ($options['ROM'] as $key => $value) { ?>
                                    <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['ROM']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                <?php } ?>
                            </select>

                        </div>
                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Duration of first stage of labour  <span class="required"> * </span></label>
                            <input minlength="1" maxlength="100" type="text" id="first_labour_duration" name="first_labour_duration" class="form-control" placeholder="Duration of first stage of labour" value="<?php echo empty($csection['first_labour_duration'])?'':$csection['first_labour_duration']; ?>"  >

                        </div>
                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Duration of first stage of labour <span class="required"> * </span></label>
                            <input minlength="1" maxlength="100" type="text" id="second_labour_duration" name="second_labour_duration" class="form-control" placeholder="Duration of second stage of labour" value="<?php echo empty($csection['second_labour_duration'])?'':$csection['second_labour_duration']; ?>"  >

                        </div>
                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>What cervical dilatation was reached prior to the caesarean section? <span class="required"> * </span></label>
                            <input minlength="1" maxlength="100" type="text" id="cervical_dilatation" name="cervical_dilatation" class="form-control" placeholder="What cervical dilatation was reached prior to the caesarean section?" value="<?php echo empty($csection['cervical_dilatation'])?'':$csection['cervical_dilatation']; ?>"  >
                        </div>
                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>If multiple pregnancy, were both babies delivered by CS or 1st baby delivered vaginally and 2nd baby by CS? </label>
                            <input minlength="1" maxlength="100" type="text" id="multiple_pregnancy" name="multiple_pregnancy" class="form-control" placeholder="If multiple pregnancy, were both babies delivered by CS or 1st baby delivered vaginally and 2nd baby by CS?" value="<?php echo empty($csection['multiple_pregnancy'])?'':$csection['multiple_pregnancy']; ?>"  >
                        </div>
                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label><br>Were prophylactic antibiotics given? <span class="required"> * </span></label>
                            <input minlength="1" maxlength="100" type="text" id="prophylactic_antibiotics" name="prophylactic_antibiotics" class="form-control" placeholder="Were prophylactic antibiotics given?" value="<?php echo empty($csection['prophylactic_antibiotics'])?'':$csection['prophylactic_antibiotics']; ?>"  >
                        </div>
                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>What was the estimated blood loss? <span class="required"> * </span></label>
                            <input minlength="1" maxlength="100" type="text" id="blood_loss" name="blood_loss" class="form-control" placeholder="What was the estimated blood loss?" value="<?php echo empty($csection['blood_loss'])?'':$csection['blood_loss']; ?>"  >
                        </div>
                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>What was the estimated blood loss? <span class="required"> * </span></label>
                            <input minlength="1" maxlength="100" type="text" id="blood_loss" name="blood_loss" class="form-control" placeholder="What was the estimated blood loss?" value="<?php echo empty($csection['blood_loss'])?'':$csection['blood_loss']; ?>"  >
                        </div>
                    </div>


                    <div class="col-md-12">
                        <div class="form-sub-heading">
                            In case of previous Caesarean delivery
                        </div>
                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>Number of pregnancies, prior to this pregnancy, of >20 weeks <span class="required"> * </span></label>
                            <input minlength="1" maxlength="100" type="text" id="pregnancies_number_greater" name="pregnancies_number_greater" class="form-control" placeholder="Number of pregnancies, prior to this pregnancy, of >20 weeks" value="<?php echo empty($csection['pregnancies_number_greater'])?'':$csection['pregnancies_number_greater']; ?>"  >
                        </div>
                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>Number of pregnancies, prior to this pregnancy, of <20 weeks <span class="required"> * </span></label>
                             <input minlength="1" maxlength="100" type="text" id="pregnancies_number_less" name="pregnancies_number_less" class="form-control" placeholder="Number of pregnancies, prior to this pregnancy, of <20 weeks" value="<?php echo empty($csection['pregnancies_number_less'])?'':$csection['pregnancies_number_less']; ?>"  >
                             </div>
                         </div>


                         <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Mode of termination <span class="required"> * </span></label>
                                <select id="termination_mode" name="termination_mode" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['termination_mode'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['termination_mode']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Has the mother had a previous caesarean section? <span class="required"> * </span></label>
                                <select id="previous_caesarean_section" name="previous_caesarean_section" class="form-control selectpicker" data-live-search="true" data-width="100%" onchange="previous_caesarean_section(this)" >
                                    <?php foreach ($options['previous_caesarean_section'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['previous_caesarean_section']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>




                        <div class="col-md-6 col-sm-6 col-xs-12 previous_caesarean_section" style="display:<?php if(isset($csection) && $csection['previous_caesarean_section']=='1'){ echo 'block'; } else { echo 'none'; } ?> ">
                            <div class="form-group">
                                <label>If ‘Yes’ how many caesarean sections? </label>
                                <input minlength="1" maxlength="100" type="text" id="caesarean_sections_count" name="caesarean_sections_count" class="form-control" placeholder="If ‘Yes’ how many caesarean sections?" value="<?php echo empty($csection['caesarean_sections_count'])?'':$csection['caesarean_sections_count']; ?>"  >
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label><br>Was the mother offered a trial of vaginal delivery during this pregnancy? <span class="required"> * </span></label>
                                <select id="trial_delivery" name="trial_delivery" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['trial_delivery'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['trial_delivery']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Does this mother require ‘special’ care post-caesarean section in addition to routine’ post-op care? <span class="required"> * </span></label>
                                <select id="special_care" name="special_care" class="form-control selectpicker" data-live-search="true" data-width="100%" onchange="special_care(this)" >
                                    <?php foreach ($options['special_care'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['special_care']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12 special_care " style="display:<?php if(isset($csection) && $csection['special_care']=='1'){ echo 'block'; } else { echo 'none'; } ?> ">
                            <div class="form-group">
                                <label>If ‘Yes’ where will this mother go to receive the additional post-op care?</label>
                                <select id="special_care_received" name="special_care_received" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['special_care_received'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['special_care_received']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>Fetal heart monitoring – Manual/ Electronic <span class="required"> * </span></label>
                                <select id="fetal_heart_monitoring" name="fetal_heart_monitoring" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['fetal_heart_monitoring'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['fetal_heart_monitoring']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>Meconium stained liquor present <span class="required"> * </span></label>
                                <select id="meconium_stained_liquor" name="meconium_stained_liquor" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['meconium_stained_liquor'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['meconium_stained_liquor']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>Other methods of delivery attempted <span class="required"> * </span></label>
                                <select id="other_method" name="other_method" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['other_method'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['other_method']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>Delivery outcome <span class="required"> * </span></label>
                                
                                <select id="delivery_outcome" name="delivery_outcome" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['delivery_outcome'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['delivery_outcome']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>Sex of the baby <span class="required"> * </span></label> 
                                <select id="baby_sex" name="baby_sex" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['baby_sex'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['baby_sex']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>Birth weight <span class="required"> * </span></label> 
                                <input minlength="1" maxlength="100" type="text" id="birth_weight" name="birth_weight" class="form-control nums" placeholder="Birth weight in gms" value="<?php echo empty($csection['birth_weight'])?'':$csection['birth_weight']; ?>"  >
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>Apgar score <span class="required"> * </span></label> 
                                <select id="apgar_score" name="apgar_score" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['apgar_score'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['apgar_score']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>Transferred to SNCU/ NICU <span class="required"> * </span></label> 
                                <select id="transfered_to" name="transfered_to" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['transfered_to'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['transfered_to']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>Maternal Outcome <span class="required"> * </span></label> 
                                <select id="maternal_outcome" name="maternal_outcome" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['maternal_outcome'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['maternal_outcome']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>If maternal death </label> 
                                <select id="maternal_death" name="maternal_death" class="form-control selectpicker" data-live-search="true" data-width="100%">
                                    <?php foreach ($options['maternal_death'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['maternal_death']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>Newborn Outcome <span class="required"> * </span></label> 
                                <select id="newborn_outcome" name="newborn_outcome" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['newborn_outcome'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['newborn_outcome']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>If neonatal death</label> 
                                <select id="neonatal_death" name="neonatal_death" class="form-control selectpicker" data-live-search="true" data-width="100%" >
                                    <?php foreach ($options['neonatal_death'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['neonatal_death']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="form-group">
                                <label>Opinion of the person conducting the audit about the necessity for this CS <span class="required"> * </span></label> 
                                <select id="person_opinion" name="person_opinion" class="form-control selectpicker" data-live-search="true" data-width="100%">
                                    <?php foreach ($options['person_opinion'] as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php if(isset($csection) && $key==$csection['person_opinion']){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                         


                    </div>

 

                </div>
  

            </div>
        </div>

        <input minlength="1" maxlength="100" type="hidden" id="facilityUser" name="facilityUser" class="form-control" placeholder="facilityUser " value="<?php echo encryptor(empty($search_options['Facility_show']['UserID'])?'':$search_options['Facility_show']['UserID']); ?>">
        <input minlength="1" maxlength="100" type="hidden" id="csectionID" name="csectionID" class="form-control" placeholder="id " value="<?php echo empty($id)?'':$id; ?>">

        <!-- Step End -->

    </div>
</div>
<!-- </form> -->

</div>
</div>

</div>
</div>
</div>
</div>
<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>