<style>
.col-md-6.bootstrap-select button, input{margin-bottom: 7px !important;}
.bold{font-weight: bold;}
.butn-hide .sw-toolbar-bottom {
  display: none;
}

</style>


<div class="page-title">
	<div class="title_left full-width">
		<h3>C-section Audit</h3>
	</div>
</div>
<div class="clearfix"></div>


<div class="main-content main-content-form-gr-h ApplyFor_center newap-cneter carti-c">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="x_panel">
					<div class="x_title">
						<h2>C-section Audit</h2>
						<ul class="nav navbar-right panel_toolbox">
							<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
						</ul>
						<div class="clearfix"></div>
					</div>
					<div class="x_content">
						<div id="smartwizard" class="butn-hide">
							<ul>
								<li><a href="#step-0"><span><em> A </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>General<br /></a></li>
								<li><a href="#step-1"><span><em> B </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>Audit Form<br /></a></li>
							</ul>
							<div>
								<!-- Step Start -->														
								<div id="step-0">


									<div class="list-report-monthly">

										<h5 class="tab-title">Section 1: General Information </h5>
										<div class="col-md-12 ">
											<div class="row">
												<div class="col-md-6 col-sm-6 col-xs-12">
													<div class="form-group">
														<span class="f-anme1">Facility Name: </span>
														<?php echo empty($search_options['Facility_show']['FacilityName'])?'':$search_options['Facility_show']['FacilityName']; ?>
													</div>
												</div>

												<div class="col-md-6 col-sm-6 col-xs-12">
													<div class="form-group">
														<span class="f-anme1">Station: </span> 
														<?php echo empty($csection['station'])?'':$csection['station']; ?>
													</div>
												</div>

											</div>


											<div class="row">
												<div class="col-md-6 col-sm-6 col-xs-12">
													<div class="form-group">
														<span class="f-anme1">Type of Facility: </span>
														<?php echo empty($options['facility_type'][$csection['facility_type']])?'':$options['facility_type'][$csection['facility_type']]; ?>
													</div>
												</div>

												<div class="col-md-6 col-sm-6 col-xs-12">
													<div class="form-group">
														<span class="f-anme1">Designation: </span> 
														<?php echo empty($csection['designation'])?'':$csection['designation']; ?>
													</div>
												</div>

											</div>


											<div class="row">
												<div class="col-md-6 col-sm-6 col-xs-12">
													<div class="form-group">
														<span class="f-anme1">Date Of Submission: </span>
														<?php echo empty($csection['dos'])?'':$csection['dos']; ?>
													</div>
												</div>
 

											</div>







										</div>
									</div>

									<!-- old code below ------->



									<div class="clear"></div>
								</div>
								<div id="step-1" style="">
									<div class="csstion-form">

										<div class="list-report-monthly">

										<h5 class="tab-title">Section 2: Audit Details </h5>
										 
									</div>



										<!------ old code below  ----------------->
										<!-- repeat ended -->
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold f-anme1">Name of the Mother, Age(Yrs)</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['mother_age'])?'':$csection['mother_age']; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Hospital No.</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['hospital_num'])?'':$csection['hospital_num']; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">G/P/L/A</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['gpla'])?'':$csection['gpla']; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Date of Admission</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['doa'])?'':$csection['doa']; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Date of delivery by CS</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['docs'])?'':$csection['docs']; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Date of CS audit</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['docs_audit'])?'':$csection['docs_audit']; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Maternal height (in cms) and weight (in kgs)</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['height_weight'])?'':$csection['height_weight']; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Booking status</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($options['book_status'][$csection['book_status']])?'':$options['book_status'][$csection['book_status']]; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Estimated gestation, in completed weeks </h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['gestation'])?'':$csection['gestation']; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Based on: </h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($options['based'][$csection['based']])?'':$options['based'][$csection['based']]; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Number of previous stillbirths >24 weeks, if any</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['prev_stillbirths'])?'':$csection['prev_stillbirths']; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Was the mother transferred to this hospital with baby in utero?</h5>
												</div>
												<div class="col-md-3">
													<div class="form-group">
														<?php echo empty($options['baby_in_utero'][$csection['baby_in_utero']])?'':$options['baby_in_utero'][$csection['baby_in_utero']]; ?>
													</div>
												</div>
												<div class="col-md-3" style="display:<?php if(isset($csection) && $csection['baby_in_utero']=='1'){ echo 'block'; } else { echo 'none'; } ?> " >
													<div class="form-group">
														<?php echo empty($csection['transferred_facility'])?'':$csection['transferred_facility']; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6" style="display:<?php if(isset($csection) && $csection['baby_in_utero']=='1'){ echo 'block'; } else { echo 'none'; } ?> " >
												<div class="col-md-6">
													<h5 class="form-tab-title bold">If yes: GA</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($options['ga'][$csection['ga']])?'':$options['ga'][$csection['ga']]; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">If preterm was AN conticosteroids given prior to transfer</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($options['conticosteroids'][$csection['conticosteroids']])?'':$options['conticosteroids'][$csection['conticosteroids']]; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Who was the most senior obstetrician involved in the decision to perform the caesarean section?</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($options['senior_obstetrician'][$csection['senior_obstetrician']])?'':$options['senior_obstetrician'][$csection['senior_obstetrician']]; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Which of the following best describes the indication for CS?</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($options['indication'][$csection['indication']])?'':$options['indication'][$csection['indication']]; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Was labour onset spontaneous?</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['onset_spontaneous'])?'':$csection['onset_spontaneous']; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Was pre-labour prostaglandin used?</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['pre_labour_prostaglandin'])?'':$csection['pre_labour_prostaglandin']; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Was oxytocin used for induction/acceleration before delivery?</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['oxytocin_used'])?'':$csection['oxytocin_used']; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Was partograph used prior to decision for CS?</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['partograph_used'])?'':$csection['partograph_used']; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Were the membranes ruptured (ROM) prior to the caesarean section?</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($options['ROM'][$csection['ROM']])?'':$options['ROM'][$csection['ROM']]; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Duration of first stage of labour</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['first_labour_duration'])?'':$csection['first_labour_duration']; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Duration of second stage of labour</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['second_labour_duration'])?'':$csection['second_labour_duration']; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">What cervical dilatation was reached prior to the caesarean section?</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['cervical_dilatation'])?'':$csection['cervical_dilatation']; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">If multiple pregnancy, were both babies delivered by CS or 1st baby delivered vaginally and 2nd baby by CS?</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['multiple_pregnancy'])?'':$csection['multiple_pregnancy']; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Were prophylactic antibiotics given?</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['prophylactic_antibiotics'])?'':$csection['prophylactic_antibiotics']; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">What was the estimated blood loss?</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['blood_loss'])?'':$csection['blood_loss']; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-12">
												<h5 class="tab-title">In case of previous Caesarean Delivery</h5>		
											</div>
										</div>

										<div class="row">
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Number of pregnancies, prior to this pregnancy, of >20 weeks</h5>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<?php echo empty($csection['pregnancies_number_greater'])?'':$csection['pregnancies_number_greater']; ?>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="col-md-6">
													<h5 class="form-tab-title bold">Number of pregnancies, prior to this pregnancy, of <20 weeks</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($csection['pregnancies_number_less'])?'':$csection['pregnancies_number_less']; ?>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Mode of termination</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['termination_mode'][$csection['termination_mode']])?'':$options['termination_mode'][$csection['termination_mode']]; ?>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Has the mother had a previous caesarean section?</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['previous_caesarean_section'][$csection['previous_caesarean_section']])?'':$options['previous_caesarean_section'][$csection['previous_caesarean_section']]; ?>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6" style="display:<?php if(isset($csection) && $csection['previous_caesarean_section']=='1'){ echo 'block'; } else { echo 'none'; } ?> " >
													<div class="col-md-6">
														<h5 class="form-tab-title bold">If ‘Yes’ how many caesarean sections?</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($csection['caesarean_sections_count'])?'':$csection['caesarean_sections_count']; ?>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Was the mother offered a trial of vaginal delivery during this pregnancy?</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['trial_delivery'][$csection['trial_delivery']])?'':$options['trial_delivery'][$csection['trial_delivery']]; ?>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Does this mother require ‘special’ care post-caesarean section in addition to routine’ post-op care?</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($csection['special_care'])?'':$csection['special_care']; ?>
														</div>
													</div>
												</div>
												<div class="col-md-6" style="display:<?php if(isset($csection) && $csection['special_care']=='1'){ echo 'block'; } else { echo 'none'; } ?> " >
													<div class="col-md-6">
														<h5 class="form-tab-title bold">If ‘Yes’ where will this mother go to receive the additional post-op care?</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['special_care_received'][$csection['special_care_received']])?'':$options['special_care_received'][$csection['special_care_received']]; ?>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Fetal heart monitoring – Manual/ Electronic</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['fetal_heart_monitoring'][$csection['fetal_heart_monitoring']])?'':$options['fetal_heart_monitoring'][$csection['fetal_heart_monitoring']]; ?>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Meconium stained liquor present</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['meconium_stained_liquor'][$csection['meconium_stained_liquor']])?'':$options['meconium_stained_liquor'][$csection['meconium_stained_liquor']]; ?>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Other methods of delivery attempted</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['other_method'][$csection['other_method']])?'':$options['other_method'][$csection['other_method']]; ?>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Delivery outcome</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['delivery_outcome'][$csection['delivery_outcome']])?'':$options['delivery_outcome'][$csection['delivery_outcome']]; ?>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Sex of the baby</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['baby_sex'][$csection['baby_sex']])?'':$options['baby_sex'][$csection['baby_sex']]; ?>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Birth weight</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($csection['birth_weight'])?'':$csection['birth_weight']; ?>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Apgar score</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['apgar_score'][$csection['apgar_score']])?'':$options['apgar_score'][$csection['apgar_score']]; ?>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Transferred to SNCU/ NICU</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['transfered_to'][$csection['transfered_to']])?'':$options['transfered_to'][$csection['transfered_to']]; ?>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Maternal Outcome</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['maternal_outcome'][$csection['maternal_outcome']])?'':$options['maternal_outcome'][$csection['maternal_outcome']]; ?>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">If maternal death</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['maternal_death'][$csection['maternal_death']])?'':$options['maternal_death'][$csection['maternal_death']]; ?>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Newborn Outcome</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['newborn_outcome'][$csection['newborn_outcome']])?'':$options['newborn_outcome'][$csection['newborn_outcome']]; ?>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">If neonatal death</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['neonatal_death'][$csection['neonatal_death']])?'':$options['neonatal_death'][$csection['neonatal_death']]; ?>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6">
													<div class="col-md-6">
														<h5 class="form-tab-title bold">Opinion of the person conducting the audit about the necessity for this CS</h5>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<?php echo empty($options['person_opinion'][$csection['person_opinion']])?'':$options['person_opinion'][$csection['person_opinion']]; ?>
														</div>
													</div>
												</div>

											</div>


											<!-- repeat ended -->



										</div>
									</div>

									<input minlength="1" maxlength="100" type="hidden" id="facilityUser" name="facilityUser" class="form-control" placeholder="facilityUser " value="<?php echo encryptor(empty($search_options['Facility_show']['UserID'])?'':$search_options['Facility_show']['UserID']); ?>"  >

									<!-- Step End -->

								</div>
							</div>
							<!-- </form> -->


						</div>
					</div>



				</div>
			</div>
		</div>
	</div>
	<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>
 