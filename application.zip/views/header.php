<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
  <title>Laqshya</title>
  <meta charset="utf-8">
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap-select.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap-datepicker.min.css">

  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700,900" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400i,600,600i,700,700i,900" rel="stylesheet">


  <!--- <link href="<?php echo base_url();?>assets/vendors/nprogress/nprogress.css" rel="stylesheet"> -->
  <!-- iCheck -->
  <link href="<?php echo base_url();?>assets/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
  
  <!-- bootstrap-progressbar -->
  <link href="<?php echo base_url();?>assets/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
  <!-- JQVMap -->
  <link href="<?php echo base_url();?>assets/vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
  <!-- bootstrap-daterangepicker -->
  <!--<link href="<?php echo base_url();?>assets/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">-->


  <!-- Datatables -->
  <link href="<?php echo base_url();?>assets/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">


  <!-- Custom Theme Style -->
  <link href="<?php echo base_url();?>assets/css/custom.min.css" rel="stylesheet">
  
  
  
  <!-- <script src="<?php //echo base_url();?>assets/js/jquery.min.js"></script>-->
  <script src="<?php echo base_url();?>assets/js/jquery1.11.3.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/jquery.cookie.js"></script>
  <script src="<?php echo base_url();?>assets/js/monthpicker.min.js"></script>
  <!-- remove this if you use Modernizr -->
  
  <script>(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>

  <script type="text/javascript">
    var pageMainUrl="<?php echo base_url();?>";
  </script>
  
  

  <!-- <style>.loader{overflow: scroll;background: #d0d0d0;position: fixed;z-index: 99; width: 100%;height: 100%; opacity: 0.3;}</style>-->

 <noscript>
   <h1 class="text-center ">This page needs JavaScript activated to work. </h1>
   <style>div { display:none; }</style>
 </noscript>

</head>
<!--<body class="nav-md" id="bodyLoad" >-->
<body class="nav-md grey" id="bg-color" >

  <div id="loader_overlay" style="display:none ">
    
    <div style="    position: absolute;z-index: 999;left: 50%;top: 50%;transform: translate(-50%, -50%)">
      <img src="<?php echo base_url('assets/images/load.gif'); ?>" alt="load" >
    </div>
  </div>
  <div class="container body">

    <div class="main_container">
<header>
        <div class="header-bottom">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-4 col-sm-4 col-xs-12 text-left main-logo">
                <a href="<?php echo base_url();?>">
                  <h1>
                    <span class="emonitoring white_logo"><img src="<?php echo base_url();?>/assets/images/laqshya-logo.png"></span>
                    <span class="emonitoring default_logo"><img src="<?php echo base_url();?>/assets/images/laqshya-logo1.png"></span>
                  </h1>
                </a>
              </div>


              <div class="col-md-4 col-sm-4 col-xs-6 indian-emblem text-center">
                <a href="https://mohfw.gov.in/" target="_blank" >
                  <img class="white_logo" style="padding-top: 5px;" src="<?php echo base_url();?>/assets/images/indian-emblem.png" alt="Indian Emblem">
                  <img class="default_logo" style="padding-top: 5px;" src="<?php echo base_url();?>/assets/images/indian-emblem1.png" alt="Indian Emblem">
                </a>
              </div>
              
              <div class="col-md-4 col-sm-4 col-xs-6 nhp-logo">
                 <a href="http://nhm.gov.in/" target="_blank">
                  
                  <img class="default_logo" style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhm-white.png" alt="NHM" class="NHM-logo">
                  <img class="white_logo" style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhm.png" alt="NHM" class="NHM-logo">
                </a>
                <a href="https://www.nhp.gov.in/" target="_blank"> 
                  <img class="default_logo"  style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhp-white.png" alt="NHP" class="nhp-logo">
                  <img class="white_logo"  style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhp.png" alt="NHP" class="nhp-logo">
                </a>
               
              </div>
            </div>
          </div>
        </div>
      </header>

      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">
          <div class="clearfix"></div>

          <!-- menu profile quick info -->
          <div class="profile clearfix">
            <div class="profile_pic">
              <?php 
              if(!empty($this->session->userdata['profile_pic']) && is_file($this->session->userdata['profile_pic'])){
                $pathProfile=$this->session->userdata['profile_pic'];
              } else {
                $pathProfile='assets/images/user.png';
              }
              ?>
              <img src="<?php echo base_url().$pathProfile;?>" alt="..." class="img-circle profile_img">
            </div>
            <div class="profile_info">
              <span>Welcome</span>
              <h2><?php echo $this->session->userdata['FirstName'].' '.$this->session->userdata['LastName'];?></h2>
            </div>
          </div>
          <!-- /menu profile quick info -->

          <br />

          <!-- sidebar menu -->
          <?php
          $parent=$this->uri->segment('1');
          $menuUrl=$this->uri->segment('1').'/'.$this->uri->segment('2');
          $menuUrl=strtolower($menuUrl);
          $parent=strtolower($parent);
          ?>
          <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
              <h3>General</h3>
              <ul class="nav side-menu">
                <li class="">
                  <a href="<?php echo base_url(); ?>user/index"><img src="<?php echo base_url(); ?>assets/images/dashboard-icon.png" alt="Dashboard">Dashboard</a>
                </li>
                <?php 
                $menu=$this->session->userdata('accessData'); 
                if(count($menu['menu'])>0){
                  foreach ($menu['menu'] as $key => $value) {
                    ksort($value['url']);
                  ?>
                  <li class="<?php if($parent==$value['controller']){ echo 'active'; } ?>" >
                    <?php 
                    if(count($value['url'])==0){  
                    reset($value['url']);
                    $first_key = key($value['url']);
                    ?>
                    <a href="<?php echo base_url().$value['url'][$first_key]['url'];?>"><img src="<?php echo base_url().$value['icon'];?>" alt="<?php echo $value['url'][$first_key]['formName']; ?>" /><?php echo $value['url'][$first_key]['formName']; ?></a>
                    <?php } else { ?>
                    <a><img src="<?php echo base_url().$value['icon'];?>" alt="<?php echo $value['moduleName'] ?>" /></i><?php echo $value['moduleName']; ?><span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <?php foreach ($value['url'] as $keyUrl => $valueUrl) { ?>
                      <li class="<?php if($menuUrl==$valueUrl['url']){ echo 'current-page'; } ?>" >
                        <a href="<?php echo base_url().$valueUrl['url'];?>"><?php echo $valueUrl['formName']; ?></a>
                      </li>
                      <?php } ?>
                    </ul>
                    <?php } ?>
                  </li>
                  <?php  
                  }
                }
                ?>


                
              </ul>
            </div>
          </div>

        </div>
      </div>

      <!-- top navigation -->
      <?php if(strtolower($this->uri->segment(1).'/'.$this->uri->segment(2))!='user/login'){ ?>
      <div class="top_nav">
        <div class="nav_menu">
          <nav>
            <div class="nav toggle my_nav">
              <a id="menu_toggle"><i class="fa fa-bars"></i></a>
            </div>

            <!-- <div class="tp-md-head">
              <h3>DASHBOARD</h3>
            </div> -->
            
            <ul class="nav navbar-nav navbar-right my_nav">

              

              <li class="">
                <a title="Logout" href="<?php echo base_url();?>ApiUser/logout" class="user-profile dropdown-toggle" >
                  <span style="font-size: 20px; color: #5A738E;" class="fa fa-sign-out" aria-hidden="true"></span>
                </a>
              </li>

              <li>
                <a title="Change Password" href="<?php echo base_url();?>User/changepassword">
                  <i  class="fa fa-lock"></i>  Change Password
                </a>
              </li>

              <li>
                <a title="Profile" href="<?php echo base_url();?>User/profile">
                  <i class="fa fa-user"></i> Profile
                </a>
              </li>
              <li>
                <a title="Notification" href="<?php echo base_url();?>User/notification">
                  <i class="fa fa-bell"></i>
                  <?php $notificationCount=$this->CommonModel->notificationCount();
                  if(!empty($notificationCount)){ ?>
                  <span class="numbel"><?php echo $notificationCount; ?></span>
                <?php } ?>
                </a>
              </li>

               <li class="">
                <a title="goBack"  onclick="goBack()" class="user-profile dropdown-toggle back-main" >
                  <span style="font-size: 20px; color: #5A738E;" class="fa fa-angle-double-left" aria-hidden="true"></span> Back
                </a>
              </li>
              <style type="text/css">
<?php
if(empty($this->session->userdata('showNot')) && $this->session->userdata('RoleName')!='Facility' ){
$this->session->set_userdata('showNot', '1');
?>
.higlighted-arpt:before {content: "";}
.higlighted-arpt a:before {content: "\f176";}

<?php } ?>
              </style>

              <li class="higlighted-arpt"><a href="<?php echo base_url();?>assets/uploads/Process_Note_on_LaQshya_Certification.docx"><i class="fa fa-info-circle" aria-hidden="true"></i> Certification Process Note </a>
              </li>

              <li class="higlighted-arpt">
                <a href="<?php echo base_url();?>assets/uploads/LaQshya_State_Certification.docx"><i class="fa fa-question-circle" aria-hidden="true"></i> State Certification  Guidelines </a>              </li>

              
            </ul>
          </nav>
        </div>
      </div>
      <?php } ?>
      <!-- /top navigation -->

      <!-- page content -->
      <div class="right_col" role="main">
        <div class="alert" id="msgDiv" style="display: none;">
          <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
          <strong id="LoginMsg"></strong>
        </div>          



