<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
  <title>Laqshya</title>
  <meta charset="utf-8">
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap-select.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap-datepicker.min.css">

  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700,900" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400i,600,600i,700,700i,900" rel="stylesheet">


  <!--- <link href="<?php echo base_url();?>assets/vendors/nprogress/nprogress.css" rel="stylesheet"> -->
  <!-- iCheck -->
  <link href="<?php echo base_url();?>assets/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
  
  <!-- bootstrap-progressbar -->
  <link href="<?php echo base_url();?>assets/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
  <!-- JQVMap -->
  <link href="<?php echo base_url();?>assets/vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
  <!-- bootstrap-daterangepicker -->
  <!--<link href="<?php echo base_url();?>assets/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">-->


  <!-- Datatables -->
  <link href="<?php echo base_url();?>assets/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">


  <!-- Custom Theme Style -->
  <link href="<?php echo base_url();?>assets/css/custom.min.css" rel="stylesheet">
  
  
  
  <!-- <script src="<?php //echo base_url();?>assets/js/jquery.min.js"></script>-->
  <script src="<?php echo base_url();?>assets/js/jquery1.11.3.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/jquery.cookie.js"></script>
  <script src="<?php echo base_url();?>assets/js/monthpicker.min.js"></script>
  <!-- remove this if you use Modernizr -->
  
  <script>(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>

  <script type="text/javascript">
    var pageMainUrl="<?php echo base_url();?>";
  </script>
  
  

  <!-- <style>.loader{overflow: scroll;background: #d0d0d0;position: fixed;z-index: 99; width: 100%;height: 100%; opacity: 0.3;}</style>-->

 <noscript>
   <h1 class="text-center ">This page needs JavaScript activated to work. </h1>
   <style>div { display:none; }</style>
 </noscript>

</head>
<!--<body class="nav-md" id="bodyLoad" >-->
<body class="nav-md grey" id="bg-color" >

  <div id="loader_overlay" style="display:none ">
    
    <div style="    position: absolute;z-index: 999;left: 50%;top: 50%;transform: translate(-50%, -50%)">
      <img src="<?php echo base_url('assets/images/load.gif'); ?>" alt="load" >
    </div>
  </div>
  <div class="container body">

    <div class="main_container">


      <!-- page content -->
      <div class="" role="main">



