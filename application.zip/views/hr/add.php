<style>
.col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}    
</style>

<div class="page-title">
  <div class="title_left">
    <h3>Hr Form</h3>
  </div>

  
</div>



<div class="main-content main-content-form-gr-h">
  <div class="container">

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2><?php echo $this->session->userdata('RoleName'); ?>  Level Credentials</h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <form enctype="multipart/form-data" name="hrForm" id="hrForm" role="form" action="<?php echo base_url(). "ApiHr/add"; ?>" method="post">             
              <?php if($this->session->userdata('RoleName')=='Facility'){ ?>
               
           
              <div class="col-md-4">
                <div class="form-group">
                  <label>Name </label>
                  <input maxlength="99" class="form-control" placeholder="Name" id="FacilityName" name="FacilityName" type="text" value="<?php if(isset($facility)){ echo $facility['FacilityName']; };  ?>" readonly="readonly" >
                </div>
              </div>
              <div>
               <input type="hidden" name="id" id="id" value="<?php echo empty($id['id'])?'':encryptor($id['id']); ?>" >
               </div>

              <div class="col-md-4">
                <div class="form-group">
                  <label> Type of Facility <span class="required"> * </span> </label>
                  <select id="FacilityTypeDetailID" name="FacilityTypeDetailID" class="selectpicker"  data-width="100%" readonly="readonly">
                   
                    <?php foreach ($facility_types as $key => $value) { 
                      if($facility['FacilityTypeDetailID'] ==$value['TypeDetailID']) {?>
                    <option value="<?php echo $value['TypeDetailID']; ?>" <?php if(isset($facility['FacilityTypeDetailID']) && $facility['FacilityTypeDetailID']==$value['TypeDetailID']){ echo ' selected="selected" '; } ?> ><?php echo $value['TypeDetailCode']; ?></option>
                    <?php  } } ?>
                </select>                  
                </div>
              </div>
           
              
              <div class="col-md-4" >
                <div class="form-group">
                  <label>Head of Facility (Name)<span class="required"> * </span> </label>
                  <input maxlength="50" class="form-control" placeholder="Head of Facility (Name)" id="FacilityHead" name="FacilityHead" type="text" value="<?php if(isset($main)){ echo $main['FacilityHead']; };  ?>">
                </div>
              </div>
              <div class="col-md-6">
                    <div class="form-group">
                      <label>Name of Gynecologist <span class="required"> * </span></label> 
                      <input maxlength="30" class="form-control" placeholder="Name of Gynecologist" id="Gynecologist" name="Gynecologist" type="text" value="<?php if(isset($main['Gynecologist'])){ echo $main['Gynecologist']; } ?>"   >
                    </div>
                  </div>
             
              <div class="col-md-6">
                <div class="form-group">
                  <label>Name of Pediatrician <span class="required"> * </span> </label>
                  <input maxlength="155" class="form-control" placeholder="Name of Pediatrician" id="Pediatrician" name="Pediatrician" type="text" value="<?php if(isset($main)){ echo $main['Pediatrician']; };  ?>"   >
                </div>
              </div>
           
           
              <div class="col-md-6">
                <div class="form-group">
                  <label>Name of Anesthetist <span class="required"> * </span> </label>
                  <input maxlength="16" class="form-control " placeholder="Anesthetist" id="Anesthetist" name="Anesthetist" type="text" value="<?php if(isset($main)){ echo $main['Anesthetist']; };  ?>"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Name of Medical Officer designated for labor room <span class="required"> * </span></label>
                  <input class="form-control " placeholder="Medical Officer" id="MedicalOfficer" name="MedicalOfficer" type="text" value="<?php if(isset($main)){ echo $main['MedicalOfficer']; };  ?>"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Name of Staff Nurse (I/C labor room) <span class="required"> * </span> </label>
                  <input maxlength="50" class="form-control" placeholder=" Name of Staff Nurse" id="lr_staff_name" name="lr_staff_name" type="text" value="<?php if(isset($main)){ echo $main['lr_staff_name']; };  ?>"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Name of Staff nurse (I/C Operation Theater)  <span class="required"> * </span> </label>
                  <input maxlength="50" class="form-control " placeholder="Name of Staff nurse" id="ot_staff_name" name="ot_staff_name" type="text" value="<?php if(isset($main)){ echo $main['ot_staff_name']; };  ?>"   >
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                  <label> Number of Staff Nurses SBA trained<span class="required"> * </span> </label>
                  <input maxlength="50" class="form-control nums" placeholder="" id="total_sba_trained" name="total_sba_trained" type="text" value="<?php if(isset($main)){ echo $main['total_sba_trained']; };  ?>"   >
                </div>
              </div>
                


              <div class="col-md-6">
                <div class="form-group">
                  <label> Number of Staff Nurses trained in Skill Lab<span class="required"> * </span></label>
                  <input maxlength="50" class="form-control nums" placeholder="" id="total_lab_trained" name="total_lab_trained" type="text" value="<?php if(isset($main)){ echo $main['total_lab_trained']; };  ?>"   >
                </div>
              </div>
            
            <div class="col-md-6">
                <div class="form-group">
                  <label> Average Deliveries per Month<span class="required"> * </span></label>
                  <input maxlength="50" class="form-control nums" placeholder="" id="avg_delivery_month" name="avg_delivery_month" type="text" value="<?php if(isset($main)){ echo $main['avg_delivery_month']; };  ?>"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Average C Section per Month <span class="required"> * </span></label>
                  <input maxlength="50" class="form-control nums" placeholder="" id="avg_section_month" name="avg_section_month" type="text" value="<?php if(isset($main)){ echo $main['avg_section_month']; };  ?>"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label>Number of labor beds / table in labor room  <span class="required"> * </span></label>
                  <input maxlength="50" class="form-control nums" placeholder="Number of labor beds" id="total_laborbeds" name=" total_laborbeds" type="text" value="<?php if(isset($main)){ echo $main['total_laborbeds']; };  ?>"   >
                </div>
              </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Medical Officer (BEmoc/CEmoc trained) <span class="required">* </span>&nbsp;&nbsp;&nbsp;</label>
                      <label class="radio inline">
                          <input id="IsTrained" name="IsTrained" type="radio"  value="1" <?php if(isset($main['IsTrained']) && $main['IsTrained']=='1'){ echo ' checked="checked"'; }  ?> >
                          <span>Yes </span>
                      </label>

                      <label class="radio inline">
                          <input id="IsTrained" name="IsTrained" type="radio"  value="0" <?php if(isset($main['IsTrained']) && $main['IsTrained']=='0'){ echo ' checked="checked"'; }  ?> >
                          <span>No</span>
                      </label>
                  </div>
              </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Display of Respectful Maternity Care protocol <span class="required"> * </span>&nbsp;&nbsp;&nbsp;</label>
                      <label class="radio inline">
                          <input id="MaternityProtocol" name="MaternityProtocol" type="radio"  value="1" <?php if(isset($main['MaternityProtocol']) && $main['MaternityProtocol']=='1'){ echo ' checked="checked"'; }  ?> >
                          <span>Yes </span>
                      </label>

                      <label class="radio inline">
                          <input id="MaternityProtocol" name="MaternityProtocol" type="radio"  value="0" <?php if(isset($main['MaternityProtocol']) && $main['MaternityProtocol']=='0'){ echo ' checked="checked"'; }  ?> >
                          <span>No</span>
                      </label>
                  </div>
              </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Display of SBA Quality protocols <span class="required">* </span>&nbsp;&nbsp;&nbsp;</label>
                      <label class="radio inline">
                          <input id="QualityProtocol" name="QualityProtocol" type="radio"  value="1" <?php if(isset($main['QualityProtocol']) && $main['QualityProtocol']=='1'){ echo ' checked="checked"'; }  ?> >
                          <span>Yes </span>
                      </label>

                      <label class="radio inline">
                          <input id="QualityProtocol" name="QualityProtocol" type="radio"  value="0" <?php if(isset($main['QualityProtocol']) && $main['QualityProtocol']=='0'){ echo ' checked="checked"'; }  ?> >
                          <span>No</span>
                      </label>
                  </div>
              </div>
              <div class="col-md-6">
                  <div class="form-group">
                      <label>Skill Lab station set up <span class="required">*</span>&nbsp;&nbsp;&nbsp;</label>
                      <label class="radio inline">
                          <input id="IsSkillsLab" name="IsSkillsLab" type="radio"  value="1" <?php if(isset($main['IsSkillsLab']) && $main['IsSkillsLab']=='1'){ echo 'checked="checked"'; }  ?> >
                          <span>Yes </span>
                      </label>

                      <label class="radio inline">
                          <input id="IsSkillsLab" name="IsSkillsLab" type="radio"  value="0" <?php if(isset($main['IsSkillsLab']) && $main['IsSkillsLab']=='0'){ echo 'checked="checked"'; }  ?> >
                          <span>No</span>
                      </label>
                  </div>
              </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Availability of Instruments / Equipment in labor room as per LaQshya Guideline <span class="required">*</span>&nbsp;&nbsp;&nbsp;</label>
                      <label class="radio inline">
                          <input id="avbl_eq_in_lr" name="avbl_eq_in_lr" type="radio" value="1" <?php if(isset($main['avbl_eq_in_lr']) && $main['avbl_eq_in_lr']=='1'){ echo ' checked="checked"'; }  ?> >
                          <span>Yes </span>
                      </label>

                      <label class="radio inline">
                          <input id="avbl_eq_in_lr" name="avbl_eq_in_lr" type="radio"  value="0" <?php if(isset($main['avbl_eq_in_lr']) && $main['avbl_eq_in_lr']=='0'){ echo ' checked="checked"'; }  ?> >
                          <span>No</span>
                      </label>
                  </div>
              </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Availability of Instruments / Equipment in Operation Theater as per LaQshya Guideline <span class="required">*</span>&nbsp;&nbsp;&nbsp;</label>
                      <label class="radio inline">
                          <input id="avbl_eq_in_ot" name="avbl_eq_in_ot" type="radio" value="1" <?php if(isset($main['avbl_eq_in_ot']) && $main['avbl_eq_in_ot']=='1'){ echo ' checked="checked"'; }  ?> >
                          <span>Yes </span>
                      </label>

                      <label class="radio inline">
                          <input id="avbl_eq_in_ot" name="avbl_eq_in_ot" type="radio"  value="0" <?php if(isset($main['avbl_eq_in_ot']) && $main['avbl_eq_in_ot']=='0'){ echo ' checked="checked"'; }  ?> >
                          <span>No</span>
                      </label>
                  </div>
              </div>
         
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Availability of Drugs in labor room  as per LaQshya Guideline <span class="required">*</span>&nbsp;&nbsp;&nbsp;</label>
                      <label class="radio inline">
                          <input id=" avbl_drg_in_lr" name="avbl_drg_in_lr" type="radio" value="1" <?php if(isset($main['avbl_drg_in_lr']) && $main['avbl_drg_in_lr']=='1'){ echo ' checked="checked"'; }  ?> >
                          <span>Yes </span>
                      </label>

                      <label class="radio inline">
                          <input id="avbl_drg_in_lr" name="avbl_drg_in_lr" type="radio"  value="0" <?php if(isset($main['avbl_drg_in_lr']) && $main['avbl_drg_in_lr']=='0'){ echo ' checked="checked"'; }  ?> >
                          <span>No</span>
                      </label>
                  </div>
              </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Availability of Drugs in Operation Theater as per LaQshya Guideline<span class="required">*</span>&nbsp;&nbsp;&nbsp;</label>
                      <label class="radio inline">
                          <input id="avbl_drg_in_ot" name="avbl_drg_in_ot" type="radio"  value="1" <?php if(isset($main['avbl_drg_in_ot']) && $main['avbl_drg_in_ot']=='1'){ echo ' checked="checked"'; }  ?> >
                          <span>Yes </span>
                      </label>

                      <label class="radio inline">
                          <input id="avbl_drg_in_ot" name="avbl_drg_in_ot" type="radio" value="0" <?php if(isset($main['avbl_drg_in_ot']) && $main['avbl_drg_in_ot']=='0'){ echo 'checked="checked"'; }  ?> >
                          <span>No</span>
                      </label>
                  </div>
              </div>

              
              <?php } ?>


              
             

              <div class="col-md-12">
                <div class="form-group">
                  <div class='input-group pull-right'>
                    <input style="margin-top: 15px; margin-right: 20px;" type='submit' id="hrBtn" name="hrBtn" value="<?php echo ($main)? 'Update': 'Save' ?>" class="btn btn-info" />

                    <input type="button" style="margin-top: 15px; margin-right: 0px;" data-href="<?php echo base_url(); ?>hr/add" class="btn btn-danger" onclick="pageRedirect(this)" value="Cancel" >
                  </div>
                </div>
              </div>                    
            </form>
          </div>
        </div>

      </div>
    </div>



  </div>
</div>