<style>
    .erroShow { border:1px solid red};
    .erroHide { border:none};
</style>

<div class="page-title">
    <div class="title_left">
        <h3>Hr Form View</h3>
    </div>


</div>

<div class="clearfix"></div>

  

      
               
<?php if (!empty($main)) { ?>

<div class="main-content"> 
    <div class="container">   
  <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>HR Report</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content x_content_mine list-report-monthly report-monthly-first report-monthly-first1">

                         <div class="col-md-6">
                                <div class="form-group">
                                    <label> Name of Facility<span class=""> : </span> <span ><?php if(isset($facility)){ echo $facility['FacilityName']; };  ?></span></label>
                                    
                                </div>
                            </div>
                             <div class="col-md-6 ">
                                <div class="form-group">
                                    <label> Type of Facility <span class=""> : </span> <span ><?php if(isset($facility['FacilityTypeDetailID']) && $facility['FacilityTypeDetailID']){ echo $facility['TypeDetailCode'] ; } ?> </span></label>
                                    
                                </div>
                            </div>
                       
   
             <div class="col-md-6" >
                <div class="form-group">
                  <label>Head of Facility (Name) : <span ><?php if(isset($main)){ echo $main['FacilityHead']; };  ?> </span ></label> 
                </div>
              </div>
            
              
              <div class="col-md-6">
                    <div class="form-group">
                      <label>Name of Gynecologist <span class="required">  </span>: <span><?php if(isset($main['Gynecologist'])){ echo $main['Gynecologist']; } ?></span></label> 
                      
                    </div>
            </div>
             
              <div class="col-md-6">
                <div class="form-group">
                  <label>Name of Pediatrician <span class="required">  </span> :<span> <?php if(isset($main)){ echo $main['Pediatrician']; };  ?></span></label> 
                 
                </div>
              </div>
           
           
              <div class="col-md-6">
                <div class="form-group">
                  <label>Name of Anesthetist <span class="required"> </span>:<span><?php if(isset($main)){ echo $main['Anesthetist']; };  ?> </span></label>
                 </div>

              </div>
                 <div class="clearfix"></div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Name of Medical Officer designated for labor room :<span> <?php if(isset($main)){ echo $main['MedicalOfficer']; };  ?></span></label>
                
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Name of Staff Nurse (I/C labor room) : <span><?php if(isset($main)){ echo $main['lr_staff_name']; };  ?></span></label>
                 
                </div>
              </div>
                 <div class="clearfix"></div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Name of Staff nurse (I/C Operation Theater)  : <span> <?php if(isset($main)){ echo $main['ot_staff_name']; };  ?></span></label>
                
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                  <label> Number of Staff Nurses SBA trained : <span><?php if(isset($main)){ echo $main['total_sba_trained']; };  ?></span></label>
                
                </div>
              </div>
                
   <div class="clearfix"></div>

              <div class="col-md-6">
                <div class="form-group">
                  <label> Number of Staff Nurses trained in Skill Lab :<span> <?php if(isset($main)){ echo $main['total_lab_trained']; };  ?></span></label>
                
                </div>
              </div>
            
            <div class="col-md-6">
                <div class="form-group">
                  <label> Average Deliveries per Month : <span><?php if(isset($main)){ echo $main['avg_delivery_month']; };  ?></span></label>
                 
                </div>
              </div>
                 <div class="clearfix"></div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Average C Section per Month  :  <span><?php if(isset($main)){ echo $main['avg_section_month']; };  ?></span></label>
                 
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label>Number of labor beds / table in labor room :<span><?php if(isset($main)){ echo $main['total_laborbeds']; };  ?></span> </label>
              
                </div>
              </div>
                 <div class="clearfix"></div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Medical Officer (BEmoc/CEmoc trained) <span class="required"> </span>&nbsp;&nbsp;&nbsp;: <span><?php if(isset($main['IsTrained']) && $main['IsTrained']=='1'){ echo ' Yes'; } else{ echo 'No';} ?></span></label>
                     

                  </div>
              </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Display of Respectful Maternity Care protocol <span class="required"> </span>&nbsp;&nbsp;&nbsp; : <span><?php if(isset($main['MaternityProtocol']) && $main['MaternityProtocol']=='1'){ echo 'Yes'; } else { echo 'No'; } ?></span></label>
                    
                  </div>
              </div>
                 <div class="clearfix"></div>
                  <div class="clearfix"></div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Display of SBA Quality protocols <span class="required"> </span>&nbsp;&nbsp;&nbsp; : <span><?php if(isset($main['QualityProtocol']) && $main['QualityProtocol']=='1'){ echo 'Yes'; }else{ echo 'No'; }  ?></span></label>
                   
                  </div>
              </div>
              <div class="col-md-6">
                  <div class="form-group">
                      <label>Skill Lab station set up <span class="required"> </span>&nbsp;&nbsp;&nbsp; :<span> <?php if(isset($main['IsSkillsLab']) && $main['IsSkillsLab']=='1'){ echo 'Yes'; } else{ echo 'No';} ?> </span></label>
                 
                 
                  </div>
              </div>
                 <div class="clearfix"></div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Availability of Instruments / Equipment in labor room as per LaQshya Guideline <span class="required"> </span>&nbsp; : <span><?php if(isset($main['avbl_eq_in_lr']) && $main['avbl_eq_in_lr']=='1'){ echo 'Yes'; }else{ echo 'No'; }  ?></span></label>
                   
                  </div>
              </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Availability of Instruments / Equipment in Operation Theater as per LaQshya Guideline <span class="required"> </span>&nbsp;&nbsp;: <span><?php if(isset($main['avbl_eq_in_ot']) && $main['avbl_eq_in_ot']=='1'){ echo 'Yes'; } else{ echo "No";} ?></span></label>
                     
                  </div>
              </div>
                 <div class="clearfix"></div>
         
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Availability of Drugs in labor room  as per LaQshya Guideline <span class="required"> </span>&nbsp;&nbsp;&nbsp; : <span><?php if(isset($main['avbl_drg_in_lr']) && $main['avbl_drg_in_lr']=='1'){ echo 'Yes'; } else { echo 'No'; }  ?> </span></label>
                   

                  </div>
              </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <label>Availability of Drugs in Operation Theater as per LaQshya Guideline<span class="required"> </span>&nbsp;&nbsp;&nbsp; : <span><?php if(isset($main['avbl_drg_in_ot']) && $main['avbl_drg_in_ot']=='1'){ echo 'Yes'; }else{ echo 'No';}  ?></span></label>
                   

                  </div>
              </div>
                 <div class="clearfix"></div>

                    </div>
                </div>
            </div>
        </div>
          
</div>
</div>
                    
                        
   
 <?php }else{ ?>
  <center><h3>No  Data Available </h3></center>
<?php } ?>


      


<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>

<style>

span{
  font-weight: 100;
}
    .form-group{margin-bottom: 5px; padding: 6px 0px;}
    .list-report-monthly .col-md-12{background: #f1f1f1;border-bottom: 1px solid #ccc;}
    .list-report-monthly .col-md-4{background: #e7f5ff;
                                    border-bottom: 1px solid #94d2ff;
                                    padding: 10px;
                                    border-right: 1px solid #94d2ff;
                                    color: #000;}
    .list-report-monthly .col-md-6{background: #e7f5ff;
                                    border-bottom: 1px solid #94d2ff;
                                    padding: 10px;
                                    border-right: 1px solid #94d2ff;
                                    color: #000;}

    .list-report-monthly .col-md-4 label {
    font-weight:bold !important;
}

    .report-monthly-second .col-md-4{min-height: 102px;}

    .report-monthly-third .col-md-4{min-height: 80px;}

    .list-report-monthly .col-md-4 label{font-size: 14px !important; line-height: 21px; font-weight: bold !important;}
    .list-report-monthly .col-md-6 label{font-size: 14px !important; line-height: 21px; font-weight: bold !important;}
    .list-report-monthly > h5.tab-title{margin-bottom: 0px;}
    .list-report-monthly > .col-md-12 > .row > h6{padding: 3px 10px;}
    #step-3 .x_content .form-group label{margin-bottom: 0px;}
    .list-report-monthly > .col-md-12 > .row > h6{background: none;}

    .form-main-labour h3:first-child{margin-left: 25px;}
</style>

<!--<script src="https://cdn.datatables.net/select/1.2.6/js/dataTables.select.min.js"/>
<script src="https://editor.datatables.net/extensions/Editor/js/dataTables.editor.min.js"/>-->
