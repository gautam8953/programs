<div class="page-title">
  <div class="title_left">
    <h3>Report</h3>
  </div>
</div>
<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">
	    <div class="row searchDiv">
	    	
	        <div class="col-md-12">
	        	<div class="well">
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_state" name="search_state" onchange="change_state()" class="form-control">
						<option value="">Select State</option>
					</select>                    
                </div>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_district" name="search_district" onchange="change_district()" class="form-control">
						<option value="">Select District</option>
					</select>
                </div>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_facility" name="search_facility" onchange="change_facility()" class="form-control">
						<option value="">Select Facility</option>
					</select>
                </div>
                <div class="col-md-3 col-xs-12 mar-top-20 bold1">
                	<input type="hidden" name="search_typeMain" id="search_typeMain" value="<?php if(!empty($types)){ echo trim(ucfirst($types)); } else { echo 'State'; } ?>">
                	<input type="hidden" name="search_typeFacility" id="search_typeFacility" value="<?php if(!empty($facility)){ echo trim(urldecode($facility)); } else { } ?>">
                	<select id="search_type" name="search_type" onchange="change_facility()" class="form-control"></select>
                </div>
                <div class="col-md-3 col-xs-12 mar-top-20">
                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" />
                    <input type="button" id="reset_btn" class="btn btn-primary btn-rouns1" value="Reset">
                </div>            	
	        </div>
	        </div>
	    </div>
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Checklist Report</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">			      
			      <table id="datatable" class="table table-striped table-bordered  table-check0list">
			        	<thead>
			            <tr>
			            	<!-- Changed from js -->
				            <th>SN.</th>
				            <th style="width: 20%" data-toggle="tooltip" title="Facility ">Facility</th>
						    <th data-toggle="tooltip" title="Department">Department</th>
						    <th data-toggle="tooltip" title="Peer Score/State Score ">Peer Score/State Score</th>
						    <th data-toggle="tooltip" title="Criterion I - Overall Score of the department (LR / OT shall be ≥70% ">Criterion I </th>
						    <th data-toggle="tooltip" title="Criterion II- Score of each Area of Concern of department (LR/OT) shall be 70% ">Criterion II </th>
						    <th colspan="3" data-toggle="tooltip" title="Criterion III- Individual scores of three core Standards (B3,E18 and E19) shall be ≥70% ">Criterion III </th>
						    <th data-toggle="tooltip" title="Criterion IV- Individual Score in each Applicable Quality Standard>60%">Criterion IV </th>
						    <th data-toggle="tooltip" title="Criterion V – Client Satisfaction of the department shall be more ≥80% ">Criterion V </th>
						    <th data-toggle="tooltip" title="Total Criterion ">Total Criterion</th>
			            </tr>
			            <tr>
				            <th></th>
				            <th></th>
				            <th></th>
				            <th></th>
				            <th></th>
				            <th></th>
				            <th>B3</th>
				            <th>E18</th>
				            <th>E19</th>
				            <th></th>
				            <th></th>
				            <th></th>
			            </tr>
			        	</thead>
			        	<tbody>
			        	</tbody>
			      </table>


			      <div class="lenget-class">
			      		<ul>
			      			<li><strong>Criterion I </strong>- Overall Score of the department (LR / OT shall be ≥<span id="criteria_1">70</span>%</li>
			      			<li><strong>Criterion II </strong> - Score of each Area of Concern of department (LR/OT) shall be <span id="criteria_2">70</span>%</li> 
			      			<li><strong>Criterion III </strong> - Individual scores of three core Standards (B3, E18 and E19) shall be ≥<span id="criteria_3">70</span>%</li>
			      			<li><strong>Criterion IV </strong>- Individual Score in each Applicable Quality Standard > <span id="criteria_4">60</span>%</li>
			      			<li><strong>Criterion V  </strong>– Client Satisfaction of the department shall be more ≥<span id="criteria_5">80</span>%</li>
			      		</ul>

			      </div>
			    </div>
			  </div>
			</div>
		</div>        
    </div>
</div>

<style>
	table tr th{background: #337ab7; color: #fff; border-color: #0d3b63 !important;}
</style>
 
 