<style>
    .col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}
    
</style>

<div class="page-title">
  <div class="title_left">
    <h3>Reports</h3>
  </div>
</div>

<div class="clearfix"></div>

<div class="main-content main-content-form-gr-osce">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>OSCE</h2>
                  
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <?php 
                if(empty($OsceID)){
                  $accessVar='access_add';
                } else {
                  $accessVar='access_edit';
                }
                if($this->CommonModel->checkPageActionWeb('reports/osce',$accessVar,$this->session->userdata('RoleName'))){ 
                ?>
                <form id="osceForm" name="osceForm" role="form" action="<?php echo base_url()."ApiFacility/osce"?>" method="post">
                
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Name of Participant<span class="required"> * </span> </label>
                        <input minlength="1" maxlength="100" type="text" id="participant" name="participant"  class="form-control" placeholder="Name of Participant" value="<?php echo isset($osceForm['participant'])?$osceForm['participant']:''; ?>" >
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Designation<span class="required"> * </span> </label>
                        <select name="designation" id="designation" class="selectpicker" data-width="100%">, , , 
                            <?php foreach ($this->config->item('osceDesig')  as $key => $value) { ?>
                            <option value="<?php echo $key; ?>" <?php if((isset($osceForm['designation']) && $osceForm['designation']==$key)){ echo ' selected="selected" '; } ?> ><?php echo $value; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <h4><strong>Clinical Training Status</strong> </h4>
                    
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 mar-bottom30">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                          <label>Dakshata<span class="required"> * </span> </label>
                        </div>
                      </div>
                      <div class="col-md-12 col-sm-12 col-xs-12 mar-top-10">
                        <div class="row">
                             <label class="radio inline" tabindex="2"> 
                              <input type="radio" id="dakshata_1" name="dakshata" value="1" onchange="changeTrained()" <?php if((isset($osceForm['dakshata']) && $osceForm['dakshata']=='Yes')){ echo ' checked="checked" '; } ?> >
                              <span>Yes</span> 
                            </label>
                             <label class="radio inline" tabindex="2"> 
                              <input type="radio" id="dakshata_0" name="dakshata" value="0" onchange="changeTrained()" <?php if((isset($osceForm['dakshata']) && $osceForm['dakshata']=='No')){ echo ' checked="checked" '; } ?> >
                              <span>No</span> 
                            </label>
                          </div>
                      </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 mar-bottom30">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                          <label>Skill Lab (Daksh)<span class="required"> * </span> </label>
                        </div>
                      </div>
                        <div class="col-md-12 col-sm-12 col-xs-12 mar-top-10">
                          <div class="row">
                             <label class="radio inline" tabindex="2"> 
                              <input type="radio" id="daksh_1" name="daksh" value="1" onchange="changeTrained()" <?php if((isset($osceForm['daksh']) && $osceForm['daksh']=='Yes')){ echo ' checked="checked" '; } ?> >
                              <span>Yes</span>                            </label>
                             <label class="radio inline" tabindex="2"> 
                              <input type="radio" id="daksh_0" name="daksh" value="0" onchange="changeTrained()" <?php if((isset($osceForm['daksh']) && $osceForm['daksh']=='No')){ echo ' checked="checked" '; } ?> >
                              <span>No</span> 
                            </label>
                          </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 mar-bottom30">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                          <label>Others<span class="required"> * </span> </label>
                        </div>
                      </div>
                        <div class="col-md-12 col-sm-12 col-xs-12 mar-top-10">
                          <div class="row">
                          <label class="radio inline" tabindex="2"> 
                              <input type="radio" id="others_1" name="others" value="1" <?php if((isset($osceForm['others']) && $osceForm['others']=='Yes')){ echo ' checked="checked" '; } ?> >
                              <span>Yes</span> 
                            </label>
                             <label class="radio inline" tabindex="2"> 
                              <input type="radio" id="others_0" name="others" value="0" <?php if((isset($osceForm['others']) && $osceForm['others']=='No')){ echo ' checked="checked" '; } ?> >
                              <span>No</span> 
                            </label>
                          </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-sm-6 col-xs-12 mar-bottom30">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                          <label>Staff Clinically Trained or Not (Auto calculated)<span class="required"> * </span> </label>
                        </div>
                      </div>
                        <div class="col-md-12 col-sm-12 col-xs-12 mar-top-10">
                        <div class="row">
                             <label class="radio inline" tabindex="2"> 
                              <input type="radio" id="trained_1" name="trained" value="1"  disabled="disabled" <?php if((isset($osceForm['trained']) && $osceForm['trained']=='Yes')){ echo ' checked="checked" '; } ?> >
                              <span>Yes</span> 
                            </label>
                             <label class="radio inline" tabindex="2"> 
                              <input type="radio" id="trained_0" name="trained" value="0"  disabled="disabled" <?php if((isset($osceForm['trained']) && $osceForm['trained']=='No')){ echo ' checked="checked" '; } ?> >
                              <span>No</span> 
                            </label>
                          </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <label>Remarks (In case of Others)<span class="required"> * </span> </label>
                        <textarea minlength="1" maxlength="100" id="remarks" name="remarks" class="form-control" placeholder="Remarks (In case of Others)"><?php echo isset($osceForm['remarks'])?$osceForm['remarks']:''; ?></textarea>
                    </div>
                </div>
                <div class="clearfix"></div>
               
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>OSCE-1 Score (Max. 20)<span class="required"> * </span> </label>
                            <input data-min="0" data-max="20" minlength="1" maxlength="2" type="text" id="score1" name="score1"  class="form-control nums" placeholder="OSCE-1 Score (Max. 20)" onchange="calculateScore()" value="<?php echo isset($osceForm['score1'])?$osceForm['score1']:''; ?>" >
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>OSCE-2 Score (Max. 20)<span class="required"> * </span> </label>
                            <input data-min="0" data-max="20"  minlength="1" maxlength="2" type="text" id="score2" name="score2"  class="form-control nums" placeholder="OSCE-1 Score (Max. 20)" onchange="calculateScore()" value="<?php echo isset($osceForm['score2'])?$osceForm['score2']:''; ?>" >
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>OSCE-3 Score (Max. 20)<span class="required"> * </span> </label>
                            <input data-min="0" data-max="20"  minlength="1" maxlength="2" type="text" id="score3" name="score3"  class="form-control nums" placeholder="OSCE-3 Score (Max. 20)" onchange="calculateScore()" value="<?php echo isset($osceForm['score3'])?$osceForm['score3']:''; ?>" >
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>OSCE-4 Score (Max. 20)<span class="required"> * </span> </label>
                            <input data-min="0" data-max="20"  minlength="1" maxlength="2" type="text" id="score4" name="score4"  class="form-control nums" placeholder="OSCE-4 Score (Max. 20)" onchange="calculateScore()" value="<?php echo isset($osceForm['score4'])?$osceForm['score4']:''; ?>" >
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>Total OSCE score (Max. 80 ) </label>
                            <input minlength="1" maxlength="100" type="text" id="scoreTot" name="scoreTot" class="form-control nums" readonly="readonly" placeholder="Auto calculated" value="<?php echo isset($osceForm['scoreTot'])?$osceForm['scoreTot']:''; ?>" >
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>Result </label>
                            <input minlength="1" maxlength="100" type="text" id="scoreRes" name="scoreRes" class="form-control" readonly="readonly" placeholder="Auto calculated" value="<?php echo isset($osceForm['scoreRes'])?$osceForm['scoreRes']:''; ?>" >
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>%  OSCE score </label>
                            <input minlength="1" maxlength="100" type="text" id="scorePer" name="scorePer" class="form-control" readonly="readonly" placeholder="Auto calculated" value="<?php echo isset($osceForm['scorePer'])?$osceForm['scorePer']:''; ?>" >
                        </div>
                    </div>

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <div class='input-group pull-right'>
                                <input type="hidden" name="OsceID" id="OsceID" value="<?php echo $this->uri->segment('3'); ?>">
                                <input style="margin-top: 15px; margin-right: 0px;" type='submit' id="osceRpt" name="osceRpt" value="Save" class="btn btn-info" />
                            </div>
                        </div>
                    </div>                    
                </form>
                <hr>
                <?php } ?>
                <?php $show=empty($osce)?'none':'block'; ?>
                <?php if($this->CommonModel->checkPageActionWeb('reports/osce','access_view',$this->session->userdata('RoleName'))){ ?>
                <div class="col-md-12 col-sm-12 col-xs-12" style="overflow-y: auto;">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Sn.</th>
                      <th>Name of the Participant</th>
                      <th>Designation</th>
                      <th>OSCE-1 Score (Max. 20)</th>
                      <th>OSCE-2 Score (Max. 20)</th>
                      <th>OSCE-3 Score (Max. 20)</th>
                      <th>OSCE-4 Score (Max. 20)</th>
                      <th>Total OSCE score (Max. 80 )</th>
                      <th>Result</th>
                      <th>% OSCE score</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    if(!empty($osce)){
                    $i=$score1=$score2=$score3=$score4=$scoreTot=$scoreRes=$scorePer=0; $totData=count($osce); 
                    $access_edit=$this->CommonModel->checkPageActionWeb('reports/osce','access_edit',$this->session->userdata('RoleName'));
                    foreach ($osce as $key => $value) { ?>
                    <tr>
                      <th scope="row"><?php echo ++$i; ?></th>
                      <td><?php echo $value['participant']; ?></td>
                      <td><?php echo $value['designation']; ?></td>
                      <td><?php echo $value['score1']; $score1+=$value['score1']; ?></td>
                      <td><?php echo $value['score2']; $score2+=$value['score2']; ?></td>
                      <td><?php echo $value['score3']; $score3+=$value['score3']; ?></td>
                      <td><?php echo $value['score4']; $score4+=$value['score4']; ?></td>
                      <td><?php echo $value['scoreTot']; $scoreTot+=$value['scoreTot']; ?></td>
                      <td><?php echo $value['scoreRes']; $scoreRes+=$value['scoreRes']; ?></td>
                      <td><?php echo $value['scorePer'].'%'; $scorePer+=$value['scorePer']; ?></td>
                      <td>
                        <?php if($access_edit){ ?>
                        <a href="<?php echo base_url().'reports/osce/'.encryptor($value['OsceID']); ?>" class="btn btn-primary btn-xs view_edit_width" ><i class="glyphicon glyphicon-check"></i>Edit</a>
                        <?php } ?>
                      </td>
                    </tr>
                    <?php } ?>
                    <tr>
                      <th scope="row">Total</th>
                      <td><?php echo $totData; ?></td>
                      <td></td>
                      <td><?php echo $score1; ?></td>
                      <td><?php echo $score2; ?></td>
                      <td><?php echo $score3; ?></td>
                      <td><?php echo $score4; ?></td>
                      <td><?php echo $scoreTot; ?></td>
                      <td><?php echo $scoreRes; ?></td>
                      <td colspan="2"><?php echo round(($scorePer/$totData),2).'%'; ?></td>
                    </tr>
                    <tr>
                      <td colspan="8" align="right" class="font-bold">% Staff Passed the OSCE assessment : </td>
                      <td><?php echo round((($scoreRes*100)/$totData),2); ?></td>
                      <td colspan="2"></td>
                    </tr>
                    <?php } else { ?>
                    <tr>
                      <th colspan="11" align="center" class="font-bold">No record found </th>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
              <?php } ?>
            </div>
        </div>

            </div>
        </div>

        
    </div>
</div>

<style>
  .table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 8px;
    line-height: 1.42857143;
    border: 1px solid #ddd !important;
}

.table thead tr th{background: #337ab7;
                  color: #fff;
                  border: 1px solid #16558c !important;
                  border-bottom: 3px solid #16558c !important;}
</style>