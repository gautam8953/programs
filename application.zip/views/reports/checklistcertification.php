<div class="page-title">
  <div class="title_left">
    <h3>Report</h3>
  </div>
</div>
<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">

		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Checklist Report</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">			      
			      <table id="datatable" class="table table-striped table-bordered">
			        	<thead>
			            <tr>
				            <th>Name of Hospital</th>
				            <th colspan="2">Peer Score / State Score (Highlighted with Yellow ink)</th>
				            <th>Criterion I -  Overall Score of the department (LR / OT shall be ≥70%</th>
				            <th>Criterion II- Score of each Area of Concern of department (LR/OT) shall be 70%</th>
				            <th colspan="3">Criterion III- Individual scores of three core Standards (B3, E18 and E19) shall be ≥70%</th>
				            <th>Criterion IV- Individual Score in each Applicable Quality Standard > 60%</th>
				            <th>Criterion V – Client Satisfaction of the department shall be more ≥80%</th>
				            <th>Total Criterion passed out of 5</th>
			            </tr>
			            <tr>
				            <th></th>
				            <th></th>
				            <th></th>
				            <th></th>
				            <th></th>
				            <th>B3</th>
				            <th>E18</th>
				            <th>E19</th>
				            <th></th>
				            <th></th>
				            <th></th>
			            </tr>
			        	</thead>
			        	<input type="hidden" name="CertificationID" id="CertificationID" value="<?php echo empty($CertificationID)?'':encryptor($CertificationID); ?>" >
			      </table>
			    </div>
			  </div>
			</div>
		</div>        
    </div>
</div>

<style>
	table tr th{background: #337ab7; color: #fff; border-color: #0d3b63 !important;}
</style>