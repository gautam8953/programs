<html lang="en">
<head>
        <title>Laqshya</title>
        <meta charset="utf-8">
        <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <!-- Bootstrap -->
        <link href="<?php echo base_url();?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="<?php echo base_url();?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">

        <!-- Animate.css -->
        <link href="<?php echo base_url();?>assets/vendors/animate.css/animate.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

        <!-- Custom Theme Style -->
        <link href="<?php echo base_url();?>assets/css/custom.min.css" rel="stylesheet">
      <!-- <link href="assets/css/pace-theme-mac-osx.css" rel="stylesheet" /> -->
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900|Open+Sans:400,600,700|Patua+One|Source+Sans+Pro:400,600,700" rel="stylesheet">

<!-- <script src="assets/js/jquery.min.js"></script>-->
      <script src="<?php echo base_url();?>assets/js/jquery1.11.3.min.js"></script>
      <script src="<?php echo base_url();?>assets/js/jquery.cookie.js"></script>

  <!-- <script src='https://www.google.com/recaptcha/api.js'></script> -->
        <script type="text/javascript">
            var pageMainUrl = "<?php echo base_url();?>";
        </script>

        <style>
          .row {
                  margin-right: -15px;
                  margin-left: -15px;
              }
          .container{width: 80%;}

          .table_responsive{100%;}
          .table_responsive table tr th{border-bottom: 3px solid #333 !important;}
          .table_responsive table tr th, td {border: 1px solid #333; padding: 10px;}
        </style>


    </head>
    <body class="termsandconditions">

        <header>

            <div class="header-bottom">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-3 col-xs-6 indian-emblem"><img style="padding-top: 5px;" src="<?php echo base_url();?>/assets/images/indianembelem_2.png" alt="Indian Emblem"></div>
                        <div class="col-md-6 col-xs-12 text-center main-logo">
                          <h1 style="margin-top: 20px;">
                            <span class="emonitoring">e-Monitoring System for LaQshya</span>
                          </h1>
                        </div>
                        <div class="col-md-3 col-xs-6 nhp-logo"><a href="http://www.nihfw.org/" target="_blank"><img src="https://pmsma.nhp.gov.in/laqshya/assets/images/nihfw-logo.png" alt="NIHFW" class="ihd-logo"></a> <a href="https://www.nhp.gov.in/" target="_blank"><img style="padding-top: 4px;" src="https://pmsma.nhp.gov.in/laqshya/assets/images/logo-nhp.png" alt="NHP" class="nhp-logo"></a></div>
                    </div>
                </div>
            </div>
        </header>

        
        <div class="container-fluid">
          <div class="row terms_heading">
            <div class="container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <h3>Help</h3>
                </div>
              </div>
            </div>
          </div>


          <div class="row bread_crumb">
            <div class="container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <span><a href="http://demosl56.rvsolutions.in/nhp-laqshya/laqshya-website-drupal/"><i class="fa fa-home"></i>&nbsp;Home </a>&nbsp; <i class="fa fa-angle-right"></i> &nbsp;<span> Help</span></span>
                </div>
              </div>
            </div>
          </div>


          <div class="row terms_content">
            <div class="container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <h3>Viewing Information in Various File Formats</h3>
                  <p>The information provided by this website is available in various file formats, such as Portable Document Format (PDF), Word, Excel and PowerPoint. To view the information properly, your browser needs to have the required plug-ins or software. For example, the Adobe Flash software is required to view the Flash files. In case your system does not have this software, you can download it from the Internet for free. The table lists the required plug-ins needed to view the information in various file formats.</p>


                  <br><br>


                  <h3>Plug-in for alternate document types</h3>
                  <div class="table_responsive">
                  <table>
                    <thead>
                      <tr>
                        <th>Document Type</th>
                        <th>Plug-in for Download</th>
                      </tr>
                    </thead>

                    <tbody>
                      <tr>
                        <td>Portable Document Format (PDF) files</td>
                        <td>Adobe Acrobat Reader Convert a PDF file online into HTML or text format</td>
                      </tr>

                      <tr>
                        <td>Word files</td>
                        <td>Word Viewer (in any version till 2003) Microsoft Office Compatibility Pack for Word (for 2007 version)</td>
                      </tr>

                      <tr>
                        <td>Excel files</td>
                        <td>Excel Viewer 2003 (in any version till 2003) Microsoft Office Compatibility Pack for Excel (for 2007 version)</td>
                      </tr>

                      <tr>
                        <td>PowerPoint presentations</td>
                        <td>PowerPoint Viewer 2003 (in any version till 2003) Microsoft Office Compatibility Pack for PowerPoint (for 2007 version)</td>
                      </tr>

                      <tr>
                        <td>Flash content</td>
                        <td>Adobe Flash Player</td>
                      </tr>
                    </tbody>
                  </table>
                  </div>



                </div>
              </div>
            </div>
          </div>
        </div>



        <footer>
            <div class="container">
                <div class="row">


                    <div class="col-md-6 col-sm-8 col-sm-6 col-xs-12 text-center visitor-number">
                        Copyright &copy; 2018. LaQshya. All Rights Reserved.
                    </div>
                    <div class="col-md-6 col-sm-4 col-sm-6 col-xs-12 text-center footer-right">
                        <img src="https://pmsma.nhp.gov.in/laqshya/assets/images/my-gov.png" alt="My Gov">
                        <img src="https://pmsma.nhp.gov.in/laqshya/assets/images/india-gov.png" alt="India Gov">
                    </div>
                </div>
            </div>
        </footer>




        <!-- date Picker -->
        <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/jquery.form.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/sweetalert.min.js"></script>

        <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>

        <script src="<?php echo base_url();?>assets/js/bootstrap-select.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/moment.min.js"></script> 
        <script src="<?php echo base_url();?>/assets/js/bootstrap-datetimepicker.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/custom.js"></script>
    
</body>
</html>