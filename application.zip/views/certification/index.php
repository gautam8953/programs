<div class="page-title">
  <div class="title_left">
    <h3>Certification</h3>
  </div>

  
</div>

<div class="clearfix"></div>

<div class="main-content carti-c Certification_List"> 
    <div class="container">	  
    <div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Certification List</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">  
        
	    <?php if(!empty($search_options['Facility'])){ ?>
	   
	        <div class="col-md-12">
	        	<div class="row mar-bottom30">
	        <?php 
	        $attr = array("class" => "form-horizontal", "role" => "form", "id" => "form1", "name" => "form1");
	        echo form_open("facility/data", $attr);
	        ?>	            
            	<?php if(isset($search_options['State']) ){ ?>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_state" name="search_state" onchange="change_state()" class="form-control">
						<option value="">Select State</option>
						<?php foreach ($search_options['State'] as $key => $value) {  ?>
						<option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
						<?php } ?>
					</select>                    
                </div>
                <?php } ?>
                <?php if(isset($search_options['District']) ){ ?>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_district" name="search_district" onchange="change_district()" class="form-control">
						<option value="">Select District</option>
						<?php foreach ($search_options['District'] as $key => $value) { ?>
						<option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
						<?php } ?>
					</select>                    
                </div>
                <?php } ?>
                <?php if(isset($search_options['Facility']) ){ ?>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_facility" name="search_facility" class="form-control" onchange="change_facility()" >
						<option value="">Select Facility</option>
						<?php  foreach ($search_options['Facility'] as $key => $value) {  ?>
						<option value="<?php echo $value['UserID']; ?>" ><?php echo $value['FacilityName']; ?></option>
						<?php } ?>
					</select>                    
                </div>
                <?php } ?>
                <div class="col-md-3 col-xs-12 mar-top-20">
                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" style="display: none;" />
                    <a href="javascript:void(0)" id="reset_btn" class="btn btn-primary">Reset</a>
                </div>
            </div>
            <hr>
	        <?php echo form_close(); ?>
            	
	        </div>
	    	<?php } ?>
		
			      <?php $RoleName=$this->session->userdata('RoleName'); ?>
			      <table id="datatable" class="table table-striped table-bordered">
			        <thead>
			            <tr>
			                <th>SN.</th>
			                <?php if($RoleName=='Ministry'){ ?>
			                <th>State</th>
			                <?php } ?>
			                <?php if($RoleName=='State' || $RoleName=='Ministry'){ ?>
			                <th>District</th>
			                <?php } ?>
			                <?php if($RoleName=='District' || $RoleName=='State' || $RoleName=='Ministry' ){ ?>
			                <th>Facility</th>
			            	<?php } ?>
			                <th>Certification Type</th>
			                <th>Unit</th>
			                <th>Status</th>
			                <th>Action</th>
			            </tr>
			            </thead>
			            <tbody>
			            	<tr>
				                <td></td>
				                <?php if($RoleName=='Ministry'){ ?>
				                <td></td>
				                <?php } ?>
				                <?php if($RoleName=='State' || $RoleName=='Ministry'){ ?>
				                <td></td>
				                <?php } ?>
				                <?php if($RoleName=='District' || $RoleName=='State' || $RoleName=='Ministry' ){ ?>
				                <td></td>
				            	<?php } ?>
			            		<td></td>
			            		<td></td>
			                	<td></td>
			                	<td></td>
			            	</tr>
			            </tbody>
			      </table>
			    </div>
			  </div>
			</div>
		</div>        
    </div>
</div>

<!-- modal window start  -->
<div id="clientScoreModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Client Satisfaction Score</h4>
      </div>
      <div class="modal-body">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="form-group">
                    <label>Client Satisfaction Score</label>
                    <input maxlength="3" type="text" id="clientScore" name="clientScore" class="form-control nums" placeholder="Client Satisfaction Score">
                    <input type="hidden" id="assessmentID" name="assessmentID" class="form-control" readonly="readonly">
                </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="form-group pull-right">
                	<input id="clientScoreBtn" name="clientScoreBtn" type="button" class="btn btn-success" value="Submit" onclick="saveClientScore()" />
                </div>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!-- modal window end  -->
