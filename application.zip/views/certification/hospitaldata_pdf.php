 
<style>
body {
	margin: 0px;
	box-sizing: border-box;
	position: relative;
	font-family: sans-serif;
	font-size: 10px;
	line-height:10px;

}

table{width: 100%;}
.score-border td{font-size: 8px;}
span.title {
	font-weight: 600;
	margin-bottom: 3px;
	display: block;
}

tr {
	list-style: none;
	padding: 0;
	margin: 0px 0px;
}
td, th {
	vertical-align: top;
	padding: 0px 10px;
	font-size: 10px;
	line-height: 150%;
	 
	vertical-align: middle;
}
.score-border th{ font-size: 9px; }
.score-border td{ }
.col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}
h1 {margin-bottom: 40px; text-align: center; font-weight: 400; }
h2 {width: 100%;
	font-size: 12px;
	margin-top: 20px;
	font-weight: 600;}

	h3 { margin: 0; width: 100%;
		font-weight: 600;}
		p {    width: 100%;
			font-size: 10px;
			float: left; padding: 0px 10px;}
			header{border: none;}    

		</style>


		<table cellpadding="5" cellspacing="0"   align="center" style="border-bottom:2px solid #344c98 ">
			<tr class="heading" >
				<td valign="middle" align="left" cellpadding="20" >
					<br><br><br>
					<img src="<?php echo base_url();?>/assets/images/laqshya-logo-pdf.png" style="width:120px; margin-top: 20px" ></td>
					<td valign="middle" style="text-align: center"><img src="<?php echo base_url();?>/assets/images/Emblem_of_India.svg" style="height:75px"></td> 
					<td valign="middle" align="right" style="font-size:9px" ><b style="font-size:14px"><br>LaQshya  </b><br>
						Ministry of Health and <br>
						Family Welfare (MoHFW) <br>
					Government of India</td>

				</tr>

			</table>
			<br><br>
			<table cellpadding="5" cellspacing="0"  bgcolor="#eaf1f7">
				<tr class="heading" >
					<td style="font-size:13px; text-align: center; color: #344c98;"> <b><?php echo $this->config->item('certificationLevel')[$data['main']['level']]; ?> <?php echo $this->config->item('survey')[$data['main']['certification_type']]; ?></b></td>
				</tr>
			</table>

			<br>
		<br>

			<table cellpadding="5" cellspacing="0">
				    <tr class="heading">
				        <td style="font-size:10px">
				            <br><b>Name of Health Facility :</b> <?php echo empty($data['show']['FacilityName'])?'':$data['show']['FacilityName']; ?>
				            <br><b>Full Address :</b> <?php echo empty($data['main']['Address'])?'':$data['main']['Address']; ?>
				            <br><b>Contact Details:</b> <?php echo empty($data['main']['landLine'])?'':$data['main']['landLine']; ?>
				            
				        </td>

				        <td style="font-size:10px; text-align: right">


				        </td>

				    </tr>

				</table>
			<br>
		<br>

		<table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff" class="score-border">
            <tr class="heading" bgcolor="#e1e8ff">
              <td colspan="2" style="font-size:9px; text-align: center; color: #0c0c0c;">SQAU</td>
            </tr>
 
                          <tr>
                          	<td width="5%" style="text-align:center" >I</td>
                            <td  >Nodal Officer:</td>
                            <td><b> <?php echo empty($data['main']['sqauOfficer'])?'':$data['main']['sqauOfficer']; ?></b></td>
                          </tr>
 
                          <tr>
                            <td style="text-align:center" >II</td>
                            <td>Email:</td>
                            <td><b><?php echo empty($data['main']['sqauEmail'])?'':$data['main']['sqauEmail']; ?></b></td>
                          </tr>

                          <tr>
                            <td style="text-align:center" >III</td>
                            <td>Tel:</td>
                            <td><b><?php echo empty($data['main']['sqauTel'])?'':$data['main']['sqauTel']; ?></b></td>
                          </tr>
            
          </table>

          <br>
		<br>
		<table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff" class="score-border">
            <tr class="heading" bgcolor="#e1e8ff">
              <td colspan="2" style="font-size:9px; text-align: center; color: #0c0c0c;">DQAU</td>
            </tr>
 
                          <tr>
                          	<td width="5%" style="text-align:center" >I</td>
                            <td >Nodal Officer:</td>
                            <td><b><?php echo empty($data['main']['dqauOfficer'])?'':$data['main']['dqauOfficer']; ?></b></td>
                          </tr>
 
                          <tr>
                            <td style="text-align:center" >II</td>
                            <td>Email:</td>
                            <td><b><?php echo empty($data['main']['dqauEmail'])?'':$data['main']['dqauEmail']; ?></b></td>
                          </tr>

                          <tr>
                            <td style="text-align:center" >III</td>
                            <td>Tel:</td>
                            <td><b><?php echo empty($data['main']['dqauTel'])?'':$data['main']['dqauTel']; ?></b></td>
                          </tr>

                          <tr>
                            <td style="text-align:center" >IV</td>
                            <td>Score of the facility in Peer Assessment:</td>
                            <td><b><?php echo empty($data['main']['dqauPeerAssmentScore'])?'':$data['main']['dqauPeerAssmentScore']; ?>%</b></td>
                          </tr>
            
          </table>

          <br>
		<br>


		<table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff" class="score-border">
            <tr class="heading" bgcolor="#e1e8ff">
              <td colspan="2" style="font-size:9px; text-align: center; color: #0c0c0c;">Facility</td>
            </tr>
 
                          <tr>
                          	<td width="5%" style="text-align:center" >I</td>
                            <td >Nodal Officer:</td>
                            <td><b><?php echo empty($data['main']['facilityOfficer'])?'':$data['main']['facilityOfficer']; ?></b></td>
                          </tr>
 
                          <tr>
                            <td style="text-align:center" >II</td>
                            <td>Email:</td>
                            <td><b> <?php echo empty($data['main']['facilityEmail'])?'':$data['main']['facilityEmail']; ?></b></td>
                          </tr>

                          <tr>
                            <td style="text-align:center" >III</td>
                            <td>Tel:</td>
                            <td><b><?php echo empty($data['main']['facilityTel'])?'':$data['main']['facilityTel']; ?></b></td>
                          </tr>

                          <tr>
                            <td style="text-align:center" >IV</td>
                            <td>Score of the facility in Peer Assessment:</td>
                            <td><b><?php echo empty($data['main']['facilityPeerAssmentScore'])?'':$data['main']['facilityPeerAssmentScore']; ?>%</b></td>
                          </tr>
            
          </table>

          <br>
		<br>


		<table cellpadding="5" cellspacing="0">
				    <tr class="heading">
				        <td style="font-size:10px">
				            <br><b>Nearest Railway Station :</b>   <?php echo empty($data['main']['railwayStation'])?'':$data['main']['railwayStation']; ?>
				            <br><b>Nearest Airport :</b>  <?php echo empty($data['main']['airport'])?'':$data['main']['airport']; ?> 
				            <br><b>No of Normal Deliveries in Last FY	:</b> <?php echo empty($data['main']['numDeleveries'])?'':$data['main']['numDeleveries']; ?>
				            <br><b>No. of C- Sections in Last FY Years	:</b>  <?php echo empty($data['main']['numCSec'])?'':$data['main']['numCSec']; ?>   
				            
				        </td>

				        <td style="font-size:10px; text-align: right">


				        </td>

				    </tr>

				</table>
			<br>
		<br>





			<!-------------- old code  
 	
   
		<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>