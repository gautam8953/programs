<style>
		.col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}
		
</style>


<div class="page-title">
	<div class="title_left full-width">
		<h3><?php echo $this->config->item('certificationLevel')[$data['main']['level']]; ?> <?php echo $this->config->item('survey')[$data['main']['certification_type']]; ?></h3>
	</div>
</div>
<div class="clearfix"></div>


<div class="main-content main-content-form-gr-h carti-c">
		<div class="container">
				<div class="row">


						<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="x_panel">
										<div class="x_title">
												<h2>Hospital Data </h2>
												<ul class="nav navbar-right panel_toolbox">
														<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
												</ul>
												<div class="clearfix"></div>
										</div>
										<div class="x_content">
<table class="table-view-table table-view-table1">
	<tbody>
		<tr>
			<td style="width: 30%;">1. Name of Health Facility </td>
			<td>
				<?php echo empty($data['show']['FacilityName'])?'':$data['show']['FacilityName']; ?>
			</td>
		</tr>
		<tr>
			<td>2. Full Address </td>
			<td>
				<?php echo empty($data['show']['Address'])?'':$data['show']['Address']; ?>
			</td>
		</tr>
		<tr>
			<td>3. Contact Details </td>
			<td>
				<?php echo empty($data['show']['landLine'])?'':$data['show']['landLine']; ?>
			</td>
		</tr>
		<tr class="borddr-bton">
			<td>4. SQAU </td>
			<td>
				<table class="table-view-table">
					<tr>
						<td style="width: 50%;" >i. Nodal Officer-</td>
						<td>
							<?php echo empty($data['main']['sqauOfficer'])?'':$data['main']['sqauOfficer']; ?>
						</td>
					</tr>
					<tr>
						<td>ii. Email </td>
						<td>
							<?php echo empty($data['main']['sqauEmail'])?'':$data['main']['sqauEmail']; ?>
						</td>
					</tr>
					<tr>
						<td>iii. Tel –  </td>
						<td>
							<?php echo empty($data['main']['sqauTel'])?'':$data['main']['sqauTel']; ?>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td>5. DQAU </td>
			<td>
				<table class="table-view-table" >
					<tr>
						<td style="width: 50%;">i. Nodal Officer-</td>
						<td>
							<?php echo empty($data['main']['dqauOfficer'])?'':$data['main']['dqauOfficer']; ?>
						</td>
					</tr>
					<tr>
						<td>ii. Email </td>
						<td>
							<?php echo empty($data['main']['dqauEmail'])?'':$data['main']['dqauEmail']; ?>
						</td>
					</tr>
					<tr>
						<td>iii. Tel –  </td>
						<td>
							<?php echo empty($data['main']['dqauTel'])?'':$data['main']['dqauTel']; ?>
						</td>
					</tr>
					<tr>
						<td>iv. Score of the facility in Peer Assessment - </td>
						<td>
							<?php echo empty($data['main']['dqauPeerAssmentScore'])?'':$data['main']['dqauPeerAssmentScore']; ?>
						%</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr class="borddr-bton">
			<td>6. Facility </td>
			<td>
				<table class="table-view-table">
					<tr>
						<td style="width: 50%;">i. Nodal Officer-</td>
						<td>
							<?php echo empty($data['main']['facilityOfficer'])?'':$data['main']['facilityOfficer']; ?>
						</td>
					</tr>
					<tr>
						<td>ii. Email </td>
						<td>
							<?php echo empty($data['main']['facilityEmail'])?'':$data['main']['facilityEmail']; ?>
						</td>
					</tr>
					<tr>
						<td>iii. Tel –  </td>
						<td>
							<?php echo empty($data['main']['facilityTel'])?'':$data['main']['facilityTel']; ?>
						</td>
					</tr>
					<tr>
						<td>iv. Score of the facility in Peer Assessment - </td>
						<td>
							<?php echo empty($data['main']['facilityPeerAssmentScore'])?'':$data['main']['facilityPeerAssmentScore']; ?>
						%</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td>7. Nearest Railway Station </td>
			<td>
				<?php echo empty($data['main']['railwayStation'])?'':$data['main']['railwayStation']; ?>
			</td>
		</tr>
		<tr>
			<td>8. Nearest Airport </td>
			<td>
				<?php echo empty($data['main']['airport'])?'':$data['main']['airport']; ?>
			</td>
		</tr>
		<tr>
			<td>9. No of Normal Deliveries in Last FY </td>
			<td>
				<?php echo empty($data['main']['numDeleveries'])?'':$data['main']['numDeleveries']; ?>
			</td>
		</tr>
		<tr>
			<td>10. No. of C- Sections in Last FY Years</td>
			<td>
				<?php echo empty($data['main']['numCSec'])?'':$data['main']['numCSec']; ?>
			</td>
		</tr>
	</tbody>
</table>
										</div>
								</div>



						</div>
				




				</div>
		</div>
</div>
<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>