<style>
		.col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}
		
</style>


<div class="page-title">
	<div class="title_left full-width">
		<h3><!-- Apply For <?php echo $level; ?> <?php echo $this->config->item('survey')[$type]; ?>--> Certification Apply</h3>
	</div>
</div>
<div class="clearfix"></div>


<div class="main-content main-content-form-gr-h ApplyFor_center newap-cneter carti-c">
		<div class="container">
				<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="x_panel">
										<div class="x_title">
												<h2>Apply <?php echo $level; ?> <?php echo $this->config->item('survey')[$type]; ?> Certification</h2>
												<ul class="nav navbar-right panel_toolbox">
														<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
												</ul>
												<div class="clearfix"></div>
										</div>
										<div class="x_content">
												<!-- <form id="assesmentForm" name="assesmentForm" role="form" action="<?php //echo base_url()."ApiFacility/assesment"?>" method="post"> -->
												<div id="smartwizard">
													<ul>
														<li><a href="#step-0"><span><em> A </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>Application Form<br /></a></li>
														<li><a href="#step-1"><span><em> B </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>Fill Hospital Data<br /></a></li>
														<li><a href="#step-2"><span><em> C </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>Upload Documents<br /></a></li>
													</ul>
													<div>
														<!-- Step Start -->														
														<div id="step-0">
<div class="col-md-12 col-xs-12">
		<div class="form-group pull-right">
			<a target="_blank" href="<?php echo base_url(); ?>certification/downloadFormat/<?php echo encryptor($user); ?>/<?php echo encryptor($type); ?>" class="btn btn-info">Print Application Format</a>
		</div>
</div>
    <?php if($type=='both'){ ?>
    <div class="col-md-4 col-sm-6 col-xs-12">
        <div class="form-group">
            <label>Certification Type <span class="required">*</span></label>
            <select name="type" id="type" class="form-control">
            <?php foreach ($this->config->item('survey') as $key => $value) {
            if(is_numeric($key)){ continue; }
            if(isset($data['main']['certification_type']) && $data['main']['certification_type']==$key){
            	$selectType=' selected="selected" ';
            } else {
            	$selectType='';
            }
            ?>
            <option value="<?php echo encryptor($key); ?>" <?php echo $selectType; ?> ><?php echo $value; ?></option>	
            <?php } ?>	
            </select>
        </div>
    </div>
    <?php } else { ?>
    <input type="hidden" name="type" id="type" value="<?php echo empty($type)?'':encryptor($type); ?>" >
    <?php } ?>
	<div class="col-md-4 col-xs-12">
		<div class="form-group">
				<label>Upload Application Form <span class="required"> * </span> </label>
				<br>
				<input type="file" id="appForm" name="appForm" accept=".jpg,.JPG,.jpeg,.JPEG,.png,.PNG,.pdf" onchange="checkFile(this)" class="inputfile inputfile-6 form-control" data-multiple-caption="{count} files selected" />
		<label for="appForm"><span></span> <strong><i class="fa fa-upload"></i> Choose a file&hellip;</strong></label>
		<?php if(!empty($data['main']['appForm'])){ $appFormUrl=is_file($data['main']['appForm'])?base_url().$data['main']['appForm']:''; } else { $appFormUrl=''; }; if(!empty($appFormUrl)){ ?>
		<a target="_blank" class="appForm viewdetailpage" href="<?php echo $appFormUrl; ?>"  ><strong>View</strong></a>
		<?php } ?>
		</div>
	</div>




															<div class="clear"></div>
														</div>
														<div id="step-1" style="">
<table class="appli-form-form-table">
	<tbody>
		<tr>
			<td><strong>Name of Health Facility </strong></td>
			<td>
				<input minlength="1" maxlength="100" type="text" id="FacilityName" name="FacilityName" class="form-control" placeholder="Facility Name" value="<?php echo empty($data['main']['FacilityName'])?$data['show']['FacilityName']:$data['main']['FacilityName']; ?>"  >
			</td>
		</tr>
		<tr>
			<td><strong>Full Address </strong></td>
			<td>
				<input minlength="1" maxlength="254" type="text" id="Address" name="Address" class="form-control" placeholder="" value="<?php echo empty($data['main']['Address'])?$data['show']['Address']:$data['main']['Address']; ?>"  >
			</td>
		</tr>
		<tr>
			<td><strong>Contact Details </strong></td>
			<td>
				<input minlength="1" maxlength="15" type="text" id="landLine" name="landLine" class="form-control" placeholder="" value="<?php echo empty($data['main']['landLine'])?$data['show']['landLine']:$data['main']['landLine']; ?>"  >
			</td>
		</tr>
		<tr class="borddr-bton">
			<td><strong>SQAU </strong></td>
			<td>
				<table>
					<tr>
						<td>i. Nodal Officer-</td>
						<td style="    width: 346px;">
							<input minlength="1" maxlength="100" type="text" id="sqauOfficer" name="sqauOfficer" class="form-control" placeholder="Nodal Officer" value="<?php echo empty($data['main']['sqauOfficer'])?'':$data['main']['sqauOfficer']; ?>" >
						</td>
					</tr>
					<tr>
						<td>ii. Email </td>
						<td>
							<input minlength="1" maxlength="254" type="text" id="sqauEmail" name="sqauEmail" class="form-control" placeholder="Email" value="<?php echo empty($data['main']['sqauEmail'])?'':$data['main']['sqauEmail']; ?>" >
						</td>
					</tr>
					<tr>
						<td>iii. Tel –  </td>
						<td>
							<input minlength="1" maxlength="15" type="text" id="sqauTel" name="sqauTel" class="form-control nums" placeholder="Telephone" value="<?php echo empty($data['main']['sqauTel'])?'':$data['main']['sqauTel']; ?>" >
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr class="borddr-bton1">
			<td><strong>DQAU </strong></td>
			<td>
				<table>
					<tr>
						<td>i. Nodal Officer-</td>
						<td style="    width: 346px;">
							<input minlength="1" maxlength="100" type="text" id="dqauOfficer" name="dqauOfficer" class="form-control" placeholder="Nodal Officer" value="<?php echo empty($data['main']['dqauOfficer'])?'':$data['main']['dqauOfficer']; ?>" >
						</td>
					</tr>
					<tr>
						<td>ii. Email </td>
						<td>
							<input minlength="1" maxlength="254" type="text" id="dqauEmail" name="dqauEmail" class="form-control" placeholder="Email" value="<?php echo empty($data['main']['dqauEmail'])?'':$data['main']['dqauEmail']; ?>" >
						</td>
					</tr>
					<tr>
						<td>iii. Tel –  </td>
						<td>
							<input minlength="1" maxlength="15" type="text" id="dqauTel" name="dqauTel" class="form-control nums" placeholder="Telephone" value="<?php echo empty($data['main']['dqauTel'])?'':$data['main']['dqauTel']; ?>" >
						</td>
					</tr>
					<tr>
						<td>iv. Score of the facility in Peer Assessment - </td>
						<td>
							<input minlength="1" maxlength="5" type="text" id="dqauPeerAssmentScore" name="dqauPeerAssmentScore" class="form-control" placeholder="Peer Assessment Score %" value="<?php echo empty($data['main']['dqauPeerAssmentScore'])?'':$data['main']['dqauPeerAssmentScore']; ?>" > </td>
					</tr>
				</table>
			</td>
		</tr>
		<tr  class="borddr-bton">
			<td><strong>Facility </strong></td>
			<td>
				<table>
					<tr>
						<td>i. Nodal Officer-</td>
						<td style="    width: 346px;">
							<input minlength="1" maxlength="100" type="text" id="facilityOfficer" name="facilityOfficer" class="form-control" placeholder="Nodal Officer" value="<?php echo empty($data['main']['facilityOfficer'])?'':$data['main']['facilityOfficer']; ?>" >
						</td>
					</tr>
					<tr>
						<td>ii. Email </td>
						<td>
							<input minlength="1" maxlength="254" type="text" id="facilityEmail" name="facilityEmail" class="form-control" placeholder="Email" value="<?php echo empty($data['main']['facilityEmail'])?'':$data['main']['facilityEmail']; ?>" >
						</td>
					</tr>
					<tr>
						<td>iii. Tel –  </td>
						<td>
							<input minlength="1" maxlength="15" type="text" id="facilityTel" name="facilityTel" class="form-control nums" placeholder="Telephone" value="<?php echo empty($data['main']['facilityTel'])?'':$data['main']['facilityTel']; ?>" >
						</td>
					</tr>
					<tr>
						<td>iv. Score of the facility in Peer Assessment - </td>
						<td>
							<input minlength="1" maxlength="5" type="text" id="facilityPeerAssmentScore" name="facilityPeerAssmentScore" class="form-control" placeholder="peer Assessment Score %" value="<?php echo empty($data['main']['facilityPeerAssmentScore'])?'':$data['main']['facilityPeerAssmentScore']; ?>"   > </td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td><strong>Nearest Railway Station</strong></td>
			<td>
				<input minlength="1" maxlength="254" type="text" id="railwayStation" name="railwayStation" class="form-control" placeholder="Nearest Railway Station" value="<?php echo empty($data['main']['railwayStation'])?'':$data['main']['railwayStation']; ?>" >
			</td>
		</tr>
		<tr>
			<td><strong>Nearest Airport</strong></td>
			<td>
				<input minlength="1" maxlength="254" type="text" id="airport" name="airport" class="form-control" placeholder="Nearest Airport" value="<?php echo empty($data['main']['airport'])?'':$data['main']['airport']; ?>" >
			</td>
		</tr>
		<tr>
			<td><strong>No of Normal Deliveries in Last FY </strong></td>
			<td>
				<input minlength="1" maxlength="5" type="text" id="numDeleveries" name="numDeleveries" class="form-control" placeholder="No of Normal Deliveries" value="<?php echo empty($data['main']['numDeleveries'])?'':$data['main']['numDeleveries']; ?>" >
			</td>
		</tr>
		<tr>
			<td><strong>No. of C- Sections in Last FY Years</strong></td>
			<td>
				<input minlength="1" maxlength="5" type="text" id="numCSec" name="numCSec" class="form-control" placeholder="No. of C- Sections" value="<?php echo empty($data['main']['numCSec'])?'':$data['main']['numCSec']; ?>" >
			</td>
		</tr>
	</tbody>
</table>

															<div class="clear"></div>
														</div>
														<div id="step-2"  style="">
<div class="row">
	<?php if(@$data['show']['services']=='both' || ($type=='both' || $type=='lr')){ ?>
	<div class="col-md-4 col-xs-12">
		<div class="form-group">
				<label>Upload LR SOP <span class="required"> * </span> </label>
				<br>
				<input type="file" id="lrsop" name="lrsop" accept=".jpg,.JPG,.jpeg,.JPEG,.png,.PNG,.pdf" onchange="checkFile(this)" class="inputfile inputfile-6 form-control" data-multiple-caption="{count} files selected" />
		<label for="lrsop" class="pull-left"><span></span> <strong><i class="fa fa-upload"></i> Choose a file&hellip;</strong></label>
        <?php if(!empty($data['main']['lrsop'])){ $lrsopUrl=is_file($data['main']['lrsop'])?base_url().$data['main']['lrsop']:''; } else { $lrsopUrl=''; }; if(!empty($lrsopUrl)){ ?>
        		<a target="_blank" class="lrsop viewdetailpage" href="<?php echo $lrsopUrl; ?>">View</a>
        <?php } ?>
		</div>
	</div>
	 
	<?php } ?>
	<?php if(@$data['show']['services']=='both' || ($type=='both' || $type=='ot') ){ ?>
	<div class="col-md-4 col-xs-12">
		<div class="form-group">
				<label>Upload OT SOP <span class="required"> * </span> </label>
				<br>
				<input type="file" id="otsop" name="otsop" accept=".jpg,.JPG,.jpeg,.JPEG,.png,.PNG,.pdf" onchange="checkFile(this)" class="inputfile inputfile-6 form-control" data-multiple-caption="{count} files selected" />
		<label for="otsop" class="pull-left"><span></span> <strong><i class="fa fa-upload"></i> Choose a file&hellip;</strong></label>
        <?php if(!empty($data['main']['otsop'])){ $otsopUrl=is_file($data['main']['otsop'])?base_url().$data['main']['otsop']:''; } else { $otsopUrl=''; }; if(!empty($otsopUrl)){ ?>
        <a target="_blank" href="<?php echo $otsopUrl; ?>" class="viewdetailpage">View</a>
        <?php } ?>
		</div>
	</div>
	<?php } ?>

	<div class="col-md-2 col-xs-12">
		<div class="form-group" style="    margin-top:26px;">
			<button id="" onclick="addMore(this)" class="btn btn-info">Add More</button>
		</div>
</div>


</div>
<!--
<div class="col-md-12 col-xs-12">
		<div class="form-group">
			<button id="" onclick="addMore(this)" class="btn btn-info">Add More</button>
		</div>
</div> -->
<?php if(!empty($data['othername'])){ foreach($data['othername'] as $key => $value) { ?>
<div class="row saved">
	
    <div class="col-md-4 col-sm-4 col-xs-12">
        <div class="form-group">
            <label> Document Name </label>
            <input minlength="1" maxlength="100" type="text" id="othernameSaved_<?php echo $key+1; ?>" name="othernameSaved[]" class="form-control" placeholder="Name of assessee" value="<?php echo empty($value['name'])?'':$value['name']; ?>"  >
            <input type="hidden" id="otherdocID_<?php echo $key+1; ?>" name="certification_otherdocID[]" class="form-control"  value="<?php echo empty($value['certification_otherdocID'])?'':$value['certification_otherdocID']; ?>"  >

        </div>
    </div>	
    <div class="col-md-4 col-sm-4 col-xs-12">
    	 
        <?php if(!empty($value['doc'])){ $docUrl=is_file($value['doc'])?base_url().$value['doc']:''; } else { $docUrl=''; }; if(!empty($docUrl)){ ?>
        <a target="_blank" href="<?php echo $docUrl; ?>" class="viewdetailpage" style="    margin-top: 27px;">View</a> <button onclick="removeRowS(this)" class="btn btn-danger" style="    margin-top: 9px;     padding: 3px 20px;"><i class="fa fa-times" aria-hidden="true"></i></button>
        <?php } ?>
    </div>

    
</div>

<?php } } //else { ?>
<div class="row copy">
	<div class="col-md-4 col-sm-4 col-xs-12">
		<div class="form-group">
				<label>Upload Other DOC </label>
				<br>
				<input type="file" id="otherdoc_1" name="otherdoc[]" accept=".jpg,.JPG,.jpeg,.JPEG,.png,.PNG,.pdf" onchange="checkFile(this)" class="inputfile inputfile-6 form-control" data-multiple-caption="{count} files selected" />
		<label for="otherdoc_1"><span></span> <strong><i class="fa fa-upload"></i> Choose a file&hellip;</strong></label>
		</div>
	</div>
    <div class="col-md-4 col-sm-4 col-xs-12">
        <div class="form-group">
            <label> Document Name </label>
            <input minlength="1" maxlength="100" type="text" id="othername_1" name="othername[]" class="form-control" >
        </div>
    </div>	
</div>
<?php //} ?>
															<div class="clear"></div>
														</div>
														<input type="hidden" name="facilityUser" id="facilityUser" value="<?php echo empty($user)?'':encryptor($user); ?>" >
														<input type="hidden" name="level" id="level" value="<?php echo empty($level)?'':encryptor($level); ?>" >
														<input type="hidden" name="CertificationID" id="CertificationID" value="<?php echo empty($CertificationID)?'':encryptor($CertificationID); ?>" >
														<input type="hidden" name="certification_no" id="certification_no" value="<?php echo empty($data['certification_no'])?'':$data['certification_no']; ?>" >

														<!-- Step End -->

													</div>
												</div>
												<!-- </form> -->


										</div>
								</div>



						</div>
				</div>
		</div>
</div>
<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>