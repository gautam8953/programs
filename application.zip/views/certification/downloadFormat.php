<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<p>
Application for External Certification under LaQshya Quality Improvement Initiative
<br/><br/>
From
<br/>
State Quality Assurance Committee
<br/><br/>
No. __________       Date:__________________
<br/><br/>                                                                                           
To,
<br/>
Joint Secretary (Policy)
<br/>
Ministry of Health & Family Welfare
<br/>
Government of India
<br/>
Nirman Bhawan, Maulana Azad Road
<br/>
New Delhi – 110011
<br/><br/>

REQUEST FOR ASSESSMENT OF HEALTH FACILITY FOR LaQshya CERTIFICATION
<br/><br/>
Sir,
<br/>
We are happy to inform that <strong><?php echo empty($data['FacilityName'])?'……………':$data['FacilityName']; ?></strong>  has made substantial progress under LaQshya Quality Improvement Initiative and the health facility has scored following scores against NQAS in latest peer/ state level assessment. 
<br/><br/>
Labour Room – <strong><?php echo empty($data['lr'])?'……………':$data['lr']; ?></strong>
<?php if($type=='both' || $type=='ot'){ ?>
<br/>
Maternity OT – <strong><?php echo empty($data['ot'])?'……………':$data['ot']; ?></strong>
<?php } ?>
<br/><br/>
The scores have been validated by State Quality Assurance Committee (SQAC)
Hence, we request you to issue instructions for assessment of the health facility for LaQshya certification. Detail information on the health facility is given in the attached
appendix I.
<br/><br/><br/>
Thanking you.
<br/>
Yours sincerely
<br/>
STATE MISSION DIRECTOR, …….. 
<br/><br/>
<!-- CC-  1. Deputy Commissioner, Maternal Health, MoHFW, Government of India 
         2. Advisor – Quality Improvement, NHSRC, New Delhi  --> 
</p>
</body>
</html>
<script src="<?php echo base_url();?>assets/js/jquery1.11.3.min.js"></script>
<script type="text/javascript">
	$('document').ready(function(){
		window.print();
	});
</script>