<style>
    .col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}
    
</style>


<div class="page-title">
  <div class="title_left">
    <h3>Assessment Form</h3>
  </div>

  <!--<div class="title_right">
    <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
      <div class="input-group" style="float: right;">
        <a href="<?php echo base_url(). "facility/assesment"; ?>" id="addBtn" class="btn btn-success disabled pull-right">Add</a>
      </div>
    </div>
  </div>-->
</div>

<div class="clearfix"></div>


<div class="main-content main-content-form-gr-h">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Assessment Summary</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <form id="assesmentForm" name="assesmentForm" role="form" action="<?php echo base_url()."ApiFacility/assesment"?>" method="post">
                
                <?php if(isset($search_options['State']) ){ ?>
                <div class="col-md-4">
                     <div class="form-group">
                    <label> State Name<span class="required"> * </span> </label>
                    <select id="search_state" name="search_state" onchange="change_state()" class="form-control">
                        <option value="">Select State</option>
                        <?php foreach ($search_options['State'] as $key => $value) {  ?>
                        <option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
                        <?php } ?>
                    </select>  
                    </div>                  
                </div>
                <?php } ?>
                <?php if(isset($search_options['District']) ){ ?>
                <div class="col-md-4">
                     <div class="form-group">
                      <label> District Name <span class="required"> * </span> </label>
                    <select id="search_district"  name="search_district" onchange="change_district()" class="form-control">
                        <option value="">Select District</option>
                        <?php foreach ($search_options['District'] as $key => $value) { ?>
                        <option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
                        <?php } ?>
                    </select>  
                    </div>                  
                </div>
                <?php } ?>
                <?php if(isset($search_options['Facility']) || $this->session->userdata('RoleName')=='Facility' ){ ?>
                <div class="col-md-4">
                    <div class="form-group">
                        <label> Name of the Hospital <span class="required"> * </span> </label>
                        <select id="facilityName" name="facilityName" class="form-control"   onchange="changeFacility(this)">
                            <option value="">Select Facility</option>
                        </select>
                    </div>
                </div>
                <?php } ?>
                <div class="col-md-4">
                    <div class="form-group">
                        <label> Assessment Type <span class="required"> * </span> </label>
                        <select name="sequence" id="sequence" class="selectpicker" data-live-search="true" data-width="100%">
                            <option value="1">Base Line</option>
                            <option value="2">Others</option>
                            <option value="3" disabled="disabled">End Line</option>
                        </select>
                    </div>
                </div>            
               
        
                    <!-- <div class="col-md-4">
                        <div class="form-group">
                            <label> Name of the Hospital <span class="required"> * </span> </label>
                            <input type="text" class="form-control" id="facilityName" name="facilityName" placeholder="Hospital name">
                        </div>
                    </div> -->
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> Date of Assessment <span class="required"> * </span> </label>
                            
                                <input minlength="10" maxlength="10" type='text' id="assessmentDate" name="assessmentDate"  placeholder="DD-MM-YYYY" class="form-control datepicker" />
                                <!--<span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>-->
                            
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> Name of Assessor 1<span class="required"> * </span> </label>
                            <input minlength="1" maxlength="100" type="text" id="assessorsName1" name="assessorsName1"  class="form-control" placeholder="Name of Assessor">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> Name of Assessee 1<span class="required"> * </span> </label>
                            <input minlength="1" maxlength="100" type="text" id="assesseesName1" name="assesseesName1" class="form-control" placeholder="Name of assessee">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> Name of Assessor 2</label>
                            <input maxlength="100" type="text" id="assessorsName2" name="assessorsName2"  class="form-control" placeholder="Name of assessor">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> Name of Assessee 2</label>
                            <input maxlength="100" type="text" id="assesseesName2" name="assesseesName2" class="form-control" placeholder="Name of assessee">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> Category of Assessment <span class="required"> * </span> </label>
                            <select name="assessment" id="assessment" class="selectpicker  " data-live-search="true" data-width="100%">
                                <option value="internal"> Internal</option>
                                <option value="peer"> Peer</option>
                                <option value="external"> External</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> Action plan Submission Date <span class="required"> * </span> </label>
                            
                                <input minlength="10" maxlength="10" type='text' id="submissionDate" name="submissionDate" placeholder="DD-MM-YYYY" class="form-control datepicker" />
                                <!--<span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>-->
                            
                        </div>
                    </div>
                    


                    <!-- <div class="col-md-12">
                        <div class="form-group">
                            <label> Service Provided<span class="required"> * </span> </label>
                              <div class="radio">
                                <label>
                                  <input type="radio" class="flat" id="facilityAvailable_1" name="facilityAvailable" value="1" checked="checked"> Labour Room
                                </label>
                              </div>
                              <div class="radio">
                                <label>
                                  <input type="radio" class="flat" id="facilityAvailable_2" name="facilityAvailable" value="2"> Operation Theatre
                                </label>
                              </div>
                              <div class="radio">
                                <label>
                                  <input type="radio" class="flat" id="facilityAvailable_3" name="facilityAvailable" value="3"> Both
                                </label>
                              </div>
                            
                            

                        </div>
                    </div> -->


                    <div class="col-md-12">
                        <div class="form-group">
                            <div class='input-group pull-right'>
                                <input type='hidden' name="SurveyID" id="SurveyID" value="<?php echo $this->uri->segment('3'); ?>" class="" />
                                <input style="margin-top: 15px; margin-right: 0px;" type='submit' id="assesment" name="assesment" value="Next" class="btn btn-info" />
                            </div>
                        </div>
                    </div>                    
                </form>
            </div>
        </div>

            </div>
        </div>
    </div>
</div>