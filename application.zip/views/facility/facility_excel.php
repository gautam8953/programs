<?php //echo "<pre>"; print_r($data['score']); echo "</pre>"; 
ob_start(); ?><table>
  <?php foreach ($data['survey'] as $keySurvey => $valueSurvey) { ?>
    <tr>
      <th colspan="7">Any changes in excel except Compliance may lead to cancled format</th>
    </tr>
    <tr>
      <th colspan="7">National Quality Assurance Standards 2016</th>
    </tr>
    <tr>
      <th colspan="7"><?php echo $valueSurvey['SurveyDesc']; ?></th>
    </tr>
    <tr>
      <th colspan="7">Assessment Summary</th>
    </tr>
    <tr>
      <th colspan="2">Name of the Hospital</th>
      <td colspan="3"><?php echo !empty($data['answersMain']['FacilityName'])?$data['answersMain']['FacilityName']:''; ?></td>
      <th colspan="1">Date of Assessment</th>
      <td colspan="1"><?php echo !empty($data['answersMain']['AssessmentDate'])?convert_date_show($data['answersMain']['AssessmentDate']):''; ?></td>
    </tr>
    <tr>
      <th colspan="2">Names of Assessors</th>
      <td colspan="3"><?php echo !empty($data['answersMain']['AssessorsName1'])?$data['answersMain']['AssessorsName1']:''; ?></td>
      <th colspan="1">Names of Assessees</th>
      <td colspan="1"><?php echo !empty($data['answersMain']['AssesseesName1'])?$data['answersMain']['AssesseesName1']:''; ?></td>
    </tr>
    <tr>
      <th colspan="2">Type of Assessment (Internal/Peer/External)</th>
      <td colspan="3"><?php echo !empty($data['answersMain']['AssessmentType'])?$data['answersMain']['AssessmentType']:''; ?></td>
      <th colspan="1">Action plan Submission Date</th>
      <td colspan="1"><?php echo !empty($data['answersMain']['start_date'])?convert_date_show($data['answersMain']['start_date']):''; ?></td>
    </tr>
    <?php if(!empty($data['score'])){ ?>
    <tr>
      <th colspan="7"><?php echo $valueSurvey['SurveyName']; ?> Score Card</th>
    </tr>
    <tr>
      <th colspan="5">Area of Concern wise Score</th>
      <th colspan="2"><?php echo $valueSurvey['SurveyName']; ?> Score</th>      
    </tr>
    <?php $ansTot=0; $quesTot=0; $cnt=1; 
    foreach ($data['score'] as $key => $value) {
      $ansTot+=$value['answer']; $quesTot+=($value['quesTot']*2);
    }
    foreach ($data['score'] as $key => $value) { ?>
    <tr>
      <td><?php echo $value['CategoryCode']; ?></td>
      <td><?php echo $value['CategoryName']; ?></td>
      <td colspan="3"><?php echo $score=(int)($value['answer']/($value['quesTot']*2)*100); echo '%'; ?></td>
      <?php if($cnt==1){ ?>
      <td valign="middle" colspan="2" rowspan="<?php echo count($data['score']); ?>" ><?php echo (int)(($ansTot/$quesTot)*100).'%'; ?></td>
      <?php $cnt++; } ?>
    </tr>
    <?php } } ?>
    <tr>
      <th></th>
      <th colspan="6">Major Gaps Observed</th>
    </tr>
    <?php $i=0;
    if(!empty($data['remarks']['q1'])){ 
    foreach ($data['remarks']['q1'] as $key => $value) {
    ?>
    <tr>
      <td><?php echo ++$i; ?></td>
      <td colspan="6"><?php echo $value['remarks']; ?></td>
    </tr>
    <?php } } 
    if($i<5){
    for (;$i<5;) { 
      ?>
    <tr>
      <td><?php echo ++$i; ?></td>
      <td colspan="6"></td>
    </tr>
    <?php } } ?>
    <tr>
      <th></th>
      <th colspan="6">Strengths / Good Practices</th>
    </tr>
    <?php $i=0;
    if(!empty($data['remarks']['q2'])){ 
    foreach ($data['remarks']['q2'] as $key => $value) {
    ?>
    <tr>
      <td><?php echo ++$i; ?></td>
      <td colspan="6"><?php echo $value['remarks']; ?></td>
    </tr>
    <?php } } 
    if($i<5){
    for (;$i<5;) { 
      ?>
    <tr>
      <td><?php echo ++$i; ?></td>
      <td colspan="6"></td>
    </tr>
    <?php } } ?>
    <tr>
      <th></th>
      <th colspan="6">Recommendations/ Opportunities for Improvement</th>
    </tr>
    <?php $i=0;
    if(!empty($data['remarks']['q3'])){ 
    foreach ($data['remarks']['q3'] as $key => $value) {
    ?>
    <tr>
      <td><?php echo ++$i; ?></td>
      <td colspan="6"><?php echo $value['remarks']; ?></td>
    </tr>
    <?php } } 
    if($i<5){
    for (;$i<5;) { 
      ?>
    <tr>
      <td><?php echo ++$i; ?></td>
      <td colspan="6"></td>
    </tr>
    <?php } } ?>
      <tr>
        <th>Reference No</th>
        <th>Measurable Elements</th>
        <th>Checkpoint</th>
        <th>Compliance</th>
        <th>Assessment Methods</th>
        <th>Means Of Verification</th>
        <th>Remarks</th>
      </tr>
    <?php foreach ($valueSurvey['category'] as $keyCat => $valueCat) { ?>
      <tr>
        <th colspan="7"><?php echo $valueCat['CategoryCode'].':'.$valueCat['CategoryName']; ?></th>
      </tr>
        <?php foreach ($valueCat['subcategory'] as $keySubCat => $valueSubCat) {  ?>
        <tr>
          <th colspan=""><?php echo $valueSubCat['SubCategoryCode']; ?></th>
          <th colspan="4"><?php echo $valueSubCat['SubCategoryName']; ?></th>
          <th><?php echo $valueSubCat['answerTot']; ?></th>
          <th><?php echo (int)(($valueSubCat['answerTot']/($valueSubCat['questionTot']*2))*100); ?></th>
        </tr>
          <?php foreach ($valueSubCat['questions'] as $keyQues => $valueQues) {  ?>
            <tr>
              <td><?php echo $valueQues['Reference']; ?></td>
              <td><?php echo $valueQues['Statement']; ?></td>
              <td><?php echo $valueQues['Checkpoint']; ?></td>
              <td><?php echo $valueQues['Answer']; ?></td>
              <td><?php echo $valueQues['Assesment']; ?></td>
              <td><?php echo $valueQues['Verification']; ?></td>
              <td><?php echo $valueQues['Remarks']; ?></td>
            </tr><?php  } ?><?php } ?><?php } ?><?php } ?></table>     <?php 
$file = 'format-'.date("Y-M-D")."-".time().'.xls';
 $content = ob_get_contents();
  ob_end_clean();
  header("Expires: 0");
 header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
 header("Cache-Control: no-store, no-cache, must-revalidate");
 header("Cache-Control: post-check=0, pre-check=0", false);
 header("Pragma: no-cache");  header("Content-type: application/vnd.ms-excel;charset:UTF-8");
 header('Content-length: '.strlen($content));
 header('Content-disposition: attachment; filename='.basename($file));
 echo $content;
 exit;
?>