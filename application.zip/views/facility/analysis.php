<div class="page-title">
  <div class="title_left">
    <h3>Gap Analysis</h3>
  </div>

  
</div>

<div class="clearfix"></div>

<div class="main-content GapAnalysis"> 
    <div class="container">	  
    <div class="row">
    		
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Gap Analysis</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">

 
 
        
	    	<?php if(!empty($search_options)){ ?>	   
	        <div class="col-md-12">
	        	<div class="row mar-bottom30">
	        	<?php if(!empty($search_options['cat'])){ ?>
                <div class="col-md-4 col-xs-12 mar-top-20">
                	<select id="search_cat" name="search_cat" onchange="getData()" class="form-control search_cat selectpicker" multiple title="Pick your condiments" data-live-search="true">
						<option value="">Select Category</option>
						<?php foreach ($search_options['cat'] as $key => $value) { ?>
						<option value="<?php echo $value['CategoryCode']; ?>" ><?php echo $value['CategoryCode'].' - '.$value['CategoryName']; ?></option>
						<?php } ?>
					</select>                    
                </div>
            	<?php } ?>
                <div class="col-md-4 col-xs-12 mar-top-20">
                	<select id="search_score" name="search_score" onchange="getData()" class="form-control search_cat selectpicker" multiple title="Pick your condiments" data-live-search="true" >
						<option value="">Select Score</option>
						<option value="0" >Score-0</option>
						<option value="1" >Score-1</option>
						<option value="2" >Score-2</option>
					</select>                    
                </div>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<input type="hidden" name="search_format" id="search_format" value="<?php echo empty($search_format)?'':encryptor($search_format); ?>" >
                	<input type="hidden" name="search_answer" id="search_answer" value="<?php echo empty($search_answer)?'':encryptor($search_answer); ?>" >
                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" style="display: none;" />
                    <a href="javascript:void(0)" id="reset_btn" class="btn btn-primary">Reset</a>
                </div>
            </div>
            <hr>            	
	        </div>
	    	<?php } ?>
		
			      
			      <table id="datatable" class="table table-striped table-bordered">
			        <thead>
			            <tr>
			                <th>Area of Concern</th>
			                <th>Standard</th>
			                <th>ME Statement</th>
			                <th>CheckPoint</th>
			                <th>Score</th>
			            </tr>
			            </thead>
			            <tbody>
			            	<tr>
			            		<td></td>
			            		<td></td>
			            		<td></td>
			            		<td></td>
			                	<td></td>
			            	</tr>
			            </tbody>
			      </table>
			    </div>
			  </div>
			</div>
		</div>        
    </div>
</div>

