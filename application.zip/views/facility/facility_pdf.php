 
<style>
body {
  margin: 0px;
  box-sizing: border-box;
  position: relative;
  font-family: sans-serif;
  font-size: 10px;
  line-height:10px;

}

table{width: 100%;}

span.title {
  font-weight: 600;
  margin-bottom: 3px;
  display: block;
}

tr {
  list-style: none;
  padding: 0;
  margin: 0px 0px;
}
td {
  vertical-align: top;
  padding: 0px 10px;
  font-size: 10px;
}

h1 {margin-bottom: 40px; text-align: center; font-weight: 400; }
h2 {width: 100%;
  font-size: 12px;
  margin-top: 20px;
  font-weight: 600;}

  h3 { margin: 0; width: 100%;
   font-weight: 600;}
   p {    width: 100%;
    font-size: 10px;
    float: left; padding: 0px 10px;}
    header{border: none;}    

  </style>
    

    <table cellpadding="5" cellspacing="0"   align="center" style="border-bottom:2px solid #344c98 ">
    <tr class="heading" >
      <td valign="middle" align="left" cellpadding="20" >
        <br><br><br>
        <img src="<?php echo base_url();?>/assets/images/laqshya-logo-pdf.png" style="width:120px; margin-top: 20px" ></td>
        <td valign="middle" style="text-align: center"><img src="<?php echo base_url();?>/assets/images/Emblem_of_India.svg" style="height:75px"></td> 
        <td valign="middle" align="right" style="font-size:9px" ><b style="font-size:14px"><br>LaQshya  </b><br>
          Ministry of Health and <br>
          Family Welfare (MoHFW) <br>
        Government of India</td>

      </tr>

    </table>
    <br><br>
  
      <?php foreach ($data['survey'] as $keySurvey => $valueSurvey) { ?>
          <table cellpadding="5" cellspacing="0">
              <tr class="heading" >
                <td style="font-size:12px; text-align: center; color: #888;"> <b>National Quality Assurance Standards 2016 </b> </td> 

              </tr>

            </table> 
            <table cellpadding="5" cellspacing="0"  bgcolor="#eaf1f7">
              <tr class="heading" >
                <td style="font-size:13px; text-align: center; color: #344c98;"> <b><?php echo $valueSurvey['SurveyDesc']; ?></b>
                </td> 

              </tr>

            </table>

            <table cellpadding="5" cellspacing="0">
              <tr class="heading" >
                <td style="font-size:12px; text-align: center; color: #888;">Assessment Summary </td> 

              </tr>

            </table>
            <br>
            <br>


            <table cellpadding="5" cellspacing="0">
                <tr class="heading">
                  <td style="font-size:10px">
                    <br><b>Name of the Hospital :</b><?php echo !empty($data['answersMain']['FacilityName'])?$data['answersMain']['FacilityName']:''; ?>
                     <br><b>Date of Assessment :</b><?php echo !empty($data['answersMain']['AssessmentDate'])?convert_date_show($data['answersMain']['AssessmentDate']):''; ?>
                    <br><b>Action plan Submission Date:</b> <?php echo !empty($data['answersMain']['start_date'])?convert_date_show($data['answersMain']['start_date']):''; ?>
                    <br><b>(Internal/Peer/External)</b>
                  </td>

                  <td style="font-size:10px; text-align: right">
                   
                    <br><b>Names of Assessors:</b> <?php echo !empty($data['answersMain']['AssessorsName1'])?$data['answersMain']['AssessorsName1']:''; ?>
                    <br><b>Names of Assessees:</b> <?php echo !empty($data['answersMain']['AssesseesName1'])?$data['answersMain']['AssesseesName1']:''; ?>
                    <br><b>Type of Assessment :</b> <?php echo !empty($data['answersMain']['AssessmentType'])?$data['answersMain']['AssessmentType']:''; ?>  
                    

                  </td>

                </tr>

              </table>
              <br><br>

      <?php if(!empty($data['score'])){ ?>
              <table cellpadding="0" cellspacing="0">
      <tr class="heading">
        <td colspan="2" style="font-size:12px; text-align: center; color: #888;"><?php echo $valueSurvey['SurveyName']; ?> Score Card <br></td>
      </tr>
      <tr>

        <td>

          <table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff" class="score-border">
            <tr class="heading" bgcolor="#e1e8ff">
              <td colspan="3" style="font-size:12px; text-align: center; color: #0c0c0c;">Area of Concern wise Score</td>
            </tr>
            <?php $ansTot=0; $quesTot=0; $cnt=1; 
          foreach ($data['score'] as $key => $value) {
            $ansTot+=$value['answer']; $quesTot+=($value['quesTot']*2);
          }
          foreach ($data['score'] as $key => $value) { ?>

              <tr>
                <td width="10%"><?php echo $value['CategoryCode']; ?></td>
                <td width="60%"><?php echo $value['CategoryName']; ?></td>
                <td width="30%"><?php echo $score=(int)($value['answer']/($value['quesTot']*2)*100); echo '%'; ?></td>
              </tr>
            <?php } ?>
          </table>

        </td>
        <td>

          <table cellpadding="10" cellspacing="0" bgcolor="#fbe1cb" >
            <tr class="heading" >
              <td style="font-size:12px; text-align: center; color: #0c0c0c;"><?php echo $valueSurvey['SurveyName']; ?> Score</td>
            </tr>
            <tr>
              <td style="height: 170px; font-weight: bold; text-align: center; font-size:30px;">
                <br><br>
              <?php echo (int)(($ansTot/$quesTot)*100).'%'; ?></td>
            </tr>

          </table>

        </td>
      </tr>

    </table>
    <br><br>

     <?php }  ?>
 



  <table cellpadding="0" cellspacing="0">
      <tr>
        <td colspan="2">

          <table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff; line-height: 100%;  " class="score-border">
            <tr class="heading" bgcolor="#e1e8ff">
              <td colspan="2" style="font-size:12px; text-align: center; color: #0c0c0c;">Major Gaps Observed</td>
            </tr>

            <?php $i=0;
            if(!empty($data['remarks']['q1'])){ 
              foreach ($data['remarks']['q1'] as $key => $value) {
                ?> 
            <tr>
              <td width="10%" style="font-size: 8px ; text-align: center;"><?php echo ++$i; ?></td>
              <td width="90%" style="font-size: 8px ; text-align: left;" ><?php echo $value['remarks']; ?></td>
            </tr> 
            <?php } } 
              if($i<5){
                for (;$i<5;) { 
                  ?>

                  <tr>
              <td width="10%" style="font-size: 8px ; text-align: center;"><?php echo ++$i; ?></td>
              <td width="90%" style="font-size: 8px ; text-align: left;"></td>
            </tr>

            <?php } } ?>
            

          </table>
        </td>
      </tr>

    </table>

<br><br> 
<table cellpadding="2" cellspacing="0">
      <tr>
        <td colspan="2">

          <table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff" class="score-border">
            <tr class="heading" bgcolor="#e1e8ff">
              <td colspan="2" style="font-size:12px; text-align: center; color: #0c0c0c;">Strengths / Good Practices</td>
            </tr>
            <?php $i=0;
                if(!empty($data['remarks']['q2'])){ 
                  foreach ($data['remarks']['q2'] as $key => $value) {
                    ?>

                  <tr>
                    <td width="10%" style="font-size: 8px ; text-align: center;"><?php echo ++$i; ?></td>
                    <td width="90%" style="font-size: 8px ; text-align: left;"><?php echo $value['remarks']; ?></td>
                  </tr>

                  <?php } } 
                  if($i<5){
                    for (;$i<5;) { 
                      ?>

                  <tr>
                    <td width="10%" style="font-size: 8px ; text-align: center;"><?php echo ++$i; ?></td>
                    <td width="90%" style="font-size: 8px ; text-align: left;"></td>
                  </tr>


            <?php } } ?>
             
          </table>
        </td>
      </tr>

    </table>
    <br><br>


    <table cellpadding="0" cellspacing="0">
      <tr>
        <td colspan="2">

          <table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff" class="score-border">
            <tr class="heading" bgcolor="#e1e8ff">
              <td colspan="2" style="font-size:12px; text-align: center; color: #0c0c0c;">Recommendations/ Opportunities for Improvement</td>
            </tr>

             <?php $i=0;
                    if(!empty($data['remarks']['q3'])){ 
                      foreach ($data['remarks']['q3'] as $key => $value) {
                        ?> 
                          <tr>
                            <td width="10%" style="font-size: 8px ; text-align: center;"><?php echo ++$i; ?></td>
                            <td width="90%" style="font-size: 8px ; text-align: left;"><?php echo $value['remarks']; ?></td>
                          </tr>

                          <?php } } 
                                    if($i<5){
                                      for (;$i<5;) { 
                                        ?>
 
                          <tr>
                            <td width="10%" style="font-size: 8px ; text-align: center;"><?php echo ++$i; ?></td>
                            <td width="90%" style="font-size: 8px; text-align: left;"></td>
                          </tr>
            <?php } } ?>


            
          </table>
        </td>
      </tr>

    </table>

    <br>
    <br>


    <table cellpadding="0" cellspacing="0">
    
    <?php foreach ($valueSurvey['category'] as $keyCat => $valueCat) { ?>
    <tr>
        <td colspan="2">
            <table cellpadding="0" cellspacing="0" style="border: 1px solid #e1e8ff">
              <tr  bgcolor="#3957a5">
                <td>
                    <table cellpadding="5" cellspacing="0">
                        <tr>
                           <td style="font-size:12px; text-align: left; color: #fff; padding: 10px" width="100%; "><?php echo $valueCat['CategoryCode'].': '.$valueCat['CategoryName']; ?> </td>
                          
                        </tr>

                    </table>
                </td>
            </tr>
            <?php foreach ($valueCat['subcategory'] as $keySubCat => $valueSubCat) {  ?>
                <tr>
                  <td colspan="2"><table cellpadding="0" cellspacing="0">
                            <tr bgcolor="#12c3f5">
                                <td>
                                    <table cellpadding="5" cellspacing="0">
                                        <tr>
                                           <td style="font-size:10px; text-align: left; color: #0c0c0c; padding: 10px" width="60%"><b><?php echo $valueSubCat['SubCategoryCode']; ?> : </b><?php echo $valueSubCat['SubCategoryName']; ?></td>
                                           <td style="font-size:12px; text-align: right; color: #0c0c0c; padding: 10px;" width="20%">Score: <?php echo $valueSubCat['answerTot']; ?></td>
                                          <td style="font-size:12px; text-align: right; color: #0c0c0c; padding: 10px;" width="20%">Remarks: <?php echo (int)(($valueSubCat['answerTot']/($valueSubCat['questionTot']*2))*100); ?></td>
                                        </tr>

                                    </table>
                                </td>
                            </tr>
                            
                              <tr>
                                  <td><table cellpadding="5" cellspacing="0"> 
                                      		<!-- <tr  bgcolor="#c9f0fb" >
                                              <td>
                                              ME A1.14 - Services are available for the time period as mandated
                                            </td>
                                          </tr> -->
                                          <tr>
                                              <td><table cellpadding="5" cellspacing="0">
					                                        <?php foreach ($valueSubCat['questions'] as $keyQues => $valueQues) {  ?>
                                                    <?php if(!empty($valueQues['Reference']) && !empty($valueQues['Statement'])){ $k=1; ?>
                                                    <tr  bgcolor="#c9f0fb" >
                                                      <td colspan="3"><?php if(isset($valueQues['Reference']) && !empty($valueQues['Reference'])){ echo $valueQues['Reference']; } ?> - <?php if(isset($valueQues['Statement']) && !empty($valueQues['Statement'])){  echo $valueQues['Statement'];  } ?>
                                                      </td>                                          
                                                    </tr>                                             
                                                    <?php  } ?>
					                                          <tr>
					                                              <td width="5%"><?php echo $k++; ?></td>
					                                              <td width="78%"><strong><?php echo $valueQues['Reference']; ?> <?php echo $valueQues['Checkpoint']; ?></strong><br><span style="font-size:8px; color: #848484;"><strong>Assesment method:</strong> <?php echo $valueQues['Assesment']; ?><br><strong>Verification: </strong><?php echo $valueQues['Verification']; ?></span>
					                                              </td>
					                                              <td width="17%">Compliance: <?php echo $valueQues['Answer']; ?></td> 
					                                          </tr>
					                                           <?php } ?>
					                                        

					                                      </table>

                                              </td>
                                               
                                          </tr>
                                          

                                      </table>
                                  </td>
                              </tr>
                           
                        </table>
                    </td>
                </tr>
                <?php } ?>
            </table>
        </td>
    </tr>
    <?php } ?>
</table>
  


        <!---- old code below --------->
          
         <table>
        
            
 
 






                        <tr>
                          <th>Reference No</th>
                          <th>Measurable Elements</th>
                          <th>Checkpoint</th>
                          <th>Compliance</th>
                          <th>Assessment Methods</th>
                          <th>Means Of Verification</th>
                          <th>Remarks</th>
                        </tr>
                        <?php foreach ($valueSurvey['category'] as $keyCat => $valueCat) { ?>
                          <tr>
                            <th colspan="7"><?php echo $valueCat['CategoryCode'].':'.$valueCat['CategoryName']; ?></th>
                          </tr>
                          <?php foreach ($valueCat['subcategory'] as $keySubCat => $valueSubCat) {  ?>
                            <tr>
                              <th colspan=""><?php echo $valueSubCat['SubCategoryCode']; ?></th>
                              <th colspan="4"><?php echo $valueSubCat['SubCategoryName']; ?></th>
                              <th><?php echo $valueSubCat['answerTot']; ?></th>
                              <th><?php echo (int)(($valueSubCat['answerTot']/($valueSubCat['questionTot']*2))*100); ?></th>
                            </tr>
                            <?php foreach ($valueSubCat['questions'] as $keyQues => $valueQues) {  ?>
                              <tr>
                                <td><?php echo $valueQues['Reference']; ?></td>
                                <td><?php echo $valueQues['Statement']; ?></td>
                                <td><?php echo $valueQues['Checkpoint']; ?></td>
                                <td><?php echo $valueQues['Answer']; ?></td>
                                <td><?php echo $valueQues['Assesment']; ?></td>
                                <td><?php echo $valueQues['Verification']; ?></td>
                                <td><?php echo $valueQues['Remarks']; ?></td>
                                </tr><?php  } ?><?php } ?><?php } ?>
</table>

                              <?php } ?>
                              