<div class="page-title">
  <div class="title_left">
    <h3>Assessment Form</h3>
  </div>

  <div class="title_right">
    <!---<div class="col-md-12 col-sm-12 col-xs-12 form-group pull-right top_search">--->
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="input-group" style="float: right;">
        <a style="margin: 10px 10px;" href="<?php echo base_url(). "facility/surveySampleDownload/1"; ?>" class="btn btn-info pull-right">Download LR Format</a><a href="<?php echo base_url(). "facility/surveySampleDownload/2"; ?>" class="btn btn-info pull-right">Download OT Format</a>
      </div>
    </div>
  </div>
</div>

<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">
    <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Assessment Import</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">  
        <?php 
        $attr = array("class" => "form-horizontal", "role" => "form", "id" => "uploaForm", "name" => "uploaForm");
        echo form_open("ApiFacility/excelupload", $attr); ?>
	    <div class="row">
                <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label> Date of Assessment <span class="required"> * </span> </label>                        
                            <input type='text' id="assessmentDate" name="assessmentDate"  placeholder="DD-MM-YYYY" class="form-control datepicker" value="<?php //echo date('dd-mm-Y') ?>" />                        
                    </div>
                </div>
            	<?php if(isset($search_options['State']) ){ ?>
                <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label> State <span class="required"> * </span> </label>
                        <select id="search_state" name="search_state" onchange="change_state()" class="form-control">
						<option value="">Select State</option>
						<?php foreach ($search_options['State'] as $key => $value) {  ?>
						<option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
						<?php } ?>
						</select>
					</div>
                </div>
                <?php } ?>
                <?php if(isset($search_options['District']) ){ ?>
                <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label> District <span class="required"> * </span> </label>                    
                	<select id="search_district" name="search_district" onchange="change_district()" class="form-control">
						<option value="">Select District</option>
						<?php foreach ($search_options['District'] as $key => $value) { ?>
						<option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
						<?php } ?>
					</select>                    
				</div>
                </div>
                <?php } ?>
                <?php if(isset($search_options['Facility']) ){ ?>
                <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label> Facility <span class="required"> * </span> </label>
                	<select id="search_facility" name="search_facility" class="form-control">
						<option value="">Select Facility</option>
					</select>                    
				</div>
                </div>
                <?php } ?>
                <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label> Assessment Form <span class="required"> * </span> </label>
                        <select name="survey" id="survey" class="form-control  " >
                            <option value="1">Labour Room </option>
                            <option value="2">Operation Theatre</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label> Assessment Type <span class="required"> * </span> </label>
                        <select name="surveyType" id="surveyType" class="form-control  " >
                            <option value="1">Base Line</option>
                            <option value="2">Others</option>
                            <option value="3">End Line</option>
                        </select>
                    </div>
                </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessor 1<span class="required"> * </span> </label>
                            <input minlength="1" maxlength="100" type="text" id="assessorsName1" name="assessorsName1"  class="form-control" placeholder="Name of Assessor">
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessee 1<span class="required"> * </span> </label>
                            <input minlength="1" maxlength="100" type="text" id="assesseesName1" name="assesseesName1" class="form-control" placeholder="Name of assessee">
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessor 2</label>
                            <input maxlength="100" type="text" id="assessorsName2" name="assessorsName2"  class="form-control" placeholder="Name of assessor">
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessee 2</label>
                            <input maxlength="100" type="text" id="assesseesName2" name="assesseesName2" class="form-control" placeholder="Name of assessee">
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="form-group">
                            <label> Category of Assessment <span class="required"> * </span> </label>
                            <select name="assessment" id="assessment" class="selectpicker  " data-live-search="true" data-width="100%">
                                <option value="internal"> Internal</option>
                                <option value="peer"> Peer</option>
                                <option value="external"> External</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="form-group">
                            <label> Action plan Submission Date </label>
                                <input minlength="10" maxlength="10" type='text' id="submissionDate" name="submissionDate" placeholder="DD-MM-YYYY" class="form-control datepicker" />
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="form-group">
                            <label> Checklist Format </label>
                            <select id="checklist_format" name="checklist_format" class="form-control">
                                <option value="A">Format A</option>
                                <option value="B">Format B</option>
                            </select>
                        </div>
                    </div>

                <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label>Choose Excel File <span class="required"> * </span> </label>
                        <br>
                        <input type="file" id="excelfile" name="excelfile" accept=".csv,.xls,.xlsx" onchange="checkFile(this)" class="inputfile inputfile-6 form-control" data-multiple-caption="{count} files selected" />
                    <label for="excelfile"><span></span> <strong><i class="fa fa-upload"></i> Choose a file&hellip;</strong></label>
                        
                        
                    </div>
                </div>
                <div class="col-md-12 col-xs-12">
                    <div class="col-md-2" style="float: right; margin-top: 10px;">
                    	<input type='submit' name="btn_upload" value="Upload" class="form-control btn btn-info" />
                    </div>
                </div>
	    </div>
		<?php echo form_close(); ?>
          <div class="row">
            <div class="col-md-12 errDivUpload">
              
            </div>
          </div>
    </div>
</div>
</div>
</div>
</div>
</div>