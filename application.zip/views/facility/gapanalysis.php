<div class="page-title">
  <div class="title_left">
    <h3>Score  Analysis  </h3>
  </div>

  
</div>

<div class="clearfix"></div>

<div class="main-content GapAnalysis"> 
    <div class="container">	  
    <div class="row">
    		<div class="col-md-12 col-sm-12 col-xs-12">
	        	<div class="x_panel">
	                <div class="x_title">
	                        <h2>Assessment Summary</h2>
	                        <ul class="nav navbar-right panel_toolbox">
	                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
	                        </ul>
	                        <div class="clearfix"></div>
	                </div>
	                <div class="x_content">
	                	<div class="col-md-12 col-sm-12 col-xs-12">
	                		<div class="top-list-new-1">
	                			<!--one-->
	                			<div class="new0car-n1">

	                				<?php foreach ($data['cat'] as $key => $value) { ?>
									<div class="card">
									    <div class="card-header card-header-primary">
									        <h4 class="card-title"><?php echo $key.'-'.$value['categoryName']; ?></h4>
									    </div>
									    <div class="card-body table-responsive">
									        <table class="table table-hover">
									            <tbody>
									            	<tr class="car-head-number1">
									                    <td>Score</td>
									                    <td>Count</td>
									                </tr>
									                <?php foreach ($value['data'] as $key1 => $value1) { ?>
									                <tr>
									                    <td><?php echo 'Score-'.$key1; ?></td>
									                    <td><?php echo $value1; ?></td>
									                </tr>
									                <?php } ?>
									            </tbody>
									        </table>
									    </div>
									</div>
									<?php } ?>

	                			</div>
	                		</div>

	                    </div>
	                    <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px;">
	                    	<div class="col-md-3 col-sm-4 col-xs-6" >
	                    		<strong>Score-0 :</strong>
	                    		<?php 
								$sum = 0;
								foreach ($data['cat'] as $item) {
								    $sum += $item['data'][0];
								} echo $sum; ?>
	                    	</div>
	                    	<div class="col-md-3 col-sm-4 col-xs-6" >
	                    		<strong>Score-1 :</strong>
	                    		<?php 
								$sum = 0;
								foreach ($data['cat'] as $item) {
								    $sum += $item['data'][1];
								} echo $sum; ?>
	                    	</div>
	                    	<div class="col-md-3 col-sm-4 col-xs-6" >
	                    		<strong>Score-2 :</strong>
	                    		<?php 
								$sum = 0;
								foreach ($data['cat'] as $item) {
								    $sum += $item['data'][2];
								} echo $sum; ?>
	                    	</div>
	                    </div> 
	                </div>
	        	</div>
    		</div>
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Score  Analysis </h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">

 
 
        
	    	<?php if(!empty($search_options)){ ?>	   
	        <div class="col-md-12">
	        	<div class="row mar-bottom30">
	        	<?php if(!empty($search_options['cat'])){ ?>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_cat" name="search_cat" onchange="getData()" class="form-control search_cat selectpicker" multiple title="Pick your condiments" data-live-search="true">
						<option value="" selected="selected">Select Category</option>
						<?php foreach ($search_options['cat'] as $key => $value) { ?>
						<option value="<?php echo $value['CategoryCode']; ?>" ><?php echo $value['CategoryCode'].' - '.$value['CategoryName']; ?></option>
						<?php } ?>
					</select>                    
                </div>
            	<?php } ?>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_score" name="search_score" onchange="getData()" class="form-control search_cat selectpicker" multiple title="Pick your condiments" data-live-search="true" >
						<option value="" selected="selected">Select Score</option>
						<option value="0" >Score-0</option>
						<option value="1" >Score-1</option>
						<option value="2" >Score-2</option>
					</select>                    
                </div>
                <div class="col-md-6 col-xs-12 mar-top-20">
                	<input type="hidden" name="search_format" id="search_format" value="<?php echo empty($search_format)?'':encryptor($search_format); ?>" >
                	<input type="hidden" name="search_answer" id="search_answer" value="<?php echo empty($search_answer)?'':encryptor($search_answer); ?>" >
                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" style="display: none;" />
                    <a href="javascript:void(0)" id="reset_btn" class="btn btn-primary">Reset</a>
                   <?php 
                   if ($gap_uploaddata[0]['filename']=='') {
                       $uploaddata='Action_Plan__LR_OT.xlsx';
                   }else{
                   	  $uploaddata=$gap_uploaddata[0]['filename'];
                   }
                   	?>
			       	 <a href="<?php echo base_url();?>assets/uploads/gapfile/<?php echo $uploaddata;?>" id="action_plan" class="btn btn-primary">Download Action Plan</a>
                    <a href="javascript:void(0)" id="upload_action_plan" data-toggle="modal" data-target="#clientScoreModal" class="btn btn-primary">Upload Action Plan</a>
                </div>
            </div>
            <hr>            	
	        </div>
	    	<?php } ?>
		
			      
			      <table id="datatable" class="table table-striped table-bordered">
			        <thead>
			            <tr>
			                <th>Area of Concern</th>
			                <th>Standard</th>
			                <th>ME Statement</th>
			                <th>CheckPoint</th>
			                <th>Score</th>
			            </tr>
			            </thead>
			            <tbody>
			            	<tr>
			            		<td></td>
			            		<td></td>
			            		<td></td>
			            		<td></td>
			                	<td></td>
			            	</tr>
			            </tbody>
			      </table>
			    </div>
			  </div>
			</div>
		</div>        
    </div>
</div>

<!-- modal window start  -->
<div id="clientScoreModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-md">

    <!-- Modal content-->
    <div class="modal-content">
    	<button type="button" class="close pull-right" data-dismiss="modal">&times;</button>
              <div class="panel-body">
                <div class="text-center">
                  <h3>Upload Action Plan</h3>
                  
                  
                  <div class="panel-body">
                    <?php
                     $attr = array("class" => "form-horizontal", "role" => "form", "id" => "uploaForm", "name" => "uploaForm");
                     echo form_open("ApiFacility/actionplanexcelupload", $attr); ?>
                      <div  class=col-md-12">
                          <div class="col-md-8 col-xs-12 mar-top-20">
	                        <div class="form-group">
	                         <div class="input-group">
	                     
	                        <input type="file" id="excelfile" name="excelfile" accept=".csv,.xls,.xlsx" onchange="checkFile(this)" class="inputfile inputfile-6 form-control" data-multiple-caption="{count} files selected" />

	                          <label for="excelfile"><span id="excelfiletext"></span> <strong><i class="fa fa-upload"></i> Choose a file&hellip;</strong></label>
	                        </div>
	                        
	                       </div>
                        </div>
	                     <div class="col-md-4 col-xs-12 mar-top-20">
	                   
	                            <input type="submit" name="btn_upload" value="Upload" class="form-control btn btn-info">
	                        </div>
	                     </div>
                   
                      
                     <?php echo form_close(); ?>
                     
                  </div>
                </div>
              </div>

 
 
    </div>

  </div>
</div>

<!-- modal window end  -->
