<style>

    table thead tr th {background: #337ab7;
                        border: 1px solid #024f92 !important;
                        color: #ffffff;}

</style>

<div class="page-title">
    <div class="title_left">
        <h3>Report</h3>
    </div>
 
</div>


<div class="main-content"> 
    <div class="container">

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel" >
                    <div class="x_title">
                        <h2>Monthly Report</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                            <!--<li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Settings 1</a>
                                </li>
                                <li><a href="#">Settings 2</a>
                                </li>
                              </ul>
                            </li>-->
                            <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                            </li>-->
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">

                        <!--<h4>Search Monthly Report</h4>-->
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <?php
                            $attr = array("class" => "form-horizontal", "role" => "form", "id" => "form1", "name" => "form1");
                            echo form_open("monthly/data", $attr);
                            ?>

<?php if (isset($search_options['State'])) { ?>
                                <div class="row">
                                    <!--<h4>Search Monthly Report</h4>-->
                                    <div class="col-md-4 col-sm-6 col-xs-12 mar-top-20">
                                        <select id="search_state" name="search_state" onchange="change_state()" class="form-control">
                                            <option value="">Select State</option>
                                            <?php foreach ($search_options['State'] as $key => $value) { ?>
                                                <option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
    <?php } ?>
                                        </select>                    
                                    </div>
                                <?php } ?>
<?php if (isset($search_options['District'])) { ?>
                                    <div class="col-md-4 col-sm-6 col-xs-12 mar-top-20">
                                        <select id="search_district" name="search_district" onchange="change_district()" class="form-control">
                                            <option value="">Select District</option>
                                            <?php foreach ($search_options['District'] as $key => $value) { ?>
                                                <option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
    <?php } ?>
                                        </select>                    
                                    </div>
                                <?php } ?>
<?php if (isset($search_options['Facility'])) { ?>
                                    <div class="col-md-4 col-sm-6 col-xs-12 mar-top-20">
                                        <select id="search_facility" name="search_facility" class="form-control">
                                            <option value="">Select Facility</option>
                                        </select>                    
                                    </div>
<?php } ?>
                                <div class="col-md-4 col-sm-6 col-xs-12 mar-top-20">
                                    <select id="search_months" name="search_months" class="selectpicker  " data-live-search="true" data-width="100%">
                                        <option value=""> Select Month</option>
                                        <?php foreach ($this->config->item('months') as $key => $value) { ?>
                                            <option value="<?php echo $key; ?>" <?php //if($key==date('m')){ echo 'selected="selected"'; } ?> ><?php echo $value; ?></option>
<?php } ?>
                                    </select>
                                </div>


                                <div class="col-md-4 col-sm-6 col-xs-12 mar-top-20">
                                    <select id="search_years" name="search_years" class="selectpicker  " data-live-search="true" data-width="100%">
                                        <option value=""> Select Year</option>
                                        <?php foreach ($this->config->item('years') as $key => $value) { ?>
                                            <option value="<?php echo $key; ?>" <?php //if($key==date('Y')){ echo 'selected="selected"'; } ?> ><?php echo $value; ?></option>
<?php } ?>
                                    </select>
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12 mar-top-20">
                                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" />
                                    <a href="javascript:void(0)" class="btn btn-primary" id="reset_btn">Reset</a>
                                </div>
                            </div>
<?php echo form_close(); ?>

                            <div class="clear"></div>
                            <hr>
                            <!-- <button style="margin: -40px 10px;" class="btn btn-success pull-right" onclick="showAddModel()" >Add</button> -->
                            <!-- <a href="<?php //echo base_url(). "monthly/add";  ?>" id="addBtn" class="btn btn-success disabled pull-right">Add</a> -->
                        </div>
                        <div class="over-hid1">


                        <table id="datatable" class="table table-striped table-bordered my-table-width" width="100%">
                            <thead>
                                <tr>
                                    <th data-toggle="tooltip" title="SN.">SN.</th>
                                    <?php if (isset($search_options['State'])) { ?><th  data-toggle="tooltip" title="State Name ">State Name</th><?php } ?>
                                    <?php if (isset($search_options['District'])) { ?><th data-toggle="tooltip" title="District Name ">District Name</th><?php } ?>
                                    <?php if (isset($search_options['Facility'])) { ?><th data-toggle="tooltip" title="Facility Name ">Facility Name</th><?php } ?>
                                    <th data-toggle="tooltip" title="Criterion I - Overall Score of the department (LR / OT shall be ≥70%">Month</th>
                                    
                                    <th data-toggle="tooltip" title="Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores">Indicator 1</th>

                                    <th data-toggle="tooltip" title="Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots">Indicator 2</th>
                                    
                                    <th data-toggle="tooltip" title="Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI">Indicator 3</th>
                                    
                                    <th data-toggle="tooltip" title="Percentage of deliveries are attended by a birth companion">Indicator 4</th>
                                    
                                    <th data-toggle="tooltip" title="Percentage deliveries are conducted using safe birth checklist in Labour Room">Indicator 5 </th>
                                    
                                    <th data-toggle="tooltip" title="Percentage of deliveries are conducted using  Safe Surgery checklist in Maternity OT">Indicator 6</th>
                                    
                                    <th data-toggle="tooltip" title="Percentage of deliveries for which Partograph is generated using real-time information in at least">Indicator 7</th>
                                    
                                    <th  data-toggle="tooltip" title="Percentage breastfeeding within 1 hour">Indicator 8 </th>
                                    
                                    <th data-toggle="tooltip" title="Neonatal asphyxia rate in Inborn Babies">Indicator 9 </th>
                                    
                                    <th data-toggle="tooltip" title="Neonatal sepsis rate in-born babies"> Indicator 10 </th>
                                    
                                    <th data-toggle="tooltip" title="Surgical Site infection Rate in Maternity OT"> Indicator 11</th>
                                    
                                    <th data-toggle="tooltip" title="Antenatal corticosteroid administration rate in case in preterm labour">  Indicator 12</th>
                                    
                                    <th data-toggle="tooltip" title="Pre-eclampsia, eclampsia & PIH related mortality">Indicator 13</th>
                                    
                                    <th data-toggle="tooltip" title="APH/PPH related mortality"> Indicator 14 </th>
                                    
                                    <th data-toggle="tooltip" title="Facility Labour Room is reorganized as labour room standardization guidelines">Indicator 15 </th>
                                    
                                    <th data-toggle="tooltip" title="Facility Labour room has staffing as per defined norms">Indicator 16 </th>
                                    
                                    <th  data-toggle="tooltip" title="Percentage of Women, administered Oxytocin, immediately after birth.">Indicator 17</th>
                                    
                                    <th style="min-width: 100px;" title="OSCE Score">Indicator 18 </th>
                                    
                                    <th title="Facility conducts referral audit on Monthly basis">Indicator 19</th>
                                    
                                    <th data-toggle="tooltip" title="Facility conducts Maternal death, Neonatal death and near-miss on monthly basis">Indicator 20</th>
                                    
                                    <th data-toggle="tooltip" title="Facility report zero stock outs in Labour Room & Maternity OT">Indicator 21</th>
                                    
                                    <th style="min-width: 120px;" title="Still Birth Rate"> Indicator 22 </th>
                                    
                                    <th data-toggle="tooltip" title="Percentage of beneficiaries  who were either satisfied or highly satisfied">Indicator 23</th>
                                    
                                    <th data-toggle="tooltip" title="functional Obs ICU/Hybrid ICU/HDU?">Indicator 24</th>
                                    
                                    <th data-toggle="tooltip" title="Microbiological Surveillance in OT & LR">Indicator 25 </th>
                                    
                                    <th data-toggle="tooltip" title="Labour Room Quality Score Improvement from Baseline">Indicator 26 </th>
                                    
                                    <th  data-toggle="tooltip" title="Maternity OT Quality Score Improvement from Baseline"> Indicator 27 </th>

                                     <th  data-toggle="tooltip" title="Percentage of deliveries conducted at night"> Indicator 28 </th>

                                    <th  data-toggle="tooltip" title="Percentage of C - section conducted at night"> Indicator 29 </th>

                                    <th  data-toggle="tooltip" title="Percentage of elective C - section"> Indicator 30 </th>

                                    <th  data-toggle="tooltip" title="Percentage of newborn required resuscitation out of total live birth"> Indicator 31 </th>

                                    <th  data-toggle="tooltip" title="Percentage of cases referred to Maternity OT"> Indicator 32 </th>

                                    <th  data-toggle="tooltip" title="Percentage of complicated cases managed"> Indicator 33 </th>

                                    <th  data-toggle="tooltip" title="Percentage PPIUCD inserted against total number of deliveries"> Indicator 34 </th>

                                    <th  data-toggle="tooltip" title="Operation cancellation rate"> Indicator 35 </th>

                                    <th  data-toggle="tooltip" title="Perioperative death rate"> Indicator 36 </th>

                                    <th  data-toggle="tooltip" title="Number of adverse event per 1000 patient"> Indicator 37 </th>
                                    <!--<th width="70px">Action</th>-->
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>

  
                    </div>
                    </div>
                    
                </div>
            </div>
        </div>

    </div>
</div>






<div class="modal fade" id="addModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Select Month Of Report</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Month </label>
                            <select id="reportMonths" name="reportMonths" class="selectpicker  " data-live-search="true" data-width="100%">
                                <option value=""> Select Month</option>
                                <?php foreach ($this->config->item('months') as $key => $value) { ?>
                                    <option value="<?php echo $key; ?>" <?php //if($key==date('m')){ echo 'selected="selected"'; } ?> ><?php echo $value; ?></option>
<?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Year </label>
                            <select id="reportYears" name="reportYears" class="selectpicker  " data-live-search="true" data-width="100%">
                                <option value=""> Select Year</option>
                                <?php foreach ($this->config->item('years') as $key => $value) { ?>
                                    <option value="<?php echo $key; ?>" <?php //if($key==date('Y')){ echo 'selected="selected"'; } ?> ><?php echo $value; ?></option>
<?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <button id="searchBtn" class="btn btn-success" style="" onclick="checkData()" >Search</button>
                    </div>
                    <div class="col-md-5" ></div>
                    <div class="col-md-2" id="resultDiv"></div>
                    <div class="col-md-5" ></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>

<style>
    .dataTables_wrapper{display:grid;}
    
    table tr th{vertical-align: top !important;}

    table.my-table-width tr th{min-width: 210px;}
</style>