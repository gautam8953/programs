<div class="page-title">
    <div class="title_left">
        <h3>Monthly Format</h3>
    </div>
 
</div>

<div class="main-content"> 
  <div class="tab-head1">
    <div class="container">        
           <div id="searchDiv" class="row" style="<?php echo $showSearch?'':'display: none;'; ?>">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <div class="x_panel">
                <div class="x_title">
                  <h2>Add Monthly Report</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                            <div class="list-report-monthly">
                                <div class="row">
                                	<!-- <div class="col-md-12 col-sm-12 col-xs-12">
	                                    <h4>Add Monthly Report</h4>
	                                </div> -->
                            <?php if(isset($search_options['State']) ){ ?>
                            
                            <div class="col-md-3 col-xs-12 mar-top-20">
                                <select id="search_state" name="search_state" onchange="change_state()" class="form-control">
                                    <option value="">Select State</option>
                                    <?php foreach ($search_options['State'] as $key => $value) {  ?>
                                    <option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
                                    <?php } ?>
                                </select>                    
                            </div>
                            <?php } ?>
                            <?php if(isset($search_options['District']) ){ ?>
                            <div class="col-md-3 col-xs-12 mar-top-20">
                                <select id="search_district" name="search_district" onchange="change_district()" class="form-control">
                                    <option value="">Select District</option>
                                    <?php foreach ($search_options['District'] as $key => $value) { ?>
                                    <option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
                                    <?php } ?>
                                </select>                    
                            </div>
                            <?php } ?>
                            <?php if(isset($search_options['Facility']) ){ ?>
                            <div class="col-md-3 col-xs-12 mar-top-20">
                                <select id="search_facility" name="search_facility" class="form-control" onchange="setFacility(this)">
                                    <option value="">Select Facility</option>
                                </select>                    
                            </div>
                            <?php } ?>
                            <div class="col-md-3 col-xs-12 mar-top-20">
                                    <select id="reportMonths" name="reportMonths" class="selectpicker  " data-live-search="true" data-width="100%">
                                        <option value=""> Select Month</option>
                                        <?php foreach ($this->config->item('months') as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php //if($key==date('m')){ echo 'selected="selected"'; } ?> ><?php echo $value; ?></option>
                                        <?php } ?>
                                    </select>
                            </div>
                       
                            <div class="col-md-3 col-xs-12 mar-top-20">
                                    <select id="reportYears" name="reportYears" class="selectpicker  " data-live-search="true" data-width="100%">
                                        <option value=""> Select Year</option>
                                        <?php foreach ($this->config->item('years') as $key => $value) { ?>
                                        <option value="<?php echo $key; ?>" <?php //if($key==date('Y')){ echo 'selected="selected"'; } ?> ><?php echo $value; ?></option>
                                        <?php } ?>
                                    </select>
                            </div>
                        
                            <div class="col-md-3 col-xs-12 mar-top-20">
                                <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Go" />
                            </div>
                            <div class="col-md-2" id="resultDiv" style="display: none;"></div>
                            </div>
                            <hr>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        


      <div id="formDiv" class="row" style="<?php echo $showSearch?'display: none;':''; ?>">
        <div class="form-main-labour">
            <form name="monthlyForm" id="monthlyForm" class="login-form login_form_mine" action="<?php echo base_url()."ApiMonthly/save"?>" method="post">
            <div id="smartwizard">
              <ul class="three-tabber">
                <li><a href="#step-1"><span><em> 1 </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>General Information<br /></a></li>
                <li><a href="#step-2"><span><em> 2 </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>One time Reporting <br /></a></li>
                <li><a href="#step-3"><span><em> 3 </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>Monthly reporting indicators<br /></a></li>
            </ul>
            <div>
                <!-- Tab Start -->
                
                <div id="step-1">
                    <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>General Information</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  
                </div>
                <div class="x_content">
                    <div class="list-report-monthly">
                        <h5 class="tab-title">Section 1: General Information </h5>
                        
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Name of State <span class="required"> * </span> </label>
                                    <select id="FacilityState" name="FacilityState" class="selectpicker  " data-live-search="true" data-width="100%">
                                        <option value=""> Select State</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Name of District <span class="required"> * </span> </label>
                                    <select id="FacilityDistrict" name="FacilityDistrict" class="selectpicker  " data-live-search="true" data-width="100%">
                                        <option value=""> Select District</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Type of Facility <span class="required"> * </span> </label>
                                    <select id="FacilityType" name="FacilityType" class="selectpicker  " data-live-search="true" data-width="100%">
                                        <option value=""> Select Facility Type</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Name of Facility <span class="required"> * </span> </label>
                                    <select id="FacilityName" name="FacilityName" class="selectpicker  " data-live-search="true" data-width="100%">
                                        <option value=""> Select Facility</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">

                                <div class="form-group">
                                    <label> Reporting Month <span class="required"> * </span> </label>
                                    <div class="input-group date ">
                                        <input id="ReportMonth" name="ReportMonth" type="text" placeholder="DD-MM-YYYY" class="form-control " value="" readonly="readonly">
                                        <span class="input-group-addon">
                                                                <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12" style="margin-bottom: 10px;">

                                <div class="form-group">
                                    <label> Date of Data Collection/Visit <span class="required"> * </span> </label>
                                    <div class="input-group date ">
                                        <input id="CollectionDate" name="CollectionDate" type="text" placeholder="DD-MM-YYYY" class="form-control datepicker">
                                        <span class="input-group-addon">
                                                                <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>

                    

                            

                            
                            


                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>





                <!-- Tab End -->
                <!-- Tab Start -->
                <div id="step-3">
                    <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Monthly reporting indicators</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  
                </div>
                <div class="x_content">
                    <div class="list-report-monthly">
                        <h5 class="tab-title">Section 3:  Monthly Reporting Indicators </h5>
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total Number of Normal Vaginal Deliveries <span class="required"> * </span> </label>
                                    <input id="TotalNormalVaginalDeliveries" name="TotalNormalVaginalDeliveries" type="text" class="form-control nums" placeholder="Normal vaginal deliveries" onchange="calulateTotalDel()" minlength="1" maxlength="5" >
                                    <div class="required err"></div>
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total Number of Assisted Vaginal Deliveries <span class="required"> * </span> </label>
                                    <input id="TotalAssistedVaginalDeliveries" name="TotalAssistedVaginalDeliveries" type="text" class="form-control nums" placeholder="Assisted Vaginal Deliveries" onchange="calulateTotalDel()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total Number of C-Sections <span class="required"> * </span> </label>
                                    <input id="TotalCSections" name="TotalCSections" type="text" class="form-control nums" placeholder="Number of C-Sections" onchange="calulateTotalDel()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total Number of Deliveries <span class="required"> * </span> </label>
                                    <input id="TotalDeliveries" name="TotalDeliveries" type="text" class="form-control" placeholder="Auto calculated" readonly="readonly" minlength="1" maxlength="6" >
                                </div>
                            </div>

                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <h6><strong> Causes of Maternal Deaths </strong> </h6>
                                
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> APH <span class="required"> * </span> </label>
                                    <input id="MaternalAPH" name="MaternalAPH" type="text" class="form-control nums" placeholder="APH" onchange="calulateTotalMaternalDeaths()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> PPH <span class="required"> * </span> </label>
                                    <input id="MaternalPPH" name="MaternalPPH" type="text" class="form-control nums" placeholder="PPH" onchange="calulateTotalMaternalDeaths()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>Sepsis <span class="required"> * </span> </label>
                                    <input id="MaternalSepsis" name="MaternalSepsis" type="text" class="form-control nums" placeholder="Sepsis" onchange="calulateTotalMaternalDeaths()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>Obstructed labour <span class="required"> * </span> </label>
                                    <input id="MaternalObstructedLabour" name="MaternalObstructedLabour" type="text" class="form-control nums" placeholder="&nbsp; Obstructed labour " onchange="calulateTotalMaternalDeaths()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>PIH/Eclampsia <span class="required"> * </span> </label>
                                    <input id="MaternalPIHEclampsia" name="MaternalPIHEclampsia" type="text" class="form-control nums" placeholder="PIH/Eclampsia" onchange="calulateTotalMaternalDeaths()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>Others <span class="required"> * </span> </label>
                                    <input id="MaternalOthers" name="MaternalOthers" type="text" class="form-control nums" placeholder="Others" onchange="calulateTotalMaternalDeaths()" minlength="1" maxlength="5">
                                </div>
                            </div>


                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total Number of Maternal Deaths <span class="required"> * </span> </label>
                                    <input id="TotalMaternalDeaths" name="TotalMaternalDeaths" type="text" class="form-control nums" placeholder="Auto Calculated" readonly="readonly" minlength="1" maxlength="6">
                                </div>
                            </div>

                            
                            

                            

                            

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total number of Fresh Still births <span class="required"> * </span> </label>
                                    <input id="TotalFreshStillBirths" name="TotalFreshStillBirths" type="text" class="form-control nums" placeholder="Total number of Fresh Still births" onchange="calulateStillBirth()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total number of macerated still births <span class="required"> * </span> </label>
                                    <input id="TotalMaceratedStillBirths" name="TotalMaceratedStillBirths" type="text" class="form-control nums" placeholder="Total number of macerated still births  " onchange="calulateStillBirth()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total number of still births <span class="required"> * </span> </label>
                                    <input id="TotalStillBirths" name="TotalStillBirths" type="text" class="form-control nums" placeholder="Auto calculated" readonly="readonly" minlength="1" maxlength="5">
                                </div>
                            </div>                            


                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total number of live births <span class="required"> * </span> </label>
                                    <input id="TotalLiveBirths" name="TotalLiveBirths" type="text" class="form-control nums" placeholder="Total number of live births  " minlength="1" maxlength="5">
                                </div>
                            </div>


                            
                            

                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <h6><strong> Major causes of neonatal deaths  </strong> </h6>
                               
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Prematurity <span class="required"> * </span> </label>
                                    <input id="NeonatalPrematurity" name="NeonatalPrematurity" type="text" class="form-control nums" placeholder="Prematurity" onchange="calulateNeonatalDeaths()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Sepsis <span class="required"> * </span> </label>
                                    <input id="NeonatalSepsis" name="NeonatalSepsis" type="text" class="form-control nums" placeholder="Sepsis" onchange="calulateNeonatalDeaths()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>Asphyxia <span class="required"> * </span> </label>
                                    <input id="NeonatalAsphyxia" name="NeonatalAsphyxia" type="text" class="form-control nums" placeholder="Asphyxia" onchange="calulateNeonatalDeaths()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> &nbsp;Others <span class="required"> * </span> </label>
                                    <input id="NeonatalOthers" name="NeonatalOthers" type="text" class="form-control nums" placeholder="Others" onchange="calulateNeonatalDeaths()" minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Number of neonatal deaths <span class="required"> * </span> </label>
                                    <input id="NumberNeonatalDeaths" name="NumberNeonatalDeaths" type="text" class="form-control nums" placeholder="Auto calculated" readonly="readonly" minlength="1" maxlength="5" >
                                </div>
                            </div>

                            
                            

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total number of Low Birth Weight babies born in facility <span class="required"> * </span> </label>
                                    <input id="TotalLowBirthWeightBabies" name="TotalLowBirthWeightBabies" type="text" class="form-control nums" placeholder="Total number of Low Birth Weight babies born in facility " minlength="1" maxlength="5">
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total no. of Preterm Deliveries <span class="required"> * </span> </label>
                                    <input id="TotalPretermDeliveries" name="TotalPretermDeliveries" type="text" class="form-control nums" placeholder="Total no. of Preterm Deliveries" minlength="1" maxlength="5">
                                </div>
                            </div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of normal deliveries conducted in presence of Birth Companion
                                    <span class="required"> * </span> </label>
                                <input id="BirthCompanionNos" name="BirthCompanionNos" type="text" class="form-control nums" placeholder="Birth companions in Normal Deliveries " minlength="1" maxlength="5">
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of normal deliveries conducted using Safe Birth Checklist
                                    <span class="required"> * </span> </label>
                                <input id="SafeBirthChecklist" name="SafeBirthChecklist" type="text" class="form-control nums" placeholder="Safe birth checklist used in Normal Deliveries" minlength="1" maxlength="5">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label style=""> Number of planned and emergency C-Section operations where safe surgical checklist was used
                                    <span class="required"> * </span> </label>
                                <input id="CSectionOTSafeChecklist" name="CSectionOTSafeChecklist" type="text" class="form-control nums" placeholder="Safe birth checklist in C-Sections" minlength="1" maxlength="5">
                            </div>
                        </div>
                       

                       
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of normal deliveries conducted using real time Partograph
                                    <span class="required"> * </span> </label>
                                <input id="RealTimePartograph" name="RealTimePartograph" type="text" class="form-control nums" placeholder="Real Time Partograph" minlength="1" maxlength="5">
                            </div>
                        </div>
                    </div>


                        <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of newborns delivered in facility who were breastfed within one hour of delivery?
                                    <span class="required"> * </span> </label>
                                <input id="BreastfedNewborns" name="BreastfedNewborns" type="text" class="form-control nums" placeholder="Breastfed Within one Hour of Delivery? " minlength="1" maxlength="5">
                            </div>
                        </div>
                    
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether microbiological sampling from labour room is collected as per protocol

                                    <span class="required"> * </span> </label>
                                    <br>
                                <label class="radio inline">
                                    <input id="MCBSamplingLR_1" name="MCBSamplingLR" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="MCBSamplingLR_0" name="MCBSamplingLR" type="radio" value="0">
                                    <span>No </span>
                                </label>

                            </div>
                        </div>
                    </div>

                        <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether microbiological sampling from Maternity OT is collected as per protocol

                                    <span class="required"> * </span> </label>
                                <label class="radio inline">
                                    <input id="MCBSamplingOT_1" name="MCBSamplingOT" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="MCBSamplingOT_0" name="MCBSamplingOT" type="radio"  value="0">
                                    <span>No </span>
                                </label>

                            </div>
                        </div>
                        
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of C-Sections operations in which surgical site infection developed within one month of operation
                                    <span class="required"> * </span> </label>
                                <input id="CSectionsInfection" name="CSectionsInfection" type="text" class="form-control nums" placeholder="Surgical site infections in C-Sections operations" minlength="1" maxlength="5">
                            </div>
                        </div>
                    </div>




                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of preterm cases where Antenatal Corticosteroids (ANCS) was administered in facilities 
                                    <span class="required"> * </span> </label>
                                <input id="PretermANCSInFacilitiesSNCU" name="PretermANCSInFacilitiesSNCU" type="text" class="form-control nums" placeholder="Preterm Cases given ANCS" minlength="1" maxlength="5">
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of newborns delivered in facility developed birth asphyxia <span class="required"> * </span> </label>
                                <input id="NewbornsSNCUAsphyxia" name="NewbornsSNCUAsphyxia" type="text" class="form-control nums" placeholder="New borns with birth Asphyxia" minlength="1" maxlength="5">
                            </div>
                        </div>
                        </div>

                        <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of newborns delivered in facility developed sepsis <span class="required"> * </span> </label>
                                <input id="NewbornsSNCUSepsis" name="NewbornsSNCUSepsis" type="text" class="form-control nums" placeholder="Newborns with Sepsis " minlength="1" maxlength="5">
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Total number of inborn LBW newborns in facility provided KMC
                                    <span class="required"> * </span> </label>
                                <input id="InbornLBWKMC" name="InbornLBWKMC" type="text" class="form-control nums" placeholder="No. of inborn newborns given KMC" minlength="1" maxlength="5">
                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of beneficiaries delivered last month who were either satisfied or highly satisfied
                                    <span class="required"> * </span> </label>
                                <input id="SatisfiedDelivered" name="SatisfiedDelivered" type="text" class="form-control nums" placeholder="Beneficiaries satisfied" minlength="1" maxlength="5">
                            </div>
                        </div>
                       
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether facility has reorganized labour room as per the guidelines?

                                    <span class="required"> * </span> </label>
                                    <br>
                                <label class="radio inline">
                                    <input id="ReorganizedLR_1" name="ReorganizedLR" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="ReorganizedLR_0" name="ReorganizedLR" type="radio"  value="0">
                                    <span>No </span>
                                </label>

                                <label class="radio inline">
                                    <input id="ReorganizedLR_2" name="ReorganizedLR" type="radio"  value="2">
                                    <span>In progress </span>
                                </label>
                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether facility has adequate staff at labour rooms as per defined norms?

                                    <span class="required"> * </span> </label>
                                    <br>
                                <label class="radio inline">
                                    <input id="AdequateStaffLR_1" name="AdequateStaffLR" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="AdequateStaffLR_0" name="AdequateStaffLR" type="radio"  value="0">
                                    <span>No </span>
                                </label>

                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of deliveries conducted in facility where Oxytocin was administered within one minute of birth

                                    <span class="required"> * </span> </label>
                                <input id="OxytocinCount" name="OxytocinCount" type="text" class="form-control nums" placeholder="Oxytocin was administered within one minute of birth" minlength="1" maxlength="5">
                            </div>
                        </div>
                    </div>


                        <div class="row">

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of maternal deaths were reviewed in last month

                                    <span class="required"> * </span> </label>
                                <input id="MaternalDeathsReviewed" name="MaternalDeathsReviewed" type="text" class="form-control nums" placeholder="Number of maternal deaths in last month" minlength="1" maxlength="5">
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of neonatal deaths were reviewed in last month

                                    <span class="required"> * </span> </label>
                                <input id="NeonatalDeaths" name="NeonatalDeaths" type="text" class="form-control nums" placeholder="Number of Neonatal Deaths in last month" minlength="1" maxlength="5">
                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of Maternal Near Miss Cases were reviewed in last month <span class="required"> * </span> </label>
                                <input id="MaternalMissCases" name="MaternalMissCases" type="text" class="form-control nums" placeholder="Number of Maternal Near Miss Cases" minlength="1" maxlength="5">
                            </div>
                        </div>
                    
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of Referral cases reviewed in the month
                                    <span class="required"> * </span> </label>
                                <input id="ReferralCases" name="ReferralCases" type="text" class="form-control nums" placeholder="Number of Referral cases" minlength="1" maxlength="5">
                            </div>
                        </div>
                    </div>

                        
                        

                        <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether there was any stock outs of drugs and consumables in LR <span class="required"> * </span> </label>
                                <br>

                                <label class="radio inline">
                                    <input id="StockOutsInLR_1" name="StockOutsInLR" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="StockOutsInLR_0" name="StockOutsInLR" type="radio"  value="0">
                                    <span>No </span>
                                </label>

                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether there was any stock outs of drugs and consumables in maternity OT <span class="required"> * </span> </label>
                                <br>
                                <label class="radio inline">
                                    <input id="StockOutsInOT_1" name="StockOutsInOT" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="StockOutsInOT_0" name="StockOutsInOT" type="radio"  value="0">
                                    <span>No </span>
                                </label>

                            </div>
                        </div>
                    </div>




                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether facility labour room has achieved NQAS certification
                                    <span class="required"> * </span> </label>
                                    <br>
                                <label class="radio inline">
                                    <input id="NQASCertification_1" name="NQASCertification" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="NQASCertification_0" name="NQASCertification" type="radio"  value="0">
                                    <span>No </span>
                                </label>
                            </div>
                        </div>
                        
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether MCH/DH has functional Obs ICU/Hybrid ICU/HDU?
                                    <span class="required"> * </span> </label>
                                    <br>
                                <label class="radio inline">
                                    <input id="MCHDHFunctional_1" name="MCHDHFunctional" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="MCHDHFunctional_0" name="MCHDHFunctional" type="radio"  value="0">
                                    <span>No </span>
                                </label>
                            </div>
                        </div>
                    </div>

                        
                        


                        <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of LaQshya mentoring visits conducted
                                    <span class="required"> * </span> </label>
                                <input id="LaQshyaMentoringVisitsConducted" name="LaQshyaMentoringVisitsConducted" type="text" class="form-control nums" placeholder="Number of LaQshya mentoring visits conducted " minlength="1" maxlength="5">
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of QI team meetings at labour room/OT

                                    <span class="required"> * </span> </label>
                                <input id="QITeamMeetings" name="QITeamMeetings" type="text" class="form-control" placeholder="Number of QI team meetings at labour room/OT

    " minlength="1" maxlength="5">
                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of onsite training session conducted

                                    <span class="required"> * </span> </label>
                                <input id="TrainingSessionConducted" name="TrainingSessionConducted" type="text" class="form-control nums" placeholder="Number of onsite training session conducted

    " minlength="1" maxlength="5">
                            </div>
                        </div>
                   
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Current Labour Room Quality Score
                                    <span class="required"> * </span> </label>
                                <input id="CurrentLabourRoomQualityScore" name="CurrentLabourRoomQualityScore" type="text" class="form-control nums" readonly="readonly" placeholder="Current Labour Room Quality Score" minlength="1" maxlength="5">
                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Current Maternity OT Quality Score <span class="required"> * </span> </label>
                                <input id="CurrentMaternityOTQualityScore" name="CurrentMaternityOTQualityScore" type="text" class="form-control nums" readonly="readonly" placeholder="Current Maternity OT Quality Score  

    " minlength="1" maxlength="5">
                            </div>
                        </div>

                        <!-- <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Current OSCE Score <span class="required"> * </span> </label>
                                <input id="CurrentOSCEScore" name="CurrentOSCEScore" type="text" class="form-control nums" placeholder="Current OSCE Score ">
                            </div>
                        </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                <!-- Tab End -->
                <!-- Tab Start -->
                <div id="step-2">
                    <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>One time Reporting</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  
                </div>
                <div class="x_content">
                    <div class="list-report-monthly">
                        <h5 class="tab-title">Section 2:  One time Reporting </h5>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="row">
                            <h6>labour room assessment</h6>
                        </div>
                           
                        </div>


                        <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility has completed baseline assessment of labour room using NQAS checklist


                                    <span class="required"> * </span> </label>
                                    <br>
                                <label class="radio inline">
                                    <input id="BaselineNQASChecklistLR_1" name="BaselineNQASChecklistLR" type="radio"  value="1" onchange="resetval('BaselineNQASChecklistLR')" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="BaselineNQASChecklistLR_0" name="BaselineNQASChecklistLR" type="radio"  value="0" onchange="resetval('BaselineNQASChecklistLR')">
                                    <span>No </span>
                                </label>

                            </div>
                        </div>

                        
                        <div class="col-md-6 col-sm-6 col-xs-12">

                            <div class="form-group">
                                <label>Month of assessment <span class="required"> * </span> </label>
                                <div class="input-group date datepicker">
                                    <input minlength="10" maxlength="10" readonly="readonly" id="AssessmentMonthLR" name="AssessmentMonthLR" type="text" placeholder="DD-MM-YYYY" class="form-control datepicker">
                                    <span class="input-group-addon">
                                                            <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>


                        <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Baseline Score for Labour Room  <span class="required"> * </span> </label>
                                <input id="BaselineScoreLR" name="BaselineScoreLR" type="text" class="form-control nums" placeholder="Baseline Score for Labour Room   " minlength="1" maxlength="5" readonly="readonly">
                            </div>
                        </div>
                    </div>




                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="row">
                            <h6>Operation Theatre  assessment </h6>
                        </div>
                           
                        </div>



                        <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility has completed baseline assessment of Operation Theatre using NQAS checklist <span class="required"> * </span> </label>
                                <br>
                                <label class="radio inline">
                                    <input id="BaselineNQASChecklistOT_1" name="BaselineNQASChecklistOT" type="radio"  value="1" onchange="resetval('BaselineNQASChecklistOT')" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="BaselineNQASChecklistOT_0" name="BaselineNQASChecklistOT" type="radio"  value="0" onchange="resetval('BaselineNQASChecklistOT')">
                                    <span>No </span>
                                </label>

                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12">

                            <div class="form-group">
                                <label>Month of assessment <span class="required"> * </span> </label>
                                <div class="input-group date datepicker">
                                    <input minlength="10" maxlength="10" readonly="readonly" id="AssessmentMonthOT" name="AssessmentMonthOT" type="text" placeholder="DD-MM-YYYY" class="form-control datepicker">
                                    <span class="input-group-addon">
                                                            <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>


                        <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Baseline Score for Operation Theatre  <span class="required"> * </span> </label>
                                <input readonly="readonly" id="BaselineScoreOT" name="BaselineScoreOT" type="text" class="form-control nums" placeholder="Baseline Score for Operation Theatre   " minlength="1" maxlength="5">
                            </div>
                        </div>
                    </div>

                        

                        <!-- <div class="col-md-12">
                            
                            <h6><strong>Staff competence  assessment </strong> </h6>
                            
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Facility has assessed  baseline staff competence using the OSCE <span class="required"> * </span> </label>
                                    <label class="radio inline">
                                        <input id="BaselineStaffCompetenceOSCE_1" name="BaselineStaffCompetenceOSCE" type="radio"  value="1" >
                                        <span>Yes </span>
                                    </label>

                                    <label class="radio inline">
                                        <input id="BaselineStaffCompetenceOSCE_0" name="BaselineStaffCompetenceOSCE" type="radio"  value="0">
                                        <span>No </span>
                                    </label>

                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>Month of assessment <span class="required"> * </span> </label>
                                    <div class="input-group date datepicker">
                                        <input id="AssessmentMonthOSCE" name="AssessmentMonthOSCE" type="text" placeholder="DD-MM-YYYY" class="form-control datepicker">
                                        <span class="input-group-addon">
                                                                <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Baseline average  OSCE Score    <span class="required"> * </span> </label>
                                    <input id="BaselineAvgOSCEScore" name="BaselineAvgOSCEScore" type="text" class="form-control nums" placeholder="Baseline Score for Labour Room   ">
                                </div>
                            </div>
                        </div> -->



                        
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="row">
                            <h6>Facility report</h6>
                        </div>
                            
                        </div>



                        <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility has setup facility level quality team  <span class="required"> * </span> </label>
                                <br>
                                
                                <label class="radio inline">
                                    <input id="QualityTeamFacility_1" name="QualityTeamFacility" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="QualityTeamFacility_0" name="QualityTeamFacility" type="radio"  value="0">
                                    <span>No </span>
                                </label>

                            </div>
                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility has setup functional quality circle in Labour Room  <span class="required"> * </span> </label>
                                <br>
                                <label class="radio inline">
                                    <input id="QualityCircleLR_1" name="QualityCircleLR" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="QualityCircleLR_0" name="QualityCircleLR" type="radio"  value="0">
                                    <span>No </span>
                                </label>

                            </div>
                        </div>
                    </div>

                        <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility has setup functional quality circle in Maternity OT  <span class="required"> * </span> </label>
                                <br>
                                <label class="radio inline">
                                    <input id="QualityCircleOT_1" name="QualityCircleOT" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="QualityCircleOT_0" name="QualityCircleOT" type="radio"  value="0">
                                    <span>No </span>
                                </label>

                            </div>
                        </div>
                    

                        
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility staff of LR and OT quality circles have attended district level or facility level orientation on LR Protocols, QI processes and RMC  <span class="required"> * </span> </label>
                                <br>
                                <label class="radio inline">
                                    <input id="OrientationAttended_1" name="OrientationAttended" type="radio"  value="1" >
                                    <span>Yes </span>
                                </label>

                                <label class="radio inline">
                                    <input id="OrientationAttended_0" name="OrientationAttended" type="radio"  value="0">
                                    <span>No </span>
                                </label>

                            </div>
                        </div>
                    </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
                <!-- Tab End -->
            </div>
        </div>
        <input type='hidden' name="MonthlyID" id="MonthlyID" value="<?php echo $this->uri->segment('3'); ?>" class="" />
        <input type='hidden' name="CurrentOSCEScore" id="CurrentOSCEScore" value="0" class="" />
    </form>
    </div>
</div>
</div>
</div>  
</div>


<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>
