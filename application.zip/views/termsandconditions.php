<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Laqshya</title>
        <meta charset="utf-8">
        <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <!-- Bootstrap -->
        <link href="<?php echo base_url(); ?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="<?php echo base_url(); ?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- NProgress -->
        <link href="<?php echo base_url(); ?>assets/vendors/nprogress/nprogress.css" rel="stylesheet">
        <!-- Animate.css -->
        <link href="<?php echo base_url(); ?>assets/vendors/animate.css/animate.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

        <!-- Custom Theme Style -->
        <link href="<?php echo base_url(); ?>assets/css/custom.min.css" rel="stylesheet">
      <!-- <link href="<?php //echo base_url(); ?>assets/css/pace-theme-mac-osx.css" rel="stylesheet" /> -->
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900|Open+Sans:400,600,700|Patua+One|Source+Sans+Pro:400,600,700" rel="stylesheet">

<!-- <script src="<?php //echo base_url(); ?>assets/js/jquery.min.js"></script>-->
      <script src="<?php echo base_url();?>assets/js/jquery1.11.3.min.js"></script>
      <script src="<?php echo base_url();?>assets/js/jquery.cookie.js"></script>

  <!-- <script src='https://www.google.com/recaptcha/api.js'></script> -->
        <script type="text/javascript">
            var pageMainUrl = "<?php echo base_url(); ?>";
        </script>

 <noscript>
   <h1 class="text-center ">This page needs JavaScript activated to work. </h1>
   <style>div { display:none; }</style>
 </noscript>
 
    </head>
    <body class="nav-md grey termsandconditions" id="bg-color">

       <header>
        <div class="header-bottom">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-4 col-sm-4 col-xs-12 text-left main-logo">
                <a href="<?php echo base_url();?>">
                  <h1>
                    <span class="emonitoring white_logo"><img src="<?php echo base_url();?>/assets/images/laqshya-logo.png"></span>
                    <span class="emonitoring default_logo"><img src="<?php echo base_url();?>/assets/images/laqshya-logo1.png"></span>
                  </h1>
                </a>
              </div>


              <div class="col-md-4 col-sm-4 col-xs-6 indian-emblem text-center">
                <a href="https://mohfw.gov.in/" target="_blank" >
                  <img class="white_logo" style="padding-top: 5px;" src="<?php echo base_url();?>/assets/images/indian-emblem.png" alt="Indian Emblem">
                  <img class="default_logo" style="padding-top: 5px;" src="<?php echo base_url();?>/assets/images/indian-emblem1.png" alt="Indian Emblem">
                </a>
              </div>
              
              <div class="col-md-4 col-sm-4 col-xs-6 nhp-logo">
                 <a href="http://nhm.gov.in/" target="_blank">
                  
                  <img class="default_logo" style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhm-white.png" alt="NHM" class="NHM-logo">
                  <img class="white_logo" style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhm.png" alt="NHM" class="NHM-logo">
                </a>
                <a href="https://www.nhp.gov.in/" target="_blank"> 
                  <img class="default_logo"  style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhp-white.png" alt="NHP" class="nhp-logo">
                  <img class="white_logo"  style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhp.png" alt="NHP" class="nhp-logo">
                </a>
               
              </div>
            </div>
          </div>
        </div>
      </header>

      <div class="bread_crumb bread_crumb1">
            <div class="container custom-container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <span><a href="<?php echo base_url();?>"><i class="fa fa-home"></i>&nbsp;Home </a>&nbsp; <i class="fa fa-angle-right"></i> &nbsp;<span> Terms and Conditions</span></span>
                </div>
              </div>
            </div>
          </div>



        
        <div class="container-fluid">
          <!--<div class="row terms_heading">
            <div class="container custom-container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <h3>Terms and Conditions</h3>
                </div>
              </div>
            </div>
          </div> -->


          


          <div class="row terms_content">
            <div class="container custom-container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <!--<h4>Lorem Ipsum is Dolar Set</h4>-->
                  <p>When you register for any services on LaQshya we ask you for your name, contact information, Profession Information, preferences, and certain demographic information. This information enables us to provide personalized services and communicate separately with you. We also use aggregated information about the use of our services to evaluate our user’s preferences, improve our programming and content delivery.</p>
                  <br>
                  <br>
                  <p>We do not share or sell personally identifiable data with other service providers, who can use such information for commercial promotion. Our newsletter and other mailers are sent to you on your explicit instruction and you can opt out of it at any time.</p>
                </div>
              </div>
            </div>
          </div>
        </div>


        <!-- color changes 
            <div class="color-theme">
                <a href="javascript:;"  class="theme-collapse-btn"><i class="fa fa-angle-left"></i></a>
                <ul>
                <li><a class="black-bg" href="javascript:;" title="Black Theme" id="color1"><img src="<?php echo base_url(); ?>assets/images/black-theme.png" alt="Black Theme"></a></li>
                
                  <li><a class="white-bg" href="javascript:;" title="Default Theme" id="color2"><img src="<?php echo base_url(); ?>assets/images/default-theme.png" alt="Default Theme"></a></li>
                          
                  <li><a class="red-bg" href="javascript:;" title="Red Theme" id="color3"><img src="<?php echo base_url(); ?>assets/images/red-bg.png" alt="Red Theme"></a></li>

                  <li><a class="grey-bg" href="javascript:;" title="Grey Theme" id="color4"><img src="<?php echo base_url(); ?>assets/images/grey-theme.png" alt="Grey Theme"></a></li>
                          
                
                  </ul>

                  <h4> Color Theme</h4>

            </div>
-->


        <footer>
            <div class="container">
                <div class="row" style="display: flex; align-items: center;">


                    <div class="col-md-12 col-sm-12 col-sm-12 col-xs-12 visitor-number">
                        Copyright &copy; 2018. LA<span style="color: #af2222;">Q</span>SHYA. All Rights Reserved.
                    </div>
                    <!-- <div class="col-md-6 col-sm-4 col-sm-6 col-xs-12 text-right footer-right">
                        <img src="<?php echo base_url(); ?>assets/images/nhm.png" alt="nhm">
                        <img src="<?php echo base_url(); ?>assets/images/nhsrc.png" alt="nhsrc">
                    </div> -->
                </div>
            </div>
        </footer>




        <!--!-- date Picker -->
        <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.form.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>

        <script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js"></script>

        <script src="<?php echo base_url(); ?>assets/js/bootstrap-select.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/moment.min.js"></script> 
        <script src="<?php echo base_url(); ?>assets/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript">
 
</script>



        <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
        <?php
        $file = $this->uri->segment(2);
        if (empty($file)) {
            $file = 'index';
        }
        $folder = $this->uri->segment(1);
        if (empty($folder)) {
            $file = 'user';
        }
        $scriptUrl = 'assets/js/' . strtolower($folder) . '/' . strtolower($file) . '.js';
        if (file_exists($scriptUrl)) {
            echo '<script src="' . base_url() . $scriptUrl . '"></script>';
        }
        ?> 


        <!-- color changes scrpipt -->







    </body>
</html>