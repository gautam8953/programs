<style>
    .erroShow { border:1px solid red};
    .erroHide { border:none};
</style>

<div class="page-title">
    <div class="title_left">
        <h3>DCT Report</h3>
    </div>

    <!--<div class="title_right">
      <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
        <div class="input-group" style="float: right;">
          <a href="<?php echo base_url() . "facility/assesment"; ?>" id="addBtn" class="btn btn-success disabled pull-right">Add</a>
        </div>
      </div>
    </div>-->
</div>

<div class="clearfix"></div>


<div class="main-content">

    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <form id="assesmentForm" name="assesmentForm" role="form" action="<?php echo base_url() . "ApiDct/add" ?>" method="post">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>DCT Report &nbsp;</h2>  <h6>(Kindly fill details of the members of District Coaching Team (DCT))</h6>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <div class="row" id="addedDiv">

                                <?php
                                for ($i = 1; $i <= 1; $i++) {
                                    ?>
                                    <div id="totalDiv_<?php echo $i; ?>">
                                        <div class="col-md-12"  >

                                            <div class="col-md-12">
                                                <a class="pull-right close-btn1" id="remove_<?php echo $i; ?>" title="Remove This Section" onclick="removeParticipantsRow(this)"><i class="fa fa-times-circle-o" aria-hidden="true"></i></a>
                                            </div>


                                            <?php if (isset($search_options['State'])) { ?>
                                                <div class="col-md-2 col-xs-12 mar-top-20">
                                                    <label> Select State <span class="required"> * </span> </label>
                                                    <select  name="search_state[]" id="search_state_<?php echo $i; ?>"  class="form-control" onchange="change_state(this.value,<?php echo $i; ?>)">
                                                        <?php //if (count($search_options['State']) > 1) { ?>
                                                            <option value="">Select State</option>
                                                        <?php //} ?>
                                                        <?php foreach ($search_options['State'] as $key => $value) {
                                                            ?>
                                                            <option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
                                                        <?php } ?>
                                                    </select>  
                                                </div>
                                            <?php } ?>

                                            <div class="col-md-2 col-xs-12 mar-top-20">
                                                <?php if (isset($search_options['District'])) { ?>

                                                    <label> Select District <span class="required"> * </span> </label>
                                                    <select id="search_district_<?php echo $i; ?>" name="search_district[]"  class="form-control">
                                                        <option value="">Select District</option>
                                                        <?php foreach ($search_options['District'] as $key => $value) { ?>
                                                            <option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
                                                        <?php } ?>
                                                    <?php } ?>
                                                </select>                    
                                            </div>

                                            <div class="col-md-2 col-xs-12 mar-top-20">
                                                <label> Name <span class="required"> * </span> </label>
                                                <input type="text" class="form-control" id="name_<?php echo $i; ?>" name="name[]" maxlength="20" /> 
                                            </div>
                                            <div class="col-md-2 col-xs-12 mar-top-20">
                                                <label> Department <span class="required"> * </span> </label>
                                                <input type="text" class="form-control" id="department_<?php echo $i; ?>" name="department[]" maxlength="20" /> 
                                            </div>
                                            <div class="col-md-2 col-xs-12 mar-top-20">
                                                <label> Designation <span class="required"> * </span> </label>
                                                <input type="text" class="form-control" id="designation_<?php echo $i; ?>" name="designation[]"  maxlength="20"/>
                                            </div>
                                            <div class="col-md-2 col-xs-12 mar-top-20">
                                                <label> Designation in DCT <span class="required"> * </span> </label>
                                                <input type="text" class="form-control" id="designation_smg_<?php echo $i; ?>" name="designation_smg[]" maxlength="20" /> 
                                            </div>
                                            <div class="col-md-2 col-xs-12 mar-top-20">
                                                <label> Email<span class="required"> * </span> </label>
                                                <input type="text" class="form-control" id="email_<?php echo $i; ?>" name="email[]" maxlength="20" /> 
                                            </div>
                                            <div class="col-md-2 col-xs-12 mar-top-20">
                                                <label> Mobile <span class="required"> * </span> </label>
                                                <input type="text" class="form-control nums" id="mobile_<?php echo $i; ?>" name="mobile[]" maxlength="13" minlength="10"/> 
                                            </div>
                                        </div>
                                        <!--<div class="col-md-12 col-xs-12">
                                            <div class="form-group">

                                                <div class='input-group pull-right' style="margin:10px;">
                                                    <input type="button" class="btn btn-danger" id="remove_<?php echo $i; ?>" name="" value="Remove" onclick="removeParticipantsRow(this)"/>

                                                </div>
                                            </div>
                                        </div>  -->
                                    </div> 
                                <?php } ?>

                            </div>
                        </div>
                    </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <div class='input-group pull-right'>
                        <input type="button" class="btn btn-warning  btn-new-roud" id="add_more_row" name="add_more_row" value="Add More" />
                        <input type='submit' name="assesment" value="Submit" class="btn btn-info  btn-new-roud" />
                    </div>
                </div>
            </div>
            </form>

        </div>
    </div>

</div>
</div>
<script>
    var addMoreParticipantsCounter = 20;
    $(document).ready(function () {


        $("#add_more_row").click(function () {
            var html_str = '';
            var total_row = $("div[id^='totalDiv_']").length;
            var latestRow = parseInt(total_row) + 1;
            $("#addedDiv").append(contentAppend(latestRow));

        });

    });
//    function removeParticipantsRow(rowId) {
////    alert(rowId);
//        if ($("div[id^='totalDiv_']").length == 1) {
//            alert("You cannot delete");
//        } else {
//            //if (window.confirm('Do you realy want to remove ?')) {
//            swal({
//                title: "Are you sure?",
//                text: "Once deleted, you will not be able to recover this detail!",
////                    icon: "warning",
//                buttons: true,
//                dangerMode: false,
//            })
//                    .then((willDelete) => {
//                        if (willDelete) {
//                            $('#totalDiv_' + rowId).remove();
//                        } else {
//                            //swal("Your imaginary file is safe!");
//                        }
//                    });
//            //}
//
//        }
//    }
    function contentAppend(latestRow) {
        var html_str = '';
        html_str += '<div id="totalDiv_' + latestRow + '" style=""><div class="col-md-12" >';
        html_str += '<div class="col-md-12"><a class="pull-right close-btn1" id="remove_' + latestRow + '" title="Remove This Section" onclick="removeParticipantsRow(this)"><i class="fa fa-times-circle-o" aria-hidden="true"></i></a></div>';
        html_str += '<?php if (isset($search_options['State'])) { ?><div class="col-md-2 mar-top-20"><label> Select State <span class="required"> * </span> </label><select id="search_state_' + latestRow + '" name="search_state[]"   class="form-control" onchange="change_state(this.value,' + latestRow + ')"><?php //if (count($search_options['State']) > 1) { ?><option value="">Select State</option><?php //} ?><?php foreach ($search_options['State'] as $key => $value) { ?><option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option><?php } ?></select></div><?php } ?>';
        html_str += '<div class="col-md-2 mar-top-20"><label> Select District <span class="required"> * </span> </label><select id="search_district_' + latestRow + '" name="search_district[]"   class="form-control"><?php //if (count($search_options['District']) > 1) { ?><option value="">Select District</option><?php //} ?><?php foreach ($search_options['District'] as $key => $value) { ?><option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option><?php } ?></select></div>';
        html_str += '<div class="col-md-2 mar-top-20"><label> Name <span class="required"> * </span> </label><input maxlength="20" type="text" class="form-control" name="name[]" id="name_' + latestRow + '" /></div>';
        html_str += '<div class="col-md-2 mar-top-20"><label> Department <span class="required"> * </span> </label><input maxlength="20" type="text" class="form-control" name="department[]" id="department_' + latestRow + '" /></div>';
        html_str += '<div class="col-md-2 mar-top-20"><label> Designation <span class="required"> * </span> </label><input maxlength="20" type="text" class="form-control" name="designation[]" id="designation_' + latestRow + '" /></div>';
        html_str += '<div class="col-md-2 mar-top-20"><label> Designation in SMG <span class="required"> * </span> </label><input maxlength="20" type="text" class="form-control" name="designation_smg[]" id="designation_smg_' + latestRow + '" /></div>';
        html_str += '<div class="col-md-2 mar-top-20"><label> Email <span class="required"> * </span> </label><input type="text" maxlength="20" class="form-control" name="email[]" id="email_' + latestRow + '" /></div>';
        html_str += '<div class="col-md-2 mar-top-20"><label> Mobile <span class="required"> * </span> </label><input type="text" maxlength="13" minlength="10" class="form-control nums" name="mobile[]"id="mobile_' + latestRow + '" /></div>';
        /*html_str += '<div class="col-md-12 mar-top-20"><div class="form-group"><div class="input-group pull-right"><input class="btn btn-danger" name="" value="Remove" id="remove_' + latestRow + '" onclick="removeParticipantsRow(this)" type="button"></div></div></div> '; */
        html_str += '</div></div>';
        return html_str;
    }
    function removeParticipantsRow(rowId) {
//    alert(rowId);
        var row_id_array = $(rowId).attr('id').split('_');
        if ($("div[id^='totalDiv_']").length == 1) {
            alert("You cannot delete");
        } else {
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this detail!",
                buttons: true,
                dangerMode: false,
            })
                    .then((willDelete) => {
                        if (willDelete) {

                            $('#totalDiv_' + row_id_array[1]).remove();
                            rearrangePrevious();
                        } else {
                            //swal("Your imaginary file is safe!");
                        }
                    });

        }
    }
    function rearrangePrevious() {
        var totalReport = ($("div[id^='totalDiv_']").length);
        var rowCount = 1;
        $("div[id^='totalDiv_']").each(function (index, value) {
            this.id = 'totalDiv_' + rowCount;
            $('#' + this.id + ' input,select').each(function () {
                var old_inpt_id = $(this).attr('id').slice(0, -1);
                $(this).attr('id', old_inpt_id + rowCount);
            });
            rowCount++;
        });
    }
</script>
