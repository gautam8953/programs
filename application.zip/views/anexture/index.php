<div class="page-title">
  <div class="title_left">
    <h3>Anexture Form</h3>
  </div>

  
</div>

<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">	  
    <div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Manage Anexture</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">  
        
	    <?php if($this->session->userdata('showState') || $this->session->userdata('showDistrict') || $this->session->userdata('showFacilities')){ ?>
	   
	        <div class="col-md-12">
	        	<div class="row mar-bottom30">
	        <?php 
	        $attr = array("class" => "form-horizontal", "role" => "form", "id" => "form1", "name" => "form1");
	        echo form_open("facility/data", $attr);
	        ?>	            
            	<?php if(!empty($this->session->userdata('showState'))){ ?>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_state" name="search_state" onchange="change_state()" class="form-control">
						<option value="">Select State</option>
						<?php foreach ($search_options['State'] as $key => $value) {  ?>
						<option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
						<?php } ?>
					</select>                    
                </div>
                <?php } ?>
                <?php if(!empty($this->session->userdata('showDistrict'))){ ?>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_district" name="search_district" onchange="change_district()" class="form-control">
						<option value="">Select District</option>
						<?php foreach ($search_options['District'] as $key => $value) { ?>
						<option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
						<?php } ?>
					</select>                    
                </div>
                <?php } ?>
                <?php if(!empty($this->session->userdata('showFacilities'))){ ?>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_facility" name="search_facility" class="form-control" onchange="change_facility()" >
						<option value="">Select Facility</option>
						<?php  foreach ($search_options['Facility'] as $key => $value) {  ?>
						<option value="<?php echo $value['UserID']; ?>" ><?php echo $value['FacilityName']; ?></option>
						<?php } ?>
					</select>                    
                </div>
                <?php } ?>
                <div class="col-md-3 col-xs-12 mar-top-20">
                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" style="display: none;" />
                    <a href="javascript:void(0)" id="reset_btn" class="btn btn-primary">Reset</a>
                </div>
            </div>
            <hr>
	        <?php echo form_close(); ?>            	
	        </div>
	    	<?php } ?>		
			      
			      <table id="datatable" class="table table-striped table-bordered">
			        <thead>
			            <tr>
			                <th>SN</th>
			                <?php if($this->session->userdata('showState')){ ?>
			                <th>State</th>
			                <?php } ?>
			                <?php if($this->session->userdata('showDistrict')){ ?>
			                <th>District</th>
			                <?php } ?>
			                <?php if($this->session->userdata('showFacilities')){ ?>
			                <th>Facility</th>
			                <?php } ?>
			                <th>Anexture Date</th>
			                <th>Status</th>
			                <th width="300px">Action</th>
			            </tr>
			            </thead>
			            <tbody>
			            	<tr>
			            		<td></td>
				                <?php if($this->session->userdata('showState')){ ?>
				                <td></td>
				                <?php } ?>
				                <?php if($this->session->userdata('showDistrict')){ ?>
				                <td></td>
				                <?php } ?>
				                <?php if($this->session->userdata('showFacilities')){ ?>
				                <td></td>
				                <?php } ?>
			            		<td></td>
			                	<td></td>
			                	<td></td>
			            	</tr>
			            </tbody>
			      </table>
			    </div>
			  </div>
			</div>
		</div>        
    </div>
</div>

<!-- modal window start  -->
<div id="clientScoreModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">

    <!-- Modal content-->
    <div class="modal-content">
    	<button type="button" class="close pull-right" data-dismiss="modal">&times;</button>
              <div class="panel-body">
                <div class="text-center">
                  <h3><i class="fa fa-heart fa-4x"></i></h3>
                  <h2 class="text-center">Beneficiary Satisfaction Score?</h2>
                  <p>You can add  Beneficiary Satisfaction Score</p>
                  <div class="panel-body">
    
                    
    
                      <div class="form-group">
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-heart color-blue"></i></span>
                          <input maxlength="3" type="text" id="clientScore" name="clientScore" class="form-control nums" placeholder="Client Satisfaction Score">
                    <input type="hidden" id="assessmentID" name="assessmentID" class="form-control" readonly="readonly">

                        </div>
                      </div>
                      <div class="form-group">
                        <input id="clientScoreBtn" name="clientScoreBtn" type="button" class="btn btn-lg btn-primary btn-block" value="Submit Score" onclick="saveClientScore()" />
                        
                      </div>
                      
                     
                     
                  </div>
                </div>
              </div>

 
 
    </div>

  </div>
</div>
<!-- modal window end  -->
