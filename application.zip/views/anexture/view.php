<style>
    .col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}    
</style>


<div class="page-title">
  <div class="title_left">
    <h3>Anexture Form</h3>
  </div>

</div>

<div class="clearfix"></div>


<div class="main-content main-content-form-gr-h">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Anexture Form</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">                
                
                <div class="col-md-4">
                     <div class="form-group">
                    <label> State Name  : </label>
                    <span id="search_state" name="search_state"  ></span>
                    </div>                  
                </div>
                
                <div class="col-md-4">
                     <div class="form-group">
                      <label> District Name  : </label>
                        <span id="search_district" name="search_district"  ></span>
                    </div>                  
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label> Name of the Hospital  : </label>
                        <span id="facilityName" name="facilityName"  ></span>
                    </div>
                </div>
                <div class="col-md-4">
                        <div class="form-group">
                            <label> Date of Assessment  : </label>
                                <span id="submitDate" name="submitDate"  ></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 1 : </label>
                            <span id="checklist_1" name="checklist_1"  ></span>
                        </div>
                    </div>


                    <div class="col-md-12">
                        <div class="form-group">
                            <div class='input-group pull-right'>
                                <input type='hidden' name="anextureID" id="anextureID" value="<?php echo $this->uri->segment('3'); ?>" class="" />
                            </div>
                        </div>
                    </div>

            </div>
        </div>

            </div>
        </div>
    </div>
</div>