<div class="page-title">
  <div class="title_left">
    <h3>Users</h3>
  </div>
</div>
<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">

		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2><?php if(isset($facility)){ echo 'Add/Update Facility'; } else { echo 'Map Facility'; } ?> </h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">
			    	<?php if(isset($facility)){ ?>
					<?php if(isset($facilityUserID) && $facilityUserID>0){ ?>
			        <div class="alert alert-danger" id="" >
			          <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
			          <strong id="">Facility user already exist in LaQshay portal</strong>
			        </div>
					<?php } if(empty($facility['FacilityNumber'])){ ?>
			        <div class="alert alert-danger" id="" >
			          <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
			          <strong id="">Facility Not Found</strong>
			        </div>
					<?php } ?>
		            <form enctype="multipart/form-data" name="facilityForm" id="facilityForm" role="form" action="<?php echo base_url(). "ApiUser/addfacility"; ?>" method="post">             
		              
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label>Name</label>
		                  <input maxlength="99" class="form-control" placeholder="Name" id="FacilityName" name="FacilityName" type="text" value="<?php if(!empty($facility)){ echo $facility['FacilityName']; };  ?>" readonly="readonly" >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> NIN ID </label>
		                  <input maxlength="25" class="form-control" placeholder="NIN ID" id="FacilityNumber" name="FacilityNumber" type="text" value="<?php if(!empty($facility)){ echo $facility['FacilityNumber']; };  ?>" readonly="readonly"  >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> Type of Facility <span class="required"> * </span></label>
		                  <select id="FacilityTypeDetailID" name="FacilityTypeDetailID" class="selectpicker" data-live-search="true" data-width="100%" onchange="check_facility(this)">
		                    <option value="" >Select Facility Type</option>
		                    <?php foreach ($facility_types as $key => $value) { ?>
		                    <option value="<?php echo $value['TypeDetailID']; ?>" <?php if(isset($facility['FacilityTypeDetailID']) && $facility['FacilityTypeDetailID']==$value['TypeDetailID']){ echo ' selected="selected" '; } ?> ><?php echo $value['TypeDetailCode']; ?></option>
		                    <?php } ?>
		                </select>
		                </div>
		              </div>
		              <div class="col-md-6" >
		                <div class="form-group" style="display: <?php echo ($facility['FacilityTypeDetailID']=='440')?'':'none'; ?>;">
		                  <label>Other Type </label>
		                  <input maxlength="50" class="form-control" placeholder="Facility Type Other" id="facilitytype_other" name="facilitytype_other" type="text" value="<?php if(isset($facility)){ echo $facility['facilitytype_other']; };  ?>">
		                </div>
		              </div>
		              <div class="clearfix"></div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label>Address <span class="required"> * </span></label>
		                  <input maxlength="255" class="form-control" placeholder="Address" id="Address" name="Address" type="text" value="<?php if(!empty($facility)){ echo $facility['Address']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> State </label>
		                  <input maxlength="50" class="form-control" placeholder="State" id="StateName" name="StateName" type="text" value="<?php if(!empty($facility)){ echo $facility['StateName']; };  ?>" readonly="readonly"   >
		                  <input maxlength="50" class="form-control" placeholder="State" id="StateID" name="StateID" type="hidden" value="<?php if(!empty($facility)){ echo $facility['StateID']; };  ?>" readonly="readonly"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> District </label>
		                  <input maxlength="50" class="form-control" placeholder="District" id="DistrictName" name="DistrictName" type="text" value="<?php if(!empty($facility)){ echo $facility['DistrictName']; };  ?>" readonly="readonly"   >
		                  <input maxlength="50" class="form-control" placeholder="State" id="DistrictID" name="DistrictID" type="hidden" value="<?php if(!empty($facility)){ echo $facility['DistrictID']; };  ?>" readonly="readonly"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label>Pin Code </label>
		                  <input maxlength="6" class="form-control nums" placeholder="Pin Code" id="PinCode" name="PinCode" type="text" value="<?php if(!empty($facility)){ echo $facility['PinCode']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> Landline No. </label>
		                  <input class="form-control" placeholder="Landline No" id="landLine" name="landLine" type="text" value="<?php if(!empty($facility)){ echo $facility['landLine']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> Latitude <span class="required"> * </span></label>
		                  <input maxlength="50" class="form-control" placeholder="Latitude" id="Latitude" name="Latitude" type="text" value="<?php if(!empty($facility)){ echo $facility['Latitude']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> Longitude <span class="required"> * </span></label>
		                  <input maxlength="50" class="form-control" placeholder="Longitude" id="Longitude" name="Longitude" type="text" value="<?php if(!empty($facility)){ echo $facility['Longitude']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                <div class="form-group">
		                  <label> Altitude </label>
		                  <input maxlength="50" class="form-control" placeholder="Altitude" id="Altitude" name="Altitude" type="text" value="<?php if(!empty($facility)){ echo $facility['Altitude']; };  ?>"   >
		                </div>
		              </div>
		              <div class="col-md-6">
		                  <div class="form-group">
		                      <label>Services <span class="required"> * </span></label>
		                          <br>
		                      <label class="radio inline">
		                          <input id="services_lr" name="services" type="radio" onchange="checkFacilityAssessment(this)" value="lr" <?php if(isset($facility['services']) && $facility['services']=='lr'){ echo ' checked="checked"'; }  ?> >
		                          <span>LR </span>
		                      </label>

		                      <label class="radio inline">
		                          <input id="services_both" name="services" type="radio" onchange="checkFacilityAssessment(this)" value="both" <?php if(isset($facility['services']) && $facility['services']=='both'){ echo ' checked="checked"'; }  ?> >
		                          <span>LR & OT Both </span>
		                      </label>

		                  </div>
		              </div>
		              <div class="col-md-6">
		                  <div class="form-group">
		                      <!-- <label>OT Type </label> -->
		                          <br>
			                    <?php 
			                      $ot_services_disp='none';
			                      if($facility['services']=='both' && array_key_exists($facility['ot_services'], $this->config->item('ot_services'))) { $ot_services_disp=''; } 
			                      ?>
			                      <label class="radio inline" style="display: <?php echo $ot_services_disp; ?>;" >
			                          <input id="both_gen" name="ot_services" type="radio" onchange="" value="gen"  <?php if(isset($facility['ot_services']) && $facility['ot_services']=='gen'){ echo ' checked="checked"'; }  ?> >
			                          <span>General OT</span>
			                      </label>

			                      <label class="radio inline" style="display: <?php echo $ot_services_disp; ?>;" >
			                          <input id="both_met" name="ot_services" type="radio" onchange="" value="met" <?php if(isset($facility['ot_services']) && $facility['ot_services']=='met'){ echo ' checked="checked"'; }  ?> >
			                          <span>Meternity OT</span>
			                      </label>
		                  </div>
		              </div>
		              <div class="clearfix"></div>

		              <div class="col-md-12"></div>
		              <div class="col-md-12 deffr_head">
		                <h4>Facility</h4>
		              </div>
		              <div class="col-md-6">
		                <div class="row">
		                  <div class="col-md-12">
		                    <div class="form-group">
		                      <label>First Name <span class="required"> * </span> </label>
		                      <input maxlength="30" class="form-control" placeholder="First Name" id="FirstName_main" name="FirstName_main" type="text" value="<?php if(isset($main['FirstName'])){ echo $main['FirstName']; } ?>"   >
		                    </div>
		                  </div>
		                  <div class="col-md-12">
		                    <div class="form-group">
		                      <label> Last Name <!-- <span class="required"> * </span> --> </label>
		                      <input maxlength="30" class="form-control" placeholder="Last Name" id="LastName_main" name="LastName_main" type="text" value="<?php if(isset($main['LastName'])){ echo $main['LastName']; } ?>"   >
		                    </div>
		                  </div>
		                  <div class="col-md-12">
		                    <div class="form-group">
		                      <label> Incharge Designation <!-- <span class="required"> * </span> --> </label>
		                      <input maxlength="50" class="form-control" placeholder="Incharge Designation_main" id="Designation_main" name="Designation_main" type="text" value="<?php if(isset($main['Designation'])){ echo $main['Designation']; } ?>"   >
		                    </div>
		                  </div>
		                  <div class="col-md-12">
		                    <div class="form-group">
		                      <label> Mobile No. <span class="required"> * </span> </label>
		                      <input maxlength="10" class="form-control nums" placeholder="Mobile No" id="Mobile_main" name="Mobile_main" type="text" value="<?php if(isset($main['Mobile'])){ echo $main['Mobile']; } ?>"   >
		                    </div>
		                  </div>
		                  <div class="col-md-12">
		                    <div class="form-group">
		                      <label>Email Address <span class="required"> * </span> </label>
		                      <input maxlength="254" class="form-control emailID" placeholder="Email Address" id="Email_main" name="Email_main" type="text" value="<?php if(isset($main['Email'])){ echo $main['Email']; } ?>"   >
		                    </div>
		                  </div>
		                </div>
		              </div>
		              <div class="col-md-6 user_img">
		                <center>
		                  <?php 
		                  if(!empty($main['Pic']) && is_file($main['Pic'])){
		                    $pathMain=$main['Pic'];
		                  } else {
		                    $pathMain='assets/images/user.png';
		                  }
		                  ?>
		                  <img src="<?php echo base_url().$pathMain;?>">
		                  <!-- <p>Image Name</p> -->
		                  <div class="form-group">                    
		                    <br>
		                    <input type="file" id="Pic_main" name="Pic_main" accept=".png,.jpg,.jpeg,.bmp,.PNG,.JPG,.JPEG,.BMP" onchange="checkFile(this)" class="inputfile inputfile-6 form-control" />
		                    <label for="Pic_main"><span></span> <strong><i class="fa fa-upload"></i> Choose a file&hellip;</strong></label>
		                  </div>
		                </center>
		              </div>
		              <div class="clearfix"></div>
		              
		              <div class="col-md-12">
		                <div class="form-group">
		                  <div class='input-group pull-right'>
		                  	<input maxlength="50" class="form-control" placeholder="FacilityID" id="FacilityID" name="FacilityID" type="hidden" value="<?php if(isset($facility['FacilityID'])){ echo $facility['FacilityID']; };  ?>" readonly="readonly"   >
		                    <input style="margin-top: 15px; margin-right: 20px;" type='submit' id="profileBtn" name="profileBtn" value="Save" class="btn btn-info" />
		                    <input type="button" style="margin-top: 15px; margin-right: 0px;" data-href="<?php echo base_url().'user/mapfacility'; ?>" class="btn btn-danger" onclick="pageRedirect(this)" value="Cancel" >
		                  </div>
		                </div>
		              </div>                    
		            </form>

			    	<?php } else { ?>
				    <div class="row">
				        <div class="col-md-12">
				        	<div class="well">
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                	<select id="search_state" name="search_state" onchange="change_state()" class="form-control">
									<option value="0">Select State</option>
								</select>                    
			                </div>
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                	<select id="search_district" name="search_district" onchange="" class="form-control">
									<option value="0">Select District</option>
								</select>                    
			                </div>
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                	<select id="opt" name="opt" onchange="change_type(this)" class="form-control">
									<option value="1">Laqshya Facility</option>
									<option value="0">InActive Facility</option>
								</select>                    
			                </div>
			                <div class="col-md-3 col-xs-12 mar-top-20">
			                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" />
			                    <a href="javascript:void(0)" id="reset_btn" class="btn btn-primary">Reset</a>
			                </div>
			                <?php if($this->CommonModel->checkPageActionWeb('user/mapfacility','access_edit',$this->session->userdata('RoleName'))){ ?>
			                <div class="col-md-2 col-xs-6 mar-top-20">
			                    <input id="search-nin-btn" name="search-nin-btn" type="button" class="btn btn-primary" value="Search Facility Details" data-toggle="modal" data-target="#searchNinModal" />
			                </div>
			            	<?php } ?>
			                <?php if($this->CommonModel->checkPageActionWeb('user/mapfacility','access_edit',$this->session->userdata('RoleName'))){ ?>
			                <div class="col-md-2 col-xs-6 mar-top-20">
			                    <input id="btn_facility_add" name="btn_facility_add" type="button" class="btn btn-primary" value="Add Facility" data-toggle="modal" data-target="#addFacilityModal" />
			                </div>
			            	<?php } ?>
			                <?php if($this->CommonModel->checkPageActionWeb('user/mapfacility','access_edit',$this->session->userdata('RoleName'))){ ?>
			                <div class="col-md-2 col-xs-6 mar-top-20">
			                    <input id="btn_facility_map" name="btn_facility_map" type="button" class="btn btn-primary" value="Map Facility to Laqshya" onclick="map_user('1')" disabled="disabled" />
			                </div>
			                <?php } ?>
			                <?php if($this->CommonModel->checkPageActionWeb('user/mapfacility','access_edit',$this->session->userdata('RoleName'))){ ?>
			                <div class="col-md-3 col-xs-6 mar-top-20">
			                    <input id="btn_facility_remove" name="btn_facility_remove" type="button" class="btn btn-primary" value="Remove Facility From Laqshya" onclick="map_user('0')" />
			                </div>
			            	<?php } ?>
			                <?php if($this->CommonModel->checkPageActionWeb('user/mapfacility','access_edit',$this->session->userdata('RoleName'))){ ?>
			                <!-- <div class="col-md-2 col-xs-6 mar-top-20">
			                    <input id="btn_facility_type_add" name="btn_facility_type_add" type="button" class="btn btn-primary" value="Add Facility Type" data-toggle="modal" data-target="#addFacilityTypeModal" />
			                </div> -->
			            	<?php } ?>
			            </div>
			            </div>
				    </div>
				      <table id="datatable" class="table table-striped table-bordered">
				        	<thead>
				            <tr>
				                <th>SN.</th>
				                <th>State</th>
				                <th>District</th>
				                <th>Facility</th>
				                <th>Nin Number</th>
				                <th>Is Laqshya</th>
				            </tr>
				        	</thead>
				            <tbody>
				            	<tr>
				            		<td></td>
				            		<td></td>
				                	<td></td>
				                	<td></td>
				                	<td></td>
				                	<td></td>
				            	</tr>
				            </tbody>
				      </table>
				    <?php } ?>
			    </div>
			  </div>
			</div>
			<form name="failitiesAdd" id="failitiesAdd" class="login-form" action="<?php echo base_url() . "ApiUser/AddFacility" ?>" method="post" style="display: none;">
				
			</form>
		</div>        
    </div>
</div>

<!-- facility add modal start -->
  <div class="modal fade" id="addFacilityModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add/Update Facility Deatils</h4>
        </div>
        <div class="modal-body">
		    <div class="row">
		        <div class="col-md-12">
		        	<div class="well">
		                <div class="col-md-6 col-xs-12 mar-top-20">
		                	<input type="text" name="" maxlength="99" class="form-control" placeholder="NIN Number" id="FacilityNumberSearch" name="FacilityNumberSearch">
		                </div>
		                <div class="col-md-6 col-xs-12 mar-top-20">
		                    <input id="btn_search_nin" name="btn_search_nin" type="button" class="btn btn-danger" value="Get Details" />
		                </div>
	            	</div>
	            </div>
		    </div>

        </div>
        <div class="modal-footer">
        	<!-- <input disabled="true" type='submit' id="saveFacilityBtn" name="saveFacilityBtn" value="Save" class="btn btn-info" /> -->
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!-- facility add modal end -->
<!-- facility Type add modal start -->
  <div class="modal fade" id="addFacilityTypeModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Facility Type</h4>
        </div>
        <div class="modal-body">
		    <div class="row">
		        <div class="col-md-12">
		        	<div class="well">
		                <div class="col-md-6 col-xs-12 mar-top-20">
		                	<input type="text" name="" maxlength="99" class="form-control" placeholder="Facility Type" id="FacilityTypeSearch" name="FacilityTypeSearch">
		                </div>
		                <div class="col-md-6 col-xs-12 mar-top-20">
		                    <input id="btn_search_type" name="btn_search_type" type="button" class="btn btn-danger" value="Save" />
		                </div>
	            	</div>
	            </div>
		    </div>
		    <div class="row">
				<table id="facilityTypeData" class="table table-striped table-bordered" style="width: 100%;">
					<thead>
				    <tr>
				        <th>SN.</th>
				        <th>Facility Type</th>
				    </tr>
					</thead>
				    <tbody>
				    </tbody>
				</table>
		    </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!-- facility Type add modal end -->