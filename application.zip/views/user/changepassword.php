<style>
    .col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}
    
</style>


<div class="page-title">
  <div class="title_left">
    <h3>Change Password</h3>
  </div>

  <!--<div class="title_right">
    <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
      <div class="input-group" style="float: right;">
        <a href="<?php echo base_url(). "facility/assesment"; ?>" id="addBtn" class="btn btn-success disabled pull-right">Add</a>
      </div>
    </div>
  </div>-->
</div>

<div class="clearfix"></div>


<div class="main-content main-content-form-gr-h">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Change Password</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <form name="changepasswordForm" id="changepasswordForm" role="form" action="<?php echo base_url()."ApiUser/changepassword"?>" method="post">                

                  <div class="col-md-4">
                      <div class="form-group">
                          <label> Old password <span class="required"> * </span> </label>
                          <input class="form-control" placeholder="Enter Old Password" id="oldPassword" name="oldPassword" type="password" value=""   >
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label> New password <span class="required"> * </span> </label>
                          <input class="form-control" placeholder="Enter New Password" id="newPassword" name="newPassword" type="password" value=""   >
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <label> Confirm password <span class="required"> * </span> </label>
                          <input class="form-control" placeholder="Re-Enter New Password" id="confirmPassword" name="confirmPassword" type="password" value=""   >
                      </div>
                  </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <div class='input-group pull-right'>
                                <input style="margin-top: 15px; margin-right: 0px;" type='submit' id="changepasswordBtn" name="changepasswordBtn" value="Submit" class="btn btn-info" />
                            </div>
                        </div>
                    </div>                    
                </form>
            </div>
        </div>

            </div>
        </div>
    </div>
</div>