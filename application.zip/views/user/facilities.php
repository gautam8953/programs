<div class="page-title">
  <div class="title_left">
    <h3>User Facility</h3>
  </div>
</div>
<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">
	    <div class="row">
	        <div class="col-md-12 ">
	        	<div class="well">
                <div class="col-md-3">
                	<select id="search_state" name="search_state" onchange="change_state()" class="form-control">
						<option value="">Select State</option>
					</select>                    
                </div>
                <div class="col-md-3">
                	<select id="search_district" name="search_district" onchange="" class="form-control">
						<option value="">Select District</option>
					</select>                    
                </div>
                <div class="col-md-3">
                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" />
                    <a href="javascript:void(0)" id="reset_btn" class="btn btn-primary">Reset</a>
                    <input id="btn_user" name="btn_user" type="button" class="btn btn-primary" value="Create User" onclick="create_user()" />
                </div>            	
	        </div>
	        </div>
	    </div>
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Manage Assessment</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">			      
			      <table id="datatable" class="table table-striped table-bordered">
			        <thead>
			            <tr>
			                <th></th>
			                <th>State</th>
			                <th>District</th>
			                <th>Facility</th>
			            </tr>
			            </thead>
			            <tbody>
			            	<tr>
			            		<td></td>
			                	<td></td>
			                	<td></td>
			                	<td></td>
			            	</tr>
			            </tbody>
			      </table>
			    </div>
			  </div>
			</div>
			<form name="failitiesAdd" id="failitiesAdd" class="login-form" action="<?php echo base_url() . "ApiUser/AddFacility" ?>" method="post" style="display: none;">
				
			</form>
		</div>        
    </div>
</div>