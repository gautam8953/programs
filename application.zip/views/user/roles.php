<style>
    .col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}
    
</style>

<div class="page-title">
  <div class="title_left">
    <h3>Roles</h3>
  </div>
</div>

<div class="clearfix"></div>

<div class="main-content main-content-form-gr-osce">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Roles</h2>
                  <?php if($this->CommonModel->checkPageActionWeb('user/roles','access_add',$this->session->userdata('RoleName'))){ ?>
                  <a href="<?php echo base_url().'user/rolesadd'; ?>" class="btn btn-primary pull-right">Add Roles</a>
                <?php } ?>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                
                <div class="col-md-12 col-sm-12 col-xs-12" style="overflow-y: auto;">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Sn.</th>
                        <th>Role Name</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php 
                      if(!empty($roles)){
                      $access_edit=$this->CommonModel->checkPageActionWeb('user/roles','access_edit',$this->session->userdata('RoleName'));
                      $i=0;
                      foreach ($roles as $key => $value) { ?>
                      <tr>
                        <th scope="row"><?php echo ++$i; ?></th>
                        <td><?php echo $value['RoleName']; ?></td>
                        <td><?php echo $value['IsActive']=='1'?'Active':'In-Active'; ?></td>
                        <td>
                          <?php if($access_edit){ ?>
                          <a href="<?php echo base_url().'user/rolesadd/'.encryptor($value['RoleID']); ?>" class="btn btn-primary btn-xs view_edit_width" ><i class="glyphicon glyphicon-check"></i>Edit</a>
                          <?php } ?>
                        </td>
                      </tr>
                      <?php } ?>
                      <?php } else { ?>
                      <tr>
                        <th colspan="11" align="center" class="font-bold">No record found </th>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>
              </div>
              
            </div>
        </div>

            </div>
        </div>

        
    </div>
</div>

<style>
  .table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 8px;
    line-height: 1.42857143;
    border: 1px solid #ddd !important;
}

.table thead tr th{background: #337ab7;
                  color: #fff;
                  border: 1px solid #16558c !important;
                  border-bottom: 3px solid #16558c !important;}
</style>