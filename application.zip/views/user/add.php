<style>
.col-md-4 .bootstrap-select button,
input {
    margin-bottom: 7px !important;
}
</style>

<div class="page-title">
    <div class="title_left full-width">
        <h3>Users</h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="main-content main-content-form-gr-h ApplyFor_center newap-cneter carti-c">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Add User</h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <form name="userForm" id="userForm" class="login-form login_form_mine" action="<?php echo base_url()."ApiUser/add"?>">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Is Admin<span class="required"> * </span> </label>
                        <select id="usertype" name="usertype" class="selectpicker" onchange="is_admin();" data-live-search="true" data-width="100%">
                          <option value="0" <?php if(isset($userdata) && $userdata['usertype']=='0'){ echo ' selected="selected" '; } ?> >No</option>
                          <option value="1" <?php if(isset($userdata) && $userdata['usertype']=='1'){ echo ' selected="selected" '; } ?> >Yes</option>
                      </select>
                  </div>
              </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Role Name<span class="required"> * </span> </label>
                        <select id="RoleID" name="RoleID" class="selectpicker" data-live-search="true" data-width="100%">
                          <?php foreach ($roles as $key => $value) { ?>
                              <option value="<?php echo $value['RoleID']; ?>" <?php if(isset($userdata) && $value['RoleID']==$userdata[ 'RoleID']){ echo ' selected="selected" '; } ?> >
                                  <?php echo $value['RoleName']; ?>
                              </option>
                          <?php } ?>
                      </select>
                  </div>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                      <label>Name<span class="required"> * </span> </label>
                      <input minlength="1" maxlength="30" type="text" id="FirstName" name="FirstName" class="form-control" placeholder="Name" value="<?php echo empty($userdata['FirstName'])?'':$userdata['FirstName']; ?>">
                  </div>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                      <label>Email<span class="required"> * </span> </label>
                      <input minlength="1" maxlength="30" type="text" id="Email" name="Email" class="form-control emailID" placeholder="Email-ID" value="<?php echo empty($userdata['Email'])?'':$userdata['Email']; ?>">
                  </div>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                      <label>Phone Number<span class="required"> * </span> </label>
                      <input minlength="1" maxlength="10" type="text" id="Mobile" name="Mobile" class="form-control nums" placeholder="Mobile Number" value="<?php echo empty($userdata['Mobile'])?'':$userdata['Mobile']; ?>">
                  </div>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                      <label>Password<span class="required"> * </span> </label>
                      <input minlength="1" maxlength="30" type="password" id="Password" name="Password" class="form-control" placeholder="Password" value="<?php echo empty($userdata['Password'])?'':$userdata['Password']; ?>">
                  </div>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                      <label>Re-Enter Password<span class="required"> * </span> </label>
                      <input minlength="1" maxlength="30" type="password" id="Password1" name="Password1" class="form-control" placeholder="Re-enter Password" value="<?php echo empty($userdata['Password'])?'':$userdata['Password']; ?>">
                  </div>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                      <label>User Name<span class="required"> * </span> </label>
                      <input <?php if(isset($userdata)){ echo ' readonly="readonly" '; } ?> minlength="1" maxlength="30" type="text" id="UserName" name="UserName" class="form-control" placeholder="User name" value="<?php echo empty($userdata['UserName'])?'':$userdata['UserName']; ?>" onchange="checkusername()">
                  </div>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Status<span class="required"> * </span> </label>
                        <select id="IsActive" name="IsActive" class="selectpicker" data-live-search="true" data-width="100%">
                              <option value="1" <?php if(isset($userdata) && $userdata['IsActive']=='1'){ echo ' selected="selected" '; } ?> >Active</option>
                              <option value="0" <?php if(isset($userdata) && $userdata['IsActive']=='0'){ echo ' selected="selected" '; } ?> >In-Active</option>
                      </select>
                  </div>
              </div>

              <div class="col-md-6 col-sm-6 col-xs-12 state">
                    <div class="form-group">
                        <label>State<span class="required"> * </span> </label>
                        <select data-live-search="true" id="search_state" name="search_state[]" class="selectpicker" onchange="change_state();" data-width="100%" multiple="multiple">
                        </select>
                  </div>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12 district">
                    <div class="form-group">
                        <label>District<span class="required"> * </span> </label>
                        <select data-live-search="true" id="search_district" name="search_district[]" class="selectpicker" onchange="change_district();" data-width="100%" multiple="multiple">
                        </select>
                  </div>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12 facility">
                    <div class="form-group">
                        <label>Facility<span class="required"> * </span> </label>
                        <select data-live-search="true" id="FacilityName" name="FacilityName[]" class="selectpicker" onchange="change_facility();" data-width="100%" multiple="multiple">
                        </select>
                  </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="form-group">
                      <div class='input-group pull-right'>
                          <input type="hidden" name="UserID" id="UserID" value="<?php echo $this->uri->segment('3'); ?>">
                          <input type="hidden" id="StateID" name="StateID" class="form-control" value="<?php echo empty($userdata['mapping']['StateID'])?'':$userdata['mapping']['StateID']; ?>">
                          <input type="hidden" id="DistrictID" name="DistrictID" class="form-control" value="<?php echo empty($userdata['mapping']['DistrictID'])?'':$userdata['mapping']['DistrictID']; ?>">
                          <input type="hidden" id="FacilityID" name="FacilityID" class="form-control" value="<?php echo empty($userdata['mapping']['FacilityID'])?'':$userdata['mapping']['FacilityID']; ?>">
                          <input style="margin-top: 15px; margin-right: 0px;" type='submit' id="userFrm" name="userFrm" value="Save" class="btn btn-info" />
                      </div>
                  </div>
              </div>
            </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
