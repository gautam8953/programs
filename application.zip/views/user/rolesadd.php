<style>
    .col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}
    
</style>

<div class="page-title">
  <div class="title_left">
    <h3>Roles</h3>
  </div>
</div>

<div class="clearfix"></div>

<div class="main-content main-content-form-gr-osce">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <?php 
                  if(empty($RoleID)){
                    $accessVar='Add';
                  } else {
                    $accessVar='Edit';
                  }
                  ?>
                  <h2><?php echo $accessVar; ?> Roles</h2>
                  
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">

                <form id="roleForm" name="roleForm" role="form" action="<?php echo base_url()."ApiUser/rolesadd"?>" method="post">                
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Role Name<span class="required"> * </span> </label>
                        <input minlength="1" maxlength="100" type="text" id="RoleName" name="RoleName"  class="form-control" placeholder="Role Name" value="<?php echo isset($roleForm['RoleName'])?$roleForm['RoleName']:''; ?>" >
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Status<span class="required"> * </span> </label>
                        <select name="IsActive" id="IsActive" class="form-control">
                            <option value="1" <?php if((isset($roleForm['IsActive']) && $roleForm['IsActive']=='1')){ echo ' selected="selected" '; } ?> >Active</option>
                            <option value="0" <?php if((isset($roleForm['IsActive']) && $roleForm['IsActive']=='0')){ echo ' selected="selected" '; } ?> >InActive</option>
                        </select>
                    </div>
                </div>

                <div class="col-md-12 col-sm-12 col-xs-12">
                  <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                            <th>SN.</th>
                            <th>Module</th>
                            <th>Form</th>
                            <th>Add</th>
                            <th>Edit</th>
                            <th>Delete</th>
                            <th>View</th>
                        </tr>
                      </thead>
                        <tbody>
                          <?php 
                          if(!empty($this->uri->segment('3'))){
                            $RoleID=encryptor($this->uri->segment('3'),'decrypt');
                          } else {
                            $RoleID=0;
                          }                          
                          $j=0;
                          $moduleName='' ;
                          foreach ($urls as $keyUrl => $valueUrl) {
                          $pages=explode(',', $valueUrl['pages']);
                          if($moduleName!=$valueUrl['moduleName']){
                            $k=0;
                          ?>
                          <tr>
                            <td><?php echo ++$j; ?></td>
                            <td><?php echo $valueUrl['moduleName']; ?></td>
                            <td colspan="5"></td>
                          </tr>
                          <?php } ?>
                          <tr>
                            <td><?php echo $j.'.'.++$k; ?></td>
                            <td></td>
                            <td><?php echo $valueUrl['formName']; ?></td>
                            <td><input type="checkbox" name="access[<?php echo $RoleID; ?>][<?php echo $valueUrl['id']; ?>][1]" id="<?php echo 'add_'.$RoleID.'_'.$valueUrl['moduleID'].'_'.$valueUrl['id'] ?>" <?php echo (isset($getUserAccess[$RoleID][$valueUrl['id']]) && $getUserAccess[$RoleID][$valueUrl['id']]['access_add']=='1')?'checked':''; ?> <?php if(!in_array('page_add', $pages)){ echo ' disabled="disabled"'; } ?> ></td>
                            <td><input type="checkbox" name="access[<?php echo $RoleID; ?>][<?php echo $valueUrl['id']; ?>][2]" id="<?php echo 'edit_'.$RoleID.'_'.$valueUrl['moduleID'].'_'.$valueUrl['id'] ?>" <?php echo (isset($getUserAccess[$RoleID][$valueUrl['id']]) && $getUserAccess[$RoleID][$valueUrl['id']]['access_edit']=='1')?'checked':''; ?> <?php if(!in_array('page_edit', $pages)){ echo ' disabled="disabled"'; } ?> ></td>
                            <td><input type="checkbox" name="access[<?php echo $RoleID; ?>][<?php echo $valueUrl['id']; ?>][3]" id="<?php echo 'delete_'.$RoleID.'_'.$valueUrl['moduleID'].'_'.$valueUrl['id'] ?>" <?php echo (isset($getUserAccess[$RoleID][$valueUrl['id']]) && $getUserAccess[$RoleID][$valueUrl['id']]['access_delete']=='1')?'checked':''; ?> <?php if(!in_array('page_delete', $pages)){ echo ' disabled="disabled"'; } ?> ></td>
                            <td><input type="checkbox" name="access[<?php echo $RoleID; ?>][<?php echo $valueUrl['id']; ?>][4]" id="<?php echo 'view_'.$RoleID.'_'.$valueUrl['moduleID'].'_'.$valueUrl['id'] ?>" <?php echo (isset($getUserAccess[$RoleID][$valueUrl['id']]) && $getUserAccess[$RoleID][$valueUrl['id']]['access_view']=='1')?'checked':''; ?> <?php if(!in_array('page_view', $pages)){ echo ' disabled="disabled"'; } ?> ></td>
                          </tr>
                          <input type="hidden" name="access[<?php echo $RoleID; ?>][<?php echo $valueUrl['id']; ?>][5]" value="1">
                          <?php $moduleName=$valueUrl['moduleName']; } ?>
                          
                          <?php if($this->CommonModel->checkPageActionWeb('user/role_management','access_edit',$this->session->userdata('RoleName'))){ ?>
                          <!-- <tr>
                            <td colspan="6"></td>
                            <td><input class="btn btn-primary" type="submit" id="save" name="save"></td>
                          </tr> -->
                          <?php } ?>
                        </tbody>
                  </table>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <div class='input-group pull-right'>
                            <input type="hidden" name="RoleID" id="RoleID" value="<?php echo $this->uri->segment('3'); ?>">
                            <input style="margin-top: 15px; margin-right: 0px;" type='submit' id="RoleFrm" name="RoleFrm" value="Save" class="btn btn-info" />
                        </div>
                    </div>
                </div>
                </form>

            </div>
        </div>

            </div>
        </div>

        
    </div>
</div>

<style>
  .table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 8px;
    line-height: 1.42857143;
    border: 1px solid #ddd !important;
}

.table thead tr th{background: #337ab7;
                  color: #fff;
                  border: 1px solid #16558c !important;
                  border-bottom: 3px solid #16558c !important;}
</style>