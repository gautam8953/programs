<div class="page-title">
  <div class="title_left">
    <h3>Dashboard</h3>
  </div>

  
</div>

<div class="clearfix"></div>

<div class="main-content"> 
  <div class="container">
    <div class="row">
     <div class="col-md-12 col-md-12 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>LA<span style="color: #aa1e1e;">Q</span>SHYA Assessment Status</h2>
        </div>
        <div class="x_content x_content_facility">
          <div class="facility_dashboard_x_content">
        <div class="row activity_row">
          <div class="col-md-4 col-sm-4 col-xs-4">
                <p><b>Activity</b></p>
            </div>
            
            <div class="col-md-2 col-sm-2 col-xs-2">
              <p><b>Status</b></p>
            </div>
            
            <div class="col-md-3 col-sm-3 col-xs-3">
              <p><b>Date</b></p>
            </div>
            
            <div class="col-md-3 col-sm-3 col-xs-3">
              <p><b>Action</b></p>
            </div>
        </div>



       <ul class="list-unstyled timeline">
        <li>
          <div class="row marclass">
              <div class="col-md-4 col-sm-4 col-xs-4">
          
             
                <div class="tags">
                  <a class="tag">
                    <span>LR Assessment
                    <?php                 
                     if(isset($data['LR']['Sequence']) && !empty($data['LR']['Sequence'])){ 
                      $surveyFormLevel=$this->config->item('assesmentSequence');
                      if(array_key_exists($data['LR']['Sequence'], $surveyFormLevel)){
                          $surveyFormLevelTxt=$surveyFormLevel[$data['LR']['Sequence']];
                      } else {
                          $surveyFormLevelTxt='';
                      }                      
                      echo $surveyFormLevelTxt; 
                      } ?>
                    </span>
                  </a>
                </div>
            </div>
            <div class="block_content block_content_mine">             
               <div class="col-md-2 col-sm-2 col-xs-2">
                <?php if(isset($data['LR']['AnswerID'])){ ?>
                  <?php if(isset($data['LR']['SurveyStatus']) && $data['LR']['SurveyStatus']=='1'){ ?>
                    <img width="30px" src="<?php echo base_url()?>assets/images/status-done.png" title="Done">
                  <?php } else { ?>
                    <img width="30px" src="<?php echo base_url()?>assets/images/status-inprocess.png"  title="In Process">
                  <?php } ?>
                <?php } else { ?>
                  <img width="30px" src="<?php echo base_url()?>assets/images/wrong.png" title="Not Started" >
                <?php } ?>
              </div>
            <div class="col-md-3 col-sm-3 col-xs-3">
              <p><?php if(isset($data['LR']['AssessmentDate'])){ echo convert_date_show($data['LR']['AssessmentDate']); } ?></p>
            </div>


            <div class="col-md-3 col-sm-3 col-xs-3">
              <?php 
              $access_LR_add=$this->CommonModel->checkPageActionWeb('facility/checklist/'.encryptor(1),'access_add',$this->session->userdata('RoleName'));
              $access_LR_edit=$this->CommonModel->checkPageActionWeb('facility/checklist/'.encryptor(1),'access_edit',$this->session->userdata('RoleName'));
              $access_LR_view=$this->CommonModel->checkPageActionWeb('facility/checklist/'.encryptor(1),'access_view',$this->session->userdata('RoleName'));
              ?>
              <?php if(isset($data['LR']['AnswerID'])){ ?>
              <?php if($data['LR']['SurveyStatus']=='1'){ ?>
                <?php if($access_LR_view){ ?>
                <a href="<?php echo base_url(). "facility/viewscore/".encryptor($data['LR']['AnswerID']); ?>" class="btn btn-info btn-info-view ">View</a>
                <?php } else { ?>
                <a href="#" class="btn btn-info btn-info-view disabled">View</a>
                <?php } ?>
              <?php } else { ?>
                <?php if($access_LR_add){ ?>
                  <a href="<?php echo base_url(). "facility/checklist/".encryptor('1').'/'.encryptor($data['LR']['AnswerID']); ?>" class="btn btn-info btn-info-edit">Draft</a>
                <?php } else { ?>
                <a href="#" class="btn btn-info btn-info-edit disabled">Draft</a>
                <?php } ?>
              <?php } } else { ?>
                <?php if($access_LR_add){ ?>
                  <a href="<?php echo base_url(). "facility/checklist/".encryptor('1'); ?>" class="btn btn-info btn-info-add">Add</a>
                <?php } else { ?>
                <a href="#" class="btn btn-info btn-info-add disabled">Add</a>
                <?php } ?>
              <?php } ?>
            </div>                        

          </div>
        </div>
      </li>
      <?php if($data['facilityType']=='both'){ ?>
      <li>
        <div class="row marclass">
            <div class="col-md-4 col-sm-4 col-xs-4">
        <div class="blockk">
          
              <div class="tags">
                <a class="tag">
                  <span>OT Assessment
                  <?php if(isset($data['OT']['Sequence']) && !empty($data['OT']['Sequence'])){ 
                      $surveyFormLevel=$this->config->item('assesmentSequence');
                      if(array_key_exists($data['OT']['Sequence'], $surveyFormLevel)){
                          $surveyFormLevelTxt=$surveyFormLevel[$data['OT']['Sequence']];
                      } else {
                          $surveyFormLevelTxt='';
                      }                      
                      echo $surveyFormLevelTxt;
                    } ?>
                  </span>
                </a>
              </div>
            </div>
          </div>
          <div class="block_content block_content_mine">           
             <div class="col-md-2 col-sm-2 col-xs-2">
                <?php if(isset($data['OT']['AnswerID'])){ ?>
                  <?php if(isset($data['OT']['SurveyStatus']) && $data['OT']['SurveyStatus']=='1'){ ?>
                    <img width="30px" src="<?php echo base_url()?>assets/images/status-done.png" title="Done">
                  <?php } else { ?>
                    <img width="30px" src="<?php echo base_url()?>assets/images/status-inprocess.png"  title="In Process">
                  <?php } ?>
                <?php } else { ?>
                <img width="30px" src="<?php echo base_url()?>assets/images/wrong.png"  title="Not Started" >
                <?php } ?>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-3">
              <p><?php if(isset($data['OT']['AssessmentDate'])){ echo convert_date_show($data['OT']['AssessmentDate']); } ?></p>
            </div>


            <div class="col-md-3 col-sm-3 col-xs-3">
                <?php 
                  $access_OT_add=$this->CommonModel->checkPageActionWeb('facility/checklist/'.encryptor(2),'access_add',$this->session->userdata('RoleName'));
                  $access_OT_edit=$this->CommonModel->checkPageActionWeb('facility/checklist/'.encryptor(2),'access_edit',$this->session->userdata('RoleName'));
                  $access_OT_view=$this->CommonModel->checkPageActionWeb('facility/checklist/'.encryptor(2),'access_view',$this->session->userdata('RoleName'));
                ?>
                <?php if(isset($data['OT']['AnswerID'])){ ?>
                <?php if($data['OT']['SurveyStatus']=='1'){ ?>
                  <?php if($access_OT_view){ ?>
                  <a href="<?php echo base_url(). "facility/viewscore/".encryptor($data['OT']['AnswerID']); ?>" class="btn btn-info btn-info-view">View</a>
                  <?php } else { ?>
                  <a href="#" class="btn btn-info btn-info-view disabled">View</a>
                  <?php } ?>
                <?php } else { ?>
                  <?php if($access_OT_add){ ?>
                  <a href="<?php echo base_url(). "facility/checklist/".encryptor('2').'/'.encryptor($data['OT']['AnswerID']); ?>" class="btn btn-info btn-info-edit">Draft</a>
                  <?php } else { ?>
                    <a href="#" class="btn btn-info btn-info-edit disabled">Draft</a>
                  <?php } ?>
                <?php } } else { ?>
                  <?php if($access_OT_add){ ?>
                    <a href="<?php echo base_url(). "facility/checklist/".encryptor('2'); ?>" class="btn btn-info btn-info-add">Add</a>
                  <?php } else { ?>
                    <a href="#" class="btn btn-info btn-info-add disabled">Add</a>
                  <?php } ?>
                <?php } ?>
            </div>                        

        </div>
      </div>
    </li>
    <?php } ?>
    <li>
      <div class="row marclass">
        <div class="col-md-4 col-sm-4 col-xs-4">
            <div class="tags">
              <a class="tag">
                <span>Monthly Reporting</span>
              </a>
            </div>
        </div>
        <div class="block_content block_content_mine">
         
           <div class="col-md-2 col-sm-2 col-xs-2">
              <?php if(isset($data['monthly']['MonthlyID'])){ ?>
                <?php if(isset($data['monthly']['MonthlyStatus']) && $data['monthly']['MonthlyStatus']=='1'){ ?>
                  <img width="30px" src="<?php echo base_url()?>assets/images/status-done.png" title="Done">
                <?php } else { ?>
                  <img width="30px" src="<?php echo base_url()?>assets/images/status-inprocess.png" title="In Process">
                <?php } ?>
              <?php } else { ?>
              <img width="30px" src="<?php echo base_url()?>assets/images/wrong.png"  title="Not Started" >
              <?php } ?>
          </div>
       


        <div class="col-md-3 col-sm-3 col-xs-3">
          <p><?php if(isset($data['monthly']['ReportMonth']) && !empty($data['monthly']['ReportMonth']) && $data['monthly']['ReportMonth']!='0000-00-00'){ echo date('F Y', strtotime($data['monthly']['ReportMonth'])); } ?></p>
        </div>


        <div class="col-md-3 col-sm-3 col-xs-3">
            <?php 

              $access_monthly_add=$this->CommonModel->checkPageActionWeb('monthly/add','access_add',$this->session->userdata('RoleName'));
              $access_monthly_edit=$this->CommonModel->checkPageActionWeb('monthly/index','access_edit',$this->session->userdata('RoleName'));
              $access_monthly_view=$this->CommonModel->checkPageActionWeb('monthly/index','access_view',$this->session->userdata('RoleName'));
            ?>
            <?php if(isset($data['monthly']['MonthlyID'])){ ?>
            <?php if($data['monthly']['MonthlyStatus']=='1'){ ?>
              <?php if($access_monthly_view){ ?>
              <a href="<?php echo base_url(). "monthly/view/".encryptor($data['monthly']['MonthlyID']); ?>" class="btn btn-info  btn-info-view">View</a>
              <?php } else { ?>
              <a href="#" class="btn btn-info  btn-info-view disabled">View</a>
              <?php } ?>
            <?php } else { ?>
              <?php if($access_monthly_add){ ?>
              <a href="<?php echo base_url(). "monthly/add/".encryptor($data['monthly']['MonthlyID']); ?>" class="btn btn-info btn-info-edit" >Draft</a>
              <?php } else { ?>
              <a href="#" class="btn btn-info btn-info-edit disabled" >Draft</a>
              <?php } ?>  
            <?php } } else { ?>
              <?php if($access_monthly_add){ ?>
              <a href="<?php echo base_url(). "monthly/add"; ?>" class="btn btn-info btn-info-add">Add</a>
              <?php } else { ?>
              <a href="#" class="btn btn-info btn-info-add disabled">Add</a>
              <?php } ?>  
            <?php } ?>
        </div>                        

      </div>
    </div>
  </li>
</ul>
</div>


</div>
</div>
</div>

      <!-- laqshya status start  -->
      <div class="col-md-12 col-md-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>LA<span style="color: #aa1e1e;">Q</span>SHYA Certification Status</h2>
          </div>
          <div class="x_content x_content_facility custom-rspor">
            <div class="facility_dashboard_x_content">
              <div class="row activity_row">
                <div class="col-md-8 col-sm-8 col-xs-8">
                  <p><b>Activity</b></p>
                </div>            
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <p><b>Status</b></p>
                </div>
              </div>
              <ul class="list-unstyled timeline">
                <li>
                  <div class="row marclass">
                    <div class="col-md-8 col-sm-8 col-xs-8">
                      <div>
                        <a>
                          <span>State Orientation</span>
                        </a>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <?php
                      if(isset($data['stateOr']['status'])){
                        $stateOrStatus=$data['stateOr']['status'];
                      } else {
                        $stateOrStatus='-1';
                      }
                      switch ($stateOrStatus) {
                        case 1:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-applied.png" title="Applied">';
                          break;
                        case 2:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-inprocess.png" title="In-progress">';
                          break;
                        case 3:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-done.png" title="Completed">';
                          break;
                        case 4:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-rejected.png" title="Rejected">';
                          break;
                        default:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-not.png" title="Not Filled">';
                          break;
                      }
                      ?>
                    </div>            
                  </div>
                </li>
                <li>
                  <div class="row marclass">
                    <div class="col-md-8 col-sm-8 col-xs-8">
                      <div>
                        <a>
                          <span>Base line Assessment for LR</span>
                        </a>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <?php
                      if(isset($data['BaselineLR']['SurveyStatus'])){
                        $SurveyStatus=$data['BaselineLR']['SurveyStatus'];
                      } else {
                        $SurveyStatus='-1';
                      }
                      switch ($SurveyStatus) {
                        case 1:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-done.png" title="Completed">';
                          break;
                        case 0:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-inprocess.png" title="In-progress">';
                          break;                        
                        default:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-not.png" title="Not Filled">';
                          break;
                      }
                      ?>                      
                    </div>            
                  </div>
                </li>
                <li>
                  <div class="row marclass">
                    <div class="col-md-8 col-sm-8 col-xs-8">
                      <div >
                        <a>
                          <span>Base line Assessment for OT</span>
                        </a>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <?php
                      if(isset($data['BaselineOT']['SurveyStatus'])){
                        $SurveyStatus=$data['BaselineOT']['SurveyStatus'];
                      } else {
                        $SurveyStatus='-1';
                      }
                      switch ($SurveyStatus) {
                        case 1:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-done.png" title="Completed">';
                          break;
                        case 0:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-inprocess.png" title="In-progress">';
                          break;                        
                        default:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-not.png" title="Not Filled">';
                          break;
                      }
                      ?>
                    </div>            
                  </div>
                </li>
                <li>
                  <div class="row marclass">
                    <div class="col-md-8 col-sm-8 col-xs-8">
                      <div >
                        <a>
                          <span>State Certification status for LR</span>
                        </a>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <?php
                      if(isset($data['StatecLR']['status'])){
                        $StatecLRStatus=$data['StatecLR']['status'];
                      } else {
                        $StatecLRStatus='-1';
                      }
                      switch ($StatecLRStatus) {
                        case 1:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-applied.png" title="Applied">';
                          break;
                        case 2:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-inprocess.png" title="In-progress">';
                          break;
                        case 3:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-done.png" title="Completed">';
                          break;
                        case 4:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-rejected.png" title="Rejected">';
                          break;
                        default:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-not.png" title="Not Filled">';
                          break;
                      }
                      ?>
                    </div>            
                  </div>
                </li>
                <li>
                  <div class="row marclass">
                    <div class="col-md-8 col-sm-8 col-xs-8">
                      <div>
                        <a >
                          <span>State Certification status for OT</span>
                        </a>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <?php
                      if(isset($data['StatecOT']['status'])){
                        $StatecOTStatus=$data['StatecOT']['status'];
                      } else {
                        $StatecOTStatus='-1';
                      }
                      switch ($StatecOTStatus) {
                        case 1:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-applied.png" title="Applied">';
                          break;
                        case 2:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-inprocess.png" title="In-progress">';
                          break;
                        case 3:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-done.png" title="Completed">';
                          break;
                        case 4:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-rejected.png" title="Rejected">';
                          break;
                        default:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-not.png" title="Not Filled">';
                          break;
                      }
                      ?>
                    </div>            
                  </div>
                </li>
                <li>
                  <div class="row marclass">
                    <div class="col-md-8 col-sm-8 col-xs-8">
                      <div >
                        <a >
                          <span>National Certification status for LR</span>
                        </a>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <?php
                      if(isset($data['cLR']['status'])){
                        $cLRStatus=$data['cLR']['status'];
                      } else {
                        $cLRStatus='-1';
                      }
                      switch ($cLRStatus) {
                        case 1:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-applied.png" title="Applied">';
                          break;
                        case 2:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-inprocess.png" title="In-progress">';
                          break;
                        case 3:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-done.png" title="Completed">';
                          break;
                        case 4:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-rejected.png" title="Rejected">';
                          break;
                        default:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-not.png" title="Not Filled">';
                          break;
                      }
                      ?>
                    </div>            
                  </div>
                </li>
                <li>
                  <div class="row marclass">
                    <div class="col-md-8 col-sm-8 col-xs-8">
                      <div >
                        <a>
                          <span>National Certification status for OT</span>
                        </a>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <?php
                      if(isset($data['cOT']['status'])){
                        $cOTStatus=$data['cOT']['status'];
                      } else {
                        $cOTStatus='-1';
                      }
                      switch ($cOTStatus) {
                        case 1:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-applied.png" title="Applied">';
                          break;
                        case 2:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-inprocess.png" title="In-progress">';
                          break;
                        case 3:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-done.png" title="Completed">';
                          break;
                        case 4:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-rejected.png" title="Rejected">';
                          break;
                        default:
                          echo '<img width="30px" src="'.base_url().'assets/images/status-not.png" title="Not Filled">';
                          break;
                      }
                      ?>
                    </div>            
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
<!-- laqshya status end  -->

      <!-- indicators started -->
    <div class="col-md-12 col-md-12 col-xs-12">
        <div class="row">
        <div class="col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>LaQshya Program Indicators- Status </h2>
              <ul class="nav navbar-right panel_toolbox">
                <li>
                  <a class="collapse-link">
                    <i class="fa fa-chevron-up"></i>
                  </a>
                </li>
              </ul>
            <div class="pull-right">
              <select class="dateChangeClass" id="faclity_monthly_indicator_date" data-changeFunction="faclity_monthly_indicator">
                <?php 
                $month=date('Y').'-'.date('m');
                $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
                foreach ($this->config->item('years') as $keyYear => $valueYear) {
                  foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
                    $monthVal=$valueYear."-".$keyMonth;
                    if($monthVal==$monthDefault){
                      $seletedText=" selected='selected' ";
                    } else {
                      $seletedText='';
                    }
                    echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
                    if($monthVal==$month){
                      break 2;
                    }
                  }
                } 
                ?>
              </select>
            </div>               
              <div class="clearfix"></div>
            </div>
            <div class="x_content faclity_monthly_indicator_new">  
                 
                  <div id="faclity_monthly_indicator">
                        <table id="datatable" class="table table-striped table-bordered my-table-width" width="100%">
                            <thead>
                                <tr>
                                  <th>Indicator</th>
                                  <th>Current Status</th>
                                  <th>Target</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                    <td title="Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores">Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores</td>
                                    <td id="a"></td>
                                    <td>Baseline Assessment & Reporting done</td>
                                </tr>
                                <tr>
                                    <td title="Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots">Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots</td>
                                    <td id="b"></td>
                                    <td>At least one Meeting in month</td>
                                </tr>
                                <tr>                                    
                                    <td title="Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI">Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI</td>
                                    <td id="c"></td>
                                    <td>All staff Trained </td>
                                </tr>
                                <tr>                                    
                                    <td title="Percentage of deliveries are attended by a birth companion">Percentage of deliveries are attended by a birth companion</td>
                                    <td id="d"></td>
                                    <td>90%</td>
                                </tr>
                                <tr>                                    
                                    <td title="Percentage deliveries are conducted using safe birth checklist in Labour Room">Percentage deliveries are conducted using safe birth checklist in Labour Room </td>
                                    <td id="e"></td>
                                    <td>90%</td>
                                </tr>
                                <tr>                                    
                                    <td title="Percentage of deliveries are conducted using  Safe Surgery checklist in Maternity OT">Percentage of deliveries are conducted using  Safe Surgery checklist in Maternity OT</td>
                                    <td id="f"></td>
                                    <td>90%</td>
                                </tr>
                                <tr>                                    
                                    <td title="Percentage of deliveries for which Partograph is generated using real-time information in at least">Percentage of deliveries for which Partograph is generated using real-time information in at least </td>
                                    <td id="g"></td>
                                    <td>90%</td>
                                </tr>
                                <tr>                                    
                                    <td title="Percentage breastfeeding within 1 hour">Percentage breastfeeding within 1 hour </td>
                                    <td id="h"></td>
                                    <td>80%</td>
                                </tr>
                                <tr>                                    
                                    <td title="Neonatal asphyxia rate in Inborn Babies"> Neonatal asphyxia rate in Inborn Babies </td>
                                    <td id="i"></td>
                                    <td>0%</td>
                                </tr>
                                <tr>                                    
                                    <td title="Neonatal sepsis rate in-born babies"> Neonatal sepsis rate in-born babies </td>
                                    <td id="j"></td>
                                    <td>0%</td>
                                </tr>
                                <tr>                                    
                                    <td title="Surgical Site infection Rate in Maternity OT"> Surgical Site infection Rate in Maternity OT </td>
                                    <td id="k"></td>
                                    <td>5%</td>
                                </tr>
                                <tr>                                    
                                    <td title="Antenatal corticosteroid administration rate in case in preterm labour">Antenatal corticosteroid administration rate in case in preterm labour</td>
                                    <td id="l"></td>
                                    <td>80%</td>
                                </tr>
                                <tr>                                    
                                    <td title="Pre-eclampsia, eclampsia & PIH related mortality">Pre-eclampsia, eclampsia & PIH related mortality</td>
                                    <td id="m"></td>
                                    <td>0</td>
                                </tr>
                                <tr>                                    
                                    <td title="APH/PPH related mortality"> APH/PPH related mortality </td>
                                    <td id="n"></td>
                                    <td>0</td>
                                </tr>
                                <tr>                                    
                                    <td title="Facility Labour Room is reorganized as labour room standardization guidelines">Facility Labour Room is reorganized as labour room standardization guidelines</td>
                                    <td id="o"></td>
                                    <td>Reorganized</td>
                                </tr>
                                <tr>                                    
                                    <td title="Facility Labour room has staffing as per defined norms">Facility Labour room has staffing as per defined norms </td>
                                    <td id="p"></td>
                                    <td>Full Staffing </td>
                                </tr>
                                <tr>                                    
                                    <td title="Percentage of Women, administered Oxytocin, immediately after birth.">Percentage of Women, administered Oxytocin, immediately after birth.</td>
                                    <td id="q"></td>
                                    <td>100%</td>
                                </tr>
                                <tr>                                    
                                    <td title="OSCE Score">OSCE Score </td>
                                    <td id="r"></td>
                                    <td>80%</td>
                                </tr>
                                <tr>                                    
                                    <td title="Facility conducts referral audit on Monthly basis">Facility conducts referral audit on Monthly basis</td>
                                    <td id="s"></td>
                                    <td>Monthly</td>
                                </tr>
                                <tr>                                    
                                    <td title="Facility conducts Maternal death, Neonatal death and near-miss on monthly basis">Facility conducts Maternal death, Neonatal death and near-miss on monthly basis</td>
                                    <td id="t"></td>
                                    <td>Monthly</td>
                                </tr>
                                <tr>                                    
                                    <td title="Facility report zero stock outs in Labour Room & Maternity OT">Facility report zero stock outs in Labour Room & Maternity OT</td>
                                    <td id="u"></td>
                                    <td>0</td>
                                </tr>
                                <tr>                                    
                                    <td title="Still Birth Rate">Still Birth Rate </td>
                                    <td id="v"></td>
                                    <td></td>
                                </tr>
                                <tr>                                    
                                    <td title="Percentage of beneficiaries  who were either satisfied or highly satisfied">Percentage of beneficiaries  who were either satisfied or highly satisfied</td>
                                    <td id="w"></td>
                                    <td></td>
                                </tr>
                                <tr>                                    
                                    <td title="functional Obs ICU/Hybrid ICU/HDU?">functional Obs ICU/Hybrid ICU/HDU?</td>
                                    <td id="x"></td>
                                    <td></td>
                                </tr>
                                <tr>                                    
                                    <td title="Microbiological Surveillance in OT & LR">Microbiological Surveillance in OT & LR </td>
                                    <td id="y"></td>
                                    <td></td>
                                </tr>
                                <tr>                                    
                                    <td title="Labour Room Quality Score Improvement from Baseline">Labour Room Quality Score Improvement from Baseline </td>
                                    <td id="z"></td>
                                    <td></td>
                                </tr>
                                <tr>                                    
                                    <td title="Maternity OT Quality Score Improvement from Baseline">Maternity OT Quality Score Improvement from Baseline </td>
                                    <td id="za"></td>
                                    <td></td>
                                </tr>
                                <tr>
                            </tbody>
                        </table>                    
                  </div>
                </div>
            </div>
            </div>
          </div>
         
       </div>
      <!-- indicators ended -->

      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 text-center">
          <a href="#" id="view-more-btn" class="view-more-btn " title="View All Dashboard Sections"><i class="fa fa-arrow-down hvr-bob" aria-hidden="true"></i> View more</a> 
        </div>
      </div>
<div class="hidden-dash-bard">
      <!-- charts box started -->
      <div class="col-md-6 col-sm-12 col-xs-12">
        <div class="x_panel short-panel1">
          <div class="x_title">
            <h2>Maternal Death Cause</h2>
            <ul class="nav navbar-right panel_toolbox">
              <li>
                <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                </a>
              </li>
            </ul>
            <div class="pull-right">
          <select class="dateChangeClass" id="piechart_MatDeath_date" data-changeFunction="piechart_MatDeath" data-msg="piechart_MatDeath_msg" data-loader="piechart_MatDeath_loader">
            <?php 
            $month=date('Y').'-'.date('m');
            $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
            foreach ($this->config->item('years') as $keyYear => $valueYear) {
              foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
                $monthVal=$valueYear."-".$keyMonth;
                if($monthVal==$monthDefault){
                  $seletedText=" selected='selected' ";
                } else {
                  $seletedText='';
                }
                echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
                if($monthVal==$month){
                  break 2;
                }
              }
            } 
            ?>
          </select>             
            </div>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">  
              <div class="col-md-12">
                <div id="piechart_MatDeath"></div>
                <div id="piechart_MatDeath_loader" class="loader-s" style="display: none;"></div>
                <div id="piechart_MatDeath_msg" class="msg-center" style="display: none;"></div>
              </div>
          </div>
        </div>
        </div>
      <div class="col-md-6 col-sm-12 col-xs-12">
        <div class="x_panel short-panel1">
          <div class="x_title">
            <h2>Neonatal Death Cause</h2>
            <ul class="nav navbar-right panel_toolbox">
              <li>
                <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                </a>
              </li>
            </ul>
            <div class="pull-right">
          <select class="dateChangeClass" id="piechart_NeonDeath_date" data-changeFunction="piechart_NeonDeath"  data-msg="piechart_NeonDeath_msg" data-loader="piechart_NeonDeath_loader">
            <?php 
            $month=date('Y').'-'.date('m');
            $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
            foreach ($this->config->item('years') as $keyYear => $valueYear) {
              foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
                $monthVal=$valueYear."-".$keyMonth;
                if($monthVal==$monthDefault){
                  $seletedText=" selected='selected' ";
                } else {
                  $seletedText='';
                }
                echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
                if($monthVal==$month){
                  break 2;
                }
              }
            } 
            ?>
          </select>             
            </div>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">  
              <div class="col-md-12">
                <div id="piechart_NeonDeath"></div>
                <div id="piechart_NeonDeath_loader" class="loader-s" style="display: none;"></div>
                <div id="piechart_NeonDeath_msg" class="msg-center" style="display: none;"></div>
              </div>
          </div>
        </div>
        </div>
      <div class="col-md-6 col-sm-12 col-xs-12">
        <div class="x_panel short-panel1">
          <div class="x_title">
            <h2>Still Birth</h2>
            <ul class="nav navbar-right panel_toolbox">
              <li>
                <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                </a>
              </li>
            </ul>
            <div class="pull-right">
          <select class="dateChangeClass" id="piechart_StillBirth_date" data-changeFunction="piechart_StillBirth" data-msg="piechart_StillBirth_msg" data-loader="piechart_StillBirth_loader">
            <?php 
            $month=date('Y').'-'.date('m');
            $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
            foreach ($this->config->item('years') as $keyYear => $valueYear) {
              foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
                $monthVal=$valueYear."-".$keyMonth;
                if($monthVal==$monthDefault){
                  $seletedText=" selected='selected' ";
                } else {
                  $seletedText='';
                }
                echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
                if($monthVal==$month){
                  break 2;
                }
              }
            } 
            ?>
          </select>             
            </div>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">  
              <div class="col-md-12">
                <div id="piechart_StillBirth" ></div>
                <div id="piechart_StillBirth_loader" class="loader-s" style="display: none;"></div>
                <div id="piechart_StillBirth_msg" class="msg-center" style="display: none;"></div>
              </div>
          </div>
        </div>
        </div>
      <div class="col-md-6 col-sm-12 col-xs-12">
        <div class="x_panel short-panel1">
          <div class="x_title">
            <h2>Normal VS C-Section Deliveries</h2>
            <ul class="nav navbar-right panel_toolbox">
              <li>
                <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                </a>
              </li>
            </ul>
            <div class="pull-right">
          <select class="dateChangeClass" id="piechart_Deliveries_date" data-changeFunction="piechart_Deliveries" data-msg="piechart_Deliveries_msg" data-loader="piechart_Deliveries_loader">
            <?php 
            $month=date('Y').'-'.date('m');
            $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
            foreach ($this->config->item('years') as $keyYear => $valueYear) {
              foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
                $monthVal=$valueYear."-".$keyMonth;
                if($monthVal==$monthDefault){
                  $seletedText=" selected='selected' ";
                } else {
                  $seletedText='';
                }
                echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
                if($monthVal==$month){
                  break 2;
                }
              }
            } 
            ?>
          </select>             
            </div>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">  
              <div class="col-md-12">
                <div id="piechart_Deliveries" ></div>
                <div id="piechart_Deliveries_loader" class="loader-s" style="display: none;"></div>
                <div id="piechart_Deliveries_msg" class="msg-center" style="display: none;"></div>
              </div>
          </div>
        </div>
        </div>
        <div class="col-md-6 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>APH/PPH related mortality Trend</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li>
                  <a class="collapse-link">
                    <i class="fa fa-chevron-up"></i>
                  </a>
                </li>
              </ul>              
              <div class="clearfix"></div>
            </div>
            <div class="x_content">  
                <div class="col-md-12">
                  <div id="chart_aph" ></div>
                </div>
            </div>
          </div>
          </div>
        <div class="col-md-6 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>Eclampsia & PIH related mortality</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li>
                  <a class="collapse-link">
                    <i class="fa fa-chevron-up"></i>
                  </a>
                </li>
              </ul>              
              <div class="clearfix"></div>
            </div>
            <div class="x_content">  
                <div class="col-md-12">
                  <div id="chart_pih" style="width: 95%; height: 100%;"></div>
                </div>
            </div>
          </div>
          </div>
        <div class="col-md-6 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>Neonatal sepsis rate Trend in-born</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li>
                  <a class="collapse-link">
                    <i class="fa fa-chevron-up"></i>
                  </a>
                </li>
              </ul>              
              <div class="clearfix"></div>
            </div>
            <div class="x_content">  
                <div class="col-md-12">
                  <div id="chart_sepsis" style="width: 95%; height: 100%;"></div>
                </div>
            </div>
          </div>
          </div>
        <div class="col-md-6 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2> Neonatal asphyxia rate Trend</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li>
                  <a class="collapse-link">
                    <i class="fa fa-chevron-up"></i>
                  </a>
                </li>
              </ul>              
              <div class="clearfix"></div>
            </div>
            <div class="x_content">  
                <div class="col-md-12">
                  <div id="chart_asphyxia"></div>
                </div>
            </div>
          </div>
          </div>
        <div class="col-md-6 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>Partograph Generation Trend</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li>
                  <a class="collapse-link">
                    <i class="fa fa-chevron-up"></i>
                  </a>
                </li>
              </ul>              
              <div class="clearfix"></div>
            </div>
            <div class="x_content">  
                <div class="col-md-12">
                  <div id="chart_partograph" style="width: 95%; height: 100%;"></div>
                </div>
            </div>
          </div>
          </div>
        <div class="col-md-6 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>Delivery Trend in presence of Birth Companion</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li>
                  <a class="collapse-link">
                    <i class="fa fa-chevron-up"></i>
                  </a>
                </li>
              </ul>              
              <div class="clearfix"></div>
            </div>
            <div class="x_content">  
                <div class="col-md-12">
                  <div id="chart_birth" style="width: 95%; height: 100%;"></div>
                </div>
            </div>
          </div>
          </div>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>Delivery Trend using Safe birth Checklist in Labour Room</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li>
                  <a class="collapse-link">
                    <i class="fa fa-chevron-up"></i>
                  </a>
                </li>
              </ul>              
              <div class="clearfix"></div>
            </div>
            <div class="x_content">  
                <div class="col-md-12">
                  <div id="chart_safebirth" style="width: 95%; height: 100%;"></div>
                </div>
            </div>
          </div>
          </div>
        <div class="col-md-6 col-sm-6 col-xs-6">
          <div class="x_panel">
            <div class="x_title">
              <h2>Delivery Trend using Safe birth Checklist in Maternity OT</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li>
                  <a class="collapse-link">
                    <i class="fa fa-chevron-up"></i>
                  </a>
                </li>
              </ul>              
              <div class="clearfix"></div>
            </div>
            <div class="x_content">  
                <div class="col-md-12">
                  <div id="chart_safebirthot" style="width: 95%; height: 100%;"></div>
                </div>
            </div>
          </div>
          </div>

      
      <!-- charts box ended -->


<div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Safe Delivery App Related Indicators</h2>
              <ul class="nav navbar-right panel_toolbox">
              <li>
                <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                </a>
              </li>
            </ul>
          </div>
          <div class="x_content servi-list-1">
            <div class="row">
                <div class="col-md-4">
                              <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
       
                                  <div class="analytics-content">
                                     <a href="#">
                                       <h2> 10</h2>
                                         
                                        <h5>Staff oriented on Safe Delivery App</h5>
                                        
                                       
                                      </a>
                                  </div>
                              </div>
                          </div>


                          <div class="col-md-4">
                              <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
       
                                  <div class="analytics-content">
                                     <a href="#">
                                      <h2>15</h2>
                                        <h5>Staff downloaded Safe Delivery App</h5>
                                       
                                         
                                      </a>
                                  </div>
                              </div>
                          </div>


                          <div class="col-md-4">
                              <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
       
                                  <div class="analytics-content">
                                    <a href="#">
                                       <h2>0</h2>
                                        <h5>Staff achieved safe delivery champion</h5>
                                       
                                         
                                      </a>
                                  </div>
                              </div>
                          </div>
 

 



                          </div>




          </div>
        </div>
      </div>




      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Mentoring visits</h2>
              <ul class="nav navbar-right panel_toolbox">
              <li>
                <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                </a>
              </li>
            </ul>
          </div>
          <div class="x_content servi-list-1">
            <div class="row">
                <div class="col-md-4">
                              <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
       
                                  <div class="analytics-content">
                                     <a href="#">
                                      <h2> 10</h2>
                                        <h5>Done in LR at facility</h5>
                                        
                                        
                                         
                                      </a>
                                  </div>
                              </div>
                          </div>


                          <div class="col-md-4">
                              <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
       
                                  <div class="analytics-content">
                                     <a href="#">
                                      <h2>15</h2>
                                         
                                        <h5> Done in maternity OT at facility</h5>
                                       
                                      </a>
                                  </div>
                              </div>
                          </div>


                        



                          </div>




          </div>
        </div>
      </div>
    </div>
 
 

</div>        
</div>
</div>









<!------------------------------ onload road map ------------------------------>
<style type="text/css">
.roadmap .modal-dialog{    width: 100%;
    margin: 0;
    border-radius: 0;}  
.roadmap .modal-content {
    background: none;
    box-shadow: none;
    border: none;
}
.roadmap{}  
.roadmapinner{    width: 100%;
    margin: 0 auto;}
#roadmap{       background: rgba(0, 0, 0, 0.65);
    width: 100%;
    border: none;
    height: 100%;
    border-radius: 0;
      z-index: 99999999999;}
</style>

<div class="roadmap">
<div id="roadmap" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
        
<div class="roadmapinner">
        <div class="container">
            <div class="row text-center">
                <h1 class="dark">LaQshya Certificate process flow and Status <span class="close skip-thi-btnb" data-dismiss="modal">Skip This</span></h1>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="main-timeline">
                      <!-- timeline-failed, timeline-success, timeline-pending -->
                        <div class="timeline timeline-success" data-heading="">

                            <?php 
                                $SurveyStatus='';
                               if(isset($data['BaselineLR']['SurveyStatus']) && isset($data['BaselineOT']['SurveyStatus'])){
                                     
                                  $SurveyStatus='green';
                                } else {
                                  $SurveyStatus='red';
                                }
                       ?>
                            <div class="timeline-content <?php echo $SurveyStatus; ?>">
                            
                                <p class="description">
                                     Baseline assessment of labour room and maternity OT
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 1</span>
                            </span>
                        </div>

                        <div class="timeline timeline-success" data-heading="">
                            <div class="timeline-content">
                                <p class="description">
                                    Action Plan for closure
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 3</span>
                            </span>
                        </div>

                        <div class="timeline timeline-success" data-heading="">

                           <?php 
                                $SurveyStatus='';
                               if(isset($data['BaselineLR']['SurveyStatus']) && isset($data['BaselineOT']['SurveyStatus']) && isset($data['monthly']['MonthlyStatus']) && $data['monthly']['MonthlyStatus']=='1'){
                                     
                                  $SurveyStatus='green';
                                } else {
                                  $SurveyStatus='red';
                                }
                          ?>
                            <div class="timeline-content <?php echo $SurveyStatus; ?>">
                                <p class="description">
                                    Preparation for state certification
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 5</span>
                            </span>
                        </div>

                        <div class="timeline timeline-success" data-heading="">
                            <?php  


                                   
                                $SurveyStatus='';
                               if(isset($data['StatecLR']['status']) && isset($data['StatecOT']['status'])){
                                     
                                  $SurveyStatus='green';
                                } else {
                                  $SurveyStatus='red';
                                }
                          ?>
                               
                           
                            <div class="timeline-content <?php echo $SurveyStatus; ?>">
                                <p class="description">
                                   Application of state certification
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 7</span>
                            </span>
                        </div>

                        <div class="timeline timeline-success" data-heading="">

                          <?php 
                                $SurveyStatus='';
                               if(isset($data['StatecLR']['status']) && isset($data['StatecOT']['status'])){
                                     
                                  $SurveyStatus='green';
                                } else {
                                  $SurveyStatus='red';
                                }
                          ?>
                            <div class="timeline-content <?php echo $SurveyStatus; ?>">
                                <p class="description">
                                    Preparation for National certification
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 7</span>
                            </span>
                        </div>

                        <div class="timeline timeline-success" data-heading="">
                           
                              <?php 
                                $SurveyStatus='';
                               if(isset($data['cLR']['status']) && isset($data['cOT']['status'])){
                                     
                                  $SurveyStatus='green';
                                } else {
                                  $SurveyStatus='red';
                                }
                       ?>
                            <div class="timeline-content <?php echo $SurveyStatus; ?>">
                                <p class="description">
                                    Application of National certification
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 7</span>
                            </span>
                        </div>


                        <div class="timeline timeline-success" data-heading="">
                            <div class="timeline-content">
                                <p class="description">
                                    Tracking of LaQshya Indicator
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 7</span>
                            </span>
                        </div>


                        <div class="timeline bottom  timeline-success" data-heading="">
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 2</span>
                            </span>
                            <div class="timeline-content">
                                <p class="description">
                                    Gap identification and gap closure
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                        </div>

                        <div class="timeline bottom timeline-success" data-heading="">
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 4</span>
                            </span>
                             <?php if(isset($data['monthly']['MonthlyID'])){ 
                             if(isset($data['monthly']['MonthlyStatus']) && $data['monthly']['MonthlyStatus']=='1') {
                                   $SurveyStatus='green';
                                } else {
                                  $SurveyStatus='red';
                                }
                              }
                            ?>
                            <div class="timeline-content <?php echo $SurveyStatus; ?>">
                                <p class="description">
                                    Facility has to fill monthly report and LaQshya indicators every month
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                        </div>

                        <div class="timeline bottom timeline-success" data-heading="">
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 6</span>
                            </span>


                          <?php  


                           if(isset($facilityData['data']['lrdata'])){ 

                             if(($facilityData['data']['lrdata']==5) && ($facilityData['data']['otdata']==5)) {
                                   $SurveyStatus='green';
                                } else {
                                  $SurveyStatus='red';
                                }
                              }
                            ?>
                               
                           
                            <div class="timeline-content <?php echo $SurveyStatus; ?>">
                                <p class="description">
                                    Prerequisites for state certification
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                        </div>

                        <div class="timeline bottom timeline-success" data-heading="">
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 6</span>
                            </span>

                              <?php 
                                $SurveyStatus='';
                               if(isset($data['StatecLR']['status']) && isset($data['StatecOT']['status'])){
                                     
                                  $SurveyStatus='green';
                                } else {
                                  $SurveyStatus='red';
                                }
                       ?>
                            <div class="timeline-content <?php echo $SurveyStatus; ?>">
                                <p class="description">
                                    State certification LR/OT
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                        </div>

                        <div class="timeline bottom timeline-success" data-heading="">
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 8</span>
                            </span>
                            <?php

                                  if(isset($facilityDatanational['data']['lrdata'])){ 

                             if(($facilityDatanational['data']['lrdata']==5) && ($facilityDatanational['data']['otdata']==5)) {
                                   $SurveyStatus='green';
                                } else {
                                  $SurveyStatus='red';
                                }
                              }
                            ?>
                            <div class="timeline-content <?php echo $SurveyStatus; ?>">
                                <p class="description">
                                    Prerequisites for National certification
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                        </div>


                        <div class="timeline bottom timeline-success" data-heading="">
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 6</span>
                            </span>

                              <?php 
                                $SurveyStatus='';
                               if(isset($data['cLR']['status']) && isset($data['cOT']['status'])){
                                     
                                  $SurveyStatus='green';
                                } else {
                                  $SurveyStatus='red';
                                }
                       ?>
                            <div class="timeline-content <?php echo $SurveyStatus; ?>">
                                <p class="description">
                                    National certification LR/OT
                                </p>
                                <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                        </div>


                        <div class="timeline bottom timeline-success final-acesssment">
                            <span class="year <?php echo $SurveyStatus; ?>">
                                <span>Step 6</span>
                            </span>
                            <div class="timeline-content">
                                <p class="description">
                                  <img src="<?php echo base_url()?>assets/images/checkmark.png" alt="final-step"/>
                                    Incentivization and Branding
                                </p>
                               <!-- <a href="#" class="read-more">Check Details</a> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    </div>

  </div>
</div>
</div>

<script type="text/javascript">

    <?php 
    if(empty($this->session->userdata('showModal'))){
    $this->session->set_userdata('showModal', '1');
    ?>
   $(window).on('load',function(){
        $('#roadmap').modal('show');
    });
    <?php } ?>
</script>
<!------------------------------ onload road map ended  ------------------------------>













<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">


  function piechart_MatDeath_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
      var params = {};
      params['device'] = 'web';
      params['csrf_token']=$.cookie("csrf_cookie");
      params['searchType'] = 'piechart_MatDeath';
      params['searchDate'] = searchDate;    
        var piechart_MatDeath_text=[];
        $.ajax({
          url: pageMainUrl + 'ApiUser/getMinistryChart',
          data: params,
          type: 'POST',
          dataType : "json",
          async: false,
          success: function (result) {
            $('#piechart_MatDeath_loader').hide();
            $('#piechart_MatDeath_msg').hide();
            if(parseInt(result.length)>2){
              $('#piechart_MatDeath').show();
              piechart_MatDeath_text = result;
              var data = google.visualization.arrayToDataTable(piechart_MatDeath_text);
              var options = {
                      title: '',          
                      //'chartArea': {height: "100%",width: "100%" },
                      is3D: true,
                      'width':500,
                     'height':300,
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
                    };
              var chart = new google.visualization.PieChart(document.getElementById('piechart_MatDeath'));
              chart.draw(data, options);
            } else{
              $('#piechart_MatDeath').hide();
              $('#piechart_MatDeath_msg').show().html('No Data Found');
            }
            
          }
      });
        /*var data = google.visualization.arrayToDataTable(piechart_MatDeath_text);

        var options = {
          title: '',
          'chartArea': {'width': '100%'},
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_MatDeath'));
        chart.draw(data, options);*/
      }   
  }
  function piechart_NeonDeath_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
      var params = {};
      params['device'] = 'web';
      params['csrf_token']=$.cookie("csrf_cookie");
      params['searchType'] = 'piechart_NeonDeath';
      params['searchDate'] = searchDate;    
        var piechart_NeonDeath_text=[];
        $.ajax({
          url: pageMainUrl + 'ApiUser/getMinistryChart',
          data: params,
          type: 'POST',
          dataType : "json",
          async: false,
          success: function (result) {
            $('#piechart_NeonDeath_loader').hide();
            $('#piechart_NeonDeath_msg').hide();
                if(parseInt(result.length)>2){
                    $('#piechart_NeonDeath').show();
                    piechart_NeonDeath_text = result;
              var data = google.visualization.arrayToDataTable(piechart_NeonDeath_text);
              var options = {
                      title: '',          
                      //'chartArea': {height: "100%",width: "100%" },
                      is3D: true,
                      'width':500,
                     'height':300,
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
                    };
              var chart = new google.visualization.PieChart(document.getElementById('piechart_NeonDeath'));
              chart.draw(data, options);
                } else{
                    $('#piechart_NeonDeath').hide();
                    $('#piechart_NeonDeath_msg').show().html('No Data Found');
                }
          }
      });
        /*var data = google.visualization.arrayToDataTable(piechart_NeonDeath_text);

        var options = {
          title: '',
          'chartArea': {'width': '100%'},
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_NeonDeath'));
        chart.draw(data, options);*/
      }
  }
  function piechart_StillBirth_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
      var params = {};
      params['device'] = 'web';
      params['csrf_token']=$.cookie("csrf_cookie");
      params['searchType'] = 'piechart_StillBirth';
      params['searchDate'] = searchDate;    
        var piechart_StillBirth_text=[];
        $.ajax({
          url: pageMainUrl + 'ApiUser/getMinistryChart',
          data: params,
          type: 'POST',
          dataType : "json",
          async: false,
          success: function (result) {
                $('#piechart_StillBirth_loader').hide();
                $('#piechart_StillBirth_msg').hide();
                if(parseInt(result.length)>2){
                $('#piechart_StillBirth').show();
                piechart_StillBirth_text = result;
            var data = google.visualization.arrayToDataTable(piechart_StillBirth_text);
            var options = {
                      title: '',          
                      //'chartArea': {height: "100%",width: "100%" },
                      is3D: true,
                      'width':500,
                     'height':300,
                     colors: ['blue', 'red'],
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
                    };
            var chart = new google.visualization.PieChart(document.getElementById('piechart_StillBirth'));
            chart.draw(data, options);
                } else{
                    $('#piechart_StillBirth').hide();
                    $('#piechart_StillBirth_msg').show().html('No Data Found');
                }
          }
      });
        /*var data = google.visualization.arrayToDataTable(piechart_StillBirth_text);

        var options = {
          title: '',
          'chartArea': {'width': '100%'},
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_StillBirth'));
        chart.draw(data, options);*/
      }
  }
  function piechart_Deliveries_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
      var params = {};
      params['device'] = 'web';
      params['csrf_token']=$.cookie("csrf_cookie");
      params['searchType'] = 'piechart_Deliveries';
      params['searchDate'] = searchDate;    
        var piechart_Deliveries_text=[];
        $.ajax({
          url: pageMainUrl + 'ApiUser/getMinistryChart',
          data: params,
          type: 'POST',
          dataType : "json",
          async: false,
          success: function (result) {
                $('#piechart_Deliveries_loader').hide();
                $('#piechart_Deliveries_msg').hide();
                if(parseInt(result.length)>2){
                    $('#piechart_Deliveries').show();
                    piechart_Deliveries_text = result;
              var data = google.visualization.arrayToDataTable(piechart_Deliveries_text);
              var options = {
                      title: '',          
                      //'chartArea': {height: "100%",width: "100%" },
                      is3D: true,
                      'width':500,
                     'height':300,
                     colors: ['blue', 'orange','red'],
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
                    };
              var chart = new google.visualization.PieChart(document.getElementById('piechart_Deliveries'));
              chart.draw(data, options);
                } else{
                    $('#piechart_Deliveries').hide();
                    $('#piechart_Deliveries_msg').show().html('No Data Found');
                }
          }
      });
        /*var data = google.visualization.arrayToDataTable(piechart_Deliveries_text);

        var options = {
          title: '',
          'chartArea': {'width': '100%'},
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_Deliveries'));
        chart.draw(data, options);*/
      }
  }



  function chart_aph_fun(searchDate=''){
      google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchType'] = 'chart_aph';
        params['searchDate'] = searchDate;    
          var chart_aph_text=[];
          $.ajax({
            url: pageMainUrl + 'ApiUser/getMinistryChart',
            data: params,
            type: 'POST',
            dataType : "json",
            async: false,
            success: function (result) {
              chart_aph_text = result;
            }
        });

        var data = google.visualization.arrayToDataTable(chart_aph_text);

        var options = {
          title: '',
          curveType: 'none',
          legend: { position: 'bottom' },
          width:600,
          chartArea: {width:"100%",height:"70%",top:20},
          
        };

       

        var chart = new google.visualization.LineChart(document.getElementById('chart_aph'));
        chart.draw(data, options);
      }
      
  }
  function chart_pih_fun(searchDate=''){
      google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchType'] = 'chart_pih';
        params['searchDate'] = searchDate;    
          var chart_pih_text=[];
          $.ajax({
            url: pageMainUrl + 'ApiUser/getMinistryChart',
            data: params,
            type: 'POST',
            dataType : "json",
            async: false,
            success: function (result) {
              chart_pih_text = result;
            }
        });
        var data = google.visualization.arrayToDataTable(chart_pih_text);

         var options = {
          title: '',
          curveType: 'none',
          legend: { position: 'bottom' },
          width:600,
          chartArea: {width:"100%",height:"70%",top:20},
          
        };

        var chart = new google.visualization.LineChart(document.getElementById('chart_pih'));
        chart.draw(data, options);
      }
      
  }
  function chart_sepsis_fun(searchDate=''){
      google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchType'] = 'chart_sepsis';
        params['searchDate'] = searchDate;    
          var chart_sepsis_text=[];
          $.ajax({
            url: pageMainUrl + 'ApiUser/getMinistryChart',
            data: params,
            type: 'POST',
            dataType : "json",
            async: false,
            success: function (result) {
              chart_sepsis_text = result;
            }
        });
        var data = google.visualization.arrayToDataTable(chart_sepsis_text);
         var options = {
          title: '',
          curveType: 'none',
          legend: { position: 'bottom' },
          width:600,
          chartArea: {width:"100%",height:"70%",top:20},
          
        };
        var chart = new google.visualization.LineChart(document.getElementById('chart_sepsis'));
        chart.draw(data, options);
      }
      
  }
  function chart_asphyxia_fun(searchDate=''){
      google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchType'] = 'chart_asphyxia';
        params['searchDate'] = searchDate;    
          var chart_asphyxia_text=[];
          $.ajax({
            url: pageMainUrl + 'ApiUser/getMinistryChart',
            data: params,
            type: 'POST',
            dataType : "json",
            async: false,
            success: function (result) {
              chart_asphyxia_text = result;
            }
        });
        var data = google.visualization.arrayToDataTable(chart_asphyxia_text);
         var options = {
          title: '',
          curveType: 'none',
          legend: { position: 'bottom' },
          width:600,
          chartArea: {width:"100%",height:"70%",top:20},
          
        };
        var chart = new google.visualization.LineChart(document.getElementById('chart_asphyxia'));
        chart.draw(data, options);
      }
      
  }
  function chart_partograph_fun(searchDate=''){
      google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchType'] = 'chart_partograph';
        params['searchDate'] = searchDate;    
          var chart_partograph_text=[];
          $.ajax({
            url: pageMainUrl + 'ApiUser/getMinistryChart',
            data: params,
            type: 'POST',
            dataType : "json",
            async: false,
            success: function (result) {
              chart_partograph_text = result;
            }
        });
        var data = google.visualization.arrayToDataTable(chart_partograph_text);
         var options = {
          title: '',
          curveType: 'none',
          legend: { position: 'bottom' },
          width:600,
          chartArea: {width:"100%",height:"70%",top:20},
          
        };
        var chart = new google.visualization.LineChart(document.getElementById('chart_partograph'));
        chart.draw(data, options);
      }
      
  }
  function chart_birth_fun(searchDate=''){
      google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchType'] = 'chart_birth';
        params['searchDate'] = searchDate;    
          var chart_birth_text=[];
          $.ajax({
            url: pageMainUrl + 'ApiUser/getMinistryChart',
            data: params,
            type: 'POST',
            dataType : "json",
            async: false,
            success: function (result) {
              chart_birth_text = result;
            }
        });
        var data = google.visualization.arrayToDataTable(chart_birth_text);
         var options = {
          title: '',
          curveType: 'none',
          legend: { position: 'bottom' },
          width:600,
          chartArea: {width:"100%",height:"70%",top:20},
          
        };
        var chart = new google.visualization.LineChart(document.getElementById('chart_birth'));
        chart.draw(data, options);
      }
      
  }
  function chart_safebirth_fun(searchDate=''){
      google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchType'] = 'chart_safebirth';
        params['searchDate'] = searchDate;    
          var chart_safebirth_text=[];
          $.ajax({
            url: pageMainUrl + 'ApiUser/getMinistryChart',
            data: params,
            type: 'POST',
            dataType : "json",
            async: false,
            success: function (result) {
              chart_safebirth_text = result;
            }
        });
        var data = google.visualization.arrayToDataTable(chart_safebirth_text);
         var options = {
          title: '',
          curveType: 'none',
          legend: { position: 'bottom' },
          width:600,
          chartArea: {width:"100%",height:"70%",top:20},
          
        };
        var chart = new google.visualization.LineChart(document.getElementById('chart_safebirth'));
        chart.draw(data, options);
      }
      
  }
  function chart_safebirthot_fun(searchDate=''){
      google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchType'] = 'chart_safebirthot';
        params['searchDate'] = searchDate;    
          var chart_safebirthot_text=[];
          $.ajax({
            url: pageMainUrl + 'ApiUser/getMinistryChart',
            data: params,
            type: 'POST',
            dataType : "json",
            async: false,
            success: function (result) {
              chart_safebirthot_text = result;
            }
        });
        var data = google.visualization.arrayToDataTable(chart_safebirthot_text);
         var options = {
          title: '',
          curveType: 'none',
          legend: { position: 'bottom' },
          width:600,
          chartArea: {width:"100%",height:"70%",top:20},
          
        };chart = new google.visualization.LineChart(document.getElementById('chart_safebirthot'));
        chart.draw(data, options);
      }
      
  }
  function faclity_monthly_indicator_fun(searchDate=''){
    $('#faclity_monthly_indicator').show();
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'faclity_monthly_indicator';
    params['searchDate'] = searchDate;    
      var faclity_monthly_indicator_text=[];
      $.ajax({
        url: pageMainUrl + 'ApiUser/getMinistryChart',
        data: params,
        type: 'POST',
        dataType : "json",
        async: false,
        success: function (result) {
          $('#a').html(result.a);
          $('#b').html(result.b);
          $('#c').html(result.c);
          $('#d').html(result.d);
          $('#e').html(result.e);
          $('#f').html(result.f);
          $('#g').html(result.g);
          $('#h').html(result.h);
          $('#i').html(result.i);
          $('#j').html(result.j);
          $('#k').html(result.k);
          $('#l').html(result.l);
          $('#m').html(result.m);
          $('#n').html(result.n);
          $('#o').html(result.o);
          $('#p').html(result.p);
          $('#q').html(result.q);
          $('#r').html(result.r);
          $('#s').html(result.s);
          $('#t').html(result.t);
          $('#u').html(result.u);
          $('#v').html(result.v);
          $('#w').html(result.w);
          $('#x').html(result.x);
          $('#y').html(result.y);
          $('#z').html(result.z);
          $('#za').html(result.za);
        }
    });
  }  

  $('document').ready(function(){
    piechart_MatDeath_fun();
    piechart_NeonDeath_fun();
    piechart_StillBirth_fun();
    piechart_Deliveries_fun();
    chart_aph_fun();
    chart_pih_fun();
    chart_sepsis_fun();
    chart_asphyxia_fun();
    chart_partograph_fun();
    chart_birth_fun();
    chart_safebirth_fun();
    chart_safebirthot_fun();
    faclity_monthly_indicator_fun();
   
    
    $('.dateChangeClass').change(function(){
      var searchDate=$(this).val();
      var functionName=$(this).attr('data-changeFunction');
      var loaderName=$(this).attr('data-loader');
      $('#'+loaderName).show();
      $('#'+functionName).hide();
      switch(functionName) {
        case 'piechart_MatDeath':
          piechart_MatDeath_fun(searchDate);
          break;
        case 'piechart_NeonDeath':
          piechart_NeonDeath_fun(searchDate);
          break;
        case 'piechart_StillBirth':
          piechart_StillBirth_fun(searchDate);
          break;
        case 'piechart_Deliveries':
          piechart_Deliveries_fun(searchDate);
          break;
        case 'chart_aph':
          chart_aph_fun(searchDate);
          break;
        case 'chart_pih':
          chart_pih_fun(searchDate);
          break;
        case 'chart_sepsis':
          chart_sepsis_fun(searchDate);
          break;
        case 'chart_asphyxia':
          chart_asphyxia_fun(searchDate);
          break;
        case 'chart_partograph':
          chart_partograph_fun(searchDate);
          break;
        case 'chart_birth':
          chart_birth_fun(searchDate);
          break;
        case 'chart_safebirth':
          chart_safebirth_fun(searchDate);
          break;
        case 'chart_safebirthot':
          chart_safebirthot_fun(searchDate);
          break;
        case 'faclity_monthly_indicator':
          faclity_monthly_indicator_fun(searchDate);
          break;
        default:
          // code block
      }
    });


        $.ajax({
            url: pageMainUrl + 'ApiUser/checkMonthlyReport',
            data: {'csrf_token':$.cookie("csrf_cookie")},
            type: 'POST',
            async: false,
            dataType : "json",
            success: function (result) {
              if(result.code!='0'){
                 swal({ title: "You have not submitted monthly report for this month yet!" ,text:"Please Submit Report.", html:true});
               }
            }
        });

  });

 





    </script>


<script type="text/javascript">
  
  $("#view-more-btn").click(function(){
    $(".hidden-dash-bard").show();
    $(this).remove();
    return false;
  });

$(document).ready(function(){
  $('.count').each(function () {
      $(this).prop('Counter',0).animate({
          Counter: $(this).text()
      }, {
          duration: 4000,
          easing: 'swing',
          step: function (now) {
              $(this).text(Math.ceil(now));
          }
      });
  });

 


   
});



</script>
 


