<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Laqshya</title>
        <meta charset="utf-8">
        <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <!-- Bootstrap -->
        <link href="<?php echo base_url(); ?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="<?php echo base_url(); ?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- NProgress -->
        <link href="<?php echo base_url(); ?>assets/vendors/nprogress/nprogress.css" rel="stylesheet">
        <!-- Animate.css -->
        <link href="<?php echo base_url(); ?>assets/vendors/animate.css/animate.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

        <!-- Custom Theme Style -->
        <link href="<?php echo base_url(); ?>assets/css/custom.min.css" rel="stylesheet">
      <!-- <link href="<?php //echo base_url(); ?>assets/css/pace-theme-mac-osx.css" rel="stylesheet" /> -->
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900|Open+Sans:400,600,700|Patua+One|Source+Sans+Pro:400,600,700" rel="stylesheet">

<!-- <script src="<?php //echo base_url(); ?>assets/js/jquery.min.js"></script>-->
      <script src="<?php echo base_url();?>assets/js/jquery1.11.3.min.js"></script>
      <script src="<?php echo base_url();?>assets/js/jquery.cookie.js"></script>

  <!-- <script src='https://www.google.com/recaptcha/api.js'></script> -->
        <script type="text/javascript">
            var pageMainUrl = "<?php echo base_url(); ?>";
        </script>

 <noscript>
   <h1 class="text-center ">This page needs JavaScript activated to work. </h1>
   <style>div { display:none; }</style>
 </noscript>
 
    </head>
    <body class="login grey" id="bg-color">

  <div id="loader_overlay" style="display:none ">
    
    <div style="    position: absolute;z-index: 999;left: 50%;top: 50%;transform: translate(-50%, -50%)">
      <img src="<?php echo base_url('assets/images/load.gif'); ?>" alt="load" >
    </div>
  </div>



           <header>
        <div class="header-bottom">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-4 col-sm-4 col-xs-12 text-left main-logo">
                <a href="<?php echo base_url();?>">
                  <h1>
                    <span class="emonitoring white_logo"><img src="<?php echo base_url();?>/assets/images/laqshya-logo.png"></span>
                    <span class="emonitoring default_logo"><img src="<?php echo base_url();?>/assets/images/laqshya-logo1.png"></span>
                  </h1>
                </a>
              </div>


              <div class="col-md-4 col-sm-4 col-xs-6 indian-emblem text-center">
                <a href="https://mohfw.gov.in/" target="_blank" >
                  <img class="white_logo" style="padding-top: 5px;" src="<?php echo base_url();?>/assets/images/indian-emblem.png" alt="Indian Emblem">
                  <img class="default_logo" style="padding-top: 5px;" src="<?php echo base_url();?>/assets/images/indian-emblem1.png" alt="Indian Emblem">
                </a>
              </div>
              
              <div class="col-md-4 col-sm-4 col-xs-6 nhp-logo">
                 <a href="http://nhm.gov.in/" target="_blank">
                  
                  <img class="default_logo" style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhm-white.png" alt="NHM" class="NHM-logo">
                  <img class="white_logo" style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhm.png" alt="NHM" class="NHM-logo">
                </a>
                <a href="https://www.nhp.gov.in/" target="_blank"> 
                  <img class="default_logo"  style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhp-white.png" alt="NHP" class="nhp-logo">
                  <img class="white_logo"  style="padding-top: 4px;" src="<?php echo base_url();?>/assets/images/nhp.png" alt="NHP" class="nhp-logo">
                </a>
               
              </div>
            </div>
          </div>
        </div>
      </header>

          









        <div class="login_wrapper">
            <div class="animate form login_form">
                <section class="login_content">
                    <form name="loginForm" id="loginForm" class="login-form" action="<?php echo base_url() . "ApiUser/login" ?>" method="post" autocomplete="off" >
                        <h1 style="padding-bottom: 10px;">
                          <span>Login</span>
                        </h1>
                        <div class="alert" id="msgDiv" style="display: none;">
                            <!-- <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a> -->
                            <span id="LoginMsg"></span>
                        </div>


                        <div class="form-group">
                            <input class="form-control" placeholder="Enter Username" id="username" name="username" type="text" autofocus  >
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="Enter Password" id="password" name="password" type="password" value="" autocomplete="new-password"  >
                        </div>
                        <div id="image_captcha" style="height:65px; float: left; width:80%;">
                            <?php echo $captchaImg; ?>
                        </div>
                        <a href="javascript:void(0);" style="width:20%; padding: 0px 10px; font-size: 30px; float:right;" class="captcha-refresh" ><i class="fa fa-refresh"></i></a>
                        <div class="form-group"> 
                            <input class="form-control" placeholder="Enter Captcha Code" id="captcha" name="captcha" type="text" value=""   >
                        </div>
                        <div class="col-md-12" style="padding: 0;">
                            <!-- online <div class="g-recaptcha" data-sitekey="6LciuWYUAAAAABIyv3tm_Q-sadWfljdhq-aUpLev"></div> -->
                            <!-- local  <div class="g-recaptcha" data-sitekey="6LfR2xMUAAAAABBy2TBrBKur0_L23TizUGR-M20s"></div>-->
                        </div>


                        <div class="checkbox1 checkbox-primary rems check_inline_flex">
                              <input id="checkbox2" type="checkbox" checked="">
                              <label for="checkbox2" style="margin-left: 9px;">
                                  <a class="terms_condition" target="_blank" href="<?php echo base_url(); ?>User/termsandconditions">I accept all the terms & conditions</a>
                              </label>
                              
                        </div>

                        <div class="clearfix"></div>


                        <div class="col-md-2 col-sm-2 col-xs-2">
                            <div class="row">
                                <input name="loginBtn" id="loginBtn" type="submit" class="btn btn-info submit mar0 login_submit" value="Login">
                            </div>
                        </div>

                        <div class="col-md-10 col-sm-10 col-xs-10 mar-top-5">
                            <div class="row">
                                <a href="#" class="forget-pass" style="color: #fff;" data-toggle="modal" data-target="#resetModal" > Forgot Password?</a>
                            </div>
                        </div>
                        <div class="clearfix"></div>

                       
                          
          
                          
                          
          
                          
                        
                    </form>
                </section>
            </div>

            <!--<div id="register" class="animate form registration_form">
              <section class="login_content">
                <form>
                  <h1>Create Account</h1>
                  <div>
                    <input type="text" class="form-control" placeholder="Username" required="" />
                  </div>
                  <div>
                    <input type="email" class="form-control" placeholder="Email" required="" />
                  </div>
                  <div>
                    <input type="password" class="form-control" placeholder="Password" required="" />
                  </div>
                  <div>
                    <a class="btn btn-default submit" href="index.html">Submit</a>
                  </div>
    
                  <div class="clearfix"></div>
    
                  <div class="separator">
                    <p class="change_link">Already a member ?
                      <a href="#signin" class="to_register"> Log in </a>
                    </p>
    
                  </div>
                </form>
              </section>
            </div>-->
        </div>



        <footer>
            <div class="container">
                <div class="row" style="display: flex; align-items: center;">


                    <div class="col-md-12 col-sm-12 col-sm-12 col-xs-12 visitor-number">
                        Copyright &copy; 2018. LA<span style="color: #af2222;">Q</span>SHYA. All Rights Reserved.
                    </div>
                    <!-- <div class="col-md-6 col-sm-4 col-sm-6 col-xs-12 text-right footer-right">
                        <img src="<?php echo base_url(); ?>assets/images/nhm.png" alt="nhm">
                        <img src="<?php echo base_url(); ?>assets/images/nhsrc.png" alt="nhsrc">
                    </div> -->
                </div>
            </div>
        </footer>


        <!-- color changes -->
            <div class="color-theme">
                <a href="javascript:;"  class="theme-collapse-btn"><i class="fa fa-angle-left"></i></a>
                <ul>
                <li><a class="black-bg" href="javascript:;" title="Black Theme" id="color1"><img src="<?php echo base_url(); ?>assets/images/black-theme.png" alt="Black Theme"></a></li>
                
                  <li><a class="white-bg" href="javascript:;" title="Default Theme" id="color2"><img src="<?php echo base_url(); ?>assets/images/default-theme.png" alt="Default Theme"></a></li>
                          
                  <li><a class="red-bg" href="javascript:;" title="Red Theme" id="color3"><img src="<?php echo base_url(); ?>assets/images/red-bg.png" alt="Red Theme"></a></li>

                  <li><a class="grey-bg" href="javascript:;" title="Grey Theme" id="color4"><img src="<?php echo base_url(); ?>assets/images/grey-theme.png" alt="Grey Theme"></a></li>
                          
                
                  </ul>

                  <h4> Color Theme</h4>

            </div>




        <!-- color changes ended -->

<!-- modal window start  -->
<div id="resetModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">

    <!-- Modal content-->
    <div class="modal-content">
        <div class="new-forget-password">
            <div class="panel panel-default">
              <button type="button" class="close pull-right" data-dismiss="modal">&times;</button>
              <div class="panel-body">
                <div class="text-center">
                  <h3><i class="fa fa-lock fa-4x"></i></h3>
                  <h2 class="text-center">Forgot Password?</h2>
                  <p>You can reset your password here.</p>
                  <div class="panel-body">
    
                    
    
                      <div class="form-group">
                        <div class="input-group">
                          <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                          
                          <input maxlength="25" type="text" id="userId" name="userId" class="form-control" placeholder="Username">
                        </div>
                      </div>
                      <div class="form-group">
                        
                        <input id="resetPassword" name="resetPassword" type="button" class="btn btn-lg btn-primary btn-block" value="Reset Password" onclick="resetPassword()" />
                      </div>
                      
                     
                     
                  </div>
                </div>
              </div>
            </div>
          </div>

 

<!--
      <div class="modal-header">
        
        <h4 class="modal-title">Forgot Password</h4>
      </div>
      <div class="modal-body">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Username</label>
                    <input maxlength="25" type="text" id="userId" name="userId" class="form-control" placeholder="Username">
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group pull-right">
                  <input id="resetPassword" name="resetPassword" type="button" class="btn btn-success" value="Submit" onclick="resetPassword()" />
                </div>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>-->
    </div>

  </div>
</div>
<!-- modal window end  -->


        <!-- date Picker -->
        <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.form.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>

        <script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js"></script>

        <script src="<?php echo base_url(); ?>assets/js/bootstrap-select.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/moment.min.js"></script> 
        <script src="<?php echo base_url(); ?>assets/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript">
 
</script>



        <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
        <?php
        $file = $this->uri->segment(2);
        if (empty($file)) {
            $file = 'index';
        }
        $folder = $this->uri->segment(1);
        if (empty($folder)) {
            $file = 'user';
        }
        $scriptUrl = 'assets/js/' . strtolower($folder) . '/' . strtolower($file) . '.js';
        if (file_exists($scriptUrl)) {
            echo '<script src="' . base_url() . $scriptUrl . '"></script>';
        }
        ?> 


        <!-- color changes scrpipt -->







    </body>
</html>