<html lang="en">
<head>
        <title>Laqshya</title>
        <meta charset="utf-8">
        <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <!-- Bootstrap -->
        <link href="<?php echo base_url();?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="<?php echo base_url();?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">

        <!-- Animate.css -->
        <link href="<?php echo base_url();?>assets/vendors/animate.css/animate.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

        <!-- Custom Theme Style -->
        <link href="<?php echo base_url();?>assets/css/custom.min.css" rel="stylesheet">
      <!-- <link href="assets/css/pace-theme-mac-osx.css" rel="stylesheet" /> -->
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900|Open+Sans:400,600,700|Patua+One|Source+Sans+Pro:400,600,700" rel="stylesheet">

<!-- <script src="assets/js/jquery.min.js"></script>-->
      <script src="<?php echo base_url();?>assets/js/jquery1.11.3.min.js"></script>
      <script src="<?php echo base_url();?>assets/js/jquery.cookie.js"></script>

  <!-- <script src='https://www.google.com/recaptcha/api.js'></script> -->
        <script type="text/javascript">
            var pageMainUrl = "<?php echo base_url();?>";
        </script>

        <style>
          .row {
                  margin-right: -15px;
                  margin-left: -15px;
              }
          .container{width: 80%;}
        </style>


    </head>
    <body class="termsandconditions grey">

        <header>

            <div class="header-bottom">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-3 col-xs-6 indian-emblem"><img style="padding-top: 5px;" src="<?php echo base_url();?>/assets/images/indianembelem_2.png" alt="Indian Emblem"></div>
                        <div class="col-md-6 col-xs-12 text-center main-logo">
                          <h1 style="margin-top: 20px;">
                            <span class="emonitoring">e-Monitoring System for LaQshya</span>
                          </h1>
                        </div>
                        <div class="col-md-3 col-xs-6 nhp-logo"><a href="http://www.nihfw.org/" target="_blank"><img src="https://LAQSHYA.nhp.gov.in/laqshya/assets/images/nihfw-logo.png" alt="NIHFW" class="ihd-logo"></a> <a href="https://www.nhp.gov.in/" target="_blank"><img style="padding-top: 4px;" src="https://LAQSHYA.nhp.gov.in/laqshya/assets/images/logo-nhp.png" alt="NHP" class="nhp-logo"></a></div>
                    </div>
                </div>
            </div>
        </header>

        
        <div class="container-fluid">
          <div class="row terms_heading">
            <div class="container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <h3>Website Policies</h3>
                </div>
              </div>
            </div>
          </div>


          <div class="row bread_crumb">
            <div class="container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <span><a href="http://demosl56.rvsolutions.in/nhp-laqshya/laqshya-website-drupal/"><i class="fa fa-home"></i>&nbsp;Home </a>&nbsp; <i class="fa fa-angle-right"></i> &nbsp;<span> Website Policies</span></span>
                </div>
              </div>
            </div>
          </div>


          <div class="row terms_content">
            <div class="container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <h3>Copyright Policy</h3>
                  <p>This contents of this Portal may not be reproduced partially or fully, without due permission from MoHFW, Govt. of India. If referred to as a part of another publication, the source must be appropriately acknowledged. The contents of this website cannot be used in any misleading or objectionable context.</p>


                  <br><br>


                  <h3>Privacy Policy</h3>
                  <p>As a general rule, this website does not collect Personal Information about you when you visit the site. You can generally visit the site without revealing Personal Information, unless you choose to provide such information.</p>


                  <br><br>


                  <h3>Site Visit Data</h3>
                  <p>This website records your visit and logs the following information for statistical purposes your server’s address; the name of the top-level domain from which you access the Internet (for example, .gov, .com, .in, etc.); the type of browser you use; the date and time you access the site; the pages you have accessed and the documents downloaded and the previous Internet address from which you linked directly to the site.</p>
                  <br>
                  <p>We will not identify users or their browsing activities, except when a law enforcement agency may exercise a warrant to inspect the service provider’s logs.</p>
                  

                  <br><br>


                  <h3>Email Management</h3>
                  <p>Your email address will only be recorded if you choose or you register on this Portal. It will only be used for the purpose for which you have provided it and will not be used for any other purpose, and will not be disclosed to anyone else or to third party, without your consent.</p>


                  <br><br>


                  <h3>Collection of Personal Information</h3>
                  <p>If you are asked for any other Personal Information you will be informed how it will be used if you choose to give it. If at any time you believe the principles referred to in this privacy statement have not been followed, or have any other comments on these principles, please notify us. Our contact details provided on ‘Contact’ page.</p>
                  <br>
                  <p><strong>Note :</strong> The use of the term “Personal Information” in this privacy statement refers to any information from which your identity is apparent or can be reasonably ascertained.</p>


                  <br><br>


                  <h3>Hyperlink Policy</h3>
                  <p>At many places in this Portal, you shall find links to other websites. This links have been placed for your convenience. LAQSHYA, Govt. of India is not responsible for the contents and reliability of the linked websites and does not necessarily endorse the views expressed in them. Mere presence of the link or its listing on this Portal should not be assumed as endorsement of any kind. We cannot guarantee that these links will work all the time and we have no control over availability of linked pages.</p>


                  <br><br>


                  <h3>Links to the LAQSHYA, Govt. of India website by other websites</h3>
                  <p>Prior permission is required before hyperlinks are directed from any website to this site. Permission for the same, stating the nature of the content on the pages from where the link has to be given and the exact language of the Hyperlink should be obtained by sending a request at _________________________.</p>


                  <br><br>


                  <h3>Accessibility Statement</h3>
                  <p>We are committed to ensure that the LAQSHYA Portal is accessible to all users irrespective of device in use, technology or ability. It has been built, with an aim, to provide maximum accessibility and usability to its visitors. As a result this website can be viewed from a variety of devices such as Desktop / Laptop Computers, Web-enabled mobile devices etc.</p>
                  <br>
                  <p>We have put in our best efforts to ensure that all information on this website is accessible easily. We also aim to be standards compliant and follow principles of usability and universal design, which should help all visitors of this website.</p>
                  <br>
                  <p>This website is designed using XHTML 1.0 Transitional to meet Web Development Guidelines for Websites and also adheres to level A of the Web Content Accessibility Guidelines (WCAG) 2.0 laid down by the World Wide Web Consortium (W3C). Part of the information in the website is also made available through links to external Websites. External Websites are maintained by the respective departments who are responsible for making these sites accessible.</p>
                  <br>
                  <p>If you have any problem or suggestion regarding the accessibility of this website, please contact us to enable us to respond in a helpful manner. Do let us know the nature of the problem along with your contact information.</p>


                  <br><br>


                  <h3>Disclaimer</h3>
                  <p>This Portal & contents of this Portal are owned, updated & maintained by the respective Government Department/Organization/Agency for information purpose. Maps used on this Portal are for general illustration only, and are not intended to be used for reference purposes. The representation of political boundaries does not necessarily reflect the position of the Government of India on international issues of recognition, sovereignty or jurisdiction.</p>
                  <br>
                  <p>Though all efforts have been made to ensure the accuracy of the content on this Portal, the same should not be construed as a statement of law or used for any legal purposes. LAQSHYA accepts no responsibility in relation to the accuracy, completeness, usefulness or otherwise, of the contents. Users are advised to verify/check any information with the relevant Government Department(s) and/or other source(s), and to obtain any appropriate professional advice before acting on the information provided on this Portal.</p>
                  <br>
                  <p>In no event will the Government or LAQSHYA be liable for any expense, loss or damage including, without limitation, indirect or consequential loss or damage, or any expense, loss or damage whatsoever arising from use, or loss of use, of data, arising out of or in connection with the use of this Portal.</p>
                  <br>
                  <p>Links to other Portals that have been included on this Portal are provided for public convenience only. LAQSHYA is not responsible for the contents or reliability of linked Portals and does not necessarily endorse the view expressed within them. We cannot guarantee the availability of such linked third party Portals/Web Pages at all times.</p>
                  <br>
                  <p>Material featured on this Portal may be reproduced free of charge after taking proper permission by sending a mail to us. However, the material has to be reproduced accurately and not to be used in a derogatory manner or in a misleading context. Wherever the material is being published or issued to others, the source must be prominently acknowledged. However, the permission to reproduce this material shall not extend to any material which is identified as being copyright of a third party. Authorization to reproduce such material must be obtained from the departments/copyright holders concerned.</p>
                  <br>
                  <p>These terms and conditions shall be governed by and construed in accordance with the Indian Laws. Any dispute arising under these terms and conditions shall be subject to the exclusive jurisdiction of the courts of India.</p>
                  <br>
                  <p>This Portal does not automatically capture any specific personal information from you, (like name, phone number or e-mail address), that allows us to identify you individually. If the Portal requests you to provide personal information, you will be informed for the particular purposes for which the information is gathered and adequate security measures will be taken to protect your personal information.</p>
                  <br>
                  <p>We do not sell or share any personally identifiable information volunteered on the Portal to any third party (public/private). Any information provided to this Portal will be protected from loss, misuse, unauthorized access or disclosure, alteration, or destruction.</p>
                  <br>
                  <p>We gather certain information about the user, browser type, operating system, the date and time of the visit and the pages visited. We make no attempt to link these addresses with the identity of individuals visiting our site unless an attempt to damage the site has been detected.</p>


                  <br><br>


                  <h3>Links to external Portals</h3>
                  <p>At many places in this Portal, you shall find links to other Portals. These links have been placed for your convenience. LAQSHYA is not responsible for the contents and reliability of the linked Portals and does not necessarily endorse the views expressed in them. Mere presence of the link or its listing on this Portal should not be assumed as endorsement of any kind. We cannot guarantee that these links will work all the time and we have no control over availability of linked pages or on content presented on those third party Portals/Web Pages.</p>


                  <br><br>


                  <h3>Links to Portal by other Portals</h3>
                  <p>We do not object if you link directly to this Portal or any of its web page and no prior permission is required for the same. However, we would like you to inform us about any links provided to this Portal so that you can be informed of any changes or updations therein. Also, we do not permit our pages to be copied or content to be copied directly to your Portal or to any material without prior permission. Also it is not permitted to load our Portal or it’s Web Page into frames on your Portal. The pages belonging to this Portal must load into a newly opened browser window of the User.</p>



                </div>
              </div>
            </div>
          </div>
        </div>



        <footer>
            <div class="container">
                <div class="row">


                    <div class="col-md-6 col-sm-8 col-sm-6 col-xs-12 text-center visitor-number">
                        Copyright &copy; 2018. LaQshya. All Rights Reserved.
                    </div>
                    <div class="col-md-6 col-sm-4 col-sm-6 col-xs-12 text-center footer-right">
                        <img src="https://pmsma.nhp.gov.in/laqshya/assets/images/my-gov.png" alt="My Gov">
                        <img src="https://pmsma.nhp.gov.in/laqshya/assets/images/india-gov.png" alt="India Gov">
                    </div>
                </div>
            </div>
        </footer>




        <!-- date Picker -->
        <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/jquery.form.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/sweetalert.min.js"></script>

        <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>

        <script src="<?php echo base_url();?>assets/js/bootstrap-select.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/moment.min.js"></script> 
        <script src="<?php echo base_url();?>/assets/js/bootstrap-datetimepicker.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/custom.js"></script>
    
</body>
</html>