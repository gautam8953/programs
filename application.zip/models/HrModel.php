<?php

class HrModel extends CI_Model {
	function __construct() {
		parent::__construct();

	}
	

	 function saveData($data) {
       
        if ($this->db->insert('hr', $data)) {
            $ansId = $this->db->insert_id();
        } else {
            $ansId = 0;
        }
        return $ansId;
    }

 function getSearchData($userID, $searchData, $search_state,$search_district,$search_facility) {
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
        $col = array(
            //0 => 'sr.stateId',
            0 => 'FacilityName',
            1 => 'StateName ',
            2 => 'DistrictName',
            3 => 'FacilityHead',
            4 => 'createdOn',
            
        );
        $this->db->select('count(hr.id) recordCount');
        $this->db->from('hr as hr');
        $this->db->join('usermapping um','hr.UserID=um.UserID');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
        $this->db->where('hr.IsActive','1');
        
        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
       
        
        if ($search_state != '') {
            $this->db->where('s.stateId', $search_state);
        }
         if ($search_district != '') {
            $this->db->where('d.DistrictID', $search_district);
        }
        if ($search_facility != '') {
            $this->db->where('hr.UserID', $search_facility);
        }

       
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);

            $this->db->where("(f.FacilityName like '%" . $searchString . "%' OR hr.FacilityHead like '%" . $searchString . "%' OR s.StateName like '%" . $searchString . "%' OR d.DistrictName like '%" . $searchString . "%' OR hr.createdOn like '%" . $searchString . "%' OR hr.Gynecologist like '%" . $searchString . "%')", NULL, FALSE);
        }
        $queryTot = $this->db->get();
        $row = $queryTot->result();
        $totalRecordCount = $row[0]->recordCount;
       

        $this->db->select('s.StateName,hr.id,f.FacilityName,d.DistrictName,hr.FacilityHead,hr.createdOn');
        $this->db->from('hr as hr');
         $this->db->join('usermapping um','hr.UserID=um.UserID');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
        $this->db->where('hr.IsActive','1');
       
        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
        
        if ($search_state != '') {
            $this->db->where('s.stateId', $search_state);
        }
         if ($search_district != '') {
            $this->db->where('d.DistrictID', $search_district);
        }
        if ($search_facility != '') {
            $this->db->where('hr.UserID', $search_facility);
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);

            $this->db->where("(f.FacilityName like '%" . $searchString . "%' OR hr.FacilityHead like '%" . $searchString . "%' OR hr.createdOn like '%" . $searchString . "%' OR s.StateName like '%" . $searchString . "%' OR d.DistrictName like '%" . $searchString . "%' OR hr.Anesthetist like '%" . $searchString . "%')", NULL, FALSE);
        }
//        print_r($col[$searchData['order'][0]['column']]);
        $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
        $this->db->limit($this->input->post('length'), $this->input->post('start'));
        $query = $this->db->get();
//var_dump($searchData['order'][0]['dir']);
        $data['draw'] = $this->input->post('draw');
//        $data['totalData'] = $queryTot->num_rows();
        $data['totalData'] = $totalRecordCount;
        $data['totalFilter'] = $totalRecordCount;
//        $surveyFormLevel = $this->config->item('assesmentSequence');
        $dataget = array();
        $cnt=$this->input->post('start');

        $access_edit=$this->CommonModel->checkPageActionWeb('hr/index','access_edit',$this->session->userdata('RoleName'));
        $access_delete=$this->CommonModel->checkPageActionWeb('hr/index','access_delete',$this->session->userdata('RoleName'));
        $access_view=$this->CommonModel->checkPageActionWeb('hr/index','access_view',$this->session->userdata('RoleName'));
        foreach ($query->result() as $key => $value) {
        	// print_r($value);die;
            $subdata = array();
            $subdata[]=++$cnt;
            $valId=encryptor($value->id);
//            $subdata[] = $surveyFormLevel[$value->Sequence];
//            $subdata[] = $value->StateName;
            $subdata[] = "<span id='name_span_".$valId."'>".$value->FacilityName."</span><span><input type='hidden' id='name_".$valId."' maxlength='20' name='name' value='".$value->FacilityName."'/></span>";
            $subdata[] = "<span id='name_span_".$valId."'>".$value->StateName."</span><span><input type='hidden' id='name_".$valId."' maxlength='20' name='name' value='".$value->StateName."'/></span>";
          
            $subdata[] = "<span id='designation_span_".$valId."'>".$value->DistrictName."</span><span><input type='hidden' id='designation_".$valId."' maxlength='20' name='name' value='".$value->DistrictName."'/></span>";
            $subdata[] = "<span id='designationSmg_span_".$valId."'>".$value->FacilityHead."</span><span><input type='hidden' id='designationSmg_".$valId."' maxlength='20' name='name' value='".$value->FacilityHead."'/></span>";
            $subdata[] = "<span id='email_span_".$valId."'>".$value->createdOn."</span><span><input type='hidden' id='email_".$valId."' name='name' maxlength='20' value='".$value->createdOn."'/></span>";
           
            $actionLink='';
            if($access_edit){
                $actionLink.='<button data-href="'.base_url().'hr/add/'.$valId.'" onclick="pageRedirect(this)" data-ans="'.$valId.'" class="btn btn-info btn-xs getAssesment getAssesment1" ><i class="glyphicon glyphicon-check"></i> Edit</button>'
                  ;
            }
            if($access_delete){
                $actionLink.='<button data-href="" data-val="' . $valId . '"  onclick="removeDataRow(\'' . $valId . '\')" class="btn btn-danger btn-xs deleteRow "><i class="glyphicon glyphicon-trash"></i> Remove</button>';
            }
             if($access_view){
                $actionLink.='<button data-page="View" data-reqMonth="' . $valId . '" data-months="' . $valId . '" data-href="' . base_url() . 'hr/view/' . $valId . '" onclick="pageRedirect(this)"  class="btn btn-primary btn-xs getScore view_edit_width" ><i class="glyphicon glyphicon-check"></i>View</button>';
            }
            $subdata[] = $actionLink;
            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;
    
        return $data;
    }



     function updateRecord($table, $id, $data) {
        $condition = array('id' => $id);
        $this->db->where($condition);
       if($this->db->update($table, $data)=== FALSE){
            return false;
        } else {
            return true;            
        }
    }
	
	
	
	
	
	
	function getFacilityDetails($userID){
	    $this->db->select('facilities.FacilityID,facilities.services,facilities.FacilityName,facilities.FacilityNumber,facilities.Latitude,facilities.Longitude,facilities.Altitude,facilities.Address,facilities.PinCode,facilities.Address,facilities.landLine,facilities.ot_services,facilities.FacilityTypeDetailID,facilities.facilitytype_other,usermapping.UserID,district.DistrictID,district.DistrictName,states.StateID,states.StateName,typedetail.TypeDetailCode');
	    $this->db->from('usermapping');
	    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
	    $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'inner');
	    $this->db->join('states', 'facilities.StateID=states.StateID', 'inner');
	    $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');
	    
	    $this->db->where('usermapping.UserID',$userID);
	    $query = $this->db->get();
		return $query->row_array();
	}
	function getHrDetails($userID=0,$type){
		if($type=='main'){
			$TypeDetailID='438';
		} else if($type=='facility'){
		  	$this->db->select('UserID');
		    $this->db->from('usermapping');
		    $this->db->join('facilities', "facilities.FacilityID=usermapping.FacilityID AND usermapping.FacilityID>0", 'inner');
		    $this->db->where('facilities.FacilityNumber',$userID);
		    $query = $this->db->get();
		    if($query->num_rows()>0){
		    	$datafacility=$query->row_array();
		    	$userID=$datafacility['UserID'];
		    	$TypeDetailID='438';
		    } else {
		    	$userID=0;
		    	$TypeDetailID='0';  // make it any wrong id
		    }
		} else {
			$TypeDetailID='439';
		}
		//print_r($userID);die;
	    $this->db->select('hr.*');
	    $this->db->from('users');
	    $this->db->join('hr', "users.UserID=hr.UserID", 'inner');
	    $this->db->where('users.UserID',$userID);
	    $this->db->where('hr.IsActive','1');
	    $query = $this->db->get();
		return $query->row_array();
	}

 function checkData($userID){
 	$this->db->select('hr.id');
	    $this->db->from('hr');
	    $this->db->where('hr.UserID',$userID);
	    $this->db->where('hr.IsActive','1');
	    $query = $this->db->get();
	    return $query->row_array();
		

 }


 function getUserId($id){
 	$this->db->select('hr.UserID');
	    $this->db->from('hr');
	    $this->db->where('hr.id',$id);
	    $this->db->where('hr.IsActive','1');
	    $query = $this->db->get();
	    return $query->row_array();
		

 }
    


	function saveHr($data,$userId){
         $err=array();
	     if(isset($data['facility'])){
		    $this->db->select('facilities.FacilityID');
		    $this->db->from('usermapping');
		    $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID AND usermapping.FacilityID>0', 'inner');
		    $this->db->where('usermapping.UserID',$userId);
		    $this->db->where('usermapping.IsActive','1');
		    $query = $this->db->get();
			$facilityData=$query->row_array();
			if($facilityData['FacilityID']>0){	
				$this->db->where('FacilityID', $facilityData['FacilityID']);
				if ($this->db->update('facilities', $data['facility']) === FALSE){
				    $err['facility']='Error updating data';
				} else {
					$this->session->set_userdata('facilityServices', $data['facility']['services']);
				}
			} else {
				$err['facility']='No Facility data found';
			}
		}
		if(isset($data['main'])){
		    $this->db->select('incharge.InchargeID');
		    $this->db->from('incharge');
		    $this->db->where('incharge.UserID',$userId);
		    $this->db->where('incharge.IsActive','1');
		    $this->db->where('incharge.TypeDetailID','438');
		    $query = $this->db->get();
			$inchargeData=$query->row_array();
			if($inchargeData['InchargeID']>0){
				$this->db->where('InchargeID', $inchargeData['InchargeID']);
				if ($this->db->update('incharge', $data['main']) === FALSE){
				    $err['main']='Error updating data';
				}
			} else {
				$data['main']['IsActive']='1';
				$data['main']['TypeDetailID']='438';
				$data['main']['UserID']=$userId;
				if(!$this->db->insert('incharge', $data['main'])){
					$err['main']='Error saving data';
				}
			}
			$updateUserData=array(
				'FirstName'=>$data['main']['FirstName'].' '.$data['main']['LastName']
			);
			$this->db->where('UserID', $userId);
			$this->db->update('users', $updateUserData);
			if(!isset($err['main']) && isset($data['main']['Pic']) ){
				$this->session->set_userdata('profile_pic', $data['main']['Pic']);
			}
			if(!isset($err['main']) ){
				$this->session->set_userdata('FirstName', $data['main']['FirstName']);
				$this->session->set_userdata('LastName', $data['main']['LastName']);
			}
		}
		if(isset($data['nodal'])){
		    $this->db->select('incharge.InchargeID');
		    $this->db->from('incharge');
		    $this->db->where('incharge.UserID',$userId);
		    $this->db->where('incharge.IsActive','1');
		    $this->db->where('incharge.TypeDetailID','439');
		    $query = $this->db->get();
			$inchargeData=$query->row_array();
			if($inchargeData['InchargeID']>0){
				$this->db->where('InchargeID', $inchargeData['InchargeID']);
				if ($this->db->update('incharge', $data['nodal']) === FALSE){
				    $err['nodal']='Error updating data';
				}
			} else {
				$data['nodal']['IsActive']='1';
				$data['nodal']['TypeDetailID']='439';
				$data['nodal']['UserID']=$userId;
				if(!$this->db->insert('incharge', $data['nodal'])){
					$err['nodal']='Error saving data';
				}
			}			
		}
		if(empty($err)){
			$response= array('code'=>0,'msg'=>$this->config->item('errCodes')[0]);
		} else {
			$response=array('code'=>16,'msg'=>'Please updaet Data again');
		}
		
		return $response;
	}

}