<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\User;
use App\Models\RegisteruserModel;
use App\Http\Requests\RegisterRequest;

use Config;
use DB;

class AuthController extends Controller
{
    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth:api', ['except' => Config::get('constants.guesturl')]);
        $this->middleware('auth:api', ['except' => Config::get('constants.guesturl')]);
    }

    /**
     * Get a JWT via given credentials.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function login()
    {
        $credentials = request(['username', 'password']);
        
        if (! $token = auth()->attempt($credentials)) {
            return response()->json(['error' => 'username or password doesn\'t exist'], 401);
        }

        return $this->respondWithToken($token);
    }
    public function register(RegisterRequest $request)
    {
        $responseHttp=array();
        $responseHttpCode=Config::get('constants.httpStatus.ok');
        $data=$request->all();
        $registerModel=new RegisteruserModel();
        $entity=array(
            'entityTypeTypeDetailID'=>'27',
            'parentEntityTypeDetailID'=>'0',
            'agencyID'=>'0',
        );
        $entityID=DB::table('tblentity')->insertGetId($entity);
        if($entityID>0){
            $userdata=array(
                'entityID'=>$entityID,
                'username'=>$data['iecCode'],
                'password'=>$data['password'],
                'password_confirmation'=>$data['password_confirmation']
            );
            $res=User::create($userdata);
            $responseHttp=$res;
            $responseHttp['message']=Config::get('constants.responseMsg.msg_4');
        } else {
            $responseHttp['message']=Config::get('constants.responseMsg.msg_3');
            $responseHttpCode=Config::get('constants.httpStatus.internal_error');
        }
        return response()->json($responseHttp,$responseHttpCode);
    }

    /**
     * Get the authenticated User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function me()
    {
        return response()->json(auth()->user());
    }

    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        auth()->logout();

        return response()->json(['message' => 'Successfully logged out']);
    }

    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {
        return $this->respondWithToken(auth()->refresh());
    }

    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60,
            'userID' => auth()->user()->userID,
            'entityID' => auth()->user()->entityID
        ]);
    }
    public function states()
    {
        $responseHttp=array();
        $responseHttpCode=Config::get('constants.httpStatus.ok');

        return response()->json(['message' => 'Successfully logged out']);
    }
}