<?php 
return array(
    'httpStatus'=>array(
        'ok'=>200,
        'created'=>201,
        'no_content'=>204,
        'moved_permanently'=>301,
        'not_modified'=>304,
        'bad_request'=>400,
        'unauthorized'=>401,
        'forbidden'=>403,
        'not_found'=>404,
        'method_not_allowed'=>405,
        'internal_error'=>500,
        'not_implemented'=>501,
    ),
    'responseMsg'=>array(
        'msg_1'=>'Data Saved Successfully',
        'msg_2'=>'Data Updated Successfully',
        'msg_3'=>'Error Saving Data',
        'msg_4'=>'User Created Successfully',
    ),
    'guesturl'=>array(
        'login',
        'register',
        'states',
    )
);
