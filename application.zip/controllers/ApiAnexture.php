<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class ApiAnexture extends CI_Controller {
	public function __construct()
	{
		parent :: __construct();
		$this->load->model('AnextureModel');
	}
	
	public function index(){
	}
	public function getSearchData(){
		if ($this->CommonModel->checkAPIWebUser()) {
		$searchData=$this->input->post();
		$searchData['cond']=array();		
        if($this->session->userdata('RoleName')=='State'){
            $searchData['cond']=array('mappedField'=>'f.StateID','mappedData'=>$this->session->userdata('MappedState'));
        }
        if($this->session->userdata('RoleName')=='District'){
            $searchData['cond']=array('mappedField'=>'f.DistrictID','mappedData'=>$this->session->userdata('MappedDistrict'));
        }
        if($this->session->userdata('RoleName')=='Facility'){
            $searchData['cond']=array('mappedField'=>'um.UserID','mappedData'=>$this->session->userdata('UserID'));
        }
		$data=$this->AnextureModel->getSearchData($searchData);
		$json_data=array(
		    "draw"              =>  intval($data['draw']),
		    "recordsTotal"      =>  intval($data['totalData']),
		    "recordsFiltered"   =>  intval($data['totalFilter']),
		    "data"              =>  $data['data']
		);
		echo json_encode($json_data);
	} else {
		$json_data=array(
		    "draw"              =>  0,
		    "recordsTotal"      =>  0,
		    "recordsFiltered"   =>  0,
		    "data"              =>  array()
		);
		echo json_encode($json_data);		
	}
	}

	function anexture()
	{
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					if(!empty($data1['facilityName']) && !empty($data1['SurveyID']) && !empty($data1['sequence'])  ){} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];						
					}
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					$saveData=array();
					$saveData['anextureID']=$this->input->post('anextureID');
					$saveData['UserID']=$this->input->post('facilityName');
					//$saveData['submitDate']=convert_date_db($this->input->post('submitDate'));
					$saveData['submitDate']=convert_date_db('01-'.str_replace('/','-',$this->input->post('submitDate')));
					$saveData['checklist_1']=$this->input->post('checklist_1');
					$saveData['checklist_2']=$this->input->post('checklist_2');
					$saveData['checklist_3']=$this->input->post('checklist_3');
					$saveData['checklist_4']=$this->input->post('checklist_4');
					$saveData['checklist_5']=$this->input->post('checklist_5');
					$saveData['checklist_6']=$this->input->post('checklist_6');
					$saveData['checklist_7']=$this->input->post('checklist_7');
					$saveData['checklist_8']=$this->input->post('checklist_8');
					$saveData['checklist_9']=$this->input->post('checklist_9');
					$saveData['checklist_10']=$this->input->post('checklist_10');
					$saveData['checklist_11']=$this->input->post('checklist_11');
					$saveData['checklist_12']=$this->input->post('checklist_12');
					$saveData['checklist_13']=$this->input->post('checklist_13');
					$saveData['checklist_14']=$this->input->post('checklist_14');
					$saveData['checklist_15']=$this->input->post('checklist_15');
					$saveData['checklist_16']=$this->input->post('checklist_16');
					$saveData['checklist_17']=$this->input->post('checklist_17');
					$saveData['checklist_18']=$this->input->post('checklist_18');
					$saveData['checklist_19']=$this->input->post('checklist_19');
					$saveData['checklist_20']=$this->input->post('checklist_20');
					$saveData['isDraft']=$this->input->post('btn')=='Draft'?1:0;
					$saveData['IsActive']=1;
					if($this->session->userdata('facilityUser')!=$this->session->userdata('UserID')){
						$saveData['ParentUserID']=$this->session->userdata('UserID');
					}
					$anextureID=$this->AnextureModel->saveData($saveData);
					if($anextureID>0){
						$response['code']='0';
						$response['sts']=$saveData['isDraft'];
						$response['anextureID']=encryptor($anextureID);
						$response['msg']=$this->config->item('errCodes')[0];
					} else {
						$response['code']='11';
						$response['sts']=$saveData['isDraft'];
						$response['msg']=$this->config->item('errCodes')[11];
					}					
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		echo json_encode($response);
		exit;
	}
	function anextureview($anextureID=null){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					if(!empty($data1['facilityName']) && !empty($data1['SurveyID']) && !empty($data1['sequence'])  ){} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];						
					}
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					$response=$this->AnextureModel->anextureview($anextureID);
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		echo json_encode($response);
		exit;		
	}
	function anextureEdit($anextureID=null){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					if(!empty($data1['facilityName']) && !empty($data1['SurveyID']) && !empty($data1['sequence'])  ){} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];						
					}
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					$response=$this->AnextureModel->anextureedit($anextureID);
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		echo json_encode($response);
		exit;
	
		
	}








}