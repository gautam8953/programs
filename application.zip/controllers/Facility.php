<?php  
defined('BASEPATH') OR exit('No direct script access allowed');

class Facility extends CI_Controller {
	public function __construct()
	{
		parent :: __construct();
		$userID=$this->session->userdata('UserID');
		if(empty($userID)){ redirect('user/login'); }
		$this->load->model('FacilityModel');
	}
		
	public function index(){
		$this->CommonModel->checkPageAccessWeb('facility/index',$this->session->userdata('RoleName'));
		$data=array();
		$data['search_options']=$this->FacilityModel->searchOptions();		
		$this->load->view('header');
		$this->load->view('facility/index',$data);
		$this->load->view('footer');
	}
	public function add(){
		$data=array();
		$data['search_options']=$this->FacilityModel->getSearchOptions();		
		$this->load->view('header');
		$this->load->view('facility/add',$data);
		$this->load->view('footer');
	}
	public function pages(){
		$saveBtn=$this->input->post('facility');
		if(!empty($saveBtn)){
			$options=$this->input->post('facilityoption');
			switch ($options) {
				case '1':
					redirect('facility/labourFacility');
					break;
				case '2':
					redirect('facility/operationFacility');
					break;				
				default:
					redirect('facility/labourFacility');
					break;
			}
		} else{
			$data['surveyOption']=$this->FacilityModel->getSurveyOption();
			$this->load->view('header');
			$this->load->view('facility/facility_options',$data);
			$this->load->view('footer');
		}
	}
	public function labourFacility(){
		$data=array('ansId'=>0);
		$uriParam=$this->uri->segment('3');
		if(!empty($uriParam)){
			$data['ansId']=encryptor($uriParam,'decrypt');
		}
		if($data['ansId']>0){
			$data['survey']=$this->FacilityModel->getQuestionsAll('1');
			$this->load->view('header');
			$this->load->view('facility/labour_room_facility',$data);
			$this->load->view('footer');
		} else {
			redirect('facility/index');
		}

	}
	public function operationFacility(){
		$data=array('ansId'=>0);
		$uriParam=$this->uri->segment('3');
		if(!empty($uriParam)){
			$data['ansId']=encryptor($uriParam,'decrypt');
		}
		if($data['ansId']>0){
			$data['survey']=$this->FacilityModel->getQuestionsAll('2');
			$this->load->view('header');
			$this->load->view('facility/operation_theater_facility',$data);
			$this->load->view('footer');
		} else {
			redirect('facility/index');
		}
	}
	public function labourChecklist(){
		$data=array('ansId'=>0);
		$uriParam=$this->uri->segment('3');
		if(!empty($uriParam)){
			$data['ansId']=encryptor($uriParam,'decrypt');
		}
		if($data['ansId']>0){
			$data['survey']=$this->FacilityModel->getQuestionsAll('1');
			$this->load->view('header');
			$this->load->view('facility/labour_room_checklist',$data);
			$this->load->view('footer');
		} else {
			redirect('facility/index');
		}
	}
	public function operationChecklist(){
		$data=array('ansId'=>0);
		$uriParam=$this->uri->segment('3');
		if(!empty($uriParam)){
			$data['ansId']=encryptor($uriParam,'decrypt');
		}
		if($data['ansId']>0){
			$data['survey']=$this->FacilityModel->getQuestionsAll('2');
			$this->load->view('header');
			$this->load->view('facility/operation_theater_checklist',$data);
			$this->load->view('footer');
		} else {
			redirect('facility/index');
		}

	}
	public function surveyFormatDownload($ansId,$format){
		$data=array('ansId'=>0);
		$uriParam=$this->uri->segment('3');
		if(!empty($uriParam)){
			$data['ansId']=encryptor($uriParam,'decrypt');
			if(!$this->CommonModel->checkPageActionWeb('facility/index','access_view',$this->session->userdata('RoleName'))){
			    redirect('/');
			}
		}
		if($data['ansId']>0){
			$data['data']['format']=$format;
			$data['data']=$this->FacilityModel->surveyFormatDownload($data);
			$this->load->view('facility/facility_excel',$data);
		} else {
			redirect('facility/index');
		}
	}
	public function surveyFormatPdf($ansId='',$format=''){
		$this->load->library('Pdf');
		$html='';
		$data=array('ansId'=>0);
		if(!empty($ansId)){
			$data['ansId']=encryptor($ansId,'decrypt');
		}
		if(!empty($format)){
			$data['format']=encryptor($format,'decrypt');
		}
		if(!empty($data['ansId']) && !empty($data['format']) ){
			$data['data']=$this->FacilityModel->surveyFormatDownload($data);
	        $html.=$this->load->view('facility/facility_pdf',$data,true);
	        $pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
	        $pdf->SetTitle($data['data']['score'][0]['SurveyName']);
	        $pdf->SetHeaderMargin(20);
	        $pdf->SetTopMargin(0); 
	        $pdf->setFooterMargin(20);
	        $pdf->SetAutoPageBreak(true);
	        $pdf->SetPrintHeader(false);
			$pdf->SetPrintFooter(false);
	        $pdf->SetAuthor('Author');
	        $pdf->SetDisplayMode('real', 'default');
	        $pdf->AddPage();
	        $pdf->writeHTML($html, true, false, true, false, '');
	        $userFolder=$this->session->userdata('UserID');
	        if (!file_exists('assets/pdf/'.$userFolder)) {
	            mkdir('assets/pdf/'.$userFolder, 0777, true);
	        }
	        if($data['data']['score'][0]['SurveyName']=='Operation Theater'){
	        	$pdfName='otassessment.pdf';
	        } else {
	        	$pdfName='lrassessment.pdf';
	        }
	        $pdf->Output(__DIR__ . '../../../assets/pdf/'.$userFolder.'/'.$pdfName, 'F');
	        $this->load->helper('download');
	        $file = file_get_contents(base_url()."/assets/pdf/".$userFolder."/".$pdfName);
	        force_download($pdfName, $file);
	        echo '<script>window.close()</script>';
		} else {
			redirect('facility/index');
		}
	}
	public function setFormatData(){
		$survey=$this->input->post('survey');
		$catgory=$this->input->post('catgory');
		$user_page_data=array(
				'pageData'=>array(
				'survey'=>$survey,
				'catgory'=>$catgory
				)
		);
		$this->session->set_userdata($user_page_data);
	}
	function assesment(){
		$uriParam=$this->uri->segment('3');
		if(!empty($uriParam)){
			$data['surveyId']=encryptor($uriParam,'decrypt');
		}
		if($data['surveyId']=='1' || $data['surveyId']=='2'){
			$data=array();
			$data['search_options']=$this->FacilityModel->getSearchOptions();
			$this->load->view('header');
			$this->load->view('facility/assesment',$data);
			$this->load->view('footer');			
		} else {
			redirect('facility/index');
		}


	}
	function score(){
		$data=array('ansId'=>0);
		$uriParam=$this->uri->segment('3');
		if(!empty($uriParam)){
			$data['ansId']=encryptor($uriParam,'decrypt');
			if(!$this->CommonModel->checkPageActionWeb('facility/index','access_view',$this->session->userdata('RoleName'))){
			    redirect('/');
			}
		}
		if($data['ansId']>0){
			$this->load->view('header');
			$this->load->view('facility/score');
			$this->load->view('footer');
		} else {
			redirect('facility/index');
		}
	}
	function assesmentData(){
		$data=array('ansId'=>0);
		$uriParam=$this->uri->segment('3');
		if(!empty($uriParam)){
			$data['ansId']=encryptor($uriParam,'decrypt');
		}
		if($data['ansId']>0){
			$this->load->view('header');
			$this->load->view('facility/assesmentView');
			$this->load->view('footer');
		} else {
			redirect('facility/index');
		}
	}
	function assesmentimport(){
		$this->CommonModel->checkPageAccessWeb('facility/assesmentimport',$this->session->userdata('RoleName'));
		$data=array();
		$data['search_options']=$this->FacilityModel->getSearchOptions();
		$this->load->view('header');
		$this->load->view('facility/assesmentimport',$data);
		$this->load->view('footer');
	}
	function viewscore(){
		if(!$this->CommonModel->checkPageActionWeb('facility/index','access_view',$this->session->userdata('RoleName'))){
		    redirect('/');
		}
		$data=array('ansId'=>0);
		$uriParam=$this->uri->segment('3');
		if(!empty($uriParam)){
			$data['ansId']=encryptor($uriParam,'decrypt');
		}
		if($data['ansId']>0){
			$this->load->view('header');
			$this->load->view('facility/viewscore');
			$this->load->view('footer');
		} else {
			redirect('facility/index');
		}
	}
	public function surveySampleDownload(){
		$uriParam=$this->uri->segment('3');
		if($uriParam=='1' || $uriParam=='2' ){
			$data['data']=$this->FacilityModel->surveySampleDownload($uriParam);
			$this->load->view('facility/sample_excel',$data);
		} else {
			redirect('facility/index');
		}
	}
	function checklist($uriParam='',$uriParamAns=''){
		$data=array('ansId'=>0,'surveyId'=>0);
		//$uriParam=$this->uri->segment('3');
		//$uriParamAns=$this->uri->segment('3');
		if(!empty($uriParamAns)){
			// edit page validate
			$data['ansId']=encryptor($uriParamAns,'decrypt');
			if(empty($data['ansId']) || $data['ansId']<=0){
				redirect('facility/index');
			}
			if(!$this->CommonModel->checkPageActionWeb('facility/index','access_edit',$this->session->userdata('RoleName'))){
				redirect('/');
			}
		} else {
			// add page validate
			//$this->CommonModel->checkPageAccessWeb('facility/checklist/'.$uriParam,$this->session->userdata('RoleName'));
			if(!$this->CommonModel->checkPageActionWeb('facility/checklist/'.$uriParam,'access_add',$this->session->userdata('RoleName'))){
				redirect('/');
			}
		}
		if(!empty($uriParam)){
			$data['surveyId']=encryptor($uriParam,'decrypt');
		}
		
		if($data['surveyId']=='1' || $data['surveyId']=='2'){
			$data['search_options']=$this->FacilityModel->getSearchOptions();
			$data['survey']=$this->FacilityModel->getQuestionsAll($data['surveyId']);
			$this->load->view('header');
			$this->load->view('facility/checklist',$data);
			$this->load->view('footer');			
		} else {
			redirect('facility/index');
		}		
	}
	function checklistview(){
		if(!$this->CommonModel->checkPageActionWeb('facility/index','access_view',$this->session->userdata('RoleName'))){
			redirect('/');
		}
		$data=array('ansId'=>0,'surveyId'=>0);
		$uriParam=$this->uri->segment('3');
		$uriParamAns=$this->uri->segment('4');
		$uriParamFormat=encryptor($this->uri->segment('5'),'decrypt');
		if($uriParamFormat!='B'){
			$uriParamFormat='A';
		}
		$data['uriParamFormat']=$uriParamFormat;
		if(!empty($uriParamAns)){
			$data['ansId']=encryptor($uriParamAns,'decrypt');
			if(empty($data['ansId']) || $data['ansId']<=0){
				redirect('facility/index');
			}
		}
		if(!empty($uriParam)){
			$data['surveyId']=encryptor($uriParam,'decrypt');
		}
		if($data['surveyId']=='1' || $data['surveyId']=='2'){
			$data['search_options']=$this->FacilityModel->getSearchOptions();
			$data['survey']=$this->FacilityModel->getQuestionsAll($data['surveyId'],$uriParamFormat);
			$data['scoreData']=$this->FacilityModel->getFacilityScore($data['ansId']);
			//echo "<pre>"; print_r($data['scoreData']); echo "</pre>";
			$this->load->view('header');
			$this->load->view('facility/checklistview',$data);
			$this->load->view('footer');			
		} else {
			redirect('facility/index');
		}		
	}
	function gapanalysis($ansID='',$format=''){
		if(!$this->CommonModel->checkPageActionWeb('facility/index','access_view',$this->session->userdata('RoleName'))){
		    redirect('/');
		}
		$data=array();
		$ansID=encryptor($ansID,'decrypt');
		$format=strtoupper(encryptor($format,'decrypt'));
		if(empty($ansID) || !in_array($format, array('A','B'))){
			redirect('/');
		} else {
			$data['search_answer']=$ansID;
			$data['search_format']=$format;
			$data['data']=$this->FacilityModel->assessment_summary($ansID,$format);
			$data['search_options']=$this->FacilityModel->getGapOptions($ansID,$format);
			//echo "<pre>"; print_r($data); echo "</pre>";

			$this->load->view('header');
			$this->load->view('facility/gapanalysis',$data);
			$this->load->view('footer');
		}

	}
	function addfacility(){
		// remove it
		$data=array();		
        $userID = $this->session->userdata('UserID');
        $RoleName=$this->session->userdata('RoleName');
		$data['search_options']=$this->FacilityModel->getSearchOptions();
		$this->load->view('header');
		$this->load->view('facility/addfacility',$data);
		$this->load->view('footer');
	}
	function analysis(){
		if(!$this->CommonModel->checkPageActionWeb('facility/index','access_view',$this->session->userdata('RoleName'))){
		    redirect('/');
		}
		$data=array();
		$ansID=encryptor($ansID,'decrypt');
		$format=strtoupper(encryptor($format,'decrypt'));
		if(empty($ansID) || !in_array($format, array('A','B'))){
			redirect('/');
		} else {
			$data['search_answer']=$ansID;
			$data['search_format']=$format;
			$data['search_options']=$this->FacilityModel->getSearchOptions();
			$data['gap_options']=$this->FacilityModel->getGapOptions($ansID,$format);
			$this->load->view('header');
			$this->load->view('facility/gapanalysis',$data);
			$this->load->view('footer');
		}

	}

}


