<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ApiHr extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //check_user();
        $this->load->model('HrModel');

               }

    public function index() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey']=$this->session->userdata('APIKey'); 
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey']=$this->session->userdata('APIKey'); 
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    //$data = $this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(isset($dataHeader['device']) && $dataHeader['device']=='app'){
            $response['APIKey']=$this->session->userdata('APIKey');            
        }
        echo json_encode($response);
        exit;
    }



 public function add() {
      $data = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
       
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                   
                    //get data and process web requrest
                    //$data = $this->input->post();
                    // $data = array();
                  //  $data['device'] = 'web';
                        $data['UserID']=$this->session->userdata('UserID');
                        $data['FacilityHead']=$this->input->post('FacilityHead');
                        $data['Gynecologist']=$this->input->post('Gynecologist');
                        $data['Pediatrician']=$this->input->post('Pediatrician');
                        $data['Anesthetist']=$this->input->post('Anesthetist');
                        $data['MedicalOfficer']=$this->input->post('MedicalOfficer');
                        $data['lr_staff_name']=$this->input->post('lr_staff_name');
                        $data['ot_staff_name']=$this->input->post('ot_staff_name');
                        $data['FacilityTypeDetailID']=$this->input->post('FacilityTypeDetailID');
                        $data['total_sba_trained']=$this->input->post('total_sba_trained');
                        $data['total_lab_trained']=$this->input->post('total_lab_trained');
                        $data['avg_delivery_month']=$this->input->post('avg_delivery_month');
                        $data['avg_section_month']=$this->input->post('avg_section_month');
                        $data['total_laborbeds']=$this->input->post('total_laborbeds');
                        $data['IsTrained']=$this->input->post('IsTrained');
                        $data['MaternityProtocol']=$this->input->post('MaternityProtocol');
                        $data['QualityProtocol']=$this->input->post('QualityProtocol');
                        $data['IsSkillsLab']=$this->input->post('IsSkillsLab');
                        $data['avbl_eq_in_lr']=$this->input->post('avbl_eq_in_lr');
                        $data['avbl_eq_in_ot']=$this->input->post('avbl_eq_in_ot');
                        $data['avbl_drg_in_lr']=$this->input->post('avbl_drg_in_lr');
                        $data['avbl_drg_in_ot']=$this->input->post('avbl_drg_in_ot');
                        $user = $this->HrModel->checkData($this->session->userdata('UserID'));
                       
                        if($user['id'] > 0 ){
                          
                            $id =$user['id'];
                           // $id=encryptor($id,'decrypt');
                            // $ansId = $this->HrModel->updateRecord('hr', $user['id'],$data1=array('IsActive' => 0));
                           
                            $ansId = $this->HrModel->updateRecord('hr', $id,$data);
                        }else{
                          
                           
                             $ansId = $this->HrModel->saveData($data);
                        }
                      
                       
                    if ($ansId > 0) {
                        $response['code'] = '0';
                        $response['msg'] = $this->config->item('errCodes')[0];
                    } else {
                        $response['code'] = '11';
                        $response['msg'] = $this->config->item('errCodes')[11];
                    }
                    echo json_encode($response);
                    return;
                } else {
                    // redirect('/');
                }
            } else {
//            redirect('/');
            }
        }
    }
        


        public function getSearchData() {
        if ($this->CommonModel->checkAPIWebUser()) {
        $searchData = $this->input->post();

            if($this->session->userdata('RoleName')=='State'){
                $searchData['cond']=array('mappedField'=>'f.StateID','mappedData'=>$this->session->userdata('MappedState'));
            }
            if($this->session->userdata('RoleName')=='District'){
                $searchData['cond']=array('mappedField'=>'f.DistrictID','mappedData'=>$this->session->userdata('MappedDistrict'));
            }
            if($this->session->userdata('RoleName')=='Facility'){
                $searchData['cond']=array('mappedField'=>'um.UserID','mappedData'=>$this->session->userdata('UserID'));
            }
        $userID = $this->session->userdata('UserID');
        $search_months = $this->input->post('search_months');
        $search_years = $this->input->post('search_years');
        $search_state = $this->input->post('search_state');
        $search_district = $this->input->post('search_district');
        $search_facility = $this->input->post('search_facility');
        $data = $this->HrModel->getSearchData($userID, $searchData, $search_state,$search_district,$search_facility);
        $json_data = array(
            "draw" => intval($data['draw']),
            "recordsTotal" => intval($data['totalData']),
            "recordsFiltered" => intval($data['totalFilter']),
            "data" => $data['data']
        );
        echo json_encode($json_data);
        }
    }



public function deleteData() {
        if ($this->CommonModel->checkAPIWebUser()) {
        $status = $this->HrModel->updateRecord('hr', encryptor($this->input->post('id'),'decrypt'), array('isActive' => 0));
        echo $status;
        }
    }

   
    
    

    function getProfile(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $RoleName=$data1['RoleName'];
                    $UserID=$this->session->userdata('UserID');
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($RoleName) && !empty($UserID)){
            if($RoleName=='Facility'){
              $response['facility']=$this->UserModel->getFacilityDetails($UserID);
            }
            $response['main']=$this->UserModel->getProfileDetails($UserID,'main');
            if($RoleName!='Facility' ){
              $response['nodal']=$this->UserModel->getProfileDetails($UserID,'nodal');          
            }            
        }
        $response['code']=0;
        $response['UserID']=$UserID;
        $response['RoleName']=$RoleName;
        echo json_encode($response);
        exit;
    }

    function getStateData(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        $data=array();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $data['state']=$data1['state'];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data['state']=$this->input->post('state');
                    $data['mappedData']= $this->session->userdata('MappedState');
                    $data['mappedField']='f.StateID';
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $response['code']=0;
        $response['data']=$this->CommonModel->getDashboardData($data);
        echo json_encode($response);
        exit;
    }
    
   

   
    function getfacilities(){
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $response=$this->CommonModel->getfacilities($data);
        echo json_encode($response);
        exit;        
    }
    
   
   
    
    

    
    public function facilitytype($facilityType=''){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    //$data = $this->CommonModel->getApiData();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    //$data=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(empty($facilityType) ){
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];            
        } else {
            $response=$this->CommonModel->facilitytype($facilityType);
        }
        echo json_encode($response);
        exit;
    }
   
    function getFacilityTypeData(){
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $searchData=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $data=$this->CommonModel->getFacilityTypeData($searchData);
        echo json_encode($data);
        exit;        
    }

     function getHrView() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $page = $data['setMonthViewPage'];
                    $facilityUser = $data['facilityUser'];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey'] = $this->session->userdata('APIKey');
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey'] = $this->session->userdata('APIKey');
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $page = $this->session->userdata('setMonthViewPage');
                    //$facilityUser = $this->session->userdata('facilityUser');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(!empty($page)){
            $response = $this->HrModel->getHrView($page);
        } else {
            $response['code']='9';
            $response['msg']=$this->config->item('errCodes')[9];
        }
        
        if (isset($dataHeader['device']) && $dataHeader['device'] == 'app') {
            $response['APIKey'] = $this->session->userdata('APIKey');
        }
        echo json_encode($response);
        exit;
    }
  

    


    

   
      


}
