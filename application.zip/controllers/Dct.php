<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dct extends CI_Controller {

    public function __construct() {
        parent :: __construct();
        $userID=$this->session->userdata('UserID');
        $RoleName=$this->session->userdata('RoleName');
        if(empty($userID)){ 
            redirect('user/login');
        } else {
            $this->load->model('DctModel');
            $this->load->model('FacilityModel');
        }

    }

    public function index() {
        $this->CommonModel->checkPageAccessWeb('dct/index',$this->session->userdata('RoleName'));
        /*if(!$this->CommonModel->checkPageActionWeb('dct/index','access_view',$this->session->userdata('RoleName'))){
            redirect('/');
        }*/
        $data = array();
        $data['search_options'] = $this->FacilityModel->getSearchOptions();
        $this->load->view('header');
        $this->load->view('dct/index', $data);
        $this->load->view('footer');
    }

    public function add() {
        //$this->CommonModel->checkPageAccessWeb('dct/add',$this->session->userdata('RoleName'));
        if(!$this->CommonModel->checkPageActionWeb('dct/add','access_add',$this->session->userdata('RoleName'))){
            redirect('/');
        }
        $data = array();
        $data['search_options'] = $this->FacilityModel->getSearchOptions();
        $this->load->view('header');
        $this->load->view('dct/add', $data);
        $this->load->view('footer');
    }

}