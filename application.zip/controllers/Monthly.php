<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Monthly extends CI_Controller {

    public function __construct() {
        parent :: __construct();
        $userID = $this->session->userdata('UserID');
        if (empty($userID)) {
            redirect('user/login');
        }
        $this->load->model('FacilityModel');
        $this->load->model('MonthlyModel');
    }

    public function index() {
        $this->CommonModel->checkPageAccessWeb('monthly/index',$this->session->userdata('RoleName'));
        $data = array();
        $data['search_options'] = $this->FacilityModel->getSearchOptions_new();
        // print_r($data);
        $this->load->view('header');
        $this->load->view('monthly/index', $data);
        $this->load->view('footer');
        // echo "<pre>"; print_r($data); echo "</pre>";

    }

    public function add() {        
        $data = array();
        $data['search_options'] = $this->FacilityModel->getSearchOptions();
        $data['MonthlyID'] = 0;
        $uriParam = $this->uri->segment('3');
        if (!empty($uriParam)) {
            // edit page
            $data['MonthlyID'] = encryptor($uriParam, 'decrypt');
            $data['showSearch'] = 0;
            if (!$data['MonthlyID'] > 0) {
                redirect('monthly/index');
            }
            if($this->CommonModel->checkPageActionWeb('monthly/index','access_edit',$this->session->userdata('RoleName')) || $this->CommonModel->checkPageActionWeb('monthly/add','access_add',$this->session->userdata('RoleName'))){
            } else {
                redirect('/');
            }
        } else {
            // add page
            $data['showSearch'] = 1;
            if(!$this->CommonModel->checkPageActionWeb('monthly/add','access_add',$this->session->userdata('RoleName'))){
                redirect('/');
            }
        }
       // print_r($data);
        $this->load->view('header');
        $this->load->view('monthly/add', $data);
        $this->load->view('footer');
    }

    public function view() {
        $data = array('MonthlyID' => 0);
        $uriParam = $this->uri->segment('3');
        if (!empty($uriParam)) {
            $data['MonthlyID'] = encryptor($uriParam, 'decrypt');
            if(!$this->CommonModel->checkPageActionWeb('monthly/index','access_view',$this->session->userdata('RoleName'))){
                redirect('/');
            }
        }
        if ($data['MonthlyID'] > 0) {
            $this->load->view('header');
            $this->load->view('monthly/view', $data);
            $this->load->view('footer');
        } else {
            redirect('monthly/index');
        }
    }

    public function report() {
        $this->CommonModel->checkPageAccessWeb('monthly/report',$this->session->userdata('RoleName'));
        $data = array();
        $data['search_options'] = $this->FacilityModel->getSearchOptions();
        $this->load->view('header');
        $this->load->view('monthly/monthly_report', $data);
        $this->load->view('footer');
    }
    public function report_certificate($CertificationID='',$monthCount=''){
        $data = array();
        $CertificationIDs=encryptor($CertificationID,'decrypt');
        $monthCounts=encryptor($monthCount,'decrypt');
        if(empty($CertificationIDs) || empty($monthCounts)){
            redirect('/');
        } else {
            $data['CertificationID']=$CertificationIDs;
            $data['monthCount']=$monthCounts;
            $this->load->view('header');
            $this->load->view('monthly/monthly_report_certificate', $data);
            $this->load->view('footer');
        }
    }
    public function report_certificate_pdf($CertificationID='',$monthCount=''){
        $this->load->library('Pdf');
        $html='';
        $data = array();
        $CertificationIDs=encryptor($CertificationID,'decrypt');
        if(empty($CertificationIDs)){
            redirect('/');
        } else {
            $data['CertificationID']=$CertificationID;
            if(!empty($monthCount)){
                $data['monthCount']=$monthCount;
                $data['indicator_data']=$this->MonthlyModel->reportData_certificate($data);
                $html.=$this->load->view('monthly/monthly_report_certificate_pdf',$data,true);
                $monthCounts=encryptor($monthCount,'decrypt');
                $pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
                $pdf->SetTitle('Laqshya Indicator Report');
                $pdf->SetHeaderMargin(20);
                $pdf->SetTopMargin(0); 
                $pdf->setFooterMargin(20);
                $pdf->SetAutoPageBreak(true);
                $pdf->SetPrintHeader(false);
                $pdf->SetPrintFooter(false);
                $pdf->SetAuthor('Author');
                $pdf->SetDisplayMode('real', 'default');
                $pdf->AddPage();
                $pdf->writeHTML($html, true, false, true, false, '');
                $userFolder=$this->session->userdata('UserID');
                if (!file_exists('assets/pdf/'.$userFolder)) {
                    mkdir('assets/pdf/'.$userFolder, 0777, true);
                }        
                $pdf->Output(__DIR__ . '../../../assets/pdf/'.$userFolder.'/hospitaldata.pdf', 'F');
                $this->load->helper('download');
                $file = file_get_contents(base_url()."/assets/pdf/".$userFolder."/hospitaldata.pdf");
                $name = 'indicator_report_'.$monthCounts.'.pdf';
                force_download($name, $file);
                
            } else {
                for ($i=1; $i <=3 ; $i++) { 
                    $data['monthCount']=encryptor($i);
                    $data['indicator_data']=$this->MonthlyModel->reportData_certificate($data);
                    $html.=$this->load->view('monthly/monthly_report_certificate_pdf',$data,true);
                    $monthCounts=$i;
                    $pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
                    $pdf->SetTitle('Laqshya Indicator Report');
                    $pdf->SetHeaderMargin(20);
                    $pdf->SetTopMargin(0); 
                    $pdf->setFooterMargin(20);
                    $pdf->SetAutoPageBreak(true);
                    $pdf->SetPrintHeader(false);
                    $pdf->SetPrintFooter(false);
                    $pdf->SetAuthor('Author');
                    $pdf->SetDisplayMode('real', 'default');
                    $pdf->AddPage();
                    $pdf->writeHTML($html, true, false, true, false, '');
                    $userFolder=$this->session->userdata('UserID');
                    if (!file_exists('assets/pdf/'.$userFolder)) {
                        mkdir('assets/pdf/'.$userFolder, 0777, true);
                    }        
                    $pdf->Output(__DIR__ . '../../../assets/pdf/'.$userFolder.'/hospitaldata.pdf', 'F');
                    $this->load->helper('download');
                    $file = file_get_contents(base_url()."/assets/pdf/".$userFolder."/hospitaldata.pdf");
                    $name = 'indicator_report_'.$monthCounts.'.pdf';
                    force_download($name, $file); 
                }
            }
            echo '<script>window.close()</script>';
        }
    }


         public function inActiveRecord($MonthlyID=""){
                $MonthlyID=encryptor($MonthlyID,'decrypt');
                $data=array();
                $saveData['IsActive']= 0;
                $data=$this->MonthlyModel->inActiveAssesmentData($saveData,$MonthlyID);
                if($data)  {
                    redirect('monthly/index');
                }else{
                     redirect('monthly/index');
                }
    
           }

    
}

?>