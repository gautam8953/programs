<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $userID = $this->session->userdata('UserID');
        if (empty($userID)) {
            redirect('user/login');
        }
    }

	public function index(){
		redirect('/');
	}
	public function checklist(){
		$this->CommonModel->checkPageAccessWeb('reports/checklist',$this->session->userdata('RoleName'));
      	$data=array();
      	$this->load->view('header');
      	$this->load->view('reports/checklist',$data);
		$this->load->view('footer');
	}

	public function osce(){
		$this->CommonModel->checkPageAccessWeb('reports/osce',$this->session->userdata('RoleName'));
      	$this->load->model('FacilityModel');
		$data=array('OsceID'=>0);
		$uriParam=$this->uri->segment('3');
		if(!empty($uriParam)){
			$data['OsceID']=encryptor($uriParam,'decrypt');
			if(empty($data['OsceID'])){
				redirect('reports/osce');
			} else {
				$data['osceForm']=$this->FacilityModel->oscedataForm($data['OsceID']);
			}
		}
      	$data['osce']=$this->FacilityModel->oscedata($this->session->userdata('UserID'));
      	$this->load->view('header');
      	$this->load->view('reports/osce',$data);
		$this->load->view('footer');
	}

}