<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ApiDct extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //check_user();
        $this->load->model('DctModel');
        $this->load->model('FacilityModel');
        $RoleName=$this->session->userdata('RoleName');
        if(!($RoleName=='Ministry' || $RoleName=='State' || $RoleName=='District')){
            $response['code'] = '15';
            $response['msg'] = $this->config->item('errCodes')[15];
            echo json_encode($response);
            exit;
        }

    }

    public function add() {
        $data = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    //$data = $this->input->post();
                    $saveData = array();
                    $saveData['device'] = 'web';
                    $saveData['name'] = $this->input->post('name');
                    $saveData['department'] = $this->input->post('department');
                    $saveData['designation'] = $this->input->post('designation');
                    $saveData['designationSmg'] = $this->input->post('designation_smg');
                    $saveData['email'] = $this->input->post('email');
                    $saveData['mobile'] = $this->input->post('mobile');
                    $saveData['userId'] = $this->session->userdata('UserID');
                    $saveData['stateId'] = $this->input->post('search_state');
                    $saveData['districtId'] = $this->input->post('search_district');

                    for ($i = 0; $i < count($this->input->post('name')); $i++) {
                        if ($this->session->userdata('RoleName') == 'District') {
                            $StateId = $this->DctModel->getStateId($saveData['districtId'][$i]);
                            if ($StateId > 0) {
                                $data1['stateId'] = $StateId; 
                            } else {
                                $response['code'] = '0';
                                $response['data'] = $facilityData;
                                $response['msg'] = count($facilityData) . ' Data get';
                            }
                        }else{
                             $data1['stateId'] = $saveData['stateId'][$i];
                        }
                        $data1['name'] = $saveData['name'][$i];
                        $data1['department'] = $saveData['department'][$i];
                        $data1['designation'] = $saveData['designation'][$i];
                        $data1['designationSmg'] = $saveData['designationSmg'][$i];
                        $data1['email'] = $saveData['email'][$i];
                        $data1['mobile'] = $saveData['mobile'][$i];
                        $data1['userId'] = $this->session->userdata('UserID');
                       
                        $data1['districtId'] = $saveData['districtId'][$i];
//                        echo $data1['districtId'];
                        $data1['createdOn'] = date('Y-m-d h:i:s');
                        $data1['createdBy'] = $data1['userId'];
//                        $data1['districtId'] = 5;
//                         echo "<pre>";
//                    print_r($saveData['districtId']);
                        $ansId = $this->DctModel->saveData($data1);
                    }

                    if ($ansId > 0) {
                        $response['code'] = '0';
                        $response['msg'] = $this->config->item('errCodes')[0];
                    } else {
                        $response['code'] = '11';
                        $response['msg'] = $this->config->item('errCodes')[11];
                    }
                    echo json_encode($response);
                    return;
                } else {
                    // redirect('/');
                }
            } else {
//            redirect('/');
            }
        }
    }

    public function getSearchOptions() {
        if ($this->CommonModel->checkAPIWebUser()) {
        switch ($this->session->userdata('RoleName')) {
            case 'District':
                $searchType = $this->input->post('searchType');
                $searchData = $this->input->post('searchData');
                if (!empty($searchType) && !empty($searchData)) {
                    if ($searchType == 'facility') {
                        $facilityData = $this->FacilityModel->getFacilityFromDistrict($searchData);
                        $response['code'] = '0';
                        $response['data'] = $facilityData;
                        $response['msg'] = count($facilityData) . ' Data get';
                    } else {
                        $response['code'] = '14';
                        $response['msg'] = 'No Proper Data Submitted';
                    }
                } else {
                    $response['code'] = '14';
                    $response['msg'] = 'No Proper Data Submitted';
                }
                break;
            case 'State':
                $searchType = $this->input->post('searchType');
                $searchData = $this->input->post('searchData');
                if (!empty($searchType) && !empty($searchData)) {
                    if ($searchType == 'district') {
                        $districtData = $this->FacilityModel->getDistrictDataFromState($searchData);
                        $response['code'] = '0';
                        $response['data'] = $districtData;
                        $response['msg'] = count($districtData) . ' Data get';
                    } else if ($searchType == 'facility') {
                        $facilityData = $this->FacilityModel->getFacilityFromDistrict($searchData);
                        $response['code'] = '0';
                        $response['data'] = $facilityData;
                        $response['msg'] = count($facilityData) . ' Data get';
                    } else {
                        $response['code'] = '14';
                        $response['msg'] = 'No Proper Data Submitted';
                    }
                } else {
                    $response['code'] = '14';
                    $response['msg'] = 'No Proper Data Submitted';
                }
                break;
            case 'Ministry':
                $searchType = $this->input->post('searchType');
                $searchData = $this->input->post('searchData');
                if (!empty($searchType) && !empty($searchData)) {
                    if ($searchType == 'district') {
                        $districtData = $this->FacilityModel->getDistrictDataFromState($searchData);
                        $response['code'] = '0';
                        $response['data'] = $districtData;
                        $response['msg'] = count($districtData) . ' Data get';
                    } else if ($searchType == 'facility') {
                        $facilityData = $this->FacilityModel->getFacilityFromDistrict($searchData);
                        $response['code'] = '0';
                        $response['data'] = $facilityData;
                        $response['msg'] = count($facilityData) . ' Data get';
                    } else {
                        $response['code'] = '14';
                        $response['msg'] = 'No Proper Data Submitted';
                    }
                } else {
                    $response['code'] = '14';
                    $response['msg'] = 'No Proper Data Submitted';
                }
                break;
            default:
                $response['code'] = '14';
                $response['msg'] = 'No Proper Data Submitted';
                break;
        }
        echo json_encode($response);
    }
    }

    public function getSearchData() {
        if ($this->CommonModel->checkAPIWebUser()) {
        $searchData = $this->input->post();
        $userID = $this->session->userdata('UserID');
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            $search_state = $this->input->post('search_state');
            $search_district = $this->input->post('search_district');
            $mappedStateID = '18,20';
            $mappedDistrictID = '329';
            $data = $this->DctModel->getSearchData($userID, $searchData, $search_state, $search_district, $mappedStateID, $mappedDistrictID);
            $json_data = array(
                "draw" => intval($data['draw']),
                "recordsTotal" => intval($data['totalData']),
                "recordsFiltered" => intval($data['totalFilter']),
                "data" => $data['data']
            );
        }
        echo json_encode($json_data);
    }
    }

    public function deleteData() {
        if ($this->CommonModel->checkAPIWebUser()) {
        $status = $this->DctModel->updateRecord('dct', encryptor($this->input->post('id'),'decrypt'), array('isActive' => 0));
        echo $status;
        }
    }

    public function updateData() {
        $data = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    //$data = $this->input->post();
                    $saveData = array();
                    $saveData['device'] = 'web';
                    $saveData['name'] = $this->input->post('name');
                    $saveData['department'] = $this->input->post('department');
                    $saveData['designation'] = $this->input->post('designation');
                    $saveData['designationSmg'] = $this->input->post('designationSmg');
                    $saveData['email'] = $this->input->post('email');
                    $saveData['mobile'] = $this->input->post('mobile');
                    $saveData['userId'] = $this->session->userdata('UserID');
//                    $saveData['stateId'] = $this->input->post('search_state');
                    $id = encryptor($this->input->post('id'),'decrypt');

                    $data1['name'] = $saveData['name'];
                    $data1['department'] = $saveData['department'];
                    $data1['designation'] = $saveData['designation'];
                    $data1['designationSmg'] = $saveData['designationSmg'];
                    $data1['email'] = $saveData['email'];
                    $data1['mobile'] = $saveData['mobile'];
                    $data1['userId'] = $this->session->userdata('UserID');
//                        $data1['stateId'] = $saveData['stateId'];
                    $data1['modifiedOn'] = date('Y-m-d h:i:s');
                    $data1['modifiedBy'] = $data1['userId'];
                    $ansId = $this->DctModel->updateRecord('dct', $id, $data1);

                    if ($ansId > 0) {
                        $response['code'] = '0';
                        $response['msg'] = $this->config->item('errCodes')[0];
                    } else {
                        $response['code'] = '11';
                        $response['msg'] = $this->config->item('errCodes')[11];
                    }
                    echo json_encode($response);
                    return;
                } else {
                    // redirect('/');
                }
            } else {
//            redirect('/');
            }
        }
    }

}
