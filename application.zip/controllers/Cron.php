<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cron extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('CronModel');
        $this->load->model('FacilityModel');
        $this->load->model('CommonModel');
    }

    public function index() {

    }
    public function facility_update(){
      $data=array();
      $data['facilities']=$this->CommonModel->facility_update();
      //$this->load->view('header');
      //$this->load->view('user/facility_update',$data);
      //$this->load->view('footer');
    }
    public function assesmentcron(){
    $dir    = FCPATH.'assets/uploads/cron_assessment';
    $files = scandir($dir);
    $dataLog=array();
    foreach ($files as $keyFile => $valueFile) {      
        if($valueFile=='.' || $valueFile=='..'){
          continue;
        } else {
          $file = FCPATH.'assets/uploads/cron_assessment/'.$valueFile;
          $fileDate=date("Y-m-d H:i:s", filemtime($file));
          $fileCheck=$this->CronModel->fileCheck($valueFile);

          if(is_file($file) && $fileCheck){
            $arrExt=explode('.', $valueFile);
            $ext = end($arrExt);
            $checklist_format='A';
            if(in_array(strtolower($ext), $this->config->item('ExcelTypes'))){
              $facilityData=$this->CronModel->facilityData($arrExt[0]);
              if(!empty($facilityData['UserID']) && !empty($facilityData['SurveyID']) && !empty($facilityData['Sequence'])){
                $this->load->library('excel');
                $objPHPExcel = PHPExcel_IOFactory::load($file);
                $objPHPExcel->setActiveSheetIndex(0);
                $arr_data=$objPHPExcel->getActiveSheet()->toArray();
                $questionStart=0;
                $err=array();
                $errAns=array();
                $done=array();
                $q1=$q2=$q3=array();
                $q1Check=0;$q2Check=0;$q3Check=0;$ansEnd=0;
                $quesTotal=$this->FacilityModel->quesTot($facilityData['SurveyID'],$checklist_format);
                
                $columnCheck=array('A','B','C','D','E','F','G','H','I','J','TOTAL');
                $answer=array('UserID'=>$facilityData['UserID'],'SurveyID'=>$facilityData['SurveyID'],'Sequence'=>$facilityData['Sequence'],'device'=>'web','SurveyStatus'=>1,'IsActive'=>1,'ParentUserID'=>'0','CreatedOn'=>date('Y-m-d H:i:s'),'CreatedBy'=>'0','format'=>'A');
                $answerDet=array();
                $checkSubcategoryExist=0;
                $Q1='Nursing staff is skilled for operating radiant warmer';
                $Q2='Nursing staff is skilled for resuscitation';
                $Q3='Nursing staff is skilled identifying and managing complication';
                $Q4='Counsellor is skilled for postnatal counselling';
                $Q5='Nursing Staff is skilled for maintaining clinical records including partograph';
                $validAns=array('0','1','2');
                foreach ($arr_data as $key => $value) {
                  if(count($value)<7){ continue; }
                  if(isset($value[0]) || isset($value[1]) || isset($value[2])){ 
                    if((strtolower(trim($value[0]))=='reference no' || strtolower(trim($value[0]))=='reference no.') && (strtolower(trim($value[1]))=='measurable element' || strtolower(trim($value[1]))=='me statement') && strtolower(trim($value[2]))=='checkpoint'){
                      $questionStart=1;

                    }
                    if ($value[0]!='' && $value[1]!='' && ($value[2]=='' && $value[4]=='' && $value[5]=='' && $value[6]=='' ) && preg_match('/Standard/i', $value[0])){
                      $subCat=preg_replace('/[^A-Za-z0-9\- ,*=.&]/', '', trim($value[0])); 
                      $checkSubcategoryExist=$this->FacilityModel->checkSubCatExist($facilityData['SurveyID'],$subCat,$checklist_format);
                    }

                    if($questionStart==1 && !empty($answer['UserID']) ){
                      if(isset($value[2]) && $value[2]!='' && isset($value[3]) && $value[3]!=='' && strtolower(trim($value[2]))!='checkpoint' && strtolower(trim($value[2]))!='maximum' && !in_array(trim(strtoupper($value[0])),$columnCheck) && $checkSubcategoryExist>0){
                        if($checklist_format=='A'){
                          if(preg_match('/Nursing staff is skilled  for operating radiant warmer/i', $value[2])){ continue; }
                          if(preg_match('/Nursing staff is skilled  for resuscitation/i', $value[2])){ continue; }
                          if(preg_match('/Nursing staff is skilled identifying and managing complication/i', $value[2])){ continue; }
                          if(preg_match('/Counsellor is skilled for postnatal counselling/i', $value[2])){ continue; }
                          if(preg_match('/Nursing Staff is skilled for maintaining clinical records including partograph/i', $value[2])){ continue; }
                        } else {

                        }
                        $checkQuestionExist=$this->FacilityModel->checkQuestionExist($facilityData['SurveyID'],$value[2],$checkSubcategoryExist,$checklist_format);
                        if(in_array(trim($value[3]), $validAns)){
                          if($checkQuestionExist>0){
                            $answerDet[]=array(
                              'AnswerID'=>'0',
                              'QuestionID'=>$checkQuestionExist,
                              'Answer'=>trim($value[3]),
                              'IsActive'=>'1',
                              'CreatedOn'=>date('Y-m-d H:i:s'),
                              'CreatedBy'=>$this->session->userdata('UserID')
                            );
                            $done[]=$value;
                          } else {
                            $err[]=$value;
                          }
                        } else {
                          $errAns[]=$value;
                        }
                      } else {
                        //echo "<pre>"; print_r($value); echo "</pre>";
                      }
                    } else {
                      // for header and assement data
                      if(strtolower(trim($value[5]))=='date of assessment'){
                        $answer['AssessmentDate']=convert_date_db(PHPExcel_Shared_Date::ExcelToPHP(trim($value[5])));
                      }
                      if(strtolower(trim($value[0]))=='names of assessors'){
                        $answer['AssessorsName1']=trim($value[2]);
                      }
                      if(strtolower(trim($value[5]))=='names of assessees'){
                        $answer['AssesseesName1']=trim($value[6]);
                      }
                      if(preg_match('/type of assessment/i', $value[0])){
                        $answer['AssessmentType']=trim($value[2]);
                      }
                      if(strtolower(trim($value[5]))=='action plan submission date'){
                        if($value[6]!=''){
                          $answer['start_date']=date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP(trim($value[6])));
                        }
                        
                      }
                      if(!preg_match('/Major Gaps Observed/i', $value[1]) && !preg_match('/Good Practices/i', $value[1]) && !preg_match('/Opportunities for Improvement/i', $value[1])&& !preg_match('/Signature of Assessors/i', $value[1]) && !preg_match('/Date/i', $value[1])){
                        if($q1Check && !empty($value[1]) && $q2Check==0 && $q3Check==0){
                          $q1[]=trim($value[1]);
                        }
                        if($q2Check && !empty($value[1]) && $q1Check==0 && $q3Check==0){
                          $q2[]=trim($value[1]);
                        }
                        if($q3Check && !empty($value[1])  && $q1Check==0 && $q2Check==0){
                          $q3[]=trim($value[1]);
                        }
                      }
                      if(preg_match('/Major Gaps Observed/i', $value[1])){
                        $q1Check=1;$q2Check=0;$q3Check=0;
                      }
                      if(preg_match('/Good Practices/i', $value[1])){
                        $q1Check=0;$q2Check=1;$q3Check=0;
                      }
                      if(preg_match('/Opportunities for Improvement/i', $value[1])){
                        $q1Check=0;$q2Check=0;$q3Check=1;
                      }
                      if(preg_match('/date/i', $value[1])){ 
                        $date=trim(preg_replace('/[^0-9\/-]/', '', trim($value[1])));
                        $date=date('Y-m-d',strtotime($date));
                        if($date=='1970-01-01'){
                          $date=NULL;
                        }
                        $answer['end_date']=$date;
                      }
                    }                 
                  } else {
                    // unable to read file
                    $dataLog=array(
                      'msg'=>'unable to read file',
                      'status'=>0
                    );
                  }
                }
                if(empty($arr_data)){
                  // Unable to read excel. Please check file and its extension
                  $dataLog=array(
                      'msg'=>'Unable to read excel, Please check file and its extension',
                      'status'=>0
                  );
                } else if(!empty($err)){
                  // Uploaded files all question not matched
                  $dataLog=array(
                      'msg'=>'Uploaded files all question not matched',
                      'status'=>0
                  );
                } else if(empty($answerDet)){
                  // No compliance get of refrences
                  $dataLog=array(
                      'msg'=>'No compliance get of refrences',
                      'status'=>0
                  );
                }else if(!empty($errAns)){
                  // Invalid compliance provided
                  $dataLog=array(
                      'msg'=>'Invalid compliance provided',
                      'status'=>0
                    );
                }else if($facilityData['SurveyID']=='1' && count($answerDet)!=$quesTotal){
                  // All refrences not provided as per format
                  $dataLog=array(
                      'msg'=>'All refrences not provided as per format',
                      'status'=>0
                    );
                }else if($facilityData['SurveyID']=='1' && count($answerDet)!=$quesTotal){
                  // All refrences not provided as per format
                  $dataLog=array(
                      'msg'=>'All refrences not provided as per format',
                      'status'=>0
                    );
                } else {
                  try {
                    if($this->db->insert('answer', $answer)){
                      $answer['AnswerID']=$this->db->insert_id();
                      foreach ($answerDet as $key => $value) {
                        $answerDet[$key]['AnswerID']=$answer['AnswerID'];
                      }
                      if($this->db->insert_batch('answerdetail', $answerDet)){
                        foreach ($q1 as $key => $value1) {
                          $saveData=array(
                            'AnswerID'=>$answer['AnswerID'],
                            'remarksType'=>'1',
                            'remarks'=>$value1,
                            'CreatedOn'=>date('Y-m-d H:i:s'),
                            'CreatedBy'=>$this->session->userdata('UserID')
                          );
                          if($this->db->insert('answerremarks', $saveData)){
                            $LoginHisID=$this->db->insert_id();
                          } else {
                            $this->db->insert('answerremarks', $saveData);
                            $LoginHisID=$this->db->insert_id();
                          }
                        }
                        foreach ($q2 as $key => $value1) {
                          $saveData=array(
                            'AnswerID'=>$answer['AnswerID'],
                            'remarksType'=>'2',
                            'remarks'=>$value1,
                            'CreatedOn'=>date('Y-m-d H:i:s'),
                            'CreatedBy'=>$this->session->userdata('UserID')
                          );
                          if($this->db->insert('answerremarks', $saveData)){
                            $LoginHisID=$this->db->insert_id();
                          } else {
                            $this->db->insert('answerremarks', $saveData);
                            $LoginHisID=$this->db->insert_id();
                          }
                          
                        }
                        foreach ($q3 as $key => $value1) {
                          $saveData=array(
                            'AnswerID'=>$answer['AnswerID'],
                            'remarksType'=>'3',
                            'remarks'=>$value1,
                            'CreatedOn'=>date('Y-m-d H:i:s'),
                            'CreatedBy'=>$this->session->userdata('UserID')
                          );
                          if($this->db->insert('answerremarks', $saveData)){
                            $LoginHisID=$this->db->insert_id();
                          } else {
                            $this->db->insert('answerremarks', $saveData);
                            $LoginHisID=$this->db->insert_id();
                          }                     
                        }
                        //unlink($file);
                        // data saved sucessfully
                        $dataLog=array(
                          'msg'=>'data saved sucessfully',
                          'status'=>1
                        );
                      } else {
                        // error occured while saving data 
                        $this->db->delete('answerdetail', array('AnswerID' => $answer['AnswerID']));
                        $dataLog=array(
                          'msg'=>'error occured while saving data',
                          'status'=>0
                        );
                      }
                    } else {
                      // error saving data
                      $dataLog=array(
                          'msg'=>'error saving data',
                          'status'=>0
                        );   
                    }                   
                  }
                  catch(Exception $e) {
                    // exceptional error
                    $dataLog=array(
                          'msg'=>'exceptional error',
                          'status'=>0
                        );
                  }
                }
                $dataLog['FacilityNumber']=$facilityData['FacilityNumber'];
              } else {
                // file name format incorect
                $dataLog=array(
                    'msg'=>'file name format incorect',
                    'status'=>0
                  );
              }
            } else {
              // error extension not valid
              $dataLog=array(
                    'msg'=>'error extension not valid',
                    'status'=>0
                  );
            }
            //print_r($value);
            $dataLog['file']=$valueFile;
            $dataLog['fileDate']=$fileDate;

            } else {
            // file not exist
            $dataLog=array(
                'msg'=>'file not found',
                'status'=>0
              );
          }
        }        
      $data['logs']=$this->CronModel->assesmentlog($dataLog);
      echo "<pre>"; print_r($dataLog); echo "</pre>";
    }
  
      /*$data=array();
      $data['assessments']=$this->CronModel->assesmentcron();
      $this->load->view('cron/assesmentcron',$data);*/
    }
    function assessment_list(){
      $this->CommonModel->checkPageAccessWeb('cron/assessment_list',$this->session->userdata('RoleName'));
      $data=array();
      $this->load->view('header');
      $this->load->view('cron/assessment_list',$data);
      $this->load->view('footer');
    }
    function assessment_list_data(){
        $response = array();
        $dataHeader = apache_request_headers();
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $draw=$this->input->post('draw');
                    $searchData=$this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }        
        $data=$this->CommonModel->assessment_list_data($searchData);
        $json_data=array(
            "draw"              =>  intval($draw),
            "recordsTotal"      =>  intval($data['totalData']),
            "recordsFiltered"   =>  intval($data['totalFilter']),
            "data"              =>  $data['data']
        );
        echo json_encode($json_data);
        exit;        
    }
    public function gunakassessment(){

      $gunakConfig=$this->config->item('gunak');
      $loginData=array(
          'email'=>$gunakConfig['userID'],
          'password'=>$gunakConfig['password']
        );
        $loginHeader=array(
          "Content-Type: application/x-www-form-urlencoded",
          "cache-control: no-cache"
        );
      $loginData=$this->curlRequest('POST',$gunakConfig['loginUrl'],$loginData,$loginHeader,1);
      $gunak=array(
        'cronDate'=>date('Y-m-d'),
        'loginStatus'=>@$loginData['responseCode'],
        'totalRecord'=>0,
        'totalPages'=>0,
        'fetchedPages'=>0,
        'remarks'=>''
      );
      if(isset($loginData['responseCode']) && $loginData['responseCode']==200){
        $this->db->insert('gunak', $gunak);
        $getDataHeader=array(
          'Accept: application/json'
        );
        $requestData=array(
          'assessmentEndDateTime' => '2016-01-01T20:54:03.292Z',
          'programName' => 'LAQSHYA',
          'assessmentToolName' => 'NQAS',
          'page' => 0,
          'size' => 1
        );
        $mainData=$this->curlRequest('GET',$gunakConfig['assessmentUrl'],$requestData,$getDataHeader,1);
        $totalData=0;
        $totalPages=0;
        $fetchedPages=0;
        if(isset($mainData['responseCode']) && $mainData['responseCode']==200){
          $totalData=$mainData['data']['totalElements'];
          $pages=$totalData/$gunakConfig['pullRequest'];
          $assessmentDataReq=$requestData;
          $assessmentDataReq['size']=$gunakConfig['pullRequest'];
          $totalPages=ceil($pages);
          for ($i=0; $i <ceil($pages) ; $i++) {
            $assessmentDataReq['page']=$i;
            $assessmentData=$this->curlRequest('GET',$gunakConfig['assessmentUrl'],$assessmentDataReq,$getDataHeader,1);
            if(isset($assessmentData['responseCode']) && $assessmentData['responseCode']==200){
              $fetchedPages++;
              if(isset($assessmentData['data']['content']) && count($assessmentData['data']['content'])>0){
                foreach ($assessmentData['data']['content'] as $key => $value) {
                  if($value['systemId']!='4bdff2a0-d198-4c71-a4c6-9edf0667c568'){ continue; }
                  $curlUrl=$gunakConfig['assessmentDetailUrl'].'/'.$value['systemId'];
                  $assessmentDetails=$this->curlRequest('GET',$curlUrl,array(),$getDataHeader,1);
                  if(isset($assessmentDetails['responseCode']) && $assessmentDetails['responseCode']==200){
                    if(!empty($assessmentDetails['data'])){
                      $saveStatus=$this->savegunakAssessment($assessmentDetails['data']);
                      $fetchedData=serialize($assessmentDetails['data']);
                    } else {
                      // empty data get of system id
                      $fetchedData='no data get';
                    }
                  } else {
                    // data not fetched, save systemId with faild response data
                    $fetchedData='';
                  }                  
                  $gunak_assessment=array(
                    'cronDate'=>date('Y-m-d'),
                    'systemId'=>$value['systemId'],
                    'fetchedData'=>$fetchedData,
                    'saveStatus'=>$saveStatus['code'],
                    'remarks'=>$saveStatus['msg'],
                    'lr'=>@$saveStatus['lr'],
                    'lrStatus'=>@$saveStatus['lrStatus'],
                    'ot'=>@$saveStatus['ot'],
                    'otStatus'=>@$saveStatus['otStatus'],
                  );
                  $this->db->insert('gunak_assessment', $gunak_assessment);                  
                }
              }
              $assessmentDataReqStatus=1;
              $fetchedData=serialize($assessmentData['data']['content']);
            } else {
              // insert error of page data not fetched, with configuration
              $assessmentDataReqStatus=0;
              $fetchedData='';
            }
            // save $assessmentDataReq as serialized data with $assessmentDataReqStatus AND http status;
            $gunak_pages=array(
              'cronDate'=>date('Y-m-d'),
              'status'=>$assessmentDataReqStatus,
              'data'=>serialize($assessmentDataReq),
              'pageNo'=>$i,
              'fetchedData'=>$fetchedData
            );
            $this->db->insert('gunak_pages', $gunak_pages);
          }
        } else {
          $msg='assessment - '.@$mainData['message'];
          $gunak['remarks']=$msg;
          //die($msg);          
        }
        $gunak=array(
          'totalRecord'=>$totalData,
          'totalPages'=>$totalPages,
          'fetchedPages'=>$fetchedPages
        );
        $this->db->where('cronDate',date('Y-m-d'));
        $this->db->update('gunak',$gunak);        
      } else {
        $msg='login - '.@$loginData['message'];
        $gunak['remarks']=$msg;
        $this->db->insert('gunak', $gunak);
        die($msg);
      }      
    }
    public function savegunakAssessment($assessmentData){
      $status=array('code'=>0,'msg'=>'assessment start');
      if(!empty($assessmentData)){
        // write code to serach facility and get userID        
        //echo "<pre>";print_r($assessmentData);echo "</pre>";
        $facilityData=array(
          'state'=>$assessmentData['state'],
          'district'=>$assessmentData['district'],
          'facilityType'=>$assessmentData['facilityType'],
          'FacilityNumber'=>$assessmentData['nin'],
          'FacilityName'=>$assessmentData['facility']
        );
        $facilityUserID=$this->CronModel->getFacility($facilityData);
        // ask how to get baseline,otherline and endline
        $surveyType=1;
        $saveSts=0;
        foreach ($assessmentData['checklists'] as $key => $value) {
          $gunak_assessment=array();
          if(strtoupper($value['name'])=='OT'){
            $SurveyID=2;
            $status['ot']=1;
          } else {
            $SurveyID=1;
            $status['lr']=1;
          }
          $assessmentText=strtolower($assessmentData['assessmentType']);
          switch ($assessmentText) {
            case 'internal':
              $assessmentType='internal';
              break;
            case 'peer':
              $assessmentType='peer';
              break;
            case 'external':
              $assessmentType='external';
              break;            
            default:
              $assessmentType='internal';
              break;
          }
          $quesTotal=$this->FacilityModel->quesTot($SurveyID,'A');
          $assessmentStartDate=explode('T', $assessmentData['assessmentStartDate']);
          $assessmentEndDate=explode('T', $assessmentData['assessmentEndDate']);
          $answer=array('UserID'=>$facilityUserID,'SurveyID'=>$SurveyID,'Sequence'=>$surveyType,'start_date'=>$assessmentStartDate[0],'end_date'=>$assessmentEndDate[0],'device'=>'Gunak','SurveyStatus'=>1,'IsActive'=>1,'ParentUserID'=>0,'assessmentDate'=>$assessmentStartDate[0],'AssessorsName1'=>'','AssesseesName1'=>'','AssessorsName2'=>'','AssesseesName2'=>'','AssessmentType'=>$assessmentType,'FacilityAvailable'=>0,'format'=>'A','CreatedOn'=>date('Y-m-d H:i:s'),'CreatedBy'=>0);
          $answerDet=array();
          $totalConcern=count($value['areaOfConcerns']);
          $questionData=array();
          $questionData['SurveyID']=$SurveyID;
          $questionData['survey']=$value['name'];
          $this->db->insert('answer', $answer);
          $answerID=$this->db->insert_id();
          if(isset($value['areaOfConcerns']) && count($value['areaOfConcerns'])>0 && $answerID>0){
            foreach ($value['areaOfConcerns'] as $keyConcern => $valueConcern) {
              $categoryID=$this->CronModel->checkCategoryExist($SurveyID,$valueConcern['reference']);
              $questionData['category']=$valueConcern['reference'];
              $questionData['categoryID']=$categoryID;
              if(isset($valueConcern['standards']) && count($valueConcern['standards'])>0 && $categoryID>0){
                foreach ($valueConcern['standards'] as $keyStd => $valueStd) {
                  $subCategoryID=$this->CronModel->checkSubCategoryExist($SurveyID,$categoryID,$valueStd['reference']);
                  $questionData['subcategory']=$valueStd['reference'];
                  $questionData['subCategoryID']=$subCategoryID;
                  if(isset($valueStd['measurableElements']) && count($valueStd['measurableElements'])>0 && $subCategoryID>0){
                    foreach ($valueStd['measurableElements'] as $keyMeas => $valueMeas) {
                      $measurableID=$this->CronModel->checkMeasurableExist($SurveyID,$categoryID,$subCategoryID,$valueMeas['reference']);
                      $questionData['measurable']=$valueMeas['reference'];
                      $questionData['measurableID']=$measurableID;
                      if(isset($valueMeas['checkpointAssessments']) && count($valueMeas['checkpointAssessments'])>0 && $measurableID>0){
                        foreach ($valueMeas['checkpointAssessments'] as $keyCheckpoint => $valueCheckpoint) {
                          $questionData['checkpoint']=$valueCheckpoint['checkpoint'];
                          $questionID=$this->CronModel->checkQuestion($questionData);
                          if(!empty($questionID)){
                            $answerDet[]=array(
                              'AnswerID'=>$answerID,
                              'QuestionID'=>$questionID,
                              'Answer'=>trim($valueCheckpoint['score']),
                              'IsActive'=>'1',
                              'CreatedOn'=>date('Y-m-d H:i:s'),
                              'CreatedBy'=>0
                            );                    
                          }
                        }                        
                      }

                    }                    
                  }         
                }                
              }
            }
          }

          try {
            /*if(count($answerDet)!=$quesTotal){
              $answer['SurveyStatus']=0;
            } else {
              $answer['SurveyStatus']=1;
            }*/
            $answer['ModifiedOn']=date('Y-m-d H:i:s');
            $this->db->where('AnswerID',$answerID);
            if($this->db->update('answer', $answer)){
              if($this->db->insert_batch('answerdetail', $answerDet)){
                $saveSts++;
                $status['code']=$saveSts;
                $status['msg']='Data saved sucessfully';
                if($answer['SurveyID']==1){
                  $status['lrStatus']=1;
                }
                if($answer['SurveyID']==2){
                  $status['otStatus']=1;
                }
              } else {
                $this->db->delete('answerdetail', array('AnswerID' => $answerID));
                $this->db->delete('answer', array('AnswerID' => $answerID));
                $status['code']=$saveSts;
                $status['msg']='Details not saved';
              }
            } else {
              $this->db->delete('answer', array('AnswerID' => $answerID));
              $status['code']=$saveSts;
              $status['msg']='update faild';
            }                   
          }
          catch(Exception $e) {
            $status['code']=$saveSts;
            $status['msg']=$e->getMessage();
          }
        }
      } else {
          $status['code']='0';
          $status['msg']='Empty assessment data get';
      }
      return $status;
    }

    public function curlRequest($method,$url,$data,$header=array(),$iscookie=1){
      //url-ify the data for the POST
      if(!empty($data)){
        $fields_string='';
        foreach($data as $key=>$value) { $fields_string .= $key.'='.urlencode($value).'&'; }
        $fields_string=rtrim($fields_string, '&');        
      }

      //open connection
      $ch = curl_init();

      //set the url
      if(strtolower($method)=='get'){
        if(!empty($fields_string)){
          $curlUrl=$url.'?'.$fields_string;
        } else {
          $curlUrl=$url;
        }
      } else {
        $curlUrl=$url;
        //set the no of post  
        curl_setopt($ch,CURLOPT_POST, count($data));

        //set the post data
        curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
      }
      // set curl url
      curl_setopt($ch,CURLOPT_URL,$curlUrl);

      // pass header variable in curl method
      curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

      // disable ssl certification check
      //curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
      //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

      // setting cookie options
      if($iscookie){
        curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__).'/../../cookies.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__).'/../../cookies.txt');
        curl_setopt($ch, CURLOPT_COOKIE, 'cookiename=JSESSIONID');        
      }

      //Set CURLOPT_RETURNTRANSFER so that the content is returned as a variable.
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

      //Set CURLOPT_FOLLOWLOCATION to true to follow redirects.
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

      //execute post
      $result = curl_exec($ch);
      $err = curl_error($ch);
      $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

      //close connection
      curl_close($ch);

      $responseCode=(int)$httpcode;
      $response=array('responseCode'=>$responseCode,'message'=>'no response');
      if ($err) {
        $response['message']="cURL Error " . $err;
        //return false;
      } else {
        if($responseCode==200){
          $resultData=json_decode($result,true);
          $response['message']="Sucess";
          $response['data']=$resultData;
        } else {
          switch ($responseCode) {
            case 401:
              $response['message']='Login failed, email and password combination incorrect';
              break;
            case 405:
              $response['message']='Method Not Allowed';
              break;
            case 500:
              $response['message']='Internal error occured';
              break;
            case 400:
              $response['message']='Bad request';
              break;
            default:
              $response['message']="unexpected error occured";
              break;
          }
        }
      }
      return $response;
    }
    
}