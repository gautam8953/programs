<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class ApiMentor extends CI_Controller {
	public function __construct()
	{
		parent :: __construct();
		$this->load->model('PmuModel');
	}
	
	public function index(){
	}
		function validate_assesment(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$userID = $data1['userID'];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
					echo json_encode($response);
					exit;
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
				echo json_encode($response);
				exit;
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest	
					$userID=$this->session->userdata('userID');
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		/*if($userID>0){
			$RoleName=$this->FacilityModel->answerview($ansId,$catgory,$subcatgory,$QuestionID);
			$response=$this->FacilityModel->answerview($ansId,$catgory,$subcatgory,$QuestionID);
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}*/		
		echo json_encode($response);
		exit;

	}
	function mentoradd(){
		$response=array();
		$dataHeader = apache_request_headers();
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data=$this->CommonModel->getApiData();
					$response['data']=$data;
					$response['code']='0';
					$response['msg']=$this->config->item('errCodes')[0];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					if($this->session->userdata('RoleName')=='Facility'){
						$userId=$this->session->userdata('UserID');
					} else {
						if(!empty($this->input->post('search_facility')) && $this->input->post('search_facility')>0){
							$userId=$this->input->post('search_facility');
							$valid=true;
						} else {
							$valid=false;
						}
					}
					if(!empty($this->input->post('survey')) && $this->input->post('survey')>0){
						$survey=$this->input->post('survey');
						$valid=true;
					} else {
						$valid=false;
					}
					if(!empty($this->input->post('checklist_format')) ){
						$checklist_format=$this->input->post('checklist_format');
						$valid=true;
					} else {
						$valid=false;
					}
					if(!empty($this->input->post('surveyType')) && $this->input->post('surveyType')>0){
						$surveyType=$this->input->post('surveyType');
						$valid=true;
					} else {
						$valid=false;
					}
					if(!empty($this->input->post('assessmentDate'))){
						$assessmentDate=convert_date_db($this->input->post('assessmentDate'));
						$valid=true;
					} else {
						$valid=false;
					}
					if(!empty($this->input->post('assessorsName1'))){
						$assessorsName1=$this->input->post('assessorsName1');
						$valid=true;
					} else {
						$valid=false;
					}
					if(!empty($this->input->post('assesseesName1'))){
						$assesseesName1=$this->input->post('assesseesName1');
						$valid=true;
					} else {
						$valid=false;
					}
					if(in_array($surveyType, array(11,12,13,14))){
						$entryCheck=$this->FacilityModel->checkEntry($surveyType,$survey,$userId);	
						//$entryCheck=true;
					} else {
						$entryCheck=true;
					}
					$AssessorsName2=$this->input->post('assessorsName2');
					$AssesseesName2=$this->input->post('assesseesName2');
					$AssessmentType=$this->input->post('assessment');
					$start_date=convert_date_db($this->input->post('submissionDate'));
					$quesTotal=$this->FacilityModel->quesTot($survey,$checklist_format);
					if($valid){
						if($entryCheck){  
							if($_FILES['excelfile']['size']>0 && $_FILES['excelfile']['error']==''){
								if($_FILES['excelfile']['size']<2000000){
								$ext = pathinfo($_FILES['excelfile']['name'], PATHINFO_EXTENSION);
								$ext=strtolower($ext);
								if(in_array($ext,$this->config->item('ExcelTypes')) ) {
								  $ExcelTypes=date('Y-m-d-H-i').preg_replace('/[^A-Za-z0-9\-]/', '', $_FILES['excelfile']['name']).'.'.$ext;
								  if(!is_file(FCPATH.'assets/uploads'.$ExcelTypes)){
								    if(move_uploaded_file($_FILES['excelfile']['tmp_name'],"assets/uploads/".$ExcelTypes)){
										$file = FCPATH.'assets/uploads/'.$ExcelTypes;
										$this->load->library('excel');
										$objPHPExcel = PHPExcel_IOFactory::load($file);
										$objPHPExcel->setActiveSheetIndex(0);
										$arr_data=$objPHPExcel->getActiveSheet()->toArray();
										$questionStart=0;
										$err=array();
										$errAns=array();
										$done=array();
										$q1=$q2=$q3=array();
										$q1Check=0;$q2Check=0;$q3Check=0;$ansEnd=0;
										if($userId!=$this->session->userdata('UserID')){
											$ParentUserID=$this->session->userdata('UserID');
										} else {
											$ParentUserID=0;
										}
										$columnCheck=array('A','B','C','D','E','F','G','H','I','J','TOTAL');
										$answer=array('UserID'=>$userId,'SurveyID'=>$survey,'Sequence'=>$surveyType,'device'=>'web','SurveyStatus'=>1,'ParentUserID'=>$ParentUserID,'CreatedOn'=>date('Y-m-d H:i:s'),'CreatedBy'=>$this->session->userdata('UserID'),'assessmentDate'=>$assessmentDate,'AssessorsName1'=>$assessorsName1,'AssesseesName1'=>$assesseesName1,'AssessorsName2'=>$AssessorsName2,'AssesseesName2'=>$AssesseesName2,'AssessmentType'=>$AssessmentType,'start_date'=>$start_date,'format'=>$checklist_format);
										$answerDet=array();
										$checkSubcategoryExist=0;
										$Q1='Nursing staff is skilled for operating radiant warmer';
										$Q2='Nursing staff is skilled for resuscitation';
										$Q3='Nursing staff is skilled identifying and managing complication';
										$Q4='Counsellor is skilled for postnatal counselling';
										$Q5='Nursing Staff is skilled for maintaining clinical records including partograph';
										$validAns=array('0','1','2');
										//echo "<pre>Main"; print_r($arr_data); echo "</pre>"; die('test');
										foreach ($arr_data as $key => $value) {
											if(count($value)<7){ continue; }
											//echo "<pre>Main"; print_r($value); echo "</pre>";
											if(isset($value[0]) || isset($value[1]) || isset($value[2])){ 
												if((strtolower(trim($value[0]))=='reference no' || strtolower(trim($value[0]))=='reference no.') && (strtolower(trim($value[1]))=='measurable element' || strtolower(trim($value[1]))=='me statement') && strtolower(trim($value[2]))=='checkpoint'){
													$questionStart=1;

												}
												//echo "<pre>Loop 0"; print_r($value); echo "</pre>";
												if ($value[0]!='' && $value[1]!='' && ($value[2]=='' && $value[4]=='' && $value[5]=='' && $value[6]=='' ) && preg_match('/Standard/i', $value[0])){
													$subCat=preg_replace('/[^A-Za-z0-9\- ,*=.&]/', '', trim($value[0])); 
													$checkSubcategoryExist=$this->FacilityModel->checkSubCatExist($survey,$subCat,$checklist_format);
												}

												if($questionStart==1 && !empty($answer['UserID']) ){
													if(isset($value[2]) && $value[2]!='' && isset($value[3]) && $value[3]!=='' && strtolower(trim($value[2]))!='checkpoint' && strtolower(trim($value[2]))!='maximum' && !in_array(trim(strtoupper($value[0])),$columnCheck) && $checkSubcategoryExist>0){
														if($checklist_format=='A'){
															if(preg_match('/Nursing staff is skilled  for operating radiant warmer/i', $value[2])){ continue; }
															if(preg_match('/Nursing staff is skilled  for resuscitation/i', $value[2])){ continue; }
															if(preg_match('/Nursing staff is skilled identifying and managing complication/i', $value[2])){ continue; }
															if(preg_match('/Counsellor is skilled for postnatal counselling/i', $value[2])){ continue; }
															if(preg_match('/Nursing Staff is skilled for maintaining clinical records including partograph/i', $value[2])){ continue; }
														} else {

														}
														$checkQuestionExist=$this->FacilityModel->checkQuestionExist($survey,$value[2],$checkSubcategoryExist,$checklist_format);
														//echo "<pre>IN".$checkSubcategoryExist.' '.$checkQuestionExist; print_r($value); echo "</pre>";
														if(in_array(trim($value[3]), $validAns)){
															if($checkQuestionExist>0){
																$answerDet[]=array(
																	'AnswerID'=>'0',
																	'QuestionID'=>$checkQuestionExist,
																	'Answer'=>trim($value[3]),
																	'IsActive'=>'1',
																	'CreatedOn'=>date('Y-m-d H:i:s'),
																	'CreatedBy'=>$this->session->userdata('UserID')
																);
																$done[]=$value;
															} else {
																$err[]=$value;
															}
														} else {
															$errAns[]=$value;
														}
													} else {
														//echo "<pre>"; print_r($value); echo "</pre>";
													}
												} else {
													// for header and assement data
													/*if(strtolower(trim($value[5]))=='date of assessment'){
														$answer['AssessmentDate']=date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP(trim($value[5])));
													}*/
													/*if(strtolower(trim($value[0]))=='names of assessors'){
														$answer['AssessorsName1']=trim($value[2]);
													}
													if(strtolower(trim($value[5]))=='names of assessees'){
														$answer['AssesseesName1']=trim($value[6]);
													}
													if(preg_match('/type of assessment/i', $value[0])){
														$answer['AssessmentType']=trim($value[2]);
													}
													if(strtolower(trim($value[5]))=='action plan submission date'){
														if($value[6]!=''){
															$answer['start_date']=date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP(trim($value[6])));
														}
														
													}*/
													if(!preg_match('/Major Gaps Observed/i', $value[1]) && !preg_match('/Good Practices/i', $value[1]) && !preg_match('/Opportunities for Improvement/i', $value[1])&& !preg_match('/Signature of Assessors/i', $value[1]) && !preg_match('/Date/i', $value[1])){
														if($q1Check && !empty($value[1]) && $q2Check==0 && $q3Check==0){
															$q1[]=trim($value[1]);
														}
														if($q2Check && !empty($value[1]) && $q1Check==0 && $q3Check==0){
															$q2[]=trim($value[1]);
														}
														if($q3Check && !empty($value[1])  && $q1Check==0 && $q2Check==0){
															$q3[]=trim($value[1]);
														}
													}
													if(preg_match('/Major Gaps Observed/i', $value[1])){
														$q1Check=1;$q2Check=0;$q3Check=0;
													}
													if(preg_match('/Good Practices/i', $value[1])){
														$q1Check=0;$q2Check=1;$q3Check=0;
													}
													if(preg_match('/Opportunities for Improvement/i', $value[1])){
														$q1Check=0;$q2Check=0;$q3Check=1;
													}
													if(preg_match('/date/i', $value[1])){ 
														$date=trim(preg_replace('/[^0-9\/-]/', '', trim($value[1])));
														$date=date('Y-m-d',strtotime($date));
														if($date=='1970-01-01'){
															$date=NULL;
														}
														$answer['end_date']=$date;
													}

												}									
											} else {
												$response['code']='12';
												$response['msg']='unable to read file';
											}
										}
										/*echo $quesTotal."<pre>"; 
										echo count($done).'_'; 
										echo count($errAns).'_'; 
										echo count($err).'_'; 
										echo count($answerDet);
										echo "</pre>";
										die('test');*/
										if(empty($arr_data)){
											$response['code']='12';
											$response['msg']='Unable to read excel. Please check file and its extension';
										} else if(!empty($err)){
											$response['code']='12';
											$response['msg']='Uploaded files all question not matched';
											$response['err']=$err;
										} else if(empty($answerDet)){
											$response['code']='13';
											$response['msg']='No compliance get of refrences';
										}else if(!empty($errAns)){
											$response['code']='15';
											$response['msg']='Invalid compliance provided';
											$response['err']=$errAns;
										}else if($survey=='1' && count($answerDet)!=$quesTotal){
											$response['code']='15';
											$response['msg']='All refrences not provided as per format';
										}else if($survey=='1' && count($answerDet)!=$quesTotal){
											$response['code']='15';
											$response['msg']='All refrences not provided as per format';
										} else {
											try {
												if($this->db->insert('answer', $answer)){
													$answer['AnswerID']=$this->db->insert_id();
													foreach ($answerDet as $key => $value) {
														$answerDet[$key]['AnswerID']=$answer['AnswerID'];
													}
													if($this->db->insert_batch('answerdetail', $answerDet)){
														foreach ($q1 as $key => $value1) {
															$saveData=array(
																'AnswerID'=>$answer['AnswerID'],
																'remarksType'=>'1',
																'remarks'=>$value1,
																'CreatedOn'=>date('Y-m-d H:i:s'),
																'CreatedBy'=>$this->session->userdata('UserID')
															);
															if($this->db->insert('answerremarks', $saveData)){
																$LoginHisID=$this->db->insert_id();
															} else {
																$this->db->insert('answerremarks', $saveData);
																$LoginHisID=$this->db->insert_id();
															}
														}
														foreach ($q2 as $key => $value1) {
															$saveData=array(
																'AnswerID'=>$answer['AnswerID'],
																'remarksType'=>'2',
																'remarks'=>$value1,
																'CreatedOn'=>date('Y-m-d H:i:s'),
																'CreatedBy'=>$this->session->userdata('UserID')
															);
															if($this->db->insert('answerremarks', $saveData)){
																$LoginHisID=$this->db->insert_id();
															} else {
																$this->db->insert('answerremarks', $saveData);
																$LoginHisID=$this->db->insert_id();
															}
															
														}
														foreach ($q3 as $key => $value1) {
															$saveData=array(
																'AnswerID'=>$answer['AnswerID'],
																'remarksType'=>'3',
																'remarks'=>$value1,
																'CreatedOn'=>date('Y-m-d H:i:s'),
																'CreatedBy'=>$this->session->userdata('UserID')
															);
															if($this->db->insert('answerremarks', $saveData)){
																$LoginHisID=$this->db->insert_id();
															} else {
																$this->db->insert('answerremarks', $saveData);
																$LoginHisID=$this->db->insert_id();
															}											
														}												
														$response['code']='0';
														$response['msg']='Data saved sucessfully';
														$response['err']=$err;
														$response['done']=$answerDet;
													} else {
														$this->db->delete('answerdetail', array('AnswerID' => $answer['AnswerID']));
														$response['code']='11';
														$response['msg']=$this->config->item('errCodes')[11];
													}
												} else {
													$response['code']='11';
													$response['msg']=$this->config->item('errCodes')[11];						
												}										
											}
											catch(Exception $e) {
												$response['code']='12';
												$response['msg']=$e->getMessage();
												$response['err']=$err;
											}
										}
							        	unlink($file);
										                	      
								    } else {
										$response['code']='13';
										$response['msg']='Error uploading file. Please uplaod again';	      
								    }
								  } else {
									$response['code']='13';
									$response['msg']='Please change file name before upload';
								  }
								} else {
									$response['code']='13';
									$response['msg']='Please upload only excel or csv files';
								}
							
								} else {
									$response['code']='13';
									$response['msg']='Invalid file uploaded';				
								}								
							} else{
								$response['code']='13';
								$response['msg']='File not uploaded, Please upload again';
							}
						} else {
							$response['code']='9';
							$response['msg']='Assesment data already filled.';
						}
					} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];
					}
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		echo json_encode($response);
		exit;
	}
	



		
}