<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //check_user();
        $this->load->model('UserModel');
    }

    public function index() {
        exit;
    }

    public function apilogintoken()
    {
        if($_POST['apikey']=='HWC_CENTRAL_DASHBORD_LOGIN2018')
        {
            $token=uniqid();
            $data = array(
                'user_id'=>'2692',             // user that you want to assign for api
                'token'=>$token,
                'request_source'=>$_POST['source'],
            );
            $this->db->insert('api_login_user',$data);
            if(!empty($this->db->insert_id())){
                $return["return_url"] = base_url('login/validateUser/' . $token);
                $return["status"]='1';
                $return["message"]='Key Matched';
                $return["json"] = json_encode($return);
                echo json_encode($return);
            } else {
                $return["return_url"]='';
                $return["status"]='0';
                $return["message"]='Key Not Matched';
                $return["json"] = json_encode($return);
                echo json_encode($return);
            }
        }
        else{
            $return["return_url"]='';
            $return["status"]='0';
            $return["message"]='Key Not Matched';
            $return["json"] = json_encode($return);
            echo json_encode($return);
        }
        die;
    }

    public function validateUser($apilogintoken='') {
        $this->session->sess_regenerate(false);
        $username='ministry';
        $password='1';
        $ip='127.0.0.1';
        $response = array();             
        $this->db->select('api_login_user.*');
        $this->db->from('api_login_user');
        $this->db->where('api_login_user.token', $apilogintoken);
        $this->db->where('api_login_user.status', 0);
        $u_info = $this->db->get()->row_array();
        if(count($u_info)>0){
            $start = date_create($u_info['request_time']); 
            $end = date_create(date("Y-m-d h:i:s"));
            $diff=date_diff($end,$start);
            if($diff->days<2){  // allow only for 1 day
                $this->db->set('status', 1); //value that used to update column  
                $this->db->where('token', $apilogintoken); //which row want to upgrade  
                $this->db->update('api_login_user');
                $response = $this->UserModel->loginCheck($username, md5($password), $ip);
            } else {
            }                      
        } else {
        }
        if(isset($response['data']['UserID']) && !empty($response['data']['UserID'])){
            $this->session->set_userdata('LoginType', 'External');
            redirect('/', 'refresh');
        } else {
            $this->session->sess_destroy();
            session_destroy();
            $this->session->sess_regenerate(true);
            redirect('/');            
        }
        die('test');
    }




}
