<?php  
defined('BASEPATH') OR exit('No direct script access allowed');



class Mentor extends CI_Controller {
	public function __construct()
	{
		parent :: __construct();
		$userID=$this->session->userdata('UserID');
		if(empty($userID)){ redirect('user/login'); }
		$this->load->model('PmuModel');
	}
		
	public function index(){
		$this->CommonModel->checkPageAccessWeb('facility/index',$this->session->userdata('RoleName'));
		$data=array();
		$data['search_options']=$this->PmuModel->searchOptions();		
		$this->load->view('header');
		$this->load->view('facility/index',$data);
		$this->load->view('footer');
	}

	
	

	function add(){
		$this->CommonModel->checkPageAccessWeb('pmu/add',$this->session->userdata('RoleName'));
		$data=array();
		$data['search_options']=$this->PmuModel->getSearchOptions();
		$this->load->view('header');
		$this->load->view('mentor/add',$data);
		$this->load->view('footer');
	}




	



}


