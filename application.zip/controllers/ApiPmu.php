<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class ApiPmu extends CI_Controller {
	public function __construct()
	{
		parent :: __construct();
		$this->load->model('PmuModel');
	}
	
	public function index(){
	}
		function validate_assesment(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$userID = $data1['userID'];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
					echo json_encode($response);
					exit;
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
				echo json_encode($response);
				exit;
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest	
					$userID=$this->session->userdata('userID');
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		/*if($userID>0){
			$RoleName=$this->FacilityModel->answerview($ansId,$catgory,$subcatgory,$QuestionID);
			$response=$this->FacilityModel->answerview($ansId,$catgory,$subcatgory,$QuestionID);
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}*/		
		echo json_encode($response);
		exit;

	}
	function pmuadd(){
		$response=array();
		$dataHeader = apache_request_headers();
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data=$this->CommonModel->getApiData();

					$response['data']=$data;
					$response['code']='0';
					$response['msg']=$this->config->item('errCodes')[0];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					if($this->session->userdata('RoleName')=='Pmu'){
						$parentid=0;
						$userId=$this->session->userdata('UserID');
					} else {
						$userId=$this->input->post('pmuName');
						$parentid=$this->session->userdata('UserID');
						if(!empty($_FILES['Keyfindings']['name'])){
						$Keyfindings=$_FILES['Keyfindings']['name'];
						$valid=true;
					   } else {
						$valid=false;
					  }
					  
					   if(!empty($_FILES['recommendations']['name'])){
						$recommendations=$_FILES['recommendations']['name'];
						$valid=true;
					   } else {
						$valid=false;
					   }
					}

					
			
					if($userId){
						  
					   
					  if(!empty($_FILES['Keyfindings']['name'])){
						 $keyfindings = $this->dokeyuploads();
						 $keyfile= $keyfindings;


					   }else{
					   	$keyfindings='ok';
					   	 $keyfile= $this->input->post('keyFind');
					   } 
					   if(!empty($_FILES['recommendations']['name'])){
						$recommendations = $this->doRecommedations();
						$recFile=$recommendations;
					   }else{
					   	$recommendations='ok';
					   	$recFile=$this->input->post('recfile');
					   } 
						  
						
						if($keyfindings!='not valid'){
							
							
							 if($recommendations!='not valid'){
								
								
								$pmuname=$this->input->post('pmuName');
								$search_facility=$this->input->post('search_facility');
								$Date_of_visit=$this->input->post('Date_of_visit');
								
								
								$addData=array(
									 'UserID'=>$userId,
									 
									 'FacilityUserID'=>$search_facility,
									 'Date_of_visit'=>date("Y-m-d", strtotime($this->input->post('Date_of_visit'))),
									 'Keyfindings'=>$keyfile,
									 'recommendations'=>$recFile,
									 'IsActive'=>1,
									 'ParentUserID'=>$parentid,
									 'CreatedOn'=>date('Y-m-d H:i:s'),
									 'CreatedBy'=>$userId,
								);
								

								if(!empty($pmuname)){
									$pmuId = encryptor($this->input->post('pmuID'),'decrypt');
									if($pmuId!=''){
										     $cond= array('id' =>$pmuId);
										     $this->db->update('pmu', $addData,$cond);
										     $response['code']='1';
										     $response['msg']="Data Update Succsessful";

										}else{
											 $this->db->insert('pmu', $addData);
										     $response['code']='0';
										     $response['msg']=$this->config->item('errCodes')[0];

										}

								     
									}
							     
							   
								
						        }else{
							         $response['code']='13';
						             $response['msg']='Please upload only pdf,doc,image or csv files';
						        }
							
						   
					}else{
							$response['code']='13';
						    $response['msg']='Please upload only pdf,doc,image or csv files';
						}
			
						
					} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];
					}
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		echo json_encode($response);
		exit;
	}
	
		function dokeyuploads()
        {
		 
		  $image=basename($_FILES['Keyfindings']['name']);
		  $image=str_replace(' ','|',$image);
		  $type = explode(".",$image);
		  $type = $type[count($type)-1];
		  $ExcelTypes=date('Y-m-d-H-i').preg_replace('/[^A-Za-z0-9\-]/', '', $_FILES['Keyfindings']['name']).'.'.$type;
		  if (in_array($type,array('jpg','jpeg','png','gif','xlsx','csv' ,'xls','doc','docx','pdf')))
		  {
		  	$tmppaths="assets/uploads/pmu/".$ExcelTypes;
			
			if(is_uploaded_file($_FILES["Keyfindings"]["tmp_name"]))
			{
			  move_uploaded_file($_FILES['Keyfindings']['tmp_name'],$tmppaths);
			  return $ExcelTypes; // returns the url of uploaded image.
			}
		  }
		  else
		  {
			return 'not valid';  
		  }
		}
		
	    function doRecommedations()
        {
		 
		  $image=basename($_FILES['recommendations']['name']);
		  $image=str_replace(' ','|',$image);
		  $type = explode(".",$image);
		  $type = $type[count($type)-1];
		  $ExcelTypes=date('Y-m-d-H-i').preg_replace('/[^A-Za-z0-9\-]/', '', $_FILES['recommendations']['name']).'.'.$type;
		  if (in_array($type,array('jpg','jpeg','png','gif','xlsx','csv' ,'xls','doc','docx','pdf')))
		  {
			  
		  	$tmppaths="assets/uploads/pmu/".$ExcelTypes;
			
			if(is_uploaded_file($_FILES["recommendations"]["tmp_name"]))
			{
			  move_uploaded_file($_FILES['recommendations']['tmp_name'],$tmppaths);
			  return $ExcelTypes; // returns the url of uploaded image.
			}
		  }
		  else
		  {
			return 'not valid';  
		  }
		}
	  public function getSearchData() {
        if ($this->CommonModel->checkAPIWebUser()) {
        $searchData = $this->input->post();

            if($this->session->userdata('RoleName')=='State'){
                $searchData['cond']=array('mappedField'=>'f.StateID','mappedData'=>$this->session->userdata('MappedState'));
            }
            if($this->session->userdata('RoleName')=='District'){
                $searchData['cond']=array('mappedField'=>'f.DistrictID','mappedData'=>$this->session->userdata('MappedDistrict'));
            }
            if($this->session->userdata('RoleName')=='Facility'){
                $searchData['cond']=array('mappedField'=>'um.UserID','mappedData'=>$this->session->userdata('UserID'));
            }
				$userID = $this->session->userdata('UserID');
				$search_months = $this->input->post('search_months');
				$search_years = $this->input->post('search_years');
				$search_state = $this->input->post('search_state');
				$search_district = $this->input->post('search_district');
				$search_facility = $this->input->post('search_facility');
				$data = $this->PmuModel->getSearchData($userID, $searchData, $search_state,$search_district,$search_facility);
        $json_data = array(
            "draw" => intval($data['draw']),
            "recordsTotal" => intval($data['totalData']),
            "recordsFiltered" => intval($data['totalFilter']),
            "data" => $data['data']
        );
        echo json_encode($json_data);
        }
    }



	function pmuDataEdit(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$pmuId = $data1['pmuId'];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					$pmuId = encryptor($this->input->post('pmuId'),'decrypt');
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		if($pmuId>0){
			$response=$this->PmuModel->pmuDataEdit($pmuId);
			$response['urlval']=base_url()."assets/uploads/pmu/";
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}		
		echo json_encode($response);
		exit;
	}


		
}