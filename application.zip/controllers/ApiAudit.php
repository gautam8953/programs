<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class ApiAudit extends CI_Controller {
	public function __construct()
	{
		parent :: __construct();
		$this->load->model('FacilityModel');
        $this->load->model('AuditModel');
		$this->load->model('EmailModel');
	}
	
	public function index(){

	}

	public function getSearchDataCsection(){
		if ($this->CommonModel->checkAPIWebUser()) {
		$searchData=$this->input->post();
		$searchData['RoleName']=$this->session->userdata('RoleName');
        if($this->session->userdata('RoleName')=='State'){
            $searchData['cond']=array('mappedField'=>'f.StateID','mappedData'=>$this->session->userdata('MappedState'));
        }
        if($this->session->userdata('RoleName')=='District'){
            $searchData['cond']=array('mappedField'=>'f.DistrictID','mappedData'=>$this->session->userdata('MappedDistrict'));
        }
        if($this->session->userdata('RoleName')=='Facility'){
            $searchData['cond']=array('mappedField'=>'um.UserID','mappedData'=>$this->session->userdata('UserID'));
        }        
		$data=$this->AuditModel->getSearchDataCsection($searchData);
		$json_data=array(
		    "draw"              =>  intval($searchData['draw']),
		    "recordsTotal"      =>  intval($data['totalData']),
		    "recordsFiltered"   =>  intval($data['totalFilter']),
		    "data"              =>  $data['data']
		);
		echo json_encode($json_data);
	} else {
		$json_data=array(
		    "draw"              =>  0,
		    "recordsTotal"      =>  0,
		    "recordsFiltered"   =>  0,
		    "data"              =>  array()
		);
		echo json_encode($json_data);		
	}
	}

    function save_csection(){
        if ($this->CommonModel->checkAPIWebUser()) {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey']=$this->session->userdata('APIKey'); 
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey']=$this->session->userdata('APIKey'); 
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $facilityUser=empty($this->input->post('facilityUser'))?'':encryptor($this->input->post('facilityUser'),'decrypt');

                    if(!empty($this->input->post('csectionID'))){
                        $data['id']=encryptor($this->input->post('csectionID'),'decrypt');
                        if(empty($data['id'])){
                            $response['code'] = '9';
                            $response['msg'] = $this->config->item('errCodes')[9];
                            echo json_encode($response);
                            exit;
                        }
                    }


                    if(!empty($facilityUser) ){
                        $data['userID']=$facilityUser;
                        $data['user']=$this->session->userdata('UserID');
                        if($facilityUser!=$this->session->userdata('UserID')){
                            $data['ParentUserID']=$this->session->userdata('UserID');
                        }
                        if($this->input->post('saveType')=='all'){
                            $data['main']['status']=1;
                        } else {
                            $data['main']['status']=0;
                        }
                        
                        $data['main']['IsActive']=1;

$data['main']['userID']=$facilityUser; 
$data['main']['station']=$this->input->post('station'); 
$data['main']['facility_type']=$this->input->post('facility_type'); 
$data['main']['designation']=$this->input->post('designation'); 
$data['main']['dos']=convert_date_db($this->input->post('dos')); 

$data['main']['mother_age']=$this->input->post('mother_age'); 
$data['main']['hospital_num']=$this->input->post('hospital_num'); 
$data['main']['gpla']=$this->input->post('gpla'); 
$data['main']['doa']=convert_date_db($this->input->post('doa')); 
$data['main']['docs']=convert_date_db($this->input->post('docs')); 
$data['main']['docs_audit']=convert_date_db($this->input->post('docs_audit')); 
$data['main']['height_weight']=$this->input->post('height_weight'); 
$data['main']['book_status']=$this->input->post('book_status'); 
$data['main']['gestation']=$this->input->post('gestation'); 
$data['main']['based']=$this->input->post('based'); 
$data['main']['prev_stillbirths']=$this->input->post('prev_stillbirths'); 
$data['main']['baby_in_utero']=$this->input->post('baby_in_utero'); 
$data['main']['transferred_facility']=$this->input->post('transferred_facility'); 
$data['main']['ga']=$this->input->post('ga'); 
$data['main']['conticosteroids']=$this->input->post('conticosteroids');
$data['main']['senior_obstetrician']=$this->input->post('senior_obstetrician'); 
$data['main']['indication']=$this->input->post('indication'); 
$data['main']['onset_spontaneous']=$this->input->post('onset_spontaneous'); 
$data['main']['pre_labour_prostaglandin']=$this->input->post('pre_labour_prostaglandin'); 
$data['main']['oxytocin_used']=$this->input->post('oxytocin_used'); 
$data['main']['partograph_used']=$this->input->post('partograph_used'); 
$data['main']['ROM']=$this->input->post('ROM'); 
$data['main']['first_labour_duration']=$this->input->post('first_labour_duration'); 
$data['main']['second_labour_duration']=$this->input->post('second_labour_duration'); 
$data['main']['cervical_dilatation']=$this->input->post('cervical_dilatation'); 
$data['main']['multiple_pregnancy']=$this->input->post('multiple_pregnancy'); 
$data['main']['prophylactic_antibiotics']=$this->input->post('prophylactic_antibiotics'); 
$data['main']['blood_loss']=$this->input->post('blood_loss'); 


$data['main']['pregnancies_number_less']=$this->input->post('pregnancies_number_less'); 
$data['main']['pregnancies_number_greater']=$this->input->post('pregnancies_number_greater'); 
$data['main']['termination_mode']=$this->input->post('termination_mode'); 
$data['main']['previous_caesarean_section']=$this->input->post('previous_caesarean_section'); 
$data['main']['caesarean_sections_count']=$this->input->post('caesarean_sections_count'); 
$data['main']['trial_delivery']=$this->input->post('trial_delivery'); 
$data['main']['special_care']=$this->input->post('special_care'); 
$data['main']['special_care_received']=$this->input->post('special_care_received'); 
$data['main']['fetal_heart_monitoring']=$this->input->post('fetal_heart_monitoring'); 
$data['main']['meconium_stained_liquor']=$this->input->post('meconium_stained_liquor'); 
$data['main']['other_method']=$this->input->post('other_method'); 
$data['main']['delivery_outcome']=$this->input->post('delivery_outcome'); 
$data['main']['baby_sex']=$this->input->post('baby_sex'); 
$data['main']['birth_weight']=$this->input->post('birth_weight'); 
$data['main']['apgar_score']=$this->input->post('apgar_score'); 
$data['main']['transfered_to']=$this->input->post('transfered_to'); 
$data['main']['maternal_outcome']=$this->input->post('maternal_outcome'); 
$data['main']['maternal_death']=$this->input->post('maternal_death'); 
$data['main']['newborn_outcome']=$this->input->post('newborn_outcome'); 
$data['main']['neonatal_death']=$this->input->post('neonatal_death'); 
$data['main']['person_opinion']=$this->input->post('person_opinion'); 

                        $response=$this->AuditModel->save_csection($data);
                        echo json_encode($response);
                        exit;
                    } else {
                        $response['code'] = '9';
                        $response['msg'] = $this->config->item('errCodes')[9];
                        echo json_encode($response);
                        exit;
                    }

                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
    }

    }


}