<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Audit extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $userID = $this->session->userdata('UserID');
        if (empty($userID)) {
            redirect('user/login');
        }
        $this->load->model('FacilityModel');
        $this->load->model('AuditModel');
    }

  public function index(){
    $this->CommonModel->checkPageAccessWeb('audit/index',$this->session->userdata('RoleName'));
    $data=array();
    $data['search_options']=$this->FacilityModel->getSearchOptions_new();
    $this->load->view('header');
    $this->load->view('audit/index',$data);
    $this->load->view('footer');

  }
  public function csection($id=''){    
    $data=array();
    $data['search_options']=$this->FacilityModel->getSearchOptions_new();
    $data['options']=$this->config->item('csection');
    $data['id']=$id;

    if(!empty($id)){
      $ids=encryptor($id,'decrypt');
      if(empty($ids)){
        redirect('/');
      } else {
        $data['csection']=$this->AuditModel->getCsectionData($ids);        
      }
      // edit link
      if(!$this->CommonModel->checkPageActionWeb('audit/index','access_edit',$this->session->userdata('RoleName'))){
          redirect('/');
      }
    } else {
      // add link
      if(!$this->CommonModel->checkPageActionWeb('audit/csection','access_add',$this->session->userdata('RoleName'))){
        redirect('/');
      }
    }
    $this->load->view('header');
    $this->load->view('audit/csection',$data);
    $this->load->view('footer');
  }
	public function csectionview($id=''){
  	$data=array();
    $data['search_options']=$this->FacilityModel->getSearchOptions_new();
    $data['options']=$this->config->item('csection');

    if(!empty($id)){
      $ids=encryptor($id,'decrypt');
      if(empty($ids)){
        redirect('/');
      } else {
        $data['csection']=$this->AuditModel->getCsectionData($ids);        
      }
      if(!$this->CommonModel->checkPageActionWeb('audit/index','access_view',$this->session->userdata('RoleName'))){
        redirect('/');
      }
    } else {
      redirect('/');
    }
  	$this->load->view('header');
  	$this->load->view('audit/csectionview',$data);
    $this->load->view('footer');
	}
	public function referral(){
    $this->CommonModel->checkPageAccessWeb('audit/referral',$this->session->userdata('RoleName'));
  	$data=array();
  	$this->load->view('header');
  	$this->load->view('inprogress',$data);
		$this->load->view('footer');
	}
	public function nearmiss(){
    $this->CommonModel->checkPageAccessWeb('audit/nearmiss',$this->session->userdata('RoleName'));
  	$data=array();
  	$this->load->view('header');
  	$this->load->view('audit/nearmiss',$data);
		$this->load->view('footer');
	}

}