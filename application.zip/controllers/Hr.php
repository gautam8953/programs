<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hr extends CI_Controller {

	  public function __construct() {
	    parent::__construct();
        $this->load->model('HrModel');
        $this->load->model('FacilityModel');
        $this->load->helper('captcha');        
    }

	
 public function index() {
        $data = array();
        $this->CommonModel->checkPageAccessWeb('hr/index',$this->session->userdata('RoleName'));
        /*if(!$this->CommonModel->checkPageActionWeb('smg/index','access_view',$this->session->userdata('RoleName'))){
            redirect('/');
        }*/
        $userID = $this->session->userdata('UserID');
        $data['search_options'] = $this->FacilityModel->getSearchOptions();
        $this->load->view('header');
        $this->load->view('hr/index', $data);
        $this->load->view('footer');
    }

	public function add(){
	     $userID = $this->session->userdata('UserID');
	        if (empty($userID)) {
	            redirect('user/login');
	          }
          $data=array();
          //$id = $this->HrModel->checkData($userID);
     
        if($this->session->userdata('RoleName')=='Facility'){
          $data['mainProfile']='Facility';
          $data['facility']=$this->HrModel->getFacilityDetails($userID);

          $data['facility_types']=$this->CommonModel->getfacilityType();
        }
        $data['main']=$this->HrModel->getHrDetails($userID,'main');
         //echo $this->db->last_query();
		    $this->load->view('header');
        $this->load->view('hr/add',$data);
        $this->load->view('footer');
	}


   public function view() {
	    $uriParam=$this->uri->segment('3');
		 if(!empty($uriParam)){
			$id =encryptor($uriParam,'decrypt');
			$userID = $this->HrModel->getUserId($id);
			$userID= $userID['UserID'];
		 }else{
		 	 $userID = $this->session->userdata('UserID');
		 }

        if (empty($userID)) {
            redirect('user/login');
        }
         $data=array();
       
        if($this->session->userdata('RoleName')=='Facility'){
          $data['mainProfile']='Facility';
         
          $data['facility_types']=$this->CommonModel->getfacilityType();
        }
         $data['facility']=$this->HrModel->getFacilityDetails($userID);
        $data['main']=$this->HrModel->getHrDetails($userID,'main');
         $this->load->view('header');
        $this->load->view('hr/view',$data);
        $this->load->view('footer');
	}


}
