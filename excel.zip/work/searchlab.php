<?php

class Searchlab extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('search_model');
        $this->load->model('searchlab_model');
        $this->load->model('laboratory_model');
        $this->load->model('certificate_model');
        $this->load->library('dropdown');
        $this->load->helper('url');        
    }

    public function index() {
        $this->load->model('zone_model');
        $data=array();
        $data['country'] = $this->searchlab_model->get_country();
        $seachData=array();            
        $data['state'] = $this->searchlab_model->get_state();
        $data['city'] = $this->searchlab_model->get_city();
        $data['zone'] = $this->searchlab_model->get_zone();
        $data['natureoflab'] = $this->searchlab_model->get_natureoflab();
        $data['facilitydropdown'] = $this->searchlab_model->get_labcat(0);
        $data['operationat'] = $this->searchlab_model->get_operationat(0);

        //echo "<pre>"; print_r($data['zone']); echo "</pre>";
        $this->load->view('searchlab/index', $data);

    }
    public function searchlabcat() {
        $response=array('code'=>0);
        if(!empty($this->input->post('search_data'))){
            $datasearch=$this->searchlab_model->get_labcat($this->input->post('search_data'));
        } else {
            $datasearch=array();
        }
        $htmData='';

        switch ($this->input->post('type_data')) {
            case 'field':
                $target='discipline';
                break;
            case 'discipline':
                $target='group';
                break;
            case 'group':
                $target='subgroup';
                break;
            
            default:
                $target='';
                $response['code']=1;
                break;
        }

        if(!empty($datasearch)){
            foreach ($datasearch as $key => $value) {
                $htmData.='<input onchange="get_labcat(this)" type="checkbox" name="'.$target.'[]" id="'.$target.'_'.$value['id'].'" value="'.$value['id'].'">'.$value['category_name']."<br>";
            }
            $response['len']=count($datasearch);
        } else {
            $response['len']=0;
        }
        $response['target']=$target;
        $response['data']=$htmData;      

        echo json_encode($response);
        exit;
    }
    function searchdata(){
        $search=$this->input->post();
        $search['pagelength']=10;
        $response=$this->searchlab_model->get_search($search);
        echo json_encode($response);
        exit;
    }


}
