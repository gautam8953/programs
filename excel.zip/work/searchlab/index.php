<?php include 'include/header_main.php'; ?>	
<script src="js/jquery.js"></script>

<style type="text/css">
    .tableListingMe {
        float: left;
        margin-right: 5px;
        margin-top: 5px;
    }
    .paginationClass{
        margin-right: 5px;
    }
</style>
<!--top-->
<!--content-->
<div class="tpcontainercontent">
    <!--advert1-->
    <!--left-->
    <!--right-->			
    <!--maincontent-->
    <div class="tpcontainermain bb">
        <div class="tpinner">
            <!--<div class="clrfix"></div>-->				
            <div class="tpcontainermainc" style="width: 940px"><table class="contentpaneopen detail">
                    <tr>
                        <td class="contentheading" width="100%">Laboratory Search</td>
                    </tr>
                </table>

                <table class="contentpaneopen" style="width:945px;" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                        <td valign="top" class="main_article">
                            <table width="100%"  border="0" cellspacing="1" cellpadding="0">
                                <tr>
                                    <td>
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0" class="Border">
                                                <tr>
                                                    <td colspan="4" class="LaboratoryGridHead LabPaddingLeft">Laboratory Search</td>
                                                </tr>
                                                <tr><td colspan="4" height="10px">&nbsp;</td></tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">Laboratory ID</td>
                                                    <td class="LabTdRight" valign="top"><input name="lab_registration_code" type="text" id="lab_registration_code" value="<?php echo isset($lab_registration_code)?$lab_registration_code:''; ?>"></td>
                                                    <td class="LabTdLeft" valign="top">Laboratory Name</td>
                                                    <td class="LabTdRight" valign="top"><input name="labname" type="text" id="labname" value="<?php echo isset($labName)?$labName:''; ?>"></td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top" id="country_col" >Certificate No.</td> 
                                                    <td class="LabTdRight" valign="top"><input name="certificate_no" type="text" id="certificate_no" value="<?php echo $certificate_no; ?>"></td>
                                                    <td class="LabTdLeft" valign="top" id="country_col" >Country<span style="color:red;">&nbsp;*</span></td>
                                                    <td class="LabTdRight" valign="top"  id="country_val">
                                                        <select style="width:150px;" name="country" id="country" onchange="getCountry(this.value);">
                                                            <option value="0">Please Select</option>
                                                            <?php
                                                            foreach ($country as $data) {
                                                                ?>
                                                                <option value="<?php echo $data[id]; ?>" <?php echo ($selectedCountry == $data[id]) ? 'selected' : ''; ?>><?php echo $data[name]; ?></option>
                                                            <?php }
                                                            ?>
                                                        </select>
                                                    </td>
                                                </tr>
                                                <tr id="country_row">
                                                    <td class="LabTdLeft" valign="top" id="">State </td>
                                                    <td class="LabTdRight" valign="top" id="">
                                                        <select style="width:150px;" name="state" id="state" >
                                                            <option value="0">Please Select</option>
                                                            <?php
                                                            foreach ($state as $data) {
                                                                ?>
                                                                <option value="<?php echo $data[id]; ?>" <?php echo ($selectedCountry == $data[id]) ? 'selected' : ''; ?>><?php echo $data[name]; ?></option>
                                                            <?php }
                                                            ?>
                                                        </select>
                                                    </td>
                                                    <td class="LabTdLeft" valign="top" id="">City </td>
                                                    <td class="LabTdRight" valign="top" id="">
                                                        <select style="width:150px;" name="city" id="city" >
                                                            <option value="0">Please Select</option>
                                                            <?php
                                                            foreach ($city as $data) {
                                                                ?>
                                                                <option value="<?php echo $data[id]; ?>" <?php echo ($selectedCountry == $data[id]) ? 'selected' : ''; ?> ><?php echo $data[name]; ?></option>
                                                            <?php }
                                                            ?>
                                                        </select></td>
                                                </tr>

                                                <tr><td colspan="4" height="5px"></td></tr>

                                                <tr>
                                                    <td class="LabTdLeft" valign="top">Zone</td>
                                                    <td class="LabTdRight" valign="top">
                                                    <?php 
                                                        if(!empty($zone) && count($zone)>0){
                                                            foreach ($zone as $key => $value) {
                                                    ?>
                                                    <input type="checkbox" name="zone[]" id="zone_<?php echo $value['id']; ?>" value="<?php echo $value['id']; ?>">
                                                    <?php 
                                                        echo $value['zone_name']."<br>";
                                                            }
                                                        } 
                                                    ?>
                                                    </td>
                                                    <td class="LabTdLeft" valign="top">Nature of Lab</td>
                                                    <td class="LabTdRight" valign="top">
                                                    <?php 
                                                        if(!empty($natureoflab) && count($natureoflab)>0){
                                                            foreach ($natureoflab as $key => $value) {
                                                    ?>
                                                    <input type="checkbox" name="natureoflab[]" id="natureoflab_<?php echo $value['id']; ?>" value="<?php echo $value['id']; ?>">
                                                    <?php 
                                                    echo $value['nature_name']."<br>";
                                                                
                                                            }
                                                        } 
                                                    ?>
                                                    </td>
                                                </tr>

                                                <tr><td colspan="4" height="10px">&nbsp;</td></tr>

                                                <tr>
                                                    <td class="LabTdLeft" valign="top">Field</td>
                                                    <td class="LabTdRight" valign="top">
                                                    <?php 
                                                        if(!empty($facilitydropdown) && count($facilitydropdown)>0){
                                                            foreach ($facilitydropdown as $key => $value) {
                                                    ?>
                                                    <input onchange="get_labcat(this)" type="checkbox" name="field[]" id="field_<?php echo $value['id']; ?>" value="<?php echo $value['id']; ?>">
                                                    <?php 
                                                    echo $value['category_name']."<br>";
                                                                
                                                            }
                                                        } 
                                                    ?>
                                                    </td>
                                                    <td class="LabTdLeft" valign="top">Facility</td>
                                                    <td class="LabTdRight" valign="top">
                                                    <?php 
                                                        if(!empty($operationat) && count($operationat)>0){
                                                            foreach ($operationat as $key => $value) {
                                                    ?>
                                                    <input type="checkbox" name="operationat[]" id="operationat_<?php echo $value['id']; ?>" value="<?php echo $value['id']; ?>">
                                                    <?php 
                                                        echo $value['operation_name']."<br>";
                                                            }
                                                        } 
                                                    ?>
                                                    </td>

                                                    </td>
                                                </tr>

                                                <tr><td colspan="4" height="5px"></td></tr>

                                                <tr>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">Discipline</td>
                                                    <td class="LabTdRight" valign="top">
                                                        <div id='discipline' style="border: 1px solid gray;width: 70%;height: 350px;max-height: 150px;overflow-y: scroll;" >
                                                        </div>
                                                    </td>
                                                    <td class="LabTdLeft" valign="top">Group</td>
                                                    <td class="LabTdRight" valign="top">
                                                        <div id='group' style="border: 1px solid gray;width: 70%;height: 350px;max-height: 150px;overflow-y: scroll;">
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">Sub Group </td>
                                                    <td class="LabTdRight" valign="top" colspan="3">
                                                        <div id='subgroup' style="border: 1px solid gray;width: 28%;height: 350px;max-height: 150px;overflow-y: scroll;">
                                                        </div>
                                                    </td>

                                                    </td>
                                                </tr>
                                                <tr><td colspan="4" height="10px"><hr /></td></tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="LabTdLeft" valign="top"><font color="#000000"><strong><em>Looking For Keyword</em></strong></font></td>
                                                    <td class="LabTdRight" valign="top"><input type="text" name="searchword" id="searchword" value="<?php echo $searchKeyword; ?>" /></td>
                                                    <td class="LabTdLeft" valign="top">&nbsp;</td>
                                                    <td class="LabTdRight" valign="top">&nbsp;</td>
                                                </tr>  
                                                <tr><td colspan="4" height="5px"></td></tr>            
                                                <tr>
                                                    <td align="center" colspan="4" valign="top"><center>
                                                    <input type="hidden" name="searchSts" id="searchSts" value="0">
                                                    <input onclick="return get_data(this);" type="button" name="submit" value="Search">
                                                    &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;
                                                    <input onclick="return get_data(this);" id="export-excel" class="btn btn-primary" name="export-excel" value="Export to excel" type="button">&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;
                                                    <input type="button" name="button" id="button" value="Reset" onclick="javascript: return resetpage();" />
                                                    </center></td>
                                                </tr>
                                                <tr><td colspan="4" height="5px"></td></tr>
                                            </table></br>
                                                <div>
                                                    
                                                </div>



                                        <table id="rowDataShow" width="100%" border="0" cellpadding="0" cellspacing="0">











                                        </table>

                                        <table width='100%' border='0' cellspacing='0' cellpadding='5'>
                                            <tr>
                                                <td align='left' valign='top' width='100%' id="pagination" >
                                                </td>
                                            </tr>
                                        </table>


                                    </td>
                                </tr>
                            </table>

                        </td>
                    </tr>

                </table>
            </div>

            <div class="clrfix"></div>
        </div>
    </div>		
    <div class="clrfix"></div>
</div> 

<!--bottom-->

<!-- -->
<!--footer-->
<?php include 'include/footer_main.php'; ?>	
</div>
</div>
</div>

<div id="templetData" style="display: none;">
    <table width="465px" border="0" cellspacing="0" cellpadding="0" class="Border LabBg tableListingMe" >
        <tbody>
        <tr>
            <td width="120px" height="50px" class="LabPaddingLeft" valign="top"><b>Lab Name :</b></td>
            <td width="0px" height="40px" class="LabPaddingLeft" valign="top"><font color="#666666"><b><span class="labname_span"></span></b></font></td>   
            <td width="5" height="40px">&nbsp;</td>
        </tr>                                                   
        <tr>
            <td style="height:5px;" colspan="3"></td>
        </tr>
        <tr>
            <td height="140px" class="LabPaddingLeft" valign="top"><b>Address :</b></td>
            <td class="LabPaddingLeft" valign="top"><span class="address_span"></span></td>
            <td width="5">&nbsp;</td>
        </tr>                                                                                         
        <tr>
            <td style="height:5px;" colspan="3"></td>
        </tr>
        <tr>
            <td class="LabPaddingLeft" valign="top"><b>Tel No. :</b></td>
            <td class="LabPaddingLeft" valign="top"><span class="tel_span"></span></td>
            <td width="5">&nbsp;</td>
        </tr>
        <tr>
            <td style="height:5px;" colspan="3"></td>
        </tr>
        <tr>
            <td class="LabPaddingLeft" valign="top"><b>Fax No. :</b></td>
            <td class="LabPaddingLeft" valign="top"><span class="fax_span"></span></td>
            <td width="5">&nbsp;</td>
        </tr>
        <tr><td style="height:5px;" colspan="3"></td></tr>
        <tr>
            <td class="LabPaddingLeft" valign="top" height="40px"><b>Email :</b></td>
            <td class="LabPaddingLeft" valign="top"><span class="email_span"></span></td>
            <td width="5">&nbsp;</td>
        </tr>
        <tr><td style="height:5px;" colspan="3"></td></tr>
        <tr>
            <td class="LabPaddingLeft" valign="top"><b>Contact Person :</b></td>
            <td class="LabPaddingLeft" valign="top"><span class="con_per_span"></span></td>
            <td width="5">&nbsp;</td>
        </tr>
        <tr><td style="height:5px;" colspan="3"></td></tr> 
        <tr>
            <td class="LabBotBg" colspan="3">                                                 
                <a href="#" class="linkopen_span" onclick=""> Click here to View the Scope of Accreditation</a>
                &nbsp;
            </td>                                                                      
        </tr>
        <tr>
            <td class="LabBotBg" colspan="3">
                <a href='#' class="fileopen_span" onclick=""> Click here to view scope of sample collection centre</a>
            </td>                           
        </tr>
        <tr>
            <td class="LabBotBg" colspan="3">&nbsp;</td>                           
        </tr>
    </tbody>
    </table>    
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    /*$("#search-form").submit(function (event) {
        if ($("#country").val() == '0')
        {
            alert("Please select country.");
            return false;
        }
        return true;
    });*/

$('document').ready(function() {
    //get_data();
});
function resetpage() {
    var servername = '<?php echo base_url(); ?>';
    window.location = "index.php?c=search&m=index";
}
function getCountry(countryid){
    if(countryid=='1'){
        $('#country_row').show();
    } else {
        $('#country_row').hide();
        $('#state,#city').val('-1');
    }
}
function get_data(ths){
    if($('#searchSts').val()=='0'){
        $('#searchSts').val('1');
        var params = {};
        params['lab_registration_code'] = $('#lab_registration_code').val();
        params['labname'] = $('#labname').val();
        params['certificate_no'] = $('#certificate_no').val();
        params['country'] = $('#country').val();
        params['state'] = $('#state').val();
        params['city'] = $('#city').val();
        params['searchword'] = $('#searchword').val();
        params['zone'] = $('[id^="zone_"]:checked').map(function() { return this.value; }).get().join(",");
        params['natureoflab'] = $('[id^="natureoflab_"]:checked').map(function() { return this.value; }).get().join(",");
        params['field'] = $('[id^="field_"]:checked').map(function() { return this.value; }).get().join(",");
        params['operationat'] = $('[id^="operationat_"]:checked').map(function() { return this.value; }).get().join(",");
        params['discipline'] = $('[id^="discipline_"]:checked').map(function() { return this.value; }).get().join(",");
        params['group'] = $('[id^="group_"]:checked').map(function() { return this.value; }).get().join(",");
        params['subgroup'] = $('[id^="subgroup_"]:checked').map(function() { return this.value; }).get().join(",");

        if($(ths)){
            if($(ths).prop('nodeName')=='A'){
                params['page'] = $(ths).attr('data-href');
            }
        }

        $.ajax({
            url: '<?php echo base_url(); ?>index.php?c=searchlab&m=searchdata',
            data: params,
            type: 'POST',
            dataType: 'json',
            async: false,
            success: function (result) {
                $('#searchSts').val('0');
                if(result.code=='0'){
                    $('#pagination').html('');
                    $('#rowDataShow').html('<tr><td><b>No Record Found</b></td></tr>');
                } else {
                    $('#rowDataShow').html('');
                    if(result.hasOwnProperty('data') && parseInt(result.data.length)>0){
                        $.each(result.data,function(keyPgn,valPgn){
                            $('#templetData .labname_span').text(valPgn.labname);
                            $('#templetData .address_span').text(valPgn.address);
                            $('#templetData .tel_span').text(valPgn.telephone);
                            $('#templetData .fax_span').text(valPgn.fax);
                            $('#templetData .email_span').text(valPgn.email);
                            $('#templetData .con_per_span').text(valPgn.contact_person);
                            $('#templetData .linkopen_span').attr('onclick','return open_win('+valPgn.linkopen_span+')');
                            if(valPgn.hasOwnProperty('fileopen_span')){
                                $('#templetData .fileopen_span').show();
                                $('#templetData .fileopen_span').attr('onclick','return open_win_sample('+valPgn.fileopen_span+')');
                            } else {
                                $('#templetData .fileopen_span').hide();
                            }
                            
                            $('#rowDataShow').append($('#templetData').html());
                        });
                    }

                    $('#pagination').html('');
                    if(result.hasOwnProperty('pagination') && parseInt(result.pagination.length)>0){
                        $.each(result.pagination,function(keyPgn,valPgn){
                            $('#pagination').append('<a onclick="get_data(this)" href="JavaScript:void(0);" class="paginationClass" data-href="'+valPgn.pageUrl+'">'+valPgn.pageText+'</a>');
                        });
                    }
                    
                }
            }
        });
    }


}
function get_labcat(ths){
    var params = {};
    var idsArr=$(ths).attr('id').split('_');
    params['type_data'] = idsArr[0];
    params['search_data'] = $('[id^="'+idsArr[0]+'_"]:checked').map(function() { return this.value; }).get().join(",");

    $.ajax({
        url: '<?php echo base_url(); ?>index.php?c=searchlab&m=searchlabcat',
        data: params,
        type: 'POST',
        dataType: 'json',
        async: false,
        success: function (result) {
            if(result.code==0){
                $('#'+result.target).html(result.data);
            }
            if(result.target=='discipline'){
                $('#group,#subgroup').html('');
            }
            if(result.target=='group'){
                $('#subgroup').html('');
            }
            console.log(result);
        }
    });    
}
function open_win_sample(certificateid){
    var cid = certificateid;
    testwindow = window.open('index.php?c=search&m=searchlabsamplecollection&cno=' + cid, 'mywindow', 'scrollbars=yes,menubar=no,height=700,width=1000,resizable=yes,toolbar=no,location=no,status=no');
    testwindow.moveTo(100, 100);
}
</script>

</body>
</html>