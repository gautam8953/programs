<?php

class searchlab_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function get_search($search) {
        $qry='SELECT l.id,l.lab_name,l.lab_address,l.phone,l.fax,l.emailid,l.contact_person,c.id as cid,c.certificate_file2
FROM laboratory_tbl as l
inner join lab_certificate_tbl as c on(c.lab_id=l.id AND c.id=(select max(cdd.id) from lab_certificate_tbl As cdd where cdd.lab_id=l.id) )
inner join certificate_sub_group_tbl as csub on(c.id=csub.certificate_id)
LEFT JOIN cities As city ON (l.city=city.id) 
LEFT JOIN states As s ON (l.state=s.id) 
LEFT JOIN country As ctry ON (l.country=ctry.id) 
LEFT JOIN zone_tbl As z ON (l.zone=z.id) 
WHERE 1 AND l.status=1 AND c.status=1 AND c.is_apiarchive=0 AND c.expiry_date>="'.date("Y-m-d").'" ';
$where='';
if(!empty($search['lab_registration_code'])){
    $where.=' AND l.lab_registration_code="'.trim($search['lab_registration_code']).'"';
}
if(!empty($search['labname'])){
    $where.=' AND l.lab_name like "%'.trim($search['labname']).'%"';
}
if(!empty($search['certificate_no'])){
    $where.=' AND c.certificate_no ="'.trim($search['certificate_no']).'"';
}
if(!empty($search['country'])){
    $where.=' AND l.country ="'.trim($search['country']).'"';
}
if(!empty($search['state'])){
    $where.=' AND l.state ="'.trim($search['state']).'"';
}
if(!empty($search['city'])){
    $where.=' AND l.city ="'.trim($search['city']).'"';
}
if(!empty($search['zone'])){
    $where.=' AND l.zone IN("'.trim($search['zone']).'")';
}
if(!empty($search['natureoflab'])){
    $where.=' AND c.nature_of_lab IN("'.trim($search['natureoflab']).'")';
}
if(!empty($search['field'])){
    $where.=' AND c.faclity_id IN("'.trim($search['field']).'")';
}
if(!empty($search['operationat'])){
    $operationatArr=explode(',', $search['operationat']);
    $operationatQry=array();
    foreach ($operationatArr as $key => $value) {
        $operationatQry[]=' c.operationat REGEXP "'.trim($value).'"';
    }
    if(!empty($operationatQry)){
        $where.=' AND ('.implode('OR', $operationatQry).')';
    }
    
}
if(!empty($search['discipline'])){
    $disciplineArr=explode(',', $search['discipline']);
    $disciplineQry=array();
    foreach ($disciplineArr as $key => $value) {
        $disciplineQry[]=' c.filed_id REGEXP "'.trim($value).'"';
    }
    if(!empty($operationatQry)){
        $where.=' AND ('.implode('OR', $disciplineQry).')';
    }
}

if(!empty($search['group'])){
    $where.=' AND csub.group_id IN("'.trim($search['group']).'")';
}
if(!empty($search['subgroup'])){
    $where.=' AND csub.sub_group_id IN("'.trim($search['subgroup']).'")';
}
if (!empty($search['searchword'])) {
    $json_api_get_array  = array();
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_URL => 'http://13.127.41.6/NABLIntegration/api/Search?Keyword='.trim($search['searchword']),
        CURLOPT_USERAGENT => 'Codular Sample cURL Request'
    ));
    $resp = curl_exec($curl);

     curl_close($curl);
     $json_obj = json_decode($resp);
     foreach($json_obj as $val){
        $json_api_get_array[] =$val->CertificateNo; 
     }
    if(!empty($json_api_get_array)){
        $apicertificateNo= implode(',',$json_api_get_array);        
        $apiCond=' OR c.certificate_no IN ("'.$apicertificateNo.'")';
    } else {
        $apiCond='';
    }

    $where.=' AND (c.file_content like "%'.trim($search['searchword']).'%" '.$apiCond.' )';
}
$group=' group by c.lab_id';
$order=' ORDER BY l.lab_name';
if(!empty($search['pagelength'])){
    if(empty($search['page']) || $search['page']==1){
        $start=0;
    } else {
        $start=(($search['page']-1)*$search['pagelength']);
    }
    $limit=' limit '.$start.','.$search['pagelength'];
}

        $sqlTot=$qry.$where.$group;
        $queryTot =$this->db->query($sqlTot,NULL);

        $sqlData=$qry.$where.$group.$order.$limit;
        $query =$this->db->query($sqlData,NULL);

        $dataget=array();
        foreach ($query->result() as $key => $value) {
            $subdata=array();
            $subdata['labname']=$value->lab_name;
            $subdata['address']=$value->lab_address;
            $subdata['telephone']=$value->phone;
            $subdata['fax']=$value->fax;
            $subdata['email']=$value->emailid;
            $subdata['contact_person']=$value->contact_person;
            if(!empty($value->certificate_file2)){
                $subdata['fileopen_span']=$value->cid;
            }
            $subdata['linkopen_span']=$value->id;
            $dataget[]=$subdata;
        }

        $pageLast=ceil($queryTot->num_rows()/$search['pagelength']);
        $pagination=array();
        $pagination[]=array('pageUrl'=>1,'pageText'=>'Start');
        for ($i=($search['page']); $i < ($search['page']+$search['pagelength']) ; $i++) {
            if($i>0 && $i<=$pageLast){
                $pagination[]=array('pageUrl'=>($i),'pageText'=>($i));                
            }
        }
        $pagination[]=array('pageUrl'=>$pageLast,'pageText'=>'Last');        

        $qryDataGet=array();
        $qryDataGet['totalData']=$queryTot->num_rows();
        $qryDataGet['code']=$queryTot->num_rows();
        $qryDataGet['data']=$dataget;
        $qryDataGet['pagelast']= $pageLast;
        $qryDataGet['extdata']= $start;
        $qryDataGet['qry']= $sqlData;
        $qryDataGet['pagination']= $pagination;

        return $qryDataGet;

    }
    public function get_country() {
        $this->db->select('id,name');
        $this->db->from('country');
        $searchArr['isActive']=1;
        $this->db->where($searchArr);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_state() {
        $this->db->select('id,name');
        $this->db->from('states');
        $this->db->order_by('name ASC');
        $searchArr['isActive']=1;
        $this->db->where($searchArr);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_city() {
        $this->db->select('id,name');
        $this->db->from('cities');
        $this->db->order_by('name ASC');
        $searchArr['isActive']=1;
        $this->db->where($searchArr);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_zone() {
        $this->db->select('id,zone_name');
        $this->db->from('zone_tbl');
        $this->db->order_by('zone_name ASC');
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_natureoflab() {
        $this->db->select('id,nature_name');
        $this->db->from('lab_nature_tbl');
        $this->db->order_by('nature_name ASC');
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_labcat($cat_id) {
        $this->db->select('id,category_name');
        $this->db->from('lab_category_tbl');
        $this->db->where_in('cat_id', explode(',',$cat_id));
        $this->db->order_by('category_name ASC');
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_operationat($cat_id) {
        $this->db->select('id,operation_name');
        $this->db->from('lab_operations_tbl');
        $this->db->order_by('operation_name ASC');
        $query = $this->db->get();
        return $query->result_array();
    }

    /*public function get_city($stateID=0,$id=0) {
        $this->db->select('id,name');
        $this->db->from('cities');
        $searchArr=array();
        if($id>0){
            $searchArr['id']=$id;
        }
        if($stateID>0){
            $searchArr['stateid']=$stateID;
        }
        $this->db->where($searchArr);
        $query = $this->db->get();
        return $query->result_array();
    }*/



}
