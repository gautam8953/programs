$(document).ready(function () {
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 5,
        "retrieve": true,
        "searching": false,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": false,
        "ajax": {
            url: pageMainUrl + "ApiMonthly/reportData_certificate",
            type: "post",
            data: function (d) {
                d.CertificationID = $('#CertificationID').val();
                d.monthCount = $('#monthCount').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        success:function(){
             
        },
        drawCallback: function () {
            $("#loader_overlay").hide();
            $("#bodyLoad").removeClass('loader');
        }
    });

    $('#btn_search').click(function () {
        datatableData.ajax.reload();
    });
    $("#reset_btn").click(function () {
        $('select').prop('selectedIndex', 0);        
        $('.selectpicker').selectpicker('refresh');
        datatableData.ajax.reload();
    })

});
