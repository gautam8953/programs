$(document).ready(function () {
    $('.numbel').hide();
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 10,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "order": [[ 0, "desc" ]],
        "ajax": {
            url: pageMainUrl + "ApiUser/getNotification",
            type: "post",
            data: function (d) {
                $("#bodyLoad").removeClass('loader');
                $("#loader_overlay").hide();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        drawCallback: function () {
        }
    });


});


