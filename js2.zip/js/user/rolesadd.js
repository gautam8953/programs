$(document).ready(function () {

    $('#roleForm').submit(function() {
        $(this).ajaxSubmit({
          beforeSubmit:  showRequest,
          success: showResponse,
          type: 'POST',
          dataType: 'json',
          data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
        });
        return false; 
    });

});

function showResponse(responseText, statusText, xhr, $form)  {
    $("#bodyLoad").removeClass('loader');
    $("#loader_overlay").hide();
    if(parseInt(responseText.code)==0){
        swal(responseText.msg).then((value) => {
            window.location.replace(pageMainUrl+"user/roles");
        });
    } else {
      swal(responseText.msg);
      $('#RoleFrm').prop('disabled',false);
    }
}
function showRequest(formData, jqForm, options) { 
    var check='0';
    $('#RoleFrm').prop('disabled',true);
    var inputCheck=$('#roleForm input[type="text"]').filter(function(){
      return $(this).val()=='';
    });
    if(parseInt(inputCheck.length)>0){
      inputCheck.closest('.form-group').addClass('has-error');
      check='1';
    }

    if(check!='0'){
      $('#RoleFrm').removeAttr('disabled');
      return false;
    }
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    return true; 
}

