$(document).ready(function () {
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 5,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "order": [[1, "ASC" ]],
        "ajax": {
            url: pageMainUrl + "ApiReports/getanalysis",
            type: "post",
            data: function (d) {
                d.search_facility = $('#search_facility').val();
                d.search_district = $('#search_district').val();
                d.search_state = $('#search_state').val();
                d.search_years = $('#search_survey').val();
                d.search_months = $('#search_cat').val();
                d.search_months = $('#search_score').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        success:function(){
             
        },
        drawCallback: function () {
            $("#loader_overlay").hide();
            $("#bodyLoad").removeClass('loader');
        }
    });

    $('#btn_search').click(function () {
        $("#bodyLoad").addClass('loader');
        $("#loader_overlay").show();
        datatableData.ajax.reload();
    });
    $("#reset_btn").click(function () {
        $('select').prop('selectedIndex', 0);        
        $('.selectpicker').selectpicker('refresh');
        datatableData.ajax.reload();
    });
     
     $('#search_months').change(function(){
        datatableData.ajax.reload();
     });
     $('#search_years').change(function(){
        datatableData.ajax.reload();
     });

});



function getDataCategory () {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['search_survey'] = $('#search_survey').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getDataCategory',
        data: params,
        type: 'POST',
        dataType: 'json',
        async: false,
        success: function (result) {
            $('#search_cat').html('<option value="">Select Category</option>');
            if(result.code!='0'){
                $.each(result.cat, function (key, val) {
                    $('#search_cat').append($("<option></option>").attr("value", val.CategoryCode).text(val.CategoryName));
                });                
            }
        }
    });
}

function change_district() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'facility';
    params['searchData'] = $('#search_district').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        async:false,
        success: function (result) {
            $('#search_facility').html('<option value="">Select Facility</option>');
            if (result.data) {
                if (parseInt(result.data.length) > 0) {
                    $.each(result.data, function (key, val) {
                        $('#search_facility').append($("<option></option>").attr("value", val.UserID).text(val.FacilityName));
                    });
                }
            }
        }
    });
    $('#btn_search').trigger('click');
}

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="">Select District</option>');
            if (parseInt(result.data.length) > 0) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }            
        }
    });
    $('#search_facility').html('<option value="">Select Facility</option>');
    $('#btn_search').trigger('click');
}



function change_facility(){
    $('#btn_search').trigger('click');
}