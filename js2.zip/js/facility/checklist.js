$(document).ready(function(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl+'ApiUser/roleData', 
        data: params, 
        type: 'POST', 
        dataType: 'json',
        async:false, 
        success: function(result){
            if(result.data.Facility.hasOwnProperty('FacilityName')){
              $('#facilityName').html('<option value="'+result.data.Facility.UserID+'">'+result.data.Facility.FacilityName+'</option>');
            }
        }
    });
    
	if($('#ansId').val()!=''){
		getAssesmentData();
		getAnswer();
	} else {
		// for getting facilityname
        if($('#user').val()=='Facility'){
	       assementdataCheck();            
        }
	}




    $('.selectpicker').selectpicker('refresh');
});
function assementdataCheck(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['SurveyID']=$('#SurveyID').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/assementdataCheck', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            if(result.code=='1'){
              console.log('lr incomplete redirect its href got ');
              swal(result.msg)
              .then((value) => {
                window.location.replace(pageMainUrl+result.href);
              });
            }
            if(result.code=='2'){
              swal(result.msg)
              .then((value) => {
                window.location.replace(pageMainUrl+result.href);
              });
              //console.log('no lr and its ot so redirect to fill lr first')
            }
            if(result.basecheck=='3'){
              //console.log('as per page baseline is alreday filled so make baseline disable');
              $('#sequence option:eq(0)').prop('disabled',true);
              $('#sequence option:eq(1)').prop('disabled',false);
              $('#sequence option:eq(2)').prop('disabled',true);
              $('#sequence').val('2');
            }
            if(result.endcheck=='3'){
              //console.log('end line open so make all disable');
              $('#sequence option:eq(0)').prop('disabled',true);
              $('#sequence option:eq(1)').prop('disabled',true);
              $('#sequence option:eq(2)').prop('disabled',false);
              $('#sequence').val('3');
            }
            $('#sequence').selectpicker('refresh');
        }
    });  
}

function changeFacility(ths){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['facilitySetId']=$(ths).val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/setFacility', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
          assementdataCheck();
          $('#facilityName').selectpicker('refresh');
        }
    });  
}

function change_district(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType']='facility';
    params['searchData']=$('#search_district').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/getSearchOptions', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#facilityName').html('<option value="">Select Facility</option>');
            if(result.data){
                if(parseInt(result.data.length)>0){
                    $.each(result.data,function(key,val){
                        //$('#facilityName').append($("<option></option>").attr("value",val.UserID).text(val.FacilityName));
                        $('#facilityName').append('<option value="'+val.UserID+'">'+val.FacilityName+'</option>');
                    });
                    $('#facilityName').selectpicker('refresh');
                //if($('#facilityName').length){
                //    if(parseInt($('#facilityName option').length)==2){
                //        $('#facilityName').val($('#facilityName option:eq(1)').val());
                //        $('#facilityName').trigger('change');
                //    }
                //}
                }                
            }
        }
    });
}

function change_state(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType']='district';
    params['searchData']=$('#search_state').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/getSearchOptions', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#search_district').html('<option value="">Select District</option>');
            if(parseInt(result.data.length)>0){
                $.each(result.data,function(key,val){
                    $('#search_district').append($("<option></option>").attr("value",val.DistrictID).text(val.DistrictName));
                });
            }
            //if(parseInt($('#search_district option').length)>=2){
            //    $('#search_district').val($('#search_district option:eq(1)').val());
            //    change_district();
            //}
            $('#facilityName').html('<option value="">Select Facility</option>');
        }
    });    
}

function getAnswer(){
	var params={};
	params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
	params['survey']=$('#SurveyID').val();
	params['ansId']=$('#ansId').val();
	$.ajax({
		url: pageMainUrl+'ApiFacility/questionsAns', 
		data: params, 
		type: 'POST', 
		dataType: 'json', 
		success: function(result){
			if(result.data.category){
				$.each(result.data.category,function(index,dataVal){
					$('a[href="#step-'+index+'"]').click();
					$.each(dataVal.questions,function(indexQues,valQues){
						$('#answer_'+indexQues+'_'+valQues).attr('checked',true);
						$('#uncheckRadio_'+indexQues).show();
					});
					if(parseInt($('#step-'+index+' .quote1-full2').length)==parseInt($('#step-'+index+' input[type=radio]:checked').length)){
						$('.sw-btn-next').click();
					}
                    $.each(dataVal.standered,function(indexSub,valSub){
                        $('#SubScore_'+indexSub).html(valSub.answer);
                        var totmarks=parseInt(valSub.questionTot*2);
                        $('#SubTot_'+indexSub).html(' - '+parseInt(parseFloat(parseInt(valSub.answer)/parseInt(totmarks))*100)+'%');
                    });

				});
			}
			if(result.data.surveyStatus=='1'){
				window.location.href=pageMainUrl+'Facility/index';
			}
		}
	});	
}
function getAssesmentData(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['ansId']=$('#ansId').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/assesmentDataEdit', 
        data: params, 
        type: 'POST', 
        dataType: 'json',
        async:false, 
        success: function(result){
            $('#sequence').val(result.data.Sequence);
            $('#assessmentDate').val(result.data.AssessmentDate);
            $('#assessorsName1').val(result.data.AssessorsName1);
            $('#assessorsName2').val(result.data.AssessorsName2);
            $('#assesseesName1').val(result.data.AssesseesName1);
            $('#assesseesName2').val(result.data.AssesseesName2);
            $('#assessmentType').val(result.data.AssessmentType);
            $('#submissionDate').val(result.data.start_date);
            $('#facilityName').html('<option value="'+result.data.UserID+'">'+result.data.FacilityName+'</option>');
            if($('#search_state').length){
                $('#search_state').append('<option value="'+result.data.StateID+'">'+result.data.StateName+'</option>');
                $('#search_state').val(result.data.StateID);
            }
            if($('#search_district').length){
                $('#search_district').append('<option value="'+result.data.DistrictID+'">'+result.data.DistrictName+'</option>');
                $('#search_district').val(result.data.DistrictID);
            }
            $('#facilityName').selectpicker('refresh');
        }
    });	
}