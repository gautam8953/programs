
  $('document').ready(function(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['ansId']=$('#ansId').val();
    $.ajax({
      url:pageMainUrl+"ApiFacility/score",
      'data':params,
      'type':'post',
      'dataType':'json',
      'success':function(result){
        var totScore=0;
        $('#assementName').text(result.data.score[0].SurveyDesc);
        $('#totScore').prev().text(result.data.score[0].SurveyName+' Score');
        var totmarks=0;
        $.each(result.data.score,function(key,val){
          if(parseFloat(val.score)>=65){
            var classTxt='success';
          } else if(parseFloat(val.score)>=40 && parseFloat(val.score)<=65){
            var classTxt='inprocess';
          } else {
            var classTxt='faild';
          }

          $('#score tbody').append('<tr class="'+classTxt+'"><td class="text-center">'+val.CategoryCode+'</td><td class="text-center">'+val.CategoryName+'</td><td class="text-right">'+val.answer+'</td><td class="text-right">'+val.quesTot*2+'</td><td class="text-right">'+val.score+'%</td></tr>');
          totmarks=parseInt(totmarks)+parseInt(val.answer);
          totScore=parseInt(totScore)+parseInt(val.quesTot*2);
        });
        //console.log(totmarks+'_'+totScore);
        var finalScore=parseInt(parseFloat(parseInt(totmarks)/parseInt(totScore))*100);
        if(parseFloat(finalScore)>=65){
          var classTxt='success';
        } else if(parseFloat(finalScore)>=40 && parseFloat(finalScore)<=65){
          var classTxt='inprocess';
        } else {
          var classTxt='faild';
        }
        $('#totScore').text(finalScore+'%');
        $('#totScore').closest('.rtst-bx-scr').addClass(classTxt);

        $('p.clientScore').text(result.data.facility.clientScore);
        $('span.FacilityName').text(result.data.facility.FacilityName);
        $('span.sequence').text(result.data.facility.Sequence);
        $('span.assessmentDate').text(result.data.facility.AssessmentDate);
        $('span.assessorsName1').text(result.data.facility.AssessorsName1);
        $('span.assessorsName2').text(result.data.facility.AssessorsName2);
        $('span.assesseesName1').text(result.data.facility.AssesseesName1);
        $('span.assesseesName2').text(result.data.facility.ssesseesName2);

        if(result.data.hasOwnProperty('standered_data')){
          $('#standardScore thead').append('<tr>');
          $.each(result.data.standered_data,function(keyCat,valCat){
            $('#standardScore thead tr').append('<th>'+valCat.CategoryCode+' - '+valCat.CategoryName+'</th>');
          });
          $('#standardScore thead').append('</tr>');
        }
        if(result.data.hasOwnProperty('standered_data')){
          $('#standardScore tbody').append('<tr>');
          $.each(result.data.standered_data,function(keyCat,valCat){
            var innerData='<table>';
            $.each(valCat.standered,function(keySubCat,valSubCat){
              if(parseFloat(valSubCat.score)>=65){
                var classTxt='success';
                var classTxt1='success1';
              } else if(parseFloat(valSubCat.score)>=40 && parseFloat(valSubCat.score)<=65){
                var classTxt='inprocess';
                var classTxt1='inprocess1';
              } else {
                var classTxt='faild';
                var classTxt1='faild1';
              }

              innerData+='<tr>';
              innerData+='<td>';

              innerData+='<table class="'+classTxt+'">';
              innerData+='<tr class="'+classTxt1+'"><th colspan="2">'+valSubCat.SubCategoryCode+'</th></tr>';
              innerData+='<tr class="'+classTxt1+'"><td>Answer:</td><td>'+valSubCat.answer+'</td></tr>';
              innerData+='<tr class="'+classTxt1+'"><td>Total:</td><td>'+(valSubCat.quesTot)*2+'</td></tr>';
              innerData+='<tr class="'+classTxt1+'"><td>Score:</td><td>'+valSubCat.score+'</td></tr>';
              innerData+='</table>';

              innerData+='</td>';
              innerData+='</tr>';

            });
            innerData+='</table>';
            
            $('#standardScore tbody tr:first').append('<td>'+innerData+'</td>');
          });
          $('#standardScore tbody').append('</tr>');
        }

      }

    });   
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['ansId']=$('#ansId').val();
    $.ajax({
      url:pageMainUrl+"ApiFacility/scoreRemarks",
      'data':params,
      'type':'post',
      'dataType':'json',
      'success':function(result){
        
        if(parseInt(Object.keys(result.data).length)>0){
          $.each(result.data,function(keyData,valData){
            var count=1;
            $.each(valData,function(key,val){
              if(count=='1'){
                $('p.q'+val.remarksType).text(val.remarks);
              } else {
                addAns('q'+val.remarksType);
                $('p.q'+val.remarksType+':last').text(val.remarks);
              }
              count=count+1;
            });
          });
        }
      }
    });


  });
  function addAns(ques){
    $('p.'+ques+':last').after($('p.'+ques+':first').clone());
  }
  function removeAns(ques,ths){
    $(ths).closest('.'+ques).remove();
  }
