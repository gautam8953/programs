//var editor;
$(document).ready(function () {
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var editIcon = function (data, type, row) {
        if (type === 'display') {
            return data + ' <i class="fa fa-pencil"/>';
        }
        return data;
    };
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 5,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "ajax": {
            url: pageMainUrl + "ApiSmg/getSearchData",
            type: "post",
            data: function (d) {
                d.search_state = $('#search_state').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        success: function () {
            $("#loader_overlay").hide();
            $("#bodyLoad").removeClass('loader');
        },
        drawCallback: function () {
            $("#loader_overlay").hide();
            $("#bodyLoad").removeClass('loader');
            /*var params={};
             params['device']='web';
             params['facility']=$('#search_facility').val();
             $.ajax({
             url: pageMainUrl+'ApiMonthly/checkMonthlyFacilityAdd', 
             data: params, 
             type: 'POST', 
             dataType: 'json', 
             success: function(result){
             if(result.code=='0'){
             $('#addBtn').removeClass('disabled');
             } else {
             $('#addBtn').addClass('disabled');
             }
             }
             });*/
        }

    });


    $("#refreshDt").click(function () {
        datatableData.ajax.reload();
    });
    $('#btn_search').click(function () {

        $("#bodyLoad").addClass('loader');
        $("#loader_overlay").show();
        if ($('#search_state') && $('#search_state').val() != '') {
            datatableData.ajax.reload();
//            $("#loader_overlay").hide();
//            $("#bodyLoad").removeClass('loader');
        } else {
            $("#loader_overlay").hide();
            $("#bodyLoad").removeClass('loader');
            swal('Please select state');
        }
    });
    $("#reset_btn").click(function () {
//        $('#search_months').prop('selectedIndex', 0);
//        $('#search_years').prop('selectedIndex', 0);
//         $('#search_district').prop('selectedIndex', 0);
        $('select').prop('selectedIndex', 0);

        $('.selectpicker').selectpicker('refresh');
//        $('#search_months').selectpicker('refresh');
//        $('#search_years').selectpicker('refresh');
//        $('#search_district').selectpicker('refresh');
//        $('#search_facility').selectpicker('refresh');
        datatableData.ajax.reload();
    })
//    $(".deleteRow").click(function () {
//        alert(2);
//    });
});


function removeDataRow(id) {
    swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover this detail!",
//        icon: "warning",
        buttons: true,
        dangerMode: false,
    })
            .then((willDelete) => {
                $("#bodyLoad").addClass('loader');
                $("#loader_overlay").show();
                if (willDelete) {
                    var params = {};
                    params['device'] = 'web';
                    params['csrf_token']=$.cookie("csrf_cookie");
                    params['deleteType'] = 'facility';
                    params['id'] = id;
                    $.ajax({
                        url: pageMainUrl + 'ApiSmg/deleteData',
                        data: params,
                        type: 'POST',
                        dataType: 'json',
                        success: function (result) {
                            $("#loader_overlay").hide();
                            $("#bodyLoad").removeClass('loader');
                            swal("Data successfully deleted!", {
//                                icon: "success",
                            });
                            $('#btn_search').trigger('click');
                        }
                    });

                } else {
                    //swal("Your imaginary file is safe!");
                }
            });
}
function getPage(ths) {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['setData'] = $(ths).attr('data-months');
    params['setDataMonth'] = $(ths).attr('data-reqMonth');
    $.ajax({
        url: pageMainUrl + 'ApiMonthly/setViewPage',
        data: params,
        type: 'POST',
        dataType: 'json',
        async: false,
        success: function (result) {
            window.location.href = $(ths).attr('data-href');
        }
    });
}


function checkData() {
    if ($('#reportMonths').val() == '') {
        swal('Please select Month');
        return false;
    }
    if ($('#reportYears').val() == '') {
        swal('Please select Year');
        return false;
    }
    var reportMonths = $('#reportMonths').val();
    var reportYears = $('#reportYears').val();
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'monthReportCheck';
    params['reportMonths'] = reportMonths;
    params['reportYears'] = reportYears;
    $.ajax({
        url: pageMainUrl + 'ApiMonthly/monthReportCheck',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#resultDiv').html(result.data);
        }
    });
}
function editInline(id) {

    $("#name_" + id).attr('type', 'text');
    $("#department_" + id).attr('type', 'text');
    $("#designation_" + id).attr('type', 'text');
    $("#designationSmg_" + id).attr('type', 'text');
    $("#email_" + id).attr('type', 'text');
    $("#mobile_" + id).attr('type', 'text');

    $("#name_span_" + id).hide();
    $("#department_span_" + id).hide();
    $("#designation_span_" + id).hide();
    $("#designationSmg_span_" + id).hide();
    $("#email_span_" + id).hide();
    $("#mobile_span_" + id).hide();

    $("#edit_" + id).css('display', 'none');
    $("#cancel_" + id).css('display', 'block');
    $("#update_" + id).css('display', 'block');
}
function cancelInline(id) {
    $("#edit_" + id).css('display', 'block');
    $("#cancel_" + id).css('display', 'none');
    $("#update_" + id).css('display', 'none');


    $("#name_" + id).attr('type', 'hidden');
    $("#department_" + id).attr('type', 'hidden');
    $("#designation_" + id).attr('type', 'hidden');
    $("#designationSmg_" + id).attr('type', 'hidden');
    $("#email_" + id).attr('type', 'hidden');
    $("#mobile_" + id).attr('type', 'hidden');



    $("#name_span_" + id).show();
    $("#department_span_" + id).show();
    $("#designation_span_" + id).show();
    $("#designationSmg_span_" + id).show();
    $("#email_span_" + id).show();
    $("#mobile_span_" + id).show();
}


function updateInline(id) {
    var name = $("#name_" + id).val();
    var department = $("#department_" + id).val();
    var designation = $("#designation_" + id).val();
    var designationSmg = $("#designationSmg_" + id).val();
    var email = $("#email_" + id).val();
    var mobile = $("#mobile_" + id).val();
    swal({
        title: "Are you sure?",
        text: "Once updated, your previous data will be lost!",
//        icon: "warning",
        buttons: true,
        dangerMode: false,
    })
            .then((willDelete) => {
                if (willDelete) {

                    var params = {};
                    params['device'] = 'web';
                    params['csrf_token']=$.cookie("csrf_cookie");
                    params['name'] = name;
                    params['department'] = department;
                    params['designation'] = designation;
                    params['designationSmg'] = designationSmg;
                    params['email'] = email;
                    params['mobile'] = mobile;
                    params['id'] = id;
                    if (showRequest(id) == true) {
                        $("#bodyLoad").addClass('loader');
                        $("#loader_overlay").show();
                        $.ajax({
                            url: pageMainUrl + 'ApiSmg/updateData',
                            data: params,
                            type: 'POST',
                            dataType: 'json',
                            success: function (result) {
                                $("#loader_overlay").hide();
                                $("#bodyLoad").removeClass('loader');
                                swal("Data successfully updated!", {
//                                icon: "success",
                                });
                                $('#refreshDt').trigger('click');
                            }
                        });
                    }

                } else {
                    //swal("Your imaginary file is safe!");
                }
            });

}
function showRequest(i) {
//    alert(i); return false;
    $("#loader_overlay").hide();
    $("#bodyLoad").removeClass('loader');
//    var totalRow = ($("div[id^='totalDiv_']").length);
    var check = '0';
//    for (var i = 1; i <= totalRow; i++) {

//alert($('#name_' + i).val());
    if ($('#name_' + i).val() == '' || $('#name_' + i).val() == 'undefined') {
        $('#name_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#name_' + i).removeClass('erroShow');
//        $('#name'+i).closest('.form-group').removeClass('has-error');
    }

    if ($('#department_' + i).val() == '' || $('#department_' + i).val() == 'undefined') {
        $('#department_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#department_' + i).removeClass('erroShow');
    }

    if ($('#designation_' + i).val() == '' || $('#designation_' + i).val() == 'undefined') {
        $('#designation_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#designation_' + i).removeClass('erroShow');
    }

    if ($('#designationSmg_' + i).val() == '' || $('#designationSmg_' + i).val() == 'undefined') {
        $('#designationSmg_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#designationSmg_' + i).removeClass('erroShow');
    }

    if ($('#email_' + i).val() == '' || $('#email_' + i).val() == 'undefined') {
        $('#email_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#email_' + i).removeClass('erroShow');
    }

    if ($('#mobile_' + i).val() == '' || $('#mobile_' + i).val() == 'undefined') {
        $('#mobile_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#mobile_' + i).removeClass('erroShow');
    }

//    }
//alert(check);
    if (check != '0') {
//        $('#assesment').prop('disabled', false);
        return false;
    }
    return true;
}