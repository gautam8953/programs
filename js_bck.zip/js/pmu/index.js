//var editor;
$(document).ready(function () {
    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var editIcon = function (data, type, row) {
        if (type === 'display') {
            return data + ' <i class="fa fa-pencil"/>';
        }
        return data;
    };
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 5,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "ajax": {
            url: pageMainUrl + "ApiPmu/getSearchData",
            type: "post",
            data: function (d) {
                d.search_state = $('#search_state').val();
                d.search_district = $('#search_district').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        success: function () {
            $('#search_district').val();
            $("#loader_overlay").hide();
            $("#bodyLoad").removeClass('loader');
        },
        drawCallback: function () {
            $("#loader_overlay").hide();
            $("#bodyLoad").removeClass('loader');
           
        }

    });


    $("#refreshDt").click(function () {
        datatableData.ajax.reload();
    });
    $('#btn_search').click(function () {

        $("#bodyLoad").addClass('loader');
        $("#loader_overlay").show();
        if ($('#search_state') && $('#search_state').val() != '') {
            datatableData.ajax.reload();
//            $("#loader_overlay").hide();
//            $("#bodyLoad").removeClass('loader');
        } else {
            $("#loader_overlay").hide();
            $("#bodyLoad").removeClass('loader');
            swal('Please select state');
        }
    });
    $("#reset_btn").click(function () {
//        $('#search_months').prop('selectedIndex', 0);
//        $('#search_years').prop('selectedIndex', 0);
//         $('#search_district').prop('selectedIndex', 0);
        $('select').prop('selectedIndex', 0);

        $('.selectpicker').selectpicker('refresh');
//        $('#search_months').selectpicker('refresh');
//        $('#search_years').selectpicker('refresh');
//        $('#search_district').selectpicker('refresh');
//        $('#search_facility').selectpicker('refresh');
        datatableData.ajax.reload();
    })
//    $(".deleteRow").click(function () {
//        alert(2);
//    });
});


function removeDataRow(id) {
    swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover this detail!",
//        icon: "warning",
        buttons: true,
        dangerMode: false,
    })
            .then((willDelete) => {
                $("#bodyLoad").addClass('loader');
                $("#loader_overlay").show();
                if (willDelete) {
                    var params = {};
                    params['device'] = 'web';
                    params['csrf_token']=$.cookie("csrf_cookie");
                    params['deleteType'] = 'facility';
                    params['id'] = id;
                    $.ajax({
                        url: pageMainUrl + 'ApiHr/deleteData',
                        data: params,
                        type: 'POST',
                        dataType: 'json',
                        success: function (result) {
                            $("#loader_overlay").hide();
                            $("#bodyLoad").removeClass('loader');
                            swal("Data successfully deleted!", {
//                                icon: "success",
                            });
                            $('#btn_search').trigger('click');
                        }
                    });

                } else {
                    //swal("Your imaginary file is safe!");
                }
            });
}

function change_facility(){
    $('#btn_search').trigger('click');
}

function checkData() {
    if ($('#reportMonths').val() == '') {
        swal('Please select Month');
        return false;
    }
    if ($('#reportYears').val() == '') {
        swal('Please select Year');
        return false;
    }
    var reportMonths = $('#reportMonths').val();
    var reportYears = $('#reportYears').val();
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'monthReportCheck';
    params['reportMonths'] = reportMonths;
    params['reportYears'] = reportYears;
    $.ajax({
        url: pageMainUrl + 'ApiMonthly/monthReportCheck',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#resultDiv').html(result.data);
        }
    });
}





function change_district() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'facility';
    params['searchData'] = $('#search_district').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        async:false,
        success: function (result) {
            $('#search_facility').html('<option value="">Select Facility</option>');
            if (result.data) {
                if (parseInt(result.data.length) > 0) {
                    $.each(result.data, function (key, val) {
                        $('#search_facility').append($("<option></option>").attr("value", val.UserID).text(val.FacilityName));
                    });
                    /*if ($('#search_facility').length) {
                        if (parseInt($('#search_facility option').length) == 2) {
                            $('#search_facility').val($('#search_facility option:eq(1)').val());
                            $('#btn_search').trigger('click');
                        }
                    }*/
                }
            }
        }
    });
    $('#btn_search').trigger('click');
}

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="">Select District</option>');
            if (parseInt(result.data.length) > 0) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
            /*if (parseInt($('#search_district option').length) >= 2) {
                $('#search_district').val($('#search_district option:eq(1)').val());
                change_district();
            }*/
            
        }
    });
    $('#search_facility').html('<option value="">Select Facility</option>');
    $('#btn_search').trigger('click');
}


function showRequest(i) {
//    alert(i); return false;
    $("#loader_overlay").hide();
    $("#bodyLoad").removeClass('loader');
//    var totalRow = ($("div[id^='totalDiv_']").length);
    var check = '0';
//    for (var i = 1; i <= totalRow; i++) {

//alert($('#name_' + i).val());
    if ($('#name_' + i).val() == '' || $('#name_' + i).val() == 'undefined') {
        $('#name_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#name_' + i).removeClass('erroShow');
//        $('#name'+i).closest('.form-group').removeClass('has-error');
    }

    if ($('#department_' + i).val() == '' || $('#department_' + i).val() == 'undefined') {
        $('#department_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#department_' + i).removeClass('erroShow');
    }

    if ($('#designation_' + i).val() == '' || $('#designation_' + i).val() == 'undefined') {
        $('#designation_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#designation_' + i).removeClass('erroShow');
    }

    if ($('#designationSmg_' + i).val() == '' || $('#designationSmg_' + i).val() == 'undefined') {
        $('#designationSmg_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#designationSmg_' + i).removeClass('erroShow');
    }

    if ($('#email_' + i).val() == '' || $('#email_' + i).val() == 'undefined') {
        $('#email_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#email_' + i).removeClass('erroShow');
    }

    if ($('#mobile_' + i).val() == '' || $('#mobile_' + i).val() == 'undefined') {
        $('#mobile_' + i).addClass('erroShow');
        check = '1';
    } else {
        $('#mobile_' + i).removeClass('erroShow');
    }

//    }
//alert(check);
    if (check != '0') {
//        $('#assesment').prop('disabled', false);
        return false;
    }
    return true;
}