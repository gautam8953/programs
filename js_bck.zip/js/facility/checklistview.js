$(document).ready(function(){
    // Step show event
    $("#smartwizard").on("showStep", function (e, anchorObject, stepNumber, stepDirection, stepPosition) {
        if (stepPosition === 'first') {
            $("#prev-btn").addClass('disabled');
        } else if (stepPosition === 'final') {
            $("#next-btn").addClass('disabled');
        } else {
            $("#prev-btn").removeClass('disabled');
            $("#next-btn").removeClass('disabled');
        }
    });
    var btnPreview = $('<button></button>').text('Preview')
            .addClass('btn btn-info btnPreview')
            .on('click', function () {
                preview_data();
            });

    // Smart Wizard
    $('#smartwizard').smartWizard({
        selected: 0,
        theme: 'default',
        transitionEffect: 'fade',
        labelFinish: 'Finish',
        showStepURLhash: false,
        toolbarSettings: {toolbarPosition: 'both',
            toolbarButtonPosition: 'end',
            toolbarExtraButtons: [btnPreview]
        },
        anchorSettings: {
            anchorClickable: true, // Enable/Disable anchor navigation
            enableAllAnchors: true, // Activates all anchors clickable all times
            markDoneStep: true, // add done css
            enableAnchorOnDoneStep: true // Enable/Disable the done steps navigation
        },
    });
    
	if($('#ansId').val()==''){
        window.location.href=pageMainUrl+'Facility/index';
	} else {
        getAssesmentData();
	    getAnswer();
	}

    $('#previewModal').on('hide.bs.modal', function (e) {
      $('#previewModal').find('.modal-body').html('');
    });

    $('#previewModal').on('show.bs.modal', function () {
        $('.modal .modal-body').css('overflow-y', 'auto'); 
        $('.modal .modal-body').css('max-height', $(window).height() * 0.7);
    });

});

function getAnswer(){
	var params={};
	params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
	params['survey']=$('#SurveyID').val();
	params['ansId']=$('#ansId').val();
	$.ajax({
		url: pageMainUrl+'ApiFacility/questionsAns', 
		data: params, 
		type: 'POST', 
		dataType: 'json', 
		success: function(result){
			if(result.data.surveyStatus=='0'){
				//window.location.href=pageMainUrl+'Facility/index';
			}
            if(result.data.category){
                $.each(result.data.category,function(index,dataVal){
                    $.each(dataVal.questions,function(indexQues,valQues){
                        $('#answer_'+indexQues).text(valQues);
                    });
                    $.each(dataVal.standered,function(indexSub,valSub){
                        $('#SubScore_'+indexSub).html(valSub.answer);
                        var totmarks=parseInt(valSub.questionTot*2);
                        $('#SubTot_'+indexSub).html(' - '+parseInt(parseFloat(parseInt(valSub.answer)/parseInt(totmarks))*100)+'%');
                    });
                })
            }
		}
	});	
}
function getAssesmentData(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['ansId']=$('#ansId').val();
    $.ajax({
        url: pageMainUrl+'ApiFacility/assesmentDataView', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#facilityName').text(result.data.FacilityName);
            $('#assessmentDate').text(result.data.AssessmentDate);
            $('#assessorsName1').text(result.data.AssessorsName1);
            $('#assessorsName2').text(result.data.AssessorsName2);
            $('#assesseesName1').text(result.data.AssesseesName1);
            $('#assesseesName2').text(result.data.AssesseesName2);
            $('#assessmentType').text(result.data.AssessmentType);
            $('#facilityAvailable').text(result.data.FacilityAvailable);
            $('#sequence').text(result.data.Sequence);
            $('#assesment').attr('data-type',result.survey);
        }
    });

}

function preview_data(){
    $('[id^="step-"]').each(function(){
        var ids=$(this).attr('id');
        var headingText=$('#smartwizard a[href="#'+ids+'"]').text();
        var html=$('#'+ids).clone();
        $(html).find('.quote-top-bar').html('<h2>'+headingText+'</h2>');
        /*$.each($(html).find('.quote-1-option'),function(key,obj){
            var radioname=$(obj).find('input:first').attr('name');
            var ans=$('#smartwizard input[name="'+radioname+'"]:checked').val()||'';
            $(obj).html('<span>'+ans+'</span>');
        });*/
        $('#previewModal').find('.modal-body').append(html);
    });
    $('#previewModal [id^="step-"]').show();
    $('#previewModal.modal-content').css('height',$(window).height()*0.8);

    $('#previewModal').modal('show');
}