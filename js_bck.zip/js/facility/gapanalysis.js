$(document).ready(function () {

    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 20,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "order": [[ 0, "desc" ]],
        "ajax": {
            url: pageMainUrl + "ApiFacility/getgapdata",
            type: "post",
            data: function (d) {
                $("#bodyLoad").removeClass('loader');
                $("#loader_overlay").hide();
                d.search_score = $('#search_score').val();
                d.search_cat = $('#search_cat').val();
                d.search_answer = $('#search_answer').val();
                d.search_format = $('#search_format').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        drawCallback: function () {
        },
        "dom":"Blfrtip",
        buttons: [
                   {
                    extend: 'excel',
                    text: 'Export to Excel',
                    extension: '.xlsx',
                    exportOptions: {
                        columns: "thead th:not(.noExport)"
                       
                    },
                   
                  }
            ]



    });


    $('#btn_search').click(function () {
        datatableData.ajax.reload();
    });
     $("#reset_btn").click(function () {
        $('select').prop('selectedIndex', 0);
        $('.selectpicker').selectpicker('refresh');
        datatableData.ajax.reload();
    });

});

function getData(){
    $('#btn_search').trigger('click');
}


// code by kunal pandey

function checkFile(fileobj) {
    var validExts = new Array(".xlsx", ".xls", ".csv");
    var fileExt = fileobj.value;
    fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
    if (validExts.indexOf(fileExt) < 0) {
        swal('Please choose only excel file');
        $('#excelfile').val('');
        $("label[for='excelfile']").children('span').text('');
        //$(fileobj).closest('.form-group').addClass('has-error');
        return false;
    } else {
        //$(fileobj).closest('.form-group').removeClass('has-error');
    }
}

function clientScore(ths){
    $('#assessmentID').val($(ths).attr('data-assessment'));
    $('#clientScore').val($(ths).attr('data-clientScore'));
}

$(document).ready(function () {
 
      $('#uploaForm').submit(function () {

        $("#bodyLoad").addClass('loader');
        $("#loader_overlay").show();
        var ansid = $('#search_answer').val();

        $(this).ajaxSubmit({
            beforeSubmit: showRequest,
            success: showResponse,
            type: 'POST',
            dataType: 'json',
            data: {'device': 'web','ansid': ansid,'csrf_token' : $.cookie("csrf_cookie")}
        });
        return false;
    });

});

function showResponse(responseText, statusText, xhr, $form)  {
    $("#loader_overlay").hide();
    $("#bodyLoad").removeClass('loader');
    if(parseInt(responseText.code)==0){
       swal(responseText.msg).then((value) => {
        $("#action_plan").attr("href",responseText.filename);
        $("#clientScoreModal .close").click();
        $("#excelfile").val('');
        $("#excelfiletext").text('');        
      });
    } else {
      swal(responseText.msg);
    }
}
function showRequest(formData, jqForm, options) {
    var check = '0';

    if ($('#excelfile').val() == '') {
        swal('Please select excel file first');
        //$('#excelfile').closest('.form-group').addClass('has-error');
        check = '1';
    } else {
        var validExts = new Array(".xlsx", ".xls", ".csv");
        var fileExt = $('#excelfile').val();
        fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
        if (validExts.indexOf(fileExt) < 0) {
        swal('Please choose only excel file');
            $('#excelfile').val('');
            $("label[for='excelfile']").children('span').text('');
            //$('#excelfile').closest('.form-group').addClass('has-error');
            check = '1';
        } else {
            //$('#excelfile').closest('.form-group').removeClass('has-error');
        }
    }
    if (check != '0') {

        $("#bodyLoad").removeClass('loader');
        $("#loader_overlay").hide();
        return false;
    }
    return true;
}




