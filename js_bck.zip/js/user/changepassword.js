$(document).ready(function(){ 
  $('#changepasswordForm').submit(function(){
      $(this).ajaxSubmit({
        beforeSubmit:  showRequest,
        success: showResponse,
        type: 'POST',
        dataType: 'json',
        data: {'device': 'web','csrf_token' : $.cookie("csrf_cookie")}
      });
      return false; 
  });
});
function showResponse(responseText, statusText, xhr, $form)  {
    if(parseInt(responseText.code)==0){
      swal(responseText.msg).then((value) => {
        window.location.href = pageMainUrl;
      });
    } else {
      swal(responseText.msg);
    }

}
function showRequest(formData, jqForm, options) { 
    var check='0';
    var strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
    var oldPassword=$('#oldPassword').val();
    var newPassword=$('#newPassword').val();
    var confirmPassword=$('#confirmPassword').val();
    if(oldPassword==''){
      $('#oldPassword').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#oldPassword').closest('.form-group').removeClass('has-error');
    }
    if(newPassword==''){
      $('#newPassword').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#newPassword').closest('.form-group').removeClass('has-error');
    }
    if(confirmPassword==''){
      $('#confirmPassword').closest('.form-group').addClass('has-error');
      check='1';
    } else {
      $('#confirmPassword').closest('.form-group').removeClass('has-error');
    }
    if(check=='0'){
      if(confirmPassword!=newPassword){
        check='1';
        $("#msgDiv").removeClass('alert-success');
        $("#msgDiv").addClass('alert-danger').show();
        $("#LoginMsg").text('New and confirm password must be same');
      } else if (parseInt(confirmPassword.length)<8) {
        check='1';
        $("#msgDiv").removeClass('alert-success');
        $("#msgDiv").addClass('alert-danger').show();
        $("#LoginMsg").text('Password length should atleast8 character');
      } else if (parseInt(confirmPassword.length)>16) {
        check='1';
        $("#msgDiv").removeClass('alert-success');
        $("#msgDiv").addClass('alert-danger').show();
        $("#LoginMsg").text('Password length should not exceed 16 character');
      } else if (!strongRegex.test(confirmPassword)) {
        check='1';
        $("#msgDiv").removeClass('alert-success');
        $("#msgDiv").addClass('alert-danger').show();
        $("#LoginMsg").text('Password should contain atleast one charcter,one capital letter, one number and one special character');
      } else if(oldPassword==confirmPassword){
        check='1';
        $("#msgDiv").removeClass('alert-success');
        $("#msgDiv").addClass('alert-danger').show();
        $("#LoginMsg").text('old and new passwords must be different');        
      }      
    }

    if(check!='0'){
      return false;
    } else {

    }
    
}