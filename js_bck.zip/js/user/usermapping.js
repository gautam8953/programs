$(document).ready(function () {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl + 'ApiUser/getstates',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (result.code=='0') {
                if (result.hasOwnProperty('data') && parseInt($('#search_state').length) > 0) {
                    $('#search_state').html('<option value="" >All State</option>');
                    $.each(result.data, function (key, val) {
                        $('#search_state').append($("<option></option>").attr("value", val.StateID).text(val.StateName));
                    });
                }
                $('#search_district').html('<option value="" >All District</option>');
                $('#facilityName').html('<option value="" >All Facility</option>');
                $('.selectpicker').selectpicker('refresh');
            }
        }
    });

});

function getuser(ths){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['search_role']=$('#search_role').val();
    $.ajax({
        url: pageMainUrl+'apiuser/getuser', 
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#search_user').html('<option value="">Select User</option>');
            if(parseInt(result.data.length)>0){
                $.each(result.data,function(key,val){
                    $('#search_user').append($("<option></option>").attr("value",val.UserID).text(val.FirstName).attr("data-subtext",val.UserName));
                });
            }
            $('#search_state,#search_district,#facilityName,#mapped_state,#mapped_district,#mapped_facility').val('');
            $('.selectpicker').selectpicker('refresh');
        }
    });
}
function change_state(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['search_state']=$('#search_state').val();
    $.ajax({
        url: pageMainUrl+'ApiUser/getdistricts',
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#search_district').html('<option value="">All District</option>');
            if(parseInt(result.data.length)>0){
                $.each(result.data,function(key,val){
                    $('#search_district').append($("<option></option>").attr("value",val.DistrictID).text(val.DistrictName).attr("data-subtext",val.StateName));
                });
            }
            $('#facilityName').html('<option value="">All Facility</option>');
            $('.selectpicker').selectpicker('refresh');
        }
    });
}
function change_district(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['search_state']=$('#search_state').val();
    params['search_district']=$('#search_district').val();
    $.ajax({
        url: pageMainUrl+'ApiUser/getfacilities',
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#facilityName').html('<option value="">All Facility</option>');
            if(parseInt(result.data.length)>0){
                $.each(result.data,function(key,val){
                    $('#facilityName').append($("<option></option>").attr("value",val.FacilityID).text(val.FacilityName).attr("data-subtext",val.hintText));
                });
            }
            $('.selectpicker').selectpicker('refresh');
        }
    });
}
function change_user(){
    var params={};
    params['device']='web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['search_user']=$('#search_user').val();
    $.ajax({
        url: pageMainUrl+'ApiUser/getUserMapping',
        data: params, 
        type: 'POST', 
        dataType: 'json', 
        success: function(result){
            $('#mappedFacility tbody').html('');
            if(parseInt(result.data.length)>0){
                $.each(result.data,function(key,val){
                    var trText='';
                    trText+='<tr><td>'+val.SN+'</td>';
                    trText+='<td>'+val.state+'</td>';
                    trText+='<td>'+val.district+'</td>';
                    trText+='<td>'+val.facility+'</td>';
                    trText+='<td>'+val.user+'</td>';
                    trText+='<td>'+val.role+'</td>';
                    trText+='<td>'+val.action+'</td></tr>';
                    $('#mappedFacility tbody').append(trText);
                });
            }            
        }
    });    
}
function removeRow(ths){
    if(parseInt($('#mappedFacility tbody tr').length)>1){
        $(ths).closest('tr').remove();
    } else {
        swal('can not remove all mapping');
    }
}
function add_row(){
    var len=parseInt($('#mappedFacility tbody tr').length)+1;
    var trText='';
    trText+='<tr><td>'+len+'</td>';
    trText+='<td>'+$('#search_state option:selected').text()+'</td>';
    trText+='<td>'+$('#search_district option:selected').text()+'</td>';
    trText+='<td>'+$('#facilityName option:selected').text()+'</td>';
    trText+='<td>'+$('#search_role option:selected').text()+'</td>';
    trText+='<td>'+$('#search_user option:selected').text()+'</td>';
    trText+='<td><button onclick="removeRow(this)" class="btn btn-danger btn-xs getAssesment getAssesment1 view" ><i class="fa fa-eye"></i>Remove</button></td></tr>';
    $('#mappedFacility tbody').append(trText);    
}