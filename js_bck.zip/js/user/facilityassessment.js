$(document).ready(function () {

    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 50,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [[5, 10, 20, 25], [5, 10, 15, 25]],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "ajax": {
            url: pageMainUrl + "ApiUser/getSearchFacilityAssessment",
            type: "post",
            data: function (d) {
                $("#bodyLoad").removeClass('loader');
                $("#loader_overlay").hide();
                d.search_district = $('#search_district').val();
                d.opt = $('#opt').val();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        }
    });

    $('#btn_search').click(function () {
        if ($('#search_district') && $('#search_district').val() != '') {
            datatableData.ajax.reload();
        } else {
            $("#bodyLoad").removeClass('loader');
            $("#loader_overlay").hide();
            swal('Please select District First');
        }
    });
    $("#reset_btn").click(function () {
        $('#search_state').val('0');
        $('#search_district').html('<option value="0">Select District</option>');
        datatableData.ajax.reload();
    });

    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    $.ajax({
        url: pageMainUrl + 'ApiUser/roleData',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            if (result.code=='0') {
                if(result.data.role=='Ministry'){

                } else if(result.data.role=='State'){

                } else if(result.data.role=='District'){
                    $('#search_state').closest('div').hide();
                } else {
                    window.location.href=pageMainUrl;
                }
                if (result.data.hasOwnProperty('District') && parseInt($('#search_district').length) > 0) {
                    $('#search_district').html('<option value="0">Select District</option>');
                    $.each(result.data.District, function (key, val) {
                        $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                    });
                    if ($('#search_district').length) {
                        if (parseInt($('#search_district option').length) == 2) {
                            $('#search_district').val($('#search_district option:eq(1)').val());
                            datatableData.ajax.reload();
                        }
                    }
                }
                if (result.data.hasOwnProperty('State') && parseInt($('#search_state').length) > 0) {
                    $('#search_state').html('<option value="0">Select State</option>');
                    $.each(result.data.State, function (key, val) {
                        $('#search_state').append($("<option></option>").attr("value", val.StateID).text(val.StateName));
                    });
                    if ($('#search_state').length) {
                        if (parseInt($('#search_state option').length) == 2) {
                            $('#search_state').val($('#search_state option:eq(1)').val());
                            change_state();
                        }
                    }
                }
            }
        }
    });

});

function change_state() {
    var params = {};
    params['device'] = 'web';
    params['csrf_token']=$.cookie("csrf_cookie");
    params['searchType'] = 'district';
    params['searchData'] = $('#search_state').val();
    $.ajax({
        url: pageMainUrl + 'ApiFacility/getSearchOptions',
        data: params,
        type: 'POST',
        dataType: 'json',
        success: function (result) {
            $('#search_district').html('<option value="0">Select District</option>');
            if (result.hasOwnProperty('data')) {
                $.each(result.data, function (key, val) {
                    $('#search_district').append($("<option></option>").attr("value", val.DistrictID).text(val.DistrictName));
                });
            }
            if (parseInt($('#search_district option').length) >= 2) {
                $('#search_district').val($('#search_district option:eq(1)').val());
                $('#btn_search').trigger('click');
            }
        }
    });
}

function facilities(ths){
        if($(ths).is(':checked')){
            var checkedFacility=$(ths).val();
            var varfacilityCheck=$('input[name="addedFacility[]"]').filter(function(){
                return $(this).val()==checkedFacility;
            });
            if(varfacilityCheck.length==0){
                $('#failitiesAssessment').append('<input type="hidden" value="'+checkedFacility+'" name="addedFacility[]">');
            }
        } else {
            var checkedFacility=$(ths).val();
            var varfacilityCheck=$('input[name="addedFacility[]"]').filter(function(){
                return $(this).val()==checkedFacility;
            }).remove();
        }
}

function map_user(mapType){
    var mappedFacilities=$('input[name="addedFacility[]"]').filter(function(){
                return $(this).val()!='';
            });
    if(mappedFacilities.length>0){
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['mapType'] = mapType;
        params['facilities'] = $('#failitiesAssessment').serializeArray();
        $.ajax({
            url: pageMainUrl + 'ApiUser/failitiesAssessment',
            data: params,
            type: 'POST',
            dataType: 'json',
            success: function (result) {
                swal(result.msg).then((value) => {
                    $('#failitiesAssessment').html('');
                    $('#btn_search').trigger('click');
                });
            }
        });        
    } else {
        swal('No facility selected');
        return false;
    }
}

function change_type(ths){
    if($(ths).val()=='3'){
        $('#btn_facility_map').prop('disabled',true);
        $('#btn_facility_remove').prop('disabled',false);
        $('#btn_search').trigger('click');
    } else {
        $('#btn_facility_map').prop('disabled',false);
        $('#btn_facility_remove').prop('disabled',true);
        $('#btn_search').trigger('click');
    }
}
