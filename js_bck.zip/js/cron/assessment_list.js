$(document).ready(function () {

    $("#bodyLoad").addClass('loader');
    $("#loader_overlay").show();
    var datatableData = $('#datatable').DataTable({
        "processing": false,
        "serverSide": true,
        "pageLength": 10,
        "retrieve": true,
        "searching": true,
        "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ],
        "language": {
            "emptyTable": "No data available"
        },
        "ordering": true,
        "order": [[ 0, "desc" ]],
        "ajax": {
            url: pageMainUrl + "cron/assessment_list_data",
            type: "post",
            data: function (d) {
                $("#bodyLoad").removeClass('loader');
                $("#loader_overlay").hide();
                d.csrf_token=$.cookie("csrf_cookie");
            }
        },
        drawCallback: function () {
        },
        "dom":"Blfrtip",
        buttons: [
                   {
                    extend: 'excel',
                    text: 'Export to Excel',
                    extension: '.xlsx',
                    exportOptions: {
                        columns: "thead th:not(.noExport)"
                       
                    },
                   
                  }
            ]
    });


});


