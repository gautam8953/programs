<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class ApiFacility extends CI_Controller {
	public function __construct()
	{
		parent :: __construct();
		$this->load->model('FacilityModel');
	}
	
	public function index(){
	}
	public function questionsAns()
	{
		$response=array();
		if($this->input->method(true) == 'POST'){
			$data = json_decode(file_get_contents("php://input"));
			$device=$this->input->post('device');			
			if(strtolower($device)=='web'){
				if(!$this->CommonModel->checkAPIWebUser()){
					$response['code']='11';
					$response['msg']='Not Logged In';
				} else {
					$SurveyType=encryptor($this->input->post('survey'),'decrypt');
					$ansId=encryptor($this->input->post('ansId'),'decrypt');
					$response=$this->FacilityModel->getQuestionsAnsCatAll($SurveyType,$ansId);
				}
			} else{

			}
		} else {
			$response['code']='1';
			$response['msg']='Bad Request Method';
		}
		echo json_encode($response);
		exit;
	}
	public function saveAns(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    if(!empty($data1['survey']) && !empty($data1['AnswerID']) && !empty($data1['status']) && !empty($data1['facilityUser'])){
                    	$this->session->set_userdata('facilityUser', trim($data1['facilityUser']));
						$ansId=$data1['AnswerID'];
						$dataAns['survey']=$data1['survey'];
						$dataAns['device']='app';
						$dataAns['status']=$data1['status'];
						$dataAns['answer']=array();
						$dataAns['answerCleared']=array();
						if(count($data1['answer'])>0){
							foreach ($data1['answer'] as $key => $value) {
								$rawData=explode('_', $key);
								if($rawData[2]==$value){
									$dataAns['answer'][$rawData[1]]=$value;
								} else {
									$dataAns['status']='draft';
								}						
						
								/*$keys=array_keys($value);								
								$rawData=explode('_', $keys[1]);
								if($rawData[2]==$value[$keys[1]]){
									$dataAns['answer'][$rawData[1]]=$value[$keys[1]];
								} else {
									$dataAns['status']='draft';
								}*/
							}
						}
						if(isset($data1['answerCleared']) && count($data1['answerCleared'])>0){
							foreach ($data1['answerCleared'] as $key => $value) {
								$dataAns['answerCleared'][$key]=$value;
							}
						}					
						$response=$this->FacilityModel->saveSurveyAns($dataAns,$ansId);
						//$dataCheckAns=$this->FacilityModel->checkSurveyAns($response['answer'],$dataAns['survey']);
						$response['status']=$dataAns['status'];
						$response['ansId']=$ansId;
                    } else {
	                    $response['code'] = '9';
	                    $response['msg'] = $this->config->item('errCodes')[9];
                    }
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
					$dataAns['survey']=$this->input->post('survey');
					$dataAns['device']=$this->input->post('device');
					$dataAns['status']=$this->input->post('status');
					$dataAns['answer']=array();
					$dataAns['answerCleared']=array();
					if(count($this->input->post('answer'))>0){
						foreach ($this->input->post('answer') as $key => $value) {
							$rawData=explode('_', $key);
							if($rawData[2]==$value){
								$dataAns['answer'][$rawData[1]]=$value;
							} else {
								$dataAns['status']='draft';
							}						
						}
					}
					$answerCleared=$this->input->post('answerCleared');
					if(!empty($answerCleared) && count($this->input->post('answerCleared'))>0){
						foreach ($this->input->post('answerCleared') as $key => $value) {
							$dataAns['answerCleared'][]=$value;
						}
					}
					$ansId=encryptor($this->input->post('ansId'),'decrypt');
					$response=$this->FacilityModel->saveSurveyAns($dataAns,$ansId);
					//$dataCheckAns=$this->FacilityModel->checkSurveyAns($response['answer'],$dataAns['survey']);
					$response['status']=$dataAns['status'];
					$response['ansId']=encryptor($ansId);				
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        echo json_encode($response);
        exit;
	}
	public function getSearchOptions(){
		//if ($this->CommonModel->checkAPIWebUser()) {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $RoleName=$data1['RoleName'];
					$searchType=$data1['searchType'];
					$searchData=$data1['searchData'];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey']=$this->session->userdata('APIKey'); 
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey']=$this->session->userdata('APIKey'); 
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $RoleName=$this->session->userdata('RoleName');
					$searchType=$this->input->post('searchType');
					$searchData=$this->input->post('searchData');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
		switch ($RoleName) {
			case 'District':
				if(!empty($searchType) && !empty($searchData)){
					if($searchType=='facility'){
						$facilityData=$this->FacilityModel->getFacilityFromDistrict($searchData);
						$response['code']='0';
						$response['data']=$facilityData;
						$response['msg']=count($facilityData).' Data get';
					} else {
						$response['code']='14';
						$response['msg']='No Proper Data Submitted';
					}
				} else {
					$response['code']='14';
					$response['msg']='No Proper Data Submitted';
				}
				break;
			case 'State':
				if(!empty($searchType) && !empty($searchData)){
					if($searchType=='district'){
						$districtData=$this->FacilityModel->getDistrictDataFromState($searchData);
						$response['code']='0';
						$response['data']=$districtData;
						$response['msg']=count($districtData).' Data get';
					} else if($searchType=='facility'){
						$facilityData=$this->FacilityModel->getFacilityFromDistrict($searchData);
						$response['code']='0';
						$response['data']=$facilityData;
						$response['msg']=count($facilityData).' Data get';
					} else {
						$response['code']='14';
						$response['msg']='No Proper Data Submitted';
					}
				} else {
					$response['code']='14';
					$response['msg']='No Proper Data Submitted';
				}
				break;
			case 'Ministry':
			case 'NHSRC':
				if(!empty($searchType) && !empty($searchData)){
					if($searchType=='district'){
						$districtData=$this->FacilityModel->getDistrictDataFromState($searchData);
						$response['code']='0';
						$response['data']=$districtData;
						$response['msg']=count($districtData).' Data get';
					} else if($searchType=='facility'){
						$facilityData=$this->FacilityModel->getFacilityFromDistrict($searchData);
						$response['code']='0';
						$response['data']=$facilityData;
						$response['msg']=count($facilityData).' Data get';
					} else {
						$response['code']='14';
						$response['msg']='No Proper Data Submitted';
					}
				} else {
					$response['code']='14';
					$response['msg']='No Proper Data Submitted';
				}
				break;
			case 'Assessors':
				if(!empty($searchType) && !empty($searchData)){
					if($searchType=='district'){
						$districtData=$this->FacilityModel->getDistrictDataFromState($searchData);
						$response['code']='0';
						$response['data']=$districtData;
						$response['msg']=count($districtData).' Data get';
					} else if($searchType=='facility'){
						$facilityData=$this->FacilityModel->getFacilityFromDistrict($searchData);
						$response['code']='0';
						$response['data']=$facilityData;
						$response['msg']=count($facilityData).' Data get';
					} else {
						$response['code']='14';
						$response['msg']='No Proper Data Submitted';
					}
				} else {
					$response['code']='14';
					$response['msg']='No Proper Data Submitted';
				}
				break;
			default:
				$response['code']='14';
				$response['msg']='No Proper Data Submitted';
				break;
		}		
		echo json_encode($response);
	//}
	}
	public function getSearchData(){
		if ($this->CommonModel->checkAPIWebUser()) {
		$searchData=$this->input->post();
		/*$searchData['cond']=array();		
        if(!empty($this->session->userdata('MappedState'))){
            $searchData['cond'][]=array('mappedField'=>'f.StateID','mappedData'=>$this->session->userdata('MappedState'));
        }
        if(!empty($this->session->userdata('MappedDistrict'))){
            $searchData['cond'][]=array('mappedField'=>'f.DistrictID','mappedData'=>$this->session->userdata('MappedDistrict'));
        }
        if(!empty($this->session->userdata('mappedFacilities'))){
            $searchData['cond'][]=array('mappedField'=>'f.FacilityID','mappedData'=>$this->session->userdata('mappedFacilities'));
        }*/
        if($this->session->userdata('RoleName')=='State'){
            $searchData['cond']=array('mappedField'=>'f.StateID','mappedData'=>$this->session->userdata('MappedState'));
        }
        if($this->session->userdata('RoleName')=='District'){
            $searchData['cond']=array('mappedField'=>'f.DistrictID','mappedData'=>$this->session->userdata('MappedDistrict'));
        }
        if($this->session->userdata('RoleName')=='Facility'){
            $searchData['cond']=array('mappedField'=>'um.UserID','mappedData'=>$this->session->userdata('UserID'));
        }
		$data=$this->FacilityModel->getSearchData($searchData);
		$json_data=array(
		    "draw"              =>  intval($data['draw']),
		    "recordsTotal"      =>  intval($data['totalData']),
		    "recordsFiltered"   =>  intval($data['totalFilter']),
		    "data"              =>  $data['data']
		);
		echo json_encode($json_data);
	} else {
		$json_data=array(
		    "draw"              =>  0,
		    "recordsTotal"      =>  0,
		    "recordsFiltered"   =>  0,
		    "data"              =>  array()
		);
		echo json_encode($json_data);		
	}
	}
	function checkFacilityAdd(){
        $response=array('code'=>'1','New Entry not allowed');
        if($this->input->method(true) == 'POST'){
            $data = apache_request_headers();
            $device=$this->input->post('device');           
            if(strtolower($device)=='web'){
                if(!$this->CommonModel->checkAPIWebUser()){
                    $response['code']='11';
                    $response['msg']='Not Logged In';
                } else {
                    // true do code here
                    $response=$this->FacilityModel->checkFacilityAdd($this->session->userdata('facilityUser'));
                }
            } else{
                $response['code'] = '5';
                $response['msg'] = $this->config->item('errCodes')[5];
                // do app code here
            }
        } else {
            $response['code']='1';
            $response['msg']='Bad Request Method';
        }
        echo json_encode($response);
        exit;

		/*if(TRUE){
			$response['code']='0';
		} else {
			$response['code']='1';
		}
		echo json_encode($response);*/
	}
	function assesmentData(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    if(!empty($data1['facilityUser'])){
	                    $response=$this->FacilityModel->getAssesmentData($data1['facilityUser']);
	                    if($this->session->userdata('RoleName')=='Facility'){
	                        $response['data']['facilityUser']=$data1['facilityUser'];
	                        //$response['data']['facilityName']=$response['data'][0]['FacilityName'];
	                    }
                    } else {
	                    $response['code'] = '9';
	                    $response['msg'] = $this->config->item('errCodes')[9];
				        echo json_encode($response);
				        exit;
                    }
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
			        echo json_encode($response);
			        exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
		        echo json_encode($response);
		        exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    //$data = $this->input->post();
                    $response=$this->FacilityModel->getAssesmentData($this->session->userdata('facilityUser'));
                    if($this->session->userdata('RoleName')=='Facility'){
                        $response['data']['facilityUser']=$this->session->userdata('facilityUser');
                        //$response['data']['facilityName']=$response['data'][0]['FacilityName'];
                    }
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        echo json_encode($response);
        exit;
	}
	function assesment()
	{
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					if(!empty($data1['facilityName']) && !empty($data1['SurveyID']) && !empty($data1['sequence'])  ){
						$this->session->set_userdata('facilityUser', trim($data1['facilityName']));
						$saveData=array();
						$saveData['AnswerID']=isset($data1['AnswerID'])?$data1['AnswerID']:'0';
						$saveData['UserID']=isset($data1['facilityName'])?$data1['facilityName']:'0';
						$saveData['device']='App';
						$saveData['AssessmentDate']=isset($data1['assessmentDate'])?convert_date_db($data1['assessmentDate']):'0000-00-00';
						$saveData['AssessorsName1']=isset($data1['assessorsName1'])?$data1['assessorsName1']:'';
						$saveData['AssessorsName2']=isset($data1['assessorsName2'])?$data1['assessorsName2']:'';
						$saveData['AssesseesName1']=isset($data1['assesseesName1'])?$data1['assesseesName1']:'';
						$saveData['AssesseesName2']=isset($data1['assesseesName2'])?$data1['assesseesName2']:'';
						$saveData['AssessmentType']=isset($data1['assessment'])?$data1['assessment']:'';
						$saveData['start_date']=isset($data1['submissionDate'])?convert_date_db($data1['submissionDate']):'0000-00-00';
						$saveData['sequence']=$data1['sequence'];
						$saveData['SurveyID']=$data1['SurveyID'];
						if($this->session->userdata('facilityUser')!=$this->session->userdata('UserID')){
							$saveData['ParentUserID']=$this->session->userdata('UserID');
						}
						$ansId=$this->FacilityModel->saveAssesmentData($saveData);
						if($ansId>0){
							$response['code']='0';
							$response['ansId']=$ansId;
							$response['msg']=$this->config->item('errCodes')[0];
						} else {
							$response['code']='11';
							$response['msg']=$this->config->item('errCodes')[11];
						}						
					} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];						
					}
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					$saveData=array();
					$saveData['AnswerID']=encryptor($this->input->post('ansId'),'decrypt');
					$saveData['UserID']=$this->input->post('facilityName');
					$saveData['device']='web';
					$saveData['AssessmentDate']=convert_date_db($this->input->post('assessmentDate'));
					$saveData['AssessorsName1']=$this->input->post('assessorsName1');
					$saveData['AssessorsName2']=$this->input->post('assessorsName2');
					$saveData['AssesseesName1']=$this->input->post('assesseesName1');
					$saveData['AssesseesName2']=$this->input->post('assesseesName2');
					$saveData['AssessmentType']=$this->input->post('assessment');
					$saveData['start_date']=convert_date_db($this->input->post('submissionDate'));
					$saveData['sequence']=$this->input->post('sequence');
					$saveData['SurveyID']=encryptor($this->input->post('SurveyID'),'decrypt');
					//$saveData['FacilityAvailable']=$this->input->post('facilityAvailable');
					if($this->session->userdata('facilityUser')!=$this->session->userdata('UserID')){
						$saveData['ParentUserID']=$this->session->userdata('UserID');
					}
					$ansId=$this->FacilityModel->saveAssesmentData($saveData);
					if($ansId>0){
						$response['code']='0';
						$response['ansId']=encryptor($ansId);
						$response['msg']=$this->config->item('errCodes')[0];
					} else {
						$response['code']='11';
						$response['msg']=$this->config->item('errCodes')[11];
					}					
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		echo json_encode($response);
		exit;
	}
	function facilityScore(){
		if ($this->CommonModel->checkAPIWebUser()) {
		$this->session->set_userdata('surveyScore', $this->input->post('ans'));
		if(TRUE){
			$response['code']='0';
		} else {
			$response['code']='1';
		}
		echo json_encode($response);
		}
	}	

  	public function score(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$ansId =$data1['AnswerID'];
					if($ansId>0){
						$response['data']=$this->FacilityModel->getFacilityScore($ansId);
						$response['clientScore']=$response['data'][0]['clientScore'];
						$response['code']='10';
						$response['msg']=$this->config->item('errCodes')[10];
					} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];
					}
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					//$data = $this->input->post();
					$ansId =encryptor($this->input->post('ansId'),'decrypt');
					if($ansId>0){
						$response['data']=$this->FacilityModel->getFacilityScore($ansId);
						
						//$response['clientScore']=$response['data'][0]['clientScore'];
						//$response['sequence']=$this->config->item('assesmentSequence')[$response['data'][0]['Sequence']];
						//$response['assessmentDate']=convert_date_show($response['data'][0]['AssessmentDate']);
						//$response['assessorsName1']=$response['data'][0]['AssessorsName1'];
						//$response['assessorsName2']=$response['data'][0]['AssessorsName2'];
						//$response['assesseesName1']=$response['data'][0]['AssesseesName1'];
						//$response['assesseesName2']=$response['data'][0]['AssesseesName2'];
						$response['code']='10';
						$response['msg']=$this->config->item('errCodes')[10];
					} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];
					}
					
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		echo json_encode($response);
		exit;
	}
	function savescore(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$data=array();
					$data['q1']=@$data1['q1'];
					$data['q2']=@$data1['q2'];
					$data['q3']=@$data1['q3'];
					$data['clientScore']=@$data1['clientScore'];
					$ansId =$data1['AnswerID'];
					if($ansId>0){
						$this->FacilityModel->savescore($ansId,$data);
						$response['code']='0';
						$response['msg']=$this->config->item('errCodes')[0];
					} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];
					}
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
					echo json_encode($response);
					exit;
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
				echo json_encode($response);
				exit;
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					$data=array();
					$data['q1']=$this->input->post('q1');
					$data['q2']=$this->input->post('q2');
					$data['q3']=$this->input->post('q3');
					$data['clientScore']=$this->input->post('clientScore');
					$ansId =encryptor($this->input->post('ansId'),'decrypt');
					if($ansId>0){
						$this->FacilityModel->savescore($ansId,$data);
						$response['code']='0';
						$response['msg']=$this->config->item('errCodes')[0];
					} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];
					}
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		echo json_encode($response);
		exit;
	}
	function scoreRemarks(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$ansId =$data1['AnswerID'];
					if($ansId>0){
						$response['data']=$this->FacilityModel->getscore($ansId);
						$response['code']='10';
						$response['msg']=$this->config->item('errCodes')[10];
					} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];
					}
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
					echo json_encode($response);
					exit;
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
				echo json_encode($response);
				exit;
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					//$data = $this->input->post();
					$ansId =encryptor($this->input->post('ansId'),'decrypt');
					if($ansId>0){
						$response['data']=$this->FacilityModel->getscore($ansId);
						$response['code']='10';
						$response['msg']=$this->config->item('errCodes')[10];
					} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];
					}
					
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		
		echo json_encode($response);
		exit;
	}
	function excelupload(){
		$response=array();
		$dataHeader = apache_request_headers();
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data=$this->CommonModel->getApiData();
					$response['data']=$data;
					$response['code']='0';
					$response['msg']=$this->config->item('errCodes')[0];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					if($this->session->userdata('RoleName')=='Facility'){
						$userId=$this->session->userdata('UserID');
					} else {
						if(!empty($this->input->post('search_facility')) && $this->input->post('search_facility')>0){
							$userId=$this->input->post('search_facility');
							$valid=true;
						} else {
							$valid=false;
						}
					}
					if(!empty($this->input->post('survey')) && $this->input->post('survey')>0){
						$survey=$this->input->post('survey');
						$valid=true;
					} else {
						$valid=false;
					}
					if(!empty($this->input->post('checklist_format')) ){
						$checklist_format=$this->input->post('checklist_format');
						$valid=true;
					} else {
						$valid=false;
					}
					if(!empty($this->input->post('surveyType')) && $this->input->post('surveyType')>0){
						$surveyType=$this->input->post('surveyType');
						$valid=true;
					} else {
						$valid=false;
					}
					if(!empty($this->input->post('assessmentDate'))){
						$assessmentDate=convert_date_db($this->input->post('assessmentDate'));
						$valid=true;
					} else {
						$valid=false;
					}
					if(!empty($this->input->post('assessorsName1'))){
						$assessorsName1=$this->input->post('assessorsName1');
						$valid=true;
					} else {
						$valid=false;
					}
					if(!empty($this->input->post('assesseesName1'))){
						$assesseesName1=$this->input->post('assesseesName1');
						$valid=true;
					} else {
						$valid=false;
					}
					if($surveyType=='1' || $surveyType=='3'){
						$entryCheck=$this->FacilityModel->checkEntry($surveyType,$survey,$userId);	
						//$entryCheck=true;
					} else {
						$entryCheck=true;
					}
					$AssessorsName2=$this->input->post('assessorsName2');
					$AssesseesName2=$this->input->post('assesseesName2');
					$AssessmentType=$this->input->post('assessment');
					$start_date=convert_date_db($this->input->post('submissionDate'));
					$quesTotal=$this->FacilityModel->quesTot($survey,$checklist_format);
					if($valid){
						if($entryCheck){  
							if($_FILES['excelfile']['size']>0 && $_FILES['excelfile']['error']==''){
								if($_FILES['excelfile']['size']<2000000){
								$ext = pathinfo($_FILES['excelfile']['name'], PATHINFO_EXTENSION);
								$ext=strtolower($ext);
								if(in_array($ext,$this->config->item('ExcelTypes')) ) {
								  $ExcelTypes=date('Y-m-d-H-i').preg_replace('/[^A-Za-z0-9\-]/', '', $_FILES['excelfile']['name']).'.'.$ext;
								  if(!is_file(FCPATH.'assets/uploads'.$ExcelTypes)){
								    if(move_uploaded_file($_FILES['excelfile']['tmp_name'],"assets/uploads/".$ExcelTypes)){
										$file = FCPATH.'assets/uploads/'.$ExcelTypes;
										$this->load->library('excel');
										$objPHPExcel = PHPExcel_IOFactory::load($file);
										$objPHPExcel->setActiveSheetIndex(0);
										$arr_data=$objPHPExcel->getActiveSheet()->toArray();
										$questionStart=0;
										$err=array();
										$errAns=array();
										$done=array();
										$q1=$q2=$q3=array();
										$q1Check=0;$q2Check=0;$q3Check=0;$ansEnd=0;
										if($userId!=$this->session->userdata('UserID')){
											$ParentUserID=$this->session->userdata('UserID');
										} else {
											$ParentUserID=0;
										}
										$columnCheck=array('A','B','C','D','E','F','G','H','I','J','TOTAL');
										$answer=array('UserID'=>$userId,'SurveyID'=>$survey,'Sequence'=>$surveyType,'device'=>'web','SurveyStatus'=>1,'ParentUserID'=>$ParentUserID,'CreatedOn'=>date('Y-m-d H:i:s'),'CreatedBy'=>$this->session->userdata('UserID'),'assessmentDate'=>$assessmentDate,'AssessorsName1'=>$assessorsName1,'AssesseesName1'=>$assesseesName1,'AssessorsName2'=>$AssessorsName2,'AssesseesName2'=>$AssesseesName2,'AssessmentType'=>$AssessmentType,'start_date'=>$start_date,'format'=>$checklist_format);
										$answerDet=array();
										$checkSubcategoryExist=0;
										$Q1='Nursing staff is skilled for operating radiant warmer';
										$Q2='Nursing staff is skilled for resuscitation';
										$Q3='Nursing staff is skilled identifying and managing complication';
										$Q4='Counsellor is skilled for postnatal counselling';
										$Q5='Nursing Staff is skilled for maintaining clinical records including partograph';
										$validAns=array('0','1','2');
										//echo "<pre>Main"; print_r($arr_data); echo "</pre>"; die('test');
										foreach ($arr_data as $key => $value) {
											if(count($value)<7){ continue; }
											//echo "<pre>Main"; print_r($value); echo "</pre>";
											if(isset($value[0]) || isset($value[1]) || isset($value[2])){ 
												if((strtolower(trim($value[0]))=='reference no' || strtolower(trim($value[0]))=='reference no.') && (strtolower(trim($value[1]))=='measurable element' || strtolower(trim($value[1]))=='me statement') && strtolower(trim($value[2]))=='checkpoint'){
													$questionStart=1;

												}
												//echo "<pre>Loop 0"; print_r($value); echo "</pre>";
												if ($value[0]!='' && $value[1]!='' && ($value[2]=='' && $value[4]=='' && $value[5]=='' && $value[6]=='' ) && preg_match('/Standard/i', $value[0])){
													$subCat=preg_replace('/[^A-Za-z0-9\- ,*=.&]/', '', trim($value[0])); 
													$checkSubcategoryExist=$this->FacilityModel->checkSubCatExist($survey,$subCat,$checklist_format);
												}

												if($questionStart==1 && !empty($answer['UserID']) ){
													if(isset($value[2]) && $value[2]!='' && isset($value[3]) && $value[3]!=='' && strtolower(trim($value[2]))!='checkpoint' && strtolower(trim($value[2]))!='maximum' && !in_array(trim(strtoupper($value[0])),$columnCheck) && $checkSubcategoryExist>0){
														if($checklist_format=='A'){
															if(preg_match('/Nursing staff is skilled  for operating radiant warmer/i', $value[2])){ continue; }
															if(preg_match('/Nursing staff is skilled  for resuscitation/i', $value[2])){ continue; }
															if(preg_match('/Nursing staff is skilled identifying and managing complication/i', $value[2])){ continue; }
															if(preg_match('/Counsellor is skilled for postnatal counselling/i', $value[2])){ continue; }
															if(preg_match('/Nursing Staff is skilled for maintaining clinical records including partograph/i', $value[2])){ continue; }
														} else {

														}
														$checkQuestionExist=$this->FacilityModel->checkQuestionExist($survey,$value[2],$checkSubcategoryExist,$checklist_format);
														//echo "<pre>IN".$checkSubcategoryExist.' '.$checkQuestionExist; print_r($value); echo "</pre>";
														if(in_array(trim($value[3]), $validAns)){
															if($checkQuestionExist>0){
																$answerDet[]=array(
																	'AnswerID'=>'0',
																	'QuestionID'=>$checkQuestionExist,
																	'Answer'=>trim($value[3]),
																	'IsActive'=>'1',
																	'CreatedOn'=>date('Y-m-d H:i:s'),
																	'CreatedBy'=>$this->session->userdata('UserID')
																);
																$done[]=$value;
															} else {
																$err[]=$value;
															}
														} else {
															$errAns[]=$value;
														}
													} else {
														//echo "<pre>"; print_r($value); echo "</pre>";
													}
												} else {
													// for header and assement data
													/*if(strtolower(trim($value[5]))=='date of assessment'){
														$answer['AssessmentDate']=date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP(trim($value[5])));
													}*/
													/*if(strtolower(trim($value[0]))=='names of assessors'){
														$answer['AssessorsName1']=trim($value[2]);
													}
													if(strtolower(trim($value[5]))=='names of assessees'){
														$answer['AssesseesName1']=trim($value[6]);
													}
													if(preg_match('/type of assessment/i', $value[0])){
														$answer['AssessmentType']=trim($value[2]);
													}
													if(strtolower(trim($value[5]))=='action plan submission date'){
														if($value[6]!=''){
															$answer['start_date']=date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP(trim($value[6])));
														}
														
													}*/
													if(!preg_match('/Major Gaps Observed/i', $value[1]) && !preg_match('/Good Practices/i', $value[1]) && !preg_match('/Opportunities for Improvement/i', $value[1])&& !preg_match('/Signature of Assessors/i', $value[1]) && !preg_match('/Date/i', $value[1])){
														if($q1Check && !empty($value[1]) && $q2Check==0 && $q3Check==0){
															$q1[]=trim($value[1]);
														}
														if($q2Check && !empty($value[1]) && $q1Check==0 && $q3Check==0){
															$q2[]=trim($value[1]);
														}
														if($q3Check && !empty($value[1])  && $q1Check==0 && $q2Check==0){
															$q3[]=trim($value[1]);
														}
													}
													if(preg_match('/Major Gaps Observed/i', $value[1])){
														$q1Check=1;$q2Check=0;$q3Check=0;
													}
													if(preg_match('/Good Practices/i', $value[1])){
														$q1Check=0;$q2Check=1;$q3Check=0;
													}
													if(preg_match('/Opportunities for Improvement/i', $value[1])){
														$q1Check=0;$q2Check=0;$q3Check=1;
													}
													if(preg_match('/date/i', $value[1])){ 
														$date=trim(preg_replace('/[^0-9\/-]/', '', trim($value[1])));
														$date=date('Y-m-d',strtotime($date));
														if($date=='1970-01-01'){
															$date=NULL;
														}
														$answer['end_date']=$date;
													}

												}									
											} else {
												$response['code']='12';
												$response['msg']='unable to read file';
											}
										}
										/*echo $quesTotal."<pre>"; 
										echo count($done).'_'; 
										echo count($errAns).'_'; 
										echo count($err).'_'; 
										echo count($answerDet);
										echo "</pre>";
										die('test');*/
										if(empty($arr_data)){
											$response['code']='12';
											$response['msg']='Unable to read excel. Please check file and its extension';
										} else if(!empty($err)){
											$response['code']='12';
											$response['msg']='Uploaded files all question not matched';
											$response['err']=$err;
										} else if(empty($answerDet)){
											$response['code']='13';
											$response['msg']='No compliance get of refrences';
										}else if(!empty($errAns)){
											$response['code']='15';
											$response['msg']='Invalid compliance provided';
											$response['err']=$errAns;
										}else if($survey=='1' && count($answerDet)!=$quesTotal){
											$response['code']='15';
											$response['msg']='All refrences not provided as per format';
										}else if($survey=='1' && count($answerDet)!=$quesTotal){
											$response['code']='15';
											$response['msg']='All refrences not provided as per format';
										} else {
											try {
												if($this->db->insert('answer', $answer)){
													$answer['AnswerID']=$this->db->insert_id();
													foreach ($answerDet as $key => $value) {
														$answerDet[$key]['AnswerID']=$answer['AnswerID'];
													}
													if($this->db->insert_batch('answerdetail', $answerDet)){
														foreach ($q1 as $key => $value1) {
															$saveData=array(
																'AnswerID'=>$answer['AnswerID'],
																'remarksType'=>'1',
																'remarks'=>$value1,
																'CreatedOn'=>date('Y-m-d H:i:s'),
																'CreatedBy'=>$this->session->userdata('UserID')
															);
															if($this->db->insert('answerremarks', $saveData)){
																$LoginHisID=$this->db->insert_id();
															} else {
																$this->db->insert('answerremarks', $saveData);
																$LoginHisID=$this->db->insert_id();
															}
														}
														foreach ($q2 as $key => $value1) {
															$saveData=array(
																'AnswerID'=>$answer['AnswerID'],
																'remarksType'=>'2',
																'remarks'=>$value1,
																'CreatedOn'=>date('Y-m-d H:i:s'),
																'CreatedBy'=>$this->session->userdata('UserID')
															);
															if($this->db->insert('answerremarks', $saveData)){
																$LoginHisID=$this->db->insert_id();
															} else {
																$this->db->insert('answerremarks', $saveData);
																$LoginHisID=$this->db->insert_id();
															}
															
														}
														foreach ($q3 as $key => $value1) {
															$saveData=array(
																'AnswerID'=>$answer['AnswerID'],
																'remarksType'=>'3',
																'remarks'=>$value1,
																'CreatedOn'=>date('Y-m-d H:i:s'),
																'CreatedBy'=>$this->session->userdata('UserID')
															);
															if($this->db->insert('answerremarks', $saveData)){
																$LoginHisID=$this->db->insert_id();
															} else {
																$this->db->insert('answerremarks', $saveData);
																$LoginHisID=$this->db->insert_id();
															}											
														}												
														$response['code']='0';
														$response['msg']='Data saved sucessfully';
														$response['err']=$err;
														$response['done']=$answerDet;
													} else {
														$this->db->delete('answerdetail', array('AnswerID' => $answer['AnswerID']));
														$response['code']='11';
														$response['msg']=$this->config->item('errCodes')[11];
													}
												} else {
													$response['code']='11';
													$response['msg']=$this->config->item('errCodes')[11];						
												}										
											}
											catch(Exception $e) {
												$response['code']='12';
												$response['msg']=$e->getMessage();
												$response['err']=$err;
											}
										}
							        	unlink($file);
										                	      
								    } else {
										$response['code']='13';
										$response['msg']='Error uploading file. Please uplaod again';	      
								    }
								  } else {
									$response['code']='13';
									$response['msg']='Please change file name before upload';
								  }
								} else {
									$response['code']='13';
									$response['msg']='Please upload only excel or csv files';
								}
							
								} else {
									$response['code']='13';
									$response['msg']='Invalid file uploaded';				
								}								
							} else{
								$response['code']='13';
								$response['msg']='File not uploaded, Please upload again';
							}
						} else {
							$response['code']='9';
							$response['msg']='Assesment data already filled.';
						}
					} else {
						$response['code']='9';
						$response['msg']=$this->config->item('errCodes')[9];
					}
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		echo json_encode($response);
		exit;
	}
	public function questionFormat_old()
	{
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
					if(!empty($data)){
						if(isset($data['survey'])){
							$survey=$data['survey'];
						} else {
							$survey=0;
						}
						if(isset($data['category'])){
							$category=$data['category'];
						} else {
							$category=0;
						}
						$response = $this->FacilityModel->surveyFormatApp($survey,$category);
					} else {
							$response['code']='13';
							$response['msg']='Empty data get';
					}
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    //$data = $this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        echo json_encode($response);
        exit;
	}
	public function questionFormat()
	{
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
					if(!empty($data)){
						if(isset($data['survey'])){
							$survey=$data['survey'];
						} else {
							$survey=0;
						}
						if(isset($data['category'])){
							$category=$data['category'];
						} else {
							$category=0;							
						}
						if(isset($data['subcategory'])){
							$subcategory=$data['subcategory'];
						} else {
							$subcategory=0;
						}
						if(isset($data['question'])){
							$question=$data['question'];
						} else {
							$question=0;
						}
						if(isset($data['format'])){
							$format=$data['format'];
						} else {
							$format='A';
						}
						$response = $this->FacilityModel->surveyFormatApp($survey,$category,$subcategory,$question,$format);
					} else {
							$response['code']='13';
							$response['msg']='Empty data get';
					}
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    //$data = $this->input->post();
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        echo json_encode($response);
        exit;
	}
	function setFacility(){
		if ($this->CommonModel->checkAPIWebUser()) {
		$this->session->set_userdata('facilityUser', $this->input->post('facilitySetId'));
		if(TRUE){
			$response['code']='0';
		} else {
			$response['code']='1';
		}
		echo json_encode($response);
		}
	}
	function assesmentDataView(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$ansId = $data1['AnswerID'];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					$ansId = encryptor($this->input->post('ansId'),'decrypt');
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		if($ansId>0){
			$response=$this->FacilityModel->assesmentDataView($ansId);
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}		
		echo json_encode($response);
		exit;
	}
	function lastAssesment(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data=$this->CommonModel->getApiData();
					$response['data']=$data;
					$response['code']='0';
					$response['msg']=$this->config->item('errCodes')[0];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					$data = $this->input->post();
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		if(!empty($data['facility'])){
			if(!isset($data['assesmentType']) || empty($data['assesmentType'])){
				$assesmentType='both';
			} else {
				$assesmentType=$data['assesmentType'];
			}
			if(!isset($data['sequence']) || empty($data['sequence'])){
				$sequence='0';
			} else {
				$sequence=$data['sequence'];
			}
			$response['data']=$this->FacilityModel->lastAssesment($data['facility'],$assesmentType,$sequence);
			$response['code']='0';
			$response['msg']='';
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}
		echo json_encode($response);
		exit;		
	}

	function assementdataCheck(){
		$response=array();
		$data=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$data['SurveyID']=$data1['SurveyID'];
					$data['facilityUser']=$data1['facilityUser'];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					$data['SurveyID'] = encryptor($this->input->post('SurveyID'),'decrypt');
					$data['facilityUser']=$this->session->userdata('facilityUser');
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		if(!empty($data['SurveyID']) && !empty($data['facilityUser'])){
			$response=$this->FacilityModel->checkEntryLast($data['SurveyID'],$data['facilityUser']);
			$response['basecheck']=$this->FacilityModel->checkBaselineEntry($data['SurveyID'],$data['facilityUser']);
			$response['endcheck']=$this->FacilityModel->checkEndlineEntry($data['facilityUser']);
		}
		echo json_encode($response);
		exit;		
	}
	function answerview(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$ansId = $data1['AnswerID'];
					$catgory = $data1['Catgory'];
					$subcatgory = $data1['Subcatgory'];
					$QuestionID = $data1['QuestionID'];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
					echo json_encode($response);
					exit;
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
				echo json_encode($response);
				exit;
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest	
					redirect('/');
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		if($ansId>0){
			$response=$this->FacilityModel->answerview($ansId,$catgory,$subcatgory,$QuestionID);
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}		
		echo json_encode($response);
		exit;
	}
	function validate_assesment(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$userID = $data1['userID'];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
					echo json_encode($response);
					exit;
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
				echo json_encode($response);
				exit;
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest	
					$userID=$this->session->userdata('userID');
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		/*if($userID>0){
			$RoleName=$this->FacilityModel->answerview($ansId,$catgory,$subcatgory,$QuestionID);
			$response=$this->FacilityModel->answerview($ansId,$catgory,$subcatgory,$QuestionID);
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}*/		
		echo json_encode($response);
		exit;

	}
	function checklistsave(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $data['question']=$data1['question'];
                    $data['ans']=@$data1['ans'];
                    $data['type']=$data1['type'];
                    $ansId=$data1['AnswerID'];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data = $this->input->post();
					$ansId=encryptor($this->input->post('ansId'),'decrypt');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if($data['question']>0 && $ansId>0 ){
			if($data['type']=='save' && in_array($data['ans'], array('0','1','2'))){
				$response=$this->FacilityModel->checklistsave($ansId,$data['type'],$data['question'],$data['ans']);		
			} else {
				$response=$this->FacilityModel->checklistsave($ansId,$data['type'],$data['question'],'');	
			}
        	
        } else {
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        }
        echo json_encode($response);
        exit;
	}
	function asessmentDataApp(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $data['facility'] = $data1['facilityUser'];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey']=$this->session->userdata('APIKey'); 
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey']=$this->session->userdata('APIKey'); 
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data['facility'] = $data1['facilityUser'];
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if($data['facility']>0){
        	$response=$this->FacilityModel->asessmentDataApp($data['facility']);	
        } else {
                $response['code'] = '9';
                $response['msg'] = $this->config->item('errCodes')[9];        	
        }
        
        if(isset($dataHeader['device']) && $dataHeader['device']=='app'){
            $response['APIKey']=$this->session->userdata('APIKey');            
        }
        echo json_encode($response);
        exit;		
	}
	function monthlyDataApp(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    $data['facility'] = $data1['facilityUser'];
                    $data['month'] = $data1['month'];
                    $data['year'] = $data1['year'];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey']=$this->session->userdata('APIKey'); 
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey']=$this->session->userdata('APIKey'); 
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data['facility'] = $data1['facilityUser'];
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if($data['facility']>0){
        	$response=$this->FacilityModel->monthlyDataApp($data['facility'],$data);	
        } else {
                $response['code'] = '9';
                $response['msg'] = $this->config->item('errCodes')[9];        	
        }
        
        if(isset($dataHeader['device']) && $dataHeader['device']=='app'){
            $response['APIKey']=$this->session->userdata('APIKey');            
        }
        echo json_encode($response);
        exit;		
	}
	function assesmentDataEdit(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					$ansId = $data1['AnswerID'];
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest
					$ansId = encryptor($this->input->post('ansId'),'decrypt');
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		if($ansId>0){
			$response=$this->FacilityModel->assesmentDataEdit($ansId);
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}		
		echo json_encode($response);
		exit;
	}
    public function osce() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $userID=$this->session->userdata('UserID');
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey']=$this->session->userdata('APIKey'); 
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey']=$this->session->userdata('APIKey'); 
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data = $this->input->post();
                    $userID=$this->session->userdata('UserID');                    
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        $RoleName=$this->session->userdata('RoleName');
        if(empty($data['participant']) || $data['score1']=='' || $data['score2']=='' || $data['score3']=='' || $data['score4']=='' || $data['dakshata']=='' || $data['daksh']=='' || $data['others']=='' || $RoleName!='Facility'){
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        } else {
			$osce=array(
				'UserID'=>$userID,
				'participant'=>$data['participant'],
				'designation'=>$data['designation'],
				'dakshata'=>$data['dakshata'],
				'daksh'=>$data['daksh'],
				'others'=>$data['others'],
				'remarks'=>$data['remarks'],
				'score1'=>$data['score1'],
				'score2'=>$data['score2'],
				'score3'=>$data['score3'],
				'score4'=>$data['score4'],
				'CreatedOn'=>date('Y-m-d H:i:s'),
				'CreatedBy'=>$this->session->userdata('UserID'),
			);
			if(isset($data['OsceID']) && encryptor($data['OsceID'],'decrypt')>0){
				$osceID=encryptor($data['OsceID'],'decrypt');
			} else{
				$osceID='0';
			}
        	$response=$this->FacilityModel->saveOsce($userID,$osce,$osceID);
        }
        if(isset($dataHeader['device']) && $dataHeader['device']=='app'){
            $response['APIKey']=$this->session->userdata('APIKey');            
        }
        echo json_encode($response);
        exit;
    }
    public function oscedata() {
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data = $this->CommonModel->getApiData();
                    $userID=$this->session->userdata('UserID');
                    $response['data'] = $data;
                    $response['code'] = '0';
                    $response['msg'] = $this->config->item('errCodes')[0];
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                    $response['APIKey']=$this->session->userdata('APIKey'); 
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
                $response['APIKey']=$this->session->userdata('APIKey'); 
                echo json_encode($response);
                exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $userID=$this->session->userdata('UserID');
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        if(empty($userID)){
            $response['code'] = '9';
            $response['msg'] = $this->config->item('errCodes')[9];
        } else {
        	$response=$this->FacilityModel->oscedata($userID);
        }
        if(isset($dataHeader['device']) && $dataHeader['device']=='app'){
            $response['APIKey']=$this->session->userdata('APIKey');            
        }
        echo json_encode($response);
        exit;
    }

	public function saveClientScore(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    $data1 = $this->CommonModel->getApiData();
                    if(!empty($data1['clientScore']) && !empty(encryptor($data1['assessmentID'],'decrypt')) ){
						$ansId=encryptor($data1['assessmentID'],'decrypt');
						$dataAns['clientScore']=$data1['clientScore'];
						$response=$this->FacilityModel->saveClientScore($dataAns,$ansId);
                    } else {
	                    $response['code'] = '9';
	                    $response['msg'] = $this->config->item('errCodes')[9];
                    }
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    if(!empty($this->input->post('clientScore')) && !empty(encryptor($this->input->post('assessmentID'),'decrypt')) ){
						$ansId=encryptor($this->input->post('assessmentID'),'decrypt');
						$dataAns['clientScore']=$this->input->post('clientScore');
						$response=$this->FacilityModel->saveClientScore($dataAns,$ansId);
                    } else {
	                    $response['code'] = '9';
	                    $response['msg'] = $this->config->item('errCodes')[9];
                    }
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        echo json_encode($response);
        exit;
	}
	function answerviewApp(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					if(isset($data1['AnswerID'])){
						$ansId = $data1['AnswerID'];
					} else {
						$ansId = '0';						
					}
					if(isset($data1['Catgory'])){
						$catgory = $data1['Catgory'];
					} else {
						$catgory = '0';						
					}
					if(isset($data1['Subcatgory'])){
						$subcatgory = $data1['Subcatgory'];
					} else {
						$subcatgory = '0';						
					}
					if(isset($data1['QuestionID'])){
						$QuestionID = $data1['QuestionID'];
					} else {
						$QuestionID = '0';						
					}
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
					echo json_encode($response);
					exit;
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
				echo json_encode($response);
				exit;
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest	
					redirect('/');
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		if($ansId>0){
			$response=$this->FacilityModel->answerview($ansId,$catgory,$subcatgory,$QuestionID);
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}		
		echo json_encode($response);
		exit;
	}
	function answerviewApp_old(){
		$response=array();
		$dataHeader = apache_request_headers();
		$dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
		if(isset($dataHeader['device']) || isset($dataHeader['token'])){
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAppRequest($dataHeader)){
					// get data and process api requrest
					$data1=$this->CommonModel->getApiData();
					if(isset($data1['AnswerID'])){
						$ansId = $data1['AnswerID'];
					} else {
						$ansId = '0';						
					}
					if(isset($data1['Catgory'])){
						$catgory = $data1['Catgory'];
					} else {
						$catgory = '0';						
					}
					if(isset($data1['Subcatgory'])){
						$subcatgory = $data1['Subcatgory'];
					} else {
						$subcatgory = '0';						
					}
					if(isset($data1['QuestionID'])){
						$QuestionID = $data1['QuestionID'];
					} else {
						$QuestionID = '0';						
					}
				} else {
					$response['code']='5';
					$response['msg']=$this->config->item('errCodes')[5];
					echo json_encode($response);
					exit;
				}				
			} else {
				$response['code']='8';
				$response['msg']=$this->config->item('errCodes')[8];
				echo json_encode($response);
				exit;
			}
		} else {
			if($this->input->method(true) == 'POST'){
				if($this->CommonModel->checkAPIWebUser()){
					// get data and process web requrest	
					redirect('/');
				} else {
					redirect('/');
				}
			} else {
				redirect('/');
			}
		}
		if($ansId>0){
			$response=$this->FacilityModel->answerview($ansId,$catgory,$subcatgory,$QuestionID);
		} else {
			$response['code']='9';
			$response['msg']=$this->config->item('errCodes')[9];
		}		
		echo json_encode($response);
		exit;
	}
	function getgapdata(){
		$json_data=array(
		    "draw"              =>  0,
		    "recordsTotal"      =>  0,
		    "recordsFiltered"   =>  0,
		    "data"              =>  array()
		);
		if ($this->CommonModel->checkAPIWebUser()) {
			$search_answer=encryptor($this->input->post('search_answer'),'decrypt');
			$search_format=strtoupper(encryptor($this->input->post('search_format'),'decrypt'));
			if(!empty($search_answer) && in_array($search_format, array('A','B')) ){
				$searchData=$this->input->post();
				$data=$this->FacilityModel->getgapdata($searchData);
				$json_data=array(
				    "draw"              =>  intval($data['draw']),
				    "recordsTotal"      =>  intval($data['totalData']),
				    "recordsFiltered"   =>  intval($data['totalFilter']),
				    "data"              =>  $data['data']
				);
			}

		} else {
					
		}
		echo json_encode($json_data);
		exit;
	}
	function getDataCategory(){
        $response = array();
        $dataHeader = apache_request_headers();
        $dataHeader = array_change_key_case($dataHeader, CASE_LOWER);
        if (isset($dataHeader['device']) || isset($dataHeader['token'])) {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAppRequest($dataHeader)) {
                    // get data and process api requrest
                    
                } else {
                    $response['code'] = '5';
                    $response['msg'] = $this->config->item('errCodes')[5];
			        echo json_encode($response);
			        exit;
                }
            } else {
                $response['code'] = '8';
                $response['msg'] = $this->config->item('errCodes')[8];
		        echo json_encode($response);
		        exit;
            }
        } else {
            if ($this->input->method(true) == 'POST') {
                if ($this->CommonModel->checkAPIWebUser()) {
                    // get data and process web requrest
                    $data = $this->input->post();
                    $surveyIds='';
                    if(!empty($this->input->post('search_survey'))){
                    	$surveyIds=$this->input->post('search_survey');                    	
                    }
                    $response=$this->FacilityModel->getCategory($surveyIds);
                } else {
                    redirect('/');
                }
            } else {
                redirect('/');
            }
        }
        echo json_encode($response);
        exit;
	}

		
}