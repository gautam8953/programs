<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Anexture extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $userID=$this->session->userdata('UserID');
        $RoleName=$this->session->userdata('RoleName');
        if(empty($userID)){ 
            redirect('user/login');
        } else {
            $this->load->model('FacilityModel');
            $this->load->model('AnextureModel');
        }
    }

  	public function index(){
      $this->CommonModel->checkPageAccessWeb('facility/index',$this->session->userdata('RoleName'));
      $data=array();
      $data['search_options']=$this->FacilityModel->searchOptions();    
      $this->load->view('header');
      $this->load->view('anexture/index',$data);
      $this->load->view('footer');
  	}
    public function add($anextureID=''){
      $data=array();
      if(!empty($anextureID)){
        $data['anextureID']=encryptor($anextureID,'decrypt');
        if(empty($data['anextureID']) || $data['anextureID']<=0){
          redirect('anexture/index');
        }
        if(!$this->CommonModel->checkPageActionWeb('monthly/index','access_edit',$this->session->userdata('RoleName'))){
          //redirect('/');
        }
      } else {
        // add page validate
        if(!$this->CommonModel->checkPageActionWeb('monthly/index','access_add',$this->session->userdata('RoleName'))){
          //redirect('/');
        }
      }
      $data['search_options']=$this->FacilityModel->getSearchOptions();
      $this->load->view('header');
      $this->load->view('anexture/add',$data);
      $this->load->view('footer');
  }
    public function view($anextureID=''){
      $data=array();
      if(!empty($anextureID)){
        $data['anextureID']=encryptor($anextureID,'decrypt');
        if(empty($data['anextureID']) || $data['anextureID']<=0){
          redirect('anexture/index');
        }
        if(!$this->CommonModel->checkPageActionWeb('monthly/index','access_edit',$this->session->userdata('RoleName'))){
          //redirect('/');
        }
      } else {
        // add page validate
        if(!$this->CommonModel->checkPageActionWeb('monthly/index','access_add',$this->session->userdata('RoleName'))){
          //redirect('/');
        }
      }
      $this->load->view('header');
      $this->load->view('anexture/view',$data);
      $this->load->view('footer');
  }

}