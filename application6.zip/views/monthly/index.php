<div class="page-title">
    <div class="title_left">
        <h3>Monthly Format</h3>
    </div>
 
</div>



<div class="main-content"> 
    <div class="container">

<div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Manage Monthly Format</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <h4>Search Monthly Report</h4>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12">
            <?php 
            $attr = array("class" => "form-horizontal", "role" => "form", "id" => "form1", "name" => "form1");
            echo form_open("monthly/data", $attr);
            ?>                
                <div class="row">                    
                <?php if(isset($search_options['State']) ){ ?>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <select id="search_state" name="search_state" onchange="change_state()" class="form-control mb10">
                        <option value="">Select State</option>
                        <?php foreach ($search_options['State'] as $key => $value) {  ?>
                        <option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
                        <?php } ?>
                    </select>                    
                </div>
                <?php } ?>
                <?php if(isset($search_options['District']) ){ ?>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <select id="search_district" name="search_district" onchange="change_district()" class="form-control mb10">
                        <option value="">Select District</option>
                        <?php foreach ($search_options['District'] as $key => $value) { ?>
                        <option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
                        <?php } ?>
                    </select>                    
                </div>
                <?php } ?>
                <?php if(isset($search_options['Facility']) ){ ?>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <select id="search_facility" name="search_facility" class="form-control mb10" onchange="change_facility()" >
                        <option value="">Select Facility</option>
                        <?php  foreach ($search_options['Facility'] as $key => $value) {  ?>
                        <option value="<?php echo $value['UserID']; ?>" ><?php echo $value['FacilityName']; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <?php } ?>
                <div class="col-md-3 col-sm-4 col-xs-12">
                        <select id="search_months" name="search_months" class="selectpicker mb10 " data-live-search="true" data-width="100%">
                            <option value=""> Select Month</option>
                            <?php foreach ($this->config->item('months') as $key => $value) { ?>
                            <option value="<?php echo $key; ?>" <?php //if($key==date('m')){ echo 'selected="selected"'; } ?> ><?php echo $value; ?></option>
                            <?php } ?>
                        </select>
                </div>
           
            
                <div class="col-md-3 col-sm-4 col-xs-12">
                        <select id="search_years" name="search_years" class="selectpicker mb10 " data-live-search="true" data-width="100%">
                            <option value=""> Select Year</option>
                            <?php foreach ($this->config->item('years') as $key => $value) { ?>
                            <option value="<?php echo $key; ?>" <?php //if($key==date('Y')){ echo 'selected="selected"'; } ?> ><?php echo $value; ?></option>
                            <?php } ?>
                        </select>
                </div>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <input id="btn_search" name="btn_search" type="button" class="btn btn-danger mb10" value="Search" style="display: none;" />
                    <a href="javascript:void(0)" class="btn btn-primary mb10" id="reset_btn">Reset</a>
                </div>
            </div>
            <?php echo form_close(); ?>
            
                <div class="clear"></div>
                <hr>
                <!-- <button style="margin: -40px 10px;" class="btn btn-success pull-right" onclick="showAddModel()" >Add</button> -->
                <!-- <a href="<?php //echo base_url(). "monthly/add"; ?>" id="addBtn" class="btn btn-success disabled pull-right">Add</a> -->
            </div>

        <table id="datatable" class="table table-striped table-bordered" width="100%">
                        <thead>
                        <tr>
                            <th>SN.</th>
                            <th>State</th>
                            <th>District</th>
                            <th>Facility</th>
                            <th>Month</th>
                            <th>Collection Date</th>
                            <th>Status</th>
                            <th>Created Date</th>
                            <th width="70px">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
    </div>
</div>
</div>
</div>
        
        </div>
    </div>

                    
                



<div class="modal fade" id="addModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Select Month Of Report</h4>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Month </label>
                        <select id="reportMonths" name="reportMonths" class="selectpicker  " data-live-search="true" data-width="100%">
                            <option value=""> Select Month</option>
                            <?php foreach ($this->config->item('months') as $key => $value) { ?>
                            <option value="<?php echo $key; ?>" <?php //if($key==date('m')){ echo 'selected="selected"'; } ?> ><?php echo $value; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Year </label>
                        <select id="reportYears" name="reportYears" class="selectpicker  " data-live-search="true" data-width="100%">
                            <option value=""> Select Year</option>
                            <?php foreach ($this->config->item('years') as $key => $value) { ?>
                            <option value="<?php echo $key; ?>" <?php //if($key==date('Y')){ echo 'selected="selected"'; } ?> ><?php echo $value; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                        <button id="searchBtn" class="btn btn-success" style="" onclick="checkData()" >Search</button>
                </div>
                <div class="col-md-5" ></div>
                <div class="col-md-2" id="resultDiv"></div>
                <div class="col-md-5" ></div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
</div>
  
