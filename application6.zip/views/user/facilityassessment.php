<style>
	.x_content .col-md-3{margin-bottom: 20px;}
</style>


<div class="page-title">
  <div class="title_left">
    <h3>Users</h3>
  </div>
</div>
<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">
	    <div class="row">
	        <div class="col-md-12 well">
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_state" name="search_state" onchange="change_state()" class="form-control">
						<option value="0">Select State</option>
					</select>                    
                </div>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="search_district" name="search_district" onchange="change_type($('#opt'))" class="form-control">
						<option value="0">Select District</option>
					</select>                    
                </div>
                <div class="col-md-3 col-xs-12 mar-top-20">
                	<select id="opt" name="opt" onchange="change_type(this)" class="form-control">
						<option value="3">Endline Facility</option>
						<option value="1">Other Facility</option>
					</select>                    
                </div>
                <div class="col-md-3 col-xs-12 mar-top-20">
                    <input style="display: none;" id="btn_search" name="btn_search" type="button" class="btn btn-danger" value="Search" />
                    <a href="javascript:void(0)" id="reset_btn" class="btn btn-primary">Reset</a>
                    <?php if($this->CommonModel->checkPageActionWeb('user/facilityassessment','access_edit',$this->session->userdata('RoleName'))){ ?>
                    <input id="btn_facility_map" name="btn_facility_map" type="button" class="btn btn-primary" value="Map Facility to Endline" onclick="map_user('3')" disabled="disabled" />
                	<?php } ?>
                </div>
                <?php if($this->CommonModel->checkPageActionWeb('user/facilityassessment','access_edit',$this->session->userdata('RoleName'))){ ?>
                <div class="col-md-3 col-xs-12 mar-top-20">
                    <input id="btn_facility_remove" name="btn_facility_remove" type="button" class="btn btn-primary" value="Remove Facility From Endline" onclick="map_user('1')" />
                </div>
            	<?php } ?>
	        </div>
	    </div>
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Facility Assessment</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">			      
			      <table id="datatable" class="table table-striped table-bordered">
			        	<thead>
			            <tr>
			                <th>SN.</th>
			                <th>State</th>
			                <th>District</th>
			                <th>Facility</th>
			                <th>Is Endline</th>
			            </tr>
			        	</thead>
			            <tbody>
			            	<tr>
			            		<td></td>
			                	<td></td>
			                	<td></td>
			                	<td></td>
			            	</tr>
			            </tbody>
			      </table>
			    </div>
			  </div>
			</div>
			<form name="failitiesAssessment" id="failitiesAssessment" class="login-form" action="<?php echo base_url() . "ApiUser/failitiesAssessment" ?>" method="post" style="display: none;">
				
			</form>
		</div>        
    </div>
</div>