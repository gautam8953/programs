<?php ob_start();
$pertot=array('a'=>'0','b'=>'0','c'=>'0','d'=>'0');
 //echo "<pre>"; print_r($data['state_static_data']); echo "</pre>"; 
 //die ?>
<div class="page-title">
  <div class="title_left">
    <h3>Dashboard</h3>
  </div>

  
</div>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<div class="clearfix"></div>

<div class="main-content"> 
   



<div class="analytics-sparkle-area">
            <div class="container">

                <!-- -------------- New Dashboard Sec 1------------------------>
                    <div class="row">
    <div class="col-md-4 col-sm-12">
        <div class="analytics-sparkle-line analytics-sparkle-line-frt reso-mg-b-30">
            <div class="analytics-content top-board1">
                <div class="board-icons-1 ">
                    <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/total-hospital.png" alt="total hostpital"></div>
                </div>
                <div class="board-deatils">
                    <h5>Total LaQshya Facilities</h5>
                    <a href="<?php echo base_url(). "user/laqshyafacility "; ?>">
                        <?php 
                        //$totalLaQshya=isset($data['totalLaQshya'])?$data['totalLaQshya']:'0'; 
                        $totalLaQshya=isset($data['state_static_data']['total'])?$data['state_static_data']['total']:'0'; 

                        ?>
                            <h2><span class="counter count"><?php echo $totalLaQshya; ?></span></h2> </a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-8 col-sm-12">
    	<div class="row">
        <div class="list-dashboard-icon1">
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/medical-collage.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils">
                            <h5>Medical Colleges</h5>
                            <a href="<?php echo base_url(). "user/laqshyafacility/Medical_College "; ?>">
                                <?php 
                                $totalMedFacility=isset($data['totalMedFacility'])?$data['totalMedFacility']:'0';
                                $totalMedFacility=isset($data['state_static_data']['medical'])?$data['state_static_data']['medical']:'0'; 
                                $per=0; 
                                $per=round(($totalMedFacility/$totalLaQshya)*100,2); ?>
                                    <h2><span class="counter count"><?php echo $totalMedFacility; ?></span></h2> </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/district-hospital.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils">
                            <h5>District Hospitals</h5>
                            <a href="<?php echo base_url(). "user/laqshyafacility/District_Hospital "; ?>">
                                <?php 
                                //$totalDisFacility=isset($data['totalDisFacility'])?$data['totalDisFacility']:'0';
                                $totalDisFacility=isset($data['state_static_data']['dh'])?$data['state_static_data']['dh']:'0';
                                $per=0; 
                                $per=round(($totalDisFacility/$totalLaQshya)*100,2); ?>
                                    <h2><span class="counter count"><?php echo $totalDisFacility ?></span></h2> </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/local-total-hospital.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils">
                            <h5>Sub-divisional Hospitals</h5>
                            <a href="<?php echo base_url(). "user/laqshyafacility/Sub-divisional_Hospital "; ?>">
                                <?php 
                                //$totalSubDivFacility=isset($data['totalSubDivFacility'])?$data['totalSubDivFacility']:'0'; 
                                $totalSubDivFacility=isset($data['state_static_data']['sdh'])?$data['state_static_data']['sdh']:'0';
                                $per=0; 
                                $per=round(($totalSubDivFacility/$totalLaQshya)*100,2); 
                                ?>
                                    <h2><span class="counter count"><?php echo $totalSubDivFacility ?></span></h2> </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/CHCs-icon.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils">
                            <h5>CHCs</h5>
                            <a href="<?php echo base_url(). "user/laqshyafacility/CHC "; ?>">
                                <?php 
                                //$totalCHC=isset($data['totalCHC'])?$data['totalCHC']:'0'; 
                                $totalCHC=isset($data['state_static_data']['chc'])?$data['state_static_data']['chc']:'0';
                                $per=0; 
                                $per=round(($totalCHC/$totalLaQshya)*100,2); ?>
                                    <h2><span class="counter count"><?php echo $totalCHC ?></span></h2> </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/medical-report-total.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils"> <a href="<?php echo base_url(). "user/laqshyafacility/FRU "; ?>"><h5>FRUs</h5> 
                            <?php 
                            //$totalFRU=isset($data['totalFRU'])?$data['totalFRU']:'0'; 
                            $totalFRU=isset($data['state_static_data']['fru'])?$data['state_static_data']['fru']:'0';
                            $per=0; 
                            $per=round(($totalFRU/$totalLaQshya)*100,2); ?><h2><span class="counter count"><?php echo $totalFRU; ?></span></h2> </a></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content top-board1">
                        <div class="board-icons-1 ">
                            <div class="rouw-img"> <img src="<?php echo base_url()?>/assets/images/total-heart.png" alt="total hostpital"></div>
                        </div>
                        <div class="board-deatils"> <a href="<?php echo base_url(). "user/laqshyafacility/Others"; ?>"><h5>Others</h5> 
                            <?php 
                            //$totalOtherFacility=isset($data['totalOtherFacility'])?$data['totalOtherFacility']:'0'; 
                            $totalOtherFacility=isset($data['state_static_data']['extra'])?$data['state_static_data']['extra']:'0';
                            $per=0; 
                            $per=round(($totalOtherFacility/$totalLaQshya)*100,2); ?><h2><span class="counter count"><?php echo $totalOtherFacility ?></span></h2> </a></div>
                    </div>
                </div>
            </div>
        </div>
         </div>

                <!-- -------------- New Dashboard Sec 1 ended ------------------------>



                <!-- -------------- New Dashboard Sec 2------------------------>


                <!-- -------------- New Dashboard Sec 2 ended ------------------------>





                <!---  
                <div class="row">
                	<div class="col-md-4 col-sm-12">
                		 
	                        <div class="analytics-sparkle-line analytics-sparkle-line-frt reso-mg-b-30">
	                            <div class="analytics-content">	
	                            	<h5>Total LaQshya Facilities</h5>
	                            	<a href="<?php echo base_url(). "user/laqshyafacility"; ?>">
	                            	<?php $totalLaQshya=isset($data['totalLaQshya'])?$data['totalLaQshya']:'0'; ?>
	                                
	                                <h2><span class="counter"><?php echo $totalLaQshya; ?></span></h2>
	                                <div class="googl-car-height">
	                                	<div id="piechart1" style="height:330px;"></div>
	                                </div>
	                                <!--<span class="text-success">100%</span>
	                                <div class="progress m-b-0">
	                                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:100%;"> <span class="sr-only">100% Complete</span> </div>
	                                </div> 
	                            	</a>
	                            </div>
	                        
	                    </div>


                    </div>
                    <div class="col-md-8 col-sm-12">
                    	<div class="row">
                    <div class="col-md-4">
                        <div class="analytics-sparkle-line reso-mg-b-30">
 
                            <div class="analytics-content">
                            	<a href="<?php echo base_url(). "user/laqshyafacility/Medical College"; ?>">
	                                <h5>Medical Colleges</h5>
	                                <?php 
	                                $totalMedFacility=isset($data['totalMedFacility'])?$data['totalMedFacility']:'0'; 
	                                $per=0;
	                                $per=round(($totalMedFacility/$totalLaQshya)*100,2);
	                                ?>
	                                <h2><span class="counter"><?php echo $totalMedFacility; ?></span></h2>
	                                <span class="text-info"><?php echo $per; ?>%</span>
	                                <div class="progress m-b-0">
	                                    <div class="progress-bar .progress-bar-info" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per; ?>%;"> <span class="sr-only"><?php echo $per; ?>% Complete</span> </div>
	                                </div>
                                </a>
                            </div>
                        </div>
                    </div>

                    


                    <div class="col-md-4">
                        <div class="analytics-sparkle-line reso-mg-b-30 table-mg-t-pro dk-res-t-pro-30">
                            <div class="analytics-content">
                                <a href="<?php echo base_url(). "user/laqshyafacility/District Hospital"; ?>">
                                	<h5>District Hospitals</h5>
                                <?php 
                                $totalDisFacility=isset($data['totalDisFacility'])?$data['totalDisFacility']:'0'; 
                                $per=0;
                                $per=round(($totalDisFacility/$totalLaQshya)*100,2);
                                ?>
                                <h2><span class="counter"><?php echo $totalDisFacility ?></span></h2>
                                <span class="text-info1"><?php echo $per; ?>%</span>
                                <div class="progress m-b-0">
                                    <div class="progress-bar progress-bar-info1" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per; ?>%;"> <span class="sr-only"><?php echo $per; ?>% Complete</span> </div>
                                </div>
                                </a>
                            </div>
                        </div>
                    </div>

                    

                    <div class="col-md-4">
                        <div class="analytics-sparkle-line table-mg-t-pro dk-res-t-pro-30">
                            <div class="analytics-content">
                            	<a href="<?php echo base_url(). "user/laqshyafacility/Sub-divisional Hospital"; ?>">
	                                <h5>Sub-divisional Hospitals</h5>
	                                 <?php 
		                                $totalSubDivFacility=isset($data['totalSubDivFacility'])?$data['totalSubDivFacility']:'0'; 
		                                $per=0;
		                                $per=round(($totalSubDivFacility/$totalLaQshya)*100,2);
		                               ?>
	                                <h2><span class="counter"><?php echo $totalSubDivFacility ?></span></h2>
	                                <span class="text-inverse"><?php echo $per; ?>%</span>
	                                <div class="progress m-b-0">
	                                    <div class="progress-bar progress-bar-inverse" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per; ?>%;"> <span class="sr-only"><?php echo $per; ?>% Complete</span> </div>
	                                </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div> -->


                <!---
                <div class="row">


                 
                    <div class="col-md-4">
                        <div class="analytics-sparkle-line reso-mg-b-30">
                            <div class="analytics-content">
                            	<a href="<?php echo base_url(). "user/laqshyafacility/CHC"; ?>">
                            	<?php 
	                                $totalCHC=isset($data['totalCHC'])?$data['totalCHC']:'0'; 
	                                $per=0;
	                                $per=round(($totalCHC/$totalLaQshya)*100,2);
	                                ?>


                                <h5>CHCs</h5>
                                <h2><span class="counter"><?php echo  $totalCHC ?></span></h2>
                                <span class="text-success"><?php echo $per; ?>%</span>
                                <div class="progress m-b-0">
                                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per; ?>%;"> <span class="sr-only"><?php echo $per; ?>% Complete</span> </div>
                                </div>
                            </a>
                            </div>
                        </div>
                    </div>


                     

                    <div class="col-md-4">
                        <div class="analytics-sparkle-line reso-mg-b-30">
 
                            <div class="analytics-content">
                            	<a href="<?php echo base_url(). "user/laqshyafacility/FRU"; ?>">
	                                <h5>FRUs</h5>
	                                <?php 
	                                $totalFRU=isset($data['totalFRU'])?$data['totalFRU']:'0'; 
	                                $per=0;
	                                $per=round(($totalFRU/$totalLaQshya)*100,2);
	                                ?>
	                                <h2><span class="counter"><?php echo $totalFRU; ?></span></h2>
	                                <span class="text-danger"><?php echo $per; ?>%</span>
	                                <div class="progress m-b-0">
	                                    <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per; ?>%;"> <span class="sr-only"><?php echo $per; ?>% Complete</span> </div>
	                                </div>
                                </a>
                            </div>
                        </div>
                    </div>

                     


                    <div class="col-md-4">
                        <div class="analytics-sparkle-line reso-mg-b-30 table-mg-t-pro dk-res-t-pro-30">
                            <div class="analytics-content">
                                <a href="<?php echo base_url(). "user/laqshyafacility/Other Hospital"; ?>">
                                	<h5>Others</h5>
                                <?php 
                                $totalOtherFacility=isset($data['totalOtherFacility'])?$data['totalOtherFacility']:'0'; 
                                $per=0;
                                $per=round(($totalOtherFacility/$totalLaQshya)*100,2);
                                ?>
                                <h2><span class="counter"><?php echo $totalOtherFacility ?></span></h2>
                                <span class="text-info2"><?php echo $per; ?>%</span>
                                <div class="progress m-b-0">
                                    <div class="progress-bar progress-bar-info2" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per; ?>%;"> <span class="sr-only"><?php echo $per; ?>% Complete</span> </div>
                                </div>
                                </a>
                            </div>
                        </div>
                    </div>

                    

                   
                </div> -->



                </div>



            </div>
        </div>
 </div>



 		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">

                <div class="new-map-edict">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>LaQshya Program At A Glance</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">


			    	<div class="col-md-7">
			    		<div class="row mar-bottom30">
			    			<div class="col-md-12 col-xs-12">
			    				<div id="mapwrapper">
			    					
			    					<div id="map_base">
			    						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 570 640" xml:space="preserve">
			    							<g>
			    								<path id="injs1" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M321.5,399.375c-7.875,4.375-8.875-8.5-16.375-4.5c-3.384,1.805,0.75,4.25-6,6s2.875,8-8,8.875c-7.112,0.572-4.25-6.125-6.874-2.875s0.874,7.75-2.501,9.5s-2.5-3.25-9.375,2.75c0.208,4.458-6.042,2.709-6.708,7.376s-9.833,3.833-12.5,7.73s-3.833-1.897-9.167,1.103s4.167,1,2.833,6.333c-0.679,2.717-6-6.166-9.333-4.333s1.167,3.833-2.333,6.333s-0.5-1.416-9.333,0c-5.981,0.959-6.795,1.221-5.833,5.667c1.333,6.167-5.333-1.167-8.333,4.333s-6.5-3.166-13.667,4c-3.073,3.072-4.833-0.666-12.333,0c0.167,3.999-8.417-3.917-11,7.5c-1.361,6.015,4.311,5.569,3,9.5c-1.75,5.249-6.77-0.119-7.5,4.166c-1.917,11.25,4.25,7.917,2.667,12s8.419,0.155,10.167,2c3,3.167-3.333,2.084-1.5,4.167s0.167,3.834-1.333,1.667s-3.833,0.001-5.5-2.5s-3.811-1.243-1.833,0.833c3.831,4.021-1.667,3.667,1.833,5.5s-0.028-2.807,4-1.833c5.167,1.249,3,5.777,8.667,2.222s7.167-5.055,8.5,0.278s5.167,3,5,6.833s4.667,0.333,3.167,7.667c-1.251,6.12-6,3.166-5.333,6.833s4.572,3.167,7.536,0s-1.202-5.833,4.131-6.833s6.833,2.667,10.5,0s1.25-7.442,5.833-3.834c7.833,6.167,8.5-12.166,15.833-7.333c-0.102-19.25-6.75-28.625,0-42.5s11.375,5.375,20-11.5c4.275-8.365,15.875,5.125,20.5-11.5c2.768-9.948,10.25-7.875,19.5-21c6.412-9.099,14.25-6.5,28-27.5C322.875,392.464,325.811,396.98,321.5,399.375z"/>
			    								<path id="injs2" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M555.5,185.75c-6-6.75-14,0.75-18.5-0.75s10.333-6-1-17.25s-14.651,8.28-24.5,4c-14-6.083-12.334,9.75-26,12.5c-7.105,1.43,0.25,8.5-8.25,9.5s3.416,11.25-19.25,12.5c-8.491,0.468-4,7.5,0.25,7.5s7.465,9.975,5.75,10.5c12.75-4,9.25,1.25,20.25-2c14.668-4.333,2.598-9.498,17-16c8.5-1.625,28.907-14.979,30.584-10.75c1.041,2.625-5.892,2.082-1.833,7.333c7.374,9.542-17.977,12.313-22.001,21.417c4.167-0.083,7.667,1.917,11,4c-1.138-1.706,12.018-13.494,21.25-20c11.165-7.869,11.375,6.5,15.25,1.75c1.733-2.124-9.375-7.125-3.5-13.5C555.602,192.591,561.5,192.5,555.5,185.75z"/>
			    								<path id="injs3" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M470.5,277.333c5.25-5.333,1.625,7.042,12.5-5.333c1-4,4.5-10.5,7.5-18s-4.818-1.436,0-9.5c6.125-10.25,7,3.5,17.5-20.25c4.024-9.103,29.375-11.875,22.001-21.417c-4.059-5.252,2.874-4.708,1.833-7.333c-1.677-4.229-22.084,9.125-30.584,10.75c-14.402,6.502-2.332,11.667-17,16c-11,3.25-7.5-2-20.25,2c-34,10.417-24.333-4.083-42.25,6.5c-0.584,4.417,2.251,4.917-2.5,10.25c3,0.75,3.204,4.883,2.749,10.75c4.002-5.417,3.669-5.058,14.335-5.083c17.041-0.042,10.135,4.637,18.334,0c19.082-10.792,8.388,1.04,16.333,2.519c17.124,3.189,3.743,11.801,0.995,12.814c6.754,3.5-0.371,0.75-3.754,12.25C468.166,277.667,469.834,276.167,470.5,277.333z"/>
			    								<path id="injs4" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M320.75,236c0,3.375-9.625-0.875-9.625,2.75s4.75,0.75,5.625,3.5s-5.25,1.125-1.623,5.125c2.332,2.572,10.873,4,9.748,7.25s-7.375-2.5-19.5,9.5c-7.614,7.536,1.625,12.625-2.125,16.75c8.25,2.75,10-2.75,15.375,0c3.062,1.566,0.422,7.737,6.875,6c3.25-0.875,2.625-6.645,6.5-3.572s12.125-2.928,13.375-5.428s6.817-3.851,10.375,2c5.625,9.25,4.203-1.391,8-0.125c9.75,3.25,6.544-23.75,20.875-14.625c-3.341-5.831,7.875-7.5,0.375-14.25c-3.944-3.55,10.625-8.705,3-15.875c-5.5,6.167-17.485,1.905-30,0c-15.333-2.333-8-3-13-5.5s-1.166,6.833-15,0s1.833-7.833-20.5-8C313,233.75,320.75,232.625,320.75,236z"/>
			    								<path id="injs5" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M316.625,310.5c-3.625-1.875,2-10.375-14.75-21.5c-2.125,7.125-7.02,5.779-10.25,3.625c-4.791,6.542-4.366,4.326-8.375,3.625c-13.813-2.417-20,4.5-11,6s7,9.5,3.75,9s-2.174,10.11-12,12c-11,2.115-8.25,17.75-16.75,23.75c6.428,4.367-2.714,2.586,0.125,8.5c6,12.5-3.625,11.75-0.5,17s-4.5,4.75,3.75,9.5s3,9.875-1,7.25s-8.723,7.492-7.375,12.125c2,6.875,6.625,0.875,8.5,5.625s4.283,14.231,8.875,12.75c7.75-2.5,5-10.75,10.875-11.25s9.72-10.25,9.297-16.875s-4.602-4.936-3.297-9.25c1.625-5.375-4.49-3.476-3.75-8c1.125-6.875,15.02,6.195,16.25,3.5c2.625-5.75-7.5-4.5-5.75-8.875s-4.321-5.212-1-11.75c8-15.75,18.654-5.141,19.625-10.875c4-23.625,11.375-17.484,14-25.424C317.734,315.326,321.646,313.098,316.625,310.5z"/>
			    								<path id="injs6" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M119.179,469.334c-0.155-3.333,0.032-8.209-5.345-8.333c-3.418-0.079-3-2.5-9.333-1.001c3,3.5,3.5,10.5,8.5,17C119.167,478.833,119.333,472.667,119.179,469.334z"/>
			    								<path id="injs7" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M98.313,366.125c1.376,0.181-0.188-2.375,2.313-2.625s1.75,3.75,2.563,4s5.125,0.019,4.979-8.5c-0.111-6.509,4.708,5.188,9.667-2.834c3.179-5.143-7.333-8.666-3.167-8.5s3.958-4.916,9-5.333c3.724-0.308,1.5-3-2.417-2s-4.25-4.167,0-7.458c-3.75-0.75-0.375-3.75-1.875-9.125s6-4.75,8.875-8.375s-6.25,0-2.625-8.25c-23.375-15.375-9.792-19.125-17.958-19.792c-4.166-0.34,3.167-7.667-5-7.167s-1.833-6.5-31.667-8.667c-7.648,16.996-8,0.667-20.5,7.5c-10.276,5.618-4.368-2.333-19-4c-13.167-1.5-4.333,9-17,6.5c-1.963-0.388-5.667,3.833-3.314,7.421c1.072,1.635,6.314-3.587,8.313-2.085s-11.166,2.331,4,16.164c16.566,15.11,29-3.167,31,1c2,4.166-11.167,18.5-30.5,13c-2.874-0.817,14.5,22.5,26,33s20-1.833,28.5-2c5.332-0.104,11.5-9.5,10.5-17.5c-0.807-6.452,6.106-6.598,5.416-1C92.833,342.334,99,334.834,96,344c-2,6.11,4.244,6.761,1.846,14.237c3.033,2.737-0.096,4.7-1.784,3.984c-0.777,1.404-1.781,2.985-3.062,4.778C94.063,367.438,95.938,365.813,98.313,366.125z"/>
			    								<path id="injs8" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M188.167,196.667c-3.25,4.75-3.167,0.417-5.662,1s-3.171-2.833-1.338-3.893c0.744-0.43-1.041-3.69,3.833-4.273c-3.5-17.917,3.25-20.417,8.667-31c-9.417-4-1.042-4.625-14-14.5c0.842,2.411,0.233,4.423,1.083,6.375c4.083,9.375,0.125,2.5-2.625,6.875s0.625,3.333-1,5.5s-5.806-4.384-7.5,0.75c-4.125,12.5-12.792,1.833-15.625,7.875c-1.982,4.226-2.345,2.992-3.625-1.625c-2.125-7.667-8.125-3.5-13.125-4.875c3.5,3.625-1.083,14.955,3,14c7.75-1.813,5.761,3.942,10.125,2.5c7.188-2.375,2.25,13.125,9.875,17.544c10.183,5.901-0.875,10.581,4,12.331c6.218,2.232,4-9.938,8.875-5.25c4.655,4.476,3.875-3.75,7.75-1s-8.125,17.917,9.625,5.333C193,202.667,187.833,200.667,188.167,196.667z"/>
			    								<path id="injs9" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M206.5,109.833c-3.511,1.249-4.558-7.636-9.333-5.5c-6.333,2.832-12.667-6.667-18.667-6.5s-3.5,4.667-9.167,4.667s-1.167,9.833-6,10.333c4.042,3.667-4.458,3.667-2.167,8.833c9.119,20.555,9.083,9.833,13.167,14.667c3.119,3.692,0.664,4.108,5.333,7.667c12.958,9.875,4.583,10.5,14,14.5c4.144-8.095-0.917-14.917,17.167-17.5c8.928-1.275,7.333,6.083,12.667,1.5c-12.159-3.783-3.333-11.167-11-26C207,114.5,214,107.165,206.5,109.833z"/>
			    								<path id="injs10" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M163.333,112.833c4.833-0.5,0.333-10.333,6-10.333s3.167-4.5,9.167-4.667s12.333,9.332,18.667,6.5c4.775-2.136,5.823,6.749,9.333,5.5c7.5-2.668,0.5,4.667,6,6.667c-1.578-3.052,2.5-8.667,7.5-3s14.115-7.509,8.833-10.833c-4.619-2.908,3.247-1.977-7.167-5c-7.652-2.222,2.458-6.234,0.167-14.395c-2.668-9.507,9.833,0.334,10.667-9.833c0.436-5.315,7,3.811,11.667-15.667c1.763-7.358-4.333-12.667-6.833-11.333s-7.5-4.167-11.833-0.333s-7.5-4.667-18.667,2.5c-4.746,3.046-8.823,4.455-10.833,0.333c-3.333-6.833-11,2-12.5-8c-0.822-5.479-10.833-6.833-13.333-13.833s-9.333-3-8.994-7.667s-4.84,0.333-10.173-2.667s-8.167,3.833-15,2s-0.667,7.333-9.333,5.5s-4.167,4.833-11.5,6.333s-7.167,11,1,10.667s4.167,6.5,11,8.167s0.5,3.667,5.333,5.667s4.167,9.667-0.667,8.333S133,69.272,126,68.772s-3,2.895-1.667,15.061s5.5,10.833,7,15.667s12.5,0.333,12.667,7.333s6.667,5.667,12,8.667C158.487,116.899,158.5,113.333,163.333,112.833z"/>
			    								<path id="injs11" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M363.75,279.75c-3.797-1.266-2.375,9.375-8,0.125c-3.558-5.851-9.125-4.5-10.375-2s-9.5,8.5-13.375,5.428s-3.25,2.697-6.5,3.572c-6.453,1.737-3.813-4.434-6.875-6c-5.375-2.75-7.125,2.75-15.375,0c-1.25,1.375-0.352,4.693-1.375,8.125c16.75,11.125,11.125,19.625,14.75,21.5c5.021,2.598,1.109,4.826-0.75,10.451c8.375,6.424,10,1.049,13.75,2.174s5.709-5.496,7.125-1.087c1.875,5.837-4.75,6.853,0.75,7.962c4.494,0.906,4.688-4.484,10.75-1.109c10.75,5.984,1.769-10.221,8.375-8.188c9.5,2.922,8.584,6.172,12.667,5.922c-1.905-3.282,4.649-4.137-4.667-10.125c-7-4.5,5.875-4-12.75-9.75c-4.348-1.342,1.5-9.125,5.875-6.5s8.5-9,14.75-7.375s18.5-16.625,12.125-27.75C370.294,256,373.5,283,363.75,279.75z"/>
			    								<path id="injs12" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M149.167,541.166c5.958-0.166,6.779,3.229,11.5,5.334c12.333,5.5,6.708-3.918,15.333-1.334s3-2.834,8.667-3s4.333-6.334,0.833-6s0.125-2.416-0.333-6.5c-0.731-6.513,2.852-2,3.926-5s4.742,0.501,9.575-0.166c-0.667-3.667,4.082-0.713,5.333-6.833c1.5-7.334-3.333-3.834-3.167-7.667s-3.667-1.5-5-6.833s-2.833-3.834-8.5-0.278s-3.5-0.973-8.667-2.222c-4.028-0.974-0.5,3.666-4,1.833s1.998-1.479-1.833-5.5c-1.978-2.076,0.167-3.334,1.833-0.833s4,0.333,5.5,2.5s3.167,0.416,1.333-1.667s4.5-1,1.5-4.167c-1.747-1.845-11.75,2.083-10.167-2s-4.583-0.75-2.667-12c0.73-4.285,5.75,1.083,7.5-4.166c1.311-3.931-4.361-3.485-3-9.5c2.583-11.417,11.167-3.501,11-7.5c-0.077-1.839-1.788-4.84,0.333-6.334c3.667-2.583-11.417-2.083-3-4.166c2.103-0.521,3.779-12.904,1.833-13.667c-4.25-1.667,8.667-8,2.981-7.833s2.685-6.167,3.352-11.334s-3.363-2.29-3.333-5.666c-4.917-4.916-9.956,6.695-13,8.333c-8.833,4.751-12.167,0.334-11,8.5c0.46,3.221-9.167,0.667-13.667-1.833s3.667,12.584-7.333,12s-6.652-0.134-13.167,4.5S125,438,120,442.833s3.5,4.668,2.833,12c-0.328,3.602-5.167,1.334-9,6.168c5.377,0.124,5.19,5,5.345,8.333S119.167,478.833,113,477c5,6.5,13,34,16.5,47C142.5,527.066,143.208,541.332,149.167,541.166z"/>
			    								<path id="injs13" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M178.494,598.667c5.006-7.666-4.66-2.5-0.827-14.5c1.286-4.024,3.167-8.667-4.833-5.834s1.333-11.666-4.5-13.166s1.167-5.249-4.25-7s1.333-4.333-4.583-6.167c-7.832-2.428-0.833-3.5,1.167-5.5c-4.721-2.105-5.542-5.5-11.5-5.334S142.5,527.066,129.5,524c1.345,4.994,4,14,10.974,21.098c3.401-0.41,5.896-0.363,2.399,4.738c6.294,14.83,10.149,23.729,12.127,29.664c3.5,10.5-4.333,19.333,17.5,40.5C180.417,608.834,171.431,609.481,178.494,598.667z"/>
			    								<path id="injs14" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M264,323.25c9.826-1.89,8.75-12.5,12-12s5.25-7.5-3.75-9s-2.813-8.417,11-6c4.009,0.701,3.584,2.917,8.375-3.625c-5.625-3.75,2.875-17.5-4.5-15s-16.928-14.865-23.75-9.625c-8.625,6.625-5.25-1.125-14.125,0.625c-7.17,1.414-1.75-8.75-11.25-4.25c-7.053,3.341-8.625,2-10.875-0.5s-1.375,3.875-7.25,2.375c-3.232-0.825-0.07-8.711-5-4.625c-8.886,7.366,8.875,18.375,3.125,23.5s-17.004-6.405-12.5-13.5c5-7.875-2.428-11.188,3.125-12.875c9.875-3,5.97-4.866,9.125-8.875c10.625-13.5-6.5-20.875-13.125-17s-33.35,18.642-32.5,23.25c2.375,12.875,15,1.25,16.75,8s-8.875,2.375-10,7.875s5,2.5,4,7.75c-0.563,2.957-6-2.375-4.375,4c1.162,4.56-1.142,4.412-5,2.625c-11.875-5.5-11.25,11.748-19.375,6.812s5.635-2.316,3.75-6.687c-2.75-6.375,5.25-5,2.25-9.625s-6.25,0.625-10.375-1.875s4.25-11.875-6.375-5.5s7.051,25.915-6.75,30.125c-7.375,2.25,2.875,4.25-3.75,7.5c-5.12,2.512-5.563-3.838-7.25,0c-3.625,8.25,5.5,4.625,2.625,8.25s-10.375,3-8.875,8.375s-1.875,8.375,1.875,9.125s6.375-2,9.375,0S128.5,339.625,136,339s4,6.75,16.75,5.5s8.75,8.125,15.625,5.625s4.77-10.698,12.375-11.25c15.5-1.125,4.75,6.875,13.125,6.625s8-6.25,15.625-2.375s9-6.625,16.75-1.625s11.25-1.125,21,5.5C255.75,341,253,325.365,264,323.25z"/>
			    								<path id="injs15" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M113.833,461.001c3.833-4.834,8.672-2.566,9-6.168c0.667-7.332-7.833-7.167-2.833-12s3.152,1.968,9.667-2.666s2.167-5.084,13.167-4.5s2.833-14.5,7.333-12s14.126,5.054,13.667,1.833c-1.167-8.166,2.167-3.749,11-8.5c3.044-1.638,8.083-13.249,13-8.333c0.083-9.251,1.917-3.917,5.333-8.5s-1.917-4.917,1-10.167s4.667,2.083,5.667-4c0.467-2.839,4.333,2.333,3.833-4.167S205,376.5,211.5,377.5s2.833,5,6.333,6.667s2.833-3.334,7.167-0.834s3.605-2.223,8,0c7.25,3.667,0.917,11.083,2.833,12s-5.5,7.417,6.417,6.042c-1.348-4.633,3.375-14.75,7.375-12.125s9.25-2.5,1-7.25s-0.625-4.25-3.75-9.5s6.5-4.5,0.5-17c-2.839-5.914,6.303-4.133-0.125-8.5c-9.75-6.625-13.25-0.5-21-5.5s-9.125,5.5-16.75,1.625s-7.25,2.125-15.625,2.375s2.375-7.75-13.125-6.625c-7.605,0.552-5.5,8.75-12.375,11.25s-2.875-6.875-15.625-5.625s-9.25-6.125-16.75-5.5s-2.375-4.125-5.375-6.125s-5.625,0.75-9.375,0c-4.25,3.291-3.917,8.458,0,7.458s6.141,1.692,2.417,2c-5.042,0.417-4.833,5.499-9,5.333s6.345,3.357,3.167,8.5c-4.958,8.021-9.778-3.675-9.667,2.834c0.146,8.519-4.167,8.75-4.979,8.5c0.188,4.438-4.688,2.063-4.875-1.375c-2.375-0.313-4.25,1.313-5.313,0.875c-3.574,5.004,1.5,32.5,5,47.753s3.5,41.747,6.5,45.247C110.833,458.501,110.416,460.922,113.833,461.001z"/>
			    								<path id="injs16" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M500,247.833c-1.959-0.476-2.167,9.333-9.5,6.167c-3,7.5-6.5,14-7.5,18s2.577,6.398,7.75,7.25c9.375,0.125,14.742,8.386,16.25-1.5c2.25-14.75,8.25-12,9.25-19.5s-5.25,1.25-2.75-9.5C509,241.833,511.666,250.667,500,247.833z"/>
			    								<path id="injs17" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M471.001,249.186c-7.945-1.479,2.749-13.311-16.333-2.519c-8.199,4.637-1.293-0.042-18.334,0c-10.666,0.026-10.333-0.333-14.335,5.083c-1.124,14.5,16.751,7.875,34.249,8.75c9.881,0.494,11.655-0.621,15.748,1.5C474.744,260.986,488.125,252.375,471.001,249.186z"/>
			    								<path id="injs18" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M483,272c-10.875,12.375-7.25,0-12.5,5.333c0.666,1.167,0.922,7.328,0.875,10.417c-0.625,12.25,3.375,14.625,7.875,30.959c2.715,9.855,7.25,0,10.25,0c7,0-6-15.709,0-15.709c5,0,5.5-19,0.75-23.75C485.077,278.398,482,276,483,272z"/>
			    								<path id="injs19" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M490.5,244.5c-4.818,8.064,3,2,0,9.5c7.333,3.167,7.541-6.643,9.5-6.167c11.666,2.833,9-6,13.5,0.917c0.475-2.041,4.25-0.25,3-5.5s7.75-7.125,2.5-15c-3.333-2.083-6.833-4.083-11-4C497.5,248,496.625,234.25,490.5,244.5z"/>
			    								<path id="injs20" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M369.292,326.625c-4.083,0.25-3.167-3-12.667-5.922c-6.606-2.033,2.375,14.172-8.375,8.188c-6.063-3.375-6.256,2.016-10.75,1.109c-5.5-1.109,1.125-2.125-0.75-7.962c-1.416-4.409-3.375,2.212-7.125,1.087s-5.375,4.25-13.75-2.174c-2.625,7.939-10,1.799-14,25.424c-0.971,5.734-11.625-4.875-19.625,10.875c-3.321,6.538,2.75,7.375,1,11.75s8.375,3.125,5.75,8.875c-1.23,2.695-15.125-10.375-16.25-3.5c-0.74,4.524,5.375,2.625,3.75,8c-1.304,4.314,2.875,2.625,3.297,9.25S276.375,408,270.5,408.5s-3.125,8.75-10.875,11.25c2.375,0.875,9.563,2.156,12.75-0.625c6.875-6,6-1,9.375-2.75s-0.123-6.25,2.501-9.5s-0.238,3.447,6.874,2.875c10.875-0.875,1.25-7.125,8-8.875s2.616-4.195,6-6c7.5-4,8.5,8.875,16.375,4.5c4.311-2.395,1.375-6.911,9-6.875c13.75-21,15.75-5.375,39-30.5c8.675-9.374-3-10.5,0-16.5s10.766-4.648,15.5-8.5C373.875,326.625,375.75,337.75,369.292,326.625z"/>
			    								<path id="injs21" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M150.375,169.75c1.28,4.617,1.643,5.851,3.625,1.625c2.833-6.042,11.5,4.625,15.625-7.875c1.694-5.134,5.875,1.417,7.5-0.75s-1.75-1.125,1-5.5s6.708,2.5,2.625-6.875c-3.083-0.292-4.416-4.375-1.083-6.375c-4.67-3.559-2.214-3.975-5.333-7.667c-4.083-4.833-4.048,5.888-13.167-14.667c-2.292-5.167,6.208-5.167,2.167-8.833c-4.833,0.5-4.847,4.065-7.333,2.667c0,5.5-7.345,5.158-9.5,6.5c-10.167,6.333,0.886,15.109-7,20.5c-16.333,11.167-10.765,21.071-14,21c4.625,0.875,8.299,0.426,11.75,1.375C142.25,166.25,148.25,162.083,150.375,169.75z"/>
			    								<path id="injs22" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M102.667,280.167c8.167-0.5,0.834,6.827,5,7.167c8.167,0.667-5.417,4.417,17.958,19.792c1.687-3.838,2.13,2.512,7.25,0c6.625-3.25-3.625-5.25,3.75-7.5c13.801-4.21-3.875-23.75,6.75-30.125s2.25,3,6.375,5.5s7.375-2.75,10.375,1.875s-5,3.25-2.25,9.625c1.885,4.371-11.875,1.75-3.75,6.687s7.5-12.312,19.375-6.812c3.858,1.787,6.162,1.935,5-2.625c-1.625-6.375,3.812-1.043,4.375-4c1-5.25-5.125-2.25-4-7.75s11.75-1.125,10-7.875s-14.375,4.875-16.75-8c-0.85-4.608,25.875-19.375,32.5-23.25c-1.375-4.792-2.292-1.042-4.958-2.208s-2.931,0.14-5.833,1.5c-5.333,2.5-5.583-0.583,0.667-3c2.715-1.05-3.25-0.833,0-3.667c1.69-1.474-7.786-3.555-4-15.167c-17.75,12.583-5.75-2.583-9.625-5.333s-3.095,5.476-7.75,1c-4.875-4.688-2.657,7.482-8.875,5.25c-4.875-1.75,6.183-6.43-4-12.331c-7.625-4.419-2.688-19.919-9.875-17.544c-4.364,1.442-2.375-4.313-10.125-2.5c-4.083,0.955,0.5-10.375-3-14c-3.451-0.949-7.125-0.5-11.75-1.375c-15.167-0.333-6.5,22.833-22.5,22c-7.008-0.365-11.167,23.167-22.5,20c-9.349-2.612-11.167,8.5-16.5-1c-3.277-5.837-9.431-4.833-11.5,2.412C49.333,218,43.138,213.021,42,219.5c-2.167,12.333,12.65,6.965,10.5,17.5c-3.333,16.333,9.793,7.979,10,13c0.667,16.167,10,18.167,8.5,21.5C100.833,273.667,94.5,280.667,102.667,280.167z"/>
			    								<path id="injs23" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M401,222c2.27-4.991-2.75-5.25-0.75-9.25s3.417-12.583-6.25-8.75c-6.712,2.662-9,15-7,19C398.625,226.875,391.5,219.25,401,222z"/>
			    								<path id="injs24" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M226.667,513.833c-4.583-3.608-2.167,1.167-5.833,3.834s-5.167-1-10.5,0s-1.167,3.666-4.131,6.833s-6.869,3.667-7.536,0c-4.833,0.667-8.5-2.834-9.575,0.166s-4.657-1.513-3.926,5c0.458,4.084-3.167,6.834,0.333,6.5s4.833,5.834-0.833,6s-0.042,5.584-8.667,3s-3,6.834-15.333,1.334c-2,2-8.998,3.072-1.167,5.5c5.917,1.834-0.833,4.416,4.583,6.167s-1.583,5.5,4.25,7s-3.5,15.999,4.5,13.166s6.119,1.81,4.833,5.834c-3.833,12,5.833,6.834,0.827,14.5c-7.063,10.814,1.923,10.167-5.994,21.333c8.042,7.796,21.833,0.333,23.5-9.5c1.41-8.32,7.5-9.333,18.5-12.5c-5.667-6.167,5.245-13.507,5.5-18.5c0.417-8.166,14.333,0.751,13-3s-2.174-6.046-1.732-9.188c-4.232-1.688-3.268-5.396,0.423-5.896c0.047-4.961-1.588-10.413-1.243-14.669c-7.469-0.837-2.281-6.58,0.552-6.247c0.5-5.5,11.625-10.375,11.5-34C235.167,501.667,234.5,520,226.667,513.833z"/>
			    								<path id="injs25" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M250.75,407c-1.875-4.75-6.5,1.25-8.5-5.625c-11.917,1.375-4.5-5.125-6.417-6.042s4.417-8.333-2.833-12c-4.395-2.223-3.667,2.5-8,0s-3.667,2.501-7.167,0.834S218,378.5,211.5,377.5s-8.333-2.167-7.833,4.333s-3.366,1.328-3.833,4.167c-1,6.083-2.75-1.25-5.667,4s2.417,5.584-1,10.167s-5.25-0.751-5.333,8.5c-0.03,3.376,4,0.499,3.333,5.666s-9.037,11.501-3.352,11.334s-7.231,6.166-2.981,7.833c1.945,0.763,0.27,13.146-1.833,13.667c-8.417,2.083,6.667,1.583,3,4.166c-2.122,1.494-0.41,4.495-0.333,6.334c7.5-0.666,9.26,3.072,12.333,0c7.167-7.166,10.667,1.5,13.667-4s9.667,1.834,8.333-4.333c-0.961-4.446-0.147-4.708,5.833-5.667c8.833-1.416,5.833,2.5,9.333,0s-1-4.5,2.333-6.333s8.654,7.05,9.333,4.333c1.333-5.333-8.167-3.333-2.833-6.333s6.5,2.795,9.167-1.103s11.833-3.063,12.5-7.73s6.916-2.918,6.708-7.376c-3.187,2.781-10.375,1.5-12.75,0.625C255.033,421.231,252.625,411.75,250.75,407z"/>
			    								<path id="injs26" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M470.5,277.333c-0.666-1.167-2.334,0.333-2.258-3.083c-2.766,9.403-15.617,5.125-18.008,12.75s2.234,8.75,2.484,14.75s10.406,5.25,10.719-3.5s4.063-8.125,7.938-10.5C471.422,284.661,471.166,278.5,470.5,277.333z"/>
			    								<path id="injs27" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M234.667,190.833c-2.667-2.833-3.167,4.792-17.833-7.167c-5.007-4.083,7.292-1.542-7.667-12.167c-5.411-3.844-4.542,8.875-10.667,1c-4.295-5.523-0.333-7.167,0.833-9.5s-2.816-3.289-5.667-4.5c-5.417,10.583-12.167,13.083-8.667,31c0.683,3.497,3.5,3.167,3.167,7.167s4.833,6,2.333,13.667c-3.786,11.612,5.69,13.693,4,15.167c-3.25,2.833,2.715,2.617,0,3.667c-6.25,2.417-6,5.5-0.667,3c2.903-1.36,3.167-2.667,5.833-1.5s3.583-2.584,4.958,2.208c6.625-3.875,23.75,3.5,13.125,17c-3.155,4.009,0.75,5.875-9.125,8.875c-5.553,1.687,1.875,5-3.125,12.875c-4.504,7.095,6.75,18.625,12.5,13.5s-12.011-16.134-3.125-23.5c4.93-4.086,1.768,3.8,5,4.625c5.875,1.5,5-4.875,7.25-2.375s3.822,3.841,10.875,0.5c9.5-4.5,4.08,5.664,11.25,4.25c8.875-1.75,5.5,6,14.125-0.625c6.822-5.24,16.375,12.125,23.75,9.625s-1.125,11.25,4.5,15c3.23,2.154,8.125,3.5,10.25-3.625c1.023-3.432,0.125-6.75,1.375-8.125c3.75-4.125-5.489-9.214,2.125-16.75c12.125-12,18.375-6.25,19.5-9.5s-7.416-4.678-9.748-7.25c-3.627-4,2.498-2.375,1.623-5.125s-5.625,0.125-5.625-3.5s9.625,0.625,9.625-2.75s-7.75-2.25-11.25-14.5c-9.736-0.073-22.833-4.5-30-8.5s-15.5-2.833-17.756-9.038C260.418,200.316,252.833,201,242,192C239.667,195.167,237.333,193.667,234.667,190.833z"/>
			    								<path id="injs28" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M210.833,141c-18.083,2.583-13.023,9.405-17.167,17.5c2.851,1.211,6.833,2.167,5.667,4.5s-5.129,3.977-0.833,9.5c6.125,7.875,5.256-4.844,10.667-1c14.958,10.625,2.66,8.084,7.667,12.167C231.5,195.625,232,188,234.667,190.833s5,4.333,7.333,1.167c-2.793-2.32,3.667-6.667,4.051-15.302c0.242-5.437,6.148-8.688,7.449-9.698c3.005-2.334,6.167-6.333-8.5-13c-8.689-3.95,1-4.5-21.5-11.5C218.167,147.083,219.762,139.725,210.833,141z"/>
			    								<path id="injs29" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M421.75,230.75c-4.332,2.559-8.523-4.977-12.25-1.25c-1.5,1.5-10.167-3.833-8.5-7.5c-9.5-2.75-2.375,4.875-14,1c2,4,6.5,5.833,1,12c7.625,7.17-6.944,12.325-3,15.875c7.5,6.75-3.716,8.419-0.375,14.25C391,276.25,378.75,294.5,372.5,292.875s-10.375,10-14.75,7.375s-10.223,5.158-5.875,6.5c18.625,5.75,5.75,5.25,12.75,9.75c9.316,5.988,2.762,6.843,4.667,10.125c6.458,11.125,4.583,0,15.708,10.375c7.375-6,10-14,11-7s6.125-5.125,14.5-8c3.329-1.143-5-9-2.5-17.5s-9.888-4.9-6.5-13.5c5.417-13.75-3.583-7.5-11.39-14c-3.46-2.881,6.247-13.572,10.89-14.23s5.5-5.77-0.5-6.27s-2.75-4.375-6.568-5c-7.045-1.153-2.682-7,0.068-10.5s-1.033-5.525,1.5-6c4-0.75,2.25,6.5,6.75,6.75s0.25-7.5,4.25-5s-1.75,6.5,5.75,8.25s4-4.75,7-4C424.001,235.667,421.166,235.167,421.75,230.75z"/>
			    								<path id="injs30" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M418.333,478.668c2.171-1.24,1.667,13.334-1.333,14S414.833,480.668,418.333,478.668z M415.162,505.668c1.829,1.167,3.838-2,4.505-4.667s-0.621-8.34-2.253-6.167C415.662,497.167,413.333,504.501,415.162,505.668z M418.833,517.334c0.5-4.334-2.392-3.039-2.833-5.5c-1.833-10.224-4.834,2.667-1.505,8S418.333,521.668,418.833,517.334z M410.5,544.001c1.167,3.167,4.866-1.34,3.995-5.667C413.824,535,409.333,540.834,410.5,544.001z M419.5,573.668c-2.333-1.5-3.334,2.833-2.334,4S421.833,575.168,419.5,573.668z M429.124,596.185c2.25-0.845,0.736-2.538-0.266-3.998C425.92,587.908,426.873,597.028,429.124,596.185z M434.166,598.668c-2.667-0.666-1,3.333,1.667,3.666s2.941-0.823,2.333-4.833C437.332,592.001,436.833,599.334,434.166,598.668z M445.333,612.668c-2.667,2,1.834,10.5,4.667,9.5S448.082,610.606,445.333,612.668z"/>
			    								<path id="injs31" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M180.75,150.375c-0.85-1.952-0.241-3.964-1.083-6.375C176.334,146,177.667,150.083,180.75,150.375z"/>
			    								<path id="injs32" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M100.625,363.5c-2.5,0.25-0.937,2.806-2.313,2.625c0.188,3.438,5.063,5.813,4.875,1.375C102.375,367.25,103.125,363.25,100.625,363.5z"/>
			    								<path id="injs33" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M97.846,358.237c-0.369,1.151-0.943,2.465-1.784,3.984C97.75,362.938,100.879,360.975,97.846,358.237z"/>
			    								<path id="injs34" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M67.375,530c-1.375,1-3.666-0.804-2.5-2.934C65.412,526.085,68.75,529,67.375,530z M63,537.375c-1.957,1.957,2.25,4.25,2.625,2.625S63.875,536.5,63,537.375z M72.5,544.942c1.125-1.567-1.375-4.067-2.375-2.442C68.86,544.556,71.375,546.51,72.5,544.942z M69.778,553.625c1.347-1.75-1.91-3.293-2.073-2.5C67.228,553.435,68.431,555.375,69.778,553.625z M69.778,560.125c0.097,2,4.042,1.75,3.007,0S69.778,560.125,69.778,560.125z M72.958,558.125c1.542,0.75,2.167,0.25,1.917-1.375C74.687,555.527,71.416,557.375,72.958,558.125z M81.75,550.911c-1.286,1.72,1,3.714,2.5,2.214S83.125,549.072,81.75,550.911z M88.875,546.5c-0.625,2.25,1,2.387,1.875,1.756S89.5,544.25,88.875,546.5z M78,566.75c-0.717,1.673,1.125,3.875,2.5,2.25S79.125,564.125,78,566.75z M69.778,575c-1.617,1.227-0.042,3.375,1.59,1.375S70.931,574.125,69.778,575z"/>
			    								<path id="injs35" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M181.167,193.773c-1.833,1.06-1.157,4.476,1.338,3.893s2.412,3.751,5.662-1c0.333-4-2.484-3.67-3.167-7.167C180.126,190.083,181.911,193.343,181.167,193.773z"/>
			    								<path id="injs36" fill="#EBECED" stroke="#FFFFFF" vector-effect="non-scaling-stroke" d="M142.873,549.836c-0.473-1.113-1.544-3.868-2.399-4.738C143.875,544.688,146.37,544.734,142.873,549.836z M231.268,567.313c0.214-1.527,0.407-4.183,0.423-5.896C228,561.917,227.035,565.624,231.268,567.313z M231,540.5c-0.118,1.303-0.332,3.531-0.552,6.247C222.979,545.91,228.167,540.167,231,540.5z"/>
			    							</g>
			    							<g id="visnames">
			    								<text fill="#000000" id="injsvn1" transform="matrix(1 0 0 1 191 475)"><tspan x="0" y="0" font-size="13">Andhra</tspan><tspan x="-3" y="15" font-size="13">Pradesh</tspan></text>
			    								<text fill="#000000" id="injsvn2" transform="matrix(1 0 0 1 427 174)"><tspan x="0" y="0" font-size="12">Arunachal</tspan><tspan x="4" y="14" font-size="12">Pradesh</tspan></text>
			    								<text fill="#000000" id="injsvn3" transform="matrix(1 0 0 1 447 239)" font-size="12">Assam</text>
			    								<text fill="#000000" id="injsvn4" transform="matrix(1 0 0 1 335 258)" font-size="13">Bihar</text>
			    								<text fill="#000000" id="injsvn5" transform="matrix(1 0 0 1 254 342)" font-size="9">Chhattisgarh</text>
			    								<text fill="#000000" id="injsvn6" transform="matrix(1 0 0 1 80 475)" font-size="13">Goa</text>
			    								<text fill="#000000" id="injsvn7" transform="matrix(1 0 0 1 60 312)" font-size="15">Gujarat</text>
			    								<text fill="#000000" id="injsvn8" transform="matrix(1 0 0 1 150 183)" font-size="9">Haryana</text>
			    								<text fill="#000000" id="injsvn9" transform="matrix(1 0 0 1 169 122)"><tspan x="0" y="0" font-size="10">Himachal</tspan><tspan x="2" y="12" font-size="10">Pradesh</tspan></text>
			    								<text fill="#000000" id="injsvn10" transform="matrix(1 0 0 1 157 69)"><tspan x="0" y="0" font-size="12">Jammu</tspan><tspan x="-14" y="14" font-size="12">and Kashmir</tspan></text>
			    								<text fill="#000000" id="injsvn11" transform="matrix(1 0 0 1 310 297)" font-size="11">Jharkhand</text>
			    								<text fill="#000000" id="injsvn12" transform="matrix(1 0 0 1 129 517)" font-size="14">Karnataka</text>
			    								<text fill="#000000" id="injsvn13" transform="matrix(1 0 0 1 119 612)" font-size="13">Kerala</text>
			    								<text fill="#000000" id="injsvn14" transform="matrix(1 0 0 1 148 313)" font-size="15">Madhya Pradesh</text>
			    								<text fill="#000000" id="injsvn15" transform="matrix(1 0 0 1 111 383)" font-size="15">Maharashtra</text>
			    								<text fill="#000000" id="injsvn16" transform="matrix(1 0 0 1 510 277)" font-size="11">Manipur</text>
			    								<text fill="#000000" id="injsvn17" transform="matrix(1 0 0 1 416 273)" font-size="10">Meghalaya</text>
			    								<text fill="#000000" id="injsvn18" transform="matrix(1 0 0 1 494 312)" font-size="11">Mizoram</text>
			    								<text fill="#000000" id="injsvn19" transform="matrix(1 0 0 1 519 244)" font-size="11">Nagaland</text>
			    								<text fill="#000000" id="injsvn20" transform="matrix(1 0 0 1 310 362)" font-size="9">Odisha</text>
			    								<text fill="#000000" id="injsvn21" transform="matrix(1 0 0 1 137 154)" font-size="12">Punjab</text>
			    								<text fill="#000000" id="injsvn22" transform="matrix(1 0 0 1 89 236)" font-size="15">Rajasthan</text>
			    								<text fill="#000000" id="injsvn23" transform="matrix(1 0 0 1 349 213)" font-size="11">Sikkim</text>
			    								<text fill="#000000" id="injsvn24" transform="matrix(1 0 0 1 184 559)"><tspan x="0" y="0" font-size="14">Tamil</tspan><tspan x="0" y="16" font-size="14">Nadu</tspan></text>
			    								<text fill="#000000" id="injsvn25" transform="matrix(1 0 0 1 194 420)" font-size="12">Telangana</text>
			    								<text fill="#000000" id="injsvn26" transform="matrix(1 0 0 1 426 316)" font-size="11">Tripura</text>
			    								<text fill="#000000" id="injsvn27" transform="matrix(1 0 0 1 211 231)" font-size="14">Uttar Pradesh</text>
			    								<text fill="#000000" id="injsvn28" transform="matrix(1 0 0 1 200 165)" font-size="10">Uttarakhand</text>
			    								<text fill="#000000" id="injsvn29" transform="matrix(1 0 0 1 374 305)"><tspan x="0" y="0" font-size="12">West</tspan><tspan x="-5" y="14" font-size="12">Bengal</tspan></text>
			    								<text fill="#000000" id="injsvn30" transform="matrix(1 0 0 1 420 550)"><tspan x="0" y="0" font-size="11">Andaman and</tspan><tspan x="-3" y="13" font-size="11">Nicobar Islands</tspan></text>
			    								<text fill="#000000" id="injsvn31" transform="matrix(1 0 0 1 185 149)" font-size="9">Chandigarh</text>
			    								<text fill="#000000" id="injsvn32" transform="matrix(1 0 0 1 16 377)" font-size="8">Dadra and Nagar Haveli</text>
			    								<text fill="#000000" id="injsvn33" transform="matrix(1 0 0 1 34 363)" font-size="8">Daman and Diu</text>
			    								<text fill="#000000" id="injsvn34" transform="matrix(1 0 0 1 32 588)" font-size="12">Lakshadweep</text>
			    								<text fill="#000000" id="injsvn35" transform="matrix(1 0 0 1 192 191)"><tspan x="0" y="0" font-size="8">National Capital</tspan><tspan x="-1" y="9" font-size="8">Territory of Delhi</tspan></text>
			    								<text fill="#000000" id="injsvn36" transform="matrix(1 0 0 1 234 558)" font-size="11">Puducherry</text>
			    							</g>
			    						</svg>
			    					</div>
			    					<script type="text/javascript">
			    						<?php if(isset($data['dataMap']) && !empty($data['dataMap'])){ ?>

			    							var injsconfig= {
			    								<?php 	
			    								$per=$colorCodeMap=array();
			    								foreach ($data['dataMap'] as $key => $value) {
			    									if(isset($value['mapCode'])){
			    										$per[$key]=(int)(((int)$value['certifiedLR']*100)/(int)$value['facilities']);
			    										if($per[$key]>=76 && $per[$key]<=100){
			    											$colorCodeMap[$key]='#72d062';
			    										} else if($per[$key]>=51 && $per[$key]<=75){
			    											$colorCodeMap[$key]='#5dc4ff';
			    										} else if($per[$key]>=26 && $per[$key]<=50){
			    											$colorCodeMap[$key]='#ff8c4d';
			    										} else {
			    											$colorCodeMap[$key]='#3956a4';
			    										}    		
			    										$facilities=isset($value['facilitiesNew'])?'<br>Total no. of Facilities: '.$value['facilitiesNew'].'<br>':'';
			    										$certifiedLR=isset($value['certifiedLR'])?'<br>Facilities completed National level LaQshya certification for LR: '.$value['certifiedLR'].'<br>':'';
			    										$certifiedOT=isset($value['certifiedOT'])?'<br>Facilities completed National level LaQshya certification for OT: '.$value['certifiedOT'].'<br>':'';
			    										$LrBaseLine=isset($value['LrBaseLine'])?'<br>Facilities completed Baseline LR Assessment: '.$value['LrBaseLine'].'<br>':'';
			    										$OtbaseLine=isset($value['OtbaseLine'])?'<br>facilities completed Baseline OT Assessment: '.$value['OtbaseLine'].'<br>':'';
			    										echo '"'.$key.'":{
			    											"hover":"<b><u>'.$value['catName'].'</u></b><br>'.$facilities.$LrBaseLine.$OtbaseLine.$certifiedLR.$certifiedOT.'", "upColor": "'.$colorCodeMap[$key].'", "overColor": "#3956a4", "downColor": "'.$colorCodeMap[$key].'", "active": !0
			    										},';
			    									} else {
			    										echo '"'.$key.'":{"hover": "GOA", "upColor": "#E0E2E2", "overColor": "#3956a4", "downColor": "#cae9af", "active": !1},';			
			    									}
			    								}
			    								?>
			    								"general": {
			    									"borderColor": "#9CA8B6", "visibleNames": "#adadad"
			    								}
			    							}

			    							;
			    							function isTouchEnabled() {
			    								return(("ontouchstart" in window)||(navigator.MaxTouchPoints>0)||(navigator.msMaxTouchPoints>0))
			    							}

			    							jQuery(function() {
			    								jQuery("path[id^=injs]").each(function(i, e) {
			    									inaddEvent(jQuery(e).attr("id"))
			    								}
			    								)
			    							}

			    							);
			    							function inaddEvent(id, relationId) {
			    								var _obj=jQuery("#"+id);
			    								var arr=id.split("");
			    								var _Textobj=jQuery("#"+id+","+"#injsvn"+arr.slice(4).join(""));
			    								jQuery("#"+["visnames"]).attr( {
			    									"fill": injsconfig.general.visibleNames
			    								}
			    								);
			    								_obj.attr( {
			    									"fill": injsconfig[id].upColor, "stroke": injsconfig.general.borderColor
			    								}
			    								);
			    								_Textobj.attr( {
			    									"cursor": "default"
			    								}
			    								);
			    								if(injsconfig[id].active===!0) {
			    									_Textobj.attr( {
			    										"cursor": "pointer"
			    									}
			    									);
			    									_Textobj.hover(function() {
			    										jQuery("#jstip").show().html(injsconfig[id].hover);
			    										_obj.css( {
			    											"fill": injsconfig[id].overColor
			    										}
			    										)
			    									}
			    									, function() {
			    										jQuery("#jstip").hide();
			    										jQuery("#"+id).css( {
			    											"fill": injsconfig[id].upColor
			    										}
			    										)
			    									}
			    									);
						                            _Textobj.click(function(){ 
						                              //console.log(_Textobj.attr('id'));
						                            var params={};
						                            params['device']='web';
						                            params['state']=_Textobj.attr('id');
						                            params['csrf_token']=$.cookie("csrf_cookie");
						                            $.ajax({
						                              url: pageMainUrl+'ApiUser/getStateData', 
						                              data: params, 
						                              type: 'POST', 
						                              dataType: 'json', 
						                              success: function(result){
						                                $("#StateName").html(result.data.all.StateName);
                                                        $("#LrBaseLine").html(result.data.all.LrBaseLine);
                                                        $("#OtbaseLine").html(result.data.all.OtbaseLine);
														//$("#AllFacilities").html(result.data.all.Facilities);
														$("#AllAppliedLR").html(result.data.all.AppliedLR);
														$("#AllAppliedOT").html(result.data.all.AppliedOT);
														//$("#AllInprocessLR").html(result.data.all.InprocessLR);
														//$("#AllInprocessOT").html(result.data.all.InprocessOT);
														$("#AllCertifiedLR").html(result.data.all.CertifiedLR);
														$("#AllCertifiedOT").html(result.data.all.CertifiedOT);
														//$("#AllStateappliedLR").html(result.data.all.StateappliedLR);
														//$("#AllStateappliedOT").html(result.data.all.StateappliedOT);
														//$("#AllStateInprocessLR").html(result.data.all.StateInprocessLR);
														//$("#AllStateInprocessOT").html(result.data.all.StateInprocessOT);
														$("#AllStatecertifiedLR").html(result.data.all.StatecertifiedLR);
														$("#AllStatecertifiedOT").html(result.data.all.StatecertifiedOT);

														$("#AsFacilities").html(result.data.aspirational.Facilities);
                                                        $("#AsLrBaseLine").html(result.data.aspirational.LrBaseLine);
                                                        $("#AsOtbaseLine").html(result.data.aspirational.OtbaseLine);
														$("#AsAppliedLR").html(result.data.aspirational.AppliedLR);
														$("#AsAppliedOT").html(result.data.aspirational.AppliedOT);
														//$("#AsInprocessLR").html(result.data.aspirational.InprocessLR);
														//$("#AsInprocessOT").html(result.data.aspirational.InprocessOT);
														$("#AsCertifiedLR").html(result.data.aspirational.CertifiedLR);
														$("#AsCertifiedOT").html(result.data.aspirational.CertifiedOT);
														$("#AsStateappliedLR").html(result.data.aspirational.StateappliedLR);
														$("#AsStateappliedOT").html(result.data.aspirational.StateappliedOT);
														//$("#AsStateInprocessLR").html(result.data.aspirational.StateInprocessLR);
														//$("#AsStateInprocessOT").html(result.data.aspirational.StateInprocessOT);
														$("#AsStatecertifiedLR").html(result.data.aspirational.StatecertifiedLR);
														$("#AsStatecertifiedOT").html(result.data.aspirational.StatecertifiedOT);
						                                                                   
						                                }
						                              });
						                            });

			    									if(injsconfig[id].target!=="none") {
			    										_Textobj.mousedown(function() {
			    											jQuery("#"+id).css( {
			    												"fill": injsconfig[id].downColor
			    											}
			    											)
			    										}
			    										)
			    									}
			    									_Textobj.mouseup(function() {
			    										jQuery("#"+id).css( {
			    											"fill": injsconfig[id].overColor
			    										}
			    										);
			    										if(injsconfig[id].target==="new_window") {
			    											window.open(injsconfig[id].url)
			    										}
			    										else if(injsconfig[id].target==="same_window") {
			    											window.parent.location.href=injsconfig[id].url
			    										}
			    										else if(injsconfig[id].target==="modal") {
			    											jQuery(injsconfig[id].url).modal("show")
			    										}
			    									}
			    									);
			    									_Textobj.mousemove(function(e) {
			    										var x=e.pageX+10, y=e.pageY+15;
			    										var tipw=jQuery("#jstip").outerWidth(), tiph=jQuery("#jstip").outerHeight(), x=(x+tipw>jQuery(document).scrollLeft()+jQuery(window).width())?x-tipw-(20*2): x;
			    										y=(y+tiph>jQuery(document).scrollTop()+jQuery(window).height())?jQuery(document).scrollTop()+jQuery(window).height()-tiph-10: y;
			    										jQuery("#jstip").css( {
			    											left: x, top: y
			    										}
			    										)
			    									}
			    									);
			    									if(isTouchEnabled()) {
			    										_Textobj.on("touchstart", function(e) {
			    											var touch=e.originalEvent.touches[0];
			    											var x=touch.pageX+10, y=touch.pageY+15;
			    											var tipw=jQuery("#jstip").outerWidth(), tiph=jQuery("#jstip").outerHeight(), x=(x+tipw>jQuery(document).scrollLeft()+jQuery(window).width())?x-tipw-(20*2): x;
			    											y=(y+tiph>jQuery(document).scrollTop()+jQuery(window).height())?jQuery(document).scrollTop()+jQuery(window).height()-tiph-10: y;
			    											jQuery("#"+id).css( {
			    												"fill": injsconfig[id].downColor
			    											}
			    											);
			    											jQuery("#jstip").show().html(injsconfig[id].hover);
			    											jQuery("#jstip").css( {
			    												left: x, top: y
			    											}
			    											)
			    										}
			    										);
			    										_Textobj.on("touchend", function() {
			    											jQuery("#"+id).css( {
			    												"fill": injsconfig[id].upColor
			    											}
			    											);
			    											if(injsconfig[id].target==="new_window") {
			    												window.open(injsconfig[id].url)
			    											}
			    											else if(injsconfig[id].target==="same_window") {
			    												window.parent.location.href=injsconfig[id].url
			    											}
			    											else if(injsconfig[id].target==="modal") {
			    												jQuery(injsconfig[id].url).modal("show")
			    											}
			    										}
			    										)
			    									}
			    								}
			    							}

			    							var pins_config= {
			    								"pins":[ {
			    									"shape": "square", "hover": "<b><u>DELHI</u></b><br>Write any text and load images<br><img src='assets/images/example.png'>", "pos_X": 185, "pos_Y": 195, "size": 18, "outline": "#000080", "upColor": "#1a1aff", "overColor": "#66d9ff", "url": "https://www.html5interactivemaps.com/", "target": "new_window", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "<b><u>BANGALORE</u></b><br><span style='color: #bcbcbc;'>Street Address:</span><br>&nbsp;321 Example, Address 54321<br><span style='color: #bcbcbc;'>Telephone:</span><br>&nbsp;(256) 555-4321 / (256) 555-1234", "pos_X": 189, "pos_Y": 524, "size": 20, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "<b><u>MUMBAI</u></b><br><span style='color: #999;'>Click to open a modal window!</span><br><span style='color: #ff6666;'><b>Modal Window Option is Compatible<br> with Bootstrap Only.</b></span>", "pos_X": 100, "pos_Y": 405, "size": 16, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "url": "#mymodal", "target": "modal", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "<b><u>HYDERABAD</u></b><br><span style='color: #999;'>*Click to open a webpage*</span>", "pos_X": 208, "pos_Y": 424, "size": 14, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "AHMEDABAD", "pos_X": 94, "pos_Y": 313, "size": 14, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "SURAT", "pos_X": 100, "pos_Y": 349, "size": 14, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "KOLKATA", "pos_X": 397, "pos_Y": 310, "size": 14, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "BLANK8", "pos_X": 20, "pos_Y": 350, "size": 0, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "BLANK9", "pos_X": 20, "pos_Y": 400, "size": 0, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "BLANK10", "pos_X": 50, "pos_Y": 400, "size": 0, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "BLANK11", "pos_X": 100, "pos_Y": 400, "size": 0, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "BLANK12", "pos_X": 150, "pos_Y": 400, "size": 0, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "BLANK13", "pos_X": 200, "pos_Y": 400, "size": 0, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "BLANK14", "pos_X": 250, "pos_Y": 400, "size": 0, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								,
			    								{
			    									"shape": "circle", "hover": "BLANK15", "pos_X": 300, "pos_Y": 400, "size": 0, "outline": "#660000", "upColor": "#e60000", "overColor": "#ffd480", "active": !0
			    								}
			    								]
			    							}

			    							;
			    							function isTouchEnabled() {
			    								return(("ontouchstart" in window)||(navigator.MaxTouchPoints>0)||(navigator.msMaxTouchPoints>0))
			    							}


			    							function injsAddEvent(id) {
			    								var obj=jQuery("#injspins_"+id);
			    								if(pins_config.pins[id].active===!0) {
			    									obj.attr( {
			    										"cursor": "pointer"
			    									}
			    									);
			    									obj.hover(function() {
			    										jQuery("#jstip").show().html(pins_config.pins[id].hover);
			    										obj.css( {
			    											"fill": pins_config.pins[id].overColor
			    										}
			    										)
			    									}
			    									, function() {
			    										jQuery("#jstip").hide();
			    										obj.css( {
			    											"fill": pins_config.pins[id].upColor
			    										}
			    										)
			    									}
			    									);
			    									obj.mouseup(function() {
			    										obj.css( {
			    											"fill": pins_config.pins[id].overColor
			    										}
			    										);
			    										if(pins_config.pins[id].target==="new_window") {
			    											window.open(pins_config.pins[id].url)
			    										}
			    										else if(pins_config.pins[id].target==="same_window") {
			    											window.parent.location.href=pins_config.pins[id].url
			    										}
			    										else if(pins_config.pins[id].target==="modal") {
			    											jQuery(pins_config.pins[id].url).modal("show")
			    										}
			    									}
			    									);
			    									obj.mousemove(function(e) {
			    										var x=e.pageX+10, y=e.pageY+15;
			    										var tipw=jQuery("#jstip").outerWidth(), tiph=jQuery("#jstip").outerHeight(), x=(x+tipw>jQuery(document).scrollLeft()+jQuery(window).width())?x-tipw-(20*2): x;
			    										y=(y+tiph>jQuery(document).scrollTop()+jQuery(window).height())?jQuery(document).scrollTop()+jQuery(window).height()-tiph-10: y;
			    										jQuery("#jstip").css( {
			    											left: x, top: y
			    										}
			    										)
			    									}
			    									);
			    									if(isTouchEnabled()) {
			    										obj.on("touchstart", function(e) {
			    											var touch=e.originalEvent.touches[0];
			    											var x=touch.pageX+10, y=touch.pageY+15;
			    											var tipw=jQuery("#jstip").outerWidth(), tiph=jQuery("#jstip").outerHeight(), x=(x+tipw>jQuery(document).scrollLeft()+jQuery(window).width())?x-tipw-(20*2): x;
			    											y=(y+tiph>jQuery(document).scrollTop()+jQuery(window).height())?jQuery(document).scrollTop()+jQuery(window).height()-tiph-10: y;
			    											jQuery("#jstip").show().html(pins_config.pins[id].hover);
			    											jQuery("#jstip").css( {
			    												left: x, top: y
			    											}
			    											)
			    										}
			    										);
			    										obj.on("touchend", function() {
			    											jQuery("#"+id).css( {
			    												"fill": pins_config.pins[id].upColor
			    											}
			    											);
			    											if(pins_config.pins[id].target==="new_window") {
			    												window.open(pins_config.pins[id].url)
			    											}
			    											else if(pins_config.pins[id].target==="same_window") {
			    												window.parent.location.href=pins_config.pins[id].url
			    											}
			    											else if(pins_config.pins[id].target==="modal") {
			    												jQuery(pins_config.pins[id].url).modal("show")
			    											}
			    										}
			    										)
			    									}
			    								}
			    							}
			    						<?php } ?>        	
			    					</script>
			    				</div><!--mapwrapper-->
			    			</div>
			    		</div>
			    		 		    		
			    	</div>
                    <div class="col-md-5 col-sm-12 col-xs-12">
                            <div class="widget1">
                                <h4 id="StateName">All</h4>                     
                                 <h1 id="AllFacilities"><?php echo $totalLaQshya=isset($data['state_static_data']['total'])?$data['state_static_data']['total']:'0'; ?></h1>
                                    <h3>Total LaQshya Facilities </h3>
                                    <div class="clearfix"></div>
                            </div>

                            <div class="win1s ">
                                <h4 id="StateName">Baseline Assessment</h4>
                                <ul>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span>  Baseline LR Assessment  <em id="LrBaseLine"> 0</em> </li>  
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span>  Baseline OT Assessment <em id="OtbaseLine"> 0</em> </li>                                     
                                </ul>
                            </div>

                            <div class="win1s">
                                <h4 id="StateName">National Certification</h4>
                                <ul>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Applied For LR <em id="AllAppliedLR"> 0</em> </li>    
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Applied For OT <em  id="AllAppliedOT"> 0</em> </li>
                                    <!-- <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> In-process For LR <em id="AllInprocessLR"> 0</em> </li>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> In-process For OT <em id="AllInprocessOT"> 0</em> </li> -->
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Certified LR <em id="AllCertifiedLR"> 0</em> </li>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Certified Maternity OT <em id="AllCertifiedOT"> 0</em> </li>

                                </ul>   


                            </div>



                            <div class="win1s">
                                <h4 id="StateName">State Certification</h4>
                                <ul>
                                    <!-- <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Applied For LR <em  id="AllStateappliedLR"> 0</em> </li>  
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Applied For OT <em id="AllStateappliedOT" > 0</em> </li> -->
                                    <!-- <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> In-process For LR <em id="AllStateInprocessLR" > 0</em> </li>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> In-process For OT <em id="AllStateInprocessOT" > 0</em> </li> -->
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Certified LR <em id="AllStatecertifiedLR"> 0</em> </li>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Certified Maternity OT <em id="AllStatecertifiedOT"> 0</em> </li>

                                </ul>   


                            </div>
                     </div>












<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="row">
        <div class="col-md-3 col-sm-3 col-xs-3">
                            <div class="widget1 widget1-m-h">
                                <h4>Total Aspirational District</h4>                     
                                 <h1 id="AsFacilities">0</h1>
                                    <!-- <h3>Aspirational District (Total) </h3>-->
                                    <div class="clearfix"></div>
                            </div>
                           </div>

                          <div class="col-md-3 col-sm-3 col-xs-3">
                            <div class="win1s wind1s">
                                <h4 id="StateName">Baseline Assessment</h4>
                                <ul>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span>   Baseline LR Assessment <em id="AsLrBaseLine"> 0</em> </li> 
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span>   Baseline OT Assessment <em  id="AsOtbaseLine"> 0</em> </li>
                                </ul>
                            </div>
                            </div>

                          <div class="col-md-3 col-sm-3 col-xs-3">
                            <div class="win1s">
                                <h4 id="StateName">National Certification</h4>
                                <ul>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Applied For LR <em id="AsAppliedLR"> 0</em> </li> 
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Applied For OT <em  id="AsAppliedOT"> 0</em> </li>
                                    <!-- <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> In-process For LR <em id="AsInprocessLR"> 0</em> </li>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> In-process For OT <em id="AsInprocessOT"> 0</em> </li> -->
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Certified LR <em id="AsCertifiedLR"> 0</em> </li>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Certified Maternity OT <em id="AsCertifiedOT"> 0</em> </li>

                                </ul>   


                            </div>
                            </div>



                         <div class="col-md-3 col-sm-3 col-xs-3">
                            <div class="win1s">
                                <h4 id="StateName">State Certification</h4>
                                <ul>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Applied For LR <em  id="AsStateappliedLR"> 0</em> </li>   
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Applied For OT <em id="AsStateappliedOT" > 0</em> </li>
                                    <!-- <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> In-process For LR <em id="AsStateInprocessLR" > 0</em> </li>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> In-process For OT <em id="AsStateInprocessOT" > 0</em> </li> -->
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Certified LR <em id="AsStatecertifiedLR"> 0</em> </li>
                                    <li><span><i class="fa fa-angle-right" aria-hidden="true"></i></span> Certified Maternity OT <em id="AsStatecertifiedOT"> 0</em> </li>

                                </ul>   


                            </div>
                          </div>
                    </div>
</div>

 <!--
			    	<div class="col-md-5 col-sm-12 col-xs-12">
			    		<div class="country_boxes">

			    		<div class="col-md-12 col-xs-12">
			    			<div class="map_box_dash">
			    				<h2><span id="StateName">All</span></h2>
			    				<p>Total LaQshya Facilities: <span id="AllFacilities">0</span></p>

			    				<h2>National Certification</h2>
			    				<p>Applied For LR: <span id="AllAppliedLR">0</span></p>
			    				<p>Applied For OT: <span id="AllAppliedOT">0</span></p>
			    				<p>In-process For LR: <span id="AllInprocessLR">0</span></p>
			    				<p>In-process For OT: <span id="AllInprocessOT">0</span></p>
			    				<p>Certified LR: <span id="AllCertifiedLR">0</span></p>
			    				<p>Certified Maternity OT: <span id="AllCertifiedOT">0</span></p>

			    				<h2>State Certification</h2>
			    				<p>Applied For LR: <span id="AllStateappliedLR">0</span></p>
			    				<p>Applied For OT: <span id="AllStateappliedOT">0</span></p>
			    				<p>In-process For LR: <span id="AllStateInprocessLR">0</span></p>
			    				<p>In-process For OT: <span id="AllStateInprocessOT">0</span></p>
			    				<p>Certified LR: <span id="AllStatecertifiedLR">0</span></p>
			    				<p>Certified Maternity OT: <span id="AllStatecertifiedOT">0</span></p>			    				
			    				<h2>Aspirational District</h2>
			    				<p>Total LaQshya Facilities: <span id="AsFacilities">0</span></p>

			    				<h2>National Certification</h2>
			    				<p>Applied For LR: <span id="AsAppliedLR">0</span></p>
			    				<p>Applied For OT: <span id="AsAppliedOT">0</span></p>
			    				<p>In-process For LR: <span id="AsInprocessLR">0</span></p>
			    				<p>In-process For OT: <span id="AsInprocessOT">0</span></p>
			    				<p>Certified LR: <span id="AsCertifiedLR">0</span></p>
			    				<p>Certified Maternity OT: <span id="AsCertifiedOT">0</span></p>

			    				<h2>State Certification</h2>
			    				<p>Applied For LR: <span id="AsStateappliedLR">0</span></p>
			    				<p>Applied For OT: <span id="AsStateappliedOT">0</span></p>
			    				<p>In-process For OT: <span id="AsStateInprocessLR">0</span></p>
			    				<p>In-process For OT: <span id="AsStateInprocessOT">0</span></p>
			    				<p>Certified LR: <span id="AsStatecertifiedLR">0</span></p>
			    				<p>Certified Maternity OT: <span id="AsStatecertifiedOT">0</span></p>

			    			</div>
			    		</div>
			    	</div>
			    </div> -->
                 </div>
			  </div>
			</div>
		</div>
		</div>  
			<!-- map end-->

            


            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="x_panel">
                    <div class="x_title">
                      <h2>LaQshya Status</h2>
                        <ul class="nav navbar-right panel_toolbox">
                    <li>
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </li>
                  </ul>
                    </div>
                    <div class="x_content servi-list-1">
                        <div class="row" >
                                <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['stateOr']['stateOrFac'])?$data['box']['stateOr']['stateOrFac']:'0'; 
                                                    $total=!empty($data['box']['stateOr']['Facilities'])?$data['box']['stateOr']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>State Orientation</h5>
                                                       
                                                   
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['State Orientation', 'Percentage'],
                                                      ['Completed', hello],
                                                      ['Total', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>







                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['StateApLR']['StateappliedLR'])?$data['box']['StateApLR']['StateappliedLR']:'0';
                                                    $total=!empty($data['box']['StateApLR']['Facilities'])?$data['box']['StateApLR']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman1" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities Applied For State Certification For LR</h5>
                                                       
                                                    
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities Applied For State Certification For LR', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman1'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                        $dataGet=!empty($data['box']['StateApOT']['StateappliedOT'])?$data['box']['StateApOT']['StateappliedOT']:'0';
                                                        $total=!empty($data['box']['StateApOT']['Facilities'])?$data['box']['StateApOT']['Facilities']:'0';
                                                        $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                        ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman2" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities Applied For State Certification For OT</h5>
                                                       
                                                     
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities Applied For State Certification For OT', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman2'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>


                                    <!-- <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['StateIpLR']['StateInprocessLR'])?$data['box']['StateIpLR']['StateInprocessLR']:'0';
                                                    $total=!empty($data['box']['StateIpLR']['Facilities'])?$data['box']['StateIpLR']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);

                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman1-StateInprocessLR" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities In-process For State Certification For LR</h5>
                                                       
                                                    
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities In-process For State Certification For LR', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman1-StateInprocessLR'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div> -->



                                    <!-- <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                        $dataGet=!empty($data['box']['StateIpOT']['StateInprocessOT'])?$data['box']['StateIpOT']['StateInprocessOT']:'0';
                                                        $total=!empty($data['box']['StateIpOT']['Facilities'])?$data['box']['StateIpOT']['Facilities']:'0';
                                                        $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                        ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman2-StateInprocessOT" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities In-process For State Certification For OT</h5>
                                                       
                                                     
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities In-process For State Certification For OT', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman2-StateInprocessOT'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div> -->



                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                        $dataGet=!empty($data['box']['StatecLR']['StatecertifiedLR'])?$data['box']['StatecLR']['StatecertifiedLR']:'0';
                                                        $total=!empty($data['box']['StatecLR']['Facilities'])?$data['box']['StatecLR']['Facilities']:'0';
                                                        $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                        ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman3" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                      
                                                        <h5>Facilities Received State Certification For LR </h5>
                                                       
                                                    
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities Received State Certification For LR', 'Percentage'],
                                                      ['Received', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman3'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>




                                    <!-- <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['StatecOT']['StatecertifiedOT'])?$data['box']['StatecOT']['StatecertifiedOT']:'0';
                                                    $total=!empty($data['box']['StatecOT']['Facilities'])?$data['box']['StatecOT']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman4" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities Received State Certification For OT </h5>
                                                       
                                                     
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php  echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities Received State Certification For OT', 'Percentage'],
                                                      ['Received', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman4'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div> -->



                                    <!-- <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['ApLR']['AppliedLR'])?$data['box']['ApLR']['AppliedLR']:'0';
                                                    $total=!empty($data['box']['ApLR']['Facilities'])?$data['box']['ApLR']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman5" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities Applied For National Certification For LR </h5>
                                                       
                                                     
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php  echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities Applied For National Certification For LR', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman5'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div> -->




                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['ApOT']['AppliedOT'])?$data['box']['ApOT']['AppliedOT']:'0';
                                                    $total=!empty($data['box']['ApOT']['Facilities'])?$data['box']['ApOT']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman6" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities Applied For National Certification For OT </h5>
                                                       
                                                     
                                                </div>

 
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php  echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities Applied For National Certification For OT', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman6'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['IpLR']['InprocessLR'])?$data['box']['IpLR']['InprocessLR']:'0';
                                                    $total=!empty($data['box']['IpLR']['Facilities'])?$data['box']['IpLR']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman5-InprocessLR" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities In-process For National Certification For LR </h5>
                                                       
                                                     
                                                </div>




                                               
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php  echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities In-process For National Certification For LR', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman5-InprocessLR'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>




                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['IpOT']['InprocessOT'])?$data['box']['IpOT']['InprocessOT']:'0';
                                                    $total=!empty($data['box']['IpOT']['Facilities'])?$data['box']['IpOT']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman6-InprocessOT" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities In-process For National Certification For OT </h5>
                                                       
                                                     
                                                </div>

 
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php  echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities In-process For National Certification For OT', 'Percentage'],
                                                      ['Applied', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman6-InprocessOT'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['cLR']['CertifiedLR'])?$data['box']['cLR']['CertifiedLR']:'0';
                                                    $total=!empty($data['box']['cLR']['Facilities'])?$data['box']['cLR']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman7" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class="par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities Received National Certification For LR </h5>
                                                       
                                                     
                                                </div>

 
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php  echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities Received National Certification For LR', 'Percentage'],
                                                      ['Received', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman7'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="col-md-4">
                                        <div class="analytics-sparkle-line chart-around-value reso-mg-b-30">
                    
                                            <div class="analytics-content" >
                                                  <?php 
                                                    $dataGet=!empty($data['box']['cOT']['CertifiedOT'])?$data['box']['cOT']['CertifiedOT']:'0';
                                                    $total=!empty($data['box']['cOT']['Facilities'])?$data['box']['cOT']['Facilities']:'0';
                                                    $per=round((($dataGet/$total)*100),2);
                                                    if($per==0){
                                                            $classShow='faild';
                                                            $classCode='#f00';          
                                                    } else {
                                                        switch ($per) {
                                                            case $per<=30:
                                                                $classShow='faild';
                                                                $classCode='#f00';
                                                                break;
                                                            case $per<=50 && $per>30:
                                                                $classShow='inprocess';
                                                                $classCode='#f9bb07';
                                                                break;              
                                                            default:
                                                                $classShow='success';
                                                                $classCode='#0d9c26';
                                                                break;
                                                        }                               
                                                    }
                                                    ?>

                                                 <div class="half-chart-line">
                                                    <div id="pacman8" class="chart-srou-1" style="width:150px; height:150px;">
                                                        
                                                    </div>
                                                    <span class=" par-cart-fixe <?php echo $classShow;  ?>"><?php echo $per; ?>%</span>
                                                 </div>


                                                <div class="chart-new-link1"> 
                                                     
                                                        <h5>Facilities Received National Certification For OT </h5>
                                                       
                                                     
                                                </div>

 
                                 

                                                <script type="text/javascript">
                                                     google.charts.load("current", {packages:["corechart"]});
                                                  google.charts.setOnLoadCallback(drawChart);
                                                  function drawChart() {
                                                    var hello = <?php  echo $dataGet; ?>;
                                                    var hello1 = <?php echo $total; ?>;
                                                    
                                                    var data = google.visualization.arrayToDataTable([
                                                      ['Facilities Received National Certification For OT', 'Percentage'],
                                                      ['Received', hello],
                                                      ['Total ', hello1],
                                                      
                                                    ]);

                                                    var options = {
                                                      pieHole: 0.7,
                                                      tooltip: {text: 'value'},
                                                      legend: 'none',
                                                      
                                                      pieSliceText: 'none',
                                                      pieStartAngle: 270,
                                                      slices: {
                                                        0: { color: '<?php echo $classCode; ?>' },
                                                        1: { color: '#d3d3d3'},
                                                        
                                                      },
                                                      backgroundColor: { fill:'transparent' },

                                                      
         
                                                      chartArea: {
                                                        left: 5,
                                                        top: 10,
                                                        right:0,
                                                        
                                                        width: 150,  height:150,
                                                        backgroundColor: {
                                                                stroke: '#fff',
                                                                strokeWidth: 1
                                                            }
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('pacman8'));
                                                    chart.draw(data, options);
                                                  }
                                                </script>
                                            </div>
                                        </div>
                                    </div>



 

                                    </div>




                    </div>
                  </div>
                </div>
            </div>


            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                    <a href="#" id="view-more-btn" class="view-more-btn " title="View All Dashboard Sections"><i class="fa fa-arrow-down hvr-bob" aria-hidden="true"></i> View more</a> 
                </div>
            </div>

<div class="hidden-dash-bard"> 


    <!-- progress bar started -->
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                  <div class="x_panel  bg-proce-bar-tag">
                    <div class="x_title">
                      <h2>LaQshya Program Indicators- Status </h2>
                      <ul class="nav navbar-right panel_toolbox">
                        <li>
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                        </li>
                      </ul>
                        <div class="pull-right select-ditc-1">
                          <select class="" id="district" onchange="change_district(); monthly_indicator_fun()">
                            <option value='' >Select District</option>
                            <?php 
                            if(isset($data['districts'])){
                              foreach ($data['districts'] as $keyD => $valueD) {
                                echo "<option value='".$keyD."' >".$valueD."</option>";
                              }                                
                            }
                            ?>
                          </select>
                          <select class="" id="facility" onchange="monthly_indicator_fun()">
                            <option value='' >Select Facility</option>
                          </select>
                          <select class="" id="monthly_indicator_date" onchange="monthly_indicator_fun()">
                            <?php 
                            $month=date('Y').'-'.date('m');
                            $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
                            foreach ($this->config->item('years') as $keyYear => $valueYear) {
                              foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
                                $monthVal=$valueYear."-".$keyMonth;
                                if($monthVal==$monthDefault){
                                  $seletedText=" selected='selected' ";
                                } else {
                                  $seletedText='';
                                }
                                echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
                                if($monthVal==$month){
                                  break 2;
                                }
                              }
                            } 
                            ?>
                          </select>
                        </div>
                      <div class="clearfix"></div>
                    </div>
                    <div class="x_content">  
                        <div id="monthly_indicator_loader" class="loader-s" style="display: none;"></div>
                        <!-- ministry,state,district started -->
                        <div id="otherIndicator" class="col-md-12">
                            <div class="bar-list-process">
                            <div class="row">
                                    <div class="col-md-6">

                                       <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores</p></h3>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="progress-outer">
                                            <div class="progress" id="val_a">
                                                <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                                <div class="progress-value"><span>0</span>%</div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots</p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_b">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI</p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_c">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage of deliveries are attended by a birth companion</p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_d">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"> <i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage deliveries are conducted using safe birth checklist in Labour Room</p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_e">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage of deliveries are conducted using Safe Surgery checklist in Maternity OT</p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer" id="val_f">
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage of deliveries for which Partograph is generated using real-time information in at least</p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_g">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage breastfeeding within 1 hour</p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_h">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Neonatal asphyxia rate in Inborn Babies</p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_i">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Neonatal sepsis rate in-born babies</p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_j">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Surgical Site infection Rate in Maternity OT    </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_k">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Antenatal corticosteroid administration rate in case in preterm labour </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_l">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Pre-eclampsia, eclampsia & PIH related mortality</p> </h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_m">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> APH/PPH related mortality </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_n">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility Labour Room is reorganized as labour room standardization guidelines </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_o">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility Labour room has staffing as per defined norms </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_p">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage of Women, administered Oxytocin, immediately after birth </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_q">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> OSCE Score </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_r">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility conducts referral audit on Monthly basis </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_s">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility conducts Maternal death, Neonatal death and near-miss on monthly basis</p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_t">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Facility report zero stock outs in Labour Room & Maternity OT</p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_u">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Still Birth Rate    </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_v">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Percentage of beneficiaries who were either satisfied or highly satisfied   </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_w">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> functional Obs ICU/Hybrid ICU/HDU?  </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_x">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Microbiological Surveillance in OT & LR </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_y">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Labour Room Quality Score Improvement from Baseline </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_z">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="progress-title"><i class="fa fa-circle-o" aria-hidden="true"></i><p> Maternity OT Quality Score Improvement from Baseline    </p></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="progress-outer">
                                        <div class="progress" id="val_za">
                                            <div class="progress-bar progress-bar-striped progress-bar-info" style="width:0%;"></div>
                                            <div class="progress-value"><span>0</span>%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        <!-- ministry,state,district ended -->
                        <!-- facility started -->
                        <div id="facilityIndicator" class="col-md-12" style="display: none;">
                          <div id="faclity_monthly_indicator">
                                <table id="datatable" class="table table-striped table-bordered my-table-width" width="100%">
                                    <thead>
                                        <tr>
                                          <th>Indicator</th>
                                          <th>Current Status</th>
                                          <th>Target</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                            <td title="Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores">Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores</td>
                                            <td id="a"></td>
                                            <td>Baseline Assessment & Reporting done</td>
                                        </tr>
                                        <tr>
                                            <td title="Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots">Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots</td>
                                            <td id="b"></td>
                                            <td>At least one Meeting in month</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI">Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI</td>
                                            <td id="c"></td>
                                            <td>All staff Trained </td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage of deliveries are attended by a birth companion">Percentage of deliveries are attended by a birth companion</td>
                                            <td id="d"></td>
                                            <td>90%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage deliveries are conducted using safe birth checklist in Labour Room">Percentage deliveries are conducted using safe birth checklist in Labour Room </td>
                                            <td id="e"></td>
                                            <td>90%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage of deliveries are conducted using  Safe Surgery checklist in Maternity OT">Percentage of deliveries are conducted using  Safe Surgery checklist in Maternity OT</td>
                                            <td id="f"></td>
                                            <td>90%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage of deliveries for which Partograph is generated using real-time information in at least">Percentage of deliveries for which Partograph is generated using real-time information in at least </td>
                                            <td id="g"></td>
                                            <td>90%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage breastfeeding within 1 hour">Percentage breastfeeding within 1 hour </td>
                                            <td id="h"></td>
                                            <td>80%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Neonatal asphyxia rate in Inborn Babies"> Neonatal asphyxia rate in Inborn Babies </td>
                                            <td id="i"></td>
                                            <td>80%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Neonatal sepsis rate in-born babies"> Neonatal sepsis rate in-born babies </td>
                                            <td id="j"></td>
                                            <td>80%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Surgical Site infection Rate in Maternity OT"> Surgical Site infection Rate in Maternity OT </td>
                                            <td id="k"></td>
                                            <td>5%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Antenatal corticosteroid administration rate in case in preterm labour">Antenatal corticosteroid administration rate in case in preterm labour</td>
                                            <td id="l"></td>
                                            <td>80%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Pre-eclampsia, eclampsia & PIH related mortality">Pre-eclampsia, eclampsia & PIH related mortality</td>
                                            <td id="m"></td>
                                            <td>0</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="APH/PPH related mortality"> APH/PPH related mortality </td>
                                            <td id="n"></td>
                                            <td>0</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility Labour Room is reorganized as labour room standardization guidelines">Facility Labour Room is reorganized as labour room standardization guidelines</td>
                                            <td id="o"></td>
                                            <td>Reorganized</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility Labour room has staffing as per defined norms">Facility Labour room has staffing as per defined norms </td>
                                            <td id="p"></td>
                                            <td>Full Staffing </td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage of Women, administered Oxytocin, immediately after birth.">Percentage of Women, administered Oxytocin, immediately after birth.</td>
                                            <td id="q"></td>
                                            <td>100%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="OSCE Score">OSCE Score </td>
                                            <td id="r"></td>
                                            <td>80%</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility conducts referral audit on Monthly basis">Facility conducts referral audit on Monthly basis</td>
                                            <td id="s"></td>
                                            <td>Monthly</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility conducts Maternal death, Neonatal death and near-miss on monthly basis">Facility conducts Maternal death, Neonatal death and near-miss on monthly basis</td>
                                            <td id="t"></td>
                                            <td>Monthly</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Facility report zero stock outs in Labour Room & Maternity OT">Facility report zero stock outs in Labour Room & Maternity OT</td>
                                            <td id="u"></td>
                                            <td>0</td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Still Birth Rate">Still Birth Rate </td>
                                            <td id="v"></td>
                                            <td></td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Percentage of beneficiaries  who were either satisfied or highly satisfied">Percentage of beneficiaries  who were either satisfied or highly satisfied</td>
                                            <td id="w"></td>
                                            <td></td>
                                        </tr>
                                        <tr>                                    
                                            <td title="functional Obs ICU/Hybrid ICU/HDU?">functional Obs ICU/Hybrid ICU/HDU?</td>
                                            <td id="x"></td>
                                            <td></td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Microbiological Surveillance in OT & LR">Microbiological Surveillance in OT & LR </td>
                                            <td id="y"></td>
                                            <td></td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Labour Room Quality Score Improvement from Baseline">Labour Room Quality Score Improvement from Baseline </td>
                                            <td id="z"></td>
                                            <td></td>
                                        </tr>
                                        <tr>                                    
                                            <td title="Maternity OT Quality Score Improvement from Baseline">Maternity OT Quality Score Improvement from Baseline </td>
                                            <td id="za"></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                    </tbody>
                                </table>                    
                          </div>                            
                        </div>
                        <!-- facility ended -->

                    </div>
                    </div>
                </div>
            </div>
            <!-- progress bar ended -->

            
			<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>LaQshya In Aspirational District</h2>
			        <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			    </div>
			    <div class="x_content servi-list-1">
			    	<div class="row" >
			    			<div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes"; ?>">
				                                 <h2 id="AsFacilitiesBox">0</h2>
                                                <h5>Facilities In Aspirational District</h5>
				                                
				                               
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/laqshyabaselr/aspirational"; ?>">
                                                <h2 id="AsLrBaseLineBox">0</h2>
				                                <h5>Facilities Baselne Assesment For LR</h5>
				                                
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/laqshyabaseot/aspirational"; ?>">
                                                <h2 id="AsOtbaseLineBox">0</h2>
				                                <h5>Facilities Baselne Assesment For OT</h5>
				                                
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>

 



			                    </div>




			    </div>
			  </div>
			</div>
		</div>


		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>National Certification Status in Aspirational District</h2>
			        <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			    </div>
			    <div class="x_content servi-list-1">
			    	<div class="row" >
			    			<div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=lr&level=national&stage=applied"; ?>">
                                                 <h2 id="AsAppliedLRBox">0</h2>
				                                <h5>Facilities Applied For LR Certification</h5>
				                                
				                               
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=ot&level=national&stage=applied"; ?>">
                                                 <h2 id="AsAppliedOTBox">0</h2>
				                                <h5>Facilities Applied For OT Certification</h5>
				                              
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=lr&level=national&stage=inprocess"; ?>">
                                                <h2 id="AsInprocessLRBox">0</h2>
				                                <h5>Facilities In-process For LR Certification</h5>
				                                
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=ot&level=national&stage=inprocess"; ?>">
                                                <h2 id="AsInprocessOTBox">0</h2>
				                                <h5>Facilities In-process For OT Certification</h5>
				                                
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=lr&level=national&stage=received"; ?>">
				                                <h2 id="AsCertifiedLRBox">0</h2>
                                                <h5>Facilities Received LR Certification</h5>
				                                
			                                </a>
			                            </div>
			                        </div>
			                    </div>



			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=ot&level=national&stage=received"; ?>">
				                                <h2 id="AsCertifiedOTBox">0</h2>
                                                <h5>Facilities Received OT Certification</h5>
				                                
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


 



			                    </div>




			    </div>
			  </div>
			</div>
		</div>



 
			<!-- box started  
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>National Certification Status in Aspirational District</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			        <li class="dropdown">
			          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
			          <ul class="dropdown-menu" role="menu">
			            <li><a href="#">Settings 1</a>
			            </li>
			            <li><a href="#">Settings 2</a>
			            </li>
			          </ul>
			        </li>
			        <li><a class="close-link"><i class="fa fa-close"></i></a>
			        </li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">
					<div class="col-md-3 col-xs-6">
							<div class="dash_box1">
								<p><a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=lr&level=national&stage=applied"; ?>">Facilities Applied For LR Certification</a></p>
								<h2 id="AsAppliedLRBox">0</h2>
							</div>
					</div>
					<div class="col-md-3 col-xs-6">
							<div class="dash_box1">
								<p><a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=ot&level=national&stage=applied"; ?>">Facilities Applied For OT Certification</a></p>
								<h2 id="AsAppliedOTBox">0</h2>
							</div>
					</div>
					<div class="col-md-3 col-xs-6">
							<div class="dash_box1">
								<p><a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=lr&level=national&stage=inprocess"; ?>">Facilities In-process For LR Certification</a></p>
								<h2 id="AsInprocessLRBox">0</h2>
							</div>
					</div>
					<div class="col-md-3 col-xs-6">
							<div class="dash_box1">
								<p><a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=ot&level=national&stage=inprocess"; ?>">Facilities In-process For OT Certification</a></p>
								<h2 id="AsInprocessOTBox">0</h2>
							</div>
					</div>
					<div class="col-md-3 col-xs-6">
							<div class="dash_box1">
								<p><a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=lr&level=national&stage=received"; ?>">Facilities Received LR Certification</a></p>
								<h2 id="AsCertifiedLRBox">0</h2>
							</div>
					</div>
					<div class="col-md-3 col-xs-6">
							<div class="dash_box1">
								<p><a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=ot&level=national&stage=received"; ?>">Facilities Received OT Certification</a></p>
								<h2 id="AsCertifiedOTBox">0</h2>
							</div>
					</div>

			    </div>
			  </div>
			</div>
			<!-- box end Aspirational -->






		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>State Certification Status in Aspirational District</h2>
			        <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			    </div>
			    <div class="x_content servi-list-1">
			    	<div class="row" >
			    			<div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=lr&level=state&stage=applied"; ?>">
				                                <h5>Facilities Applied For LR Certification</h5>
				                                
				                                <h2 id="AsStateappliedLRBox">0</h2>
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=ot&level=state&stage=applied"; ?>">
				                                <h5>Facilities Applied For OT Certification</h5>
				                               <h2 id="AsStateappliedOTBox">0</h2>
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=lr&level=state&stage=inprocess"; ?>">
				                                <h5>Facilities In-process For LR Certification</h5>
				                                <h2 id="AsStateInprocessLRBox">0</h2>
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=ot&level=state&stage=inprocess"; ?>">
				                                <h5>Facilities In-process For OT Certification</h5>
				                                <h2 id="AsStateInprocessOTBox">0</h2>
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=lr&level=state&stage=received"; ?>">
				                                <h5>Facilities Received LR Certification</h5>
				                                <h2 id="AsStatecertifiedLRBox">0</h2>
			                                </a>
			                            </div>
			                        </div>
			                    </div>



			                    <div class="col-md-4">
			                        <div class="analytics-sparkle-line analytics-content2 reso-mg-b-30">
			 
			                            <div class="analytics-content" >
			                            	<a href="<?php echo base_url(). "user/facilitydata?aspirational=yes&types=ot&level=state&stage=received"; ?>">
				                                <h5>Facilities Received OT Certification</h5>
				                                <h2 id="AsStatecertifiedOTBox">0</h2>
				                                 
			                                </a>
			                            </div>
			                        </div>
			                    </div>


 



			                    </div>




			    </div>
			  </div>
			</div>
		</div>


 

			
		  


			<!-- meter box started  
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>LaQshya Status</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
			        <li class="dropdown">
			          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
			          <ul class="dropdown-menu" role="menu">
			            <li><a href="#">Settings 1</a>
			            </li>
			            <li><a href="#">Settings 2</a>
			            </li>
			          </ul>
			        </li>
			        <li><a class="close-link"><i class="fa fa-close"></i></a>
			        </li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">
					<div class="col-md-4 col-xs-6">
							<div class="dash_box4">
								<p>State Orientation</p>
								<?php 
								$dataGet=!empty($data['box']['stateOr']['stateOrFac'])?$data['box']['stateOr']['stateOrFac']:'0'; 
								$total=!empty($data['box']['stateOr']['Facilities'])?$data['box']['stateOr']['Facilities']:'0';
								$per=round((($dataGet/$total)*100),2);
								?>
								<h2>Total: <?php echo $total; ?></h2>
								<h2>Completed: <?php echo $dataGet; ?></h2>
								<h2>Percentage: <?php echo $per; ?></h2>
							</div>
					</div>
					<div class="col-md-4 col-xs-6">
							<div class="dash_box4">
								<p>Facilities Applied For State Certification For LR</p>
								<?php 
								$dataGet=!empty($data['box']['StateApLR']['StateappliedLR'])?$data['box']['StateApLR']['StateappliedLR']:'0';
								$total=!empty($data['box']['StateApLR']['Facilities'])?$data['box']['StateApLR']['Facilities']:'0';
								$per=round((($dataGet/$total)*100),2);
								?>
								<h2>Total: <?php echo $total; ?></h2>
								<h2>Applied: <?php echo $dataGet; ?></h2>
								<h2>Percentage: <?php echo $per; ?></h2>
							</div>
					</div>
					<div class="col-md-4 col-xs-6">
							<div class="dash_box4">
								<p>Facilities Applied For State Certification For OT</p>
								<?php 
								$dataGet=!empty($data['box']['StateApOT']['StateappliedOT'])?$data['box']['StateApOT']['StateappliedOT']:'0';
								$total=!empty($data['box']['StateApOT']['Facilities'])?$data['box']['StateApOT']['Facilities']:'0';
								$per=round((($dataGet/$total)*100),2);
								?>
								<h2>Total : <?php echo $total; ?></h2>
								<h2>Applied: <?php echo $dataGet; ?></h2>
								<h2>Percentage: <?php echo $per; ?></h2>
							</div>
					</div>
					<div class="col-md-4 col-xs-6">
							<div class="dash_box4">
								<p>Facilities Received State Certification For LR</p>
								<?php 
								$dataGet=!empty($data['box']['StatecLR']['StatecertifiedLR'])?$data['box']['StatecLR']['StatecertifiedLR']:'0';
								$total=!empty($data['box']['StatecLR']['Facilities'])?$data['box']['StatecLR']['Facilities']:'0';
								$per=round((($dataGet/$total)*100),2);
								?>
								<h2>Total : <?php echo $total; ?></h2>
								<h2>Received: <?php echo $dataGet; ?></h2>
								<h2>Percentage: <?php echo $per; ?></h2>
							</div>
					</div>
					<div class="col-md-4 col-xs-6">
							<div class="dash_box4">
								<p>Facilities Received State Certification For OT</p>
								<?php 
								$dataGet=!empty($data['box']['StatecOT']['StatecertifiedOT'])?$data['box']['StatecOT']['StatecertifiedOT']:'0';
								$total=!empty($data['box']['StatecOT']['Facilities'])?$data['box']['StatecOT']['Facilities']:'0';
								$per=round((($dataGet/$total)*100),2);
								?>
								<h2>Total : <?php echo $total; ?></h2>
								<h2>Received: <?php echo $dataGet; ?></h2>
								<h2>Percentage: <?php echo $per; ?></h2>
							</div>
					</div>
					<div class="col-md-4 col-xs-6">
							<div class="dash_box4">
								<p>Facilities Applied For National Certification For LR</p>
								<?php 
								$dataGet=!empty($data['box']['ApLR']['AppliedLR'])?$data['box']['ApLR']['AppliedLR']:'0';
								$total=!empty($data['box']['ApLR']['Facilities'])?$data['box']['ApLR']['Facilities']:'0';
								$per=round((($dataGet/$total)*100),2);
								?>
								<h2>Total : <?php echo $total; ?></h2>
								<h2>Applied: <?php echo $dataGet; ?></h2>
								<h2>Percentage: <?php echo $per; ?></h2>
							</div>
					</div>
					<div class="col-md-4 col-xs-6">
							<div class="dash_box4">
								<p>Facilities Applied For National Certification For OT</p>
								<?php 
								$dataGet=!empty($data['box']['ApOT']['AppliedOT'])?$data['box']['ApOT']['AppliedOT']:'0';
								$total=!empty($data['box']['ApOT']['Facilities'])?$data['box']['ApOT']['Facilities']:'0';
								$per=round((($dataGet/$total)*100),2);
								?>
								<h2>Total : <?php echo $total; ?></h2>
								<h2>Applied: <?php echo $dataGet; ?></h2>
								<h2>Percentage: <?php echo $per; ?></h2>
							</div>
					</div>
					<div class="col-md-4 col-xs-6">
							<div class="dash_box4">
								<p>Facilities Received National Certification For LR</p>
								<?php 
								$dataGet=!empty($data['box']['cLR']['CertifiedLR'])?$data['box']['cLR']['CertifiedLR']:'0';
								$total=!empty($data['box']['cLR']['Facilities'])?$data['box']['cLR']['Facilities']:'0';
								$per=round((($dataGet/$total)*100),2);
								?>
								<h2>Total : <?php echo $total; ?></h2>
								<h2>Received: <?php echo $dataGet; ?></h2>
								<h2>Percentage: <?php echo $per; ?></h2>
							</div>
					</div>
					<div class="col-md-4 col-xs-6">
							<div class="dash_box4">
								<p>Facilities Received National Certification For OT</p>
								<?php 
								$dataGet=!empty($data['box']['cOT']['CertifiedOT'])?$data['box']['cOT']['CertifiedOT']:'0';
								$total=!empty($data['box']['cOT']['Facilities'])?$data['box']['cOT']['Facilities']:'0';
								$per=round((($dataGet/$total)*100),2);
								?>
								<h2>Total : <?php echo $total; ?></h2>
								<h2>Received: <?php echo $dataGet; ?></h2>
								<h2>Percentage: <?php echo $per; ?></h2>
							</div>
					</div>


			    </div>
			  </div>
			</div>
			<!-- meter box ended -->

			<!-- charts box started -->
		<div class="row">
			<div class="col-md-6 col-sm-12 col-xs-12">
			  <div class="x_panel short-panel1">
			    <div class="x_title">
			      <h2>Maternal Death Cause</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			      <div class="pull-right">
					<select class="dateChangeClass" id="piechart_MatDeath_date" data-changeFunction="piechart_MatDeath" data-msg="piechart_MatDeath_msg" data-loader="piechart_MatDeath_loader">
						<?php 
						$month=date('Y').'-'.date('m');
                        $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
						foreach ($this->config->item('years') as $keyYear => $valueYear) {
							foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
								$monthVal=$valueYear."-".$keyMonth;
								if($monthVal==$monthDefault){
									$seletedText=" selected='selected' ";
								} else {
									$seletedText='';
								}
								echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
                                if($monthVal==$month){
                                    break 2;
                                }
							}
						} 
						?>
					</select>			      	
			      </div>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">  
        			<div class="col-md-12">
        				<div id="piechart_MatDeath" ></div>
                        <div id="piechart_MatDeath_loader" class="loader-s" style="display: none;"></div>
                        <div id="piechart_MatDeath_msg" class="msg-center" style="display: none;"></div>
	        		</div>
	    		</div>
	    	</div>
	    	</div>
			<div class="col-md-6 col-sm-12 col-xs-12">
			  <div class="x_panel short-panel1">
			    <div class="x_title">
			      <h2>Neonatal Death Cause</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			      <div class="pull-right">
					<select class="dateChangeClass" id="piechart_NeonDeath_date" data-changeFunction="piechart_NeonDeath"  data-msg="piechart_NeonDeath_msg" data-loader="piechart_NeonDeath_loader">
						<?php 
						$month=date('Y').'-'.date('m');
                        $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
						foreach ($this->config->item('years') as $keyYear => $valueYear) {
							foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
								$monthVal=$valueYear."-".$keyMonth;
								if($monthVal==$monthDefault){
									$seletedText=" selected='selected' ";
								} else {
									$seletedText='';
								}
								echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
                                if($monthVal==$month){
                                    break 2;
                                }
							}
						} 
						?>
					</select>			      	
			      </div>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">  
        			<div class="col-md-12">
        				<div id="piechart_NeonDeath" ></div>
                        <div id="piechart_NeonDeath_loader" class="loader-s" style="display: none;"></div>
                        <div id="piechart_NeonDeath_msg" class="msg-center" style="display: none;"></div>
	        		</div>
	    		</div>
	    	</div>
	    	</div>
			<div class="col-md-6 col-sm-12 col-xs-12">
			  <div class="x_panel short-panel1">
			    <div class="x_title">
			      <h2>Still Birth</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			      <div class="pull-right">
					<select class="dateChangeClass" id="piechart_StillBirth_date" data-changeFunction="piechart_StillBirth" data-msg="piechart_StillBirth_msg" data-loader="piechart_StillBirth_loader">
						<?php 
						$month=date('Y').'-'.date('m');
                        $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
						foreach ($this->config->item('years') as $keyYear => $valueYear) {
							foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
								$monthVal=$valueYear."-".$keyMonth;
								if($monthVal==$monthDefault){
									$seletedText=" selected='selected' ";
								} else {
									$seletedText='';
								}
								echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
                                if($monthVal==$month){
                                    break 2;
                                }
							}
						} 
						?>
					</select>			      	
			      </div>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">  
        			<div class="col-md-12">
        				<div id="piechart_StillBirth" ></div>
                        <div id="piechart_StillBirth_loader" class="loader-s" style="display: none;"></div>
                        <div id="piechart_StillBirth_msg" class="msg-center" style="display: none;"></div>
	        		</div>
	    		</div>
	    	</div>
	    	</div>
			<div class="col-md-6 col-sm-12 col-xs-12">
			  <div class="x_panel short-panel1">
			    <div class="x_title">
			      <h2>Normal VS C-Section Deliveries</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			      <div class="pull-right">
					<select class="dateChangeClass" id="piechart_Deliveries_date" data-changeFunction="piechart_Deliveries" data-msg="piechart_Deliveries_msg" data-loader="piechart_Deliveries_loader">
						<?php 
						$month=date('Y').'-'.date('m');
                        $monthDefault=date('Y').'-'.date('m',strtotime("-1 month"));
						foreach ($this->config->item('years') as $keyYear => $valueYear) {
							foreach ($this->config->item('months') as $keyMonth => $valueMonth) { 
								$monthVal=$valueYear."-".$keyMonth;
								if($monthVal==$monthDefault){
									$seletedText=" selected='selected' ";
								} else {
									$seletedText='';
								}
								echo "<option value='".$monthVal."' ".$seletedText." >".$valueMonth." ".$valueYear."</option>";
                                if($monthVal==$month){
                                    break 2;
                                }
							}
						} 
						?>
					</select>			      	
			      </div>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">  
        			<div class="col-md-12">
        				<div id="piechart_Deliveries" ></div>
                        <div id="piechart_Deliveries_loader" class="loader-s" style="display: none;"></div>
                        <div id="piechart_Deliveries_msg" class="msg-center" style="display: none;"></div>
	        		</div>
	    		</div>
	    	</div>
	    	</div>
	    </div>
			<!-- <div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel">
			    <div class="x_title">
			      <h2>Live Birth VS Still Birth</h2>
			      <ul class="nav navbar-right panel_toolbox">
			        <li>
			        	<a class="collapse-link">
			        		<i class="fa fa-chevron-up"></i>
			        	</a>
			        </li>
			      </ul>
			      <div class="clearfix"></div>
			    </div>
			    <div class="x_content">  
        			<div class="col-md-12">
        				<div id="LiveVSStill" style="width: 95%; height: 100%;"></div>
	        		</div>
	    		</div>
	    	</div>
	    	</div> -->
			
			<!-- charts box ended -->


	 
</div>
</div>
<span id="jstip"></span>


    <!-- <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Month', 'Live Birth', 'Still Birth'],
	        <?php 
	        //foreach ($data['chart']['LiveVSStill'] as $key => $value) {
	          //echo '["'.$value['ReportMonth'].'",  '.$value['TotalLiveBirths'].', '.$value['TotalStillBirths'].'],';
	        //}
	        ?>
        ]);

        var options = {
          title: 'Live Birth VS Still Birth',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('LiveVSStill'));

        chart.draw(data, options);
      }

    </script> -->
<?php 
$out2 = ob_get_contents();
ob_end_clean();
echo $out2;
?>
<script type="text/javascript">
	function piechart_MatDeath_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
	    var params = {};
	    params['device'] = 'web';
	    params['csrf_token']=$.cookie("csrf_cookie");
	    params['searchType'] = 'piechart_MatDeath';
	    params['searchDate'] = searchDate;    
      	var piechart_MatDeath_text=[];
      	$.ajax({
	        url: pageMainUrl + 'ApiUser/getMinistryChart',
	        data: params,
	        type: 'POST',
	        dataType : "json",
	        async: false,
	        success: function (result) {
                $('#piechart_MatDeath_loader').hide();
                $('#piechart_MatDeath_msg').hide();
                if(parseInt(result.length)>2){
                    $('#piechart_MatDeath').show();
                    piechart_MatDeath_text = result;
                    var data = google.visualization.arrayToDataTable(piechart_MatDeath_text);
                    var options = {
                      title: '',          
                      //'chartArea': {height: "100%",width: "100%" },
                      is3D: true,
                      'width':500,
                     'height':300,
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
                    };
                    var chart = new google.visualization.PieChart(document.getElementById('piechart_MatDeath'));
                    chart.draw(data, options);
                } else{
                    $('#piechart_MatDeath').hide();
                    $('#piechart_MatDeath_msg').show().html('No Data Found');
                }
                
            }
	    });
        /*var data = google.visualization.arrayToDataTable(piechart_MatDeath_text);

        var options = {
          title: '',
          'chartArea': {'width': '100%'},
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_MatDeath'));
        chart.draw(data, options);*/
      }		
	}
	function piechart_NeonDeath_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
	    var params = {};
	    params['device'] = 'web';
	    params['csrf_token']=$.cookie("csrf_cookie");
	    params['searchType'] = 'piechart_NeonDeath';
	    params['searchDate'] = searchDate;    
      	var piechart_NeonDeath_text=[];
      	$.ajax({
	        url: pageMainUrl + 'ApiUser/getMinistryChart',
	        data: params,
	        type: 'POST',
	        dataType : "json",
	        async: false,
	        success: function (result) {
                $('#piechart_NeonDeath_loader').hide();
                $('#piechart_NeonDeath_msg').hide();
                if(parseInt(result.length)>2){
                    $('#piechart_NeonDeath').show();
                    piechart_NeonDeath_text = result;
                    var data = google.visualization.arrayToDataTable(piechart_NeonDeath_text);
                    var options = {
                      title: '',          
                      //'chartArea': {height: "100%",width: "100%" },
                      is3D: true,
                      'width':500,
                     'height':300,
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
                    };
                    var chart = new google.visualization.PieChart(document.getElementById('piechart_NeonDeath'));
                    chart.draw(data, options);
                } else{
                    $('#piechart_NeonDeath').hide();
                    $('#piechart_NeonDeath_msg').show().html('No Data Found');
                }
            }
	    });
        /*var data = google.visualization.arrayToDataTable(piechart_NeonDeath_text);
        var options = {
          title: '',
          'chartArea': {'width': '100%'},
          is3D: true,
        };
        var chart = new google.visualization.PieChart(document.getElementById('piechart_NeonDeath'));
        chart.draw(data, options);*/
      }
	}
	function piechart_StillBirth_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
	    var params = {};
	    params['device'] = 'web';
	    params['csrf_token']=$.cookie("csrf_cookie");
	    params['searchType'] = 'piechart_StillBirth';
	    params['searchDate'] = searchDate;    
      	var piechart_StillBirth_text=[];
      	$.ajax({
	        url: pageMainUrl + 'ApiUser/getMinistryChart',
	        data: params,
	        type: 'POST',
	        dataType : "json",
	        async: false,
	        success: function (result) {
                $('#piechart_StillBirth_loader').hide();
                $('#piechart_StillBirth_msg').hide();
                if(parseInt(result.length)>2){
                $('#piechart_StillBirth').show();
                piechart_StillBirth_text = result;
                var data = google.visualization.arrayToDataTable(piechart_StillBirth_text);
                var options = {
                      title: '',          
                      //'chartArea': {height: "100%",width: "100%" },
                      is3D: true,
                      'width':500,
                     'height':300,
                     colors: ['blue', 'red'],
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
                    };
                var chart = new google.visualization.PieChart(document.getElementById('piechart_StillBirth'));
                chart.draw(data, options);
                } else{
                    $('#piechart_StillBirth').hide();
                    $('#piechart_StillBirth_msg').show().html('No Data Found');
                }
            }
	    });
        /*var data = google.visualization.arrayToDataTable(piechart_StillBirth_text);
        var options = {
          title: '',
          'chartArea': {'width': '100%'},
          is3D: true,
        };
        var chart = new google.visualization.PieChart(document.getElementById('piechart_StillBirth'));
        chart.draw(data, options);*/
      }
	}
	function piechart_Deliveries_fun(searchDate=''){
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
	    var params = {};
	    params['device'] = 'web';
	    params['csrf_token']=$.cookie("csrf_cookie");
	    params['searchType'] = 'piechart_Deliveries';
	    params['searchDate'] = searchDate;    
      	var piechart_Deliveries_text=[];
      	$.ajax({
	        url: pageMainUrl + 'ApiUser/getMinistryChart',
	        data: params,
	        type: 'POST',
	        dataType : "json",
	        async: false,
	        success: function (result) {
                $('#piechart_Deliveries_loader').hide();
                $('#piechart_Deliveries_msg').hide();
                if(parseInt(result.length)>2){
                    $('#piechart_Deliveries').show();
                    piechart_Deliveries_text = result;
                    var data = google.visualization.arrayToDataTable(piechart_Deliveries_text);
                    var options = {
                      title: '',          
                      //'chartArea': {height: "100%",width: "100%" },
                      is3D: true,
                      'width':500,
                     'height':300,
                     colors: ['blue', 'orange','red'],
                     chartArea:{left:0,top:5,width:"100%",height:"100%"},
                     legend: {position: 'right'}
                    }; 
                    var chart = new google.visualization.PieChart(document.getElementById('piechart_Deliveries'));
                    chart.draw(data, options);
                } else{
                    $('#piechart_Deliveries').hide();
                    $('#piechart_Deliveries_msg').show().html('No Data Found');
                }
            }
	    });
        /*var data = google.visualization.arrayToDataTable(piechart_Deliveries_text);

        var options = {
          title: '',
          'chartArea': {'width': '100%'},
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_Deliveries'));
        chart.draw(data, options);*/
      }
	}
    function monthly_indicator_fun(){
        $('#monthly_indicator_loader').css({'display':'block'});
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchDate'] = $('#monthly_indicator_date').val();    
        if($('#facility').val()==''){
            // for ministry,state and district
            params['searchType'] = 'monthly_indicator_state';
            params['district'] = $('#district').val();
        } else {
            // for facility
            params['searchType'] = 'faclity_monthly_indicator';
            params['facility'] = $('#facility').val();
        }

          var monthly_indicator_text=[];
          $.ajax({
            url: pageMainUrl + 'ApiUser/getMinistryChart',
            data: params,
            type: 'POST',
            dataType : "json",
            async: false,
            success: function (result) {
                $('#monthly_indicator_loader').css({'display':'none'});
                if($('#facility').val()==''){
                    $('#facilityIndicator').hide();
                    $('#otherIndicator').show();
                    $(result.data).each(function(keyData,valData){
                        $('#'+valData.id+' .progress-bar').attr('style', 'width:'+valData.val+'%');
                        $('#'+valData.id+' .progress-value span').html(valData.val);
                        $('#'+valData.id+' .progress-bar').removeClass('success inprocess faild');
                        $('#'+valData.id+' .progress-bar').addClass(valData.class);
                    });
                    $('.progress-value > span').each(function(){
                        $(this).prop('Counter',0).animate({
                            Counter: $(this).text()
                        },{
                            duration: 1500,
                            easing: 'swing',
                            step: function (now){
                                $(this).text(Math.ceil(now));
                            }
                        });
                    });
                } else {
                    $('#facilityIndicator').show();
                    $('#otherIndicator').hide();
                  $('#a').html(result.a);
                  $('#b').html(result.b);
                  $('#c').html(result.c);
                  $('#d').html(result.d);
                  $('#e').html(result.e);
                  $('#f').html(result.f);
                  $('#g').html(result.g);
                  $('#h').html(result.h);
                  $('#i').html(result.i);
                  $('#j').html(result.j);
                  $('#k').html(result.k);
                  $('#l').html(result.l);
                  $('#m').html(result.m);
                  $('#n').html(result.n);
                  $('#o').html(result.o);
                  $('#p').html(result.p);
                  $('#q').html(result.q);
                  $('#r').html(result.r);
                  $('#s').html(result.s);
                  $('#t').html(result.t);
                  $('#u').html(result.u);
                  $('#v').html(result.v);
                  $('#w').html(result.w);
                  $('#x').html(result.x);
                  $('#y').html(result.y);
                  $('#z').html(result.z);
                  $('#za').html(result.za);                    
                }
            }
        });
        //$('#monthly_indicator').show();
      
  }
    function change_district() {
        var params = {};
        params['device'] = 'web';
        params['csrf_token']=$.cookie("csrf_cookie");
        params['searchType'] = 'facility';
        params['searchData'] = $('#district').val();
        $.ajax({
            url: pageMainUrl + 'ApiFacility/getSearchOptions',
            data: params,
            type: 'POST',
            dataType: 'json',
            async:false,
            success: function (result) {
                $('#facility').html('<option value="">Select Facility</option>');
                if (result.data) {
                    if (parseInt(result.data.length) > 0) {
                        $.each(result.data, function (key, val) {
                            $('#facility').append($("<option></option>").attr("value", val.UserID).text(val.FacilityName));
                        });
                    }
                }
            }
        });
    }

	$('document').ready(function(){
		var params={};
		params['device']='web';
		params['csrf_token']=$.cookie("csrf_cookie");
		$.ajax({
			url: pageMainUrl+'ApiUser/getStateData', 
			data: params, 
			type: 'POST', 
			dataType: 'json', 
			success: function(result){
				$("#StateName").html(result.data.all.StateName);
                $("#LrBaseLine").html(result.data.all.LrBaseLine);
                $("#OtbaseLine").html(result.data.all.OtbaseLine);
				//$("#AllFacilities").html(result.data.all.Facilities);
				$("#AllAppliedLR").html(result.data.all.AppliedLR);
				$("#AllAppliedOT").html(result.data.all.AppliedOT);
				$("#AllInprocessLR").html(result.data.all.InprocessLR);
				$("#AllInprocessOT").html(result.data.all.InprocessOT);
				$("#AllCertifiedLR").html(result.data.all.CertifiedLR);
				$("#AllCertifiedOT").html(result.data.all.CertifiedOT);
				//$("#AllStateappliedLR").html(result.data.all.StateappliedLR);
				//$("#AllStateappliedOT").html(result.data.all.StateappliedOT);
				$("#AllStateInprocessLR").html(result.data.all.StateInprocessLR);
				$("#AllStateInprocessOT").html(result.data.all.StateInprocessOT);
				$("#AllStatecertifiedLR").html(result.data.all.StatecertifiedLR);
				$("#AllStatecertifiedOT").html(result.data.all.StatecertifiedOT);

                //$("#AsFacilities").html(result.data.aspirational.Facilities);
				$("#AsFacilities").html(result.data.aspirational.FacilitiesNew);
                $("#AsLrBaseLine").html(result.data.aspirational.LrBaseLine);
                $("#AsOtbaseLine").html(result.data.aspirational.OtbaseLine);
				$("#AsAppliedLR").html(result.data.aspirational.AppliedLR);
				$("#AsAppliedOT").html(result.data.aspirational.AppliedOT);
				$("#AsInprocessLR").html(result.data.aspirational.InprocessLR);
				$("#AsInprocessOT").html(result.data.aspirational.InprocessOT);
				$("#AsCertifiedLR").html(result.data.aspirational.CertifiedLR);
				$("#AsCertifiedOT").html(result.data.aspirational.CertifiedOT);
				$("#AsStateappliedLR").html(result.data.aspirational.StateappliedLR);
				$("#AsStateappliedOT").html(result.data.aspirational.StateappliedOT);
				$("#AsStateInprocessLR").html(result.data.aspirational.StateInprocessLR);
				$("#AsStateInprocessOT").html(result.data.aspirational.StateInprocessOT);
				$("#AsStatecertifiedLR").html(result.data.aspirational.StatecertifiedLR);
				$("#AsStatecertifiedOT").html(result.data.aspirational.StatecertifiedOT);

				$("#AsFacilitiesBox").html(result.data.aspirational.Facilities);
				$("#AsLrBaseLineBox").html(result.data.aspirational.LrBaseLine);
				$("#AsOtbaseLineBox").html(result.data.aspirational.OtbaseLine);

				$("#AsAppliedLRBox").html(result.data.aspirational.AppliedLR);
				$("#AsAppliedOTBox").html(result.data.aspirational.AppliedOT);
				$("#AsInprocessLRBox").html(result.data.aspirational.InprocessLR);
				$("#AsInprocessOTBox").html(result.data.aspirational.InprocessOT);
				$("#AsCertifiedLRBox").html(result.data.aspirational.CertifiedLR);
				$("#AsCertifiedOTBox").html(result.data.aspirational.CertifiedOT);

				$("#AsStateappliedLRBox").html(result.data.aspirational.StateappliedLR);
				$("#AsStateappliedOTBox").html(result.data.aspirational.StateappliedOT);
				$("#AsStateInprocessLRBox").html(result.data.aspirational.StateInprocessLR);
				$("#AsStateInprocessOTBox").html(result.data.aspirational.StateInprocessOT);
				$("#AsStatecertifiedLRBox").html(result.data.aspirational.StatecertifiedLR);
				$("#AsStatecertifiedOTBox").html(result.data.aspirational.StatecertifiedOT);
			}
		});		

		piechart_MatDeath_fun();
		piechart_NeonDeath_fun();
		piechart_StillBirth_fun();
		piechart_Deliveries_fun();
        monthly_indicator_fun();
		$('.dateChangeClass').change(function(){
			var searchDate=$(this).val();
			var functionName=$(this).attr('data-changeFunction');
            var loaderName=$(this).attr('data-loader');
            $('#'+loaderName).show();
            $('#'+functionName).hide();
			switch(functionName) {
			  case 'piechart_MatDeath':
			    piechart_MatDeath_fun(searchDate);
			    break;
			  case 'piechart_NeonDeath':
			    piechart_NeonDeath_fun(searchDate);
			    break;
			  case 'piechart_StillBirth':
			    piechart_StillBirth_fun(searchDate);
			    break;
			  case 'piechart_Deliveries':
			    piechart_Deliveries_fun(searchDate);
			    break;
			  default:
			    // code block
			}
		});

	});
</script>






<script type="text/javascript">
    
    $("#view-more-btn").click(function(){
        $(".hidden-dash-bard").show();
        $(this).remove();
        return false;
    });

$(document).ready(function(){
    $('.count').each(function () {
        $(this).prop('Counter',0).animate({
            Counter: $(this).text()
        }, {
            duration: 4000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });
});



</script>
 