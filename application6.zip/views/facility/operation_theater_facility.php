<div class="main-content">  
  <div class="tab-head1">
    <div class="container">
      <div class="row">
        <div class="form-main-labour">
          <h3 class="title"><?php echo isset($survey['survey'][2]['SurveyDesc'])?$survey['survey'][2]['SurveyDesc']:''; ?> <span class="downlo-btn-form">
            <a href="#" data-toggle="modal" data-target="#abbreviationModal"> <i class="fa fa-question-circle" aria-hidden="true"></i></a>
          </span>
          <h3>
            <!-- SmartWizard html -->
            <div id="smartwizard">          
              <?php if(isset($survey['survey'][2]['category']) && count($survey['survey'][2]['category'])>0){ ?>
              <ul>
                <?php foreach ($survey['survey'][2]['category'] as $keyCat => $valueCat) { ?>            
                <li><a href="#step-<?php echo $keyCat; ?>"><span><em> <?php echo isset($valueCat['CategoryCode'])?$valueCat['CategoryCode']:''; ?> </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span><?php echo isset($valueCat['CategoryName'])?$valueCat['CategoryName']:''; ?><br /></a></li>
                <?php } ?>
              </ul>
              <?php } ?>
              <div> 

                <!-- Catgory Start -->
                <?php if(isset($survey['survey'][2]['category']) && count($survey['survey'][2]['category'])>0){ ?>
                <?php foreach ($survey['survey'][2]['category'] as $keyCat => $valueCat) { ?>
                <div id="step-<?php echo $keyCat; ?>">      
                  <div class="col-md-12">
                    <div class="quote-top-bar">
                      <div class="col-md-1 col-md-offset-7 text-right">
                          <p>Compliance</p>
                      </div>
                      <div class="col-md-4  text-center">
                        <div class="col-md-3 text-right">
                          <p>  0-49%</p>
                        </div>
                        <div class="col-md-3 text-center">
                          <p>  49-99%</p>
                        </div>
                        <div class="col-md-3 text-left">
                          <p>  100%</p>
                        </div>
                      </div>  
                    </div>  
                  </div>
                  <div class="clear"></div>

                  <!-- Subcatgory Start -->
                  <?php if(isset($valueCat['subcategory']) && count($valueCat['subcategory'])>0){ ?>
                  <?php foreach ($valueCat['subcategory'] as $keySubCat => $valueSubCat) { ?>
                  <div class="question-list">
                    <h3 class="form-title"><?php echo isset($valueSubCat['SubCategoryCode'])?$valueSubCat['SubCategoryCode'].': ':''; echo isset($valueSubCat['SubCategoryName'])?$valueSubCat['SubCategoryName']:'';  ?></h3>
                    <div class="question-list1">
                      <div class="quest1">

                        <!-- questation Start -->
                        <?php if(isset($valueSubCat['questions']) && count($valueSubCat['questions'])>0){ ?>
                        <?php foreach ($valueSubCat['questions'] as $keyQues => $valueQues) { 
                          if(!empty($valueQues['Reference']) && !empty($valueQues['Statement'])){
                          ?>
                        <div class="col-md-12">
                         <div class="quote1-full">
                          <div class="col-md-12">  
                            <div class="quote-1-list">
                              <?php if(isset($valueQues['Reference']) && !empty($valueQues['Reference'])){ ?><div class="num-list"><?php echo $valueQues['Reference']; ?></div><?php } ?>
                              <div class="quotation-content"> 
                                <?php if(isset($valueQues['Statement']) && !empty($valueQues['Statement'])){ ?><h4><?php echo $valueQues['Statement']; ?></h4><?php } ?>
                              </div>
                              
                           </div>
                          </div>
                         </div>
                        </div>
                        <?php  } ?>
                        <div class="col-md-12">
                         <div class="quote1-full  quote1-full2">                          
                           
                          <div class="col-md-8">  
                            <div class="quote-1-list">
                              <div class="num-list"></div>
                              <div class="quotation-content"> 
                                <?php if(isset($valueQues['Checkpoint']) && !empty($valueQues['Checkpoint'])){ ?><h5><?php echo $valueQues['Checkpoint']; ?></h5><?php } ?>
                              </div>
                              <?php if(!empty($valueQues['Assesment']) || !empty($valueQues['Verification'])){ ?>
                              <div class="toltip">
                               <i class="fa fa-info-circle" aria-hidden="true"></i>
                               <p class="tool-tip-pop"><?php echo 'Assesment method: '.$valueQues['Assesment']; ?></br><?php echo 'Verification: '.$valueQues['Verification']; ?></p>
                             </div>
                             <?php } ?>
                           </div>
                          </div>

                         <div class="col-md-4 text-center">  
                          <div class="quote-1-option">
                            <div class="maxl">
                             <div class="col-md-3">  
                               <label class="radio inline"> 
                                <input type="radio" id="answer_<?php echo $keyQues; ?>_0" name="answer[<?php echo $keyQues; ?>]" value="0" >
                                <span> 0 </span> 
                              </label>
                            </div>
                            <div class="col-md-3">  
                             <label class="radio inline"> 
                              <input type="radio" id="answer_<?php echo $keyQues; ?>_1" name="answer[<?php echo $keyQues; ?>]" value="1">
                              <span>1 </span> 
                            </label>
                          </div>
                          <div class="col-md-3">  
                            <label class="radio inline"> 
                              <input type="radio" id="answer_<?php echo $keyQues; ?>_2" name="answer[<?php echo $keyQues; ?>]" value="2" >
                              <span>2 </span> 
                            </label>
                          </div>
                          <div class="col-md-3">  
                            <div class="selec-uncheck-btn" title="Uncheck Your Answer" >
                                <a href="javascript:void(0);" class="uncheckRadio" id="uncheckRadio_<?php echo $keyQues; ?>" style="display: none;" > <i class="fa fa-trash" aria-hidden="true"></i></a>
                            </div>
                          </div>

                        </div>
                      </div>
                    </div>

                  </div>
                </div>  
                <!-- questation Ended -->
                <?php } ?>
                <?php } ?>
              </div>
            </div>                  
          </div>
          <?php } ?>
          <?php } ?>
          <!-- Subcatgory End -->

        </div>
        <?php } ?>        
        <?php } ?>  
        <!-- Catgory End -->         
        <input type="hidden" name="surveyName" id="surveyName" value="2" >
        <input type='hidden' name="ansId" id="ansId" value="<?php echo $this->uri->segment('3'); ?>" class="" />
      </div>
    </div>   
    
  </div>
</div>
</div>
</div>  
</div><!--main-content --> 

<!-- abbrevation modal start -->
  <div class="modal fade" id="abbreviationModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Assessment Methods </h4>
        </div>
        <div class="modal-body">
          <p>
          <span >Assessment Method – </span> Assessment Methods are given in adjacent column to checkpoint and provides aid to the assessors that how the information required for a specific checkpoint can be gathered. There are four assessment methods:</br></br>
          <span style="font-weight: bold;" >Observations (OB) – </span> Where information can be gathered though
          direct observation. e.g. Level of Cleanliness, Display of Protocols,
          Landscaping, Signage etc.</br></br>
          <span style="font-weight: bold;" >Staff Interview (SI) – </span> Information should be gathered by interacting the concerned staff to understand the current practices, competency, etc. such as steps in hand washing, method to clean
          floor, wearing gloves.</br></br>
          <span style="font-weight: bold;" >Record Review (RR) – </span> Where information can be extracted from the records available at the facility. Few examples are availability of filled-in Housekeeping checklist, culture report for microbial surveillance, minutes of meeting of infection control committee.</br></br>
          <span style="font-weight: bold;" >Patient Interview (PI) – </span> Some information may be gathered by interacting the patients or their attendants e.g. counselling of patients on hygiene.</br></br>
          </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!-- abbrevation modal end -->

<!-- previewModal modal start -->
  <div class="modal fade" id="previewModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Excel Format </h4>
        </div>
        <div class="modal-body">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!-- previewModal modal end -->


<!-- wizaard -->
<script src="<?php echo base_url();?>assets/js/notify.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>
<script src="<?php echo base_url();?>assets/js/form-custom.js"></script>
 