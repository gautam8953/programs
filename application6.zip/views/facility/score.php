<!--<div class="page-title">
  <div class="title_left">
    <h3>Assessment Score</h3>
  </div>

  <div class="title_right">
    <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
      <div class="input-group" style="float: right;">
        <a href="<?php echo base_url(). "facility/assesment"; ?>" id="addBtn" class="btn btn-success disabled pull-right">Add</a>
      </div>
    </div>
  </div>
</div>

<div class="clearfix"></div>-->


<div class="main-content"> 
    <div class="container">
      <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Assessment Score</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
    <form name="scoreForm" id="scoreForm" class="login-form login_form_mine" action="<?php echo base_url()."ApiFacility/savescore"?>"> 
    <div class="alert" id="msgDiv" style="display: none;">
        <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
      <strong id="LoginMsg"></strong>
    </div>
      <div class="row">
            <div class="col-md-12">
                <h3 id="assementName" class="title-mine"></h3>
                <!-- <div class="print-score">
                  <i class="fa fa-print"> | Print Score</i>
                </div> -->
            </div>
            <div class="clear"></div>
            <hr>
            <div class="col-md-12 col-xs-12 col-sm-12 dsp-flx">
            <div class="col-md-8 col-sm-6 col-xs-12 pad-bg">
              <div class="row">
                <div class="table-responsive">
                  <table id="score" class="table table-striped table-bordered" width="100%">
                      <thead>
                          <tr>
                              <th colspan="5" class="text-center dif-bg" >Area of Concern wise score </th>
                          </tr>
                          <tr>
                            <th class="text-center">Code</th>
                            <th class="text-center">Area of Concern</th>
                            <th class="text-center">Marks</th>
                            <th class="text-center">Total Marks</th>
                            <th class="text-center">Score</th>
                          </tr>
                      </thead>
                      <tbody>
                          
                      </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="rtsd-bx rtst-bx-scr">
                  <div class="border">
                    <h2  style="text-align: center;">Score</h2>
                    <p id="totScore" class="score_p_num">0.00%</p>
                  </div>
                </div>
            </div>
          </div>
      </div>
      <div class="clear"></div>
      <hr>
      <div class="row">
        <div class="col-md-12">
          <div class="table-responsive">
            <table id="standardScore" class="table table-striped table-bordered" width="100%">
                <thead>
                </thead>
                <tbody>                    
                </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="clear"></div>
      <hr>
      <div class="add-feed-backup-table">
      <div class="row ">

        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="form-group">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <label class="mar-bot-20">Client Satisfaction Score </label>
              </div>
              <div class="col-md-9 col-sm-9 col-xs-9">
                <input type="text" placeholder="In percentage" name="clientScore" class="form-control nums" id="clientScore" maxlength="3" >
              </div>
            </div>
        </div>

        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-9">
              <label class="mar-bot-20">Major Gaps Observed </label>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-3 actionDiv">
              <input type="button" name="" onclick="addAns('q1')"  class="btn btn-sm btn-info addMore mar-bot-20 btn-width" value="Add More">
            </div>
            </div>
        </div>

        <div class="col-md-12 col-sm-12 col-xs-12 q1" >
          <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-9">
              <div class="form-group">
                <input type="text" name="q1[]" class="form-control" id="email" maxlength="255" placeholder="Major Gaps Observed" >
              </div>
            </div>
            
            <div class="col-md-3 col-sm-3 col-xs-3 actionDiv">
              <!--<input type="button" name="" onclick="addAns('q1')"  class="btn btn-sm btn-info addMore mar-bot-20" value="Add More">-->
                
                <button onclick="removeRow(this)" class="btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i></button>
            </div>
            </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-9">
              <label class="mar-bot-20">Strengths / Good Practices  </label>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-3 actionDiv">
              <!--<input type="button" name="" onclick="addAns('q1')"  class="btn btn-sm btn-info addMore mar-bot-20" value="Add More">-->
              <input type="button" name="" onclick="addAns('q2')"  class="btn btn-sm btn-info addMore mar-bot-20 btn-width" value="Add More">
            </div>
            </div>
        </div>
        <div class="col-md-12 col-sm-12 col-xs-12 q2" >
          <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-9">
              <div class="form-group">
                <input type="text" name="q2[]" class="form-control" id="email" maxlength="255" placeholder="Strengths / Good Practices" >
              </div>
            </div>
            
            <div class="col-md-3 col-sm-3 col-xs-3 actionDiv">
              <!--<input type="button" name="" onclick="addAns('q1')"  class="btn btn-sm btn-info addMore mar-bot-20" value="Add More">-->
                
                <button  onclick="removeAns('q2',this)" class="btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i></button>
            </div>
            </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-9">
            <label class="mar-bot-20">Recommendations/ Opportunities for Improvement </label>
            </div>
             <div class="col-md-3 col-sm-3 col-xs-3 actionDiv">
              <!--<input type="button" name="" onclick="addAns('q1')"  class="btn btn-sm btn-info addMore mar-bot-20" value="Add More">-->
              <input type="button" name="" onclick="addAns('q3')"  class="btn btn-sm btn-info addMore mar-bot-20 btn-width" value="Add More" >
            </div>
            </div>
            
        </div>
        <div class="col-md-12 col-sm-12 col-xs-12 q3" >
          <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-9">
              <div class="form-group">
                <input type="text" name="q3[]" class="form-control" id="email" maxlength="255" placeholder="Recommendations/ Opportunities for Improvement" >
              </div>
            </div>
           
            <div class="col-md-3 col-sm-3 col-xs-3 actionDiv">
                <!--<input type="button" name="" onclick="addAns('q1')"  class="btn btn-sm btn-info addMore mar-bot-20" value="Add More">-->
                
                <button  onclick="removeAns('q3',this)" class="btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i></button>
            </div>
            </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-10 col-sm-10 col-xs-10">
           
        </div>
        <div class="col-md-2 col-sm-2 col-xs-2">
            <input type='hidden' name="ansId" id="ansId" value="<?php echo $this->uri->segment('3'); ?>" class="" />
            <input style="margin: 30px 10px 0px 0px;" type="submit" name="" class="form-control btn sbmt-btn btn-info pull-right" value="Save">
        </div>
      </div>
      </div>

    </form>
  </div>
</div>
</div>
</div>
  </div>
</div>