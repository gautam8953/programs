<style>
    .col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}    
</style>


<div class="page-title">
  <div class="title_left">
    <h3>Anexture Form</h3>
  </div>

</div>

<div class="clearfix"></div>


<div class="main-content main-content-form-gr-h">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Anexture Form</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <form id="assesmentForm" name="assesmentForm" role="form" action="<?php echo base_url()."ApiAnexture/anexture"?>" method="post">
                
                <?php if(isset($search_options['State']) ){ ?>
                <div class="col-md-4">
                     <div class="form-group">
                    <label> State Name<span class="required"> * </span> </label>
                    <select id="search_state" name="search_state" onchange="change_state()" class="form-control">
                        <option value="">Select State</option>
                        <?php foreach ($search_options['State'] as $key => $value) {  ?>
                        <option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
                        <?php } ?>
                    </select>  
                    </div>                  
                </div>
                <?php } ?>
                <?php if(isset($search_options['District']) ){ ?>
                <div class="col-md-4">
                     <div class="form-group">
                      <label> District Name <span class="required"> * </span> </label>
                    <select id="search_district"  name="search_district" onchange="change_district()" class="form-control">
                        <option value="">Select District</option>
                        <?php foreach ($search_options['District'] as $key => $value) { ?>
                        <option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
                        <?php } ?>
                    </select>  
                    </div>                  
                </div>
                <?php } ?>
                <?php if(isset($search_options['Facility']) || $this->session->userdata('RoleName')=='Facility' ){ ?>
                <div class="col-md-4">
                    <div class="form-group">
                        <label> Name of the Hospital <span class="required"> * </span> </label>
                        <select id="facilityName" name="facilityName" class="form-control"   onchange="change_facility(this)">
                            <option value="">Select Facility</option>
                        </select>
                    </div>
                </div>
                <?php } ?>                    <div class="col-md-4">
                        <div class="form-group">
                            <label> Date of Assessment <span class="required"> * </span> </label>
                                <input minlength="10" maxlength="10" type='text' id="submitDate" name="submitDate"  placeholder="DD-MM-YYYY" class="form-control datepicker" />
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 1 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_1" name="checklist_1"  class="form-control" placeholder="checklist 1">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist  </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_2" name="checklist_2"  class="form-control" placeholder="checklist 2">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 3 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_3" name="checklist_3"  class="form-control" placeholder="checklist 3">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 4 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_4" name="checklist_4"  class="form-control" placeholder="checklist 4">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 5 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_5" name="checklist_5"  class="form-control" placeholder="checklist 5">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 6 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_6" name="checklist_6"  class="form-control" placeholder="checklist 6">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 7 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_7" name="checklist_7"  class="form-control" placeholder="checklist 7">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 8 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_8" name="checklist_8"  class="form-control" placeholder="checklist 8">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 9 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_9" name="checklist_9"  class="form-control" placeholder="checklist 9">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 10 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_10" name="checklist_10"  class="form-control" placeholder="checklist 10">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 11 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_11" name="checklist_11"  class="form-control" placeholder="checklist 11">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 12 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_12" name="checklist_12"  class="form-control" placeholder="checklist 12">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 13 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_13" name="checklist_13"  class="form-control" placeholder="checklist 13">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 14 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_14" name="checklist_14"  class="form-control" placeholder="checklist 11">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 15 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_15" name="checklist_15"  class="form-control" placeholder="checklist 15">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 16 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_16" name="checklist_16"  class="form-control" placeholder="checklist 16">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 17 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_17" name="checklist_17"  class="form-control" placeholder="checklist 17">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 18 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_18" name="checklist_18"  class="form-control" placeholder="checklist 18">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 19 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_19" name="checklist_19"  class="form-control" placeholder="checklist 19">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label> checklist 20 </label>
                            <input minlength="1" maxlength="100" type="text" id="checklist_20" name="checklist_20"  class="form-control" placeholder="checklist 20">
                        </div>
                    </div>


                    <div class="col-md-12">
                        <div class="form-group">
                            <div class='input-group pull-right'>
                                <input type='hidden' name="anextureID" id="anextureID" value="<?php echo $this->uri->segment('3'); ?>" class="" />
                                <input style="margin-top: 15px; margin-right: 0px;" type='submit' id="anexture" name="anexture" value="Draft" class="btn btn-info" />
                                <input style="margin-top: 15px; margin-right: 0px;" type='submit' id="anexture" name="anexture" value="Save" class="btn btn-info" />
                            </div>
                        </div>
                    </div>                    
                </form>
            </div>
        </div>

            </div>
        </div>
    </div>
</div>