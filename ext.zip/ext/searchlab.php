<?php

class Searchlab extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('search_model');
        $this->load->model('searchlab_model');
        $this->load->model('laboratory_model');
        $this->load->model('certificate_model');
        $this->load->library('dropdown');
        $this->load->helper('url');        
    }

    public function index() {
        $this->load->model('zone_model');
        $data=array();
        $data['country'] = $this->searchlab_model->get_country();
        $seachData=array();            
        $data['state'] = $this->searchlab_model->get_state();
        $data['city'] = $this->searchlab_model->get_city();
        $data['zone'] = $this->searchlab_model->get_zone();
        $data['natureoflab'] = $this->searchlab_model->get_natureoflab();
        $data['facilitydropdown'] = $this->searchlab_model->get_labcat(0);
        $data['operationat'] = $this->searchlab_model->get_operationat(0);

        //echo "<pre>"; print_r($data['zone']); echo "</pre>";
        $this->load->view('searchlab/index', $data);

    }
    public function searchlabcat() {
        $response=array('code'=>1,'msg'=>'error data');
        $datasearch=$this->searchlab_model->get_labcat($this->input->post('search_data'));
        
        $searchType=$this->input->post('type_data');

        if(true) {
            
        } else {
            $response['msg']='No serach type get';
        }
        /*$this->load->model('zone_model');
        $data=array();
        $data['country'] = $this->searchlab_model->get_country();
        $seachData=array();            
        $data['state'] = $this->searchlab_model->get_state();
        $data['city'] = $this->searchlab_model->get_city();
        $data['zone'] = $this->searchlab_model->get_zone();
        $data['natureoflab'] = $this->searchlab_model->get_natureoflab();
        $data['facilitydropdown'] = $this->searchlab_model->get_labcat(0);
        $data['operationat'] = $this->searchlab_model->get_operationat(0);*/

        echo "<pre>"; print_r($datasearch); echo "</pre>";

        echo json_encode($response);
        exit;
        //$this->load->view('searchlab/index', $data);

    }
    function searchdata(){
    $response=array();
    $data=array();
    for ($i=0; $i <rand(1,10) ; $i++) { 
        $data[]=array(
            'id'=>$i,
            'labname'=>'aaaaa'.$i,
            'address'=>'aaaaa'.$i,
            'telephone'=>'aaaaa'.$i,
            'fax'=>'aaaaa'.$i,
            'email'=>'aaaaa'.$i,
            'contact_person'=>'aaaaa'.$i,
        );
    }
    $response['data']=$data;
    $response['code']=10;
    $response['totalData']=100;

    $response['pagelast']=20;
    $pagination=array();
    $pagination[]=array('pageUrl'=>1,'pageText'=>'Start');
    $pagination[]=array('pageUrl'=>1,'pageText'=>'1');
    $pagination[]=array('pageUrl'=>2,'pageText'=>'2');
    $pagination[]=array('pageUrl'=>3,'pageText'=>'3');
    $pagination[]=array('pageUrl'=>10,'pageText'=>'10');
    $pagination[]=array('pageUrl'=>500,'pageText'=>'Last');
    $response['pagination']=$pagination;
    echo json_encode($response);
    exit;
    }


}
