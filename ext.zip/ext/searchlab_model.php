<?php

class searchlab_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function get_search($limit) {

    }
    public function get_country() {
        $this->db->select('id,name');
        $this->db->from('country');
        $searchArr['isActive']=1;
        $this->db->where($searchArr);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_state() {
        $this->db->select('id,name');
        $this->db->from('states');
        $this->db->order_by('name ASC');
        $searchArr['isActive']=1;
        $this->db->where($searchArr);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_city() {
        $this->db->select('id,name');
        $this->db->from('cities');
        $this->db->order_by('name ASC');
        $searchArr['isActive']=1;
        $this->db->where($searchArr);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_zone() {
        $this->db->select('id,zone_name');
        $this->db->from('zone_tbl');
        $this->db->order_by('zone_name ASC');
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_natureoflab() {
        $this->db->select('id,nature_name');
        $this->db->from('lab_nature_tbl');
        $this->db->order_by('nature_name ASC');
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_labcat($cat_id) {
        $this->db->select('id,category_name');
        $this->db->from('lab_category_tbl');
        $this->db->where_in('cat_id', explode(',',$cat_id));
        $this->db->order_by('category_name ASC');
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_operationat($cat_id) {
        $this->db->select('id,operation_name');
        $this->db->from('lab_operations_tbl');
        $this->db->order_by('operation_name ASC');
        $query = $this->db->get();
        return $query->result_array();
    }

    /*public function get_city($stateID=0,$id=0) {
        $this->db->select('id,name');
        $this->db->from('cities');
        $searchArr=array();
        if($id>0){
            $searchArr['id']=$id;
        }
        if($stateID>0){
            $searchArr['stateid']=$stateID;
        }
        $this->db->where($searchArr);
        $query = $this->db->get();
        return $query->result_array();
    }*/



}
