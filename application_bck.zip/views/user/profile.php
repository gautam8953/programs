<style>
.col-md-4 .bootstrap-select button, input{margin-bottom: 7px !important;}    
</style>

<div class="page-title">
  <div class="title_left">
    <h3>User Profile</h3>
  </div>

  
</div>



<div class="main-content main-content-form-gr-h">
  <div class="container">

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2><?php echo $this->session->userdata('RoleName'); ?> User Profile Information</h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <form enctype="multipart/form-data" name="profileForm" id="profileForm" role="form" action="<?php echo base_url(). "ApiUser/profile"; ?>" method="post">             
              <?php if($this->session->userdata('RoleName')=='Facility'){ ?>
              <div class="col-md-6">
                <div class="form-group">
                  <label>Name <!-- <span class="required"> * </span> --> </label>
                  <input maxlength="99" class="form-control FacilityName" placeholder="Name" id="FacilityName" name="FacilityName" type="text"  value="<?php if(isset($facility)){ echo $facility['FacilityName']; };  ?>" readonly="readonly" >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> NIN ID <span class="required"> * </span> </label>
                  <input maxlength="25" class="form-control" placeholder="NIN ID" id="FacilityNumber" name="FacilityNumber" type="text" value="<?php if(isset($facility)){ echo $facility['FacilityNumber']; };  ?>"   >
                </div>
                <button class="btn btn-info" id="search-nin-btn" type="button" data-toggle="modal" data-target="#searchNinModal">Search NIN ID</button>

              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Type of Facility <span class="required"> * </span> </label>
                  <select id="FacilityTypeDetailID" name="FacilityTypeDetailID" class="selectpicker" data-live-search="true" data-width="100%" onchange="check_facility(this)">
                    <option value="" >Select Facility Type</option>
                    <?php foreach ($facility_types as $key => $value) { ?>
                    <option value="<?php echo $value['TypeDetailID']; ?>" <?php if(isset($facility['FacilityTypeDetailID']) && $facility['FacilityTypeDetailID']==$value['TypeDetailID']){ echo ' selected="selected" '; } ?> ><?php echo $value['TypeDetailCode']; ?></option>
                    <?php } ?>
                </select>                  
                </div>
              </div>
              <div class="col-md-6" >
                <div class="form-group" style="display: <?php echo ($facility['FacilityTypeDetailID']=='440')?'':'none'; ?>;">
                  <label>Other Type </label>
                  <input maxlength="50" class="form-control" placeholder="Facility Type Other" id="facilitytype_other" name="facilitytype_other" type="text" value="<?php if(isset($facility)){ echo $facility['facilitytype_other']; };  ?>"   >
                </div>
              </div>
              <div class="clearfix"></div>
              <div class="col-md-6">
                <div class="form-group">
                  <label>Address <span class="required"> * </span> </label>
                  <input maxlength="255" class="form-control" placeholder="Address" id="Address" name="Address" type="text" value="<?php if(isset($facility)){ echo $facility['Address']; };  ?>"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> State <!-- <span class="required"> * </span> --> </label>
                  <input maxlength="50" class="form-control" placeholder="State" id="StateName" name="StateName" type="text" value="<?php if(isset($facility)){ echo $facility['StateName']; };  ?>" readonly="readonly"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> District <!-- <span class="required"> * </span> --> </label>
                  <input maxlength="50" class="form-control" placeholder="District" id="DistrictName" name="DistrictName" type="text" value="<?php if(isset($facility)){ echo $facility['DistrictName']; };  ?>" readonly="readonly"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label>Pin Code <span class="required"> * </span> </label>
                  <input maxlength="6" class="form-control nums" placeholder="Pin Code" id="PinCode" name="PinCode" type="text" value="<?php if(isset($facility)){ echo $facility['PinCode']; };  ?>"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Landline No. <!-- <span class="required"> * </span> --> </label>
                  <input class="form-control num_spec" placeholder="Landline No" id="landLine" name="landLine" type="text" value="<?php if(isset($facility)){ echo $facility['landLine']; };  ?>"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Latitude <span class="required"> * </span> </label>
                  <input maxlength="50" class="form-control" placeholder="Latitude" id="Latitude" name="Latitude" type="text" value="<?php if(isset($facility)){ echo $facility['Latitude']; };  ?>"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Longitude <span class="required"> * </span> </label>
                  <input maxlength="50" class="form-control" placeholder="Longitude" id="Longitude" name="Longitude" type="text" value="<?php if(isset($facility)){ echo $facility['Longitude']; };  ?>"   >
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Altitude <!-- <span class="required"> * </span> --> </label>
                  <input maxlength="50" class="form-control" placeholder="Altitude" id="Altitude" name="Altitude" type="text" value="<?php if(isset($facility)){ echo $facility['Altitude']; };  ?>"   >
                </div>
              </div>
              <div class="col-md-6">
                  <div class="form-group">
                      <label>Services<span class="required"> * </span>&nbsp;&nbsp;&nbsp;</label>
                      <label class="radio inline">
                          <input id="services_lr" name="services" type="radio" onchange="checkFacilityAssessment(this)" value="lr" <?php if(isset($facility['services']) && $facility['services']=='lr'){ echo ' checked="checked"'; }  ?> >
                          <span>LR </span>
                      </label>

                      <label class="radio inline">
                          <input id="services_both" name="services" type="radio" onchange="checkFacilityAssessment(this)" value="both" <?php if(isset($facility['services']) && $facility['services']=='both'){ echo ' checked="checked"'; }  ?> >
                          <span>LR & OT Both </span>
                      </label>
                  </div>
              </div>
              <div class="col-md-6">
                  <div class="form-group">
                    <!-- <label>Operation Theater Type&nbsp;&nbsp;&nbsp;</label> -->
                    <?php 
                      $ot_services_disp='none';
                      if($facility['services']=='both' && array_key_exists($facility['ot_services'], $this->config->item('ot_services'))) { $ot_services_disp=''; } ?>
                      <label class="radio inline" style="display: <?php echo $ot_services_disp; ?>;" >
                          <input id="both_gen" name="ot_services" type="radio" onchange="" value="gen" <?php if(isset($facility['ot_services']) && $facility['ot_services']=='gen'){ echo ' checked="checked"'; }  ?> >
                          <span>General OT</span>
                      </label>

                      <label class="radio inline" style="display: <?php echo $ot_services_disp; ?>;" >
                          <input id="both_met" name="ot_services" type="radio" onchange="" value="met" <?php if(isset($facility['ot_services']) && $facility['ot_services']=='met'){ echo ' checked="checked"'; }  ?> >
                          <span>Meternity OT</span>
                      </label>
                  </div>
              </div>
              <?php } ?>


              <div class="col-md-12"></div>
              <?php if(!empty($mainProfile)){ ?>
              <div class="col-md-12 deffr_head">
                <h4><?php echo $mainProfile; ?>&nbsp;<?php if($this->session->userdata('RoleName')=='Facility'){ ?><b>(Add details of Laqshya nodal of this facility) </b><?php } ?></h4>
              </div>
              <?php } ?>
              <div class="col-md-6">
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label>First Name <span class="required"> * </span></label> 
                      
                      <input maxlength="30" class="form-control" placeholder="First Name" id="FirstName_main" name="FirstName_main" type="text" value="<?php if(isset($main['FirstName'])){ echo $main['FirstName']; } ?>"   >
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label> Last Name <!-- <span class="required"> * </span> --> </label>
                      <input maxlength="30" class="form-control" placeholder="Last Name" id="LastName_main" name="LastName_main" type="text" value="<?php if(isset($main['LastName'])){ echo $main['LastName']; } ?>"   >
                    </div>
                  </div>
                  <?php if($this->session->userdata('RoleName')=='Facility'){ ?>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label> Incharge Designation <!-- <span class="required"> * </span> --> </label>
                      <input maxlength="50" class="form-control" placeholder="Incharge Designation_main" id="Designation_main" name="Designation_main" type="text" value="<?php if(isset($main['Designation'])){ echo $main['Designation']; } ?>"   >
                    </div>
                  </div>
                  <?php } ?>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label> Mobile No. <span class="required"> * </span> </label>
                      <input maxlength="10" class="form-control nums" placeholder="Mobile No" id="Mobile_main" name="Mobile_main" type="text" value="<?php if(isset($main['Mobile'])){ echo $main['Mobile']; } ?>"   >
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label>Email Address <span class="required"> * </span> </label>
                      <input maxlength="254" class="form-control emailID" placeholder="Email Address" id="Email_main" name="Email_main" type="text" value="<?php if(isset($main['Email'])){ echo $main['Email']; } ?>"   >
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6 user_img">
                <center>
                  <?php 
                  if(!empty($main['Pic']) && is_file($main['Pic'])){
                    $pathMain=$main['Pic'];
                  } else {
                    $pathMain='assets/images/user.png';
                  }
                  ?>
                  <img src="<?php echo base_url().$pathMain;?>">
                  <!-- <p>Image Name</p> -->
                  <div class="form-group">                    
                    <br>
                    <input type="file" id="Pic_main" name="Pic_main" accept=".png,.jpg,.jpeg,.bmp,.PNG,.JPG,.JPEG,.BMP" onchange="checkFile(this)" class="inputfile inputfile-6 form-control" />
                    <label for="Pic_main"><span></span> <strong><i class="fa fa-upload"></i> Choose a file&hellip;</strong></label>
                  </div>
                </center>
              </div>

              <?php if($this->session->userdata('RoleName')!='Facility'){ ?>
                  <div class="col-md-12"></div>
                  <div class="col-md-12 deffr_head">
                    <h4>Nodal Officer</h4>
                  </div> 
                  <div class="col-md-6">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label>First Name <span class="required"> * </span> </label>
                          <input maxlength="30" class="form-control" placeholder="First Name" id="FirstName_nodal" name="FirstName_nodal" type="text" value="<?php if(isset($nodal['FirstName'])){ echo $nodal['FirstName']; } ?>"   >
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                          <label> Last Name <!-- <span class="required"> * </span> --> </label>
                          <input maxlength="30" class="form-control" placeholder="Last Name" id="LastName_nodal" name="LastName_nodal" type="text" value="<?php if(isset($nodal['LastName'])){ echo $nodal['LastName']; } ?>"   >
                        </div>
                      </div>
                      <div class="col-md-12">
                          <div class="form-group">
                              <label> Incharge Designation <!-- <span class="required"> * </span> --> </label>
                              <input maxlength="50" class="form-control" placeholder="Incharge Designation" id="Designation_nodal" name="Designation_nodal" type="text" value="<?php if(isset($nodal['Designation'])){ echo $nodal['Designation']; } ?>"   >
                          </div>
                      </div>

                      <div class="col-md-12">
                          <div class="form-group">
                              <label> Incharge Mobile No. <span class="required"> * </span> </label>
                              <input maxlength="10" class="form-control nums" placeholder="Mobile No." id="Mobile_nodal" name="Mobile_nodal" type="text" value="<?php if(isset($nodal['Mobile'])){ echo $nodal['Mobile']; } ?>"   >
                          </div>
                      </div>

                      <div class="col-md-12">
                          <div class="form-group">
                              <label> Email ID <span class="required"> * </span> </label>
                              <input maxlength="254" class="form-control emailID" placeholder="Email ID" id="Email_nodal" name="Email_nodal" type="text" value="<?php if(isset($nodal['Email'])){ echo $nodal['Email']; } ?>"   >
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6 user_img">
                    <center>
                      <?php 
                      if(!empty($nodal['Pic']) && is_file($nodal['Pic'])){
                        $pathNodal=$nodal['Pic'];
                      } else {
                        $pathNodal='assets/images/user.png';
                      }
                      ?>
                      <img src="<?php echo base_url().$pathNodal;?>">
                      <!-- <p>Image Name</p> -->
                      <div class="form-group">
                        
                        <br>
                        <input type="file" id="Pic_nodal" name="Pic_nodal" accept=".png,.jpg,.jpeg,.bmp,.PNG,.JPG,.JPEG,.BMP" onchange="checkFile(this)" class="inputfile inputfile-6 form-control" />
                    <label for="Pic_nodal"><span></span> <strong><i class="fa fa-upload"></i> Choose a file&hellip;</strong></label>
                        
                        
                    </div>
                    </center>
                  </div>
              <?php } ?>


              <div class="col-md-12">
                <div class="form-group">
                  <div class='input-group pull-right'>
                    <input style="margin-top: 15px; margin-right: 20px;" type='submit' id="profileBtn" name="profileBtn" value="Save" class="btn btn-info" />

                    <input type="button" style="margin-top: 15px; margin-right: 0px;" data-href="<?php echo base_url(); ?>" class="btn btn-danger" onclick="pageRedirect(this)" value="Cancel" >
                  </div>
                </div>
              </div>                    
            </form>
          </div>
        </div>

      </div>
    </div>



  </div>
</div>