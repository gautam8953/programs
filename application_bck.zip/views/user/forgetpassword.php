<!DOCTYPE html>
<html lang="en">
<head>
  <title>Laqshya</title>
  <meta charset="utf-8">
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
  <!-- Bootstrap -->
    <link href="<?php echo base_url();?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url();?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url();?>assets/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?php echo base_url();?>assets/vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url();?>assets/css/custom.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/css/pace-theme-mac-osx.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900|Open+Sans:400,600,700|Patua+One|Source+Sans+Pro:400,600,700" rel="stylesheet"> 
  
  <!-- <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

  <script src='https://www.google.com/recaptcha/api.js'></script>
  <script type="text/javascript">
    var pageMainUrl="<?php echo base_url();?>";
  </script>
  
  
  

  
</head>
<body class="login">

  <!--<div class="top_div">
    <div class="header-top">
      <div class="container">
        <div class="row">
          <div class="header-main">
          <div class="col-md-4">
             <div class="current-time">
              <?php echo date('d-m-y g:i:a'); ?> 
             </div>
             
             
          </div>
          <div class="col-md-8">
          <div class="topright">
            <div class="skip_to_main"> <a href="#">Skip to main content</a> </div>
              <ul class="top-m">
              <li class="fontS noback"><a   title="Decrease font size" href="#">A<sup>-</sup></a></li>
              <li class="fontS noback noPadding-left"> <a   title="Reset font size" href="#">A</a></li>
              <li class="fontS noback noPadding-left"> <a   title="Increase font size" href="#">A<sup>+</sup></a></li>
              <li class="blackA noback noPadding-right"> <a title="Dark"   class="dark" href="#">A</a> </li>
              <li class="greyA noback"><a title="Light"   class="light" href="#">A</a></li>
              </ul>
              
              
              <ul class="top-m social-icon-top">
              <li class="fontS noback"><a   title="Facebook" href="#"><i class="fa fa-facebook"></i></a></li>
              <li class="fontS noback noPadding-left"> <a   title="Twitter" href="#"><i class="fa fa-twitter"></i></a></li>
               
              </ul>
              
              <div class="searchbox">
              <div class="box">
                <input class="NormalTextBox" type="text" placeholder="Search..">
                <input class="SkinObject" type="submit" value="&#xf002;"> 
               </div>
              </div>
              
              
              <div class="languege-area"> <a href="#" class="pull-left"><img src="<?php echo base_url();?>assets/img/screen_reader_icon.png" width="30" height="16" alt=""></a>  
              <div class="pull-left" id="asdf">
                <p>Language</p>
                <select class="select-languege">
                <option selected="selected" value="en">English</option>
                <option value="hi">Hindi</option>
                </select>
              </div>
              </div>
              
            <div class="login-home">
            <?php $userID=$this->session->userdata('UserID'); if(!empty($userID)){ ?>
            <a href="#" id="logout"> Logout </a>
            <?php } else { ?>
            <a href="#" id="login"> Login </a>
            <?php }  ?>
            </div>
            
            
              
               
            
          </div>
          </div>
          </div>
         
        </div>
      </div>
      
      </div>
  
  </div>-->

  
  <header>
  
    <div class="header-bottom">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3 col-xs-4 indian-emblem"><img src="https://pmsma.nhp.gov.in/laqshya/assets/images/indianembelem_2.png" alt="Indian Emblem"></div>
          <div class="col-md-6 col-xs-12 text-center main-logo"><h1><span class="emonitoring">e-Monitoring System for LaQshya</span></h1></div>
          <div class="col-md-3 col-xs-3 nhp-logo"><a href="http://www.nihfw.org/" target="_blank"><img src="https://pmsma.nhp.gov.in/laqshya/assets/images/nihfw-logo.png" alt="NIHFW" class="ihd-logo"></a> <a href="https://www.nhp.gov.in/" target="_blank"><img src="https://pmsma.nhp.gov.in/laqshya/assets/images/logo-nhp.png" alt="NHP" class="nhp-logo"></a></div>
        </div>
       </div>
    </div>
  </header>


<!-- Page content -->
<div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content_pass">
            <form name="resetForm" id="resetForm" class="login-form" action="<?php echo base_url()."ApiUser/login"?>" method="post">
              <h1 style="padding-bottom: 10px;"><span style="position: absolute; top: -9px; left: 58px;">Reset Password</span></h1>
                
                    <div class="alert" id="msgDiv" style="display: none;">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                      <strong id="LoginMsg"></strong>
                    </div>
                    

                    
                    <div>
                      <input class="form-control" placeholder="Enter Username" id="username" name="username" type="text" autofocus  >
                    </div>
                    <div>
                      <input class="form-control" placeholder="Enter Old Password" id="oldPassword" name="oldPassword" type="password" value=""   >
                    </div>

                    <div>
                      <input class="form-control" placeholder="Enter New Password" id="newPassword" name="newPassword" type="password" value=""   >
                    </div>
                    <div>
                      <input class="form-control" placeholder="Re-Enter New Password" id="confirmPassword" name="confirmPassword" type="password" value=""   >
                    </div>

                    <div class="clearfix"></div>


                    <div class="for-pass-btn-block">

                      
                      <input name="loginBtn" id="loginBtn" type="submit" class="btn btn-info" value="Submit">

                      <a style="margin-right: 0px;" href="<?php echo base_url(); ?>" class="btn btn-danger"> Cancel</a>

                    </div>
                    
                    
                    
                    <!--<div class="col-md-6">
                         <a href="<?php echo base_url()."User/forgetpassword"?>" class="forget-pass"> Reset Password</a>
                    </div>-->
                </form>
            </section>
        </div> 
</div>




<script src="<?php echo base_url();?>assets/js/user/forgetpassword.js"></script>

