<script>
function printFunction() {
    window.print();
}
</script>

 <style type="text/css">
 @media print{

  /*********************************** this code is for print this page ************************************************/
    .indian-emblem .white_logo{display: none !important;}
    .indian-emblem .default_logo{display:block !important;     width: 278px;}
    span.emonitoring{position: inherit;}
    .nhp-logo{position: inherit;}
    .header-bottom .col-md-4{    width: 33.33333333% !important;} 
    .nhp-logo a{    padding: 0 !important;     float: left;    width: 50%;}
    .nhp-logo a:nth-child(2) img{    filter: invert(0); margin-right: 0;}
    .nhp-logo a:nth-child(1) img {    filter: invert(0%);}
    .score_p_num{    width: 122px;
    height: 141px;
    top: 27%;
    left: 48%;
    padding-top: 45px;
    transform: translate(-44%);
  font-size: 38px;}
  #standardScore{}
  #standardScore table th {
    width: 100%;
    padding: 5px 5px;
    text-align: center;
    border: 1px solid #ccc !important;
    background: #ececec !important;

}
body {
  -webkit-print-color-adjust: exact !important;
}
#standardScore table{width: 100%;     border: none !important;}
#standardScore table th{width: 100%;}
#standardScore table td{border: none !important;}
footer{display: none;}
.header-bottom{margin: 0px !important;}
.x_content{border: none; padding-top: 0;}
#standardScore table td{    border: none !important;    padding: 3px 6px 2px 6px !important;}
#standardScore thead {   display: table-row-group;}*/
td{page-break-inside: avoid;}
 table{ border: 1px solid #ccc !important;}
 .grey .table>thead>tr>th{border: 1px solid #ccc !important;}
  }
  .rtst-bx-scr{border: 1px solid #ccc !important;}

 </style>


 <div class="page-title">
  <div class="title_left">
    <h3>Manage Assessment</h3>
  </div>

   
</div>

<div class="clearfix"></div> 


<div class="main-content"> 
    <div class="container">
      <div class="row">


            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <div class="row">
                  <div class="col-md-8 col-sm-8 col-xs-8">
                    <div class="row">
                      <h2>Assessment Score</h2>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="row">
                      <ul class="nav navbar-right panel_toolbox">
                        <div class="print-score">
                          <a href="javascript:void(0);" onclick="printFunction()"><i class="fa fa-print"> | Print</i></a>
                        </div>
                        <!-- <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>-->
                       
                      </ul>
                    </div>
                  </div>
                </div>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content x_content_print">


                <h4><b>Assessment Details</b> <span class="FacilityName"></span></h4>
              <div class="assess-detail">
              <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label> Assessment Type: <span class="sequence"> Example</span> </label>
                        
                    </div>
                </div>            
               
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Date of Assessment: <span class="assessmentDate"> Example</span> </label>
                            
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessor 1:<span class="assessorsName1"></span> </label>
                    
                        </div>
                    </div>
                    
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessor 2:<span class="assessorsName2"></span> </label>
                          
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessee 1:<span class="assesseesName1"></span> </label>
                          
                        </div>
                    </div>


                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label> Name of Assessee 2:<span class="assesseesName2"></span> </label>
                          
                        </div>
                    </div>
                    

                    <div class="clear"></div>
                    <hr>






    <form name="scoreForm" id="scoreForm" class="login-form login_form_mine sore-table-new" action="<?php echo base_url()."ApiFacility/savescore"?>"> 
    <div class="alert" id="msgDiv" style="display: none;">
        <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
      <strong id="LoginMsg"></strong>
    </div>
      <div class="row">
            <div class="col-md-12">
              <div class="row">
                <h4 id="assementName" class="title-mine"></h4>
              </div>
                
            </div>


            <div class="col-md-12 col-xs-12 col-sm-12 dsp-flx">
            <div class="col-md-8 col-sm-6 col-xs-12 pad-bg">
              <div class="row">
              <div class="table-responsive">
                <table id="score" class="table table-striped table-bordered" width="100%">
                    <thead>
                        <tr>
                            <th colspan="5" class="text-center dif-bg" >Area of Concern wise score </th>
                        </tr>
                        <tr>
                          <th class="text-center">Code</th>
                          <th class="text-center">Area of Concern</th>
                          <th class="text-center">Marks</th>
                          <th class="text-center">Total Marks</th>
                          <th class="text-center">Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
              </div>
            </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">                 
                <div class=" rtsd-bx rtst-bx-scr">
                  <div class="border">
                    <h2 style="text-align: center;"> Score</h2>
                    <p id="totScore" class="score_p_num">0.00%</p>
                  </div>
                </div>
            </div>
          </div>
      </div>

    </form>
  </div>
</div>
</div>


</div>

  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_title">
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
      <h4><b>Standard Wise Score</b></h4>
        <div class="row">
          <div class="col-md-12">
            <div class="table-responsive">
              <table id="standardScore" class="table table-striped table-bordered" width="100%">
                  <thead>
                  </thead>
                  <tbody>                    
                  </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="clear"></div>
        <hr>
    </div>
  </div>
</div>


<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      
      <div class="x_content">
          <div class="row">
        <div class="col-md-12">
            
            <label class="mar-bot-20">Client Satisfaction Score </label>
            
            
              <p class="normal_font remarks clientScore" ></p>
                    
        </div>

        <div style="clear: both;"></div>

        <div class="col-md-12">
            
            <h4>Major Gaps Observed </h4>
           
            
            
        </div>
        <div class="col-md-12 q1" >
            
              <div class="form-group">
                <p class="normal_font remarks q1" ></p><br>
              </div>
            
            
            
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
            
              <h4>Strengths / Good Practices  </h4>
            
            
            
        </div>
        <div class="col-md-12 q2" >
            
              <div class="form-group">
                <p class="normal_font remarks q2" ></p><br>
              </div>
            
            
            
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
            
            <h4>Recommendations/ Opportunities for Improvement </h4>
            
             
            
        </div>
        <div class="col-md-12 q3" >
            
              <div class="form-group">
                <p class="normal_font remarks q3" ></p><br>
              </div>
            
           
            
        </div>
        <input type='hidden' name="ansId" id="ansId" value="<?php echo $this->uri->segment('3'); ?>" class="" />
      </div>
      </div>
    </div>
  </div>



</div>
</div>
</div>