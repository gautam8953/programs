 
<style>
body {
  margin: 0px;
  box-sizing: border-box;
  position: relative;
  font-family: sans-serif;
  font-size: 10px;
  line-height:10px;

}

table{width: 100%;}
.score-border td{font-size: 8px;}
span.title {
  font-weight: 600;
  margin-bottom: 3px;
  display: block;
}

tr {
  list-style: none;
  padding: 0;
  margin: 0px 0px;
}
td, th {
  vertical-align: top;
  padding: 0px 10px;
  font-size: 10px;
  line-height: 150%;
  text-align:center;
  vertical-align: middle;
}
.score-border th{ font-size:9.5px; }
.score-border td{font-weight:bold; font-size: 11px; }

h1 {margin-bottom: 40px; text-align: center; font-weight: 400; }
h2 {width: 100%;
  font-size: 12px;
  margin-top: 20px;
  font-weight: 600;}

  h3 { margin: 0; width: 100%;
     font-weight: 600;}
     p {    width: 100%;
        font-size: 10px;
        float: left; padding: 0px 10px;}
        header{border: none;}    

    </style>


    <table cellpadding="5" cellspacing="0"   align="center" style="border-bottom:2px solid #344c98 ">
        <tr class="heading" >
          <td valign="middle" align="left" cellpadding="20" >
            <br><br><br>
            <img src="<?php echo base_url();?>/assets/images/laqshya-logo-pdf.png" style="width:120px; margin-top: 20px" ></td>
            <td valign="middle" style="text-align: center"><img src="<?php echo base_url();?>/assets/images/Emblem_of_India.svg" style="height:75px"></td> 
            <td valign="middle" align="right" style="font-size:9px" ><b style="font-size:14px"><br>LaQshya  </b><br>
              Ministry of Health and <br>
              Family Welfare (MoHFW) <br>
          Government of India</td>

      </tr>

  </table>
  <br><br>
  <table cellpadding="5" cellspacing="0"  bgcolor="#eaf1f7">
     <tr class="heading" >
        <td style="font-size:13px; text-align: center; color: #344c98;"> <b>Laqshya Indicator Report</b></td>
    </tr>
</table>

<br><br>
<?php if(isset($indicator_data['totalData']) && $indicator_data['totalData']>0){ foreach ($indicator_data['data'] as $key => $value) { ?>
    <table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff; line-height: 100%;  " class="score-border">
       <tr bgcolor="#e1e8ff">
          <th>Month</th>
          <th>Facility has assessed Labour Room and OT using NQAS checklist and reported Baseline Quality Scores</th>
          <th>Facility has set Quality Team at facility level and Quality Circles in Labour Room & Maternity Ots</th>
          <th>Facility has oriented the Labour room and Maternity OT staff on LR protocols, RMC & QI</th>
      </tr> 

      <tr>
          <td><?php echo $value[0]; ?></td>
          <td><?php echo $value[1]; ?></td>
          <td><?php echo $value[2]; ?></td>
          <td><?php echo $value[3]; ?></td>

      </tr>


  </table>  
      <br><br>

      <table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff; line-height: 100%;" class="score-border">

    <tr bgcolor="#e1e8ff">
        <th>Percentage of deliveries are attended by a birth companion</th>
        <th>Percentage deliveries are conducted using safe birth checklist in Labour Room</th>
        <th>Percentage of deliveries are conducted using Safe Surgery checklist in Maternity OT</th>
        <th>Percentage of deliveries for which Partograph is generated using real-time information in at least</th>
    </tr> 

    <tr>
      <td><?php echo $value[4]; ?></td>
      <td><?php echo $value[5]; ?></td>
      <td><?php echo $value[6]; ?></td>
      <td><?php echo $value[7]; ?></td>

  </tr>


</table>

<br><br>



<table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff; line-height: 100%;" class="score-border">
    <tr bgcolor="#e1e8ff">
       <th>Percentage breastfeeding within 1 hour</th>
       <th> Neonatal asphyxia rate in Inborn Babies</th>
       <th> Neonatal sepsis rate in-born babies</th>
       <th> Surgical Site infection Rate in Maternity OT</th>
   </tr>
   <tr>
     <td><?php echo $value[8]; ?></td>
     <td><?php echo $value[9]; ?></td>
     <td><?php echo $value[10]; ?></td>
     <td><?php echo $value[11]; ?></td>

 </tr>


</table>

<br><br>




<table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff; line-height: 100%;" class="score-border">

    <tr bgcolor="#e1e8ff">
        <th>Antenatal corticosteroid administration rate in case in preterm labour</th>
        <th>Pre-eclampsia, eclampsia & PIH related mortality</th>
        <th> APH/PPH related mortality</th>
        <th>Facility Labour Room is reorganized as labour room standardization guidelines</th>
    </tr>

    <tr>
        <td><?php echo $value[12]; ?></td>
        <td><?php echo $value[13]; ?></td>
        <td><?php echo $value[14]; ?></td>
        <td><?php echo $value[15]; ?></td>

    </tr>


</table>

<br><br>



<table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff; line-height: 100%;" class="score-border">

    <tr bgcolor="#e1e8ff">
     <th>Facility Labour room has staffing as per defined norms</th>
     <th>Percentage of Women, administered Oxytocin, immediately after birth.</th>
     <th>OSCE Score</th>
     <th>Facility conducts referral audit on Monthly basis</th>
 </tr>

 <tr>
     <td><?php echo $value[16]; ?></td>
     <td><?php echo $value[17]; ?></td>
     <td><?php echo $value[18]; ?></td>
     <td><?php echo $value[19]; ?></td>
 </tr>


</table>

<br><br>


<table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff; line-height: 100%;" class="score-border">

    <tr bgcolor="#e1e8ff">
     <th>Facility conducts Maternal death, Neonatal death and near-miss on monthly basis</th>
     <th>Facility report zero stock outs in Labour Room & Maternity OT</th>
     <th>Still Birth Rate</th>
     <th>Percentage of beneficiaries who were either satisfied or highly satisfied</th>
 </tr>

 <tr>
     <td><?php echo $value[20]; ?></td>
     <td><?php echo $value[21]; ?></td>
     <td><?php echo $value[22]; ?></td>
     <td><?php echo $value[23]; ?></td>
 </tr>


</table>

<br><br>


<table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff; line-height: 100%;" class="score-border">

    <tr bgcolor="#e1e8ff">
      <th>functional Obs ICU/Hybrid ICU/HDU?</th>
      <th>Microbiological Surveillance in OT & LR</th>
      <th>Labour Room Quality Score Improvement from Baseline</th>
      <th>Maternity OT Quality Score Improvement from Baseline</th>
  </tr>

  <tr>
      <td><?php echo $value[24]; ?></td>
      <td><?php echo $value[25]; ?></td>
      <td><?php echo $value[26]; ?></td>
      <td><?php echo $value[27]; ?></td>
  </tr>


</table>

<br><br>







<?php } } else { ?>
<table cellpadding="5" cellspacing="0" style="border: 1px solid #e1e8ff; line-height: 100%;  " class="score-border">
   <tr bgcolor="#e1e8ff">
      <th>No Data Submitted in <?php echo $indicator_data['monthdate']; ?></th>
  </tr> 
</table>
<?php } ?>
<br><br>

