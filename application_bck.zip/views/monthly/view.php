
<div class="page-title">
    <div class="title_left">
        <h3>Monthly Reporting (View Only)</h3>
    </div>
 
</div>

<div class="main-content">  
  <div class="tab-head1">
    <div class="container">
      <div class="row">
        <div class="form-main-labour">
          <!-- <h3>Monthly Reporting (View Only)<span class="downlo-btn-form"></span><h3>-->
            <form name="monthlyForm" id="monthlyForm" class="login-form login_form_mine" action="<?php echo base_url()."ApiMonthly/save"?>" method="post">
            <div id="">
              <!---<ul>
                <li><a href="#step-1"><span><em> 1 </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>General Information<br /></a></li>
                <li><a href="#step-2"><span><em> 2 </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>One time Reporting <br /></a></li>
                <li><a href="#step-3"><span><em> 3 </em> <i class="fa fa-check-circle-o" aria-hidden="true"></i></span>Monthly reporting indicators<br /></a></li>
            </ul>-->
            <div>
                <!-- Tab Start -->
                <div id="step-1">
                    <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>General Information</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content x_content_mine">
                    <div class="list-report-monthly report-monthly-first report-monthly-first1">
                        <h5 class="tab-title">Section 1: General Information </h5>

                        
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Name of State <span class=""> : </span> <span class="normal_font" id="FacilityState"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Name of District <span class=""> : </span> <span class="normal_font" id="FacilityDistrict"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Type of Facility <span class=""> : </span> <span class="normal_font" id="FacilityType"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Name of Facility <span class=""> : </span> <span class="normal_font" id="FacilityName"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">

                                <div class="form-group">
                                    <label> Reporting Month <span class=""> : </span> <span class="normal_font" id="ReportMonth"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">

                                <div class="form-group">
                                    <label> Date of Data Collection/Visit : <span class="normal_font" id="CollectionDate"></span> </label>
                                    
                                </div>
                            </div>






                            
                            


                    </div>
                </div>
            </div>
            </div>
        </div>
                </div>
                <!-- Tab End -->
                









                <!-- Tab Start -->
                <div id="step-3">
                    <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Monthly Reporting Indicators</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content x_content_mine">
                    <div class="list-report-monthly report-monthly-second  report-monthly-second1">
                        <h5 class="tab-title">Section 3:  Monthly Reporting Indicators </h5>

                        <div class="">
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total Number of Normal Vaginal Deliveries <span class=""> : </span> <span class="normal_font" id="TotalNormalVaginalDeliveries"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total Number of Assisted Vaginal Deliveries <span class=""> : </span> <span class="normal_font" id="TotalAssistedVaginalDeliveries"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total Number of C-Sections <span class=""> : </span> <span class="normal_font" id="TotalCSections"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total Number of Deliveries <span class=""> : </span> <span class="normal_font" id="TotalDeliveries"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-12 col-md-12 col-xs-12" style="background: #c1e5ff;">
                                <h5><strong> Causes of Maternal Deaths </strong> </h5>
                                
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> APH <span class=""> : </span> <span class="normal_font" id="MaternalAPH"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> PPH <span class=""> : </span> <span class="normal_font" id="MaternalPPH"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>  Sepsis <span class=""> : </span> <span class="normal_font" id="MaternalSepsis"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>  Obstructed labour <span class=""> : </span> <span class="normal_font" id="MaternalObstructedLabour"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>  PIH/Eclampsia <span class=""> : </span> <span class="normal_font" id="MaternalPIHEclampsia"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>  Others <span class=""> : </span> <span class="normal_font" id="MaternalOthers"></span></label>
                                    
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total Number of Maternal Deaths <span class=""> : </span> <span class="normal_font" id="TotalMaternalDeaths"></span></label>
                                    
                                </div>
                            </div>

                            
                            


                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total number of Fresh Still births <span class=""> : </span> <span class="normal_font" id="TotalFreshStillBirths"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total number of macerated still births <span class=""> : </span> <span class="normal_font" id="TotalMaceratedStillBirths"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total number of still births <span class=""> : </span> <span class="normal_font" id="TotalStillBirths"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total number of live births <span class=""> : </span> <span class="normal_font" id="TotalLiveBirths"></span></label>
                                    
                                </div>
                            </div>


                            
                            

                            <div class="col-md-12 col-md-12 col-xs-12" style="background: #c1e5ff;">
                                <h5><strong> Major causes of neonatal deaths  </strong> </h5>
                                
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Prematurity <span class=""> : </span> <span class="normal_font" id="NeonatalPrematurity"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Sepsis <span class=""> : </span> <span class="normal_font" id="NeonatalSepsis"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>  Asphyxia <span class=""> : </span> <span class="normal_font" id="NeonatalAsphyxia"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Others <span class=""> : </span> <span class="normal_font" id="NeonatalOthers"></span></label>
                                    
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Number of neonatal deaths <span class=""> : </span> <span class="normal_font" id="NumberNeonatalDeaths"></span></label>
                                    
                                </div>
                            </div>

                            
                            

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total number of Low Birth Weight babies born in facility <span class=""> : </span> <span class="normal_font" id="TotalLowBirthWeightBabies"></span> </label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label> Total no. of Preterm Deliveries <span class=""> : </span> <span class="normal_font" id="TotalPretermDeliveries"></span></label>
                                    
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of normal deliveries conducted in presence of Birth Companion
                                    <span class=""> : </span> <span class="normal_font" id="BirthCompanionNos"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of normal deliveries conducted using Safe Birth Checklist
                                    <span class=""> : </span> <span class="normal_font" id="SafeBirthChecklist"></span></label>
                                    
                            </div>
                        </div>
                    </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of planned and emergency C-Section operations where safe surgical checklist was used
                                    <span class=""> : </span> <span class="normal_font" id="CSectionOTSafeChecklist"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of normal deliveries conducted using real time Partograph
                                    <span class=""> : </span> <span class="normal_font" id="RealTimePartograph"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of newborns delivered in facility who were breastfed within one hour of delivery?
                                    <span class=""> : </span> <span class="normal_font" id="BreastfedNewborns"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether microbiological sampling from labour room is collected as per protocol

                                    <span class=""> : </span> <span id="MCBSamplingLR" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether microbiological sampling from Maternity OT is collected as per protocol

                                    <span class=""> : </span> <span id="MCBSamplingOT" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>

                        
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of C-Sections operations in which surgical site infection developed within one month of operation
                                    <span class=""> : </span> <span class="normal_font" id="CSectionsInfection"></span></label>
                                    
                            </div>
                        </div>

                        
                            <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of preterm cases where Antenatal Corticosteroids (ANCS) was administered in facilities 
                                    <span class=""> : </span> <span class="normal_font" id="PretermANCSInFacilitiesSNCU"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of newborns delivered in facility developed birth asphyxia <span class=""> : </span> <span class="normal_font" id="NewbornsSNCUAsphyxia"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of newborns delivered in facility developed sepsis <span class=""> : </span> <span class="normal_font" id="NewbornsSNCUSepsis"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Total number of inborn LBW newborns in facility provided KMC
                                    <span class=""> : </span> <span class="normal_font" id="InbornLBWKMC"></span></label>
                                    
                            </div>
                        </div>

                       
                            <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of beneficiaries delivered last month who were either satisfied or highly satisfied

                                    <span class=""> : </span> <span class="normal_font" id="SatisfiedDelivered"></span></label>
                                    
                            </div>
                        </div>


                        
                       


                       <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether facility has reorganized labour room as per the guidelines?

                                    <span class=""> : </span> <span id="ReorganizedLR" class="radioOpt normal_font"></span>
                            </label>
                                    
                        </div>
                    </div>
               

                       
                            <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether facility has adequate staff at labour rooms as per defined norms?

                                    <span class=""> : </span> <span id="AdequateStaffLR" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of deliveries conducted in facility where Oxytocin was administered within one minute of birth

                                    <span class=""> : </span> <span class="normal_font" id="OxytocinCount"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of maternal deaths were reviewed in last month

                                    <span class=""> : </span> <span class="normal_font" id="MaternalDeathsReviewed"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of neonatal deaths were reviewed in last month

                                    <span class=""> : </span> <span class="normal_font" id="NeonatalDeaths"></span></label>
                                    
                            </div>
                        </div>
                    

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of Maternal Near Miss Cases were reviewed in last month <span class=""> : </span> <span class="normal_font" id="MaternalMissCases"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of Referral cases reviewed in the month
                                    <span class=""> : </span> <span class="normal_font" id="ReferralCases"></span></label>
                                    
                            </div>
                        </div>
                    

                        
                       


                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether there was any stock outs of drugs and consumables in LR <span class=""> : </span> <span id="StockOutsInLR" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether there was any stock outs of drugs and consumables in maternity OT <span class=""> : </span> <span id="StockOutsInOT" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>
                    

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether facility labour room has achieved NQAS certification
                                    <span class=""> : </span> <span id="NQASCertification" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>

                        

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Whether MCH/DH has functional Obs ICU/Hybrid ICU/HDU?
                                    <span class=""> : </span> <span id="MCHDHFunctional" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>

                        
                        



                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of LaQshya mentoring visits conducted
                                    <span class=""> : </span> <span class="normal_font" id="LaQshyaMentoringVisitsConducted"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of QI team meetings at labour room/OT

                                    <span class=""> : </span> <span class="normal_font" id="QITeamMeetings"></span></label>
                                    
                            </div>
                        </div>
                    

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Number of onsite training session conducted

                                    <span class=""> : </span> <span class="normal_font" id="TrainingSessionConducted"></span></label>
                                    
                            </div>
                        </div>

                         <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> No. of deliveries done at Night 

                                    <span class=""> : </span> <span class="normal_font" id="NoOfDeliveriesdoneNight"></span></label>
                                    
                            </div>
                        </div>

                    <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>No. of C-sections done at Night 

                                    <span class=""> : </span> <span class="normal_font" id="NoOfCsectionsDoneNight"></span></label>
                                    
                            </div>
                        </div>


                     <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>No. of elective C-sections

                                    <span class=""> : </span> <span class="normal_font" id="NoofelectiveCsections"></span></label>
                                    
                            </div>
                        </div>


               

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>No. of babies required resuscitation

                                    <span class=""> : </span> <span class="normal_font" id="NoofbabiesRequiredResuscitation"></span></label>
                                    
                            </div>
                        </div>


                    <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>No of cases referred out to OT

                                    <span class=""> : </span> <span class="normal_font" id="NoofCasesReferredouttoOT"></span></label>
                                    
                            </div>
                        </div>

                 <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Total no. of admission in the labour room

                                    <span class=""> : </span> <span class="normal_font" id="TotalnoAdmissionLabourroom"></span></label>
                                    
                            </div>
                     </div>

                <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Total no. of Obstetric Complications Managed

                                    <span class=""> : </span> <span class="normal_font" id="ObstetricComplicationsManaged"></span></label>
                                    
                            </div>
                     </div>

                <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Total no. of PPIUCD inserted

                                    <span class=""> : </span> <span class="normal_font" id="TotaNoPPIUCDInserted"></span></label>
                                    
                            </div>
                     </div>

                <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Number of cancelled C-section

                                    <span class=""> : </span> <span class="normal_font" id="NumberCancelledCsection"></span></label>
                                    
                            </div>
                     </div>

                <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Total C-section conducted

                                    <span class=""> : </span> <span class="normal_font" id="TotalCsectionconducted"></span></label>
                                    
                            </div>
                     </div>

                <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>No of Perioperative deaths in OT during C-Section

                                    <span class=""> : </span> <span class="normal_font" id="PerioperativedeathsSection"></span></label>
                                    
                            </div>
                     </div>

                <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Total no. of adverse event cases in Labour Room

                                    <span class=""> : </span> <span class="normal_font" id="AdverseeventCasesLabourRoom"></span></label>
                                    
                            </div>
                     </div>
                    

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Current Maternity OT Quality Score <span class=""> : </span> <span class="normal_font" id="CurrentMaternityOTQualityScore"></span></label>
                                    
                            </div>
                        </div>

                        <!-- <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Current OSCE Score <span class=""> : </span> </label>
                                    <span class="normal_font" id="CurrentOSCEScore"></span>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
                </div>
                <!-- Tab End -->








                <!-- Tab Start -->
                <div id="step-2">
                    <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>One time Reporting</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content x_content_mine">
                    <div class="list-report-monthly report-monthly-third">
                        <h5 class="tab-title">Section 2:  One time Reporting </h5>
                        <div class="col-md-12 col-md-12 col-xs-12" style="background: #c1e5ff; border-top: 1px solid #bbb;">
                            <div class="row">
                            <h6>labour room assessment</h6>
                        </div>
                            
                        </div>


                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility has completed baseline assessment of labour room using NQAS checklist


                                    <span class=""> : </span> <span id="BaselineNQASChecklistLR" class="normal_font radioOpt"></span></label>
                                    
                            </div>
                        </div>


                        <div class="col-md-4 col-sm-6 col-xs-12">

                            <div class="form-group">
                                <label>Month of assessment <span class=""> : </span> <span class="normal_font" id="AssessmentMonthLR"></span></label>
                                    
                            </div>
                        </div>


                        
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Baseline Score for Labour Room  <span class=""> : </span> <span class="normal_font" id="BaselineScoreLR"></span></label>
                                    
                            </div>
                        </div>

                        <div class="col-md-12 col-md-12 col-xs-12" style="background: #c1e5ff;">
                            <div class="row">
                                <h6>Operation Theatre assessment</h6>
                            </div>
                        </div>



                       
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility has completed baseline assessment of Operation Theatre using NQAS checklist <span class=""> : </span> <span id="BaselineNQASChecklistOT" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>


                        <div class="col-md-4 col-sm-6 col-xs-12">

                            <div class="form-group">
                                <label>Month of assessment <span class=""> : </span> <span class="normal_font" id="AssessmentMonthOT"></span></label>
                                    
                            </div>
                        </div>


                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Baseline Score for Operation Theatre  <span class=""> : </span> <span class="normal_font" id="BaselineScoreOT"></span></label>
                                    
                            </div>
                        </div>

                        

                        <!-- <div class="col-md-12">
                            
                            <h6><strong>Staff competence  assessment </strong> </h6>
                            
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility has assessed  baseline staff competence using the OSCE <span class=""> : </span> </label>
                                    <span id="BaselineStaffCompetenceOSCE" class="radioOpt normal_font"></span>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Month of assessment <span class=""> : </span> </label>
                                    <span class="normal_font" id="AssessmentMonthOSCE"></span>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Baseline average  OSCE Score    <span class=""> : </span> </label>
                                    <span class="normal_font" id="BaselineAvgOSCEScore"></span>
                            </div>
                        </div> -->



                        
                        <div class="col-md-12 col-md-12 col-xs-12" style="background: #c1e5ff;">
                            <div class="row">
                            <h6>Facility report</h6>
                        </div>
                            
                        </div>



                       
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility has setup facility level quality team  <span class=""> : </span> <span  id="QualityTeamFacility" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>


                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility has setup functional quality circle in Labour Room  <span class=""> : </span> <span id="QualityCircleLR" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>

                        
                        
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility has setup functional quality circle in Maternity OT  <span class=""> : </span> <span id="QualityCircleOT" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>


                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label> Facility staff of LR and OT quality circles have attended district level or facility level orientation on LR Protocols, QI processes and RMC  <span class=""> : </span> <span id="OrientationAttended" class="radioOpt normal_font"></span></label>
                                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
                </div>
                <!-- Tab End -->
            </div>
        </div>
        <input type='hidden' name="MonthlyID" id="MonthlyID" value="<?php echo $this->uri->segment('3'); ?>" class="" />
    </form>
    </div>
</div>
</div>
</div>  
</div>

<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>

<style>
    .form-group{margin-bottom: 5px; padding: 6px 0px;}
    .list-report-monthly .col-md-12{background: #f1f1f1;border-bottom: 1px solid #ccc;}
    .list-report-monthly .col-md-4{background: #e7f5ff;
                                    border-bottom: 1px solid #94d2ff;
                                    padding: 10px;
                                    border-right: 1px solid #94d2ff;
                                    color: #000;}



    .report-monthly-second .col-md-4{min-height: 102px;}

    .report-monthly-third .col-md-4{min-height: 80px;}

    .list-report-monthly .col-md-4 label{font-size: 14px !important; line-height: 21px; font-weight: bold !important;}
    .list-report-monthly > h5.tab-title{margin-bottom: 0px;}
    .list-report-monthly > .col-md-12 > .row > h6{padding: 3px 10px;}
    #step-3 .x_content .form-group label{margin-bottom: 0px;}
    .list-report-monthly > .col-md-12 > .row > h6{background: none;}

    .form-main-labour h3:first-child{margin-left: 25px;}
</style>