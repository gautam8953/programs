<div class="page-title">
  <div class="title_left">
    <h3>Mentor Form</h3>
  </div>

  <div class="title_right">
    <!---<div class="col-md-12 col-sm-12 col-xs-12 form-group pull-right top_search">--->

  </div>
</div>

<div class="clearfix"></div>

<div class="main-content"> 
    <div class="container">
    <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Mentor Add</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    <!--<li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>-->
                    <!--<li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>-->
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">  
        <?php 
        $attr = array("class" => "form-horizontal", "role" => "form", "id" => "uploaForms", "name" => "uploaForm");
        echo form_open("ApiMentor/mentoradd", $attr); ?>
	    <div class="row">
                <div class="col-md-4 col-xs-12">
                     <div class="form-group">
                        <label>Name <span class="required"> * </span> </label>                        
                       <select id="mentorName" name="mentorName" class="form-control">
                        <option value="">Select </option>
                        <?php foreach ($mentor['Mentoruser'] as $key => $value) { 
                            if($value['UserID']==$this->session->userdata('UserID'))
                                $select = 'selected="selected"';
                            else
                                $select = '';
                            

                         ?>

                        <option value="<?php echo $value['UserID']; ?>" <?php echo $select; ?>><?php echo $value['FirstName']; ?></option>
                        <?php } ?>
                        </select>                            
                    </div>
                </div>

               <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label>Name of organization <span class="required"> * </span> </label>                        
                            <input type='text' id="OrganizationName" name="OrganizationName"  placeholder="Name of organization" class="form-control " value="<?php if($this->uri->segment('3')!=''){ echo $main['OrganizationName']; } ?>" />                       
                    </div>
                </div>
            	<?php if(isset($search_options['State']) ){ ?>
                <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label> State <span class="required"> * </span> </label>
                        <select id="search_state" name="search_state" onchange="change_state()" class="form-control">
						<option value="">Select State</option>
						<?php foreach ($search_options['State'] as $key => $value) {  ?>
						<option value="<?php echo $value['StateID']; ?>" ><?php echo $value['StateName']; ?></option>
						<?php } ?>
						</select>
					</div>
                </div>
                <?php } ?>
                <?php if(isset($search_options['District']) ){ ?>
                <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label> District <span class="required"> * </span> </label>                    
                	<select id="search_district" name="search_district" onchange="change_district()" class="form-control">
						<option value="">Select District</option>
						<?php foreach ($search_options['District'] as $key => $value) { ?>
						<option value="<?php echo $value['DistrictID']; ?>" ><?php echo $value['DistrictName']; ?></option>
						<?php } ?>
					</select>                    
				</div>
                </div>
                <?php } ?>
                <?php if(isset($search_options['Facility']) ){ ?>
                <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label> Facility <span class="required"> * </span> </label>
                	    <select id="search_facility" name="search_facility" class="form-control">
						<option value="">Select Facility</option>
					</select>                    
				</div>
                </div>
                <?php } ?>
               <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label> Date of visit <span class="required"> * </span> </label>                        
                            <input type='text' id="Date_of_visit" name="Date_of_visit"  placeholder="DD-MM-YYYY" class="form-control datepicker" value="<?php //echo date('dd-mm-Y') ?>" />                        
                    </div>
                </div>
  
                 <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label>Upload Key findings <span class="required"> * </span> </label>
                        <br>
                        <input type="file" id="Keyfindings" name="Keyfindings" accept=".csv,.xls,.xlsx" onchange="checkFilekey(this)" class="inputfile inputfile-6 form-control" data-multiple-caption="{count} files selected" />
                    <label for="Keyfindings"><span></span> <strong><i class="fa fa-upload"></i> Choose a file&hellip;</strong></label>
                    <?php if($this->uri->segment('3')!=''){?>
                         <input type="hidden" name="mentordataID" id="mentordataID" value="1">
                         <input type="hidden" name="keyFind" id="keyFind" value="">
                         <input type="hidden" name="recfile" id="recfile" value="">
                         <a href="#"  id="Keyfindings_file" class="btn btn-primary">View Key findings</a>
                   <?php } ?>
                        
                        
                    </div>
                </div>

                <div class="col-md-4 col-xs-12">
                    <div class="form-group">
                        <label>Upload Recommendations <span class="required"> * </span> </label>
                        <br>
                        <input type="file" id="recommendations" name="recommendations" accept=".csv,.xls,.xlsx" onchange="checkFileRec(this)" class="inputfile inputfile-6 form-control" data-multiple-caption="{count} files selected" />
                    <label for="recommendations"><span></span> <strong><i class="fa fa-upload"></i> Choose a file&hellip;</strong></label>
                         <?php if($this->uri->segment('3')!=''){?>
                         <a  href="#" id="recommendations_file" class="btn btn-primary">View Recommendations</a>
                          <?php } ?>
                        
                    </div>
                </div>
                <div class="col-md-12 col-xs-12">
                    <div class="col-md-2" style="float: right; margin-top: 10px;">
                        <input type="hidden" name="pmuID" id="pmuID" value="<?php echo $this->uri->segment('3');?>">
                        <input minlength="10" maxlength="10" type='hidden' id="submissionDate" name="submissionDate" placeholder="DD-MM-YYYY" class="form-control datepicker" value="<?php echo date('d-m-Y'); ?>" />
                        <input type='submit' name="btn_upload" value="Upload" class="form-control btn btn-info" />
                    </div>
                </div>
	    </div>
		<?php echo form_close(); ?>
          <div class="row">
            <div class="col-md-12 errDivUpload">
              
            </div>
          </div>
    </div>
</div>
</div>
</div>
</div>
</div>