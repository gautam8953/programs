<style>
    .erroShow { border:1px solid red};
    .erroHide { border:none};
</style>

<div class="page-title">
    <div class="title_left">
        <h3>Mentor Form View</h3>
    </div>


</div>

<div class="clearfix"></div>

  

      
               
<?php if (!empty($main)) { ?>

<div class="main-content"> 
    <div class="container">   
  <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Mentor View</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content x_content_mine list-report-monthly report-monthly-first report-monthly-first1">

                         <div class="col-md-6">
                                <div class="form-group">
                                    <label> Name of Facility<span class=""> : </span> <span ><?php if(isset($facility)){ echo $facility['FacilityName']; };  ?></span></label>
                                    
                                </div>
                            </div>
                             <div class="col-md-6 ">
                                <div class="form-group">
                                    <label> Type of Facility <span class=""> : </span> <span ><?php if(isset($facility['FacilityTypeDetailID']) && $facility['FacilityTypeDetailID']){ echo $facility['TypeDetailCode'] ; } ?> </span></label>
                                    
                                </div>
                            </div>
                       
   
             <div class="col-md-6" >
                <div class="form-group">
                  <label>Mentor Name : <span ><?php if(isset($main)){ echo $main['FirstName']; };  ?> </span ></label> 
                </div>
              </div>
                <div class="col-md-6" >
                <div class="form-group">
                  <label>Organization Name : <span ><?php if(isset($main)){ echo $main['OrganizationName']; };  ?> </span ></label> 
                </div>
              </div>
              
          
              <div class="col-md-6">
                <div class="form-group">
                  <label>State Name<span class="required">  </span> : <span class=""> : </span> <span ><?php if(isset($facility['StateName']) && $facility['StateName']){ echo $facility['StateName'] ; } ?> </span></label> 
                 
                </div>
              </div>
           
           
              <div class="col-md-6">
                <div class="form-group">
                  <label>District Name<span class="required">  </span> : <span class=""> : </span> <span ><?php if(isset($facility['DistrictName']) && $facility['DistrictName']){ echo $facility['DistrictName'] ; } ?> </span></label> 
                 </div>

              </div>
                 
              <div class="col-md-6">
                <div class="form-group">
                  <label>Date of visit :<span> <?php if(isset($main)){ echo date("d-m-Y", strtotime($main['Date_of_visit'])); }  ?></span></label>
                
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Key findings file : <span><?php if(isset($main)){ ?><a href="<?php echo base_url();?>assets/uploads/mentor/<?php echo $main['Keyfindings'];?> ">Download</a> <?php  };  ?></span></label>
                 
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label> Recommendations file : <span><?php if(isset($main)){ ?><a href="<?php echo base_url();?>assets/uploads/mentor/<?php echo $main['recommendations'];?> ">Download</a> <?php  };  ?></span></label>
                 
                </div>
              </div>
   
                 <div class="clearfix"></div>

                    </div>
                </div>
            </div>
        </div>
          
</div>
</div>
                    
                        
   
 <?php }else{ ?>
  <center><h3>No  Data Available </h3></center>
<?php } ?>


      


<script src="<?php echo base_url();?>assets/js/jquery.smartWizard.min.js"></script>

<style>

span{
  font-weight: 100;
}
    .form-group{margin-bottom: 5px; padding: 6px 0px;}
    .list-report-monthly .col-md-12{background: #f1f1f1;border-bottom: 1px solid #ccc;}
    .list-report-monthly .col-md-4{background: #e7f5ff;
                                    border-bottom: 1px solid #94d2ff;
                                    padding: 10px;
                                    border-right: 1px solid #94d2ff;
                                    color: #000;}
    .list-report-monthly .col-md-6{background: #e7f5ff;
                                    border-bottom: 1px solid #94d2ff;
                                    padding: 10px;
                                    border-right: 1px solid #94d2ff;
                                    color: #000;}

    .list-report-monthly .col-md-4 label {
    font-weight:bold !important;
}

    .report-monthly-second .col-md-4{min-height: 102px;}

    .report-monthly-third .col-md-4{min-height: 80px;}

    .list-report-monthly .col-md-4 label{font-size: 14px !important; line-height: 21px; font-weight: bold !important;}
    .list-report-monthly .col-md-6 label{font-size: 14px !important; line-height: 21px; font-weight: bold !important;}
    .list-report-monthly > h5.tab-title{margin-bottom: 0px;}
    .list-report-monthly > .col-md-12 > .row > h6{padding: 3px 10px;}
    #step-3 .x_content .form-group label{margin-bottom: 0px;}
    .list-report-monthly > .col-md-12 > .row > h6{background: none;}

    .form-main-labour h3:first-child{margin-left: 25px;}
</style>

<!--<script src="https://cdn.datatables.net/select/1.2.6/js/dataTables.select.min.js"/>
<script src="https://editor.datatables.net/extensions/Editor/js/dataTables.editor.min.js"/>-->
