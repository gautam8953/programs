<?php

class MentorModel extends CI_Model {
	function __construct() {
		parent::__construct();
	}


 			


	function getMentor(){
		$this->db->select('users.UserID,users.FirstName');
	    $this->db->from('users');
	    $this->db->join('userrole', 'users.UserID=userrole.UserID', 'inner');
	    if($this->session->userdata('RoleName')=='Mentor'){
	       $this->db->where('users.UserID',$this->session->userdata('UserID'));
         }
        $this->db->where('userrole.RoleID',12);
	    $this->db->order_by('users.UserID','DESC');
	    $query = $this->db->get();
		$Mentor=$query->result_array();
		$data['Mentoruser']=$Mentor;
	    return $data;
	}


	 function getSearchData($userID, $searchData, $search_state,$search_district,$search_facility) {
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
        $col = array(
            //0 => 'sr.stateId',
            
            0 => 'StateName ',
            1 => 'DistrictName',
            2 => 'FacilityName',
            3 => 'FacilityHead',
            4 => 'createdOn',
            
        );
        $this->db->select('count(pmu.id) recordCount');
        $this->db->from('mentor as pmu');
        $this->db->join('users pmuusers','pmu.UserID=pmuusers.UserID');
      
        $this->db->join('usermapping um','pmu.FacilityUserID=um.UserID AND um.FacilityID>0 AND um.IsActive=1');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
        $this->db->where('pmu.IsActive','1');
 
 // pmu -> user 2 (pmu, fCILITY)

        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
       
        
        if ($search_state != '') {
            $this->db->where('s.stateId', $search_state);
        }
         if ($search_district != '') {
            $this->db->where('d.DistrictID', $search_district);
        }
        if ($search_facility != '') {
            $this->db->where('pmu.FacilityUserID', $search_facility);
        }

       
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);

            $this->db->where("(f.FacilityName like '%" . $searchString . "%' OR pmuusers.FirstName like '%" . $searchString . "%' OR s.StateName like '%" . $searchString . "%' OR d.DistrictName like '%" . $searchString . "%' OR pmu.Date_of_visit like '%" . $searchString . "%' )", NULL, FALSE);
        }
        $queryTot = $this->db->get();
        $row = $queryTot->result();
        $totalRecordCount = $row[0]->recordCount;
       

        $this->db->select('s.StateName,pmu.id,f.FacilityName,d.DistrictName,pmuusers.FirstName,pmu.Date_of_visit,pmu.OrganizationName');
        $this->db->from('mentor as pmu');
        $this->db->join('users pmuusers','pmu.UserID=pmuusers.UserID');
      
        $this->db->join('usermapping um','pmu.FacilityUserID=um.UserID AND um.FacilityID>0 AND um.IsActive=1');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
        $this->db->where('pmu.IsActive','1');
       
        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
        
        if ($search_state != '') {
            $this->db->where('s.stateId', $search_state);
        }
         if ($search_district != '') {
            $this->db->where('d.DistrictID', $search_district);
        }
        if ($search_facility != '') {
            $this->db->where('pmu.FacilityUserID', $search_facility);
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);

            $this->db->where("(f.FacilityName like '%" . $searchString . "%' OR pmuusers.FirstName like '%" . $searchString . "%' OR pmu.Date_of_visit like '%" . $searchString . "%' OR s.StateName like '%" . $searchString . "%' OR d.DistrictName like '%" . $searchString . "%' )", NULL, FALSE);
        }
//        print_r($col[$searchData['order'][0]['column']]);
        $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
        $this->db->limit($this->input->post('length'), $this->input->post('start'));
        $query = $this->db->get();
//var_dump($searchData['order'][0]['dir']);
        $data['draw'] = $this->input->post('draw');
//        $data['totalData'] = $queryTot->num_rows();
        $data['totalData'] = $totalRecordCount;
        $data['totalFilter'] = $totalRecordCount;
//        $surveyFormLevel = $this->config->item('assesmentSequence');
        $dataget = array();
        $cnt=$this->input->post('start');

        //$access_add=$this->CommonModel->checkPageActionWeb('facility/index','access_add',$this->session->userdata('RoleName'));
        $access_edit=$this->CommonModel->checkPageActionWeb('pmu/index','access_edit',$this->session->userdata('RoleName'));
        $access_delete=$this->CommonModel->checkPageActionWeb('pmu/index','access_delete',$this->session->userdata('RoleName'));
        $access_view=$this->CommonModel->checkPageActionWeb('pmu/index','access_view',$this->session->userdata('RoleName'));
        foreach ($query->result() as $key => $value) {
        	// print_r($value);die;
            $subdata = array();
            $subdata[]=++$cnt;
            $valId=encryptor($value->id);
//            $subdata[] = $surveyFormLevel[$value->Sequence];
//            $subdata[] = $value->StateName;
           
            $subdata[] = "<span id='name_span_".$valId."'>".$value->StateName."</span><span><input type='hidden' id='name_".$valId."' maxlength='20' name='name' value='".$value->StateName."'/></span>";
          
            $subdata[] = "<span id='designation_span_".$valId."'>".$value->DistrictName."</span><span><input type='hidden' id='designation_".$valId."' maxlength='20' name='name' value='".$value->DistrictName."'/></span>";

             $subdata[] = "<span id='name_span_".$valId."'>".$value->FacilityName."</span><span><input type='hidden' id='name_".$valId."' maxlength='20' name='name' value='".$value->FacilityName."'/></span>";
            $subdata[] = "<span id='designationSmg_span_".$valId."'>".$value->FirstName."</span><span><input type='hidden' id='designationSmg_".$valId."' maxlength='20' name='name' value='".$value->FirstName."'/></span>";
            // $subdata[] = "<span id='mobile_span_".$valId."'>".$value->OrganizationName."</span><span><input type='hidden' id='mobile_".$valId."' maxlength='20' name='name' value='".$value->OrganizationName."'/></span>";
            $subdata[] = "<span id='email_span_".$valId."'>".$value->Date_of_visit."</span><span><input type='hidden' id='email_".$valId."' name='name' maxlength='20' value='".$value->Date_of_visit."'/></span>";
           
            $actionLink='';
            if($access_edit){
                $actionLink.='<button data-href="'.base_url().'mentor/add/'.$valId.'" onclick="pageRedirect(this)" data-ans="'.$valId.'" class="btn btn-info btn-xs getAssesment getAssesment1" ><i class="glyphicon glyphicon-check"></i> Edit</button>'
                  ;
            }
            if($access_delete){
                $actionLink.='<button data-href="" data-val="' . $valId . '"  onclick="removeDataRow(\'' . $valId . '\')" class="btn btn-danger btn-xs deleteRow "><i class="glyphicon glyphicon-trash"></i> Remove</button>';
            }
             if($access_view){
                $actionLink.='<button data-page="View" data-reqMonth="' . $valId . '" data-months="' . $valId . '" data-href="' . base_url() . 'mentor/view/' . $valId . '" onclick="pageRedirect(this)"  class="btn btn-primary btn-xs getScore view_edit_width" ><i class="glyphicon glyphicon-check"></i>View</button>';
            }
            $subdata[] = $actionLink;
            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;
    
        return $data;
    }

 function getUserId($id){
        $this->db->select('mentor.UserID,mentor.id,mentor.FacilityUserID');
        $this->db->from('mentor');
        $this->db->where('mentor.id',$id);
        $this->db->where('mentor.IsActive','1');
        $query = $this->db->get();
        return $query->row_array();
        

 }

function getFacilityDetails($userID){
        $this->db->select('facilities.FacilityID,facilities.services,facilities.FacilityName,facilities.FacilityNumber,facilities.Latitude,facilities.Longitude,facilities.Altitude,facilities.Address,facilities.PinCode,facilities.Address,facilities.landLine,facilities.ot_services,facilities.FacilityTypeDetailID,facilities.facilitytype_other,usermapping.UserID,district.DistrictID,district.DistrictName,states.StateID,states.StateName,typedetail.TypeDetailCode');
        $this->db->from('usermapping');
        $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
        $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'inner');
        $this->db->join('states', 'facilities.StateID=states.StateID', 'inner');
        $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');
        
        $this->db->where('usermapping.UserID',$userID);
        $query = $this->db->get();
        return $query->row_array();
    }


function getMentorDetails($mentorID){

        
        $this->db->select('mentor.*,users.FirstName');
        $this->db->from('users');
        $this->db->join('mentor', "users.UserID=mentor.UserID", 'inner');
        $this->db->where('mentor.id',$mentorID);
        $this->db->where('mentor.IsActive','1');
        $query = $this->db->get();
        return $query->row_array();
    }

    function  mentorDataEdit($mentorId){

        $this->db->select('facilities.StateID,states.StateName,facilities.DistrictID,district.DistrictName,facilities.FacilityName,pmuusers.FirstName,pmu.Date_of_visit,pmu.OrganizationName,pmu.Keyfindings,pmu.recommendations,pmu.FacilityUserID,pmu.UserID');
        $this->db->from('mentor as pmu');
        $this->db->join('users pmuusers','pmu.UserID=pmuusers.UserID');
      
        $this->db->join('usermapping', 'pmu.FacilityUserID=usermapping.UserID AND usermapping.FacilityID >0', 'left');
        $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'left');
        $this->db->join('states', 'facilities.StateID=states.StateID', 'left');
        $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'left');
        $this->db->where('pmu.id',$mentorId);
        $this->db->order_by('pmu.id', 'DESC');
        $this->db->limit('1');
        $result = $this->db->get();
        $data=$result->row_array();
        $response['code']=$result ->num_rows();
        $response['msg']=$result ->num_rows().' data get';
        $response['data']=$data;
        return $response;
    }

	// code by kunal pandey

	   function select_record($column_name, $table, $condition = "") {
        $this->db->select($column_name);
        $this->db->from($table);
        if ($condition) {
            foreach ($condition as $k => $v) {
                $this->db->where($k, $v);
            }
        }
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            foreach ($query->result() as $row1) {
                
            }
            return $row1->$column_name;
        } else {
            return false;
        }
    }

    public function updateData($table, $data, $condition) {
        foreach ($condition as $k => $v) {
            $this->db->where($k, $v);
        }
        $this->db->update($table, $data);
        return TRUE;
    }
    function updateRecord($table, $id, $data) {
        $condition = array('AnswerID' => $id);
        $this->db->where($condition);
        if($this->db->update($table, $data)=== FALSE){
            return false;
        } else {
            return true;            
        }
    } 

}