<?php

class PmuModel extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	function getPmu(){
		$this->db->select('users.UserID,users.FirstName');
	    $this->db->from('users');
	    $this->db->join('userrole', 'users.UserID=userrole.UserID', 'inner');
	    if($this->session->userdata('RoleName')=='Pmu'){
	       $this->db->where('users.UserID',$this->session->userdata('UserID'));
         }
        $this->db->where('userrole.RoleID',11);
	    $this->db->order_by('users.UserID','DESC');
	    $query = $this->db->get();
		$Pmuuser=$query->result_array();
		$data['Pmuuser']=$Pmuuser;
	    return $data;
	}
	function getSearchData($userID, $searchData, $search_state,$search_district,$search_facility){
        $data = array('draw' => 0, 'totalData' => 0, 'totalFilter' => 0, 'data' => array());
        $col = array();
        if(!empty($this->session->userdata('showState'))){
            $col[]='s.StateName';
        }
        if(!empty($this->session->userdata('showDistrict'))){
            $col[]='d.DistrictName';
        }
        if(!empty($this->session->userdata('showFacilities'))){
            $col[]='f.facilityName';
        }
        $col[]='answer.FacilityHead';

        $this->db->select('pmu.id');
        $this->db->from('pmu as pmu');
        $this->db->join('usermapping um','pmu.FacilityUserID=um.UserID AND um.FacilityID>0 AND um.IsActive=1');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND s.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND d.IsActive=1', 'inner');
        $this->db->join('users pmuusers','pmu.UserID=pmuusers.UserID', 'inner');
        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
        $this->db->where('pmu.IsActive','1');        
        if ($search_state != '') {
            $this->db->where('s.stateId', $search_state);
        }
         if ($search_district != '') {
            $this->db->where('d.DistrictID', $search_district);
        }
        if ($search_facility != '') {
            $this->db->where('pmu.FacilityUserID', $search_facility);
        }       
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);
            $this->db->where("(f.FacilityName like '%" . $searchString . "%' OR pmuusers.FirstName like '%" . $searchString . "%' OR s.StateName like '%" . $searchString . "%' OR d.DistrictName like '%" . $searchString . "%' OR pmu.Date_of_visit like '%" . $searchString . "%' )", NULL, FALSE);
        }
        $queryTot = $this->db->get();

        $this->db->select('s.StateName,pmu.id,f.FacilityName,d.DistrictName,pmuusers.FirstName,pmu.Date_of_visit');
        $this->db->from('pmu as pmu');
      
        $this->db->join('usermapping um','pmu.FacilityUserID=um.UserID AND um.FacilityID>0 AND um.IsActive=1');
        $this->db->join('facilities f', 'f.FacilityID=um.FacilityID AND um.FacilityID>0 AND f.IsActive=1', 'inner');
        $this->db->join('states s','f.StateID=s.StateID AND f.IsActive=1', 'inner');
        $this->db->join('district d','f.DistrictID=d.DistrictID AND f.IsActive=1', 'inner');
        $this->db->join('users pmuusers','pmu.UserID=pmuusers.UserID');
        $this->db->where('pmu.IsActive','1');       
        if(!empty($searchData['cond'])){
            $this->db->where_in($searchData['cond']['mappedField'],$searchData['cond']['mappedData']);
        }
        if ($search_state != '') {
            $this->db->where('s.stateId', $search_state);
        }
         if ($search_district != '') {
            $this->db->where('d.DistrictID', $search_district);
        }
        if ($search_facility != '') {
            $this->db->where('pmu.FacilityUserID', $search_facility);
        }
        if (!empty($searchData['search']['value'])) {
            $searchString = trim($searchData['search']['value']);

            $this->db->where("(f.FacilityName like '%" . $searchString . "%' OR pmuusers.FirstName like '%" . $searchString . "%' OR pmu.Date_of_visit like '%" . $searchString . "%' OR s.StateName like '%" . $searchString . "%' OR d.DistrictName like '%" . $searchString . "%' )", NULL, FALSE);
        }
        $this->db->order_by($col[$searchData['order'][0]['column']], $searchData['order'][0]['dir']);
        $this->db->limit($this->input->post('length'), $this->input->post('start'));
        $query = $this->db->get();
        $data['draw'] = $this->input->post('draw');
        $data['totalData'] = $queryTot->num_rows();
        $data['totalFilter'] = $queryTot->num_rows();
        $dataget = array();
        $cnt=$this->input->post('start');

        $access_edit=$this->CommonModel->checkPageActionWeb('pmu/index','access_edit',$this->session->userdata('RoleName'));
        $access_delete=$this->CommonModel->checkPageActionWeb('pmu/index','access_delete',$this->session->userdata('RoleName'));
        $access_view=$this->CommonModel->checkPageActionWeb('pmu/index','access_view',$this->session->userdata('RoleName'));
        foreach ($query->result() as $key => $value) {
            $subdata = array();
            $subdata[]=++$cnt;
            $valId=encryptor($value->id);
            if($this->session->userdata('showState')){
                $subdata[]=$value->StateName;               
            }
            if($this->session->userdata('showDistrict')){
                $subdata[]=$value->DistrictName;                
            }
            if($this->session->userdata('showFacilities')){
                $subdata[]=$value->FacilityName;                
            }
            $subdata[] = "<span id='designationSmg_span_".$valId."'>".$value->FirstName."</span><span><input type='hidden' id='designationSmg_".$valId."' maxlength='20' name='name' value='".$value->FirstName."'/></span>";
            $subdata[] = "<span id='email_span_".$valId."'>".$value->Date_of_visit."</span><span><input type='hidden' id='email_".$valId."' name='name' maxlength='20' value='".$value->Date_of_visit."'/></span>";
           
            $actionLink='';
            if($access_edit){
                $actionLink.='<button data-href="'.base_url().'pmu/add/'.$valId.'" onclick="pageRedirect(this)" data-ans="'.$valId.'" class="btn btn-info btn-xs getAssesment getAssesment1" ><i class="glyphicon glyphicon-check"></i> Edit</button>'
                  ;
            }
            if($access_delete){
                $actionLink.='<button data-href="" data-val="' . $valId . '"  onclick="removeDataRow(\'' . $valId . '\')" class="btn btn-danger btn-xs deleteRow "><i class="glyphicon glyphicon-trash"></i> Remove</button>';
            }
             if($access_view){
                $actionLink.='<button data-page="View" data-reqMonth="' . $valId . '" data-months="' . $valId . '" data-href="' . base_url() . 'pmu/view/' . $valId . '" onclick="pageRedirect(this)"  class="btn btn-primary btn-xs getScore view_edit_width" ><i class="glyphicon glyphicon-check"></i>View</button>';
            }
            $subdata[] = $actionLink;
            $dataget[] = $subdata;
        }
        $data['data'] = $dataget;
    
        return $data;
    }

 function getUserId($id){
        $this->db->select('pmu.UserID,pmu.id,pmu.FacilityUserID');
        $this->db->from('pmu');
        $this->db->where('pmu.id',$id);
        $this->db->where('pmu.IsActive','1');
        $query = $this->db->get();
        return $query->row_array();
        

 }

function getFacilityDetails($userID){
        $this->db->select('facilities.FacilityID,facilities.services,facilities.FacilityName,facilities.FacilityNumber,facilities.Latitude,facilities.Longitude,facilities.Altitude,facilities.Address,facilities.PinCode,facilities.Address,facilities.landLine,facilities.ot_services,facilities.FacilityTypeDetailID,facilities.facilitytype_other,usermapping.UserID,district.DistrictID,district.DistrictName,states.StateID,states.StateName,typedetail.TypeDetailCode');
        $this->db->from('usermapping');
        $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'inner');
        $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'inner');
        $this->db->join('states', 'facilities.StateID=states.StateID', 'inner');
        $this->db->join('typedetail', 'facilities.FacilityTypeDetailID=typedetail.TypeDetailID', 'left');
        
        $this->db->where('usermapping.UserID',$userID);
        $query = $this->db->get();
        return $query->row_array();
    }


function getPmuDetails($pmuID){

        
        $this->db->select('pmu.*,users.FirstName');
        $this->db->from('users');
        $this->db->join('pmu', "users.UserID=pmu.UserID", 'inner');
        $this->db->where('pmu.id',$pmuID);
        $this->db->where('pmu.IsActive','1');
        $query = $this->db->get();
        return $query->row_array();
    }

    function pmuDataEdit($pmuId){

        $this->db->select('facilities.StateID,states.StateName,facilities.DistrictID,district.DistrictName,facilities.FacilityName,pmuusers.FirstName,pmu.Date_of_visit,pmu.Keyfindings,pmu.recommendations,pmu.FacilityUserID,pmu.UserID');
        $this->db->from('pmu as pmu');
        $this->db->join('users pmuusers','pmu.UserID=pmuusers.UserID');
      
        $this->db->join('usermapping', 'pmu.FacilityUserID=usermapping.UserID AND usermapping.FacilityID >0', 'left');
        $this->db->join('facilities', 'usermapping.FacilityID=facilities.FacilityID', 'left');
        $this->db->join('states', 'facilities.StateID=states.StateID', 'left');
        $this->db->join('district', 'facilities.DistrictID=district.DistrictID', 'left');
        $this->db->where('pmu.id',$pmuId);
        $this->db->order_by('pmu.id', 'DESC');
        $this->db->limit('1');
        $result = $this->db->get();
        $data=$result->row_array();
        $response['code']=$result ->num_rows();
        $response['msg']=$result ->num_rows().' data get';
        $response['data']=$data;
        return $response;
    }

	// code by kunal pandey

	   function select_record($column_name, $table, $condition = "") {
        $this->db->select($column_name);
        $this->db->from($table);
        if ($condition) {
            foreach ($condition as $k => $v) {
                $this->db->where($k, $v);
            }
        }
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            foreach ($query->result() as $row1) {
                
            }
            return $row1->$column_name;
        } else {
            return false;
        }
    }

    public function updateData($table, $data, $condition) {
        foreach ($condition as $k => $v) {
            $this->db->where($k, $v);
        }
        $this->db->update($table, $data);
        return TRUE;
    }
    function updateRecord($table, $id, $data) {
        $condition = array('AnswerID' => $id);
        $this->db->where($condition);
        if($this->db->update($table, $data)=== FALSE){
            return false;
        } else {
            return true;            
        }
    } 

}