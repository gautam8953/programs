<?php  
defined('BASEPATH') OR exit('No direct script access allowed');



class Pmu extends CI_Controller {
	public function __construct()
	{
		parent :: __construct();
		$userID=$this->session->userdata('UserID');
		if(empty($userID)){ redirect('user/login'); }
		$this->load->model('FacilityModel');
		$this->load->model('PmuModel');
	}
		
	public function index(){
		$this->CommonModel->checkPageAccessWeb('pmu/index',$this->session->userdata('RoleName'));

		$data=array();
		$data['search_options']=$this->FacilityModel->getSearchOptions();		
		$this->load->view('header');
		$this->load->view('pmu/index',$data);
		$this->load->view('footer');
	}

	
	

	function add($id=''){

	
		$this->CommonModel->checkPageAccessWeb('pmu/add',$this->session->userdata('RoleName'));
	   		$uriParam=$id;
	   	$data=array();
		 if(!empty($uriParam)){
			$id =encryptor($uriParam,'decrypt');
			$data = $this->PmuModel->getUserId($id);
	
			$userID= $data['UserID'];
			$pmuID= $data['id'];
			$FacilityUserID= $data['FacilityUserID'];

		
       
        if($this->session->userdata('RoleName')=='Pmu'){
          $data['mainProfile']='Pmu';
         
          $data['facility_types']=$this->CommonModel->getfacilityType();
        }
         $data['facilitys']=$this->PmuModel->getFacilityDetails($FacilityUserID);
        
         $data['main']=$this->PmuModel->getPmuDetails($pmuID);
		 }else{
		 	 $userID = $this->session->userdata('UserID');
		 }
	
		$data['search_options']=$this->FacilityModel->getSearchOptions();
		$data['pmu']=$this->PmuModel->getPmu();

		//echo "<pre>";
		//print_r($data);

		$this->load->view('header');
		$this->load->view('pmu/add',$data);
		$this->load->view('footer');
	}

	 public function view() {
	    $uriParam=$this->uri->segment('3');
		 if(!empty($uriParam)){
			$id =encryptor($uriParam,'decrypt');
			$data = $this->PmuModel->getUserId($id);
	
			$userID= $data['UserID'];
			$pmuID= $data['id'];
			$FacilityUserID= $data['FacilityUserID'];
		 }else{
		 	 $userID = $this->session->userdata('UserID');
		 }

        if (empty($userID)) {
            redirect('user/login');
        }
         $data=array();
       
        if($this->session->userdata('RoleName')=='Pmu'){
          $data['mainProfile']='Pmu';
         
          $data['facility_types']=$this->CommonModel->getfacilityType();
        }
         $data['facility']=$this->PmuModel->getFacilityDetails($FacilityUserID);
        
         $data['main']=$this->PmuModel->getPmuDetails($pmuID);
         $this->load->view('header');
        $this->load->view('pmu/view',$data);
        $this->load->view('footer');
	}




	



}


