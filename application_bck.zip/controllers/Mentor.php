<?php  
defined('BASEPATH') OR exit('No direct script access allowed');



class Mentor extends CI_Controller {
	public function __construct()
	{
		parent :: __construct();
		$userID=$this->session->userdata('UserID');
		if(empty($userID)){ redirect('user/login'); }
		$this->load->model('MentorModel');
		$this->load->model('FacilityModel');
	}
		
	public function index(){
		$this->CommonModel->checkPageAccessWeb('facility/index',$this->session->userdata('RoleName'));
		$data=array();
		$data['search_options']=$this->FacilityModel->getSearchOptions();		
		//print_r($data);die;
		$this->load->view('header');
		$this->load->view('mentor/index',$data);
		$this->load->view('footer');
	}

	
	

	// function add(){
	// 	$this->CommonModel->checkPageAccessWeb('pmu/add',$this->session->userdata('RoleName'));
	// 	$data=array();
	// 	$data['search_options']=$this->MentorModel->getSearchOptions();
	// 	$this->load->view('header');
	// 	$this->load->view('mentor/add',$data);
	// 	$this->load->view('footer');
	// }

    function add($id=''){

	
		$this->CommonModel->checkPageAccessWeb('mentor/add',$this->session->userdata('RoleName'));
	   		$uriParam=$id;
	   	$data=array();
		 if(!empty($uriParam)){
			$id =encryptor($uriParam,'decrypt');
			$data = $this->MentorModel->getUserId($id);
	
			$userID= $data['UserID'];
			$mentorID= $data['id'];
			$FacilityUserID= $data['FacilityUserID'];

		
       
        if($this->session->userdata('RoleName')=='Mentor'){
          $data['mainProfile']='Mentor';
         
          $data['facility_types']=$this->CommonModel->getfacilityType();
        }
         $data['facilitys']=$this->MentorModel->getFacilityDetails($FacilityUserID);
        
         $data['main']=$this->MentorModel->getMentorDetails($mentorID);
		 }else{
		 	 $userID = $this->session->userdata('UserID');
		 }
	
		$data['search_options']=$this->FacilityModel->getSearchOptions();
		$data['mentor']=$this->MentorModel->getMentor();

		// echo "<pre>";
		// print_r($data);

		$this->load->view('header');
		$this->load->view('mentor/add',$data);
		$this->load->view('footer');
	}



 public function view() {
	    $uriParam=$this->uri->segment('3');
	    //print_r($uriParam);
	    //die;
		 if(!empty($uriParam)){
			$id =encryptor($uriParam,'decrypt');
			$data = $this->MentorModel->getUserId($id);
	
			$userID= $data['UserID'];
			$pmuID= $data['id'];
			$FacilityUserID= $data['FacilityUserID'];
		 }else{
		 	 $userID = $this->session->userdata('UserID');
		 }

        if (empty($userID)) {
            redirect('user/login');
        }
         $data=array();
       
        if($this->session->userdata('RoleName')=='Mentor'){
          $data['mainProfile']='Pmu';
         
          $data['facility_types']=$this->CommonModel->getfacilityType();
        }
         $data['facility']=$this->MentorModel->getFacilityDetails($FacilityUserID);
        
         $data['main']=$this->MentorModel->getMentorDetails($pmuID);

        $this->load->view('header');
        $this->load->view('mentor/view',$data);
        $this->load->view('footer');
	}

	



}


